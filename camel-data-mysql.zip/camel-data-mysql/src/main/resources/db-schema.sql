CREATE TABLE employees (
  empId VARCHAR(10) NOT NULL,
  empName VARCHAR(100) NOT NULL
);