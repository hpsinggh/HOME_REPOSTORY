package com.javainuse.exception;

public class CamelCustomException extends Exception {

    private static final long serialVersionUID = 1L;

}
