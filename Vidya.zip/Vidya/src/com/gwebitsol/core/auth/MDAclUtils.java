/*
Proprietary Notice
This file contains confidential information of meldit Pvt. Ltd. (India)  and meldit Inc. (USA), 
which is available for the sole purpose of permitting the recipient for engineering and product development purposes.  
In consideration of receipt of this file, the recipient agrees to maintain such information in confidence and not to
reproduce or otherwise disclose this information to any person outside the group directly responsible for its contents.

Security
The information contained herein is proprietary to meldit Pvt. Ltd. (India)  and meldit Inc. (USA) and may not be used, 
reproduced or disclosed.  The recipient of this file, by its retention and use, agrees to protect the same and the 
information contained therein from distribution, loss and theft.
__________________________________________________________________________________________________________________________________________________________________________________
*/

package com.gwebitsol.core.auth;

public class MDAclUtils 
{
	//generate "U#64:" only
	public String generateACLString(int userid)
	{
		StringBuffer sb=new StringBuffer();
		sb.append("U#");
		sb.append(userid);
		sb.append(":");
		
		return sb.toString();
	
	}
	

	//gives "100" for "U#64:100", etc 
	public int getACLvalue(String aclString)
	{
		int aclVal = 0;
		String [] uacl = aclString.split(":");
		aclVal = Integer.valueOf(uacl[1]);
		
		return aclVal;
	}
	
	//gives "RWD" for "U#64:111" , etc
	public String getRightsString(String aclString)
	{
		int aclval = getACLvalue(aclString);
		String rightsString = getACLRights(aclval);
	
		return rightsString;
	}
	
	//gives "111" for "RWD", etc
	public int getRightsValue(String rightString)
	{
		int aclVal = 0;
		if (rightString.equals("RWD")) aclVal=111;
		if (rightString.equals("RW")) aclVal=110;
		if (rightString.equals("R")) aclVal=100;
				
		return aclVal;
	}
		
	
	//gives "RW" for "110", etc 
	public String getACLRights(int aclVal)
	{
		String rightsString  = null;
		if (aclVal==111) rightsString = "RWD";
		if (aclVal==110) rightsString = "RW";
		if (aclVal==100) rightsString = "R";
		
		return rightsString;
	
	}
	
	
}








