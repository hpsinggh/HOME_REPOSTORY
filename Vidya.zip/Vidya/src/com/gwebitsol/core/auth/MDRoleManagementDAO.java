/*
_________________________________________________________________________________________________________________________________________________________________________

Proprietary Notice
This file contains confidential information of Tata Associates, which is available for the sole purpose of permitting 
the recipient for engineering and product development purposes.  
In consideration of receipt of this file, the recipient agrees to maintain such information in confidence and not to
reproduce or otherwise disclose this information to any person outside the group directly responsible for its contents.

Security
The information contained herein is proprietary to Tata Associates and may not be used, 
reproduced or disclosed.  The recipient of this file, by its retention and use, agrees to protect the same and the 
information contained therein from distribution, loss and theft.
__________________________________________________________________________________________________________________________________________________________________________________
*/

package com.gwebitsol.core.auth;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.auth.MDRolePOJO;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

 
public class MDRoleManagementDAO
{
	public String addRole(MDRolePOJO rolePOJO) 
	{
		Session arSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction arTx=null;
		String xmlStr=null;
		//String newacl=rolePOJO.getPrivilegeString();
		try
		{  
			arTx=arSession.beginTransaction();
			Integer roleid = (Integer) arSession.save(rolePOJO);
			System.out.println(roleid);
			
			
			String prvstr= rolePOJO.getPrivilegeString();
			String[] prvstr1= prvstr.split(";");
			for(String s:prvstr1)
			{
			String[] prvstr2= s.split(":");
			for(String s1:prvstr2)
			{
				System.out.println(s1);
				int i = Integer.parseInt(s1);
				String privilegename =(String)arSession.createSQLQuery("Select privilegename from mdprivileges where privilegeid='"+i+"'").uniqueResult();
				String actacl = (String)arSession.createSQLQuery("Select ACL from mdfolder where foldername='"+privilegename+"' and (foldertype ='M' or foldertype='iF') ").uniqueResult();
				//if(actacl!=null)
			//	{
				if(actacl!=null && actacl.indexOf("R#"+roleid)==-1)
				{
					actacl=actacl+"R#"+roleid+":"+prvstr2[1]+";";
					String qquery = "Update mdfolder set acl = '"+actacl+"' where foldername='"+privilegename+"' and (foldertype ='M' or foldertype='iF') ";
				Query nQuery=arSession.createSQLQuery(qquery);
				nQuery.executeUpdate();
				}
//				}else
//				{
//				actacl=(String)arSession.createSQLQuery("Update mdfolder set acl = R#'"+rolePOJO.getPrivilegeString()+"' where foldername='"+privilegename+"'").uniqueResult();
//				Query aQuery=arSession.createSQLQuery(actacl);
//				aQuery.executeUpdate();
//				}
				}
			}
			arTx.commit();
			xmlStr="success";
			
		}
		catch (Exception localException) 
		{
			arTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			xmlStr="fail";
		} 
		finally
		{
			arSession.close();
		}
		return xmlStr;
	}
	public String updaterole(MDRole mdrole,int userID) 

	{
		Session urSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction urTx=null;
		String XMLStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String d=dateFormat.format(date);
		try
		{  

			urTx=urSession.beginTransaction();
		    int id =(Integer)urSession.createSQLQuery("select roleid from mdrole where rolename= '"+mdrole.getRoleName()+"'").uniqueResult();
		    MDRolePOJO rolePOJO=(MDRolePOJO)urSession.load(MDRolePOJO.class, id);
			rolePOJO.setPrivilegeString(mdrole.getPrivilegeString());
			rolePOJO.setModifiedBy(Integer.toString(userID));
			rolePOJO.setModifiedDate(d);
			rolePOJO.setDescription(mdrole.getDescription());	
			urSession.save(rolePOJO);
			
			urTx.commit();
			System.out.println(mdrole.getRoleName()+" : Role successfully updated");
			XMLStr= "success";
		}
		catch (Exception localException) 
		{
			urTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			XMLStr="fail";
		} 
		finally
		{
			urSession.close();
		}
		return XMLStr;
	}
	@SuppressWarnings({ "rawtypes", "deprecation" })
	public String deleterole(String roleName,int uid) 
	{
		Session drSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction drTx=null;
		String rtnString=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String d=dateFormat.format(date);
		String rolename=";"+roleName+";";
		try
		{
			System.out.println("inside delete role");
			drTx=drSession.beginTransaction();
			String drSql="select * from mdusers where rolestring like '%"+rolename+"%'";
			Query drQuery=drSession.createSQLQuery(drSql).addScalar("userid",Hibernate.INTEGER).addScalar("rolestring",Hibernate.STRING);
			List drList=drQuery.list();
			System.out.println("Size of List"+drList.size());
			if(drList.isEmpty())
			{
				String drSql2="delete from mdrole where roleName='"+roleName+"'";
				Query drQuery2=drSession.createSQLQuery(drSql2);
				drQuery2.executeUpdate();
			}
			else
			{
			Iterator drIT=drList.iterator();
			while(drIT.hasNext())
			{
				Object[] drObj=(Object[])drIT.next();
				int userID=(Integer)drObj[0];
				String roleString=(String)drObj[1];
				String modifiedString=roleString.replace(rolename,"");
				System.out.println("actual roleString"+roleString);
				System.out.println("modified roleString"+modifiedString);
				
				String drSql1="update mdusers set roleString='"+modifiedString+"',modifieddate='"+d+"',modifiedby="+uid+" where userid="+userID;
				Query drQuery1=drSession.createSQLQuery(drSql1);
				drQuery1.executeUpdate();	
				
				String drSql2="SELECT * FROM MDFOLDER WHERE PARENTFOLDERID=1 AND ACL LIKE '%U#"+userID+":111%'";
				Query drQuery2=drSession.createSQLQuery(drSql2).addScalar("folderid",Hibernate.INTEGER).addScalar("acl",Hibernate.STRING);
				List drList1=drQuery2.list();
				Iterator drIT1=drList1.iterator();
				while(drIT1.hasNext())
				{
					Object[] drObj1=(Object[])drIT1.next();
					int folderID=(Integer)drObj1[0];
					String acl=(String)drObj1[1];
					String modifiedAcl=acl.replaceAll(";U#"+userID+":111","");
					System.out.println("actual acl"+acl);
					System.out.println("modified acl"+modifiedAcl);
					
					String drSql3="update mdfolder set acl='"+modifiedAcl+"',modifieddate='"+d+"',modifiedby="+uid+" where folderid="+folderID;
					Query drQuery3=drSession.createSQLQuery(drSql3);
					drQuery3.executeUpdate();
				}
			}
			
			String drSql2="delete from mdrole where roleName='"+roleName+"'";
			Query drQuery2=drSession.createSQLQuery(drSql2);
			drQuery2.executeUpdate();
			}
			drTx.commit();
			rtnString="success";
		}
		catch(Exception localException)
		{
			drTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			rtnString="fail";
		}
		finally
		{
			drSession.close();
		}
		
		return rtnString;
	}	
	@SuppressWarnings("rawtypes")
	public String getRolesList()
	{
		Session grSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction grTx=null;
		StringBuffer roleBuffer=new StringBuffer();
		String XMLStr=null;
		try
		{  
			grTx=grSession.beginTransaction();
			String hqlQuery="from MDRolePOJO";
			Query grQuery=grSession.createQuery(hqlQuery);
			List rList=grQuery.list();
			Iterator rIT=rList.iterator();
			roleBuffer.append("<MD_Roles>");roleBuffer.append("\n");
			while(rIT.hasNext())
			{
				MDRolePOJO rolePOJO=(MDRolePOJO)rIT.next();
				roleBuffer.append("<MD_Role>");roleBuffer.append("\n");
				roleBuffer.append("<RoleId>");
				roleBuffer.append(rolePOJO.getRoleID());
				roleBuffer.append("</RoleId>");roleBuffer.append("\n");
				roleBuffer.append("<RoleName>");
				roleBuffer.append(rolePOJO.getRoleName());
				roleBuffer.append("</RoleName>");roleBuffer.append("\n");
				roleBuffer.append("<Description>");
				roleBuffer.append(rolePOJO.getDescription());
				roleBuffer.append("</Description>");roleBuffer.append("\n");
				roleBuffer.append("</MD_Role>");roleBuffer.append("\n");
			}
			roleBuffer.append("</MD_Roles>");
			grTx.commit();
			XMLStr=roleBuffer.toString();
		}
		catch (Exception localException) 
		{
			grTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			XMLStr="fail";
		} 
		finally
		{
			grSession.close();
			roleBuffer=null;
		}
		return XMLStr;
	}
	public MDRolePOJO getRoledetails(String rolename)
	{
		Session rdSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx=null;
		MDRolePOJO rolePOJO=new MDRolePOJO();
		try
		{  
			rdTx=rdSession.beginTransaction();
			Integer roleID=(Integer)rdSession.createSQLQuery("select roleid from mdrole where rolename='"+rolename+"'").uniqueResult();
			if(roleID!=null)
			{
				rolePOJO=(MDRolePOJO)rdSession.get(MDRolePOJO.class,roleID);
			}
			else
			{
				rolePOJO=null;
			}
			rdTx.commit();
		}
		catch (Exception localException) 
		{
			rdTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
		} 
		finally
		{
			rdSession.close();

		}
		return rolePOJO;

	}

	@SuppressWarnings({"deprecation", "rawtypes" })
	public String assignRoleToUser(String toUserName,String nwroleString,HashMap prvMap)
	{
		Session arSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction arTx=null;
		String statusStr=null;
					
		try
			{  
				arTx=arSession.beginTransaction();
				String sqlQuery="select * from mdusers where username='"+toUserName+"'";
				Query objQuery=arSession.createSQLQuery(sqlQuery).addScalar("userid",Hibernate.INTEGER).addScalar("rolestring",Hibernate.STRING);
				List objList=objQuery.list();
				Iterator rit=objList.iterator();
				Integer usrid=null;
				String extroleStr=null;
				String updroleStr=null;
				String newRoles [] = nwroleString.split(";");
				System.out.println(nwroleString);
				
				while(rit.hasNext())
				{
				Object[] userObj=(Object[])rit.next();
				usrid=(Integer)userObj[0];
				System.out.println(usrid);
				extroleStr=(String)userObj[1];
				System.out.println(extroleStr);
				}
				
				
				if(extroleStr.equals(null)||extroleStr.equals("")) {
					updroleStr=nwroleString+";";
					System.out.println("User has no existing roles");
				}
				else			
				{ 				
					String [] nRoles = nwroleString.toLowerCase().split(";");
					String [] eRoles = extroleStr.toLowerCase().split(";");
					updroleStr = extroleStr;
					for (int k = 0; k < nRoles.length ; k++) {
						if (!(Arrays.asList(eRoles).contains(nRoles[k])))				
						updroleStr=updroleStr+newRoles[k]+";";
					}				
				}
										
				Query userQuery1=arSession.createSQLQuery("update mdusers set rolestring='"+updroleStr+"' where userid="+(int)usrid);
				userQuery1.executeUpdate();
				
				// Existing Code moved as a Separate method - MDGetPrivilegesDAO.assignUserACL(String userId, HashMap prvMap)	
				System.out.println("Creating User ACL Privilege Set");
				MDGetPrivilegesDAO gpdao = new MDGetPrivilegesDAO();			
				statusStr = gpdao.assignUserACL(usrid, prvMap);
			
				arTx.commit();
				//statusStr="success";
	
			}

			catch (Exception localException) 
			{
				arTx.rollback();
				MDTransactionWriter.exceptionlog.info(localException);
				statusStr="fail";
			} 
			finally
			{
				arSession.close();
			}
		
		return statusStr;
	
	}
	
	
	@SuppressWarnings({ "deprecation", "rawtypes" })
	public String removeRoleFromUser(String removeFromUser, String rmroleString, HashMap<String, String> prvMap) 
	
	{
		Session arSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction arTx=null;
		String statusStr=null;
			
		try
		{  
			arTx=arSession.beginTransaction();
			String sqlQuery="select * from mdusers where username='"+removeFromUser+"'";
			Query objQuery=arSession.createSQLQuery(sqlQuery).addScalar("userid",Hibernate.INTEGER).addScalar("rolestring",Hibernate.STRING);
			List objList=objQuery.list();
			Iterator rit=objList.iterator();
			Integer usrid=null;
			String extroleStr=null;
			rmroleString = rmroleString.toLowerCase();	
			HashMap updprvMap=null;
			String updroleStr=null;
			//String newRoles [] = rmroleString.split(";");
			System.out.println(rmroleString);
			
						
			while(rit.hasNext())
			{
			Object[] userObj=(Object[])rit.next();
			usrid=(Integer)userObj[0];
			System.out.println(usrid);
			extroleStr=(String)userObj[1];
			System.out.println(extroleStr);
			}
			
			extroleStr = extroleStr.toLowerCase();
											
			if(extroleStr.equals(null) || extroleStr.equals("")) 
			{
				updroleStr=rmroleString;
				statusStr= rmroleString + " : Role NOT Assigned to User"; 
				}
			else
			{ 
				updroleStr=extroleStr.replace(rmroleString+";", "");
			
			Query userQuery1=arSession.createSQLQuery("update mdusers set rolestring='"+updroleStr+"' where userid="+(int)usrid);
			userQuery1.executeUpdate();
			
			
			// Existing Code moved as a Separate method - MDGetPrivilegesDAO.assignUserACL(String userId, HashMap prvMap, HashMap extprvMap)	
			System.out.println("Removing User ACL Privilege set");
			MDGetPrivilegesDAO gpdao = new MDGetPrivilegesDAO();
			statusStr = gpdao.removeUserACL(usrid, prvMap);
			
			if (!(updroleStr.equals(null)||updroleStr.equals(""))) {
			updprvMap = gpdao.getPrivilegesMap(updroleStr);
			statusStr = gpdao.assignUserACL(usrid, updprvMap);
			}
			
			arTx.commit();
			//statusStr="success";
			}

		}
		catch (Exception localException) 
		{
			arTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			statusStr="fail";
		} 
		finally
		{
			arSession.close();

		}
		return statusStr;

	}
	
	
	@SuppressWarnings({ "deprecation", "rawtypes" })
	public String updateUsersForRole(int updUserID, MDRole mdRole, HashMap<String, String> prvMap) 
	
	{
		Session arSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction arTx=null;
		String statusStr=null;
		String roleName = mdRole.getRoleName();
		try
		{  
			arTx=arSession.beginTransaction();
			String sqlQuery="select * from mdusers where rolestring like '%"+roleName+"%'";
			Query objQuery=arSession.createSQLQuery(sqlQuery).addScalar("userid",Hibernate.INTEGER).addScalar("username",Hibernate.STRING).addScalar("rolestring",Hibernate.STRING);
			List objList=objQuery.list();
			Iterator rit=objList.iterator();
			HashMap updprvMap = null;
			MDGetPrivilegesDAO gpdao = new MDGetPrivilegesDAO();
			String XMLString=updaterole(mdRole, updUserID);
			statusStr = XMLString;
			updprvMap = gpdao.getPrivilegesMap(roleName);
			
			if (!objList.isEmpty())
			{
				Integer userId = null;
				while(rit.hasNext())
				{
					Object[] userObj=(Object[])rit.next();
					userId = (Integer)userObj[0];
					
					System.out.println(userId);
					statusStr = gpdao.removeUserACL(userId, prvMap);
					statusStr = gpdao.assignUserACL(userId, updprvMap);
				}
				
				arTx.commit();
			}

			System.out.println(roleName+" : No users are assigned!");
		}
		catch (Exception localException) 
		{
			arTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			statusStr="fail";
		} 
		finally
		{
			arSession.close();

		}
		return statusStr;

	}
	
	
	@SuppressWarnings({ "unchecked", "rawtypes", "deprecation" })
	public String assignRoleToGroup(String toGroupName,String roleString,HashMap prvMap)
	{
		Session artgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction artgTx=null;
		String statusStr=null;
		Set<String> ts=new TreeSet<String>();
		try
		{  
			artgTx=artgSession.beginTransaction();
			String sqlQuery="select * from mdgroups where groupname='"+toGroupName+"'";
			Query objQuery=artgSession.createSQLQuery(sqlQuery).addScalar("groupid",Hibernate.INTEGER).addScalar("rolestring",Hibernate.STRING);
			List objList=objQuery.list();
			Iterator rit=objList.iterator();
			Integer grpid=null;
			String roleStr=null;
			while(rit.hasNext())
			{
			Object[] userObj=(Object[])rit.next();
			grpid=(Integer)userObj[0];
			System.out.println(grpid);
			roleStr=(String)userObj[1];
			System.out.println(roleStr);
			}
			if(roleStr.equals("null"))
			roleStr=roleString;
			else
				roleStr=roleStr+";"+roleString;
			
			Query userQuery1=artgSession.createSQLQuery("update mdgroups set rolestring='"+roleStr+"' where groupid="+(int)grpid);
			userQuery1.executeUpdate();
			System.out.println("going to call set");
			ts=prvMap.keySet();
			System.out.println(ts);
			String[] prvNames=ts.toArray(new String[0]);
			System.out.println(prvNames);
			Arrays.toString(prvNames);
			int p=prvNames.length;
			System.out.println(p);
			for(int k=0;k<p;k++)
			{
				String rightStr=null;
				System.out.println("entered into DAO for loop");
				String prvName=prvNames[k];
				rightStr=(String)prvMap.get(prvName);
				System.out.println(rightStr);
				
				String aclStr=(String)artgSession.createSQLQuery("select acl from mdfolder where foldername='"+prvName+"'").uniqueResult();
				if(rightStr.equals("R"))
					aclStr=aclStr+";"+"U#"+grpid+":100";
				else if(rightStr.equals("RW"))
					aclStr=aclStr+";"+"U#"+grpid+":110";
				else
					aclStr=aclStr+";"+"U#"+grpid+":111";
				
				Query userQuery2=artgSession.createSQLQuery("update mdfolder set acl='"+aclStr+"' where foldername='"+prvName+"'");
				userQuery2.executeUpdate();

			}
			artgTx.commit();
			statusStr="success";

		}
		catch (Exception localException) 
		{
			artgTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			statusStr="fail";
		} 
		finally
		{
			artgSession.close();

		}
		return statusStr;

	}

}




