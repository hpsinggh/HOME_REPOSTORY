/*
Proprietary Notice
This file contains confidential information of meldit Pvt. Ltd. (India)  and meldit Inc. (USA), 
which is available for the sole purpose of permitting the recipient for engineering and product development purposes.  
In consideration of receipt of this file, the recipient agrees to maintain such information in confidence and not to
reproduce or otherwise disclose this information to any person outside the group directly responsible for its contents.

Security
The information contained herein is proprietary to meldit Pvt. Ltd. (India)  and meldit Inc. (USA) and may not be used, 
reproduced or disclosed.  The recipient of this file, by its retention and use, agrees to protect the same and the 
information contained therein from distribution, loss and theft.
__________________________________________________________________________________________________________________________________________________________________________________
*/

package com.gwebitsol.core.auth;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

import com.gwebitsol.core.auth.MDRole;

@Path("/rolemanagement/")
public interface MDRoleManagementServiceIntf 
{
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/addrole/")
	public Response addRole(MDRole mdRole,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam ("datastoreName") String datastoreName);
	
	@GET
	@Produces ({"application/xml","application/json"})
	@Path("/getallroles")
	public Response getAllRoles(@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam ("datastoreName") String datastoreName);
	
	@GET
	@Produces ({"application/xml","application/json"})
	@Path("/getroledetails")
	public Response getRoleDetails(@QueryParam("roleName") String roleName,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam ("datastoreName") String datastoreName);
	
	@POST
	@Produces ({"application/xml","application/json"})
	@Path("/delRole")
	public Response deleteRole(@QueryParam("roleName") String roleName,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam ("datastoreName") String datastoreName);
	
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/assignroletouser")
	public Response assignRoleToUser(@QueryParam("userToAssign") String userToAssign,@QueryParam("roleString") String roleString,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam ("datastoreName") String datastoreName);
	
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/removerolefromuser")
	public Response removeRoleFromUser(@QueryParam("userToRemove") String userToRemove,@QueryParam("roleString") String roleString,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam ("datastoreName") String datastoreName);
	
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/updaterole/")
	public Response updateRole(MDRole mdRole,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam ("datastoreName") String datastoreName);
	
	
	/*@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/assignroletogroup")
	public Response assignRoleToGroup(@QueryParam("groupToAssign") String userToAssign,@QueryParam("roleString") String roleString,@QueryParam ("username") String username,@QueryParam ("connectonid") String connectionid,@QueryParam ("datastorename") String datastorename);
	*/
	
}
