/*
Proprietary Notice
This file contains confidential information of meldit Pvt. Ltd. (India)  and meldit Inc. (USA), 
which is available for the sole purpose of permitting the recipient for engineering and product development purposes.  
In consideration of receipt of this file, the recipient agrees to maintain such information in confidence and not to
reproduce or otherwise disclose this information to any person outside the group directly responsible for its contents.

Security
The information contained herein is proprietary to meldit Pvt. Ltd. (India)  and meldit Inc. (USA) and may not be used, 
reproduced or disclosed.  The recipient of this file, by its retention and use, agrees to protect the same and the 
information contained therein from distribution, loss and theft.
__________________________________________________________________________________________________________________________________________________________________________________
*/


package com.gwebitsol.core.auth;

import java.io.StringReader;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.gwebitsol.core.util.MDTransactionWriter;

@SuppressWarnings("unchecked")
public class MDAssignRole 
{
	public String assignRoleToUser(String userToAssign,String roleString)
	{
		MDRoleManagementDAO rmDAO=new MDRoleManagementDAO();
		MDGetPrivilegesDAO gpDAO = new MDGetPrivilegesDAO();
		HashMap<String,String> privilegeMap=new HashMap<String, String>();
		
		privilegeMap = gpDAO.getPrivilegesMap(roleString);
				
		String status=rmDAO.assignRoleToUser(userToAssign, roleString, privilegeMap);
 		
		return status;
		
	}		
	
	public String assignRoleToGroup(String togroup,String roleString)
	{
		String[] roleNames=roleString.split(";");
		int i=roleNames.length;
		int k=0;
		MDRoleManagementDAO rmDAO=new MDRoleManagementDAO();
		MDGetRoleDetails getRoleDetails=new MDGetRoleDetails();
		HashMap<String,String> privilegeMap=new HashMap<String, String>();
		while(k<i)
		{
			
			try
			{
			String XMLRoleDetailsString=getRoleDetails.getDetails(roleNames[k]);
			k++;
			InputSource is=new InputSource();
			is.setCharacterStream(new StringReader(XMLRoleDetailsString));
				DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
				Document doc = dBuilder.parse(is);
				doc.getDocumentElement().normalize();

				System.out.println("root of xml file" + doc.getDocumentElement().getNodeName());
				NodeList nodes = doc.getElementsByTagName("privilege");
				for (int m = 0; m < nodes.getLength(); m++)
				{
					Node node = nodes.item(m);

					if (node.getNodeType() == Node.ELEMENT_NODE)
					{
						Element element = (Element) node;
						System.out.println("PrivilegeName: " + getValue("Privilege_Name", element));
						System.out.println("Right String: " + getValue("Right_String", element));
						privilegeMap.put(getValue("Privilege_Name",element).trim(),getValue("Right_String",element).trim());
					}
				}
				
			} 
			catch (Exception localException) 
			{
				MDTransactionWriter.exceptionlog.info(localException);
			}
			
		}
		String status=rmDAO.assignRoleToGroup(togroup,roleString, privilegeMap);

		return status;
	}
		//String status=rmDAO.assignRoleToUser(touser, prvName,prvStrArr[1]);
		
		
	private static String getValue(String tag, Element element)
	{
			NodeList nodes = element.getElementsByTagName(tag).item(0).getChildNodes();
			Node node = (Node) nodes.item(0);
			return node.getNodeValue();
	}
}
