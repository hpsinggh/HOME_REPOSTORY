/*
Proprietary Notice
This file contains confidential information of meldit Pvt. Ltd. (India)  and meldit Inc. (USA), 
which is available for the sole purpose of permitting the recipient for engineering and product development purposes.  
In consideration of receipt of this file, the recipient agrees to maintain such information in confidence and not to
reproduce or otherwise disclose this information to any person outside the group directly responsible for its contents.

Security
The information contained herein is proprietary to meldit Pvt. Ltd. (India)  and meldit Inc. (USA) and may not be used, 
reproduced or disclosed.  The recipient of this file, by its retention and use, agrees to protect the same and the 
information contained therein from distribution, loss and theft.
__________________________________________________________________________________________________________________________________________________________________________________
*/

package com.gwebitsol.core.auth;

import java.util.HashMap;

@SuppressWarnings("unchecked")
public class MDRemoveUserRole 
{
	public String removeRoleFromUser(String userToRemove,String roleString)
	{
		
		MDRoleManagementDAO rmDAO=new MDRoleManagementDAO();
		MDGetPrivilegesDAO gpDAO = new MDGetPrivilegesDAO();
		HashMap<String,String> privilegeMap=new HashMap<String, String>();
		
		privilegeMap = gpDAO.getPrivilegesMap(roleString);
		
		String status=rmDAO.removeRoleFromUser(userToRemove, roleString, privilegeMap);
 
		return status;
	}
	
	
}