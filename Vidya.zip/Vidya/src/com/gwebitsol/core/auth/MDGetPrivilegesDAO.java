/*
Proprietary Notice
This file contains confidential information of meldit Pvt. Ltd. (India)  and meldit Inc. (USA), 
which is available for the sole purpose of permitting the recipient for engineering and product development purposes.  
In consideration of receipt of this file, the recipient agrees to maintain such information in confidence and not to
reproduce or otherwise disclose this information to any person outside the group directly responsible for its contents.

Security
The information contained herein is proprietary to meldit Pvt. Ltd. (India)  and meldit Inc. (USA) and may not be used, 
reproduced or disclosed.  The recipient of this file, by its retention and use, agrees to protect the same and the 
information contained therein from distribution, loss and theft.
__________________________________________________________________________________________________________________________________________________________________________________
*/

package com.gwebitsol.core.auth;

import java.io.StringReader;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class MDGetPrivilegesDAO 
{
	@SuppressWarnings({ "deprecation", "rawtypes" })
	public String getPrivileges()
	{

		Session prvSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction getprvTx = null;

		String respXMLString=null;
		StringBuffer prvSB=new StringBuffer();

		try
		{
			getprvTx=prvSession.beginTransaction();
			String prvSql="select * from mdprivileges order by privilegeid asc";
			Query prvQuery=prvSession.createSQLQuery(prvSql).addScalar("privilegeid",Hibernate.INTEGER).addScalar("privilegename",Hibernate.STRING);
			List prvList=prvQuery.list();
			Iterator it=prvList.iterator();
			prvSB.append("<MD_Privileges>");
			prvSB.append("\n");
			while(it.hasNext())
			{
				Object[] obj=(Object[])it.next();
				prvSB.append("<privilege>");prvSB.append("\n");
				prvSB.append("<privilegeid>"+obj[0]+"</privilegeid>");
				prvSB.append("\n");
				prvSB.append("<privilegename>"+obj[1]+"</privilegename>");
				prvSB.append("\n");
				prvSB.append("</privilege>");prvSB.append("\n");
			}
			prvSB.append("</MD_Privileges>");
			respXMLString=prvSB.toString();
			prvSB.setLength(0);
			getprvTx.commit();

		}
		catch(Exception localException)
		{
			getprvTx.rollback();
			prvSB=null;
			MDTransactionWriter.exceptionlog.info(localException);
			respXMLString="fail";
		}
		finally
		{
			prvSession.close();
			prvSB=null;
		}
		return respXMLString;
	}
	
	public String getPrivilegeStringFromRole(String roleName)
	{
		Session prvSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction getprvTx = null;

		String prvStr=null;
		try
		{
			getprvTx=prvSession.beginTransaction();
			String sql="select privilegestring from mdrole where rolename='"+roleName+"'";
			prvStr=(String)prvSession.createSQLQuery(sql).uniqueResult();
			getprvTx.commit();

		}
		catch(Exception localException)
		{
			getprvTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			prvStr="null";
		}
		finally
		{
			prvSession.close();
		}
		return prvStr;
		
	}
	

	@SuppressWarnings("rawtypes")
	public HashMap getPrivilegesMap(String roleString)
	{
		String[] roleNames=roleString.split(";");
		int i=roleNames.length;
		int k=0;

		MDGetRoleDetails getRoleDetails=new MDGetRoleDetails();
		HashMap<String,String> privilegesMap=new HashMap<String, String>();
		while(k<i)
		{
			try
			{
				if(roleNames[k]!=null && !"".equalsIgnoreCase(roleNames[k].trim()))
				{
			String XMLRoleDetailsString=getRoleDetails.getDetails(roleNames[k]);
			k++;
			InputSource is=new InputSource();
			is.setCharacterStream(new StringReader(XMLRoleDetailsString));
				DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
				Document doc = dBuilder.parse(is);
				doc.getDocumentElement().normalize();

				System.out.println("root of xml file" + doc.getDocumentElement().getNodeName());
				NodeList nodes = doc.getElementsByTagName("privilege");
				for (int m = 0; m < nodes.getLength(); m++)
				{
					Node node = nodes.item(m);

					if (node.getNodeType() == Node.ELEMENT_NODE)
					{
						Element element = (Element) node;
						System.out.println("PrivilegeName: " + getValue("Privilege_Name", element));
						System.out.println("Right String: " + getValue("Right_String", element));
						privilegesMap.put(getValue("Privilege_Name",element).trim(),getValue("Right_String",element).trim());
					}
				}
				
			} 
		}
			catch (Exception localException) 
			{
				MDTransactionWriter.exceptionlog.info(localException);
			}
			
		}

		return privilegesMap;
	}
	
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public String assignUserACL(Integer userId, HashMap prvMap)
	{
		Session arSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction arTx=null;
		String statusStr=null;
		Set<String> ts=new TreeSet<String>();


		try 
		{
		arTx=arSession.beginTransaction();
		ts=prvMap.keySet();
		System.out.println(ts);
		String[] prvNames=ts.toArray(new String[0]);
		System.out.println(prvNames);
		Arrays.toString(prvNames);
		int p=prvNames.length;
		System.out.println(p);

			for(int k=0;k<p;k++)
			{
				String rightStr=null;
				System.out.println("Processing to Assign Privileges");
				String prvName=prvNames[k];
				rightStr=(String)prvMap.get(prvName);
				System.out.println(rightStr);
				String prvaclStr=(String)arSession.createSQLQuery("select acl from mdfolder where foldername='"+prvName+"'").uniqueResult();
			
				prvaclStr = setUsrAcl(userId, prvaclStr, rightStr);
		
				Query userQuery2=arSession.createSQLQuery("update mdfolder set acl='"+prvaclStr+"' where foldername='"+prvName+"'");
				userQuery2.executeUpdate();
				
			}
			
		arTx.commit();
		statusStr="success";
		}
		
		catch (Exception localException) 
		{
		arTx.rollback();
		MDTransactionWriter.exceptionlog.info(localException);
		statusStr="failed - setting User ACL";
		} 

		finally
		{
		arSession.close();
		}

	return statusStr;
	}

	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public String removeUserACL(Integer userId, HashMap prvMap )
	{
		Session arSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction arTx=null;
		String statusStr=null;
		Set<String> ts=new TreeSet<String>();

		try 
		{
		arTx=arSession.beginTransaction();
		ts=prvMap.keySet();
		System.out.println(ts);
		String[] prvNames=ts.toArray(new String[0]);
		System.out.println(prvNames);
		Arrays.toString(prvNames);
		int p=prvNames.length;
		System.out.println(p);

			for(int k=0;k<p;k++)
			{
				String rightStr=null;
				System.out.println("Processing to Remove Privileges");
				String prvName=prvNames[k];
				System.out.println(prvName);
				rightStr=(String)prvMap.get(prvName);
				System.out.println(rightStr);
				String prvaclStr=(String)arSession.createSQLQuery("select acl from mdfolder where foldername='"+prvName+"'").uniqueResult();
				
				prvaclStr = removeUsrAcl(userId, prvaclStr);
				Query userQuery2=arSession.createSQLQuery("update mdfolder set acl='"+prvaclStr+"' where foldername='"+prvName+"'");
				userQuery2.executeUpdate();
			}
			
		arTx.commit();
		statusStr="success";
		}
		
		catch (Exception localException) 
		{
		arTx.rollback();
		MDTransactionWriter.exceptionlog.info(localException);
		statusStr="failed - setting User ACL";
		} 

		finally
		{
		arSession.close();
		}

	return statusStr;
	}
	
	private String removeUsrAcl(Integer userId, String prvaclStr) {
	
		String strRemove = "U#"+userId+":...;";
		prvaclStr = prvaclStr.replaceAll(strRemove, "");		
			
	return prvaclStr;
		
	}
	

	private String setUsrAcl(Integer userId, String prvaclStr, String rightStr) 
	{
		
		int exstaclVal = 0;
		MDAclUtils mdaclu = new MDAclUtils();
		int aclVal = mdaclu.getRightsValue(rightStr);
		String usrAclStr = getUserAclString(prvaclStr,userId);
					
			if (usrAclStr == null) {
				prvaclStr=prvaclStr+"U#"+userId+":"+aclVal+";";
				System.out.println("New user ACL added to Privilge");
			}
			else {
				exstaclVal = mdaclu.getACLvalue(usrAclStr);
							
				if(aclVal > exstaclVal) {
					String strRemove = "U#"+userId+":...;";
					String strReplace = "U#"+userId+":"+aclVal+";";
					prvaclStr = prvaclStr.replaceAll(strRemove, strReplace);
				}
			
		}
	return prvaclStr;
	}
	
	
	private String getUserAclString (String allUsrsPrvStr, Integer userId)
	{
		String usrAclStr = null;
		String [] usrsAcls = allUsrsPrvStr.split(";");
		for (int i = 0; i < usrsAcls.length; i++) {
		if (usrsAcls[i].startsWith("U#"+userId+":")) usrAclStr = usrsAcls[i];
		}
		
		return usrAclStr;
				
	}

	
	private static String getValue(String tag, Element element)
	{
			NodeList nodes = element.getElementsByTagName(tag).item(0).getChildNodes();
			Node node = (Node) nodes.item(0);
			return node.getNodeValue();
	}

	public String getMenuPrivileges(int parentfolderid) {
		
		Session prvSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction getprvTx = null;

		String respXMLString=null;
		StringBuffer prvSB=new StringBuffer();

		try
		{
			getprvTx=prvSession.beginTransaction();
			String prvSql="select mdprivileges.PrivilegeId, mdfolder.folderid, mdfolder.foldername, mdfolder.parentfolderid, mdfolder.foldertype"
			+" from mdprivileges, mdfolder"
			+" where parentfolderid ="+parentfolderid
			+" and FolderType = 'M'"
			+" and mdprivileges.PRIVILEGENAME = mdfolder.foldername"
			+" order by mdfolder.parentfolderid,mdfolder.folderid";
			
			Query prvQuery=prvSession.createSQLQuery(prvSql);
			List prvList=prvQuery.list();
			Iterator it=prvList.iterator();
			prvSB.append("<MD_Privileges>");
			prvSB.append("\n");
			
		
			while(it.hasNext())
			{
				Object[] obj=(Object[])it.next();
				prvSB.append("<privilege>");
				prvSB.append("\n");
				prvSB.append("<privilegeid>"+obj[0]+"</privilegeid>");
				prvSB.append("\n");
				prvSB.append("<folderid>"+obj[1]+"</folderid>");
				prvSB.append("\n");
				prvSB.append("<foldername>"+obj[2]+"</foldername>");
				prvSB.append("\n");
				prvSB.append("<parentfolderid>"+obj[3]+"</parentfolderid>");
				prvSB.append("\n");
				prvSB.append("<foldertype>"+obj[4]+"</foldertype>");
				prvSB.append("\n");
				prvSB.append("</privilege>");
				
			}
			prvSB.append("</MD_Privileges>");
			respXMLString=prvSB.toString();
			prvSB.setLength(0);
			getprvTx.commit();

		}
		catch(Exception localException)
		{
			getprvTx.rollback();
			prvSB=null;
			MDTransactionWriter.exceptionlog.info(localException);
			respXMLString="fail";
		}
		finally
		{
			prvSession.close();
			prvSB=null;
		}
		return respXMLString;
	}	
	
}
