/*
Proprietary Notice
This file contains confidential information of meldit Pvt. Ltd. (India)  and meldit Inc. (USA), 
which is available for the sole purpose of permitting the recipient for engineering and product development purposes.  
In consideration of receipt of this file, the recipient agrees to maintain such information in confidence and not to
reproduce or otherwise disclose this information to any person outside the group directly responsible for its contents.

Security
The information contained herein is proprietary to meldit Pvt. Ltd. (India)  and meldit Inc. (USA) and may not be used, 
reproduced or disclosed.  The recipient of this file, by its retention and use, agrees to protect the same and the 
information contained therein from distribution, loss and theft.
__________________________________________________________________________________________________________________________________________________________________________________
*/

package com.gwebitsol.core.auth;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.auth.MDRole;
import com.gwebitsol.core.auth.MDRoleManagementServiceIntf;
import com.gwebitsol.core.auth.MDRolePOJO;
import com.gwebitsol.core.security.MDVerifyConnectionID;
import com.gwebitsol.core.security.MDVerifyDatastoreName;
import com.gwebitsol.core.usermanagement.MDGetUserFromID;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class MDRoleManagementService implements MDRoleManagementServiceIntf
{
	@Context private HttpServletRequest hsr;
	public Response addRole(MDRole mdrole,int userID,int connectionID,String datastoreName)
	{
		MDTransactionWriter.accesslog.info("Request from:"+hsr.getRemoteHost());		
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
				MDRolePOJO rolePOJO=new MDRolePOJO();
				if(mdrole.getRoleName().isEmpty())
				{
					XMLString="Enter a valid rolename...";
				}
				else
				{
				rolePOJO.setRoleName(mdrole.getRoleName());
				rolePOJO.setPrivilegeString(mdrole.getPrivilegeString());
				rolePOJO.setCreatedBy(requester);
				rolePOJO.setCreatedDate(startDate);
				rolePOJO.setModifiedBy("null");
				rolePOJO.setModifiedDate("0000-00-00 00:00:00");
				rolePOJO.setDescription(mdrole.getDescription());		
				MDRoleManagementDAO rmDAO=new MDRoleManagementDAO();
				XMLString=rmDAO.addRole(rolePOJO);
				if(XMLString.equals("fail"))
					statusStr="failed";
				else
					statusStr="success";
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				MDTransactionWriter.writeLog("idea","RMS","rajesh",startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
				}
			}
			else
			{
				XMLString="you are not authorised user";
			}
		}
		catch(Exception localException)
		{
			MDTransactionWriter.exceptionlog.info(localException);
			XMLString="failed in service Layer";
			
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}
	public Response getAllRoles(int userID,int connectionID,String datastoreName)
	{
		MDTransactionWriter.accesslog.info("Request from:"+hsr.getRemoteHost());		
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{					
				MDRoleManagementDAO rmDAO=new MDRoleManagementDAO();
				XMLString=rmDAO.getRolesList();
				if(XMLString.equals("fail"))
					statusStr="failed";
				else
					statusStr="success";
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				MDTransactionWriter.writeLog(datastoreName,"RoleMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}
		}
		catch(Exception localException)
		{
			MDTransactionWriter.exceptionlog.info(localException);
			XMLString="failed in service Layer";
			
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}
	public Response getRoleDetails(String roleName,int userID,int connectionID,String datastoreName)
	{
		MDTransactionWriter.accesslog.info("Request from:"+hsr.getRemoteHost()+" at"+new Date());		
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
			
				MDGetRoleDetails getRoleDetails=new MDGetRoleDetails();
				XMLString=getRoleDetails.getDetails(roleName);
				if(XMLString.equals("fail"))
					statusStr="failed";
				else
					statusStr="success";
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				MDTransactionWriter.writeLog(datastoreName,"RoleMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}
		}
		catch(Exception localException)
		{
			MDTransactionWriter.exceptionlog.info(localException);
			XMLString="failed in service Layer";
			
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}
	
	
	public Response assignRoleToUser(String userToAssign,String roleString,int userID,int connectionID,String datastoreName)
	{
		MDTransactionWriter.accesslog.info("Request from:"+hsr.getRemoteHost());		
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{

			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			
			if(ret==1 )//&& rtVal==1)
			{
				MDAssignRole asRole=new MDAssignRole();
				XMLString=asRole.assignRoleToUser(userToAssign, roleString);
				if(XMLString.equals("fail"))
					statusStr="failed";
				else
					statusStr="success";
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				MDTransactionWriter.writeLog(datastoreName,"RoleMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}
		}
		catch(Exception localException)
		{
			MDTransactionWriter.exceptionlog.info(localException);
			XMLString="failed in service Layer";
			
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}
	
	public Response removeRoleFromUser(String userToRemove,String roleString,int userID,int connectionID,String datastoreName)
	{
		MDTransactionWriter.accesslog.info("Request from:"+hsr.getRemoteHost());		
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{

			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
				MDRemoveUserRole rmRole=new MDRemoveUserRole();
				XMLString=rmRole.removeRoleFromUser(userToRemove, roleString);
				if(XMLString.equals("fail"))
					statusStr="failed";
				else
					statusStr="success";
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				MDTransactionWriter.writeLog(datastoreName,"RoleManagaent-removeRole",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}
		}
		catch(Exception localException)
		{
			MDTransactionWriter.exceptionlog.info(localException);
			XMLString="failed in service Layer";
			
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}
	
	
	
	public Response assignRoleToGroup(String toGroup,String roleString,int userID,int connectionID,String datastoreName)
	{
		MDTransactionWriter.accesslog.info("Request from:"+hsr.getRemoteHost()+"at "+new Date());		
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
				MDAssignRole asRole=new MDAssignRole();
				XMLString=asRole.assignRoleToGroup(toGroup, roleString);
				if(XMLString.equals("fail"))
					statusStr="failed";
				else
					statusStr="success";
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				MDTransactionWriter.writeLog(datastoreName,"RoleMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}
		}
		catch(Exception localException)
		{
			MDTransactionWriter.exceptionlog.info(localException);
			XMLString="failed in service Layer";
			
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}

	public Response updateRole(MDRole mdrole, int userID, int connectionID,String datastoreName) 
	{
	
		MDTransactionWriter.accesslog.info("Request from:"+hsr.getRemoteHost()+"at "+new Date());		
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
					
				//Siva, 7/11/14, Modified for update User ACLs with that role when Role Updated
				//MDRoleManagementDAO rmDAO=new MDRoleManagementDAO();
				//XMLString=rmDAO.updaterole(mdrole, userID);
				MDUpdateUsersRole usrsRole=new MDUpdateUsersRole();
				XMLString=usrsRole.updateUsersForRole(mdrole, userID);
				
				if(XMLString.equals("fail"))
					statusStr="failed";
				else
					statusStr="success";
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				MDTransactionWriter.writeLog(datastoreName,"RoleMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not an authorised user";
			}
		}
		catch(Exception localException)
		{
			MDTransactionWriter.exceptionlog.info(localException);
			XMLString="failed in service Layer";
			
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}
	public Response deleteRole(String roleName, int userID, int connectionID,String datastoreName) 
	{
		MDTransactionWriter.accesslog.info("Request from:"+hsr.getRemoteHost()+"at "+new Date());		
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
							
				MDRoleManagementDAO rmDAO=new MDRoleManagementDAO();
				XMLString=rmDAO.deleterole(roleName,userID);
				if(XMLString.equals("fail"))
					statusStr="failed";
				else
					statusStr="success";
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				MDTransactionWriter.writeLog(datastoreName,"RoleMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}
		}
		catch(Exception localException)
		{
			MDTransactionWriter.exceptionlog.info(localException);
			XMLString="failed in service Layer";
			
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}
	
}
