/*
Proprietary Notice
This file contains confidential information of meldit Pvt. Ltd. (India)  and meldit Inc. (USA), 
which is available for the sole purpose of permitting the recipient for engineering and product development purposes.  
In consideration of receipt of this file, the recipient agrees to maintain such information in confidence and not to
reproduce or otherwise disclose this information to any person outside the group directly responsible for its contents.

Security
The information contained herein is proprietary to meldit Pvt. Ltd. (India)  and meldit Inc. (USA) and may not be used, 
reproduced or disclosed.  The recipient of this file, by its retention and use, agrees to protect the same and the 
information contained therein from distribution, loss and theft.
__________________________________________________________________________________________________________________________________________________________________________________
*/

package com.gwebitsol.core.auth;

import java.math.BigInteger;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class MDGetRoleDetails
{
	
	public String getDetails(String roleName)
	{
		StringBuffer grBuffer=new StringBuffer();
		String respStr=null;
		MDRolePOJO rp=null;
		try
		{
		grBuffer.append("<MD_Role_Details>");grBuffer.append("\n");
		MDRoleManagementDAO rmDAO=new MDRoleManagementDAO();
		rp=rmDAO.getRoledetails(roleName);
		grBuffer.append("<Role_Id>");
		grBuffer.append(rp.getRoleID());
		grBuffer.append("</Role_Id>");
		grBuffer.append("\n");
		grBuffer.append("<Role_Name>");grBuffer.append(rp.getRoleName());grBuffer.append("</Role_Name>");
		grBuffer.append("\n");
		grBuffer.append("<Privileges>");
		grBuffer.append("\n");
		grBuffer.append(getPrvNamesFromPrvString(rp.getPrivilegeString()));
		grBuffer.append("</Privileges>");
		grBuffer.append("\n");
		grBuffer.append("<Role_Created_By>");grBuffer.append(rp.getCreatedBy());grBuffer.append("</Role_Created_By>");
		grBuffer.append("\n");
		grBuffer.append("<Role_Created_On>");grBuffer.append(rp.getCreatedDate());grBuffer.append("</Role_Created_On>");
		grBuffer.append("\n");
		grBuffer.append("<Role_Modified_By>");grBuffer.append(rp.getModifiedBy());grBuffer.append("</Role_Modified_By>");
		grBuffer.append("\n");
		grBuffer.append("<Role_Modified_On>");grBuffer.append(rp.getModifiedDate());grBuffer.append("</Role_Modified_On>");
		grBuffer.append("\n");
		grBuffer.append("<Role_Description>");grBuffer.append(rp.getDescription());grBuffer.append("</Role_Description>");
		grBuffer.append("\n");
		grBuffer.append("</MD_Role_Details>");
		respStr=grBuffer.toString();
		grBuffer=null;
		}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.info("Error in getting details..,Please check the exception log.");
			MDTransactionWriter.exceptionlog.info(localException);
			grBuffer=null;
			respStr="fail";
		}
		return respStr;
	}
	
	
		
private static String getPrvNamesFromPrvString(String prvString)
	{
		
		String[] rStr=prvString.split(";");
		StringBuffer rBuffer=new StringBuffer();
		String rightStr1=null;
		String finalStr=null;
		Session vuSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction vuTx = null;
		MDGetPrivilegeNameFromIDDAO prvDAO=new MDGetPrivilegeNameFromIDDAO();
		int i=0;
		int k=rStr.length;
		
		String Sql = "select count(FOLDERNAME) from mdfolder where PARENTFOLDERID in (-1,1)";
		BigInteger numprv =  (BigInteger) vuSession.createSQLQuery(Sql).uniqueResult();
		
		int noofprv= numprv.intValue();
		
		while(i<k)
		{
			vuTx = vuSession.beginTransaction();
			String[] localStr=rStr[i].split(":");
			int pID=Integer.parseInt(localStr[0]);
			String rightStr=localStr[1]; 
			
			
			//String prvName=prvDAO.getName(pID);   -- this is from mdprivileges.
			// srinu : here too many connections got happend to make it less Keep the all pId in an
			// an array and trim the braces of an array and add these braces () in query to use "IN" operator.

			if(pID<=noofprv)
			{
			
				// ex-- 1:000 here 1 is privilegeid,to below query i have to send folderid so 
				// by using this privilegeid we need to get privilegename. using this privilege name 
				// we need to get folderid
				// select privilegename from mdpriviles where privilegeid=pid
				// select foldername from mdfolder where foldername=privilegename
				
				Sql = "select PRIVILEGENAME from mdprivileges where PRIVILEGEID='"+pID+"';";
				String prvName = (String) vuSession.createSQLQuery(Sql).uniqueResult();
				
				Sql = "select FOLDERNAME from mdfolder where FOLDERNAME='"+prvName+"' and PARENTFOLDERID in (-1,1)";
				String fldName = (String) vuSession.createSQLQuery(Sql).uniqueResult();
				
			if(fldName!=null)
			{
			System.out.println(fldName);
			if(rightStr.equals("100"))
				rightStr1="R";
			else if(rightStr.equals("110"))
				rightStr1="RW";
			else
				rightStr1="RWD";
			rBuffer.append("<privilege>");
			rBuffer.append("\n");
			rBuffer.append("<Privilege_Name>");
			rBuffer.append(fldName);
			rBuffer.append("</Privilege_Name>");
			rBuffer.append("\n");
			rBuffer.append("<Right_String>");
			rBuffer.append(rightStr1);
			rBuffer.append("</Right_String>");
			rBuffer.append("\n");
			rBuffer.append("</privilege>");
			rBuffer.append("\n");
			}
		}
			i++;
		}
		
		finalStr=rBuffer.toString();
		rBuffer=null;
		return finalStr;
	}
}
