package com.gwebitsol.core.padagogy;

import java.util.Iterator;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class SubjectDao {
	
	public String addSubject(SubjectPojo subjectPojo) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		String strg= null;
		 StringBuffer sb= new StringBuffer();
		 try {
				tx = rdSession.beginTransaction();
				Integer i=(Integer) rdSession.save(subjectPojo);
				System.out.println(i);
				tx.commit();
				sb.append("<subject>");
				  sb.append("\n");
				  sb.append("<subjectid>");
				  sb.append(i);
				  sb.append("</subjectid>");
				  sb.append("\n");
				  sb.append("</subject>");
				   strg= sb.toString();					
				} catch (Exception localException) {

					System.out.println(localException);
					localException.printStackTrace();
				   sb.append("<Response>");
				   sb.append("\n");
				   sb.append("<Result>");
				   sb.append("\n");
				   sb.append("Fail");
				   sb.append("\n");
				   sb.append("</Result>");
				   sb.append("\n");
				   sb.append("<Description>");
				   sb.append("could not inserted subject item");
				   sb.append("</Description>");
				   sb.append("\n");
				   sb.append("<Exception>");
				   sb.append(localException);
				   sb.append("</Exception>");
				   sb.append("</Response>");
				   strg=sb.toString();
				   MDTransactionWriter.exceptionlog.info(localException);
				  if (tx!=null)
				   tx.rollback();
				  } finally {
				   rdSession.close(); 
				  }
				  return strg;
				 }
								
			public String deleteSubject(int subjectId,int schoolId,int branchId) {
				Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
				Transaction tx = null;
					StringBuffer sb=new StringBuffer();
					String strg= null;
					try {
							tx = rdSession.beginTransaction();
							
							/*subjectPojo sub=new SubjectPojo();
							sub.setSubjectId(id);
							rdSession.delete(sub);
							tx.commit();*/
							SubjectPojo sub = (SubjectPojo) rdSession.get(SubjectPojo.class,subjectId);					   
							   rdSession.evict(sub);
							   if(schoolId==sub.getSchoolId()&&branchId==sub.getBranchId())
							   {
							   Query empQuery=rdSession.createSQLQuery("update gbl_sm_tbl_subjects set isDeleted='y' where subjectId='"+subjectId+"'");
							   empQuery.executeUpdate();
							   tx.commit();
							sb.append("<subjectid>");
						    sb.append("\n");
						    sb.append("<id>");
							sb.append("subject item deleted");
							sb.append("</id>");
							sb.append("\n");
							sb.append("</subjectid>");
							 strg= sb.toString();  
						
				}else{
					   strg = " subject is not deleted";
					   sb.append("<subject>");
					   sb.append("\n");
					   sb.append(strg);
					   sb.append("</subject>");
					    String str = sb.toString();
					    return str;
					   }
				}
				catch(Exception localException)
				{
					System.out.println(localException);
					localException.printStackTrace();
				   sb.append("<Response>");
				   sb.append("\n");
				   sb.append("<Result>");
				   sb.append("\n");
				   sb.append("Fail");
				   sb.append("\n");
				   sb.append("</Result>");
				   sb.append("\n");
				   sb.append("<Description>");
				   sb.append("could not deleted subject item");
				   sb.append("</Description>");
				   sb.append("\n");
				   sb.append("<Exception>");
				   sb.append(localException);
				   sb.append("</Exception>");
				   sb.append("</Response>");
				   strg=sb.toString();
				   MDTransactionWriter.exceptionlog.info(localException);
				  if (tx!=null)
				   tx.rollback();
				  } finally {
				   rdSession.close(); 
				  }
				  return strg;
				 }
			
			public String updateSubject(SubjectPojo subjectPojo,int schoolId,int branchId) {
				Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
				Transaction tx = null;
					StringBuffer sb= new StringBuffer();
					String strg= null;
						try {
								tx = rdSession.beginTransaction();
								/*rdSession.update(subjectPojo);
								  tx.commit();*/
								SubjectPojo sub = (SubjectPojo) rdSession.get(SubjectPojo.class,subjectPojo.getSubjectId());
								rdSession.evict(sub);
								   if(schoolId==sub.getSchoolId()&&branchId==sub.getBranchId())
								   rdSession.update(subjectPojo);  
								   tx.commit();
								    sb.append("<subjectPojo>");
								    sb.append("\n");
								    sb.append("<subjectid>");
									sb.append("\n");
									sb.append("subject succssfully updated");
									sb.append("</subjectid>");
									sb.append("\n");
									sb.append("</subjectPojo>");
									strg= sb.toString();
							} 	catch (Exception localException) {

								System.out.println(localException);
								localException.printStackTrace();
							   sb.append("<Response>");
							   sb.append("\n");
							   sb.append("<Result>");
							   sb.append("\n");
							   sb.append("Fail");
							   sb.append("\n");
							   sb.append("</Result>");
							   sb.append("\n");
							   sb.append("<Description>");
							   sb.append("could not updated subject item");
							   sb.append("</Description>");
							   sb.append("\n");
							   sb.append("<Exception>");
							   sb.append(localException);
							   sb.append("</Exception>");
							   sb.append("</Response>");
							   strg=sb.toString();
							   MDTransactionWriter.exceptionlog.info(localException);
							  if (tx!=null)
							   tx.rollback();
							  } finally {
							   rdSession.close(); 
							  }
							  return strg;
							 }
		
					@SuppressWarnings("rawtypes")
					public String getAllSubjects(int PNO, int size,int schoolId,int branchId,int classId,int sectionId) {
							  String xmlString=null;
							  Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
							  Transaction stgTx=null;
							  StringBuffer sb = new StringBuffer();
							  String gsSql;
							  try
							  {
							   stgTx=stgSession.beginTransaction();
							    int fset = (PNO-1)*size;
							    	 String filterWhere="";
							    	 if(classId!=0){									  								    	
									    	filterWhere+=" and sub.ClassId="+classId;			    	
										if(sectionId!=0){
											filterWhere +=  " and sub.SectionId="+sectionId;
											}
									    }
							    	gsSql ="select count(*) from gbl_sm_tbl_subjects sub where isDeleted<>'y' or isDeleted is null and schoolId='"+schoolId+"' and branchId='"+branchId+"'"+filterWhere+" ";
							    
							    Query gsQuery=stgSession.createSQLQuery(gsSql);
							    Object noRecords= gsQuery.uniqueResult();
							    int intNoRecords=0;
								if(noRecords!=null && Integer.parseInt(noRecords.toString())!=0)
								{
									intNoRecords=Integer.parseInt(noRecords.toString());
								}
							    sb.append("<subjects>");
							    sb.append("\n");
							    sb.append("<noRecords>"+noRecords+"</noRecords>");
							    sb.append("\n");
							    if(intNoRecords!=0)
								{
							     if (PNO > 0 & size > 0){
							     gsSql="SELECT sub.SubjectId,sub.SUBCATEGORYID,subcat.SUBCATEGORYNAME,sub.CATEGORYID,mdc.CATEGORYNAME,"
							     		+ "sub.TextBookId,tb.TextBookName,sub.ClassId,cls.ClassName,sub.CurriculumId,curlm.CurriculumTitle,"
							     		+ "sub.SubjectTypeId,subtype.SubjectName,sub.Description,sub.Remarks,sub.SubWeekPeriods,sub.Priority,"
							     		+ "sub.SectionId,sec.SectionName,sub.SchoolId,sub.BranchId FROM gbl_sm_tbl_subjects as sub "
							     		+ "join mdsubcategory as subcat on subcat.SUBCATEGORYID=sub.SUBCATEGORYID join "
							     		+ "gbl_sm_tbl_textbook as tb on	tb.TextBookId=sub.TextBookId join gbl_sm_tbl_class as cls "
							     		+ "on cls.ClassId= sub.ClassId join gbl_sm_tbl_curriculum as curlm  "
							     		+ "on curlm.CurriculumId=sub.CurriculumId join gbl_sm_tbl_section  "
							     		+ "as sec on sec.SectionId=sub.SectionId join gbl_sm_tbl_subject_type as subtype on "
							     		+ "subtype.SubjectTypeId=sub.SubjectTypeId join mdcategory as mdc on mdc.CATEGORYID=sub.CATEGORYID"
							     		+ " where sub.isDeleted<>'y' or sub.isDeleted is null and  sub.schoolId='"+schoolId+"' and sub.branchId='"+branchId+"' "+filterWhere+" limit "+size+" offset "+fset;
							     }
							     else {
							      gsSql="SELECT sub.SubjectId,sub.SUBCATEGORYID,subcat.SUBCATEGORYNAME,sub.CATEGORYID,mdc.CATEGORYNAME,sub.TextBookId,tb.TextBookName,sub.ClassId,cls.ClassName,sub.CurriculumId,curlm.CurriculumTitle,sub.SubjectTypeId,subtype.SubjectName,sub.Description,sub.Remarks,sub.SubWeekPeriods,sub.Priority,sub.SectionId,sec.SectionName,sub.SchoolId,sub.BranchId FROM gbl_sm_tbl_subjects as sub join mdsubcategory as subcat on subcat.SUBCATEGORYID=sub.SUBCATEGORYID join gbl_sm_tbl_textbook as tb on	tb.TextBookId=sub.TextBookId join gbl_sm_tbl_class as cls on cls.ClassId= sub.ClassId join 	gbl_sm_tbl_curriculum as curlm  on curlm.CurriculumId=sub.CurriculumId join gbl_sm_tbl_section	 as sec on sec.SectionId=sub.SectionId join gbl_sm_tbl_subject_type as subtype on subtype.SubjectTypeId=sub.SubjectTypeId join mdcategory as mdc on mdc.CATEGORYID=sub.CATEGORYID where sub.isDeleted<>'y' or sub.isDeleted is null and  sub.schoolId='"+schoolId+"' and sub.branchId='"+branchId+"'"+filterWhere+" ";
							     } 
							    gsQuery=stgSession.createSQLQuery(gsSql);
							    List gcList=gsQuery.list();
							    Iterator gsIT=gcList.iterator();
							     while(gsIT.hasNext())
							     {
							      Object[] mdcArr=(Object[])gsIT.next();
							      sb.append("<subject>");
							      sb.append("\n");
							      sb.append("<subjectId>"+mdcArr[0]+"</subjectId>");
							      sb.append("\n");
							      sb.append("<subCategoryId>" + mdcArr[1]+ "</subCategoryId>");
							      sb.append("\n");
							      sb.append("<subCategoryName>" + mdcArr[2]+ "</subCategoryName>");
							      sb.append("\n");
							      sb.append("<categoryId>" + mdcArr[3]+ "</categoryId>");
							      sb.append("\n");
							      sb.append("<categoryName>" + mdcArr[4]+ "</categoryName>");
							      sb.append("\n");					      
							      sb.append("<textBookId>" + mdcArr[5] + "</textBookId>");
							      sb.append("\n");
							      sb.append("<textBookName>" + mdcArr[6]+ "</textBookName>");
							      sb.append("\n");
							      sb.append("<classId>" + mdcArr[7] + "</classId>");
							      sb.append("\n");
							      sb.append("<className>" +  mdcArr[8]+ "</className>");
							      sb.append("\n");
							      sb.append("<curriculumId>" + mdcArr[9] + "</curriculumId>");
							      sb.append("\n");
							      sb.append("<curriculumTitle>" + mdcArr[10] + "</curriculumTitle>");
							      sb.append("\n");
							      sb.append("<subjectTypeId>"+mdcArr[11]+"</subjectTypeId>");
							      sb.append("\n");
							      sb.append("<subjectName>" + mdcArr[12] + "</subjectName>");
							      sb.append("\n");
							      sb.append("<description>" + mdcArr[13] + "</description>");
							      sb.append("\n");
							      sb.append("<remarks>" + mdcArr[14] + "</remarks>");
							      sb.append("\n");
							      sb.append("<subWeekPeriods>" + mdcArr[15] + "</subWeekPeriods>");
							      sb.append("\n");
							      sb.append("<priority>" + mdcArr[16] + "</priority>");
							      sb.append("\n");
							      sb.append("<sectionId>" + mdcArr[17] + "</sectionId>");
							      sb.append("\n");
							      sb.append("<sectionName>" + mdcArr[18] + "</sectionName>");
							      sb.append("\n");
							      sb.append("<schoolId>" + mdcArr[19] + "</schoolId>");
							      sb.append("\n");
							      sb.append("<branchId>" + mdcArr[20] + "</branchId>");
							      sb.append("\n");
							      sb.append("</subject>");
							     }	
								}
							    stgTx.commit();
							    sb.append("</subjects>");
							    sb.append("\n");
							    
							    xmlString=sb.toString();   
							  } 
					catch(Exception localException)
					{

						System.out.println(localException);
						localException.printStackTrace();
					   sb.append("<Response>");
					   sb.append("\n");
					   sb.append("<Result>");
					   sb.append("\n");
					   sb.append("Fail");
					   sb.append("\n");
					   sb.append("</Result>");
					   sb.append("\n");
					   sb.append("<Description>");
					   sb.append("could not getall subject items");
					   sb.append("</Description>");
					   sb.append("\n");
					   sb.append("<Exception>");
					   sb.append(localException);
					   sb.append("</Exception>");
					   sb.append("</Response>");					    
					   xmlString=sb.toString();
					   MDTransactionWriter.exceptionlog.info(localException);
					  if (stgTx!=null)
						  stgTx.rollback();
					  } finally {
					   stgSession.close(); 
					  }
					  return xmlString;
					 }
				@SuppressWarnings("rawtypes")
				public String getByIdSubject(int subjectId,int schoolId,int branchId) {
					Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
					Transaction tx = null;
					StringBuffer sb= new StringBuffer();
					String strg= null;
					
						try {
							tx = rdSession.beginTransaction();
							Query query=rdSession.createSQLQuery("SELECT sub.SubjectId,sub.SUBCATEGORYID,subcat.SUBCATEGORYNAME,sub.CATEGORYID,mdc.CATEGORYNAME,"
							     		+ "sub.TextBookId,tb.TextBookName,sub.ClassId,cls.ClassName,sub.CurriculumId,curlm.CurriculumTitle,"
							     		+ "sub.SubjectTypeId,subtype.SubjectName,sub.Description,sub.Remarks,sub.SubWeekPeriods,sub.Priority,"
							     		+ "sub.SectionId,sec.SectionName,sub.SchoolId,sub.BranchId FROM gbl_sm_tbl_subjects as sub "
							     		+ "join mdsubcategory as subcat on subcat.SUBCATEGORYID=sub.SUBCATEGORYID join "
							     		+ "gbl_sm_tbl_textbook as tb on	tb.TextBookId=sub.TextBookId join gbl_sm_tbl_class as cls "
							     		+ "on cls.ClassId= sub.ClassId join gbl_sm_tbl_curriculum as curlm  "
							     		+ "on curlm.CurriculumId=sub.CurriculumId join gbl_sm_tbl_section  "
							     		+ "as sec on sec.SectionId=sub.SectionId join gbl_sm_tbl_subject_type as subtype on "
							     		+ "subtype.SubjectTypeId=sub.SubjectTypeId join mdcategory as mdc on mdc.CATEGORYID=sub.CATEGORYID"
							     		+ " where sub.isDeleted<>'y' or sub.isDeleted is null and SubjectId='"+subjectId+"' and sub.schoolId='"+schoolId+"' and sub.branchId='"+branchId+"'");
						    List gcList=query.list();
						    Iterator gsIT=gcList.iterator();
						     while(gsIT.hasNext())
						     {
						      Object[] mdcArr=(Object[])gsIT.next();
						  
						      sb.append("<subject>");
						      sb.append("\n");
						      sb.append("<subjectId>"+mdcArr[0]+"</subjectId>");
						      sb.append("\n");
						      sb.append("<subCategoryId>" + mdcArr[1]+ "</subCategoryId>");
						      sb.append("\n");
						      sb.append("<subCategoryName>" + mdcArr[2]+ "</subCategoryName>");
						      sb.append("\n");
						      sb.append("<categoryId>" + mdcArr[3]+ "</categoryId>");
						      sb.append("\n");
						      sb.append("<categoryName>" + mdcArr[4]+ "</categoryName>");
						      sb.append("\n");					      
						      sb.append("<textBookId>" + mdcArr[5] + "</textBookId>");
						      sb.append("\n");
						      sb.append("<textBookName>" + mdcArr[6]+ "</textBookName>");
						      sb.append("\n");
						      sb.append("<classId>" + mdcArr[7] + "</classId>");
						      sb.append("\n");
						      sb.append("<className>" +  mdcArr[8]+ "</className>");
						      sb.append("\n");
						      sb.append("<curriculumId>" + mdcArr[9] + "</curriculumId>");
						      sb.append("\n");
						      sb.append("<curriculumTitle>" + mdcArr[10] + "</curriculumTitle>");
						      sb.append("\n");
						      sb.append("<subjectTypeId>"+mdcArr[11]+"</subjectTypeId>");
						      sb.append("\n");
						      sb.append("<subjectName>" + mdcArr[12] + "</subjectName>");
						      sb.append("\n");
						      sb.append("<description>" + mdcArr[13] + "</description>");
						      sb.append("\n");
						      sb.append("<remarks>" + mdcArr[14] + "</remarks>");
						      sb.append("\n");
						      sb.append("<subWeekPeriods>" + mdcArr[15] + "</subWeekPeriods>");
						      sb.append("\n");
						      sb.append("<priority>" + mdcArr[16] + "</priority>");
						      sb.append("\n");
						      sb.append("<sectionId>" + mdcArr[17] + "</sectionId>");
						      sb.append("\n");
						      sb.append("<sectionName>" + mdcArr[18] + "</sectionName>");
						      sb.append("\n");
						      sb.append("<schoolId>" + mdcArr[19] + "</schoolId>");
						      sb.append("\n");
						      sb.append("<branchId>" + mdcArr[20] + "</branchId>");
						      sb.append("\n");
						      sb.append("</subject>");
								String str= sb.toString();
								return str;
						}
								
						} 	catch (Exception localException) {

							System.out.println(localException);
							localException.printStackTrace();
						   sb.append("<Response>");
						   sb.append("\n");
						   sb.append("<Result>");
						   sb.append("\n");
						   sb.append("Fail");
						   sb.append("\n");
						   sb.append("</Result>");
						   sb.append("\n");
						   sb.append("<Description>");
						   sb.append("could not getby subject items");
						   sb.append("</Description>");
						   sb.append("\n");
						   sb.append("<Exception>");
						   sb.append(localException);
						   sb.append("</Exception>");
						   sb.append("</Response>");
						   strg=sb.toString();
						   MDTransactionWriter.exceptionlog.info(localException);
						  if (tx!=null)
						   tx.rollback();
						  } finally {
						   rdSession.close(); 
						  }
						  return strg;
						 }
				}

