package com.gwebitsol.core.padagogy;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.springframework.stereotype.Component;
import com.gwebitsol.core.security.MDValidation;
import com.gwebitsol.core.usermanagement.MDGetUserFromID;
import com.gwebitsol.core.util.MDTransactionWriter;
@Component
public class BookServiceImpl implements BookServiceInf{

	@Context 
	private HttpServletRequest hsr;
	public Response addTextBooks(TextBook textbook,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
			
				MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
			
				String status=null;
				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date date = new Date();
				String startDate=dateFormat.format(date);
				Long sl=System.currentTimeMillis();
				textbook.setBranchId(branchId);
				textbook.setSchoolId(schoolId);
					try
						{	
						MDValidation mdv = new MDValidation();  
						  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
						   System.out.println("verifiedvalue::"+ret);
						   
							MDGetUserFromID mdgufid = new MDGetUserFromID();
							   String requester = mdgufid.getUserName(userID);
						if(ret==1 )//&& rtVal==1)
						{
						BookDaoImpl dao= new BookDaoImpl();
							status=dao.addTextBooks(textbook);
							String endDate=dateFormat.format(new Date());
							Long el=System.currentTimeMillis();
							MDTransactionWriter.writeLog(datastoreName,"BookServiceImpl_addTextBooks",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
						}else
						{
							status="you are not authorised user";
						}
						}
							catch(Exception localException)
							{
								MDTransactionWriter.errorlog.debug(localException);
								MDTransactionWriter.errorlog.info(localException);
								status="failed in service layer";
								System.out.println(localException);
							}
			
					return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
			}
	
public Response deleteTextBooks(int textbookId,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		
		try
			{	
			MDValidation mdv = new MDValidation();  
			  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			   System.out.println("verifiedvalue::"+ret);
			   
				MDGetUserFromID mdgufid = new MDGetUserFromID();
				   String requester = mdgufid.getUserName(userID);
			if(ret==1 )//&& rtVal==1)
			{
			BookDaoImpl dao= new BookDaoImpl();
			status=dao.deleteTextBooks(textbookId, schoolId,branchId);
		
		String endDate=dateFormat.format(new Date());	
		Long el=System.currentTimeMillis();
		//status="user validation successfull";
			MDTransactionWriter.writeLog(datastoreName,"BookServiceImpl_deleteTextBooks",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
	}else
	{
		status="you are not authorised user";
	}
	}
	catch(Exception localException)
	{
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
		status="failed in service layer";
	}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();	
	}


public Response updateTextBooks(TextBook textbook,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		textbook.setSchoolId(schoolId);
		textbook.setBranchId(branchId);
		try
		{	
			MDValidation mdv = new MDValidation();  
		  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
		   System.out.println("verifiedvalue::"+ret);
		   
			MDGetUserFromID mdgufid = new MDGetUserFromID();
			   String requester = mdgufid.getUserName(userID);
		if(ret==1 )//&& rtVal==1)
		{
			BookDaoImpl dao= new BookDaoImpl();
			status=dao.updateTextBooks(textbook, schoolId,branchId);
		  String endDate=dateFormat.format(new Date());
		  Long el=System.currentTimeMillis();
		  //status="user validation successfull";
		  MDTransactionWriter.writeLog(datastoreName,"BookServiceImpl_updateTextBooks",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
		}else
		{
			status="you are not authorised user";
		}
		}
		  catch(Exception localException)
		   {
			  MDTransactionWriter.errorlog.debug(localException);
			  MDTransactionWriter.errorlog.info(localException);
			  status="failed in service layer";
		   }
    return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}
	
	
	public Response getAllTextBooks(int userID, int connectionID,String datastoreName,int PNO, int size,int schoolId,int branchId,int classId,int sectionId,int subjectTypeId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try{	
				MDValidation mdv = new MDValidation();  
			  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			   System.out.println("verifiedvalue::"+ret);
			   
				MDGetUserFromID mdgufid = new MDGetUserFromID();
				   String requester = mdgufid.getUserName(userID);
		if(ret==1 )//&& rtVal==1)
		{
			BookDaoImpl dao= new BookDaoImpl();
			status=dao.getAllTextBooks(PNO, size, schoolId,branchId, classId, sectionId, subjectTypeId);
			System.out.println(status);
			String endDate=dateFormat.format(new Date());
			  Long el=System.currentTimeMillis();
			 MDTransactionWriter.writeLog(datastoreName,"BookServiceImpl_getAllTextBooks",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		

		}else
		{
			status="you are not authorised user";
		}
		}catch(Exception localException)
		   {
			  MDTransactionWriter.errorlog.debug(localException);
			  MDTransactionWriter.errorlog.info(localException);
			  status="failed in service layer";
		   }
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}
	
	
	public Response getByIdTextBook(int textbookId,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
			MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
			
			String status=null;
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date date = new Date();
			String startDate=dateFormat.format(date);
			Long sl=System.currentTimeMillis();
			try
				{	
					MDValidation mdv = new MDValidation();  
					int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
				   System.out.println("verifiedvalue::"+ret);
				   
					MDGetUserFromID mdgufid = new MDGetUserFromID();
					   String requester = mdgufid.getUserName(userID);
				if(ret==1 )//&& rtVal==1)
				{
				BookDaoImpl dao= new BookDaoImpl();
				status=dao.getByIdTextBook(textbookId,schoolId,branchId);
				 System.out.println(status);
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				//status1="user validation successfull";
				MDTransactionWriter.writeLog(datastoreName,"BookServiceImpl_getByIdTextBook",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
		}else
		{
			status="you are not authorised user";
		}
		}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			status="failed in service layer";
			//System.out.println(localException);
		  }
	 return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
		}


}
