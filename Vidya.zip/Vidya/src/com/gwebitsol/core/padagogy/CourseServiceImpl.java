package com.gwebitsol.core.padagogy;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import com.gwebitsol.core.security.MDValidation;
import com.gwebitsol.core.usermanagement.MDGetUserFromID;
import com.gwebitsol.core.util.MDTransactionWriter;

public class CourseServiceImpl implements CourseServiceInf{
	@Context 
	private HttpServletRequest hsr;
	
	public Response addCourse(CoursePojo coursePojo,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		coursePojo.setBranchId(branchId);
		coursePojo.setSchoolId(schoolId);
			try
				{	
					MDValidation mdv = new MDValidation();  
				  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
				   System.out.println("verifiedvalue::"+ret);
				   
					MDGetUserFromID mdgufid = new MDGetUserFromID();
					   String requester = mdgufid.getUserName(userID);
				if(ret==1 )//&& rtVal==1)
				{
					CourseDao dao= new CourseDao();
					status=dao.addCourse(coursePojo);
					String endDate=dateFormat.format(new Date());
					Long el=System.currentTimeMillis();
					MDTransactionWriter.writeLog(datastoreName,"CourseServiceImpl_addCourse",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
					}else
					{
					status="you are not authorised user";
					}
				}catch(Exception localException)
					{
						MDTransactionWriter.errorlog.debug(localException);
						MDTransactionWriter.errorlog.info(localException);
						status="failed in service layer";
						System.out.println(localException);
					}
	
			return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}


	public Response deleteCourse(int courseId,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
			{	
				MDValidation mdv = new MDValidation();  
			  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			   System.out.println("verifiedvalue::"+ret);
			   
				MDGetUserFromID mdgufid = new MDGetUserFromID();
				   String requester = mdgufid.getUserName(userID);
			if(ret==1 )//&& rtVal==1)
			{
			CourseDao dao= new CourseDao();
			status=dao.deleteCourse(courseId, schoolId,branchId);
			String endDate=dateFormat.format(new Date());	
			Long el=System.currentTimeMillis();
			//status="user validation successfull";
			MDTransactionWriter.writeLog(datastoreName,"CourseServiceImpl_deleteCourse",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
			}
			else
			{
				status="you are not authorised user";
			}
			}
			catch(Exception localException)
				{
					MDTransactionWriter.errorlog.debug(localException);
					MDTransactionWriter.errorlog.info(localException);
					status="failed in service layer";
				}
			return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();	
		}
		public Response updateCourse(CoursePojo coursePojo,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
			MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
			String status=null;
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date date = new Date();
			String startDate=dateFormat.format(date);
			Long sl=System.currentTimeMillis();
			coursePojo.setBranchId(branchId);
			coursePojo.setSchoolId(schoolId);
			try
				{	
				MDValidation mdv = new MDValidation();  
				  int ret =mdv.allvalidations(userID,connectionID,datastoreName,schoolId,branchId);
				   System.out.println("verifiedvalue::"+ret);
				   
					MDGetUserFromID mdgufid = new MDGetUserFromID();
					   String requester = mdgufid.getUserName(userID);
				if(ret==1 )//&& rtVal==1)
				{
					CourseDao dao= new CourseDao();
				status=dao.updateCourse(coursePojo,schoolId,branchId);
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				//status="user validation successfull";
				MDTransactionWriter.writeLog(datastoreName,"CourseServiceImpl_updateCourse",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
				}else
				{
					status="you are not authorised user";
				}
			}
				catch(Exception localException)
				{
					MDTransactionWriter.errorlog.debug(localException);
					MDTransactionWriter.errorlog.info(localException);
					status="failed in service layer";
					}
			return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
		}


		public Response getAllCourses(int userID, int connectionID,String datastoreName,int PNO, int size,int schoolId,int branchId,int classId,int sectionId,int subjectId,int unitId,int chapterId,int topicId) {
				MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
				String status=null;
				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date date = new Date();
				String startDate=dateFormat.format(date);
				Long sl=System.currentTimeMillis();
				
				try{
					MDValidation mdv = new MDValidation();  
					  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
					   System.out.println("verifiedvalue::"+ret);
					   
						MDGetUserFromID mdgufid = new MDGetUserFromID();
						   String requester = mdgufid.getUserName(userID);
				if(ret==1 )//&& rtVal==1)
				{
					CourseDao dao= new CourseDao();
					status=dao.getAllCourses( PNO,size, schoolId, branchId, classId, sectionId, subjectId, unitId, chapterId,topicId);
					System.out.println(status);
					String endDate=dateFormat.format(new Date());
					Long el=System.currentTimeMillis();
					MDTransactionWriter.writeLog(datastoreName,"CourseServiceImpl_getAllCourses",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
				}
					else
					{
						status="you are not authorised user";
					}
				}catch(Exception localException)
					{
						MDTransactionWriter.errorlog.debug(localException);
						MDTransactionWriter.errorlog.info(localException);
						status="failed in service layer";
					}
				return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
			}


		public Response getByIdCourse(int courseId,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
			MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
			String status=null;
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date date = new Date();
			String startDate=dateFormat.format(date);
			Long sl=System.currentTimeMillis();
			try
			{	
				MDValidation mdv = new MDValidation();  
			  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			   System.out.println("verifiedvalue::"+ret);
			   
				MDGetUserFromID mdgufid = new MDGetUserFromID();
				   String requester = mdgufid.getUserName(userID);
			if(ret==1 )//&& rtVal==1)
			{
				CourseDao dao= new CourseDao();
				status=dao.getByIdCourse(courseId,schoolId,branchId);
				System.out.println(status);
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				//status1="user validation successfull";
				MDTransactionWriter.writeLog(datastoreName,"CourseServiceImpl_getByIdCourse",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
			}else
			{
				status="you are not authorised user";
			}
			}
			catch(Exception localException)
			{
				MDTransactionWriter.errorlog.debug(localException);
				MDTransactionWriter.errorlog.info(localException);
				status="failed in service layer";
				//System.out.println(localException);
			}
			return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
		}


	public Response addChapter(ChapterPojo chapterPojo,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		chapterPojo.setBranchId(branchId);
		chapterPojo.setSchoolId(schoolId);
			try
				{	
				MDValidation mdv = new MDValidation();  
				  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
				   System.out.println("verifiedvalue::"+ret);
				   
					MDGetUserFromID mdgufid = new MDGetUserFromID();
					   String requester = mdgufid.getUserName(userID);
				if(ret==1 )//&& rtVal==1)
				{
				CourseDao dao= new CourseDao();
					status=dao.addChapter(chapterPojo);
					String endDate=dateFormat.format(new Date());
					Long el=System.currentTimeMillis();
					MDTransactionWriter.writeLog(datastoreName,"CourseServiceImpl_addChapter",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
				}else
				{
					status="you are not authorised user";
				}
			}
					catch(Exception localException)
					{
						MDTransactionWriter.errorlog.debug(localException);
						MDTransactionWriter.errorlog.info(localException);
						status="failed in service layer";
						System.out.println(localException);
					}
	
			return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
		}


	public Response deleteChapter(int chapterId,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {

			MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	

			String status=null;
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date date = new Date();
			String startDate=dateFormat.format(date);
				Long sl=System.currentTimeMillis();

				try
				{	
					MDValidation mdv = new MDValidation();  
					  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
					   System.out.println("verifiedvalue::"+ret);
					   
						MDGetUserFromID mdgufid = new MDGetUserFromID();
						   String requester = mdgufid.getUserName(userID);
				if(ret==1 )//&& rtVal==1)
				{
					CourseDao dao= new CourseDao();
					status=dao.deleteChapter(chapterId,schoolId,branchId);
					String endDate=dateFormat.format(new Date());	
					Long el=System.currentTimeMillis();
					//status="user validation successfull";
					MDTransactionWriter.writeLog(datastoreName,"CourseServiceImpl_deleteChapter",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
				}else
				{
					status="you are not authorised user";
				}
				}
				catch(Exception localException)
				{
					MDTransactionWriter.errorlog.debug(localException);
					MDTransactionWriter.errorlog.info(localException);
					status="failed in service layer";
				}
				return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();	
		}
	public Response updateChapter(ChapterPojo chapterPojo,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
			MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
			String status=null;
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date date = new Date();
			String startDate=dateFormat.format(date);
			Long sl=System.currentTimeMillis();
			chapterPojo.setBranchId(branchId);
			chapterPojo.setSchoolId(schoolId);
			try
			{	
				MDValidation mdv = new MDValidation();  
				  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
				   System.out.println("verifiedvalue::"+ret);
				   
					MDGetUserFromID mdgufid = new MDGetUserFromID();
					   String requester = mdgufid.getUserName(userID);
			if(ret==1 )//&& rtVal==1)
			{
				CourseDao dao=new CourseDao();
				status=dao.updateChapter(chapterPojo, schoolId, branchId);
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				//status="user validation successfull";
				MDTransactionWriter.writeLog(datastoreName,"CourseServiceImpl_updateChapter",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
			}else
			{
				status="you are not authorised user";
			}
			}
			catch(Exception localException)
			{
				MDTransactionWriter.errorlog.debug(localException);
				MDTransactionWriter.errorlog.info(localException);
				status="failed in service layer";
			}
			return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
		}

	public Response getAllChapters(int userID, int connectionID,String datastoreName,int PNO, int size,int schoolId,int branchId,int classId,int sectionId,int subjectId,int unitId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try{
			MDValidation mdv = new MDValidation();  
			  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			   System.out.println("verifiedvalue::"+ret);
			   
				MDGetUserFromID mdgufid = new MDGetUserFromID();
				   String requester = mdgufid.getUserName(userID);
			if(ret==1 )//&& rtVal==1)
			{
			CourseDao dao=new CourseDao();
			status=dao.getAllChapters( PNO, size,schoolId,branchId, classId,sectionId, subjectId, unitId);
			System.out.println(status);
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			MDTransactionWriter.writeLog(datastoreName,"CourseServiceImpl_getAllChapters",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
			}
			else
			{
				status="you are not authorised user";
			}
		}catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			status="failed in service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response getByIdChapter(int chapterId,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
			try
			{	
				MDValidation mdv = new MDValidation();  
				  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
				   System.out.println("verifiedvalue::"+ret);
				   
					MDGetUserFromID mdgufid = new MDGetUserFromID();
					   String requester = mdgufid.getUserName(userID);
			if(ret==1 )//&& rtVal==1)
			{
				CourseDao dao=new CourseDao();
				status=dao.getByIdChapter(chapterId, schoolId, branchId);
				System.out.println(status);
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				//status1="user validation successfull";
				MDTransactionWriter.writeLog(datastoreName,"CourseServiceImpl_getByIdChapter",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
			}else
			{
				status="you are not authorised user";
			}
			}
			catch(Exception localException)
			{
				MDTransactionWriter.errorlog.debug(localException);
				MDTransactionWriter.errorlog.info(localException);
				status="failed in service layer";
				//System.out.println(localException);
			}
			return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
		}


	public Response addUnit(UnitsPojo unitsPojo,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		unitsPojo.setBranchId(branchId);
		unitsPojo.setSchoolId(schoolId);
			try
				{	
					MDValidation mdv = new MDValidation();  
					int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
				   System.out.println("verifiedvalue::"+ret);
				   
					MDGetUserFromID mdgufid = new MDGetUserFromID();
					   String requester = mdgufid.getUserName(userID);
				if(ret==1 )//&& rtVal==1)
				{
					CourseDao dao=new CourseDao();
					status=dao.addUnit(unitsPojo);
					String endDate=dateFormat.format(new Date());
					Long el=System.currentTimeMillis();
					MDTransactionWriter.writeLog(datastoreName,"CourseServiceImpl_addUnit",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
				}else
					{
						status="you are not authorised user";
					}
				}
					catch(Exception localException)
					{
						MDTransactionWriter.errorlog.debug(localException);
						MDTransactionWriter.errorlog.info(localException);
						status="failed in service layer";
						System.out.println(localException);
					}
	
			return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}


	public Response deleteUnit(int unitId,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {

		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	

		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();

		try
		{	
			MDValidation mdv = new MDValidation();  
			  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			   System.out.println("verifiedvalue::"+ret);
			   
				MDGetUserFromID mdgufid = new MDGetUserFromID();
				   String requester = mdgufid.getUserName(userID);
			if(ret==1 )//&& rtVal==1)
			{
			CourseDao dao=new CourseDao();
			status=dao.deleteUnit(unitId, schoolId,branchId);

			String endDate=dateFormat.format(new Date());	
			Long el=System.currentTimeMillis();
			//status="user validation successfull";
			MDTransactionWriter.writeLog(datastoreName,"CourseServiceImpl_deleteUnit",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
			}else
			{
				status="you are not authorised user";
			}
			}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			status="failed in service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();	
	}
	public Response updateUnit(UnitsPojo unitsPojo,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		unitsPojo.setBranchId(branchId);
		unitsPojo.setSchoolId(schoolId);
		try
		{	
			MDValidation mdv = new MDValidation();  
			  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			   System.out.println("verifiedvalue::"+ret);
			   
				MDGetUserFromID mdgufid = new MDGetUserFromID();
				   String requester = mdgufid.getUserName(userID);
		if(ret==1 )//&& rtVal==1)
		{
			CourseDao dao=new CourseDao();
			status=dao.updateUnit(unitsPojo, schoolId,branchId);
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			//status="user validation successfull";
			MDTransactionWriter.writeLog(datastoreName,"CourseServiceImpl_updateUnit",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
		}else
		{
			status="you are not authorised user";
		}
		}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			status="failed in service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}


	public Response getAllUnits(int userID, int connectionID,String datastoreName,int PNO, int size,int schoolId,int branchId,int classId,int sectionId,int subjectId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			


		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try{ 
			MDValidation mdv = new MDValidation();  
			  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			   System.out.println("verifiedvalue::"+ret);
			   
				MDGetUserFromID mdgufid = new MDGetUserFromID();
				   String requester = mdgufid.getUserName(userID);
		if(ret==1 )//&& rtVal==1)
		{
			CourseDao dao=new CourseDao();
			status=dao.getAllUnits( PNO, size, schoolId,branchId, classId, sectionId, subjectId);
			System.out.println(status);
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			MDTransactionWriter.writeLog(datastoreName,"CourseServiceImpl_getAllUnits",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
		}else
			{
				status="you are not authorised user";
			}
		}catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			status="failed in service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response getByIdUnit(int unitId,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{		
			MDValidation mdv = new MDValidation();  
			  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			   System.out.println("verifiedvalue::"+ret);
			   
				MDGetUserFromID mdgufid = new MDGetUserFromID();
				   String requester = mdgufid.getUserName(userID);
		if(ret==1 )//&& rtVal==1)
		{
			CourseDao dao=new CourseDao();
			status=dao.getByIdUnit(unitId, schoolId, branchId);
			System.out.println(status);
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			//status1="user validation successfull";
			MDTransactionWriter.writeLog(datastoreName,"CourseServiceImpl_getByIdUnit",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
		}else
		{
			status="you are not authorised user";
		}
		}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			status="failed in service layer";
			//System.out.println(localException);
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	
	public Response addTopic(TopicPojo topicPojo,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());			
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();	
		topicPojo.setBranchId(branchId);
		topicPojo.setSchoolId(schoolId);
			try
				{	
				MDValidation mdv = new MDValidation();  
				  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
				   System.out.println("verifiedvalue::"+ret);
				   
					MDGetUserFromID mdgufid = new MDGetUserFromID();
					   String requester = mdgufid.getUserName(userID);
				if(ret==1 )//&& rtVal==1)
				{
					CourseDao dao=new CourseDao();
					status=dao.addTopic(topicPojo);
					String endDate=dateFormat.format(new Date());
					Long el=System.currentTimeMillis();
					MDTransactionWriter.writeLog(datastoreName,"CourseServiceImpl_addTopic",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
				}else
				{
					status="you are not authorised user";
					}
				}catch(Exception localException)
					{
						MDTransactionWriter.errorlog.debug(localException);
						MDTransactionWriter.errorlog.info(localException);
						status="failed in service layer";
						System.out.println(localException);
					}
	
			return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}


	public Response deleteTopic(int topicId,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {

		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	

		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();

		try
		{	
			MDValidation mdv = new MDValidation();  
			  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			   System.out.println("verifiedvalue::"+ret);
			   
				MDGetUserFromID mdgufid = new MDGetUserFromID();
				   String requester = mdgufid.getUserName(userID);
		if(ret==1 )//&& rtVal==1)
		{
			CourseDao dao=new CourseDao();
			status=dao.deleteTopic(topicId,schoolId,branchId);
			String endDate=dateFormat.format(new Date());	
			Long el=System.currentTimeMillis();
			//status="user validation successfull";
			MDTransactionWriter.writeLog(datastoreName,"CourseServiceImpl_deleteTopic",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
		}
		else
		{
			status="you are not authorised user";
		}
	}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			status="failed in service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();	
	}	
	public Response updateTopic(TopicPojo topicPojo,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		topicPojo.setSchoolId(schoolId);
		topicPojo.setBranchId(branchId);
		
		try
		{	MDValidation mdv = new MDValidation();  
		  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
		   System.out.println("verifiedvalue::"+ret);
		   
			MDGetUserFromID mdgufid = new MDGetUserFromID();
			   String requester = mdgufid.getUserName(userID);
		if(ret==1 )//&& rtVal==1)
		{
			CourseDao dao=new CourseDao();
			status=dao.updateTopic(topicPojo,schoolId, branchId);
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			//status="user validation successfull";
			MDTransactionWriter.writeLog(datastoreName,"CourseServiceImpl_updateTopic",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
		}else
		{
			status="you are not authorised user";
		}
	}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			status="failed in service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}


	public Response getAllTopics(int userID, int connectionID,String datastoreName,int PNO, int size,int  schoolId,int branchId,int classId,int sectionId,int subjectId,int unitId,int chapterId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try{
				MDValidation mdv = new MDValidation();  
				int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			   System.out.println("verifiedvalue::"+ret);
			   
				MDGetUserFromID mdgufid = new MDGetUserFromID();
				   String requester = mdgufid.getUserName(userID);
			if(ret==1 )//&& rtVal==1)
			{
				CourseDao dao=new CourseDao();
				status=dao.getAllTopics( PNO, size,schoolId,branchId, classId,sectionId, subjectId,unitId,chapterId);
				System.out.println(status);
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				MDTransactionWriter.writeLog(datastoreName,"CourseServiceImpl_getAllTopics",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
			}
				else
				{
					status="you are not authorised user";
				}
		}catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			status="failed in service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}


	public Response getByIdTopics(int topicId,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
			MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	

			String status=null;
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date date = new Date();
			String startDate=dateFormat.format(date);
			Long sl=System.currentTimeMillis();
			try
			{	
				MDValidation mdv = new MDValidation();  
				  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
				   System.out.println("verifiedvalue::"+ret);
				   
					MDGetUserFromID mdgufid = new MDGetUserFromID();
					   String requester = mdgufid.getUserName(userID);
				if(ret==1 )//&& rtVal==1)
				{
				CourseDao dao=new CourseDao();
				status=dao.getByIdTopics(topicId, schoolId,branchId);
				System.out.println(status);
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				//status1="user validation successfull";
				MDTransactionWriter.writeLog(datastoreName,"CourseServiceImpl_getByIdTopics",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
			}else
			{
				status="you are not authorised user";
			}
			}
			catch(Exception localException)
			{
				MDTransactionWriter.errorlog.debug(localException);
				MDTransactionWriter.errorlog.info(localException);
				status="failed in service layer";
				//System.out.println(localException);
			}
			return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
		}
}
