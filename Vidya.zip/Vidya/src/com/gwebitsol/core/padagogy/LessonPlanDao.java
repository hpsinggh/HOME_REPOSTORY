package com.gwebitsol.core.padagogy;

import java.util.Iterator;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class LessonPlanDao {

	public String addLessonPlan(LessonPlanPojo lessonPlanPojo) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
					String strg= null;
						 StringBuffer sb= new StringBuffer();
						 try {
								tx = rdSession.beginTransaction();
								String[] topid=null;
								int i;
								 i=(Integer)rdSession.save(lessonPlanPojo);		 
								System.out.println(i);
								topid=lessonPlanPojo.getTopicId().split(",");
								StringBuffer flsb=new StringBuffer();
								for(int j=0;j<=topid.length-1;j++)
								{
									flsb.append("insert into gbl_sm_tbl_lessonplantopic(LessonPlanId,TopicId) VALUES(");
									flsb.append(i);
									flsb.append(",");
									flsb.append(topid[j]);
									flsb.append(");");
									Query query=rdSession.createSQLQuery(flsb.toString());
									query.executeUpdate();
									flsb.setLength(0);
								}
									tx.commit();
									sb.append("<lessonPlan>");
									  sb.append("\n");
									  sb.append("<lessonPlanid>");
									  sb.append(i);
									  sb.append("</lessonPlanid>");
									  sb.append("\n");
									  sb.append("</lessonPlan>");
									  strg= sb.toString();
										} catch (Exception localException) {
											System.out.println(localException);
											localException.printStackTrace();
										   sb.append("<Response>");
										   sb.append("\n");
										   sb.append("<Result>");
										   sb.append("\n");
										   sb.append("Fail");
										   sb.append("\n");
										   sb.append("</Result>");
										   sb.append("\n");
										   sb.append("<Description>");
										   sb.append("could not inserted lessonplan item");
										   sb.append("</Description>");
										   sb.append("\n");
										   sb.append("<Exception>");
										   sb.append(localException);
										   sb.append("</Exception>");
										   sb.append("</Response>");
										   strg=sb.toString();
										   MDTransactionWriter.exceptionlog.info(localException);
										  if (tx!=null)
										   tx.rollback();
										  } finally {
										   rdSession.close(); 
										  }
										  return strg;
										 }
									
				public String deleteLessonPlan(int lessonplanId,int schoolId,int branchId) {
					Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
					Transaction tx = null;
						StringBuffer sb=new StringBuffer();
						String strg= null;                                                                        
						try {
								tx = rdSession.beginTransaction();
								LessonPlanPojo lpp = (LessonPlanPojo) rdSession.get(LessonPlanPojo.class,lessonplanId);					   
								   rdSession.evict(lpp);
								   if(branchId==lpp.getBranchId()&&schoolId==lpp.getSchoolId())
								   {
								   Query empQuery=rdSession.createSQLQuery("update gbl_sm_tbl_lessonplan set isDeleted='y' where LessonPlanId='"+lessonplanId+"'");
								   empQuery.executeUpdate();
								   tx.commit();
								    sb.append("<lessonPlan>");
								    sb.append("\n");
								    sb.append("<id>");
									sb.append("lessonPlan item deleted");
									sb.append("</id>");
									sb.append("\n");
									sb.append("</lessonPlan>");
									strg= sb.toString();
					}else{
						   strg = " lessonplan is not deleted";
						   sb.append("<lessonplan>");
						   sb.append("\n");
						   sb.append(strg);
						   sb.append("</lessonplan>");
						    String str = sb.toString();
						    return str;
						   }
						}
					catch(Exception localException)
					{
						System.out.println(localException);
						localException.printStackTrace();
					   sb.append("<Response>");
					   sb.append("\n");
					   sb.append("<Result>");
					   sb.append("\n");
					   sb.append("Fail");
					   sb.append("\n");
					   sb.append("</Result>");
					   sb.append("\n");
					   sb.append("<Description>");
					   sb.append("could not deleted lessonplan item");
					   sb.append("</Description>");
					   sb.append("\n");
					   sb.append("<Exception>");
					   sb.append(localException);
					   sb.append("</Exception>");
					   sb.append("</Response>");
					   strg=sb.toString();
					   MDTransactionWriter.exceptionlog.info(localException);
					  if (tx!=null)
					   tx.rollback();
					  } finally {
					   rdSession.close(); 
					  }
					  return strg;
					 }
				public String updateLessonPlan(LessonPlanPojo lessonPlanPojo,int schoolId,int branchId) {
					Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
					Transaction tx = null;	
					StringBuffer sb= new StringBuffer();
						String strg= null;
							try {
									tx = rdSession.beginTransaction();
									/*rdSession.update(lessonPlanPojo);
									 tx.commit();*/
									LessonPlanPojo lpp = (LessonPlanPojo) rdSession.get(LessonPlanPojo.class,lessonPlanPojo.getLessonPlanId());
									rdSession.evict(lpp);
									   if(branchId==lpp.getBranchId()&&schoolId==lpp.getSchoolId())
									   rdSession.update(lessonPlanPojo);
									     
									   tx.commit();
									    sb.append("<lessonPlan>");
									    sb.append("\n");
									    sb.append("<lessonPlanid>");
										sb.append("\n");
										sb.append("lessonplan succssfully updated");
										sb.append("</lessonPlanid>");
										sb.append("\n");
										sb.append("</lessonPlan>");
										 strg= sb.toString();
								} 	catch (Exception localException) {

									System.out.println(localException);
									localException.printStackTrace();
								   sb.append("<Response>");
								   sb.append("\n");
								   sb.append("<Result>");
								   sb.append("\n");
								   sb.append("Fail");
								   sb.append("\n");
								   sb.append("</Result>");
								   sb.append("\n");
								   sb.append("<Description>");
								   sb.append("could not update lessonplan item");
								   sb.append("</Description>");
								   sb.append("\n");
								   sb.append("<Exception>");
								   sb.append(localException);
								   sb.append("</Exception>");
								   sb.append("</Response>");
								   strg=sb.toString();
								   MDTransactionWriter.exceptionlog.info(localException);
								  if (tx!=null)
								   tx.rollback();
								  } finally {
								   rdSession.close(); 
								  }
								  return strg;
								 }
				@SuppressWarnings("rawtypes")
				public String getAllLessonPlans(int PNO, int size,int schoolId,int branchId,int classId,int subjectId,int unitId,int chapterId) {
								  String xmlString=null;
								  Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
								  Transaction stgTx=null;
								  StringBuffer sb = new StringBuffer();
								  try
								  {
								   stgTx=stgSession.beginTransaction();
								    int fset = (PNO-1)*size;
								    String filterWhere="";
								    if(classId!=0){									  								    	
								    	filterWhere+=" and lp.ClassId="+classId;	 								
								    }
									if(subjectId!=0){
										filterWhere += " and lp.SubjectId="+subjectId;
									}
								    if(unitId!=0){
								    	filterWhere+=" and units.UnitId="+unitId;	
								    }
								    if(chapterId!=0){
								    	filterWhere+=" and chapter.ChapterId="+chapterId;			    	
								    		}
								    String gsSql ="SELECT count(*) FROM gbl_sm_tbl_lessonplan as lp left outer join gbl_sm_tbl_lessonplantopic as lestopic on lestopic.LessonPlanId=lp.LessonPlanId JOIN gbl_sm_tbl_staff as staff ON staff.EmployeeId=lp.EmployeeId left outer join gbl_sm_tbl_topic as topic on lestopic.TopicId=topic.TopicId left outer join gbl_sm_tbl_chapter as chapter on topic.ChapterId=chapter.ChapterId left outer join gbl_sm_tbl_units as units on units.UnitId=chapter.UnitId left outer join gbl_sm_tbl_subjects as sub on sub.SubjectId=lp.SubjectId left outer join gbl_sm_tbl_subject_type as subtype on subtype.SubjectTypeId=sub.SubjectTypeId join gbl_sm_tbl_class as cls on lp.ClassId=cls.ClassId left outer join gbl_sm_tbl_section as sec on sec.SectionId=sub.SectionId where (lp.isDeleted<>'y' or lp.isDeleted is null) and lp.schoolId='"+schoolId+"' and lp.branchId='"+branchId+"' "+filterWhere+"";
								    Query gsQuery=stgSession.createSQLQuery(gsSql);
								    Object noRecords= gsQuery.uniqueResult();
								    sb.append("<lessonplans>");
								    sb.append("\n");
								    sb.append("<noRecords>"+noRecords+"</noRecords>");
								    sb.append("\n");
								    
								     if (PNO > 0 & size > 0){
								     gsSql="SELECT lp.LessonPlanId,lp.EmployeeId,staff.StaffNumber,staff.FirstName,staff.MiddleName,staff.LastName,lp.LessonPlanName,lp.LessonPlanStatus,lp.StartDate,lp.EndDate,lp.LessonPlanDescription,lp.CreatedDate,lp.ModifiedDate,lp.SchoolId,lp.BranchId,lp.ClassId,cls.ClassName,lp.SubjectId,subtype.SubjectName,units.UnitId,units.UnitName,chapter.ChapterId,chapter.ChapterName,sec.SectionId,sec.SectionName FROM gbl_sm_tbl_lessonplan as lp left outer join gbl_sm_tbl_lessonplantopic as lestopic on lestopic.LessonPlanId=lp.LessonPlanId JOIN gbl_sm_tbl_staff as staff ON staff.EmployeeId=lp.EmployeeId left outer join gbl_sm_tbl_topic as topic on lestopic.TopicId=topic.TopicId left outer join gbl_sm_tbl_chapter as chapter on topic.ChapterId=chapter.ChapterId left outer join gbl_sm_tbl_units as units on units.UnitId=chapter.UnitId left outer join gbl_sm_tbl_subjects as sub on sub.SubjectId=lp.SubjectId left outer join gbl_sm_tbl_subject_type as subtype on subtype.SubjectTypeId=sub.SubjectTypeId join gbl_sm_tbl_class as cls on lp.ClassId=cls.ClassId left outer join gbl_sm_tbl_section as sec on sec.SectionId=sub.SectionId where (lp.isDeleted<>'y' or lp.isDeleted is null) and lp.schoolId='"+schoolId+"' and lp.branchId='"+branchId+"'"+filterWhere+" limit "+size+" offset "+fset;
								     }
								     else {
								      gsSql="SELECT lp.LessonPlanId,lp.EmployeeId,staff.StaffNumber,staff.FirstName,staff.MiddleName,staff.LastName,lp.LessonPlanName,lp.LessonPlanStatus,lp.StartDate,lp.EndDate,lp.LessonPlanDescription,lp.CreatedDate,lp.ModifiedDate,lp.SchoolId,lp.BranchId,lp.ClassId,cls.ClassName,lp.SubjectId,subtype.SubjectName,units.UnitId,units.UnitName,chapter.ChapterId,chapter.ChapterName,sec.SectionId,sec.SectionName FROM gbl_sm_tbl_lessonplan as lp left outer join gbl_sm_tbl_lessonplantopic as lestopic on lestopic.LessonPlanId=lp.LessonPlanId JOIN gbl_sm_tbl_staff as staff ON staff.EmployeeId=lp.EmployeeId left outer join gbl_sm_tbl_topic as topic on lestopic.TopicId=topic.TopicId left outer join gbl_sm_tbl_chapter as chapter on topic.ChapterId=chapter.ChapterId left outer join gbl_sm_tbl_units as units on units.UnitId=chapter.UnitId left outer join gbl_sm_tbl_subjects as sub on sub.SubjectId=lp.SubjectId left outer join gbl_sm_tbl_subject_type as subtype on subtype.SubjectTypeId=sub.SubjectTypeId join gbl_sm_tbl_class as cls on lp.ClassId=cls.ClassId left outer join gbl_sm_tbl_section as sec on sec.SectionId=sub.SectionId where (lp.isDeleted<>'y' or lp.isDeleted is null) and lp.schoolId='"+schoolId+"' and lp.branchId='"+branchId+"'"+filterWhere+"";
								     } 
								    
								    gsQuery=stgSession.createSQLQuery(gsSql);
								    List gcList=gsQuery.list();
								    Iterator gsIT=gcList.iterator();
								     while(gsIT.hasNext())
								     {
								      Object[] mdcArr=(Object[])gsIT.next();
								      sb.append("<lessonplan>");
								      sb.append("\n");
								      sb.append("<lessonPlanId>"+mdcArr[0]+"</lessonPlanId>");
								      sb.append("\n");
								      sb.append("<employeeId>" + mdcArr[1]+ "</employeeId>");
								      sb.append("\n");
								      sb.append("<staffNumber>" + mdcArr[2]+ "</staffNumber>");
								      sb.append("\n");
								      sb.append("<firstName>" + mdcArr[3] + "</firstName>");
								      sb.append("\n");
								      sb.append("<middleName>" + mdcArr[4]+ "</middleName>");
								      sb.append("\n");
								      sb.append("<lastName>" + mdcArr[5] + "</lastName>");
								      sb.append("\n");
								      sb.append("<lessonPlanName>" +  mdcArr[6]+ "</lessonPlanName>");
								      sb.append("\n");
								      sb.append("<lessonPlanStatus>" + mdcArr[7] + "</lessonPlanStatus>");
								      sb.append("\n");
								      sb.append("<startDate>" + mdcArr[8] + "</startDate>");
								      sb.append("\n");
								      sb.append("<endDate>" +  mdcArr[9]+ "</endDate>");
								      sb.append("\n");
								      sb.append("<lessonPlanDescription>" + mdcArr[10] + "</lessonPlanDescription>");
								      sb.append("\n");
								      sb.append("<createdDate>" + mdcArr[11] + "</createdDate>");
								      sb.append("\n");
								      sb.append("<modifiedDate>" + mdcArr[12] + "</modifiedDate>");
								      sb.append("\n");
								      sb.append("<schoolId>" + mdcArr[13] + "</schoolId>");
								      sb.append("\n");
								      sb.append("<branchId>" + mdcArr[14] + "</branchId>");
								      sb.append("\n");								   								      
								      sb.append("<classId>"+mdcArr[15]+"</classId>");
								      sb.append("\n");
								      sb.append("<className>"+mdcArr[16]+"</className>");
								      sb.append("\n");								   
								      sb.append("<subjectId>"+mdcArr[17]+"</subjectId>");
								      sb.append("\n");
								      sb.append("<subjectName>"+mdcArr[18]+"</subjectName>");
								      sb.append("\n");
								      sb.append("<unitId>"+mdcArr[19]+"</unitId>");
								      sb.append("\n");
								      sb.append("<unitName>"+mdcArr[20]+"</unitName>");
								      sb.append("\n");
								      sb.append("<chapterId>" + mdcArr[21]+ "</chapterId>");
								      sb.append("\n");
								      sb.append("<chapterName>" + mdcArr[22] + "</chapterName>");
								      sb.append("\n");
								      sb.append("<sectionId>" + mdcArr[23]+ "</sectionId>");
								      sb.append("\n");
								      sb.append("<sectionName>" + mdcArr[24] + "</sectionName>");
								      sb.append("\n");
								      sb.append("</lessonplan>");
								     }
								    
								    stgTx.commit();
								    sb.append("</lessonplans>");
								    sb.append("\n");

								    xmlString=sb.toString();
								   }
						catch(Exception localException)
						{

							System.out.println(localException);
							localException.printStackTrace();
						   sb.append("<Response>");
						   sb.append("\n");
						   sb.append("<Result>");
						   sb.append("\n");
						   sb.append("Fail");
						   sb.append("\n");
						   sb.append("</Result>");
						   sb.append("\n");
						   sb.append("<Description>");
						   sb.append("could not getall lessonplan items");
						   sb.append("</Description>");
						   sb.append("\n");
						   sb.append("<Exception>");
						   sb.append(localException);
						   sb.append("</Exception>");
						   sb.append("</Response>");
						   xmlString=sb.toString();
						   MDTransactionWriter.exceptionlog.info(localException);
						  if (stgTx!=null)
							  stgTx.rollback();
						  } finally {
						   stgSession.close(); 
						  }
						  return xmlString;
						 }
					

				@SuppressWarnings("rawtypes")
				public String getByIdLessonPlan(int lessonplanId,int schoolId,int branchId) {
					Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
					Transaction tx = null;
						StringBuffer sb= new StringBuffer();
						System.out.println("hi dao impl success");
						String strg= null;
						
							try {
								tx = rdSession.beginTransaction();
								Query query=rdSession.createSQLQuery("SELECT lp.LessonPlanId,lp.EmployeeId,staff.StaffNumber,staff.FirstName,staff.MiddleName,staff.LastName,lp.LessonPlanName,lp.LessonPlanStatus,lp.StartDate,lp.EndDate,lp.LessonPlanDescription,lp.CreatedDate,lp.ModifiedDate,lp.SchoolId,lp.BranchId,lp.ClassId,cls.ClassName,lp.SubjectId,subtype.SubjectName,units.UnitId,units.UnitName,chapter.ChapterId,chapter.ChapterName,sec.SectionId,sec.SectionName FROM gbl_sm_tbl_lessonplan as lp left outer join gbl_sm_tbl_lessonplantopic as lestopic on lestopic.LessonPlanId=lp.LessonPlanId JOIN gbl_sm_tbl_staff as staff ON staff.EmployeeId=lp.EmployeeId left outer join gbl_sm_tbl_topic as topic on lestopic.TopicId=topic.TopicId left outer join gbl_sm_tbl_chapter as chapter on topic.ChapterId=chapter.ChapterId left outer join gbl_sm_tbl_units as units on units.UnitId=chapter.UnitId left outer join gbl_sm_tbl_subjects as sub on sub.SubjectId=lp.SubjectId left outer join gbl_sm_tbl_subject_type as subtype on subtype.SubjectTypeId=sub.SubjectTypeId join gbl_sm_tbl_class as cls on lp.ClassId=cls.ClassId left outer join gbl_sm_tbl_section as sec on sec.SectionId=sub.SectionId where (lp.isDeleted<>'y' or lp.isDeleted is null) "
								     		+ " and lp.LessonPlanId='"+lessonplanId+"' and lp.schoolId='"+schoolId+"' and lp.branchId='"+branchId+"'");
							    List gcList=query.list();
							    Iterator gsIT=gcList.iterator();
							     while(gsIT.hasNext())
							     {
							      Object[] mdcArr=(Object[])gsIT.next();
							  
							      sb.append("<lessonplan>");
							      sb.append("\n");
							      sb.append("<lessonPlanId>"+mdcArr[0]+"</lessonPlanId>");
							      sb.append("\n");
							      sb.append("<employeeId>" + mdcArr[1]+ "</employeeId>");
							      sb.append("\n");
							      sb.append("<staffNumber>" + mdcArr[2]+ "</staffNumber>");
							      sb.append("\n");
							      sb.append("<firstName>" + mdcArr[3] + "</firstName>");
							      sb.append("\n");
							      sb.append("<middleName>" + mdcArr[4]+ "</middleName>");
							      sb.append("\n");
							      sb.append("<lastName>" + mdcArr[5] + "</lastName>");
							      sb.append("\n");
							      sb.append("<lessonPlanName>" +  mdcArr[6]+ "</lessonPlanName>");
							      sb.append("\n");
							      sb.append("<lessonPlanStatus>" + mdcArr[7] + "</lessonPlanStatus>");
							      sb.append("\n");
							      sb.append("<startDate>" + mdcArr[8] + "</startDate>");
							      sb.append("\n");
							      sb.append("<endDate>" +  mdcArr[9]+ "</endDate>");
							      sb.append("\n");
							      sb.append("<lessonPlanDescription>" + mdcArr[10] + "</lessonPlanDescription>");
							      sb.append("\n");
							      sb.append("<createdDate>" + mdcArr[11] + "</createdDate>");
							      sb.append("\n");
							      sb.append("<modifiedDate>" + mdcArr[12] + "</modifiedDate>");
							      sb.append("\n");
							      sb.append("<schoolId>" + mdcArr[13] + "</schoolId>");
							      sb.append("\n");
							      sb.append("<branchId>" + mdcArr[14] + "</branchId>");
							      sb.append("\n");								   								      
							      sb.append("<classId>"+mdcArr[15]+"</classId>");
							      sb.append("\n");
							      sb.append("<className>"+mdcArr[16]+"</className>");
							      sb.append("\n");								   
							      sb.append("<subjectId>"+mdcArr[17]+"</subjectId>");
							      sb.append("\n");
							      sb.append("<subjectName>"+mdcArr[18]+"</subjectName>");
							      sb.append("\n");
							      sb.append("<unitId>"+mdcArr[19]+"</unitId>");
							      sb.append("\n");
							      sb.append("<unitName>"+mdcArr[20]+"</unitName>");
							      sb.append("\n");
							      sb.append("<chapterId>" + mdcArr[21]+ "</chapterId>");
							      sb.append("\n");
							      sb.append("<chapterName>" + mdcArr[22] + "</chapterName>");
							      sb.append("\n");
							      sb.append("<sectionId>" + mdcArr[23]+ "</sectionId>");
							      sb.append("\n");
							      sb.append("<sectionName>" + mdcArr[24] + "</sectionName>");
							      sb.append("\n");
							      sb.append("</lessonplan>");
							      sb.append("\n");
									String str= sb.toString();
									return str;
							}
									
							} 	catch (Exception localException) {

								System.out.println(localException);
								localException.printStackTrace();
							   sb.append("<Response>");
							   sb.append("\n");
							   sb.append("<Result>");
							   sb.append("\n");
							   sb.append("Fail");
							   sb.append("\n");
							   sb.append("</Result>");
							   sb.append("\n");
							   sb.append("<Description>");
							   sb.append("could not getby lessonplan item");
							   sb.append("</Description>");
							   sb.append("\n");
							   sb.append("<Exception>");
							   sb.append(localException);
							   sb.append("</Exception>");
							   sb.append("</Response>");
							   strg=sb.toString();
							   MDTransactionWriter.exceptionlog.info(localException);
							  if (tx!=null)
							   tx.rollback();
							  } finally {
							   rdSession.close(); 
							  }
							  return strg;
							 }

				@SuppressWarnings({ "unchecked", "rawtypes" })
				public String getAllTopicsByLessonPlanId(int lessonPlanId,int schoolId,int branchId) {
					Session stgSession = MDHibernateUtil.getSessionFactory().openSession();
					Transaction tx = null;
					StringBuffer sb= new StringBuffer();
					String strg= null;
					
						try {
								tx = stgSession.beginTransaction();
								List<TopicPojo> list=stgSession.createSQLQuery("select lestopic.LessonPlanId,lestopic.TopicId,topic.ChapterId,chapter.ChapterNo,chapter.ChapterName,topic.TopicName,topic.`Status`,topic.Description,topic.SchoolId,topic.BranchId from gbl_sm_tbl_lessonplantopic as lestopic left outer join gbl_sm_tbl_lessonplan as les on lestopic.LessonPlanId=les.LessonPlanId left outer join gbl_sm_tbl_topic as topic on lestopic.TopicId=topic.TopicId left outer join gbl_sm_tbl_chapter as chapter on topic.ChapterId=chapter.ChapterId where lestopic.LessonPlanId='"+lessonPlanId+"'").list();
							     Iterator it=list.iterator();
							     sb.append("<lessonplan>");
							     sb.append("\n");
							     while(it.hasNext()){
							    	  Object[] ex=(Object[])it.next();
							    	  sb.append("<topics>");
							    	  sb.append("\n");
							    	  	sb.append("<lessonplanId>");
							             sb.append(ex[0]);
							             sb.append("</lessonplanId>");
							             sb.append("\n");
							             sb.append("<topicId>");
							             sb.append(ex[1]);
							             sb.append("</topicId>");
							             sb.append("\n");
							             sb.append("<chapterId>");
							             sb.append(ex[2]);
							             sb.append("</chapterId>");
							             sb.append("\n");
									      sb.append("<chapterNo>" + ex[3] + "</chapterNo>");
									      sb.append("\n");
									      sb.append("<chapterName>" + ex[4] + "</chapterName>");
									      sb.append("\n");
							             sb.append("<topicName>");
							             sb.append(ex[5]);
							             sb.append("</topicName>");
							             sb.append("\n");
							             sb.append("<status>");
							             sb.append(ex[6]);
							             sb.append("</status>");
							             sb.append("\n");
							             sb.append("<description>");
							             sb.append(ex[7]);
							             sb.append("</description>");
							             sb.append("\n");
							             sb.append("<schoolId>" + ex[8] + "</schoolId>");
									      sb.append("\n");
									      sb.append("<branchId>" + ex[9] + "</branchId>");
									      sb.append("\n");
									      sb.append("</topics>");
									      sb.append("\n");
							     }
							     sb.append("</lessonplan>");
							     String str= sb.toString();
									return str;
							    
				}catch (Exception localException) {

					System.out.println(localException);
					localException.printStackTrace();
				   sb.append("<Response>");
				   sb.append("\n");
				   sb.append("<Result>");
				   sb.append("\n");
				   sb.append("Fail");
				   sb.append("\n");
				   sb.append("</Result>");
				   sb.append("\n");
				   sb.append("<Description>");
				   sb.append("could not getbyall topic  lessonplan item");
				   sb.append("</Description>");
				   sb.append("\n");
				   sb.append("<Exception>");
				   sb.append(localException);
				   sb.append("</Exception>");
				   sb.append("</Response>");
				   strg=sb.toString();
				   MDTransactionWriter.exceptionlog.info(localException);
				  if (tx!=null)
				   tx.rollback();
				  } finally {
				   stgSession.close(); 
				  }
				  return strg;
				 }
				}

