package com.gwebitsol.core.padagogy;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class CourseDao {
	
	public String addCourse(CoursePojo coursePojo) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		String strg= null;
		StringBuffer sb= new StringBuffer();
		try {
				tx = rdSession.beginTransaction();
				Integer i=(Integer) rdSession.save(coursePojo);
				tx.commit();
				 sb.append("<course>");
				 sb.append("\n");
				 sb.append("<courseid>");
				 sb.append(i);
				 sb.append("</courseid>");
				 sb.append("\n");
				 sb.append("</course>");
				 strg= sb.toString();
					} catch (Exception localException) {
						System.out.println(localException);
 						localException.printStackTrace();
					   sb.append("<Response>");
					   sb.append("\n");
					   sb.append("<Result>");
					   sb.append("\n");
					   sb.append("Fail");
					   sb.append("\n");
					   sb.append("</Result>");
					   sb.append("\n");
					   sb.append("<Description>");
					   sb.append("could not inserted course info");
					   sb.append("</Description>");
					   sb.append("\n");
					   sb.append("<Exception>");
					   sb.append(localException);
					   sb.append("</Exception>");
					   sb.append("</Response>");
					    strg=sb.toString();
					   MDTransactionWriter.exceptionlog.info(localException);
					  if (tx!=null)
					   tx.rollback();
					  } finally {
					   rdSession.close(); 
					  }
					  return strg;
					 }
						
	public String deleteCourse(int courseId,int schoolId,int branchId) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb=new StringBuffer();
		String strg= null;
		try {
				tx = rdSession.beginTransaction();
				/*CoursePojo course=new CoursePojo();				
				course.setCourseId(id);
				rdSession.delete(course);*/
				CoursePojo cp = (CoursePojo)rdSession.get(CoursePojo.class,courseId);
				   rdSession.evict(cp);
				   if(branchId==cp.getBranchId()&&schoolId==cp.getSchoolId())
				   {
				   Query empQuery=rdSession.createSQLQuery("update gbl_sm_tbl_course set isDeleted='y' where courseId='"+courseId+"'");
				   empQuery.executeUpdate();
				   tx.commit();
				   strg="<delete></delete>";
				   sb.append("<courseid>");
				   sb.append("\n");
				   sb.append("<id>");
					sb.append("course item deleted");
					sb.append("</id>");
					sb.append("\n");
					sb.append("</courseid>");
					strg= sb.toString();				
					}else{
						   strg = " course table is not deleted";
						   sb.append("<course>");
						   sb.append("\n");
						   sb.append(strg);
						   sb.append("</course>");
						    String str = sb.toString();
						    return str;
						   }
		}
					catch(Exception localException)
						{
							System.out.println(localException);
	 						localException.printStackTrace();
						   sb.append("<Response>");
						   sb.append("\n");
						   sb.append("<Result>");
						   sb.append("\n");
						   sb.append("Fail");
						   sb.append("\n");
						   sb.append("</Result>");
						   sb.append("\n");
						   sb.append("<Description>");
						   sb.append("could not deleted course item");
						   sb.append("</Description>");
						   sb.append("\n");
						   sb.append("<Exception>");
						   sb.append(localException);
						   sb.append("</Exception>");
						   sb.append("</Response>");
						    strg=sb.toString();
						   MDTransactionWriter.exceptionlog.info(localException);
						  if (tx!=null)
						   tx.rollback();
						  } finally {
						   rdSession.close(); 
						  }
						  return strg;
						 }
	public String updateCourse(CoursePojo coursePojo,int schoolId,int branchId) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb= new StringBuffer();
		String strg= null;
		try {
				tx = rdSession.beginTransaction();
				/*rdSession.update(coursePojo);
				tx.commit();*/
				CoursePojo cp = (CoursePojo) rdSession.get(CoursePojo.class,coursePojo.getCourseId());
				rdSession.evict(cp);
				   if(branchId==cp.getBranchId()&&schoolId==cp.getSchoolId())
				   rdSession.update(coursePojo);  
				   tx.commit();
				sb.append("<course>");
				sb.append("\n");
				sb.append("<courseid>");
				sb.append("course succssfully updated");
				sb.append("</courseid>");
				sb.append("\n");
				sb.append("</course>");
				strg= sb.toString();					   
				} catch (Exception localException) {
					System.out.println(localException);
					localException.printStackTrace();
				   sb.append("<Response>");
				   sb.append("\n");
				   sb.append("<Result>");
				   sb.append("\n");
				   sb.append("Fail");
				   sb.append("\n");
				   sb.append("</Result>");
				   sb.append("\n");
				   sb.append("<Description>");
				   sb.append("could not updated course info");
				   sb.append("</Description>");
				   sb.append("\n");
				   sb.append("<Exception>");
				   sb.append(localException);
				   sb.append("</Exception>");
				   sb.append("</Response>");
				    strg=sb.toString();
				   MDTransactionWriter.exceptionlog.info(localException);
				  if (tx!=null)
				   tx.rollback();
				  } finally {
				   rdSession.close(); 
				  }
				  return strg;
				 }
				
	@SuppressWarnings("rawtypes")
	public String getAllCourses(int PNO, int size,int schoolId,int branchId,int classId,int sectionId,int subjectId,int unitId,int chapterId,int topicId) {
						  String xmlString=null;
						  Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
						  Transaction stgTx=null;
						  StringBuffer sb = new StringBuffer();
						  try
						  {
						   stgTx=stgSession.beginTransaction();
						    int fset = (PNO-1)*size;
						    String filterWhere="";
						    if(classId!=0){									  								    	
						    	filterWhere+=" and sub.ClassId="+classId;						
							if(sectionId!=0){
								filterWhere +=  " and sub.SectionId="+sectionId;
							}
						    }
							if(subjectId!=0){
								filterWhere += " and units.SubjectId="+subjectId;
							}
						    if(unitId!=0){
						    	filterWhere+=" and chapter.UnitId="+unitId;	
						    }
						    if(chapterId!=0){
						    	filterWhere+=" and topic.ChapterId="+chapterId;	
						    }
						    if(topicId!=0){									  								    	
						    	filterWhere+=" and course.TopicId="+topicId;			    	
						    			}
					
						    String gsSql =" SELECT count(*) FROM gbl_sm_tbl_course as course left outer join gbl_sm_tbl_topic as  topic on course.TopicId=topic.TopicId left outer join gbl_sm_tbl_chapter as chapter on topic.ChapterId =chapter.ChapterId left outer join gbl_sm_tbl_units as units on chapter.UnitId=units.UnitId left outer join gbl_sm_tbl_subjects as sub ON  units.SubjectId =sub.SubjectId left outer join gbl_sm_tbl_class as cls on sub.ClassId= cls.ClassId  left outer join gbl_sm_tbl_section as sec on sub.SectionId=sec.SectionId  left outer join gbl_sm_tbl_subject_type as subtype on sub.SubjectTypeId=subtype.SubjectTypeId where (course.isDeleted<>'y' or course.isDeleted is null) and course.schoolId='"+schoolId+"' and course.branchId='"+branchId+"'"+filterWhere+" ";			   
						    Query gsQuery=stgSession.createSQLQuery(gsSql);
						    Object noRecords= gsQuery.uniqueResult();
						    int intNoRecords=0;
							if(noRecords!=null && Integer.parseInt(noRecords.toString())!=0)
							{
								intNoRecords=Integer.parseInt(noRecords.toString());
							}
						    sb.append("<courses>");
						    sb.append("\n");
						    sb.append("<noRecords>"+noRecords+"</noRecords>");
						    sb.append("\n");
						    if(intNoRecords!=0)
							{
						     if (PNO > 0 & size > 0){
						     gsSql="SELECT course.CourseId,sub.ClassId,cls.ClassName, sub.SectionId,sec.SectionName,units.SubjectId,subtype.SubjectName,chapter.UnitId,units.UnitNo,units.UnitName,topic.ChapterId,chapter.ChapterNo,chapter.ChapterName,course.TopicId,topic.TopicName,course.CourseName,course.Duration,course.`Status`,course.Description,course.Remarks,course.CreatedDate,course.ModifiedDate,course.SchoolId,course.BranchId FROM gbl_sm_tbl_course as course left outer join gbl_sm_tbl_topic as  topic on course.TopicId=topic.TopicId left outer join gbl_sm_tbl_chapter as chapter on topic.ChapterId =chapter.ChapterId left outer join gbl_sm_tbl_units as units on chapter.UnitId=units.UnitId left outer join gbl_sm_tbl_subjects as sub ON  units.SubjectId =sub.SubjectId left outer join gbl_sm_tbl_class as cls on sub.ClassId= cls.ClassId  left outer join gbl_sm_tbl_section as sec on sub.SectionId=sec.SectionId  left outer join gbl_sm_tbl_subject_type as subtype on sub.SubjectTypeId=subtype.SubjectTypeId where (course.isDeleted<>'y' or course.isDeleted is null) and course.schoolId='"+schoolId+"' and course.branchId ='"+branchId+"'"+filterWhere+"  "
						     				+ "limit "+size+" offset "+fset;
						     }
						     else {
						      gsSql="SELECT course.CourseId ,sub.ClassId,cls.ClassName, sub.SectionId,sec.SectionName,units.SubjectId,subtype.SubjectName,chapter.UnitId,units.UnitNo,units.UnitName,topic.ChapterId,chapter.ChapterNo,chapter.ChapterName,course.TopicId,topic.TopicName,course.CourseName,course.Duration,course.`Status`,course.Description,course.Remarks,course.CreatedDate,course.ModifiedDate,course.SchoolId,course.BranchId FROM gbl_sm_tbl_course as course left outer join gbl_sm_tbl_topic as  topic on course.TopicId=topic.TopicId left outer join gbl_sm_tbl_chapter as chapter on topic.ChapterId =chapter.ChapterId left outer join gbl_sm_tbl_units as units on chapter.UnitId=units.UnitId left outer join gbl_sm_tbl_subjects as sub ON  units.SubjectId =sub.SubjectId left outer join gbl_sm_tbl_class as cls on sub.ClassId= cls.ClassId  left outer join gbl_sm_tbl_section as sec on sub.SectionId=sec.SectionId  left outer join gbl_sm_tbl_subject_type as subtype on sub.SubjectTypeId=subtype.SubjectTypeId where (course.isDeleted<>'y' or course.isDeleted is null)  and course.schoolId='"+schoolId+"' and course.branchId ='"+branchId+"'"+filterWhere+" ";
						     }
						    gsQuery=stgSession.createSQLQuery(gsSql);
						    List gcList=gsQuery.list();
						    Iterator gsIT=gcList.iterator();
						     while(gsIT.hasNext())
						     {
						      Object[] mdcArr=(Object[])gsIT.next();
						      sb.append("<course>");
						      sb.append("\n");
						      sb.append("<courseId>"+mdcArr[0]+"</courseId>");
						      sb.append("\n");
						      sb.append("<classId>"+mdcArr[1]+"</classId>");
						      sb.append("\n");
						      if((String)mdcArr[2]!=null){
						      sb.append("<className>"+mdcArr[2]+"</className>");
						      }else{
						    	  sb.append("<className></className>");
						      }
						      
						      sb.append("\n");
						      sb.append("<sectionId>"+mdcArr[3]+"</sectionId>");
						      sb.append("\n");
						      sb.append("<sectionName>"+mdcArr[4]+"</sectionName>");
						      sb.append("\n");
						      sb.append("<subjectId>"+mdcArr[5]+"</subjectId>");
						      sb.append("\n");
						      sb.append("<subjectName>"+mdcArr[6]+"</subjectName>");
						      sb.append("\n");
						      sb.append("<unitId>"+mdcArr[7]+"</unitId>");
						      sb.append("\n");
						      sb.append("<unitNo>"+mdcArr[8]+"</unitNo>");
						      sb.append("\n");
						      sb.append("<unitName>"+mdcArr[9]+"</unitName>");
						      sb.append("\n");
						      sb.append("<chapterId>" + mdcArr[10]+ "</chapterId>");
						      sb.append("\n");
						      sb.append("<chapterNo>" + mdcArr[11]+ "</chapterNo>");
						      sb.append("\n");
						      sb.append("<chapterName>" + mdcArr[12] + "</chapterName>");
						      sb.append("\n");
						      sb.append("<topicId>" + mdcArr[13]+ "</topicId>");
						      sb.append("\n");
						      sb.append("<topicName>" + mdcArr[14]+ "</topicName>");
						      sb.append("\n");
						      sb.append("<courseName>" + mdcArr[15] + "</courseName>");
						      sb.append("\n");
						      sb.append("<duration>" + mdcArr[16]+ "</duration>");
						      sb.append("\n");
						      sb.append("<status>" + mdcArr[17] + "</status>");
						      sb.append("\n");
						      sb.append("<description>" +  mdcArr[18]+ "</description>");
						      sb.append("\n");
						      sb.append("<remarks>" + mdcArr[19] + "</remarks>");
						      sb.append("\n");
						      sb.append("<createdDate>" + mdcArr[20] + "</createdDate>");
						      sb.append("\n");
						      sb.append("<modifiedDate>" + mdcArr[21] + "</modifiedDate>");
						      sb.append("\n");
						      sb.append("<schoolId>" + mdcArr[22] + "</schoolId>");
						      sb.append("\n");
						      sb.append("<branchId>" + mdcArr[23] + "</branchId>");
						      sb.append("\n");
						      sb.append("</course>");
						     }  
							}
						    stgTx.commit();
						    sb.append("</courses>");
						    sb.append("\n");

						    xmlString=sb.toString();
						    
						  } 
						  catch(Exception localException)
							{
								System.out.println(localException);
		 						localException.printStackTrace();
							   sb.append("<Response>");
							   sb.append("\n");
							   sb.append("<Result>");
							   sb.append("\n");
							   sb.append("Fail");
							   sb.append("\n");
							   sb.append("</Result>");
							   sb.append("\n");
							   sb.append("<Description>");
							   sb.append("could notgetall course info");
							   sb.append("</Description>");
							   sb.append("\n");
							   sb.append("<Exception>");
							   sb.append(localException);
							   sb.append("</Exception>");
							   sb.append("</Response>");
							   xmlString=sb.toString();
							   MDTransactionWriter.exceptionlog.info(localException);
							  if (stgTx!=null)
								  stgTx.rollback();
							  } finally {
							   stgSession.close(); 
							  }
							  return xmlString;
							 }
	@SuppressWarnings("rawtypes")
	public String getByIdCourse(int courseId,int schoolId,int branchId) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb= new StringBuffer();
		String strg= null;
						
		try {
				tx = rdSession.beginTransaction();
				Query query=rdSession.createSQLQuery("SELECT course.CourseId,sub.ClassId,cls.ClassName, sub.SectionId,sec.SectionName,units.SubjectId,subtype.SubjectName,chapter.UnitId,units.UnitNo,units.UnitName,topic.ChapterId,chapter.ChapterNo,chapter.ChapterName,course.TopicId,topic.TopicName,course.CourseName,course.Duration,course.`Status`,course.Description,course.Remarks,course.CreatedDate,course.ModifiedDate,course.SchoolId,course.BranchId FROM gbl_sm_tbl_course as course left outer join gbl_sm_tbl_topic as  topic on course.TopicId=topic.TopicId left outer join gbl_sm_tbl_chapter as chapter on topic.ChapterId =chapter.ChapterId left outer join gbl_sm_tbl_units as units on chapter.UnitId=units.UnitId left outer join gbl_sm_tbl_subjects as sub ON  units.SubjectId =sub.SubjectId left outer join gbl_sm_tbl_class as cls on sub.ClassId= cls.ClassId  left outer join gbl_sm_tbl_section as sec on sub.SectionId=sec.SectionId  left outer join gbl_sm_tbl_subject_type as subtype on sub.SubjectTypeId=subtype.SubjectTypeId where (course.isDeleted<>'y' or course.isDeleted is null) and course.CourseId='"+courseId+"' and course.schoolId='"+schoolId+"' and course.branchId ='"+branchId+"' ");
			    List gcList=query.list();
			    Iterator gsIT=gcList.iterator();
			     while(gsIT.hasNext())
			     {
			      Object[] mdcArr=(Object[])gsIT.next();
			  
			      sb.append("<course>");
			      sb.append("\n");
			      sb.append("<courseId>"+mdcArr[0]+"</courseId>");
			      sb.append("\n");
			      sb.append("<classId>"+mdcArr[1]+"</classId>");
			      sb.append("\n");
			      sb.append("<className>"+mdcArr[2]+"</className>");
			      sb.append("\n");
			      sb.append("<sectionId>"+mdcArr[3]+"</sectionId>");
			      sb.append("\n");
			      sb.append("<sectionName>"+mdcArr[4]+"</sectionName>");
			      sb.append("\n");
			      sb.append("<subjectId>"+mdcArr[5]+"</subjectId>");
			      sb.append("\n");
			      sb.append("<subjectName>"+mdcArr[6]+"</subjectName>");
			      sb.append("\n");
			      sb.append("<unitId>"+mdcArr[7]+"</unitId>");
			      sb.append("\n");
			      sb.append("<unitNo>"+mdcArr[8]+"</unitNo>");
			      sb.append("\n");
			      sb.append("<unitName>"+mdcArr[9]+"</unitName>");
			      sb.append("\n");
			      sb.append("<chapterId>" + mdcArr[10]+ "</chapterId>");
			      sb.append("\n");
			      sb.append("<chapterNo>" + mdcArr[11]+ "</chapterNo>");
			      sb.append("\n");
			      sb.append("<chapterName>" + mdcArr[12] + "</chapterName>");
			      sb.append("\n");
			      sb.append("<topicId>" + mdcArr[13]+ "</topicId>");
			      sb.append("\n");
			      sb.append("<topicName>" + mdcArr[14]+ "</topicName>");
			      sb.append("\n");
			      sb.append("<courseName>" + mdcArr[15] + "</courseName>");
			      sb.append("\n");
			      sb.append("<duration>" + mdcArr[16]+ "</duration>");
			      sb.append("\n");
			      sb.append("<status>" + mdcArr[17] + "</status>");
			      sb.append("\n");
			      sb.append("<description>" +  mdcArr[18]+ "</description>");
			      sb.append("\n");
			      sb.append("<remarks>" + mdcArr[19] + "</remarks>");
			      sb.append("\n");
			      sb.append("<createdDate>" + mdcArr[20] + "</createdDate>");
			      sb.append("\n");
			      sb.append("<modifiedDate>" + mdcArr[21] + "</modifiedDate>");
			      sb.append("\n");
			      sb.append("<schoolId>" + mdcArr[22] + "</schoolId>");
			      sb.append("\n");
			      sb.append("<branchId>" + mdcArr[23] + "</branchId>");
			      sb.append("\n");
			      sb.append("</course>");
					String str= sb.toString();
					return str;
			}
									
						} 	catch (Exception localException) {
							System.out.println(localException);
	 						localException.printStackTrace();
						   sb.append("<Response>");
						   sb.append("\n");
						   sb.append("<Result>");
						   sb.append("\n");
						   sb.append("Fail");
						   sb.append("\n");
						   sb.append("</Result>");
						   sb.append("\n");
						   sb.append("<Description>");
						   sb.append("could not getby course item");
						   sb.append("</Description>");
						   sb.append("\n");
						   sb.append("<Exception>");
						   sb.append(localException);
						   sb.append("</Exception>");
						   sb.append("</Response>");						  
						   strg=sb.toString();
						   MDTransactionWriter.exceptionlog.info(localException);
						  if (tx!=null)
						   tx.rollback();
						  } finally {
						   rdSession.close(); 
						  }
						  return strg;
						 }
	
	
	public String addChapter(ChapterPojo chapterPojo) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
			String strg= null;
			StringBuffer sb= new StringBuffer();
			try {
					tx = rdSession.beginTransaction();
					Integer i=(Integer) rdSession.save(chapterPojo);
					System.out.println(i);
					tx.commit();
					sb.append("<chapter>");
					 sb.append("\n");
					 sb.append("<chapterid>");
					 sb.append(i);
					 sb.append("</chapterid>");
					 sb.append("\n");
					 sb.append("</chapter>");
					 strg= sb.toString();						
				} catch (Exception localException) {
					System.out.println(localException);
			 		localException.printStackTrace();
					sb.append("<Response>");
					 sb.append("\n");
					   sb.append("<Result>");
					   sb.append("\n");
					   sb.append("Fail");
					   sb.append("\n");
					   sb.append("</Result>");
					   sb.append("\n");
					   sb.append("<Description>");
					   sb.append("could not inserted chapter info");
					   sb.append("</Description>");
					   sb.append("\n");
					   sb.append("<Exception>");
					   sb.append(localException);
					   sb.append("</Exception>");
					   sb.append("</Response>");
					    strg=sb.toString();
					   MDTransactionWriter.exceptionlog.info(localException);
					  if (tx!=null)
					   tx.rollback();
					  } finally {
					   rdSession.close(); 
					  }
					  return strg;
					 }			  
							
	public String deleteChapter(int chapterId,int schoolId,int branchId) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
			StringBuffer sb=new StringBuffer();
			String strg= null;
			try {
					tx = rdSession.beginTransaction();
					/*ChapterPojo chapter=new ChapterPojo();				
					chapter.setChapterId(id);
					rdSession.delete(chapter);*/
					ChapterPojo chapter = (ChapterPojo) rdSession.get(ChapterPojo.class,chapterId);					   
					   rdSession.evict(chapter);
					   if(branchId==chapter.getBranchId()&&schoolId==chapter.getSchoolId())
					   {
					   Query empQuery=rdSession.createSQLQuery("update gbl_sm_tbl_chapter set isDeleted='y' where chapterId='"+chapterId+"'");
					   empQuery.executeUpdate();
					   tx.commit();
					sb.append("<chapterid>");
				    sb.append("\n");
				    sb.append("<id>");
					sb.append("\n");
					sb.append("chapter item deleted");
					sb.append("</id>");
					sb.append("\n");
					sb.append("</chapterid>");
					strg= sb.toString();				
				}else{
					   strg = " chapter is not deleted";
					   sb.append("<chapter>");
					   sb.append("\n");
					   sb.append(strg);
					   sb.append("</chapter>");
					    String str = sb.toString();
					    return str;
					   }
			}
					catch(Exception localException){
							System.out.println(localException);
							localException.printStackTrace();
						   sb.append("<Response>");
						   sb.append("\n");
						   sb.append("<Result>");
						   sb.append("\n");
						   sb.append("Fail");
						   sb.append("\n");
						   sb.append("</Result>");
						   sb.append("\n");
						   sb.append("<Description>");
						   sb.append("could not deleted chapter item");
						   sb.append("</Description>");
						   sb.append("\n");
						   sb.append("<Exception>");
						   sb.append(localException);
						   sb.append("</Exception>");
						   sb.append("</Response>");
						    strg=sb.toString();
						   MDTransactionWriter.exceptionlog.info(localException);
						  if (tx!=null)
						   tx.rollback();
						  } finally {
						   rdSession.close(); 
						  }
						  return strg;
						 }
					
	public String updateChapter(ChapterPojo chapterPojo,int schoolId,int branchId) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
			StringBuffer sb= new StringBuffer();
			String strg= null;
			try {
					tx = rdSession.beginTransaction();
					/*rdSession.update(chapterPojo);
					tx.commit();*/
					ChapterPojo cp = (ChapterPojo) rdSession.get(ChapterPojo.class,chapterPojo.getChapterId());
					rdSession.evict(cp);
					   if(branchId==cp.getBranchId()&&schoolId==cp.getSchoolId())
					   rdSession.update(chapterPojo);	     
					   tx.commit();
					sb.append("<chapter>");
					sb.append("\n");
					sb.append("<chapterid>");
					sb.append("chaptersuccssfully updated");
					sb.append("</chapterid>");
					sb.append("\n");
					sb.append("</chapter>");
					strg= sb.toString();		
					} 	catch (Exception localException) {
								System.out.println(localException);
								localException.printStackTrace();
								   sb.append("<Response>");
								   sb.append("\n");
								   sb.append("<Result>");
								   sb.append("\n");
								   sb.append("Fail");
								   sb.append("\n");
								   sb.append("</Result>");
								   sb.append("\n");
								   sb.append("<Description>");
								   sb.append("could not updated chapter item");
								   sb.append("</Description>");
								   sb.append("\n");
								   sb.append("<Exception>");
								   sb.append(localException);
								   sb.append("</Exception>");
								   sb.append("</Response>");
								    strg=sb.toString();
								   MDTransactionWriter.exceptionlog.info(localException);
								  if (tx!=null)
								   tx.rollback();
								  } finally {
								   rdSession.close(); 
								  }
								  return strg;
				}


		@SuppressWarnings("rawtypes")
		public String getAllChapters(int PNO, int size,int schoolId,int branchId,int classId,int sectionId,int subjectId,int unitId) {
				  String xmlString=null;
				  Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
				  Transaction stgTx=null;
				  StringBuffer sb = new StringBuffer();
				  try
				  {
				   stgTx=stgSession.beginTransaction();
				    int fset = (PNO-1)*size;
				    String filterWhere="";
				    if(classId!=0){									  								    	
				    	filterWhere+=" and sub.ClassId="+classId;					    
					if(sectionId!=0){
						filterWhere +=  " and sub.SectionId="+sectionId;
					}
				    }
					if(subjectId!=0){
						filterWhere += " and units.SubjectId="+subjectId;
					}
				    if(unitId!=0){
				    	filterWhere+=" and chapter.UnitId="+unitId;			    	
				    	}		 
				    String gsSql ="select count(*) FROM gbl_sm_tbl_chapter  chapter left outer join gbl_sm_tbl_units as units on chapter.UnitId=units.UnitId left outer join gbl_sm_tbl_subjects as sub ON  units.SubjectId =sub.SubjectId left outer join gbl_sm_tbl_class as cls on sub.ClassId= cls.ClassId  left outer join gbl_sm_tbl_section as sec  on sub.SectionId=sec.SectionId  left outer join gbl_sm_tbl_subject_type as subtype on sub.SubjectTypeId=subtype.SubjectTypeId where  (chapter.isDeleted<>'y' or chapter.isDeleted is null)  and chapter.schoolId='"+schoolId+"' and chapter.branchId='"+branchId+"'"+filterWhere+" ";				    
				    Query gsQuery=stgSession.createSQLQuery(gsSql);
				    Object noRecords= gsQuery.uniqueResult();
				    int intNoRecords=0;
					if(noRecords!=null && Integer.parseInt(noRecords.toString())!=0)
					{
						intNoRecords=Integer.parseInt(noRecords.toString());
					}
				    sb.append("<chapters>");
				    sb.append("\n");
				    sb.append("<noRecords>"+noRecords+"</noRecords>");
				    sb.append("\n");
				    if(intNoRecords!=0)
					{
				     if (PNO > 0 & size > 0){
				     gsSql="SELECT chapter.ChapterId,sub.ClassId,cls.ClassName, sub.SectionId,sec.SectionName,sub.SubjectId,subtype.SubjectName,chapter.UnitId,units.UnitNo,units.UnitName,chapter.ChapterNo,chapter.ChapterName,chapter.`Status`,chapter.Description,chapter.SchoolId,chapter.BranchId  FROM gbl_sm_tbl_chapter  chapter left outer join gbl_sm_tbl_units as units on chapter.UnitId=units.UnitId left outer join gbl_sm_tbl_subjects as sub ON  units.SubjectId =sub.SubjectId left outer join gbl_sm_tbl_class as cls on sub.ClassId= cls.ClassId  left outer join gbl_sm_tbl_section as sec  on sub.SectionId=sec.SectionId  left outer join gbl_sm_tbl_subject_type as subtype on sub.SubjectTypeId=subtype.SubjectTypeId where  (chapter.isDeleted<>'y' or chapter.isDeleted is null) and chapter.schoolId='"+schoolId+"' and chapter.branchId='"+branchId+"'"+filterWhere+" limit "+size+" offset "+fset;
				     }
				     else {
				      gsSql="SELECT chapter.ChapterId,sub.ClassId,cls.ClassName, sub.SectionId,sec.SectionName,sub.SubjectId,subtype.SubjectName,chapter.UnitId,units.UnitNo,units.UnitName,chapter.ChapterNo,chapter.ChapterName,chapter.`Status`,chapter.Description,chapter.SchoolId,chapter.BranchId  FROM gbl_sm_tbl_chapter  chapter left outer join gbl_sm_tbl_units as units on chapter.UnitId=units.UnitId left outer join gbl_sm_tbl_subjects as sub ON  units.SubjectId =sub.SubjectId left outer join gbl_sm_tbl_class as cls on sub.ClassId= cls.ClassId  left outer join gbl_sm_tbl_section as sec  on sub.SectionId=sec.SectionId  left outer join gbl_sm_tbl_subject_type as subtype on sub.SubjectTypeId=subtype.SubjectTypeId where  (chapter.isDeleted<>'y' or chapter.isDeleted is null)  and chapter.schoolId='"+schoolId+"' and chapter.branchId='"+branchId+"'"+filterWhere+"";
				     } 				   
				    gsQuery=stgSession.createSQLQuery(gsSql);
					List gcList=gsQuery.list();
				    Iterator gsIT=gcList.iterator();
				     while(gsIT.hasNext())
				     {
				      Object[] mdcArr=(Object[])gsIT.next();
				      sb.append("<chapter>");
				      sb.append("\n");
				      sb.append("<chapterId>"+mdcArr[0]+"</chapterId>");
				      sb.append("\n");
				      sb.append("<ClassId>"+mdcArr[1]+"</ClassId>");
				      sb.append("\n");
				      sb.append("<ClassName>"+mdcArr[2]+"</ClassName>");
				      sb.append("\n");
				      sb.append("<SectionId>"+mdcArr[3]+"</SectionId>");
				      sb.append("\n");
				      sb.append("<SectionName>"+mdcArr[4]+"</SectionName>");
				      sb.append("\n");
				      sb.append("<subjectId>"+mdcArr[5]+"</subjectId>");
				      sb.append("\n");
				      sb.append("<subjectName>"+mdcArr[6]+"</subjectName>");
				      sb.append("\n");
				      sb.append("<unitId>" + mdcArr[7]+ "</unitId>");
				      sb.append("\n");
				      sb.append("<unitNo>" + mdcArr[8]+ "</unitNo>");
				      sb.append("\n");
				      sb.append("<unitName>" + mdcArr[9] + "</unitName>");
				      sb.append("\n");
				      sb.append("<chapterNo>" + mdcArr[10]+ "</chapterNo>");
				      sb.append("\n");
				      sb.append("<chapterName>" + mdcArr[11] + "</chapterName>");
				      sb.append("\n");
				      sb.append("<status>" +  mdcArr[12]+ "</status>");
				      sb.append("\n");
				      sb.append("<description>" + mdcArr[13] + "</description>");
				      sb.append("\n");
				      sb.append("<schoolId>" + mdcArr[14] + "</schoolId>");
				      sb.append("\n");
				      sb.append("<branchId>" + mdcArr[15] + "</branchId>");
				      sb.append("\n");
				      sb.append("</chapter>");
				     }
					}
				    stgTx.commit();
				    sb.append("</chapters>");
				    sb.append("\n");

				    xmlString=sb.toString();  
				  } 
							catch(Exception localException)
							{
								System.out.println(localException);
								localException.printStackTrace();
						   sb.append("<Response>");
						   sb.append("\n");
						   sb.append("<Result>");
						   sb.append("\n");
						   sb.append("Fail");
						   sb.append("\n");
						   sb.append("</Result>");
						   sb.append("\n");
						   sb.append("<Description>");
						   sb.append("could not getall chapter items");
						   sb.append("</Description>");
						   sb.append("\n");
						   sb.append("<Exception>");
						   sb.append(localException);
						   sb.append("</Exception>");
						   sb.append("</Response>");
						   xmlString=sb.toString();
						   MDTransactionWriter.exceptionlog.info(localException);
						  if (stgTx!=null)
							  stgTx.rollback();
						  } finally {
						   stgSession.close(); 
						  }
						  return xmlString;
						 }

	@SuppressWarnings("rawtypes")
	public String getByIdChapter(int chapterId,int schoolId,int branchId) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
			StringBuffer sb= new StringBuffer();
			String strg= null;			
			try {
				tx = rdSession.beginTransaction();
				Query query=rdSession.createSQLQuery("SELECT chapter.ChapterId,sub.ClassId,cls.ClassName, sub.SectionId,sec.SectionName,sub.SubjectId,subtype.SubjectName,chapter.UnitId,units.UnitNo,units.UnitName,chapter.ChapterNo,chapter.ChapterName,chapter.`Status`,chapter.Description,chapter.SchoolId,chapter.BranchId  FROM gbl_sm_tbl_chapter  chapter left outer join gbl_sm_tbl_units as units on chapter.UnitId=units.UnitId left outer join gbl_sm_tbl_subjects as sub ON  units.SubjectId =sub.SubjectId left outer join gbl_sm_tbl_class as cls on sub.ClassId= cls.ClassId  left outer join gbl_sm_tbl_section as sec  on sub.SectionId=sec.SectionId  left outer join gbl_sm_tbl_subject_type as subtype on sub.SubjectTypeId=subtype.SubjectTypeId where  (chapter.isDeleted<>'y' or chapter.isDeleted is null)  and chapter.ChapterId='"+chapterId+"' and chapter.schoolId='"+schoolId+"' and chapter.branchId='"+branchId+"'");
			    List gcList=query.list();
				Iterator gsIT=gcList.iterator();
			     while(gsIT.hasNext())
			     {
			      Object[] mdcArr=(Object[])gsIT.next();
			  
			      sb.append("<chapter>");
			      sb.append("\n");
			      sb.append("<chapterId>"+mdcArr[0]+"</chapterId>");
			      sb.append("\n");
			      sb.append("<ClassId>"+mdcArr[1]+"</ClassId>");
			      sb.append("\n");
			      sb.append("<ClassName>"+mdcArr[2]+"</ClassName>");
			      sb.append("\n");
			      sb.append("<SectionId>"+mdcArr[3]+"</SectionId>");
			      sb.append("\n");
			      sb.append("<SectionName>"+mdcArr[4]+"</SectionName>");
			      sb.append("\n");
			      sb.append("<subjectId>"+mdcArr[5]+"</subjectId>");
			      sb.append("\n");
			      sb.append("<subjectName>"+mdcArr[6]+"</subjectName>");
			      sb.append("\n");
			      sb.append("<unitId>" + mdcArr[7]+ "</unitId>");
			      sb.append("\n");
			      sb.append("<unitNo>" + mdcArr[8]+ "</unitNo>");
			      sb.append("\n");
			      sb.append("<unitName>" + mdcArr[9] + "</unitName>");
			      sb.append("\n");
			      sb.append("<chapterNo>" + mdcArr[10]+ "</chapterNo>");
			      sb.append("\n");
			      sb.append("<chapterName>" + mdcArr[11] + "</chapterName>");
			      sb.append("\n");
			      sb.append("<status>" +  mdcArr[12]+ "</status>");
			      sb.append("\n");
			      sb.append("<description>" + mdcArr[13] + "</description>");
			      sb.append("\n");
			      sb.append("<schoolId>" + mdcArr[14] + "</schoolId>");
			      sb.append("\n");
			      sb.append("<branchId>" + mdcArr[15] + "</branchId>");
			      sb.append("\n");
			      sb.append("</chapter>");
					String str= sb.toString();
					return str;
			}
							} 	catch (Exception localException) {
								System.out.println(localException);
								localException.printStackTrace();
						   sb.append("<Response>");
						   sb.append("\n");
						   sb.append("<Result>");
						   sb.append("\n");
						   sb.append("Fail");
						   sb.append("\n");
						   sb.append("</Result>");
						   sb.append("\n");
						   sb.append("<Description>");
						   sb.append("could not getby chapter item");
						   sb.append("</Description>");
						   sb.append("\n");
						   sb.append("<Exception>");
						   sb.append(localException);
						   sb.append("</Exception>");
						   sb.append("</Response>");
						   sb.append("</chapterid>");
						   sb.append("</Chapter>");
						    strg=sb.toString();
						   MDTransactionWriter.exceptionlog.info(localException);
						  if (tx!=null)
						   tx.rollback();
						  } finally {
						   rdSession.close(); 
						  }
						  return strg;
						 }


	public String addUnit(UnitsPojo unitsPojo) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		String strg= null;
		 StringBuffer sb= new StringBuffer();
		 try {
				tx = rdSession.beginTransaction();
				Integer i=(Integer) rdSession.save(unitsPojo);		 
				System.out.println(i);
				tx.commit();
				sb.append("<units>");
				  sb.append("\n");
				  sb.append("<unitid>");
				  sb.append(i);
				  sb.append("</unitid>");
				  sb.append("\n");
				  sb.append("</units>");			  
				  strg= sb.toString();
				} catch (Exception localException) {
						System.out.println(localException);
						localException.printStackTrace();
					   sb.append("<Response>");
					   sb.append("\n");
					   sb.append("<Result>");
					   sb.append("\n");
					   sb.append("Fail");
					   sb.append("\n");
					   sb.append("</Result>");
					   sb.append("\n");
					   sb.append("<Description>");
					   sb.append("could not inserted unit info");
					   sb.append("</Description>");
					   sb.append("\n");
					   sb.append("<Exception>");
					   sb.append(localException);
					   sb.append("</Exception>");
					   sb.append("</Response>");
					    strg=sb.toString();
					   MDTransactionWriter.exceptionlog.info(localException);
					  if (tx!=null)
					   tx.rollback();
					  } finally {
					   rdSession.close(); 
					  }
					  return strg;
					 }
	public String deleteUnit(int unitId,int schoolId,int branchId) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb=new StringBuffer();
		String strg= null;
		try {
				tx = rdSession.beginTransaction();
				/*UnitsPojo up=new UnitsPojo();
				up.setUnitId(id);
				rdSession.delete(up);
				tx.commit();*/
				UnitsPojo up = (UnitsPojo) rdSession.get(UnitsPojo.class,unitId);					   
				   rdSession.evict(up);
				   if(branchId==up.getBranchId()&&schoolId==up.getSchoolId())
				   {
				   Query empQuery=rdSession.createSQLQuery("update gbl_sm_tbl_units set isDeleted='y' where unitId='"+unitId+"'");
				   empQuery.executeUpdate();
				   tx.commit();
				 sb.append("<unitid>");
				   sb.append("\n");
				    sb.append("<id>");
					sb.append("unit item deleted");
					sb.append("</id>");
					sb.append("\n");
					sb.append("</unitid>");
					 strg= sb.toString();		
		}else{
			   strg = " unit is not deleted";
			   sb.append("<unit>");
			   sb.append("\n");
			   sb.append(strg);
			   sb.append("</unit>");
			    String str = sb.toString();
			    return str;
			   }
		}
		catch(Exception localException){
			System.out.println(localException);
			localException.printStackTrace();
	   sb.append("<Response>");
	   sb.append("\n");
	   sb.append("<Result>");
	   sb.append("\n");
	   sb.append("Fail");
	   sb.append("\n");
	   sb.append("</Result>");
	   sb.append("\n");
	   sb.append("<Description>");
	   sb.append("could not delete unit item");
	   sb.append("</Description>");
	   sb.append("\n");
	   sb.append("<Exception>");
	   sb.append(localException);
	   sb.append("</Exception>");
	   sb.append("</Response>");
	    strg=sb.toString();
	   MDTransactionWriter.exceptionlog.info(localException);
	  if (tx!=null)
	   tx.rollback();
	  } finally {
	   rdSession.close(); 
	  }
	  return strg;
	 }

	public String updateUnit(UnitsPojo unitsPojo,int schoolId,int branchId) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb= new StringBuffer();
		String strg= null;
			try {
					tx = rdSession.beginTransaction();
					/*rdSession.update(unitsPojo);
					  tx.commit();*/
					UnitsPojo up = (UnitsPojo) rdSession.get(UnitsPojo.class,unitsPojo.getUnitId());
					rdSession.evict(up);
					   if(branchId==up.getBranchId()&&schoolId==up.getSchoolId())
					   rdSession.update(unitsPojo);   
					   tx.commit();
					    sb.append("<units>");
					    sb.append("\n");
					    sb.append("<id>");
						sb.append("\n");
						sb.append("units succssfully updated");
						sb.append("</id>");
						sb.append("\n");
						sb.append("</units>");
						strg=sb.toString();
				} 	catch (Exception localException) {
					System.out.println(localException);
					localException.printStackTrace();
			   sb.append("<Response>");
			   sb.append("\n");
			   sb.append("<Result>");
			   sb.append("\n");
			   sb.append("Fail");
			   sb.append("\n");
			   sb.append("</Result>");
			   sb.append("\n");
			   sb.append("<Description>");
			   sb.append("could not update unit item");
			   sb.append("</Description>");
			   sb.append("\n");
			   sb.append("<Exception>");
			   sb.append(localException);
			   sb.append("</Exception>");
			   sb.append("</Response>");
			    strg=sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (tx!=null)
			   tx.rollback();
			  } finally {
			   rdSession.close(); 
			  }
			  return strg;
			 }
	
	@SuppressWarnings("rawtypes")
	public String getAllUnits(int PNO, int size,int schoolId,int branchId,int classId,int sectionId,int subjectId) {
				  String xmlString=null;
				  Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
				  Transaction stgTx=null;
				  StringBuffer sb = new StringBuffer();
				  try
				  {
				   stgTx=stgSession.beginTransaction();
				    int fset = (PNO-1)*size;
				    String filterWhere="";
				    if(classId!=0){									  								    	
				    	filterWhere+=" and sub.ClassId="+classId;	
				    
					if(sectionId!=0){
						filterWhere +=  " and sub.SectionId="+sectionId;
					}
				    }
					if(subjectId!=0){
						filterWhere += " and sub.SubjectId="+subjectId;
						}
					String  gsSql ="select count(*) from gbl_sm_tbl_units as units left outer join  gbl_sm_tbl_subjects as sub on units.SubjectId=sub.SubjectId where  (units.isDeleted<>'y' or units.isDeleted is null)  and units.schoolId='"+schoolId+"' and units.branchId='"+branchId+"'"+filterWhere+" ";				   
				    Query gsQuery=stgSession.createSQLQuery(gsSql);
				    Object noRecords= gsQuery.uniqueResult();
				    int intNoRecords=0;
					if(noRecords!=null && Integer.parseInt(noRecords.toString())!=0)
					{
						intNoRecords=Integer.parseInt(noRecords.toString());
					}
				    sb.append("<units>");
				    sb.append("\n");
				    sb.append("<noRecords>"+noRecords+"</noRecords>");
				    sb.append("\n");
				    if(intNoRecords!=0)
					{
				     if (PNO > 0 & size > 0){
				     gsSql=" SELECT units.UnitId,units.SubjectId,sub.SubjectTypeId, subtype.SubjectName ,sub.ClassId,cls.ClassName,sub.SectionId,sec.SectionName,units.UnitNo,units.UnitName,units.`status`,units.Description,units.SchoolId,units.BranchId FROM gbl_sm_tbl_units as units left outer join gbl_sm_tbl_subjects as sub ON  units.SubjectId =sub.SubjectId left outer join gbl_sm_tbl_class as cls on sub.ClassId= cls.ClassId  left outer join gbl_sm_tbl_section as sec  on sub.SectionId=sec.SectionId  left outer join gbl_sm_tbl_subject_type as subtype on sub.SubjectTypeId=subtype.SubjectTypeId where (units.isDeleted<>'y' or units.isDeleted is null)  and units.schoolId='"+schoolId+"' and units.branchId='"+branchId+"'"+filterWhere+"  limit "+size+" offset "+fset;
				     }
				     else {
				      gsSql=" SELECT units.UnitId,units.SubjectId,sub.SubjectTypeId, subtype.SubjectName ,sub.ClassId,cls.ClassName,sub.SectionId,sec.SectionName,units.UnitNo,units.UnitName,units.`status`,units.Description,units.SchoolId,units.BranchId FROM gbl_sm_tbl_units as units left outer join gbl_sm_tbl_subjects as sub ON  units.SubjectId =sub.SubjectId left outer join gbl_sm_tbl_class as cls on sub.ClassId= cls.ClassId  left outer join gbl_sm_tbl_section as sec  on sub.SectionId=sec.SectionId  left outer join gbl_sm_tbl_subject_type as subtype on sub.SubjectTypeId=subtype.SubjectTypeId where (units.isDeleted<>'y' or units.isDeleted is null) and units.schoolId='"+schoolId+"' and units.branchId='"+branchId+"'"+filterWhere+" ";
				     }  
				    
				    gsQuery=stgSession.createSQLQuery(gsSql);
				    List gcList=gsQuery.list();
				    Iterator gsIT=gcList.iterator();
				     while(gsIT.hasNext())
				     {
				      Object[] mdcArr=(Object[])gsIT.next();
				      sb.append("<unit>");
				      sb.append("\n");
				      sb.append("<unitId>"+mdcArr[0]+"</unitId>");
				      sb.append("\n");
				      sb.append("<SubjectId>" + mdcArr[1]+ "</SubjectId>");
				      sb.append("\n");
				      sb.append("<SubjectTypeId>" + mdcArr[2]+ "</SubjectTypeId>");
				      sb.append("\n");
				      sb.append("<subjectName>" + mdcArr[3]+ "</subjectName>");
				      sb.append("\n");
				      sb.append("<classId>" + mdcArr[4]+ "</classId>");
				      sb.append("\n");
				      sb.append("<className>" + mdcArr[5]+ "</className>");
				      sb.append("\n");
				      sb.append("<sectionId>" + mdcArr[6]+ "</sectionId>");
				      sb.append("\n");
				      sb.append("<sectionName>" + mdcArr[7]+ "</sectionName>");
				      sb.append("\n");
				      sb.append("<unitNo>" + mdcArr[8] + "</unitNo>");
				      sb.append("\n");
				      sb.append("<unitName>" + mdcArr[9]+ "</unitName>");
				      sb.append("\n");
				      sb.append("<status>" + mdcArr[10] + "</status>");
				      sb.append("\n");
				      sb.append("<description>" +  mdcArr[11]+ "</description>");
				      sb.append("\n");
				      sb.append("<schoolId>" + mdcArr[12] + "</schoolId>");
				      sb.append("\n");
				      sb.append("<branchId>" + mdcArr[13] + "</branchId>");
				      sb.append("\n");
				      sb.append("</unit>");
				     }
					}
				    stgTx.commit();
				    sb.append("</units>");
				    sb.append("\n");

				    xmlString=sb.toString();
				   }
		catch(Exception localException)
		{
			System.out.println(localException);
			localException.printStackTrace();
	   sb.append("<Response>");
	   sb.append("\n");
	   sb.append("<Result>");
	   sb.append("\n");
	   sb.append("Fail");
	   sb.append("\n");
	   sb.append("</Result>");
	   sb.append("\n");
	   sb.append("<Description>");
	   sb.append("could not getall unit  items");
	   sb.append("</Description>");
	   sb.append("\n");
	   sb.append("<Exception>");
	   sb.append(localException);
	   sb.append("</Exception>");
	   sb.append("</Response>");
	   xmlString=sb.toString();
	   MDTransactionWriter.exceptionlog.info(localException);
	  if (stgTx!=null)
		  stgTx.rollback();
	  } finally {
	   stgSession.close(); 
	  }
	  return xmlString;
	 }

	@SuppressWarnings("rawtypes")
	public String getByIdUnit(int unitId,int schoolId,int branchId) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb= new StringBuffer();
		String strg= null;
		try {
			tx = rdSession.beginTransaction();
			Query query=rdSession.createSQLQuery("SELECT units.UnitId,units.SubjectId,sub.SubjectTypeId, subtype.SubjectName ,sub.ClassId,cls.ClassName,sub.SectionId,sec.SectionName,units.UnitNo,units.UnitName,units.`status`,units.Description,units.SchoolId,units.BranchId FROM gbl_sm_tbl_units as units left outer join gbl_sm_tbl_subjects as sub ON  units.SubjectId =sub.SubjectId left outer join gbl_sm_tbl_class as cls on sub.ClassId= cls.ClassId  left outer join gbl_sm_tbl_section as sec  on sub.SectionId=sec.SectionId  left outer join gbl_sm_tbl_subject_type as subtype on sub.SubjectTypeId=subtype.SubjectTypeId where (units.isDeleted<>'y' or units.isDeleted is null) and "
				     		+ " units.UnitId='"+unitId+"' and units.schoolId='"+schoolId+"' and units.branchId='"+branchId+"'");
		    List gcList=query.list();
		    Iterator gsIT=gcList.iterator();
		     while(gsIT.hasNext())
		     {
		      Object[] mdcArr=(Object[])gsIT.next();
		  
		      sb.append("<unit>");
		      sb.append("\n");
		      sb.append("<unitId>"+mdcArr[0]+"</unitId>");
		      sb.append("\n");
		      sb.append("<SubjectId>" + mdcArr[1]+ "</SubjectId>");
		      sb.append("\n");
		      sb.append("<SubjectTypeId>" + mdcArr[2]+ "</SubjectTypeId>");
		      sb.append("\n");
		      sb.append("<subjectName>" + mdcArr[3]+ "</subjectName>");
		      sb.append("\n");
		      sb.append("<classId>" + mdcArr[4]+ "</classId>");
		      sb.append("\n");
		      sb.append("<className>" + mdcArr[5]+ "</className>");
		      sb.append("\n");
		      sb.append("<sectionId>" + mdcArr[6]+ "</sectionId>");
		      sb.append("\n");
		      sb.append("<sectionName>" + mdcArr[7]+ "</sectionName>");
		      sb.append("\n");
		      sb.append("<unitNo>" + mdcArr[8] + "</unitNo>");
		      sb.append("\n");
		      sb.append("<unitName>" + mdcArr[9]+ "</unitName>");
		      sb.append("\n");
		      sb.append("<status>" + mdcArr[10] + "</status>");
		      sb.append("\n");
		      sb.append("<description>" +  mdcArr[11]+ "</description>");
		      sb.append("\n");
		      sb.append("<schoolId>" + mdcArr[12] + "</schoolId>");
		      sb.append("\n");
		      sb.append("<branchId>" + mdcArr[13] + "</branchId>");
		      sb.append("\n");
		      sb.append("</unit>");
				String str= sb.toString();
				return str;
		}
			} 	catch (Exception localException) {
				System.out.println(localException);
				localException.printStackTrace();
		   sb.append("<Response>");
		   sb.append("\n");
		   sb.append("<Result>");
		   sb.append("\n");
		   sb.append("Fail");
		   sb.append("\n");
		   sb.append("</Result>");
		   sb.append("\n");
		   sb.append("<Description>");
		   sb.append("could not getby unit item");
		   sb.append("</Description>");
		   sb.append("\n");
		   sb.append("<Exception>");
		   sb.append(localException);
		   sb.append("</Exception>");
		   sb.append("</Response>");
		   sb.append("</unitId>");
		   sb.append("</units>");
		    strg=sb.toString();
		   MDTransactionWriter.exceptionlog.info(localException);
		  if (tx!=null)
		   tx.rollback();
		  } finally {
		   rdSession.close(); 
		  }
		  return strg;
		 }

	public String addTopic(TopicPojo topicPojo) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		String strg= null;
		 StringBuffer sb= new StringBuffer();
		 try {
				tx = rdSession.beginTransaction();
				Integer i=(Integer) rdSession.save(topicPojo);		 
				System.out.println(i);
				tx.commit();
				 sb.append("<topic>");
				  sb.append("\n");
				  sb.append("<id>");
				  sb.append(i);
				  sb.append("</id>");
				  sb.append("\n");
				  sb.append("</topic>");
				 strg= sb.toString();		
				} catch (Exception localException) {
						System.out.println(localException);
						localException.printStackTrace();
					   sb.append("<Response>");
					   sb.append("\n");
					   sb.append("<Result>");
					   sb.append("\n");
					   sb.append("Fail");
					   sb.append("\n");
					   sb.append("</Result>");
					   sb.append("\n");
					   sb.append("<Description>");
					   sb.append("could not inserted topic item");
					   sb.append("</Description>");
					   sb.append("\n");
					   sb.append("<Exception>");
					   sb.append(localException);
					   sb.append("</Exception>");
					   sb.append("</Response>");
					    strg=sb.toString();
					   MDTransactionWriter.exceptionlog.info(localException);
					  if (tx!=null)
					   tx.rollback();
					  } finally {
					   rdSession.close(); 
					  }
					  return strg;
					 }
	public String deleteTopic(int topicId,int schoolId,int branchId) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb=new StringBuffer();
		String strg= null;
		try {
				tx = rdSession.beginTransaction();
				/*TopicPojo tp=new TopicPojo();
				tp.setTopicId(id);
				rdSession.delete(tp);
				tx.commit();*/
				TopicPojo tp = (TopicPojo)rdSession.get(TopicPojo.class,topicId);					   
				   rdSession.evict(tp);
				   if(branchId==tp.getBranchId()&&schoolId==tp.getSchoolId())
				   {
				   Query empQuery=rdSession.createSQLQuery("update gbl_sm_tbl_topic set isDeleted='y' where topicId='"+topicId+"'");
				   empQuery.executeUpdate();
				   tx.commit();
				sb.append("<topic>");
				    sb.append("\n");
				    sb.append("<id>");
					sb.append("topic item deleted");
					sb.append("</id>");
					sb.append("\n");
					sb.append("</topic>");
					strg= sb.toString();
		}else{
			   strg = " topic is not deleted";
			   sb.append("<topic>");
			   sb.append("\n");
			   sb.append(strg);
			   sb.append("</topic>");
			    String str = sb.toString();
			    return str;
			   }
		}
		catch(Exception localException)
		{
			System.out.println(localException);
			localException.printStackTrace();
			sb.append("<Response>");
			sb.append("\n");
			sb.append("<Result>");
			   sb.append("\n");
			   sb.append("Fail");
			   sb.append("\n");
			   sb.append("</Result>");
			   sb.append("\n");
			   sb.append("<Description>");
			   sb.append("could not delete topic item");
			   sb.append("</Description>");
			   sb.append("\n");
			   sb.append("<Exception>");
			   sb.append(localException);
			   sb.append("</Exception>");
			   sb.append("</Response>");
			    strg=sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (tx!=null)
			   tx.rollback();
			  } finally {
			   rdSession.close(); 
			  }
			  return strg;
			 }
   
	public String updateTopic(TopicPojo topicPojo,int schoolId,int branchId) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb= new StringBuffer();
		String strg= null;
			try {
					tx = rdSession.beginTransaction();
					/*rdSession.update(topicPojo);
					  tx.commit();*/
					TopicPojo tp = (TopicPojo) rdSession.get(TopicPojo.class,topicPojo.getTopicId());
					rdSession.evict(tp);
					   if(schoolId==tp.getSchoolId()&&branchId==tp.getBranchId())
					   rdSession.update(topicPojo);  
					   tx.commit();
					    sb.append("<topic>");
					    sb.append("\n");
					    sb.append("<id>");
						sb.append("\n");
						sb.append("topic succssfully updated");
						sb.append("</id>");
						sb.append("\n");
						sb.append("</topic>");
						strg= sb.toString();
				} 	catch (Exception localException) {
					System.out.println(localException);
					localException.printStackTrace();
			   sb.append("<Response>");
			   sb.append("\n");
			   sb.append("<Result>");
			   sb.append("\n");
			   sb.append("Fail");
			   sb.append("\n");
			   sb.append("</Result>");
			   sb.append("\n");
			   sb.append("<Description>");
			   sb.append("could not update topic item");
			   sb.append("</Description>");
			   sb.append("\n");
			   sb.append("<Exception>");
			   sb.append(localException);
			   sb.append("</Exception>");
			   sb.append("</Response>");
			    strg=sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (tx!=null)
			   tx.rollback();
			  } finally {
			   rdSession.close(); 
			  }
			  return strg;
			 }

	@SuppressWarnings("rawtypes")
	public String getAllTopics(int PNO, int size,int schoolId,int branchId,int classId,int sectionId,int subjectId,int unitId,int chapterId) {
			  String xmlString=null;
			  Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
			  Transaction stgTx=null;
			  StringBuffer sb = new StringBuffer();			  
			  try
			  {
			   stgTx=stgSession.beginTransaction();
			    int fset = (PNO-1)*size;
			    String filterWhere="";
			    if(classId!=0){									  								    	
			    	filterWhere+=" and sub.ClassId="+classId;	
			    
				if(sectionId!=0){
					filterWhere +=  " and sub.SectionId="+sectionId;
				}
			    }
				if(subjectId!=0){
					filterWhere += " and units.SubjectId="+subjectId;
				}
			    if(unitId!=0){
			    	filterWhere+=" and chapter.UnitId="+unitId;	
			    }
			    if(chapterId!=0){
			    	filterWhere+=" and topic.ChapterId="+chapterId;			    	
			    		}
			    String  gsSql =" SELECT count(*) FROM  gbl_sm_tbl_topic as  topic  left outer join gbl_sm_tbl_chapter as chapter on topic.ChapterId =chapter.ChapterId left outer join gbl_sm_tbl_units as units on chapter.UnitId=units.UnitId left outer join gbl_sm_tbl_subjects as sub ON  units.SubjectId =sub.SubjectId left outer join gbl_sm_tbl_class as cls on sub.ClassId= cls.ClassId  left outer join gbl_sm_tbl_section as sec on sub.SectionId=sec.SectionId  left outer join gbl_sm_tbl_subject_type as subtype on sub.SubjectTypeId=subtype.SubjectTypeId where (topic.isDeleted<>'y' or topic.isDeleted is null) and topic.schoolId='"+schoolId+"' and topic.branchId='"+branchId+"'"+filterWhere+" ";	
			    Query gsQuery=stgSession.createSQLQuery(gsSql);		    
			    Object noRecords= gsQuery.uniqueResult();
			    int intNoRecords=0;
				if(noRecords!=null && Integer.parseInt(noRecords.toString())!=0)
				{
					intNoRecords=Integer.parseInt(noRecords.toString());
				}
			    sb.append("<topics>");
			    sb.append("\n");
			    sb.append("<noRecords>"+noRecords+"</noRecords>");
			    sb.append("\n");	
			    if(intNoRecords!=0)
				{
			     if (PNO > 0 & size > 0){
			     gsSql="SELECT topic.TopicId,sub.ClassId,cls.ClassName, sub.SectionId,sec.SectionName,units.SubjectId,subtype.SubjectName,chapter.UnitId,units.UnitNo,units.UnitName,topic.ChapterId,chapter.ChapterNo,chapter.ChapterName ,topic.TopicName,topic.`Status`,topic.Description,topic.CreatedDate,topic.ModifiedDate,topic.SchoolId,topic.BranchId FROM gbl_sm_tbl_topic as topic left outer join gbl_sm_tbl_chapter as chapter on topic.ChapterId =chapter.ChapterId left outer join gbl_sm_tbl_units as units on chapter.UnitId=units.UnitId left outer join gbl_sm_tbl_subjects as sub ON  units.SubjectId =sub.SubjectId left outer join gbl_sm_tbl_class as cls on sub.ClassId= cls.ClassId  left outer join gbl_sm_tbl_section as sec  on sub.SectionId=sec.SectionId  left outer join gbl_sm_tbl_subject_type as subtype on sub.SubjectTypeId=subtype.SubjectTypeId   where  (topic.isDeleted<>'y' or topic.isDeleted is null) and topic.schoolId='"+schoolId+"' and topic.branchId='"+branchId+"'"+filterWhere+"  limit "+size+" offset "+fset;
			     }
			     else {
			      gsSql="SELECT topic.TopicId,sub.ClassId,cls.ClassName, sub.SectionId,sec.SectionName,units.SubjectId,subtype.SubjectName,chapter.UnitId,units.UnitNo,units.UnitName,topic.ChapterId,chapter.ChapterNo,chapter.ChapterName ,topic.TopicName,topic.`Status`,topic.Description,topic.CreatedDate,topic.ModifiedDate,topic.SchoolId,topic.BranchId FROM gbl_sm_tbl_topic as topic left outer join gbl_sm_tbl_chapter as chapter on topic.ChapterId =chapter.ChapterId left outer join gbl_sm_tbl_units as units on chapter.UnitId=units.UnitId left outer join gbl_sm_tbl_subjects as sub ON  units.SubjectId =sub.SubjectId left outer join gbl_sm_tbl_class as cls on sub.ClassId= cls.ClassId  left outer join gbl_sm_tbl_section as sec  on sub.SectionId=sec.SectionId  left outer join gbl_sm_tbl_subject_type as subtype on sub.SubjectTypeId=subtype.SubjectTypeId   where  (topic.isDeleted<>'y' or topic.isDeleted is null) and topic.schoolId='"+schoolId+"' and topic.branchId='"+branchId+"'"+filterWhere+" ";
			     } 
			    gsQuery=stgSession.createSQLQuery(gsSql);
			    List gcList=gsQuery.list();
			    Iterator gsIT=gcList.iterator();
			     while(gsIT.hasNext())
			     {
			      Object[] mdcArr=(Object[])gsIT.next();
			      sb.append("<topic>");
			      sb.append("\n");
			      sb.append("<topicId>"+mdcArr[0]+"</topicId>");
			      sb.append("\n");
			      sb.append("<classId>"+mdcArr[1]+"</classId>");
			      sb.append("\n");
			      sb.append("<className>"+mdcArr[2]+"</className>");
			      sb.append("\n");
			      sb.append("<sectionId>"+mdcArr[3]+"</sectionId>");
			      sb.append("\n");
			      sb.append("<sectionName>"+mdcArr[4]+"</sectionName>");
			      sb.append("\n");
			      sb.append("<subjectId>"+mdcArr[5]+"</subjectId>");
			      sb.append("\n");
			      sb.append("<subjectName>"+mdcArr[6]+"</subjectName>");
			      sb.append("\n");
			      sb.append("<unitId>"+mdcArr[7]+"</unitId>");
			      sb.append("\n");
			      sb.append("<unitNo>"+mdcArr[8]+"</unitNo>");
			      sb.append("\n");
			      sb.append("<unitName>"+mdcArr[9]+"</unitName>");
			      sb.append("\n");
			      sb.append("<chapterId>" + mdcArr[10]+ "</chapterId>");
			      sb.append("\n");
			      sb.append("<chapterNo>" + mdcArr[11]+ "</chapterNo>");
			      sb.append("\n");
			      sb.append("<chapterName>" + mdcArr[12] + "</chapterName>");
			      sb.append("\n");
			      sb.append("<topicName>" + mdcArr[13]+ "</topicName>");
			      sb.append("\n");
			      sb.append("<status>" + mdcArr[14] + "</status>");
			      sb.append("\n");
			      sb.append("<description>" +  mdcArr[15]+ "</description>");
			      sb.append("\n");
			      sb.append("<createdDate>" + mdcArr[16] + "</createdDate>");
			      sb.append("\n");
			      sb.append("<modifiedDate>" + mdcArr[17] + "</modifiedDate>");
			      sb.append("\n");
			      sb.append("<schoolId>" + mdcArr[18] + "</schoolId>");
			      sb.append("\n");
			      sb.append("<branchId>" + mdcArr[19] + "</branchId>");
			      sb.append("\n");
			      sb.append("</topic>");
			     }
				}
			    stgTx.commit();
			    sb.append("</topics>");
			    sb.append("\n");

			    xmlString=sb.toString();
			   }	
		catch(Exception localException){
			System.out.println(localException);
			localException.printStackTrace();
		   sb.append("<Response>");
		   sb.append("\n");
		   sb.append("<Result>");
		   sb.append("\n");
		   sb.append("Fail");
		   sb.append("\n");
		   sb.append("</Result>");
		   sb.append("\n");
		   sb.append("<Description>");
		   sb.append("could not getall topic items");
		   sb.append("</Description>");
		   sb.append("\n");
		   sb.append("<Exception>");
		   sb.append(localException);
		   sb.append("</Exception>");
		   sb.append("</Response>");
		   xmlString=sb.toString();
		   MDTransactionWriter.exceptionlog.info(localException);
		  if (stgTx!=null)
			  stgTx.rollback();
		  } finally {
			  stgSession.close(); 
		  }
		  return xmlString;
		 }
	
	@SuppressWarnings("rawtypes")
	public String getByIdTopics(int topicId,int schoolId,int branchId) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb= new StringBuffer();
		String strg= null;
		try {
			tx = rdSession.beginTransaction();
			Query query=rdSession.createSQLQuery("SELECT topic.TopicId,sub.ClassId,cls.ClassName, sub.SectionId,sec.SectionName,units.SubjectId,subtype.SubjectName,chapter.UnitId,units.UnitNo,units.UnitName,topic.ChapterId,chapter.ChapterNo,chapter.ChapterName ,topic.TopicName,	topic.`Status`,topic.Description,topic.CreatedDate,topic.ModifiedDate,topic.SchoolId,topic.BranchId FROM gbl_sm_tbl_topic as topic left outer join gbl_sm_tbl_chapter as chapter on topic.ChapterId =chapter.ChapterId left outer join gbl_sm_tbl_units as units on chapter.UnitId=units.UnitId left outer join gbl_sm_tbl_subjects as sub ON  units.SubjectId =sub.SubjectId left outer join gbl_sm_tbl_class as cls on sub.ClassId= cls.ClassId  left outer join gbl_sm_tbl_section as sec  on sub.SectionId=sec.SectionId  left outer join gbl_sm_tbl_subject_type as subtype on sub.SubjectTypeId=subtype.SubjectTypeId   where  (topic.isDeleted<>'y' or topic.isDeleted is null) and topic.TopicId='"+topicId+"' and topic.schoolId='"+schoolId+"' and topic.branchId='"+branchId+"'");
		    List gcList=query.list();
		    Iterator gsIT=gcList.iterator();
		     while(gsIT.hasNext())
		     {
		      Object[] mdcArr=(Object[])gsIT.next();
		      sb.append("<topic>");
		      sb.append("\n");
		      sb.append("<topicId>"+mdcArr[0]+"</topicId>");
		      sb.append("\n");
		      sb.append("<classId>"+mdcArr[1]+"</classId>");
		      sb.append("\n");
		      sb.append("<className>"+mdcArr[2]+"</className>");
		      sb.append("\n");
		      sb.append("<sectionId>"+mdcArr[3]+"</sectionId>");
		      sb.append("\n");
		      sb.append("<sectionName>"+mdcArr[4]+"</sectionName>");
		      sb.append("\n");
		      sb.append("<subjectId>"+mdcArr[5]+"</subjectId>");
		      sb.append("\n");
		      sb.append("<subjectName>"+mdcArr[6]+"</subjectName>");
		      sb.append("\n");
		      sb.append("<unitId>"+mdcArr[7]+"</unitId>");
		      sb.append("\n");
		      sb.append("<unitNo>"+mdcArr[8]+"</unitNo>");
		      sb.append("\n");
		      sb.append("<unitName>"+mdcArr[9]+"</unitName>");
		      sb.append("\n");
		      sb.append("<chapterId>" + mdcArr[10]+ "</chapterId>");
		      sb.append("\n");
		      sb.append("<chapterNo>" + mdcArr[11]+ "</chapterNo>");
		      sb.append("\n");
		      sb.append("<chapterName>" + mdcArr[12] + "</chapterName>");
		      sb.append("\n");
		      sb.append("<topicName>" + mdcArr[13]+ "</topicName>");
		      sb.append("\n");
		      sb.append("<status>" + mdcArr[14] + "</status>");
		      sb.append("\n");
		      sb.append("<description>" +  mdcArr[15]+ "</description>");
		      sb.append("\n");
		      sb.append("<createdDate>" + mdcArr[16] + "</createdDate>");
		      sb.append("\n");
		      sb.append("<modifiedDate>" + mdcArr[17] + "</modifiedDate>");
		      sb.append("\n");
		      sb.append("<schoolId>" + mdcArr[18] + "</schoolId>");
		      sb.append("\n");
		      sb.append("<branchId>" + mdcArr[19] + "</branchId>");
		      sb.append("\n");
		      sb.append("</topic>");
		      String str= sb.toString();
				return str;
		}
			} 	catch (Exception localException) {
				System.out.println(localException);
				localException.printStackTrace();
		   sb.append("<Response>");
		   sb.append("\n");
		   sb.append("<Result>");
		   sb.append("\n");
		   sb.append("Fail");
		   sb.append("\n");
		   sb.append("</Result>");
		   sb.append("\n");
		   sb.append("<Description>");
		   sb.append("could not getby topic item");
		   sb.append("</Description>");
		   sb.append("\n");
		   sb.append("<Exception>");
		   sb.append(localException);
		   sb.append("</Exception>");
		   sb.append("</Response>");
		   sb.append("</topicId>");
		   sb.append("</topic>");    
		    strg=sb.toString();
		   MDTransactionWriter.exceptionlog.info(localException);
		  if (tx!=null)
		   tx.rollback();
		  } finally {
		   rdSession.close(); 
		  }
		  return strg;
		 }
	
}

		

	
	
	
