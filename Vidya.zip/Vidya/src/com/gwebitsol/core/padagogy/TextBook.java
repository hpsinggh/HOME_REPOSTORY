package com.gwebitsol.core.padagogy;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="TextBook")

public class TextBook {
	private int textBookId;
	private String textBookName;
	private String author;
	private String publisher;
	private String description;
	private int schoolId;
	private int branchId;

	public int getTextBookId() {
		return textBookId;
	}
	public void setTextBookId(int textBookId) {
		this.textBookId = textBookId;
	}
	public String getTextBookName() {
		return textBookName;
	}
	public void setTextBookName(String textBookName) {
		this.textBookName = textBookName;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getPublisher() {
		return publisher;
	}
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getSchoolId() {
		return schoolId;
	}
	public void setSchoolId(int schoolId) {
		this.schoolId = schoolId;
	}
	public int getBranchId() {
		return branchId;
	}
	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}
}
