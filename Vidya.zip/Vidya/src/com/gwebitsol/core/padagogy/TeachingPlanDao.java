package com.gwebitsol.core.padagogy;

import java.util.Iterator;
import java.util.List;

import javax.jms.ServerSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.gwebitsol.core.setting.MDCategory;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class TeachingPlanDao {
	

	@SuppressWarnings("rawtypes")
	public String getTeachingPlan(String startdate, String enddate) /* *//*String startdate, String enddate, */{
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		String strg= null;
		StringBuffer sb= new StringBuffer();
		try {
				tx = rdSession.beginTransaction();
		
			List list = rdSession.createSQLQuery("select lp.LessonPlanId, lp.LessonPlanName, lp.LessonPlanDescription,  lp.EmployeeId, lp.StartDate, lp.EndDate, lp.LessonPlanStatus,t.TopicId, t.ChapterId, t.TopicName, t.Description, t.Status FROM gbl_sm_tbl_lessonplan lp JOIN gbl_sm_tbl_lessonplantopic lpt on (lp.LessonPlanId = lpt.LessonPlanId) JOIN gbl_sm_tbl_topic t on (lpt.TopicId = t.TopicId)").list();
			Iterator it=list.iterator();
		     sb.append("<lessonplan>");
			  while(it.hasNext()){
			      Object[] ex=(Object[])it.next();
			      sb.append("<lessonplanid>");
			      sb.append(ex[0]);
			      sb.append("</lessonplanid>");
			      sb.append("<LessonPlanName>");
			      sb.append(ex[1]);
			      sb.append("</LessonPlanName>");
			      sb.append("<LessonPlanDescription>");
			      sb.append(ex[2]);
			      sb.append("</LessonPlanDescription>");
			      sb.append("<EmployeeId>");
			      sb.append(ex[3]);
			      sb.append("</EmployeeId>");
			      sb.append("<StartDate>");
			      sb.append(ex[4]);
			      sb.append("</StartDate>");
			      sb.append("<endDate>");
			      sb.append(ex[5]);
			      sb.append("</endDate>");
			      sb.append("<LessonPlanStatus>");
			      sb.append(ex[6]);
			      sb.append("</LessonPlanStatus>");
			      sb.append("<TopicId>");
			      sb.append(ex[7]);
			      sb.append("</TopicId>");
			      sb.append("<ChapterId>");
			      sb.append(ex[8]);
			      sb.append("</ChapterId>");
			      sb.append("<TopicName>");
			      sb.append(ex[9]);
			      sb.append("</TopicName>");
			      
			     sb.append("</lessonplan>");
			     strg=  sb.toString();
			  }
	}
	catch (Exception localException) {
		
		System.out.println(localException);
			localException.printStackTrace();
	 if (tx!=null)
		  tx.rollback();
	  } finally {
		  rdSession.close(); 
	  }
		return strg;
}

	public String getTeachingPlanTopics(int PNO, int size,String settings) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		String xmlString=null;
		StringBuffer sb = new StringBuffer();
		try
		{
			boolean topics = false;
			String [] setgArr = settings.split(",");
			if (settings.trim().equalsIgnoreCase("all")) {
				topics = true;}
				else {
					for (int i=0; i<setgArr.length; i++){
						if (setgArr[i].trim().equalsIgnoreCase("topics")) topics = true;
		
		}
	}
			sb.append("<Topics>");
			sb.append("\n");
			if (topics) {
				xmlString=gettopics(PNO, size, null);
				sb.append(xmlString);
				}
				else {
					sb.append("<topics></topics>");
					sb.append("\n");
					System.out.println("Empty List of topics");
				}
			sb.append("</Topics>");
			sb.append("\n");
			xmlString=sb.toString();
			
		}
		catch(Exception localException)
		{
			MDTransactionWriter.exceptionlog.info(localException);
			xmlString="fail";
			  } finally {
				  rdSession.close(); 
			  }
		return xmlString;
	}
			
		@SuppressWarnings("rawtypes")
		public String gettopics(int PNO, int size, List<TopicPojo> topics){
			
			String xmlString=null;
			Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
			Transaction stgTx=null;
			StringBuffer catSB = new StringBuffer();
			try {
				stgTx=stgSession.beginTransaction();
				int fset = (PNO-1)*size;
				String gsSql ="select count(*) from gbl_sm_tbl_topic ";
				Query gsQuery=stgSession.createSQLQuery(gsSql);
				Object noRecords= gsQuery.uniqueResult();
				catSB.append("<topicsdata>");
				catSB.append("\n");
				catSB.append("<noRecords>"+noRecords+"</noRecords>");
				catSB.append("\n");
				if(topics==null) {
				if (PNO > 0 & size > 0){
				gsSql="select * from gbl_sm_tbl_topic limit "+size+" offset "+fset;}
				else {
					gsSql="select * from gbl_sm_tbl_topic";
				}
				} else {
					StringBuffer ctIdSB = new StringBuffer();
					Iterator gsIdIT=topics.iterator();
						while(gsIdIT.hasNext())
						{
							MDCategory mdct=(MDCategory)gsIdIT.next();
							ctIdSB .append("'"+mdct.getCategoryId()+"',");
						}
						int k=ctIdSB.lastIndexOf(",");
						ctIdSB.deleteCharAt(k);
						String ctIdStr = ctIdSB.toString();	
					gsSql="select * from gbl_sm_tbl_topic where topicId in ("+ctIdStr+")";
				}
				gsQuery=stgSession.createSQLQuery(gsSql);
				List gcList=gsQuery.list();
				Iterator gsIT=gcList.iterator();
					while(gsIT.hasNext())
					{
						//MDCategory mdc=(MDCategory)gsIT.next();
						Object[] mdcArr=(Object[])gsIT.next();
						catSB.append("<topic>");
						catSB.append("\n");
						catSB.append("<topicId>"+ mdcArr[0]+"</topicId>");
						catSB.append("\n");
						catSB.append("<chapterid>"+ mdcArr[1]+"</chapterid>");
						catSB.append("\n");
						catSB.append("<topicname>"+ mdcArr[2]+"</topicname>");
						catSB.append("\n");
						catSB.append("<Status>"+ mdcArr[3]+"</Status>");
						catSB.append("\n");
						catSB.append("<description>"+mdcArr[4]+"</description>");
						catSB.append("\n");
						catSB.append("<createddate>"+ mdcArr[5]+"</createddate>");
						catSB.append("\n");
						catSB.append("<modifieddate>"+ mdcArr[6]+"</modifieddate>");
						catSB.append("\n");
						catSB.append("</topic>");
						catSB.append("\n");
					}
				
				stgTx.commit();
				catSB.append("</topicsdata>");
				catSB.append("\n");

				xmlString=catSB.toString();
			}
			catch(Exception localException)
			{
				stgTx.rollback();
				localException.printStackTrace();
				xmlString = "fail";
				System.out.println("Could not Get Categories");
			}
			finally
			{
				stgSession.close();
			}
		 return xmlString;
		}

		@SuppressWarnings("rawtypes")
		public String getTimETableByPeriods(String days) {
			Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
			Transaction tx = null;
			String strg= null;
			StringBuffer sb= new StringBuffer();
			try {
					tx = rdSession.beginTransaction();
				List list = rdSession.createSQLQuery(" select * from gbl_sm_tbl_timetable join gbl_sm_tbl_period on gbl_sm_tbl_timetable.TimeTableId=gbl_sm_tbl_period.TimeTableId where gbl_sm_tbl_period.PeriodId in (select PeriodId from gbl_sm_tbl_period where Days REGEXP '"+days+"')").list();
				Iterator it=list.iterator();
			     sb.append("<timetable>");
				  while(it.hasNext()){
				      Object[] ex=(Object[])it.next();
				      sb.append("<id>");
				      sb.append(ex[0]);
				      sb.append("<lessonplanid>");
				      sb.append("<LessonPlanName>");
				      sb.append(ex[1]);
				      sb.append("</LessonPlanName>");
				      sb.append("<LessonPlanDescription>");
				      sb.append(ex[2]);
				      sb.append("</LessonPlanDescription>");
				      sb.append("<EmployeeId>");
				      sb.append(ex[3]);
				      sb.append("</EmployeeId>");
				      sb.append("<StartDate>");
				      sb.append(ex[4]);
				      sb.append("</StartDate>");
				      sb.append("<endDate>");
				      sb.append(ex[5]);
				      sb.append("</endDate>");
				      sb.append("<LessonPlanStatus>");
				      sb.append(ex[6]);
				      sb.append("</LessonPlanStatus>");
				      sb.append("<TopicId>");
				      sb.append(ex[7]);
				      sb.append("</TopicId>");
				      sb.append("<ChapterId>");
				      sb.append(ex[8]);
				      sb.append("</ChapterId>");
				      sb.append("<TopicName>");
				      sb.append(ex[9]);
				      sb.append("</TopicName>");
				      sb.append(ex[10]);
				      sb.append("</lessonplanid>");
				      sb.append("<id>");
				      sb.append(ex[11]);
				      sb.append("<lessonplanid>");
				      sb.append("<LessonPlanName>");
				      sb.append(ex[12]);
				      sb.append("</LessonPlanName>");
				      sb.append("<LessonPlanDescription>");
				      sb.append(ex[13]);
				      sb.append("</LessonPlanDescription>");
				      sb.append("<EmployeeId>");
				      sb.append(ex[14]);
				      sb.append("</EmployeeId>");
				      sb.append("<StartDate>");
				      sb.append(ex[15]);
				      sb.append("</StartDate>");
				      sb.append("<endDate>");
				      sb.append(ex[16]);
				      sb.append("</endDate>");
				      sb.append("<LessonPlanStatus>");
				      sb.append(ex[17]);
				      sb.append("</LessonPlanStatus>");
				      sb.append("<TopicId>");
				      sb.append(ex[18]);
				      sb.append("</TopicId>");
					  strg=  sb.toString();      
		}
			}
			catch(Exception localException)
			{
				tx.rollback();
				localException.printStackTrace();
				strg = "fail";
				System.out.println("Could not Get tbleby periods");
			}
			finally
			{
				rdSession.close();
			}
		 return strg;
		}

		@SuppressWarnings("rawtypes")
		public String getallTeachingPlans(String startdate, String enddate, int classid, int employeeid,
				int sectionid,int subjectid,int PNO,int size,String teachingplans) {
			Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
			Transaction tx = null;
			String strg= null;
			StringBuffer sb= new StringBuffer();
			try {
					tx = rdSession.beginTransaction();
				List list = rdSession.createSQLQuery("select gbl_sm_tbl_lessonplan.LessonPlanId,"
						+ "gbl_sm_tbl_lessonplan.LessonPlanName,gbl_sm_tbl_lessonplan.StartDate,gbl_sm_tbl_lessonplan.EndDate,gbl_sm_tbl_lessonplan.LessonPlanDescription,gbl_sm_tbl_lessonplan.EmployeeId,"
						+ "gbl_sm_tbl_topic.TopicId,gbl_sm_tbl_topic.TopicName,gbl_sm_tbl_topic.Description,gbl_sm_tbl_chapter.ChapterId,gbl_sm_tbl_chapter.ChapterNo,"
						+ "gbl_sm_tbl_chapter.ChapterName,gbl_sm_tbl_chapter.UnitId,gbl_sm_tbl_units.UnitId,gbl_sm_tbl_units.SubjectId,gbl_sm_tbl_units.UnitNo,gbl_sm_tbl_units.UnitName,"
						+ "gbl_sm_tbl_units.Description, gbl_sm_tbl_subjects.SubjectId,gbl_sm_tbl_subjects.SubjectName,gbl_sm_tbl_subjects.ClassId,gbl_sm_tbl_subjects.Syllabus,"
						+ "gbl_sm_tbl_section.SectionId,gbl_sm_tbl_section.SectionName,gbl_sm_tbl_section.Description,gbl_sm_tbl_class.ClassId,"
						+ "gbl_sm_tbl_class.ClassName,gbl_sm_tbl_staff.EmployeeId,gbl_sm_tbl_staff.StaffNumber,gbl_sm_tbl_staff.FirstName,"
						+ "gbl_sm_tbl_staff.LastName  from gbl_sm_tbl_lessonplantopic join gbl_sm_tbl_lessonplan on gbl_sm_tbl_lessonplan.LessonPlanId=gbl_sm_tbl_lessonplantopic.LessonPlanId "
						+ "join gbl_sm_tbl_staff on gbl_sm_tbl_staff.EmployeeId=gbl_sm_tbl_lessonplan.EmployeeId join gbl_sm_tbl_topic on gbl_sm_tbl_topic.TopicId=gbl_sm_tbl_lessonplantopic.TopicId "
						+ "join gbl_sm_tbl_chapter on gbl_sm_tbl_chapter.ChapterId=gbl_sm_tbl_topic.ChapterId join gbl_sm_tbl_units on gbl_sm_tbl_units.UnitId=gbl_sm_tbl_chapter.UnitId "
						+ "join gbl_sm_tbl_subjects on gbl_sm_tbl_subjects.SubjectId=gbl_sm_tbl_units.SubjectId join gbl_sm_tbl_class on gbl_sm_tbl_class.ClassId=gbl_sm_tbl_subjects.ClassId "
						+ "join gbl_sm_tbl_section on gbl_sm_tbl_section.ClassId=gbl_sm_tbl_class.ClassId where gbl_sm_tbl_lessonplan.StartDate>='"+startdate+"' "
						+ "and gbl_sm_tbl_lessonplan.EndDate<='"+enddate+"' and gbl_sm_tbl_class.ClassId='"+classid+"' or gbl_sm_tbl_section.SectionId='"+sectionid+"'"
						+ " or gbl_sm_tbl_staff.EmployeeId='"+employeeid+"' and gbl_sm_tbl_subjects.SubjectId='"+subjectid+"'").list();
				Iterator it=list.iterator();
			     sb.append("<getallteachingplan>");
				  while(it.hasNext()){
				      Object[] ex=(Object[])it.next();
				      sb.append("<lessonplanid>");
				      sb.append(ex[0]);
				      sb.append("</lessonplanid>");
				      sb.append("<LessonPlanName>");
				      sb.append(ex[1]);
				      sb.append("</LessonPlanName>");
				      sb.append("<startdate>");
				      sb.append(ex[2]);
				      sb.append("</startdate>");
				      sb.append("<enddate>");
				      sb.append(ex[3]);
				      sb.append("</enddate>");
				      sb.append("<lessonplandescription>");
				      sb.append(ex[4]);
				      sb.append("</lessonplandescription>");
				      sb.append("<employeeid>");
				      sb.append(ex[5]);
				      sb.append("</employeeid>");
				      sb.append("<topicid>");
				      sb.append(ex[6]);
				      sb.append("</topicid>");
				      sb.append("<topicname>");
				      sb.append(ex[7]);
				      sb.append("</topicname>");
				      sb.append("<topicdescription>");
				      sb.append(ex[8]);
				      sb.append("</topicdescription>");
				      sb.append("<chapterid>");
				      sb.append(ex[9]);
				      sb.append("</chapterid>");
				      sb.append("<chapterno>");
				      sb.append(ex[10]);
				      sb.append("</chapterno>");
				      sb.append("<chaptername>");
				      sb.append(ex[11]);
				      sb.append("</chaptername>");
				      sb.append("<unitid>");
				      sb.append(ex[12]);
				      sb.append("</unitid>");
				      sb.append("<unitid>");
				      sb.append(ex[13]);
				      sb.append("</unitid>");
				      sb.append("<subjectid>");
				      sb.append(ex[14]);
				      sb.append("</subjectid>");
				      sb.append("<unitno>");
				      sb.append(ex[15]);
				      sb.append("</unitno>");
				      sb.append("<unitname>");
				      sb.append(ex[16]);
				      sb.append("</unitname>");
				      sb.append("<unitdescription>");
				      sb.append(ex[17]);
				      sb.append("</unitdescription>");
				      sb.append("<subjectId>");
				      sb.append(ex[18]);
				      sb.append("</subjectId>");
				      sb.append("<subjectname>");
				      sb.append(ex[19]);
				      sb.append("</subjectname>");
				      sb.append("<classid>");
				      sb.append(ex[20]);
				      sb.append("</classid>");
				      sb.append("<syllabus>");
				      sb.append(ex[21]);
				      sb.append("</syllabus>");
				      sb.append("<sectionid>");
				      sb.append(ex[22]);
				      sb.append("</sectionid>");
				      sb.append("<sectionname>");
				      sb.append(ex[23]);
				      sb.append("</sectionname>");
				      sb.append("<sectionDescription>");
				      sb.append(ex[24]);
				      sb.append("</sectionDescription>");
				      sb.append("<classid>");
				      sb.append(ex[25]);
				      sb.append("</classid>");
				      sb.append("<classname>");
				      sb.append(ex[26]);
				      sb.append("</classname>");
				      sb.append("<employeeid>");
				      sb.append(ex[27]);
				      sb.append("</employeeid>");
				      sb.append("<staffnumber>");
				      sb.append(ex[28]);
				      sb.append("</staffnumber>");
				      sb.append("<firstname>");
				      sb.append(ex[29]);
				      sb.append("</firstname>");
				      sb.append("<lastname>");
				      sb.append(ex[30]);
				      sb.append("</lastname>");
			}
			
			sb.append("</getallteachingplan>");
			String str= sb.toString();
			return str;
			}
			catch(Exception localException)
			{
				tx.rollback();
				localException.printStackTrace();
				strg = "fail";
				System.out.println("Could not Get tbleby periods");
			}
			finally
			{
				rdSession.close();
			}
		 return strg;
		}
}
