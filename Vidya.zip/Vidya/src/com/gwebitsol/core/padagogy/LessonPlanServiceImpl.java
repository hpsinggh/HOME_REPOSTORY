package com.gwebitsol.core.padagogy;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import com.gwebitsol.core.security.MDValidation;
import com.gwebitsol.core.util.MDTransactionWriter;

public class LessonPlanServiceImpl implements LessonPlanServiceInf{
	@Context 
	private HttpServletRequest hsr;
	public Response addLessonPlan(LessonPlanPojo lessonPlanPojo,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		lessonPlanPojo.setSchoolId(schoolId);
		lessonPlanPojo.setBranchId(branchId);
			try
				{	
					MDValidation mdv = new MDValidation();  
					int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
					System.out.println("verifiedvalue::"+ret);
					if(ret==1 ){
					LessonPlanDao dao= new LessonPlanDao ();
					status=dao.addLessonPlan(lessonPlanPojo);
					String endDate=dateFormat.format(new Date());
					Long el=System.currentTimeMillis();
					MDTransactionWriter.writeLog(datastoreName,"CMS","requester",startDate,endDate,sl,el,status,hsr.getRemoteHost());		
				}else
				{
					status="you are not authorised user";
				}
			}
				catch(Exception localException)
					{
						MDTransactionWriter.errorlog.debug(localException);
						MDTransactionWriter.errorlog.info(localException);
						status="failed in service layer";
						System.out.println(localException);
					}
	
			return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response deleteLessonPlan(int lessonplanId,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
			
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
			
		try
			{	
				MDValidation mdv = new MDValidation();  
				int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			   System.out.println("verifiedvalue::"+ret);
			if(ret==1 ){
		
			LessonPlanDao dao= new LessonPlanDao ();
			status=dao.deleteLessonPlan(lessonplanId, schoolId,branchId);
			
			String endDate=dateFormat.format(new Date());	
			Long el=System.currentTimeMillis();
			//status="user validation successfull";
			MDTransactionWriter.writeLog("sai","CMS","requester",startDate,endDate,sl,el,status,hsr.getRemoteHost());		
		}else
		{
			status="you are not authorised user";
		}
			}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			status="failed in service layer";
		}
	return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}
	public Response updateLessonPlan(LessonPlanPojo lessonPlanPojo,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		lessonPlanPojo.setBranchId(branchId);
		lessonPlanPojo.setSchoolId(schoolId);
		try
		{	
			MDValidation mdv = new MDValidation();  
			int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			System.out.println("verifiedvalue::"+ret);
		if(ret==1 ){
			LessonPlanDao dao= new LessonPlanDao ();
			status=dao.updateLessonPlan(lessonPlanPojo, schoolId, branchId);
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			//status="user validation successfull";
			MDTransactionWriter.writeLog("sai","CMS","requester",startDate,endDate,sl,el,status,hsr.getRemoteHost());		
		}else
		{
			status="you are not authorised user";
		}
	}
		  	catch(Exception localException)
			{
			  MDTransactionWriter.errorlog.debug(localException);
			  MDTransactionWriter.errorlog.info(localException);
			  status="failed in service layer";
		   }
    return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}
	

	public Response getAllLessonPlans(int userID, int connectionID,String datastoreName,int PNO, int size,int schoolId,int branchId,int classId,int subjectId,int unitId,int chapterId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try{
			MDValidation mdv = new MDValidation();  
			int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
		   System.out.println("verifiedvalue::"+ret);
			if(ret==1 ){
		
			LessonPlanDao dao= new LessonPlanDao ();
			status=dao.getAllLessonPlans( PNO,size, schoolId, branchId,classId, subjectId, unitId, chapterId);
			System.out.println(status);
			String endDate=dateFormat.format(new Date());
			  Long el=System.currentTimeMillis();
			 MDTransactionWriter.writeLog("sai","CMS","requester",startDate,endDate,sl,el,status,hsr.getRemoteHost());		
		}else
		{
			status="you are not authorised user";
		}
	}catch(Exception localException)
		   {
			  MDTransactionWriter.errorlog.debug(localException);
			  MDTransactionWriter.errorlog.info(localException);
			  status="failed in service layer";
		   }
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response getByIdLessonPlan(int lessonplanId,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
			{	
			MDValidation mdv = new MDValidation();  
			int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
		   System.out.println("verifiedvalue::"+ret);
			if(ret==1 ){
			LessonPlanDao dao= new LessonPlanDao ();
			status=dao.getByIdLessonPlan(lessonplanId,schoolId,branchId);
			 System.out.println(status);
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			//status1="user validation successfull";
			MDTransactionWriter.writeLog("sai","CMS","requester",startDate,endDate,sl,el,status,hsr.getRemoteHost());		
	}else
	{
		status="you are not authorised user";
	}
}
	catch(Exception localException)
	{
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
		status="failed in service layer";
		//System.out.println(localException);
	  }
 return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response getAllTopicsByLessonPlanId(int userID, int connectionID,String datastoreName,int lessonPlanId,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
	{	
			MDValidation mdv = new MDValidation();  
			int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
		   System.out.println("verifiedvalue::"+ret);
			if(ret==1 ){
			LessonPlanDao dao= new LessonPlanDao ();
			status=dao.getAllTopicsByLessonPlanId(lessonPlanId, schoolId, branchId);
			 System.out.println(status);
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			//status1="user validation successfull";
			MDTransactionWriter.writeLog(datastoreName,"CMS","requester",startDate,endDate,sl,el,status,hsr.getRemoteHost());		
	}else
	{
		status="you are not authorised user";
	}
}
	catch(Exception localException)
	{
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
		status="failed in service layer";
		//System.out.println(localException);
	  }
 return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}
}
	


