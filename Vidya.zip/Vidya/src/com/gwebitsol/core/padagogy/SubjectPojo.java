package com.gwebitsol.core.padagogy;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="Subject")
public class SubjectPojo {
	private int subjectId;
	private int subCategoryId;
	private int categoryId;
	private int textBookId;
	private int classId;
	private String curriculumId;
	private String description;
	private String remarks;
	private int schoolId;
	private int branchId;
	private int priority;
	private int sectionId;
	private int subjectTypeId;
	private int subWeekPeriods;
	
	public int getSubjectId() {
		return subjectId;
	}
	public void setSubjectId(int subjectId) {
		this.subjectId = subjectId;
	}
	public int getSubCategoryId() {
		return subCategoryId;
	}
	public void setSubCategoryId(int subCategoryId) {
		this.subCategoryId = subCategoryId;
	}
	public int getTextBookId() {
		return textBookId;
	}
	public void setTextBookId(int textBookId) {
		this.textBookId = textBookId;
	}
	public int getClassId() {
		return classId;
	}
	public void setClassId(int classId) {
		this.classId = classId;
	}
	public String getCurriculumId() {
		return curriculumId;
	}
	public void setCurriculumId(String curriculumId) {
		this.curriculumId = curriculumId;
	}
	
	public int getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	public int getSubjectTypeId() {
		return subjectTypeId;
	}
	public void setSubjectTypeId(int subjectTypeId) {
		this.subjectTypeId = subjectTypeId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public int getSchoolId() {
		return schoolId;
	}
	public void setSchoolId(int schoolId) {
		this.schoolId = schoolId;
	}
	public int getBranchId() {
		return branchId;
	}
	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}
	public int getPriority() {
		return priority;
	}
	public void setPriority(int priority) {
		this.priority = priority;
	}
	public int getSectionId() {
		return sectionId;
	}
	public void setSectionId(int sectionId) {
		this.sectionId = sectionId;
	}
	public int getSubWeekPeriods() {
		return subWeekPeriods;
	}
	public void setSubWeekPeriods(int subWeekPeriods) {
		this.subWeekPeriods = subWeekPeriods;
	}
		
}