package com.gwebitsol.core.padagogy;

import java.util.Iterator;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class RefBookDaoImpl {
	
	public String addRefTextBooks(ReferenceBookPojo referenceBookPojo) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
				String strg= null;
				 StringBuffer sb= new StringBuffer();
				try {
					tx = rdSession.beginTransaction();
				    Integer i=(Integer) rdSession.save(referenceBookPojo);
				   	System.out.println(i);
				   	tx.commit();
					    sb.append("<refTextBook>");
					    sb.append("\n");
					    sb.append("<reftextBookId>");
					    sb.append(i);
					    sb.append("</reftextBookId>");
						sb.append("\n");
						sb.append("</refTextBook>");
						strg= sb.toString();
						} catch (Exception localException) {
							System.out.println(localException);
							localException.printStackTrace();
					   sb.append("<Response>");
					   sb.append("\n");
					   sb.append("<Result>");
					   sb.append("\n");
					   sb.append("Fail");
					   sb.append("\n");
					   sb.append("</Result>");
					   sb.append("\n");
					   sb.append("<Description>");
					   sb.append("could not inserted reftextbook item");
					   sb.append("</Description>");
					   sb.append("\n");
					   sb.append("<Exception>");
					   sb.append(localException);
					   sb.append("</Exception>");
					   sb.append("</Response>");
					    strg=sb.toString();
					   MDTransactionWriter.exceptionlog.info(localException);
					  if (tx!=null)
					   tx.rollback();
					  } finally {
					   rdSession.close(); 
					  }
					  return strg;
					 }

	public String deleteRefTextBooks(int referencebookId,int schoolId,int branchId) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb=new StringBuffer();
		String strg= null;
		try {
				tx = rdSession.beginTransaction();
				/*ReferenceBookPojo rtb=new ReferenceBookPojo();
				rtb.setReferenceBookId(referencebookId);
				rdSession.delete(rtb);
				  tx.commit();*/
				ReferenceBookPojo rb = (ReferenceBookPojo) rdSession.get(ReferenceBookPojo.class,referencebookId);					   
				   rdSession.evict(rb);
				   if(branchId==rb.getBranchId()&&schoolId==rb.getSchoolId())
				   {
				   Query empQuery=rdSession.createSQLQuery("update gbl_sm_tbl_reference_book set isDeleted='y' where referenceBookId='"+referencebookId+"'");
				   empQuery.executeUpdate();
				   tx.commit();
				 strg="<delete></delete>";
				    sb.append("<refTextbook>");
				    sb.append("\n");
				    sb.append("<id>");
					sb.append("\n");
					sb.append("reftextbook item deleted");
					sb.append("</id>");
					sb.append("\n");
					sb.append("</refTextbook>");
					 strg= sb.toString();
		}else{
			   strg = " refTextbook is not deleted";
			   sb.append("<refTextbook>");
			   sb.append("\n");
			   sb.append(strg);
			   sb.append("</refTextbook>");
			    String str = sb.toString();
			    return str;
			   }
		}
		catch(Exception localException)
		{
			System.out.println(localException);
			localException.printStackTrace();
			sb.append("<Response>");
			   sb.append("\n");
			   sb.append("<Result>");
			   sb.append("\n");
			   sb.append("Fail");
			   sb.append("\n");
			   sb.append("</Result>");
			   sb.append("\n");
			   sb.append("<Description>");
			   sb.append("could not deleted reftextbook item");
			   sb.append("</Description>");
			   sb.append("\n");
			   sb.append("<Exception>");
			   sb.append(localException);
			   sb.append("</Exception>");
			   sb.append("</Response>");
			    strg=sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (tx!=null)
			   tx.rollback();
			  } finally {
			   rdSession.close(); 
			  }
			  return strg;
	}

	public String updateRefTextBooks(ReferenceBookPojo referenceBookPojo,int schoolId,int branchId) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb= new StringBuffer();
		String strg= null;
			try {
					tx = rdSession.beginTransaction();
					ReferenceBookPojo rb = (ReferenceBookPojo) rdSession.get(ReferenceBookPojo.class,referenceBookPojo.getReferenceBookId());
					rdSession.evict(rb);
					   if(schoolId==rb.getSchoolId()&&branchId==rb.getBranchId())
					   rdSession.update(referenceBookPojo);
					   tx.commit();
					    sb.append("<reftextbook>");
					    sb.append("\n");
					    sb.append("<reftextbookid>");
						sb.append("reftextbook succssfully updated");
						sb.append("</reftextbookid>");
						sb.append("\n");
						sb.append("</reftextbook>");
						strg= sb.toString();
						return strg;
				
				} 	catch (Exception localException) {
					System.out.println(localException);
					localException.printStackTrace();
			   sb.append("<Response>");
			   sb.append("\n");
			   sb.append("<Result>");
			   sb.append("\n");
			   sb.append("Fail");
			   sb.append("\n");
			   sb.append("</Result>");
			   sb.append("\n");
			   sb.append("<Description>");
			   sb.append("could not update reftextbook item");
			   sb.append("</Description>");
			   sb.append("\n");
			   sb.append("<Exception>");
			   sb.append(localException);
			   sb.append("</Exception>");
			   sb.append("</Response>");
			    strg=sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (tx!=null)
			   tx.rollback();
			  } finally {
			   rdSession.close(); 
			  }
			  return strg;
			 }
	
	@SuppressWarnings("rawtypes")
	public String getAllRefTextBooks(int PNO, int size,int schoolId,int branchId) {
				  String xmlString=null;
				  Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
				  Transaction stgTx=null;
				  StringBuffer sb = new StringBuffer();
				  try
				  {
				   stgTx=stgSession.beginTransaction();
				    int fset = (PNO-1)*size;
				    String gsSql ="select count(*) from gbl_sm_tbl_reference_book where isDeleted<>'y' or isDeleted is	null and schoolId='"+schoolId+"' and branchId='"+branchId+"' ";
				    Query gsQuery=stgSession.createSQLQuery(gsSql);
				    Object noRecords= gsQuery.uniqueResult();
				    sb.append("<reftextbooks>");
				    sb.append("\n");
				    sb.append("<noRecords>"+noRecords+"</noRecords>");
				    sb.append("\n");
				    
				     if (PNO > 0 & size > 0){
				     gsSql="SELECT rb.ReferenceBookId,rb.SubjectId,sub.SubjectName,rb.ReferenceBookName,rb.Author,rb.Publisher,"
				     		+ "rb.Description,rb.SchoolId,rb.BranchId FROM gbl_sm_tbl_reference_book as rb JOIN gbl_sm_tbl_subjects as sub ON "
				     		+ "sub.SubjectId=rb.SubjectId where rb.isDeleted<>'y' or rb.isDeleted is null and rb.schoolId='"+schoolId+"' and rb.branchId='"+branchId+"' limit "+size+" offset "+fset;
				     }
				     else {
				      gsSql="SELECT rb.ReferenceBookId,rb.SubjectId,sub.SubjectName,rb.ReferenceBookName,rb.Author,rb.Publisher,"
				     		+ "rb.Description,rb.SchoolId,rb.BranchId FROM gbl_sm_tbl_reference_book as rb JOIN gbl_sm_tbl_subjects as sub ON "
				     		+ "sub.SubjectId=rb.SubjectId where rb.isDeleted<>'y' or rb.isDeleted is null and rb.schoolId='"+schoolId+"' and rb.branchId='"+branchId+"'";
				     } 
				    
				    gsQuery=stgSession.createSQLQuery(gsSql);
				    List gcList=gsQuery.list();
				    Iterator gsIT=gcList.iterator();
				     while(gsIT.hasNext())
				     {
				      Object[] mdcArr=(Object[])gsIT.next();
				      sb.append("<reftextbook>");
				      sb.append("\n");
				      sb.append("<referenceBookId>"+mdcArr[0]+"</referenceBookId>");
				      sb.append("\n");
				      sb.append("<subjectId>" + mdcArr[1]+ "</subjectId>");
				      sb.append("\n");
				      sb.append("<subjectName>" + mdcArr[2]+ "</subjectName>");
				      sb.append("\n");
				      sb.append("<referenceBookName>" + mdcArr[3] + "</referenceBookName>");
				      sb.append("\n");
				      sb.append("<author>" + mdcArr[4]+ "</author>");
				      sb.append("\n");
				      sb.append("<publisher>" + mdcArr[5] + "</publisher>");
				      sb.append("\n");
				      sb.append("<description>" +  mdcArr[6]+ "</description>");
				      sb.append("\n");
				      sb.append("<schoolId>" + mdcArr[7] + "</schoolId>");
				      sb.append("\n");
				      sb.append("<branchId>" + mdcArr[8] + "</branchId>");
				      sb.append("\n");
				      
				      sb.append("</reftextbook>");
				     }
				    
				    stgTx.commit();
				    sb.append("</reftextbooks>");
				    sb.append("\n");

				    xmlString=sb.toString();
				   }
				   
		catch(Exception localException)
		{
			System.out.println(localException);
			localException.printStackTrace();
	   sb.append("<Response>");
	   sb.append("\n");
	   sb.append("<Result>");
	   sb.append("\n");
	   sb.append("Fail");
	   sb.append("\n");
	   sb.append("</Result>");
	   sb.append("\n");
	   sb.append("<Description>");
	   sb.append("could not all reftextbook item");
	   sb.append("</Description>");
	   sb.append("\n");
	   sb.append("<Exception>");
	   sb.append(localException);
	   sb.append("</Exception>");
	   sb.append("</Response>");
	    xmlString=sb.toString();
	   MDTransactionWriter.exceptionlog.info(localException);
	  if (stgTx!=null)
		  stgTx.rollback();
	  } finally {
	   stgSession.close(); 
	  }
	  return xmlString;
	 }
	

	@SuppressWarnings("rawtypes")
	public String getByIdRefTextBook(int referencebookId,int schoolId,int branchId) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb= new StringBuffer();
		String strg= null;
		
			try {
				tx = rdSession.beginTransaction();
				Query query=rdSession.createSQLQuery("SELECT rb.ReferenceBookId,rb.SubjectId,sub.SubjectName,rb.ReferenceBookName,rb.Author,rb.Publisher,"
				     		+ "rb.Description,rb.SchoolId,rb.BranchId FROM gbl_sm_tbl_reference_book as rb JOIN gbl_sm_tbl_subjects as sub ON "
				     		+ "sub.SubjectId=rb.SubjectId where rb.isDeleted<>'y' or rb.isDeleted is null and ReferenceBookId='"+referencebookId+"' and rb.schoolId='"+schoolId+"' and "
				     				+ "rb.branchId='"+branchId+"'");
			    List gcList=query.list();
			    Iterator gsIT=gcList.iterator();
			     while(gsIT.hasNext())
			     {
			      Object[] mdcArr=(Object[])gsIT.next();
			  
			      sb.append("<reftextbook>");
			      sb.append("\n");
			      sb.append("<referenceBookId>"+mdcArr[0]+"</referenceBookId>");
			      sb.append("\n");
			      sb.append("<subjectId>" + mdcArr[1]+ "</subjectId>");
			      sb.append("\n");
			      sb.append("<subjectName>" + mdcArr[2]+ "</subjectName>");
			      sb.append("\n");
			      sb.append("<referenceBookName>" + mdcArr[3] + "</referenceBookName>");
			      sb.append("\n");
			      sb.append("<author>" + mdcArr[4]+ "</author>");
			      sb.append("\n");
			      sb.append("<publisher>" + mdcArr[5] + "</publisher>");
			      sb.append("\n");
			      sb.append("<description>" +  mdcArr[6]+ "</description>");
			      sb.append("\n");
			      sb.append("<schoolId>" + mdcArr[7] + "</schoolId>");
			      sb.append("\n");
			      sb.append("<branchId>" + mdcArr[8] + "</branchId>");
			      sb.append("\n");
			      sb.append("</reftextbook>");
					String str= sb.toString();
					return str;
			}
			
					
			} 	catch (Exception localException) {
				System.out.println(localException);
				localException.printStackTrace();
		   sb.append("<Response>");
		   sb.append("\n");
		   sb.append("<Result>");
		   sb.append("\n");
		   sb.append("Fail");
		   sb.append("\n");
		   sb.append("</Result>");
		   sb.append("\n");
		   sb.append("<Description>");
		   sb.append("could not single ref textbook item");
		   sb.append("</Description>");
		   sb.append("\n");
		   sb.append("<Exception>");
		   sb.append(localException);
		   sb.append("</Exception>");
		   sb.append("</Response>");
		    strg=sb.toString();
		   MDTransactionWriter.exceptionlog.info(localException);
		  if (tx!=null)
		   tx.rollback();
		  } finally {
		   rdSession.close(); 
		  }
		  return strg;
		 }
}
	
