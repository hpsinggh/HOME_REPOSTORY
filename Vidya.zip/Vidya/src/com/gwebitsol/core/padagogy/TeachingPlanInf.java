package com.gwebitsol.core.padagogy;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

@Path("/teachingplan")
public interface TeachingPlanInf {
	@GET
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/get")
	public Response getTeachingPlan(@QueryParam("startdate") String startdate,@QueryParam("enddate") String enddate,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);
	@GET
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/teachingplantopics")
	public Response getTeachingPlanTopics(@QueryParam("PNO") int PNO,@QueryParam("size") int size, @QueryParam("settings") String settings,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);

	@GET
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/gettimetable")
	public Response getTimETableByPeriods(@QueryParam("days") String days,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);

	@GET
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/getall")
	public Response getallTeachingPlans(@QueryParam("subjectid") int subjectid,@QueryParam("startdate") String startdate,@QueryParam("enddate") String enddate,@QueryParam("classid") int classid ,@QueryParam("sectionid") int sectionid,@QueryParam("employeeid") int employeeid,@QueryParam("userid") int userid,@QueryParam("connectionid") 
	int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("PNO") int PNO,@QueryParam("size") int size, @QueryParam("teachingplans") String teachingplans,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);

}


