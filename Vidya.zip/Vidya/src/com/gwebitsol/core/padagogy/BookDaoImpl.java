package com.gwebitsol.core.padagogy;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;
@Repository
@Component
public class BookDaoImpl {

	public String addTextBooks(TextBook textbook) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
				String strg= null;
				 StringBuffer sb= new StringBuffer();
				try {
					tx = rdSession.beginTransaction();
				    Integer i=(Integer) rdSession.save(textbook);
					System.out.println(i);
				   	tx.commit();
				   		sb.append("<TextBook>");
					    sb.append("\n");
					    sb.append("<textBookId>");
					    sb.append(i);
					    sb.append("</textBookId>");
						sb.append("\n");
						sb.append("</TextBook>");
						strg= sb.toString();
						} 
				catch (Exception localException) {
							System.out.println(localException);
	 						localException.printStackTrace();
						   sb.append("<Response>");
						   sb.append("\n");
						   sb.append("<Result>");
						   sb.append("\n");
						   sb.append("Fail");
						   sb.append("\n");
						   sb.append("</Result>");
						   sb.append("\n");
						   sb.append("<Description>");
						   sb.append("could not inserted textbook info");
						   sb.append("</Description>");
						   sb.append("\n");
						   sb.append("<Exception>");
						   sb.append(localException);
						   sb.append("</Exception>");
						   sb.append("</Response>");
						    strg=sb.toString();
						   MDTransactionWriter.exceptionlog.info(localException);
						  if (tx!=null)
						   tx.rollback();
						  } finally {
						   rdSession.close(); 
						  }
						  return strg;
						 }

	public String deleteTextBooks(int textbookId,int schoolId,int branchId) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb=new StringBuffer();
		String strg= null;
		try {
				tx = rdSession.beginTransaction();
			/*TextBook tb=new TextBook();
				tb.setTextBookId(id);
				rdSession.delete(tb);
				tx.commit();*/
				TextBook tb = (TextBook) rdSession.get(TextBook.class,textbookId);
				   
				   rdSession.evict(tb);
				   
				   if(branchId==tb.getBranchId()&&schoolId==tb.getSchoolId())
				   {
				   Query empQuery=rdSession.createSQLQuery("update gbl_sm_tbl_textbook set isDeleted='y' where textbookId='"+textbookId+"'");
				   empQuery.executeUpdate();
				   tx.commit();				
				 strg="<delete></delete>";
				    sb.append("<Textbook>");
				    sb.append("\n");
				    sb.append("<id>");
					sb.append("\n");
					sb.append("textbook item deleted");
					sb.append("</id>");
					sb.append("\n");
					sb.append("</Textbook>");
					strg= sb.toString();
				   }
		}
		catch(Exception localException)
		{
			System.out.println(localException);
				localException.printStackTrace();
		   sb.append("<Response>");
		   sb.append("\n");
		   sb.append("<Result>");
		   sb.append("\n");
		   sb.append("Fail");
		   sb.append("\n");
		   sb.append("</Result>");
		   sb.append("\n");
		   sb.append("<Description>");
		   sb.append("could not deleted textbook item");
		   sb.append("</Description>");
		   sb.append("\n");
		   sb.append("<Exception>");
		   sb.append(localException);
		   sb.append("</Exception>");
		   sb.append("</Response>");
		    strg=sb.toString();
		   MDTransactionWriter.exceptionlog.info(localException);
		  if (tx!=null)
		   tx.rollback();
		  } finally {
		   rdSession.close(); 
		  }
		  return strg;
		 }

	public String updateTextBooks(TextBook textbook,int schoolId,int branchId) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb= new StringBuffer();
		String strg= null;
			try {
					tx = rdSession.beginTransaction();
					/*rdSession.update(textbook);
					  tx.commit();*/
					TextBook tb = (TextBook) rdSession.get(TextBook.class,textbook.getTextBookId());
					   
					   if(branchId==tb.getBranchId()&&schoolId==tb.getSchoolId())
					    
					   rdSession.evict(tb);
					   
					   rdSession.update(textbook);
					     
					   tx.commit();
					    sb.append("<textbook>");
					    sb.append("\n");
					    sb.append("<textbookid>");
						sb.append("\n");
						sb.append("textbook succssfully updated");
						sb.append("</textbookid>");
						sb.append("\n");
						sb.append("</textbook>");
						 strg= sb.toString();
				} 	catch (Exception localException) {
					System.out.println(localException);
					localException.printStackTrace();
			   sb.append("<Response>");
			   sb.append("\n");
			   sb.append("<Result>");
			   sb.append("\n");
			   sb.append("Fail");
			   sb.append("\n");
			   sb.append("</Result>");
			   sb.append("\n");
			   sb.append("<Description>");
			   sb.append("could not update textbook item");
			   sb.append("</Description>");
			   sb.append("\n");
			   sb.append("<Exception>");
			   sb.append(localException);
			   sb.append("</Exception>");
			   sb.append("</Response>");
			    strg=sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (tx!=null)
			   tx.rollback();
			  } finally {
			   rdSession.close(); 
			  }
			  return strg;
			 }	

	@SuppressWarnings("rawtypes")
	public String getByIdTextBook(int textbookId,int schoolId,int branchId) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb= new StringBuffer();
		System.out.println("hi dao impl success");
		String strg= null;
			try {
					tx = rdSession.beginTransaction();
					Query query=rdSession.createSQLQuery("SELECT tx.TextBookId,tx.TextBookName,tx.Author,tx.Publisher,tx.Description,tx.SchoolId,tx.BranchId from gbl_sm_tbl_textbook tx where (tx.isDeleted<>'y' or tx.isDeleted is null) and tx.TextBookId='"+textbookId+"' and tx.schoolId='"+schoolId+"' and tx.branchId='"+branchId +"' ");
					    List gcList=query.list();
					    Iterator gsIT=gcList.iterator();
					     while(gsIT.hasNext())
					     {
					      Object[] mdcArr=(Object[])gsIT.next();					  
					      //textbookId=(Integer)mdcArr[0];
					      
					     String gsSql="SELECT sub.SubjectId,sub.SubjectTypeId,subtype.SubjectName,sub.ClassId,cls.ClassName,sub.SectionId,sec.SectionName FROM gbl_sm_tbl_textbook as tx, gbl_sm_tbl_subjects as sub, gbl_sm_tbl_class as cls, gbl_sm_tbl_section as sec,gbl_sm_tbl_subject_type as subtype where tx.isDeleted<>'y' or tx.isDeleted is null and sub.TextBookId='"+textbookId+"' and sub.ClassId=cls.ClassId and sub.SectionId=sec.SectionId and subtype.SubjectTypeId=sub.SubjectTypeId and tx.schoolId='"+schoolId+"' and tx.branchId='"+branchId +"'";
					     query=rdSession.createSQLQuery(gsSql);
						    List gcListSub=query.list();
						    Iterator gsITSub=gcListSub.iterator();
					      sb.append("<textbook>");
					      sb.append("\n");
					      sb.append("<textBookId>"+textbookId+"</textBookId>");
					      sb.append("\n");
					      while(gsITSub.hasNext())
					      {
					      Object[] subArr=(Object[])gsITSub.next();
					      sb.append("<subjectId>" + subArr[0]+ "</subjectId>");
					      sb.append("\n");
					      sb.append("<subjectTypeId>" + subArr[1]+ "</subjectTypeId>");
					      sb.append("\n");
					      sb.append("<subjectName>" + subArr[2]+ "</subjectName>");
					      sb.append("\n");
					      sb.append("<classId>" + subArr[3] + "</classId>");
					      sb.append("\n");
					      sb.append("<className>" + subArr[4]+ "</className>");
					      sb.append("\n");
					      sb.append("<sectionId>" + subArr[5]+ "</sectionId>");
					      sb.append("\n");
					      sb.append("<sectionName>" + subArr[6] + "</sectionName>");
					      sb.append("\n");	
					      break;
					      }
					      sb.append("<textBookName>" + mdcArr[1]+ "</textBookName>");
					      sb.append("\n");
					      sb.append("<author>" + mdcArr[2]+ "</author>");
					      sb.append("\n");
					      sb.append("<publisher>" + mdcArr[3] + "</publisher>");
					      sb.append("\n");
					      sb.append("<description>" + mdcArr[4]+ "</description>");
					      sb.append("\n");
					      sb.append("<schoolId>" + mdcArr[5] + "</schoolId>");
					      sb.append("\n");
					      sb.append("<branchId>" + mdcArr[6] + "</branchId>");
					      sb.append("\n");
					      sb.append("</textbook>");
					     
						
							String str= sb.toString();
							return str;
					}
	
			} 	catch (Exception localException) {
				System.out.println(localException);
				localException.printStackTrace();
		   sb.append("<Response>");
		   sb.append("\n");
		   sb.append("<Result>");
		   sb.append("\n");
		   sb.append("Fail");
		   sb.append("\n");
		   sb.append("</Result>");
		   sb.append("\n");
		   sb.append("<Description>");
		   sb.append("could not single textbook item");
		   sb.append("</Description>");
		   sb.append("\n");
		   sb.append("<Exception>");
		   sb.append(localException);
		   sb.append("</Exception>");
		   sb.append("</Response>");
		    strg=sb.toString();
		   MDTransactionWriter.exceptionlog.info(localException);
		  if (tx!=null)
		   tx.rollback();
		  } finally {
		   rdSession.close(); 
		  }
		  return strg;
		 }
	
	@SuppressWarnings("rawtypes")
	public String getAllTextBooks(int PNO, int size,int schoolId,int branchId,int classId,int sectionId,int subjectTypeId) {
		  
		  String xmlString=null;
		  Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		  Transaction stgTx=null;
		  StringBuffer sb = new StringBuffer();
		  try
		  {
		   stgTx=stgSession.beginTransaction();
		    int fset = (PNO-1)*size;
		    String filterWhere="";
		    String subInnerQuery=" and TextBookId in (select TextBookId from gbl_sm_tbl_subjects as sub where (sub.isDeleted<>'y' or sub.isDeleted is null) ";
		    boolean isFlterExist=false;
		    if(classId!=0){									  								    	
		    	subInnerQuery+=" and sub.ClassId="+classId;			    	
			if(sectionId!=0){
				subInnerQuery +=  " and sub.SectionId="+sectionId;
			
			}
			isFlterExist=true;
			}
		    if(subjectTypeId!=0){
		    	subInnerQuery += " and sub.SubjectTypeId="+subjectTypeId;
		    	isFlterExist=true;
		    	}
		    if(isFlterExist){
		    	filterWhere=subInnerQuery+")";
		    }
		    String gsSql ="select count(*) from gbl_sm_tbl_textbook tx where (tx.isDeleted<>'y' or tx.isDeleted is null)  and tx.schoolId='"+schoolId+"' and tx.branchId='"+branchId+"'"+filterWhere+" ";		    
		    Query gsQuery=stgSession.createSQLQuery(gsSql);
		    Object noRecords= gsQuery.uniqueResult();
		    int intNoRecords=0;
			if(noRecords!=null && Integer.parseInt(noRecords.toString())!=0)
			{
				intNoRecords=Integer.parseInt(noRecords.toString());
			}
		    sb.append("<textbooks>");
		    sb.append("\n");
		    sb.append("<noRecords>"+noRecords+"</noRecords>");
		    sb.append("\n");
		    if(intNoRecords!=0)
			{
		     if (PNO > 0 & size > 0){
		     gsSql="SELECT  tx.TextBookId,tx.TextBookName,tx.Author,tx.Publisher,tx.Description,tx.SchoolId,tx.BranchId from gbl_sm_tbl_textbook tx where (tx.isDeleted<>'y' or tx.isDeleted is null)  and tx.schoolId='"+schoolId+"' and tx.branchId='"+branchId+"'"+filterWhere+" limit "+size+" offset "+fset;
		     }
		     else {
		      gsSql="SELECT tx.TextBookId,tx.TextBookName,tx.Author,tx.Publisher,tx.Description,tx.SchoolId,tx.BranchId from gbl_sm_tbl_textbook tx where (tx.isDeleted<>'y' or tx.isDeleted is null)  and tx.schoolId='"+schoolId+"' and tx.branchId='"+branchId+"'"+filterWhere+" ";
		     } 
		   
		    gsQuery=stgSession.createSQLQuery(gsSql);
		    List gcList=gsQuery.list();
		    Iterator gsIT=gcList.iterator();
		    int textbookId=0;
		     while(gsIT.hasNext())
		     {
		      Object[] mdcArr=(Object[])gsIT.next();
		      textbookId=(Integer)mdcArr[0];
		      
		      gsSql="SELECT sub.SubjectId,sub.SubjectTypeId,subtype.SubjectName,sub.ClassId,cls.ClassName,sub.SectionId,sec.SectionName FROM gbl_sm_tbl_textbook as tx, gbl_sm_tbl_subjects as sub, gbl_sm_tbl_class as cls, gbl_sm_tbl_section as sec,gbl_sm_tbl_subject_type as subtype where tx.isDeleted<>'y' or tx.isDeleted is null and sub.TextBookId='"+textbookId+"' and sub.ClassId=cls.ClassId and sub.SectionId=sec.SectionId and subtype.SubjectTypeId=sub.SubjectTypeId and tx.schoolId='"+schoolId+"' and tx.branchId='"+branchId +"'";
		      gsQuery=stgSession.createSQLQuery(gsSql);
			    List gcListSub=gsQuery.list();
			    Iterator gsITSub=gcListSub.iterator();
		      sb.append("<textbook>");
		      sb.append("\n");
		      sb.append("<textBookId>"+textbookId+"</textBookId>");
		      sb.append("\n");
		      while(gsITSub.hasNext())
		      {
		      Object[] subArr=(Object[])gsITSub.next();
		      sb.append("<subjectId>" + subArr[0]+ "</subjectId>");
		      sb.append("\n");
		      sb.append("<subjectTypeId>" + subArr[1]+ "</subjectTypeId>");
		      sb.append("\n");
		      sb.append("<subjectName>" + subArr[2]+ "</subjectName>");
		      sb.append("\n");
		      sb.append("<classId>" + subArr[3] + "</classId>");
		      sb.append("\n");
		      sb.append("<className>" + subArr[4]+ "</className>");
		      sb.append("\n");
		      sb.append("<sectionId>" + subArr[5]+ "</sectionId>");
		      sb.append("\n");
		      sb.append("<sectionName>" + subArr[6] + "</sectionName>");
		      sb.append("\n");	
		      break;
		      }
		      sb.append("<textBookName>" + mdcArr[1]+ "</textBookName>");
		      sb.append("\n");
		      sb.append("<author>" + mdcArr[2]+ "</author>");
		      sb.append("\n");
		      sb.append("<publisher>" + mdcArr[3] + "</publisher>");
		      sb.append("\n");
		      sb.append("<description>" + mdcArr[4]+ "</description>");
		      sb.append("\n");
		      sb.append("<schoolId>" + mdcArr[5] + "</schoolId>");
		      sb.append("\n");
		      sb.append("<branchId>" + mdcArr[6] + "</branchId>");
		      sb.append("\n");
		      sb.append("</textbook>");
		     }
			}
		    stgTx.commit();
		    sb.append("</textbooks>");
		    sb.append("\n");
		    xmlString=sb.toString();
		  } 
		  catch(Exception localException)
		  {
			  System.out.println(localException);
				localException.printStackTrace();
		   sb.append("<Response>");
		   sb.append("\n");
		   sb.append("<Result>");
		   sb.append("\n");
		   sb.append("Fail");
		   sb.append("\n");
		   sb.append("</Result>");
		   sb.append("\n");
		   sb.append("<Description>");
		   sb.append("could not single textbook item");
		   sb.append("</Description>");
		   sb.append("\n");
		   sb.append("<Exception>");
		   sb.append(localException);
		   sb.append("</Exception>");
		   sb.append("</Response>");
		   xmlString=sb.toString();
		   MDTransactionWriter.exceptionlog.info(localException);
		  if (stgTx!=null)
			  stgTx.rollback();
		  } finally {
			  stgSession.close(); 
		  }
		  return xmlString;

		 }
}
	
	


