package com.gwebitsol.core.padagogy;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

 @Path("/textbook")
public interface BookServiceInf {

	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	 @Path("/add")
	public Response addTextBooks(TextBook textbook,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);

	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	 @Path("/delete")
	public Response deleteTextBooks(@QueryParam("textbookId") int textbookId,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);
	
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	 @Path("/update")
	public Response updateTextBooks(TextBook textbook,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);
	
	@GET
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	 @Path("/getall")
    public Response getAllTextBooks(@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("PNO") int PNO, @QueryParam("size") int size,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId,@QueryParam("classId") int classId,@QueryParam("sectionId") int sectionId,@QueryParam("subjectTypeId") int subjectTypeId);
	
	@GET
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	 @Path("/getbyid")
	public Response getByIdTextBook( @QueryParam("textbookId") int textbookId,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);
}

