package com.gwebitsol.core.padagogy;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.gwebitsol.core.security.MDValidation;
import com.gwebitsol.core.usermanagement.MDGetUserFromID;
import com.gwebitsol.core.util.MDTransactionWriter;

public class TeachingPlanServiceImpl implements TeachingPlanInf {
	@Context 
	private HttpServletRequest hsr;
	public Response getTeachingPlan( String startdate,String enddate, int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String status1=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try{
			MDValidation mdv = new MDValidation();  
			  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			   System.out.println("verifiedvalue::"+ret);
			   
			   MDGetUserFromID mdgufid = new MDGetUserFromID();
			   String requester = mdgufid.getUserName(userID);
			if(ret==1 )//&& rtVal==1)
			{
			TeachingPlanDao dao=new TeachingPlanDao();
			status1=dao.getTeachingPlan(startdate,enddate);
			System.out.println(status1);
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			MDTransactionWriter.writeLog(datastoreName,"TeachingPlanServiceImpl_getTeachingPlan",requester,startDate,endDate,sl,el,status1,hsr.getRemoteHost());
			}
				else
				{
					status1="you are not authorised user";
				}
		}catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			status1="failed in service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status1).build();
	}

	/**/
	public Response getTeachingPlanTopics( int PNO,int size, String settings,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String status1=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try{
			MDValidation mdv = new MDValidation();  
			  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			   System.out.println("verifiedvalue::"+ret);
			   
			   MDGetUserFromID mdgufid = new MDGetUserFromID();
			   String requester = mdgufid.getUserName(userID);
			if(ret==1 )//&& rtVal==1)
			{
			TeachingPlanDao dao=new TeachingPlanDao();
			status1=dao.getTeachingPlanTopics(PNO, size, settings);
			System.out.println(status1);
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			MDTransactionWriter.writeLog(datastoreName,"TeachingPlanServiceImpl_getTeachingPlanTopics",requester,startDate,endDate,sl,el,status1,hsr.getRemoteHost());		
			}
				else
				{
					status1="you are not authorised user";
				}}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			status1="failed in service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status1).build();
	}

	public Response getTimETableByPeriods(String days,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String status1=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try{
			MDValidation mdv = new MDValidation();  
			  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			   System.out.println("verifiedvalue::"+ret);
			   
			   MDGetUserFromID mdgufid = new MDGetUserFromID();
			   String requester = mdgufid.getUserName(userID);
			if(ret==1 )//&& rtVal==1)
			{
			TeachingPlanDao dao=new TeachingPlanDao();
			status1=dao.getTimETableByPeriods(days);
			System.out.println(status1);
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
				MDTransactionWriter.writeLog(datastoreName,"TeachingPlanServiceImpl_getTimETableByPeriods",requester,startDate,endDate,sl,el,status1,hsr.getRemoteHost());		
			}
				else
				{
					status1="you are not authorised user";
				}
		}catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			status1="failed in service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status1).build();
	}

	public Response getallTeachingPlans(int subjectid, String startdate, String enddate, int classid, int sectionid,
			int employeeid, int userID, int connectionID, String datastoreName, int PNO, int size,
			String teachingplans,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String status1=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try{
			MDValidation mdv = new MDValidation();  
			  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			   System.out.println("verifiedvalue::"+ret);
			   
			   MDGetUserFromID mdgufid = new MDGetUserFromID();
			   String requester = mdgufid.getUserName(userID);
			if(ret==1 )//&& rtVal==1)
			{
			TeachingPlanDao dao=new TeachingPlanDao();
			status1=dao.getallTeachingPlans(startdate,enddate,classid,employeeid,sectionid,subjectid,PNO,size,teachingplans);
			System.out.println(status1);
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
				MDTransactionWriter.writeLog(datastoreName,"TeachingPlanServiceImpl_getallTeachingPlans",requester,startDate,endDate,sl,el,status1,hsr.getRemoteHost());		
			}
				else
				{
					status1="you are not authorised user";
				}
		}catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			status1="failed in service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status1).build();
	}
}
