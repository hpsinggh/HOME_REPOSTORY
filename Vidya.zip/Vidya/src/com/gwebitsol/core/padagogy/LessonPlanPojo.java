package com.gwebitsol.core.padagogy;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="LessonPlan")
public class LessonPlanPojo {
	private int lessonPlanId;
	private int employeeId;
	private String lessonPlanName;
	private String startDate;
	private String endDate;
	private String lessonPlanDescription;
	private String lessonPlanStatus;
	private int schoolId;
	private int branchId;
	private int classId;
	private int subjectId;
	private String topicId;
	private String createdDate;
	DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	Date date = new Date();
	String modifiedDate=dateFormat.format(date);
	
	
	public String getTopicId() {
		return topicId;
	}
	public void setTopicId(String topicId) {
		this.topicId = topicId;
	}
	public int getClassId() {
		return classId;
	}
	public void setClassId(int classId) {
		this.classId = classId;
	}
	public int getSubjectId() {
		return subjectId;
	}
	public void setSubjectId(int subjectId) {
		this.subjectId = subjectId;
	}
	

	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public int getLessonPlanId() {
		return lessonPlanId;
	}
	public void setLessonPlanId(int lessonPlanId) {
		this.lessonPlanId = lessonPlanId;
	}
	public String getLessonPlanName() {
		return lessonPlanName;
	}
	public void setLessonPlanName(String lessonPlanName) {
		this.lessonPlanName = lessonPlanName;
	}
	public String getLessonPlanDescription() {
		return lessonPlanDescription;
	}
	public void setLessonPlanDescription(String lessonPlanDescription) {
		this.lessonPlanDescription = lessonPlanDescription;
	}
	public String getLessonPlanStatus() {
		return lessonPlanStatus;
	}
	public void setLessonPlanStatus(String lessonPlanStatus) {
		this.lessonPlanStatus = lessonPlanStatus;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public int getSchoolId() {
		return schoolId;
	}
	public void setSchoolId(int schoolId) {
		this.schoolId = schoolId;
	}
	public int getBranchId() {
		return branchId;
	}
	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}

}
