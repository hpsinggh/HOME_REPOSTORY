package com.gwebitsol.core.padagogy;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="ReferenceBook")
public class ReferenceBookPojo {
	private int referenceBookId;
	private int subjectId;
	private String  referenceBookName;
	private String  author;
	private String publisher;
	private String description;
	private int schoolId;
	private int branchId;
	
	public int getReferenceBookId() {
		return referenceBookId;
	}
	public void setReferenceBookId(int referenceBookId) {
		this.referenceBookId = referenceBookId;
	}
	public int getSubjectId() {
		return subjectId;
	}
	public void setSubjectId(int subjectId) {
		this.subjectId = subjectId;
	}
	public String getReferenceBookName() {
		return referenceBookName;
	}
	public void setReferenceBookName(String referenceBookName) {
		this.referenceBookName = referenceBookName;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getPublisher() {
		return publisher;
	}
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getSchoolId() {
		return schoolId;
	}
	public void setSchoolId(int schoolId) {
		this.schoolId = schoolId;
	}
	public int getBranchId() {
		return branchId;
	}
	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}
	
}
