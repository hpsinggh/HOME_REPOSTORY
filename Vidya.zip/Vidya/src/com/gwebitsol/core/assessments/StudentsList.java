package com.gwebitsol.core.assessments;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement(name="Students")
public class StudentsList {
	List<StudentPojo> studentPojo;

	public List<StudentPojo> getStudentPojo() {
		return studentPojo;
	}

	public void setStudentPojo(List<StudentPojo> studentPojo) {
		this.studentPojo = studentPojo;
	}
	

}
