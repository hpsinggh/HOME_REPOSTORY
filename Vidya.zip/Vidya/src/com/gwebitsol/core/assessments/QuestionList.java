package com.gwebitsol.core.assessments;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="Questions")
public class QuestionList {
	List<QuestionsPaperSectionPojo> questionsPaperSectionPojo;

	public List<QuestionsPaperSectionPojo> getQuestionsPaperSectionPojo() {
		return questionsPaperSectionPojo;
	}

	public void setQuestionsPaperSectionPojo(List<QuestionsPaperSectionPojo> questionsPaperSectionPojo) {
		this.questionsPaperSectionPojo = questionsPaperSectionPojo;
	}
	
}
