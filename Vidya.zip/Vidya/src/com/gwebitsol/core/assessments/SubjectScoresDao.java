package com.gwebitsol.core.assessments;

import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.infrastructure.FieldPojo;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class SubjectScoresDao {
	Session addempSession=MDHibernateUtil.getSessionFactory().openSession();
	Transaction addempTx=null;
	public String addSubjectScores(SubjectScoresPojo ssp) {
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			addempTx=addempSession.beginTransaction();
			Integer in=(Integer)addempSession.save(ssp);
			System.out.println(in);
			addempTx.commit();
			sb.append("<SubjectScores>");
			sb.append("\n");
			sb.append("<SubjectScoresid>");
			sb.append(in);
			sb.append("</SubjectScoresid>");
			sb.append("</SubjectScores>");
			outStr=sb.toString();
   		 	}
		
		catch(Exception localException)
		{
			System.out.println(localException);
			
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    sb.append("could not inserted SubjectScores info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    outStr= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (addempTx!=null)
				  addempTx.rollback();
		}
		finally
		{			
			addempSession.close();
		}
		return outStr;
	}

	public String updateSubjectScores(SubjectScoresPojo ssp,int schoolId,int branchId) {
		Session upempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction upempTx=null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			upempTx=upempSession.beginTransaction();
			SubjectScoresPojo field = (SubjectScoresPojo) upempSession.get(SubjectScoresPojo.class,ssp.getSubjectScoreId());
			upempSession.evict(field);
			if(branchId==field.getBranchId()&&schoolId==field.getSchoolId())
			upempSession.update(ssp);
			upempTx.commit();
			sb.append("<SubjectScores>");
			sb.append("\n");
			sb.append("update sucessfully");
			sb.append("</SubjectScores>");
			String str=sb.toString();
			return str;
   		 	}
		
		catch(Exception localException)
		{
			System.out.println(localException);
			
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    
			    sb.append("could not update SubjectScores info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    outStr= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (upempTx!=null)
				  upempTx.rollback();
		}
		finally
		{			
			upempSession.close();
		}
		return outStr;
	}

	public String deleteSubjectScores(int subjectScoreId,int schoolId,int branchId) {
		Session delempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction delempTx=null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			delempTx=delempSession.beginTransaction();
			
			SubjectScoresPojo subjectscore = (SubjectScoresPojo) delempSession.get(SubjectScoresPojo.class,subjectScoreId);
			   
			   int branid = subjectscore.getBranchId();
			   int sclid = subjectscore.getSchoolId();
			   delempSession.evict(subjectscore);         
			   if(branchId==branid&&schoolId==sclid)
			   {
			Query empQuery=delempSession.createSQLQuery("update gbl_sm_tbl_subject_scores set IsDeleted ='Y' where subjectScoreId='"+subjectScoreId+"'");
			empQuery.executeUpdate();
			delempTx.commit();
			sb.append("<SubjectScores>");
			sb.append("\n");
			sb.append("deleted sucessfully");
			sb.append("</SubjectScores>");
			String str=sb.toString();
			return str;
   		 	}
			}
		catch(Exception localException)
		{
			System.out.println(localException);
			
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    
			    sb.append("could not delete SubjectScores info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    outStr= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (delempTx!=null)
				  delempTx.rollback();
		}
		finally
		{			
			delempSession.close();
		}
		return outStr;
	}

	public String getBySubjectScoresId(int subjectScoreId,int schoolId,int branchId) {
		Session gtempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gtTx=null;
			StringBuffer sb= new StringBuffer();
			System.out.println("hi dao impl success");
			String strg= null;
				try {
					gtTx = gtempSession.beginTransaction();
					List list=gtempSession.createSQLQuery("SELECT s.SubjectScoreId,s.SubjectId,su.SubjectName,s.StudentId,st.StudentNumber,st.FirstName,st.MiddleName,st.LastName,s.SubjectScore,s.SchoolId,s.BranchId from gbl_sm_tbl_subject_scores s join gbl_sm_tbl_subjects su join gbl_sm_tbl_student st on s.SubjectId = su.SubjectId and s.StudentId = st.StudentId where SubjectScoreId='" + subjectScoreId + "' and s.SchoolId ='" + schoolId + "'  and s.BranchId ='" + branchId + "' ;").list();
				     Iterator it=list.iterator();
				    		    sb.append("<SubjectScore>");
						        sb.append("\n");
						        while(it.hasNext())
						        {
								Object[] ex=(Object[])it.next();
						        sb.append("<subjectScoreId>");
							    sb.append(ex[0]);
							    sb.append("</subjectScoreId>");
							    sb.append("\n");
							    sb.append("<subjectId>");
							    sb.append(ex[1]);
							    sb.append("</subjectId>");
							    sb.append("\n");
							    sb.append("<subjectName>");
								sb.append(ex[2]);
								sb.append("</subjectName>");
								 sb.append("\n");
								sb.append("<studentId>");
								sb.append(ex[3]);
								sb.append("</studentId>");
								 sb.append("\n");
								sb.append("<studentNumber>");
								sb.append(ex[4]);
								sb.append("</studentNumber>");
								sb.append("\n");
								sb.append("<firstName>");
								sb.append(ex[5]);
								sb.append("</firstName>");
								sb.append("\n");
								sb.append("<middleName>");
								sb.append(ex[6]);
								sb.append("</middleName>");
								sb.append("\n");
								sb.append("<lastName>");
							    sb.append(ex[7]);
							    sb.append("</lastName>");
							    sb.append("\n");
							    sb.append("<subjectScore>");
							    sb.append(ex[8]);
							    sb.append("</subjectScore>");
							    sb.append("\n");
								sb.append("<schoolId>");
								sb.append(ex[9]);
								sb.append("</schoolId>");
								sb.append("\n");
								sb.append("<branchId>");
								sb.append(ex[10]);
								sb.append("</branchId>");
								sb.append("\n");
						        }
								sb.append("</SubjectScore>");
							    strg= sb.toString();
				} 	catch (Exception localException) {
					System.out.println(localException);
					   sb.append("<Response>");
					    sb.append("\n");
					    sb.append("<Result>");
					    sb.append("\n");
					    sb.append("Fail");
					    sb.append("\n");
					    sb.append("</Result>");
					    sb.append("\n");
					    sb.append("<Description>");
					    sb.append("could not getbyid SubjectScores info");
					    sb.append("</Description>");
					    sb.append("\n");
					    sb.append("<Exception>");
					    sb.append(localException);
					    sb.append("</Exception>");
					    sb.append("</Response>");
					    sb.append("</subjectScoreId>");
					    sb.append("</SubjectScores>");
					    strg= sb.toString();
					   MDTransactionWriter.exceptionlog.info(localException);
					  if (gtTx!=null)
						  gtTx.rollback();
					} finally {
						gtempSession.close();
					}
			return strg;
	}

	public String getAllSubjectScores(int PNO, int size,int schoolId,int branchId) {
		Session rdSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb= new StringBuffer();
		String string=null;
		//SubjectScoresPojo ex=null;
		
		try
		{
			tx = rdSession.beginTransaction();
			
			if(("all") != null)
			   {
			    int fset = (PNO-1)*size;
			    String gsSql ="select count(*) from gbl_sm_tbl_subject_scores as s where s.IsDeleted <> 'Y' or s.IsDeleted IS NULL and s.SchoolId ='" + schoolId + "'  and s.BranchId ='" + branchId + "'";
			    Query gsQuery=rdSession.createSQLQuery(gsSql);
			    Object noRecords= gsQuery.uniqueResult();
			    sb.append("<SubjectScores>");
			    sb.append("\n");
			    sb.append("<noRecords>"+noRecords+"</noRecords>");
			    sb.append("\n");
			    
			     if (PNO > 0 & size > 0){
			     gsSql="SELECT s.SubjectScoreId,s.SubjectId,su.SubjectName,s.StudentId,st.StudentNumber,st.FirstName,st.MiddleName,st.LastName,s.SubjectScore,s.SchoolId,s.BranchId from gbl_sm_tbl_subject_scores s join gbl_sm_tbl_subjects su join gbl_sm_tbl_student st on s.SubjectId = su.SubjectId and s.StudentId = st.StudentId and s.SchoolId ='" + schoolId + "'  and s.BranchId ='" + branchId + "' limit "+size+" offset "+fset;}
			     else {
			      gsSql="SELECT s.SubjectScoreId,s.SubjectId,su.SubjectName,s.StudentId,st.StudentNumber,st.FirstName,st.MiddleName,st.LastName,s.SubjectScore,s.SchoolId,s.BranchId from gbl_sm_tbl_subject_scores s join gbl_sm_tbl_subjects su join gbl_sm_tbl_student st on s.SubjectId = su.SubjectId and s.StudentId = st.StudentId and s.SchoolId ='" + schoolId + "'  and s.BranchId ='" + branchId + "'";
			     } 
			    gsQuery=rdSession.createSQLQuery(gsSql);
			    List gcList=gsQuery.list();
			    Iterator gsIT=gcList.iterator();
			    while(gsIT.hasNext())
			     {
			    	Object[] ex=(Object[])gsIT.next();
			    	sb.append("<SubjectScore>");
				    sb.append("\n");
				      sb.append("<subjectScoreId>");
					    sb.append(ex[0]);
					    sb.append("</subjectScoreId>");
					    sb.append("\n");
					    sb.append("<subjectId>");
					    sb.append(ex[1]);
					    sb.append("</subjectId>");
					    sb.append("\n");
					    sb.append("<subjectName>");
						sb.append(ex[2]);
						sb.append("</subjectName>");
						 sb.append("\n");
						sb.append("<studentId>");
						sb.append(ex[3]);
						sb.append("</studentId>");
						 sb.append("\n");
						sb.append("<studentNumber>");
						sb.append(ex[4]);
						sb.append("</studentNumber>");
						sb.append("\n");
						sb.append("<firstName>");
						sb.append(ex[5]);
						sb.append("</firstName>");
						sb.append("\n");
						sb.append("<middleName>");
						sb.append(ex[6]);
						sb.append("</middleName>");
						sb.append("\n");
						sb.append("<lastName>");
					    sb.append(ex[7]);
					    sb.append("</lastName>");
					    sb.append("\n");
					    sb.append("<subjectScore>");
					    sb.append(ex[8]);
					    sb.append("</subjectScore>");
					    sb.append("\n");
						sb.append("<schoolId>");
						sb.append(ex[9]);
						sb.append("</schoolId>");
						sb.append("\n");
						sb.append("<branchId>");
						sb.append(ex[10]);
						sb.append("</branchId>");
						sb.append("\n");
				    sb.append("</SubjectScore>");
			}
		}
			sb.append("</SubjectScores>");
					    String str= sb.toString();
						 tx.commit();
					return str;
			
		
		}
		catch(Exception localException)
		{
			System.out.println(localException);
			
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    
			    sb.append("could not getall SubjectScores info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    string= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (tx!=null)
				  tx.rollback();
		}
		finally
		{
			rdSession.close();
		
		}
		return string;
	}

	public String getSubjectscoresbystudent(int studentId,int schoolId,int branchId) {
		Session gtempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gtTx=null;
			StringBuffer sb= new StringBuffer();
			System.out.println("hi dao impl success");
			String strg= null;
				try {
					gtTx = gtempSession.beginTransaction();
					List list=gtempSession.createSQLQuery("SELECT s.StudentId,st.StudentNumber,st.FirstName,st.MiddleName,st.LastName,st.RollNo,s.SubjectScoreId,su.SubjectName,s.SubjectScore,cl.ClassId,cl.ClassName,s.SchoolId,s.BranchId from gbl_sm_tbl_subject_scores s join gbl_sm_tbl_subjects su join gbl_sm_tbl_student st join gbl_sm_tbl_class as cl on s.SubjectId = su.SubjectId and s.StudentId = st.StudentId and su.ClassId = cl.ClassId where s.IsDeleted <> 'Y' or s.IsDeleted IS NULL and s.StudentId = '" + studentId + "' and s.SchoolId = '" + schoolId + "' and s.BranchId = '" + branchId + "';").list();
				     Iterator it=list.iterator();
				    		    sb.append("<SubjectScoresbystudent>");
						        sb.append("\n");
						        while(it.hasNext())
						        {
								Object[] ex=(Object[])it.next();
								sb.append("<SubjectScoresbystudent>");
							    sb.append("\n");
						        sb.append("<studentId>");
							    sb.append(ex[0]);
							    sb.append("</studentId>");
							    sb.append("\n");
							    sb.append("<studentNumber>");
							    sb.append(ex[1]);
							    sb.append("</studentNumber>");
							    sb.append("\n");
							    sb.append("<firstName>");
								sb.append(ex[2]);
								sb.append("</firstName>");
								 sb.append("\n");
								sb.append("<middleName>");
								sb.append(ex[3]);
								sb.append("</middleName>");
								 sb.append("\n");
								sb.append("<lastName>");
								sb.append(ex[4]);
								sb.append("</lastName>");
								sb.append("\n");
								sb.append("<rollNo>");
								sb.append(ex[5]);
								sb.append("</rollNo>");
								sb.append("\n");
								sb.append("<subjectScoreId>");
								sb.append(ex[6]);
								sb.append("</subjectScoreId>");
								sb.append("\n");
								sb.append("<subjectName>");
							    sb.append(ex[7]);
							    sb.append("</subjectName>");
							    sb.append("\n");
							    sb.append("<subjectScore>");
							    sb.append(ex[8]);
							    sb.append("</subjectScore>");
							    sb.append("\n");
								sb.append("<classId>");
							    sb.append(ex[9]);
							    sb.append("</classId>");
							    sb.append("\n");
							    sb.append("<className>");
							    sb.append(ex[10]);
							    sb.append("</className>");
							    sb.append("\n");
								sb.append("<schoolId>");
								sb.append(ex[11]);
								sb.append("</schoolId>");
								sb.append("\n");
								sb.append("<branchId>");
								sb.append(ex[12]);
								sb.append("</branchId>");
								sb.append("\n");
								sb.append("</SubjectScoresbystudent>");
						        }
								sb.append("</SubjectScoresbystudent>");
							    strg= sb.toString();
													
						
				} 	catch (Exception localException) {
					System.out.println(localException);
					
					   sb.append("<Response>");
					    sb.append("\n");
					    sb.append("<Result>");
					    sb.append("\n");
					    sb.append("Fail");
					    sb.append("\n");
					    sb.append("</Result>");
					    sb.append("\n");
					    sb.append("<Description>");
					    
					    sb.append("could not getbyid SubjectScores info");
					    sb.append("</Description>");
					    sb.append("\n");
					    sb.append("<Exception>");
					    sb.append(localException);
					    sb.append("</Exception>");
					    sb.append("</Response>");
					    sb.append("</subjectScoreId>");
					    sb.append("</SubjectScores>");
					    strg= sb.toString();
					   MDTransactionWriter.exceptionlog.info(localException);
					  if (gtTx!=null)
						  gtTx.rollback();
					} finally {
						gtempSession.close();
					}
			return strg;
	}

}
