package com.gwebitsol.core.assessments;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.stereotype.Service;

import com.gwebitsol.core.security.MDValidation;
import com.gwebitsol.core.security.MDVerifyConnectionID;
import com.gwebitsol.core.security.MDVerifyDatastoreName;
import com.gwebitsol.core.usermanagement.MDGetUserFromID;
import com.gwebitsol.core.util.MDTransactionWriter;
@Service
public class QuestionChoicesService implements QuestionChoicesIntf {
	@Context 
	private HttpServletRequest hsr;
	public Response addQuestionChoices(QuestionChoice qc, int userid, int connectionid, String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String XMLString=null;
	    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		qc.setBranchId(branchId);
		qc.setSchoolId(schoolId);
		try
		{
			MDValidation mdv = new MDValidation();  
			int ret =mdv.allvalidations(userid, connectionid, datastoreName,schoolId,branchId);
			System.out.println("verifiedvalue::"+ret);
			if(ret==1 )//&& rtVal==1)
			{	
			
			String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				QuestionChoicesDao spDAO=new QuestionChoicesDao();
				XMLString=spDAO.addQuestionChoices(qc);
				System.out.println(XMLString);
				MDTransactionWriter.writeLog("datastoreName","EmpMS","requester",startDate,endDate,sl,el,XMLString,hsr.getRemoteHost());
		}
			else
			{
				XMLString="you are not authorised user";
			}
			
		}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
		   XMLString="failed in service layer";
		}
	
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}

	public Response updateQuestionChoices(QuestionChoice qc, int userid, int connectionid, String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String XMLString=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		qc.setBranchId(branchId);
		qc.setSchoolId(schoolId);
		try
		{
			MDValidation mdv = new MDValidation();  
			int ret =mdv.allvalidations(userid, connectionid, datastoreName,schoolId,branchId);
			System.out.println("verifiedvalue::"+ret);
			if(ret==1 )//&& rtVal==1)
			{
			
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			QuestionChoicesDao flDAO=new QuestionChoicesDao();
			XMLString=flDAO.updateQuestionChoices(qc,schoolId,branchId);
			System.out.println(XMLString);
			MDTransactionWriter.writeLog("datastoreName","EmpMS","requester",startDate,endDate,sl,el,XMLString,hsr.getRemoteHost());
	}
			else
	{
		XMLString="you are not authorised user";
	}
	
}
	
	catch(Exception localException)
	{
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
	   XMLString="failed in service layer";
	}

	return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}

	public Response deleteQuestionChoices(int questionChoiceId, int userid, int connectionid, String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		String XMLString=null;
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		
		try
		{	
			MDValidation mdv = new MDValidation();  
			int ret =mdv.allvalidations(userid, connectionid, datastoreName,schoolId,branchId);
			System.out.println("verifiedvalue::"+ret);
			if(ret==1 )//&& rtVal==1)
			{
			
				QuestionChoicesDao ex=new QuestionChoicesDao();
				status=ex.deleteQuestionChoices(questionChoiceId,schoolId,branchId);
		
				String endDate=dateFormat.format(new Date());	
				Long el=System.currentTimeMillis();
				//status="user validation successfull";
			MDTransactionWriter.writeLog("sai","CMS","requester",startDate,endDate,sl,el,status,hsr.getRemoteHost());		
			}
			else
			{
				XMLString="you are not authorised user";
			}
			
			}
			catch(Exception localException)
			{
				MDTransactionWriter.errorlog.debug(localException);
				MDTransactionWriter.errorlog.info(localException);
				status="failed in service layer";
			}
			return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
		}

	public Response getQuestionChoices(int questionChoiceId, int userid, int connectionid, String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		String XMLString=null;
		String status1=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{	
			MDValidation mdv = new MDValidation();  
			int ret =mdv.allvalidations(userid, connectionid, datastoreName,schoolId,branchId);
			System.out.println("verifiedvalue::"+ret);
			if(ret==1 )//&& rtVal==1)
			{
			QuestionChoicesDao ex=new QuestionChoicesDao();
			 status1=ex.getQuestionChoices(questionChoiceId,schoolId,branchId);
			 System.out.println(status1);
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			//status1="user validation successfull";
			MDTransactionWriter.writeLog("sai","CMS","requester",startDate,endDate,sl,el,status1,hsr.getRemoteHost());		
		}else
		{
		XMLString="you are not authorised user";
		}
	
		}
		catch(Exception localException)
		{
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
		status1="failed in service layer";
		//System.out.println(localException);
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status1).build();
		}

	public Response getAllQuestionChoices(int userid, int connectionid, String datastoreName, int PNO, int size,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		
		String XMLString=null;
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try{
			MDValidation mdv = new MDValidation();  
			int ret =mdv.allvalidations(userid, connectionid, datastoreName,schoolId,branchId);
			System.out.println("verifiedvalue::"+ret);
			if(ret==1 )//&& rtVal==1)
			{
			QuestionChoicesDao ex=new QuestionChoicesDao();
			status=ex.getAllQuestionChoices(PNO,size,schoolId,branchId);
			System.out.println(status);
			String endDate=dateFormat.format(new Date());
			  Long el=System.currentTimeMillis();
			 MDTransactionWriter.writeLog("sai","CMS","requester",startDate,endDate,sl,el,status,hsr.getRemoteHost());		

		}else
		{
			XMLString="you are not authorised user";
		}
		
		}
			catch(Exception localException)
		   {
			  MDTransactionWriter.errorlog.debug(localException);
			  MDTransactionWriter.errorlog.info(localException);
			  status="failed in service layer";
		   }
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

}
