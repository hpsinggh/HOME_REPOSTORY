package com.gwebitsol.core.assessments;

import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class ScoreSheetDao {
	Session addempSession=MDHibernateUtil.getSessionFactory().openSession();
	Transaction addempTx=null;
	StringBuffer sb=new StringBuffer();
	public String addScoreSheet(ScoreSheetPojo brp) {
	String outStr=null;
	try
		{
			addempTx=addempSession.beginTransaction();
	        Integer in=(Integer)addempSession.save(brp);
			System.out.println(in);
			addempTx.commit();
			sb.append("<ScoreSheet>");
			sb.append("\n");
			sb.append("<scoreSheetId>");
			sb.append(in);
			sb.append("</scoreSheetId>");
			sb.append("</ScoreSheet>");
			outStr=sb.toString();
   		 }
		
			catch(Exception localException)
			{
			System.out.println(localException);
			    sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    sb.append("could not inserted ScoreSheet info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    outStr= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (addempTx!=null)
				  addempTx.rollback();
		}
		finally
		{			
			addempSession.close();
		}
		return outStr;
	}
	public String updateScoreSheet(ScoreSheetPojo brp,int schoolId,int branchId) {
		Session upempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction upempTx=null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
				upempTx=upempSession.beginTransaction();
				ScoreSheetPojo scoresheet = (ScoreSheetPojo) upempSession.get(ScoreSheetPojo.class,brp.getScoreSheetId());
				if(branchId==scoresheet.getBranchId()&&schoolId==scoresheet.getSchoolId())  
				upempSession.evict(scoresheet);
				upempSession.update(brp);
				upempTx.commit();
				sb.append("<ScoreSheet>");
				sb.append("\n");
				sb.append("update successfully");
				sb.append("</ScoreSheet>");
				String str=sb.toString();
				return str;
	   		 	}
			catch(Exception localException)
			{
					System.out.println(localException);
					sb.append("<Response>");
				    sb.append("\n");
				    sb.append("<Result>");
				    sb.append("\n");
				    sb.append("Fail");
				    sb.append("\n");
				    sb.append("</Result>");
				    sb.append("\n");
				    sb.append("<Description>");
				    sb.append("could not update ScoreSheet info");
				    sb.append("</Description>");
				    sb.append("\n");
				    sb.append("<Exception>");
				    sb.append(localException);
				    sb.append("</Exception>");
				    sb.append("</Response>");
				    outStr= sb.toString();
				    MDTransactionWriter.exceptionlog.info(localException);
				    if (upempTx!=null)
					upempTx.rollback();
			}
			finally
			{			
					upempSession.close();
			}
					return outStr;
	}
	public String deleteScoreSheet(int scoreSheetId,int schoolId,int branchId) {
		Session delempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction delempTx=null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			delempTx=delempSession.beginTransaction();
			
			ScoreSheetPojo scoresheet = (ScoreSheetPojo) delempSession.get(ScoreSheetPojo.class,scoreSheetId);
			   
			   int branid = scoresheet.getBranchId();
			   int sclid = scoresheet.getSchoolId();
			   delempSession.evict(scoresheet);           
			   if(branchId==branid&&schoolId==sclid)
			   {
			Query empQuery=delempSession.createSQLQuery("update gbl_sm_tbl_scoresheet set IsDeleted ='Y' where scoreSheetId='"+scoreSheetId+"'");
			empQuery.executeUpdate();
			delempTx.commit();
			sb.append("<ScoreSheet>");
			sb.append("\n");
			sb.append("delete successfully");
			sb.append("</ScoreSheet>");
			String str=sb.toString();
			return str;
			   }	
			   else
			   {
				outStr = "scoresheet is not deleted";
			    sb.append("<ScoreSheet>");
			    sb.append("\n");
			    sb.append(outStr);
			    sb.append("</ScoreSheet>");
			    String str = sb.toString();
			    return str;
			   }
				}
			catch(Exception localException)
			{
				System.out.println(localException);		
				    sb.append("<Response>");
				    sb.append("\n");
				    sb.append("<Result>");
				    sb.append("\n");
				    sb.append("Fail");
				    sb.append("\n");
				    sb.append("</Result>");
				    sb.append("\n");
				    sb.append("<Description>");
				    sb.append("could not delete ScoreSheet info");
				    sb.append("</Description>");
				    sb.append("\n");
				    sb.append("<Exception>");
				    sb.append(localException);
				    sb.append("</Exception>");
				    sb.append("</Response>");
				    outStr= sb.toString();
				   MDTransactionWriter.exceptionlog.info(localException);
				  if (delempTx!=null)
					  delempTx.rollback();
			}
			finally
			{			
				delempSession.close();
			}
			return outStr;
	}
	public String getByIdScoreSheet(int scoreSheetId,int schoolId,int branchId) {
		Session gtempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gtempTx=null;
		StringBuffer sb=new StringBuffer();
		System.out.println("hi success");
		String strg= null;
			try {
				gtempTx = gtempSession.beginTransaction();
				List list=gtempSession.createSQLQuery("SELECT s.ScoreSheetId,s.QuestionPaperId,qp.PaperTitle,s.StudentId,st.StudentNumber,st.FirstName,st.MiddleName,st.LastName,s.TotalScore,s.`Status`,s.Result,s.Remarks,s.CreatedDate,s.ModifiedDate,s.SchoolId,s.BranchId from gbl_sm_tbl_scoresheet s join gbl_sm_tbl_question_paper qp join gbl_sm_tbl_student st on s.QuestionPaperId = qp.QuestionPaperId and s.StudentId = st.StudentId where s.IsDeleted <> 'Y' or s.IsDeleted IS NULL and ScoreSheetId ='" + scoreSheetId + "' and s.SchoolId ='" + schoolId + "' and s.BranchId ='" + branchId + "';").list();
			     Iterator it=list.iterator();
			    		    sb.append("<ScoreSheet>");
					        sb.append("\n");
					        while(it.hasNext())
					        {
							Object[] ex=(Object[])it.next();
					        sb.append("<scoreSheetId>");
						    sb.append(ex[0]);
						    sb.append("</scoreSheetId>");
						    sb.append("\n");
						    sb.append("<questionPaperId>");
						    sb.append(ex[1]);
						    sb.append("</questionPaperId>");
						    sb.append("\n");
						    sb.append("<paperTitle>");
							sb.append(ex[2]);
							sb.append("</paperTitle>");
							 sb.append("\n");
							sb.append("<studentId>");
							sb.append(ex[3]);
							sb.append("</studentId>");
							 sb.append("\n");
							sb.append("<studentNumber>");
							sb.append(ex[4]);
							sb.append("</studentNumber>");
							sb.append("\n");
							sb.append("<firstName>");
							sb.append(ex[5]);
							sb.append("</firstName>");
							sb.append("\n");
							sb.append("<middleName>");
							sb.append(ex[6]);
							sb.append("</middleName>");
							sb.append("\n");
							sb.append("<lastName>");
						    sb.append(ex[7]);
						    sb.append("</lastName>");
						    sb.append("\n");
						    sb.append("<totalScore>");
						    sb.append(ex[8]);
						    sb.append("</totalScore>");
						    sb.append("\n");
						    sb.append("<status>");
							sb.append(ex[9]);
							sb.append("</status>");
							 sb.append("\n");
							sb.append("<result>");
							sb.append(ex[10]);
							sb.append("</result>");
							 sb.append("\n");
							sb.append("<remarks>");
							sb.append(ex[11]);
							sb.append("</remarks>");
							sb.append("\n");
							sb.append("<createdDate>");
							sb.append(ex[12]);
							sb.append("</createdDate>");
							sb.append("\n");
							sb.append("<modifiedDate>");
							sb.append(ex[13]);
							sb.append("</modifiedDate>");
							sb.append("\n");
							sb.append("<schoolId>");
							sb.append(ex[14]);
							sb.append("</schoolId>");
							sb.append("\n");
							sb.append("<branchId>");
							sb.append(ex[15]);
							sb.append("</branchId>");
							sb.append("\n");
					        }
							sb.append("</ScoreSheet>");
						    strg= sb.toString();
												
			} 	catch (Exception localException) {
				System.out.println(localException);
				   	sb.append("<Response>");
				    sb.append("\n");
				    sb.append("<Result>");
				    sb.append("\n");
				    sb.append("Fail");
				    sb.append("\n");
				    sb.append("</Result>");
				    sb.append("\n");
				    sb.append("<Description>");
				    sb.append("could not getbyid ScoreSheet info");
				    sb.append("</Description>");
				    sb.append("\n");
				    sb.append("<Exception>");
				    sb.append(localException);
				    sb.append("</Exception>");
				    sb.append("</Response>");
				    sb.append("</scoreSheetId>");
				    sb.append("</ScoreSheet>");
				    strg= sb.toString();
				   MDTransactionWriter.exceptionlog.info(localException);
				  if (gtempTx!=null)
					  gtempTx.rollback();
				} finally {
					gtempSession.close();
				}
		return strg;
	}
	public String getAllScoreSheet(int PNO, int size,int schoolId,int branchId) {
		Session rdSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb= new StringBuffer();
		String string=null;
		//ScoreSheetPojo ex=null;
		try
		{
			tx = rdSession.beginTransaction();
			
			if(("all") != null)
			   {
			    int fset = (PNO-1)*size;
			    String gsSql ="select count(*) from gbl_sm_tbl_scoresheet as s where s.IsDeleted <> 'Y' or s.IsDeleted IS NULL and s.SchoolId ='" + schoolId + "' and s.BranchId ='" + branchId + "'";
			    Query gsQuery=rdSession.createSQLQuery(gsSql);
			    Object noRecords= gsQuery.uniqueResult();
			    sb.append("<ScoreSheets>");
			    sb.append("\n");
			    sb.append("<noRecords>"+noRecords+"</noRecords>");
			    sb.append("\n");
			    
			     if (PNO > 0 & size > 0){
			     gsSql="SELECT s.ScoreSheetId,s.QuestionPaperId,qp.PaperTitle,s.StudentId,st.StudentNumber,st.FirstName,st.MiddleName,st.LastName,s.TotalScore,s.`Status`,s.Result,s.Remarks,s.CreatedDate,s.ModifiedDate,s.SchoolId,s.BranchId from gbl_sm_tbl_scoresheet s join gbl_sm_tbl_question_paper qp join gbl_sm_tbl_student st on s.QuestionPaperId = qp.QuestionPaperId and s.StudentId = st.StudentId  where s.IsDeleted <> 'Y' or s.IsDeleted IS NULL and s.SchoolId ='" + schoolId + "' and s.BranchId ='" + branchId + "' limit "+size+" offset "+fset;}
			     else {
			      gsSql="SELECT s.ScoreSheetId,s.QuestionPaperId,qp.PaperTitle,s.StudentId,st.StudentNumber,st.FirstName,st.MiddleName,st.LastName,s.TotalScore,s.`Status`,s.Result,s.Remarks,s.CreatedDate,s.ModifiedDate,s.SchoolId,s.BranchId from gbl_sm_tbl_scoresheet s join gbl_sm_tbl_question_paper qp join gbl_sm_tbl_student st on s.QuestionPaperId = qp.QuestionPaperId and s.StudentId = st.StudentId where s.IsDeleted <> 'Y' or s.IsDeleted IS NULL and s.SchoolId ='" + schoolId + "' and s.BranchId ='" + branchId + "'";
			     } 
			   
			    gsQuery=rdSession.createSQLQuery(gsSql);
			    List gcList=gsQuery.list();
			    Iterator gsIT=gcList.iterator();
			    while(gsIT.hasNext())
			     {
			    	 Object[] ex=(Object[])gsIT.next();
			    		sb.append("<ScoreSheet>");
			    		  sb.append("\n");
			         sb.append("<scoreSheetId>");
					    sb.append(ex[0]);
					    sb.append("</scoreSheetId>");
					    sb.append("\n");
					    sb.append("<questionPaperId>");
					    sb.append(ex[1]);
					    sb.append("</questionPaperId>");
					    sb.append("\n");
					    sb.append("<paperTitle>");
						sb.append(ex[2]);
						sb.append("</paperTitle>");
						 sb.append("\n");
						sb.append("<studentId>");
						sb.append(ex[3]);
						sb.append("</studentId>");
						 sb.append("\n");
						sb.append("<studentNumber>");
						sb.append(ex[4]);
						sb.append("</studentNumber>");
						sb.append("\n");
						sb.append("<firstName>");
						sb.append(ex[5]);
						sb.append("</firstName>");
						sb.append("\n");
						sb.append("<middleName>");
						sb.append(ex[6]);
						sb.append("</middleName>");
						sb.append("\n");
						sb.append("<lastName>");
					    sb.append(ex[7]);
					    sb.append("</lastName>");
					    sb.append("\n");
					    sb.append("<totalScore>");
					    sb.append(ex[8]);
					    sb.append("</totalScore>");
					    sb.append("\n");
					    sb.append("<status>");
						sb.append(ex[9]);
						sb.append("</status>");
						 sb.append("\n");
						sb.append("<result>");
						sb.append(ex[10]);
						sb.append("</result>");
						 sb.append("\n");
						sb.append("<remarks>");
						sb.append(ex[11]);
						sb.append("</remarks>");
						sb.append("\n");
						sb.append("<createdDate>");
						sb.append(ex[12]);
						sb.append("</createdDate>");
						sb.append("\n");
						sb.append("<modifiedDate>");
						sb.append(ex[13]);
						sb.append("</modifiedDate>");
						sb.append("\n");
						sb.append("<schoolId>");
						sb.append(ex[14]);
						sb.append("</schoolId>");
						sb.append("\n");
						sb.append("<branchId>");
						sb.append(ex[15]);
						sb.append("</branchId>");
						sb.append("\n");
						sb.append("</ScoreSheet>");
			}
		}
					 sb.append("</ScoreSheets>");
					 String str= sb.toString();
					 tx.commit();
					 return str;
		}
		catch(Exception localException)
		{
				System.out.println(localException);
				sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    sb.append("could not getall ScoreSheet info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    string= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			   if (tx!=null)
				  tx.rollback();
		}
		finally
		{
			rdSession.close();
		}
		return string;
	}
}