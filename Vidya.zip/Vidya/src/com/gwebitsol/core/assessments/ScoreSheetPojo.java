package com.gwebitsol.core.assessments;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="ScoreSheet")
public class ScoreSheetPojo {
	private int scoreSheetId;
	private int questionPaperId;
	private int studentId;
	private int totalScore;
	private String status;
	private String remarks;
	private String result;
	private String  createdDate;
	private int schoolId;
	private int branchId;
	
	 
	 DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	 Date date = new Date();
	 String modifiedDate=dateFormat.format(date);
	 
	  
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	protected String getModifiedDate() {
	  return modifiedDate;
	 }
	 protected void setModifiedDate(String modifiedDate) {
	  this.modifiedDate = modifiedDate;
	 }
	public int getScoreSheetId() {
		return scoreSheetId;
	}
	public void setScoreSheetId(int scoreSheetId) {
		this.scoreSheetId = scoreSheetId;
	}
	public int getQuestionPaperId() {
		return questionPaperId;
	}
	public void setQuestionPaperId(int questionPaperId) {
		this.questionPaperId = questionPaperId;
	}
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public int getTotalScore() {
		return totalScore;
	}
	public void setTotalScore(int totalScore) {
		this.totalScore = totalScore;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public int getSchoolId() {
		return schoolId;
	}
	public void setSchoolId(int schoolId) {
		this.schoolId = schoolId;
	}
	public int getBranchId() {
		return branchId;
	}
	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}
}

