package com.gwebitsol.core.assessments;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="SubjectScores")
public class SubjectScoresPojo {
	private int subjectScoreId;
	private int subjectId;
	private int studentId;
	private int subjectScore;
	private int schoolId;
	private int branchId;
	private String isDeleted;
	
	public int getSubjectScoreId() {
		return subjectScoreId;
	}
	public void setSubjectScoreId(int subjectScoreId) {
		this.subjectScoreId = subjectScoreId;
	}
	public int getSubjectId() {
		return subjectId;
	}
	public void setSubjectId(int subjectId) {
		this.subjectId = subjectId;
	}
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public int getSubjectScore() {
		return subjectScore;
	}
	public void setSubjectScore(int subjectScore) {
		this.subjectScore = subjectScore;
	}
	public int getSchoolId() {
		return schoolId;
	}
	public void setSchoolId(int schoolId) {
		this.schoolId = schoolId;
	}
	public int getBranchId() {
		return branchId;
	}
	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}
	public String getIsDeleted() {
		return isDeleted;
	}
	public void setIsDeleted(String isDeleted) {
		this.isDeleted = isDeleted;
	}
}
