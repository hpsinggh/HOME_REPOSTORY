package com.gwebitsol.core.assessments;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="QuestionChoice")
public class QuestionChoice
{
	private int questionChoiceId;
	private int questionId;
	private String choiceTag;
	private String choice;
	private String answerChoice;
	private int schoolId;
	private int branchId;
	
	public int getQuestionChoiceId() {
		return questionChoiceId;
	}
	public void setQuestionChoiceId(int questionChoiceId) {
		this.questionChoiceId = questionChoiceId;
	}
	public int getQuestionId() {
		return questionId;
	}
	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}

	public String getChoiceTag() {
		return choiceTag;
	}
	public void setChoiceTag(String choiceTag) {
		this.choiceTag = choiceTag;
	}
	public String getChoice() {
		return choice;
	}
	public void setChoice(String choice) {
		this.choice = choice;
	}
	public String getAnswerChoice() {
		return answerChoice;
	}
	public void setAnswerChoice(String answerChoice) {
		this.answerChoice = answerChoice;
	}
	public int getSchoolId() {
		return schoolId;
	}
	public void setSchoolId(int schoolId) {
		this.schoolId = schoolId;
	}
	public int getBranchId() {
		return branchId;
	}
	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}
	
}
