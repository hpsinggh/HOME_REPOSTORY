package com.gwebitsol.core.assessments;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class PaperSectionDao {
	
	
	public String addPaperSection(PaperSectionPojo psp) {
		String sqlstr = null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		Integer paperSectionId=null;
		Session addempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction addempTx=null;
		try
		{
			addempTx=addempSession.beginTransaction();			
			paperSectionId=(Integer)addempSession.save(psp);
			List<QuestionsPaperSectionPojo> questionsperpapersec = psp.getQuestionList().getQuestionsPaperSectionPojo();
			for (int i = 0; i <= questionsperpapersec.size()-1; i++) 
			{
				QuestionsPaperSectionPojo qpsp = questionsperpapersec.get(i);
				int quesid = qpsp.getQuestionId();
					
				sqlstr = "insert into gbl_sm_tbl_questions_papersection(PaperSectionId,QuestionId) values ('" + paperSectionId+ "','" + quesid + "');";
				SQLQuery stpar = addempSession.createSQLQuery(sqlstr);
				
				stpar.executeUpdate();
				
			}
		
			addempTx.commit();
		
			sb.append("<PaperSection>");
			sb.append("\n");
			sb.append("<paperSectionId>");
			sb.append(paperSectionId);
			sb.append("</paperSectionId>");
			sb.append("</PaperSection>");
			outStr=sb.toString();
			
   		 	}
		
		catch(Exception localException)
		{
			System.out.println(localException);
			
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    
			    sb.append("could not inserted PaperSection info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    outStr= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (addempTx!=null)
				  addempTx.rollback();
		}
		finally
		{			
			addempSession.close();
		}
		return outStr;
	}

	public String updatePaperSection(PaperSectionPojo psp,int schoolId,int branchId) {
		Session upempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction upempTx=null;
		StringBuffer sb=new StringBuffer();
		String sqlstr=null;
		String str=null;
		psp.setSchoolId(schoolId);
		psp.setBranchId(branchId);
		try
		{
			upempTx=upempSession.beginTransaction();
			PaperSectionPojo papersection = (PaperSectionPojo) upempSession.get(PaperSectionPojo.class,psp.getPaperSectionId());
			if(branchId==papersection.getBranchId()&&schoolId==papersection.getSchoolId())  
			upempSession.evict(papersection);
			upempSession.update(psp);
			
			int papersectionId = psp.getPaperSectionId();
			
			   List<QuestionsPaperSectionPojo> questionsperpapersec = psp.getQuestionList().getQuestionsPaperSectionPojo();
				for (int i = 0; i <= questionsperpapersec.size()-1; i++) 
				{
					QuestionsPaperSectionPojo qpsp = questionsperpapersec.get(i);
					int quesid = qpsp.getQuestionId();
					int qspasec	= qpsp.getQuestionPaperSectionId();
					
					if(qspasec!=0)
					{
					
					sqlstr = "update gbl_sm_tbl_questions_papersection as pasec set pasec.PaperSectionId ='"+papersectionId+"'  , pasec.QuestionId = '"+quesid+"' where pasec.QuestionPaperSectionId ='"+qspasec+"'";
					SQLQuery stpar = upempSession.createSQLQuery(sqlstr);
					
					stpar.executeUpdate();
					}else
					{
						Integer count=(Integer)upempSession.createSQLQuery("select questionid from gbl_sm_tbl_questions_papersection where PaperSectionId ='"+papersectionId+"' and QuestionId='"+quesid+"'").uniqueResult();
						if(count==null || count==0)
					    {	
						sqlstr = "insert into gbl_sm_tbl_questions_papersection(PaperSectionId,QuestionId) values ('" + papersectionId+ "','" + quesid + "');";
						SQLQuery stpar = upempSession.createSQLQuery(sqlstr);
						
						stpar.executeUpdate();
					    }
					}
				}
			          
						
			upempTx.commit();
			sb.append("<PaperSection>");
			sb.append("\n");
			sb.append("update sucessfully");
			sb.append("</PaperSection>");
			str=sb.toString();
			}
		catch(Exception localException)
		{
			System.out.println(localException);
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    sb.append("could not update papersection info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    str= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (sqlstr!=null)
				  upempTx.rollback();
		}
		finally
		{			
			upempSession.close();
		}
		return str;
	}

	public String deletePaperSection(int paperSectionId,int schoolId,int branchId) {
		Session delempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction delempTx=null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			delempTx=delempSession.beginTransaction();
			PaperSectionPojo papersection = (PaperSectionPojo) delempSession.get(PaperSectionPojo.class,paperSectionId);
			   
			   int branid = papersection.getBranchId();
			   int sclid = papersection.getSchoolId();
			   delempSession.evict(papersection);         
			   if(branchId==branid&&schoolId==sclid)
			   {
			Query empQuery=delempSession.createSQLQuery("update gbl_sm_tbl_paper_section set IsDeleted ='Y' where paperSectionId='"+paperSectionId+"'");
			empQuery.executeUpdate();
			delempTx.commit();
			sb.append("<PaperSection>");
			sb.append("\n");
			sb.append("deleted sucessfully");
			sb.append("</PaperSection>");
			String str=sb.toString();
			return str;
   		 	}
			   else
			   {
				outStr = "papersection is not deleted";
			    sb.append("<PaperSection>");
			    sb.append("\n");
			    sb.append(outStr);
			    sb.append("</PaperSection>");
			    String str = sb.toString();
			    return str;
			   }
				}
		catch(Exception localException)
		{
			System.out.println(localException);
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    sb.append("could not delete papersection info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    outStr= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (outStr!=null)
				  delempTx.rollback();
		}
		finally
		{			
			delempSession.close();
		}
		return outStr;
	}

	public String getByPaperSectionId(int paperSectionId,int schoolId,int branchId) {
		Session gtempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gtTx=null;
			StringBuffer sb= new StringBuffer();
			System.out.println("hi dao impl success");
			String strg= null;
				try {
						gtTx = gtempSession.beginTransaction();
						List list=gtempSession.createSQLQuery("SELECT ps.PaperSectionId,ps.QuestionPaperId,qp.PaperTitle,ps.SectionTitle,ps.Instructions,ps.MaxScore,ps.SchoolId,ps.BranchId FROM gbl_sm_tbl_paper_section ps JOIN gbl_sm_tbl_question_paper qp on ps.QuestionPaperId = qp.QuestionPaperId where ps.IsDeleted <> 'Y' or ps.IsDeleted IS NULL and ps.PaperSectionId ='" + paperSectionId + "' and ps.SchoolId ='" + schoolId + "' and ps.BranchId ='" + branchId + "' ;").list();
					     Iterator it=list.iterator();
					     sb.append("<PaperSections>");
					     sb.append("\n");
					     while(it.hasNext())
					     {
					      Object[] ex=(Object[])it.next();
					         sb.append("<PaperSection>");
						     sb.append("\n");
					         sb.append("<paperSectionId>");
					         sb.append(ex[0]);
					         sb.append("</paperSectionId>");
					         sb.append("\n");
					         sb.append("<questionPaperId>");
					         sb.append(ex[1]);
					         sb.append("</questionPaperId>");
					         sb.append("\n");
					         sb.append("<paperTitle>");
					         sb.append(ex[2]);
					         sb.append("</paperTitle>");
					         sb.append("\n");
					         sb.append("<sectionTitle>");
					         sb.append(ex[3]);
					         sb.append("</sectionTitle>");
					         sb.append("\n");
					         sb.append("<instructions>");
					         sb.append(ex[4]);
					         sb.append("</instructions>");
					         sb.append("\n");
					         sb.append("<maxScore>");
					         sb.append(ex[5]);
					         sb.append("</maxScore>");
					         sb.append("\n");
							 sb.append("<schoolId>");
							 sb.append(ex[6]);
							 sb.append("</schoolId>");
							 sb.append("\n");
							 sb.append("<branchId>");
							 sb.append(ex[7]);
							 sb.append("</branchId>");
							 sb.append("\n");
							 sb.append("</PaperSection>");
							 sb.append("\n");
					     
					     if(paperSectionId!=0)
					     {
					    	 String  gsSql="select qp.QuestionPaperSectionId,qp.QuestionId,ques.QuestionTitle from gbl_sm_tbl_questions_papersection qp join gbl_sm_tbl_paper_section psec on psec.PaperSectionId = qp.PaperSectionId join gbl_sm_tbl_question ques on ques.QuestionId = qp.QuestionId where qp.PaperSectionId = '"+paperSectionId+"' order by qp.PaperSectionId,qp.QuestionId";
						      Query gsQuery = gtempSession.createSQLQuery(gsSql);
						      List parList1 = gsQuery.list();
						      sb.append("<Questions>");
								sb.append("\n");
								Iterator IT = parList1.iterator();
							     while(IT.hasNext())
							     {
							      Object[] ex1=(Object[])IT.next();
							         sb.append("<Question>");
								     sb.append("\n");
							         sb.append("<questionPaperSectionId>");
							         sb.append(ex1[0]);
							         sb.append("</questionPaperSectionId>");
							         sb.append("\n");
							         sb.append("<questionId>");
							         sb.append(ex1[1]);
							         sb.append("</questionId>");
							         sb.append("\n");
							         sb.append("<questionTitle>");
							         sb.append(ex1[2]);
							         sb.append("</questionTitle>");
							         sb.append("\n");
							         sb.append("</Question>");
								     sb.append("\n");
							         
					     	}
							     
					     }
							     sb.append("</Questions>");
									sb.append("\n");
					     
					     }
									sb.append("</PaperSections>");
									strg= sb.toString();
						
				} 	catch (Exception localException) {
					System.out.println(localException);
					
					   sb.append("<Response>");
					    sb.append("\n");
					    sb.append("<Result>");
					    sb.append("\n");
					    sb.append("Fail");
					    sb.append("\n");
					    sb.append("</Result>");
					    sb.append("\n");
					    sb.append("<Description>");
					    
					    sb.append("could not getbyid papersection info");
					    sb.append("</Description>");
					    sb.append("\n");
					    sb.append("<Exception>");
					    sb.append(localException);
					    sb.append("</Exception>");
					    sb.append("</Response>");
					    sb.append("</paperSectionId>");
					    sb.append("</PapetSection>");
					    strg= sb.toString();
					   MDTransactionWriter.exceptionlog.info(localException);
					  if (strg!=null)
						  gtTx.rollback();
					} finally {
						gtempSession.close();
					}
			return strg;
	}

	public String getAllPaperSection(int PNO, int size,int schoolId,int branchId) {
		Session rdSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb= new StringBuffer();
		String string=null;
		//PaperSectionPojo ex=null;
		
		try
		{
			tx = rdSession.beginTransaction();
			
			 if(("all") != null)
			   {
			    int fset = (PNO-1)*size;
			    String gsSql ="select count(*) from gbl_sm_tbl_paper_section as ps where (ps.IsDeleted <> 'Y' or ps.IsDeleted IS NULL) and ps.SchoolId ='" + schoolId + "' and ps.BranchId ='" + branchId + "'";
			    Query gsQuery=rdSession.createSQLQuery(gsSql);
			    Object noRecords= gsQuery.uniqueResult();
			    sb.append("<PaperSections>");
			    sb.append("\n");
			    sb.append("<noRecords>"+noRecords+"</noRecords>");
			    sb.append("\n");
			    
			     if (PNO > 0 & size > 0){
			     gsSql="SELECT ps.PaperSectionId,ps.QuestionPaperId,qp.PaperTitle,ps.SectionTitle,ps.Instructions,ps.MaxScore,ps.SchoolId,ps.BranchId FROM gbl_sm_tbl_paper_section ps JOIN gbl_sm_tbl_question_paper qp on ps.QuestionPaperId = qp.QuestionPaperId where ps.IsDeleted <> 'Y' or ps.IsDeleted IS NULL and ps.SchoolId ='" + schoolId + "' and ps.BranchId ='" + branchId + "' limit "+size+" offset "+fset;
			     }
			     else {
			      gsSql="SELECT ps.PaperSectionId,ps.QuestionPaperId,qp.PaperTitle,ps.SectionTitle,ps.Instructions,ps.MaxScore,ps.SchoolId,ps.BranchId FROM gbl_sm_tbl_paper_section ps JOIN gbl_sm_tbl_question_paper qp on ps.QuestionPaperId = qp.QuestionPaperId where ps.IsDeleted <> 'Y' or ps.IsDeleted IS NULL and ps.SchoolId ='" + schoolId + "' and ps.BranchId ='" + branchId + "'";
			     } 
			   
			    gsQuery=rdSession.createSQLQuery(gsSql);
			    List gcList=gsQuery.list();
			    Iterator gsIT=gcList.iterator();
			    while(gsIT.hasNext())
			     {
			    	 Object[] ex=(Object[])gsIT.next();
			    	  sb.append("<PaperSection>");
					     sb.append("\n");
				         sb.append("<paperSectionId>");
				         sb.append(ex[0]);
				         sb.append("</paperSectionId>");
				         sb.append("\n");
				         sb.append("<questionPaperId>");
				         sb.append(ex[1]);
				         sb.append("</questionPaperId>");
				         sb.append("\n");
				         sb.append("<paperTitle>");
				         sb.append(ex[2]);
				         sb.append("</paperTitle>");
				         sb.append("\n");
				         sb.append("<sectionTitle>");
				         sb.append(ex[3]);
				         sb.append("</sectionTitle>");
				         sb.append("\n");
				         sb.append("<instructions>");
				         sb.append(ex[4]);
				         sb.append("</instructions>");
				         sb.append("\n");
				         sb.append("<maxScore>");
				         sb.append(ex[5]);
				         sb.append("</maxScore>");
				         sb.append("\n");
						 sb.append("<schoolId>");
						 sb.append(ex[6]);
						 sb.append("</schoolId>");
						 sb.append("\n");
						 sb.append("<branchId>");
						 sb.append(ex[7]);
						 sb.append("</branchId>");
						 sb.append("\n");
						 sb.append("</PaperSection>");
						 sb.append("\n");
						 
						 int paperSectionId=(Integer)ex[0]; 
						 
						  if(paperSectionId!=0)
						     {
						    	 String  gsSqls="select qp.QuestionPaperSectionId,qp.QuestionId,ques.QuestionTitle from gbl_sm_tbl_questions_papersection qp join gbl_sm_tbl_paper_section psec on psec.PaperSectionId = qp.PaperSectionId join gbl_sm_tbl_question ques on ques.QuestionId = qp.QuestionId where qp.PaperSectionId = '"+paperSectionId+"' order by qp.PaperSectionId,qp.QuestionId";
							      Query gsQuerys = rdSession.createSQLQuery(gsSqls);
							      List parList1 = gsQuerys.list();
							      sb.append("<Questions>");
									sb.append("\n");
									Iterator IT = parList1.iterator();
								     while(IT.hasNext())
								     {
								      Object[] ex1=(Object[])IT.next();
								         sb.append("<Question>");
									     sb.append("\n");
								         sb.append("<questionPaperSectionId>");
								         sb.append(ex1[0]);
								         sb.append("</questionPaperSectionId>");
								         sb.append("\n");
								         sb.append("<questionId>");
								         sb.append(ex1[1]);
								         sb.append("</questionId>");
								         sb.append("\n");
								         sb.append("<questionTitle>");
								         sb.append(ex1[2]);
								         sb.append("</questionTitle>");
								         sb.append("\n");
								         sb.append("</Question>");
									     sb.append("\n");
								         
						     	}
								     
						     }
								     sb.append("</Questions>");
										sb.append("\n");
						     
						     }
			   }
										sb.append("</PaperSections>");
										string= sb.toString();
		}
		
		catch(Exception localException)
		{
			System.out.println(localException);
			
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    
			    sb.append("could not getall papersection info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    string= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (string!=null)
				  tx.rollback();
		}
		finally
		{
			rdSession.close();
		
		}
		return string;
	}

}
