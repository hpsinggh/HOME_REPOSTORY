package com.gwebitsol.core.assessments;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.stereotype.Service;

import com.gwebitsol.core.security.MDValidation;
import com.gwebitsol.core.security.MDVerifyConnectionID;
import com.gwebitsol.core.security.MDVerifyDatastoreName;
import com.gwebitsol.core.usermanagement.MDGetUserFromID;
import com.gwebitsol.core.util.MDTransactionWriter;
@Service
public class QuestionPaperService implements QuestionPaperIntf {
	@Context 
	private HttpServletRequest hsr;
	public Response addQuestionPaper(QuestionPaperPojo qpp, int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String XMLString=null;
	    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		qpp.setSchoolId(schoolId);
		qpp.setBranchId(branchId);
		try
		{
			MDValidation mdv = new MDValidation();  
			int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			System.out.println("verifiedvalue::"+ret);
			
			MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userID);
			
			if(ret==1 )//&& rtVal==1)
			{	
			String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				QuestionPaperDao spDAO=new QuestionPaperDao();
				XMLString=spDAO.addQuestionPaper(qpp);
				System.out.println(XMLString);
				MDTransactionWriter.writeLog(datastoreName,"QuestionPaperService_addQuestionPaper",requester,startDate,endDate,sl,el,XMLString,hsr.getRemoteHost());
		}
			else
			{
				XMLString="you are not authorised user";
			}
			
		}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
		   XMLString="failed in service layer";
		}
	
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}

	public Response updateQuestionPaper(QuestionPaperPojo qpp, int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String XMLString=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		qpp.setSchoolId(schoolId);
		qpp.setBranchId(branchId);
		try
		{
			MDValidation mdv = new MDValidation();  
			int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			System.out.println("verifiedvalue::"+ret);
			
			MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userID);
			
			if(ret==1 )//&& rtVal==1)
			{
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			QuestionPaperDao flDAO=new QuestionPaperDao();
			XMLString=flDAO.updateQuestionPaper(qpp,schoolId,branchId);
			System.out.println(XMLString);
			MDTransactionWriter.writeLog(datastoreName,"QuestionPaperService_updateQuestionPaper",requester,startDate,endDate,sl,el,XMLString,hsr.getRemoteHost());
	}
			else
			{
				XMLString="you are not authorised user";
			}
			
		}
	catch(Exception localException)
	{
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
	   XMLString="failed in service layer";
	}

	return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}

	public Response deleteQuestionPaper(int questionPaperId, int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		String XMLString=null;
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{	
			MDValidation mdv = new MDValidation();  
			int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			System.out.println("verifiedvalue::"+ret);
			
			MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userID);
			
			if(ret==1 )//&& rtVal==1)
			{
		QuestionPaperDao ex=new QuestionPaperDao();
		status=ex.deleteQuestionPaper(questionPaperId,schoolId,branchId);
		
		String endDate=dateFormat.format(new Date());	
		Long el=System.currentTimeMillis();
		//status="user validation successfull";
			MDTransactionWriter.writeLog(datastoreName,"QuestionPaperService_deleteQuestionPaper",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
	}else
	{
		XMLString="you are not authorised user";
	}
	
}
	catch(Exception localException)
	{
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
		status="failed in service layer";
	}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response getByQuestionPaperId(int questionPaperId, int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		String XMLString=null;
		String status1=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{	
			MDValidation mdv = new MDValidation();  
			int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			System.out.println("verifiedvalue::"+ret);
			
			MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userID);
			
			if(ret==1 )//&& rtVal==1)
			{
			QuestionPaperDao ex=new QuestionPaperDao();
			 status1=ex.getByQuestionPaperId(questionPaperId,schoolId,branchId);
			 System.out.println(status1);
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			//status1="user validation successfull";
			MDTransactionWriter.writeLog(datastoreName,"QuestionPaperService_getByQuestionPaperId",requester,startDate,endDate,sl,el,status1,hsr.getRemoteHost());		
	}
			else
			{
				XMLString="you are not authorised user";
			}
			
		}
			catch(Exception localException)
	{
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
		status1="failed in service layer";
		//System.out.println(localException);
	}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status1).build();
	}

	public Response getAllQuestionPaper(int userID, int connectionID,String datastoreName, int PNO, int size,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String XMLString=null;
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try{
			MDValidation mdv = new MDValidation();  
			int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			System.out.println("verifiedvalue::"+ret);
			
			MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userID);
			
			if(ret==1 )//&& rtVal==1)
			{
			QuestionPaperDao ex=new QuestionPaperDao();
			status=ex.getAllQuestionPaper(PNO,size,schoolId,branchId);
			System.out.println(status);
			String endDate=dateFormat.format(new Date());
			  Long el=System.currentTimeMillis();
			 MDTransactionWriter.writeLog(datastoreName,"QuestionPaperService_getAllQuestionPaper",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		

		}
			else
			{
				XMLString="you are not authorised user";
			}
			
		}
			catch(Exception localException)
		   {
			  MDTransactionWriter.errorlog.debug(localException);
			  MDTransactionWriter.errorlog.info(localException);
			  status="failed in service layer";
		   }
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

}
