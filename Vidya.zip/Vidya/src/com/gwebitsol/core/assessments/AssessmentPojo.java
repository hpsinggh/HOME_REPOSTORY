package com.gwebitsol.core.assessments;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="Assessment")
public class AssessmentPojo {
	private int assessmentId;
	private int assessmentTypeId;
	private String assessmentName;
	private String description;
	private String startDate;
	private String endDate;
	private String status;
	private String remarks;
	private int maxScore;
	private String questionPaperId;
	private int schoolId;
	private int branchId;
	private int classId;
	private String sectionId;
	
	private String  createdDate;
	 
	DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	Date date = new Date();
	String modifiedDate=dateFormat.format(date);
	 
	  
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	protected String getModifiedDate() {
	  return modifiedDate;
	 }
	 protected void setModifiedDate(String modifiedDate) {
	  this.modifiedDate = modifiedDate;
	 }
	
	public int getAssessmentId() {
		return assessmentId;
	}
	public void setAssessmentId(int assessmentId) {
		this.assessmentId = assessmentId;
	}
	public int getAssessmentTypeId() {
		return assessmentTypeId;
	}
	public void setAssessmentTypeId(int assessmentTypeId) {
		this.assessmentTypeId = assessmentTypeId;
	}
	public String getAssessmentName() {
		return assessmentName;
	}
	public void setAssessmentName(String assessmentName) {
		this.assessmentName = assessmentName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public int getMaxScore() {
		return maxScore;
	}
	public void setMaxScore(int maxScore) {
		this.maxScore = maxScore;
	}
	public String getQuestionPaperId() {
		return questionPaperId;
	}
	public void setQuestionPaperId(String questionPaperId) {
		this.questionPaperId = questionPaperId;
	}
	public int getSchoolId() {
		return schoolId;
	}
	public void setSchoolId(int schoolId) {
		this.schoolId = schoolId;
	}
	public int getBranchId() {
		return branchId;
	}
	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}
	public int getClassId() {
		return classId;
	}
	public void setClassId(int classId) {
		this.classId = classId;
	}
	public String getSectionId() {
		return sectionId;
	}
	public void setSectionId(String sectionId) {
		this.sectionId = sectionId;
	}
	
	
	StudentsList stuList= new StudentsList();


	public StudentsList getStuList() {
		return stuList;
	}
	public void setStuList(StudentsList stuList) {
		this.stuList = stuList;
	}
	

	@XmlElementWrapper(name="Students")
	@XmlElement(name="Student")
	
	public List<StudentPojo> getStudentPojo() {
		return stuList.getStudentPojo();
	}

	public void setStudentPojo(List<StudentPojo> studentPojo) {
		stuList.setStudentPojo(studentPojo);
	}
	
}

