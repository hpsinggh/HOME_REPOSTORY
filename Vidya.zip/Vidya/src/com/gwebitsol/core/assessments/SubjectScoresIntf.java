package com.gwebitsol.core.assessments;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

@Path("/subjectscores")
public interface SubjectScoresIntf {
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/add/")
    public Response addSubjectScores(SubjectScoresPojo ssp,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);
	
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/update/")
	public Response updateSubjectScores(SubjectScoresPojo ssp,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);
	
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/delete/")
	public Response deleteSubjectScores(@QueryParam("subjectScoreId") int subjectScoreId,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);
	
	@GET
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/get/")
	public Response getBySubjectScoresId(@QueryParam("subjectScoreId") int subjectScoreId,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);
	
	@GET
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/getall/")
	public Response getAllSubjectScores(@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName
			,@QueryParam("PNO") int PNO,@QueryParam("size") int size,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);
	
	@GET
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/getsubjectscoresbystudent/")
	public Response getSubjectscoresbystudent(@QueryParam("studentId") int studentId,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);
}
