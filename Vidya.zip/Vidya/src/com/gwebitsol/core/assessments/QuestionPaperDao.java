package com.gwebitsol.core.assessments;

import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class QuestionPaperDao {
	Session addempSession=MDHibernateUtil.getSessionFactory().openSession();
	Transaction addempTx=null;
	
	public String addQuestionPaper(QuestionPaperPojo qpp) {
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			addempTx=addempSession.beginTransaction();
			Integer in=(Integer)addempSession.save(qpp);
			System.out.println(in);
			
			addempTx.commit();
			
			
			sb.append("<QuestionPaper>");
			sb.append("\n");
			sb.append("<questionPaperId>");
			sb.append(in);
			sb.append("</questionPaperId>");
			sb.append("</QuestionPaper>");
			outStr=sb.toString();
			
		   
   		 	}
		
		catch(Exception localException)
		{
			System.out.println(localException);
			
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    
			    sb.append("could not inserted QuestionPaper info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    outStr= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (addempTx!=null)
				  addempTx.rollback();
		}
		finally
		{			
			addempSession.close();
		}
		return outStr;
	}

	public String updateQuestionPaper(QuestionPaperPojo qpp,int schoolId,int branchId) {
		Session upempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction upempTx=null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			upempTx=upempSession.beginTransaction();
			QuestionPaperPojo questionpaper = (QuestionPaperPojo) upempSession.get(QuestionPaperPojo.class,qpp.getQuestionPaperId());
			if(branchId==questionpaper.getBranchId()&&schoolId==questionpaper.getSchoolId())  
			upempSession.evict(questionpaper);
	        upempSession.update(qpp);
			upempTx.commit();
			sb.append("<QuestionPaper>");
			sb.append("\n");
			sb.append("update sucessfully");
			sb.append("</QuestionPaper>");
			String str=sb.toString();
			return str;
   		 	}
		
		catch(Exception localException)
		{
			System.out.println(localException);
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    sb.append("could not update QuestionPaper info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    outStr= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (upempTx!=null)
				  upempTx.rollback();
		}
		finally
		{			
			upempSession.close();
		}
		return outStr;
	}

	public String deleteQuestionPaper(int questionPaperId,int schoolId,int branchId) {
		Session delempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction delempTx=null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			delempTx=delempSession.beginTransaction();
			
			QuestionPaperPojo questionpaper = (QuestionPaperPojo) delempSession.get(QuestionPaperPojo.class,questionPaperId);
			   
			   int branid = questionpaper.getBranchId();
			   int sclid = questionpaper.getSchoolId();
			   delempSession.evict(questionpaper);          
			   if(branchId==branid&&schoolId==sclid)
			   {
			Query empQuery=delempSession.createSQLQuery("update gbl_sm_tbl_question_paper set IsDeleted ='Y' where questionPaperId='"+questionPaperId+"'");
			empQuery.executeUpdate();
			delempTx.commit();
			sb.append("<QuestionPaper>");
			sb.append("\n");
			sb.append("deleted sucessfully");
			sb.append("</QuestionPaper>");
			String str=sb.toString();
			return str;
   		 	}
			   else
			   {
				outStr = "questionpaper is not deleted";
			    sb.append("<QuestionPaper>");
			    sb.append("\n");
			    sb.append(outStr);
			    sb.append("</QuestionPaper>");
			    String str = sb.toString();
			    return str;
			   }
				}
		catch(Exception localException)
		{
			System.out.println(localException);
			
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    
			    sb.append("could not delete QuestionPaper info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    outStr= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (delempTx!=null)
				  delempTx.rollback();
		}
		finally
		{			
			delempSession.close();
		}
		return outStr;
	}

	public String getByQuestionPaperId(int questionPaperId,int schoolId,int branchId) {
		Session gtempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gtTx=null;
			StringBuffer sb= new StringBuffer();
			System.out.println("hi dao impl success");
			String strg= null;
				try {
					gtTx = gtempSession.beginTransaction();
					List list=gtempSession.createSQLQuery("select qp.QuestionPaperId,qp.Instructions,qp.PaperTitle,qp.`Level`,qp.`Status`,qp.Description,qp.Remarks,qp.CreatedDate,qp.ModifiedDate,qp.SchoolId,qp.BranchId,sub.ClassId,cls.ClassName,sub.SectionId,sec.SectionName,qp.SubjectId,sbt.SubjectTypeId,sbt.SubjectName from gbl_sm_tbl_question_paper as qp join gbl_sm_tbl_subjects as sub on qp.SubjectId=sub.SubjectId join gbl_sm_tbl_class as cls on sub.ClassId = cls.ClassId join gbl_sm_tbl_section as sec on sub.SectionId = sec.SectionId join gbl_sm_tbl_subject_type as sbt on sub.SubjectTypeId = sbt.SubjectTypeId where qp.IsDeleted <> 'Y' or qp.IsDeleted IS NULL and QuestionPaperId= '" + questionPaperId + "' and qp.SchoolId = '" + schoolId + "' and qp.BranchId = '" + branchId + "';").list();
				     Iterator it=list.iterator();
				     sb.append("<QuestionPaper>");
				     sb.append("\n");
				     while(it.hasNext())
				     {
				      Object[] ex=(Object[])it.next();
				      	 sb.append("<questionPaperId>");
				         sb.append(ex[0]);
				         sb.append("</questionPaperId>");
				         sb.append("\n");
				         sb.append("<instructions>");
				         sb.append(ex[1]);
				         sb.append("</instructions>");
				         sb.append("\n");
				         sb.append("<paperTitle>");
				         sb.append(ex[2]);
				         sb.append("</paperTitle>");
				         sb.append("\n");
				         sb.append("<level>");
				         sb.append(ex[3]);
				         sb.append("</level>");
				         sb.append("\n");
				         sb.append("<status>");
				         sb.append(ex[4]);
				         sb.append("</status>");
				         sb.append("\n");
				         sb.append("<description>");
				         sb.append(ex[5]);
				         sb.append("</description>");
				         sb.append("\n");
				         sb.append("<remarks>");
				         sb.append(ex[6]);
				         sb.append("</remarks>");
				         sb.append("\n");
				         sb.append("<createdDate>");
				         sb.append(ex[7]);
				         sb.append("</createdDate>");
				         sb.append("\n");
				         sb.append("<modifiedDate>");
				         sb.append(ex[8]);
				         sb.append("</modifiedDate>");
				         sb.append("\n");
				         sb.append("<schoolId>");
				         sb.append(ex[9]);
				         sb.append("</schoolId>");
				         sb.append("\n");
				         sb.append("<branchId>");
				         sb.append(ex[10]);
				         sb.append("</branchId>");
				         sb.append("\n");
				         sb.append("<classId>");
				         sb.append(ex[11]);
				         sb.append("</classId>");
				         sb.append("\n");
				         sb.append("<className>");
				         sb.append(ex[12]);
				         sb.append("</className>");
				         sb.append("\n");
						 sb.append("<sectionId>");
						 sb.append(ex[13]);
						 sb.append("</sectionId>");
						 sb.append("\n");
						 sb.append("<sectionName>");
						 sb.append(ex[14]);
						 sb.append("</sectionName>");
						 sb.append("\n");
						    sb.append("<subjectId>");
					         sb.append(ex[15]);
					         sb.append("</subjectId>");
					         sb.append("\n");
							 sb.append("<subjectTypeId>");
							 sb.append(ex[16]);
							 sb.append("</subjectTypeId>");
							 sb.append("\n");
							 sb.append("<subjectName>");
							 sb.append(ex[17]);
							 sb.append("</subjectName>");
							 sb.append("\n");
				     }
						 sb.append("</QuestionPaper>");
						 strg= sb.toString();
				     
						
						
				} 	catch (Exception localException) {
					System.out.println(localException);
					
					   sb.append("<Response>");
					    sb.append("\n");
					    sb.append("<Result>");
					    sb.append("\n");
					    sb.append("Fail");
					    sb.append("\n");
					    sb.append("</Result>");
					    sb.append("\n");
					    sb.append("<Description>");
					    
					    sb.append("could not get by id QuestionPaper info");
					    sb.append("</Description>");
					    sb.append("\n");
					    sb.append("<Exception>");
					    sb.append(localException);
					    sb.append("</Exception>");
					    sb.append("</Response>");
					    sb.append("</questionPaperId>");
					    sb.append("</QuestionPaper>");
					    strg= sb.toString();
					   MDTransactionWriter.exceptionlog.info(localException);
					  if (gtTx!=null)
						  gtTx.rollback();
					} finally {
						gtempSession.close();
					}
			return strg;
	}

	public String getAllQuestionPaper(int PNO, int size,int schoolId,int branchId) {
		Session rdSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb= new StringBuffer();
		String string=null;
		//QuestionPaperPojo ex=null;
		
		try
		{
			tx = rdSession.beginTransaction();
			
			if(("all") != null)
			   {
			    int fset = (PNO-1)*size;
			    String gsSql ="select count(*) from gbl_sm_tbl_question_paper as qp where qp.IsDeleted <> 'Y' or qp.IsDeleted IS NULL and qp.SchoolId ='" + schoolId + "' and qp.BranchId ='" + branchId + "'";
			    Query gsQuery=rdSession.createSQLQuery(gsSql);
			    Object noRecords= gsQuery.uniqueResult();
			    sb.append("<QuestionPapers>");
			    sb.append("\n");
			    sb.append("<noRecords>"+noRecords+"</noRecords>");
			    sb.append("\n");
			    
			     if (PNO > 0 & size > 0){
			     gsSql="select qp.QuestionPaperId,qp.Instructions,qp.PaperTitle,qp.`Level`,qp.`Status`,qp.Description,qp.Remarks,qp.CreatedDate,qp.ModifiedDate,qp.SchoolId,qp.BranchId,sub.ClassId,cls.ClassName,sub.SectionId,sec.SectionName,qp.SubjectId,sbt.SubjectTypeId,sbt.SubjectName from gbl_sm_tbl_question_paper as qp join gbl_sm_tbl_subjects as sub on qp.SubjectId=sub.SubjectId join gbl_sm_tbl_class as cls on sub.ClassId = cls.ClassId join gbl_sm_tbl_section as sec on sub.SectionId = sec.SectionId join gbl_sm_tbl_subject_type as sbt on sub.SubjectTypeId = sbt.SubjectTypeId where qp.IsDeleted <> 'Y' or qp.IsDeleted IS NULL and qp.SchoolId ='" + schoolId + "' and qp.BranchId ='" + branchId + "' limit "+size+" offset "+fset;}
			     else {
			      gsSql="select qp.QuestionPaperId,qp.Instructions,qp.PaperTitle,qp.`Level`,qp.`Status`,qp.Description,qp.Remarks,qp.CreatedDate,qp.ModifiedDate,qp.SchoolId,qp.BranchId,sub.ClassId,cls.ClassName,sub.SectionId,sec.SectionName,qp.SubjectId,sbt.SubjectTypeId,sbt.SubjectName from gbl_sm_tbl_question_paper as qp join gbl_sm_tbl_subjects as sub on qp.SubjectId=sub.SubjectId join gbl_sm_tbl_class as cls on sub.ClassId = cls.ClassId join gbl_sm_tbl_section as sec on sub.SectionId = sec.SectionId join gbl_sm_tbl_subject_type as sbt on sub.SubjectTypeId = sbt.SubjectTypeId where qp.IsDeleted <> 'Y' or qp.IsDeleted IS NULL and qp.SchoolId ='" + schoolId + "' and qp.BranchId ='" + branchId + "'";
			     } 
			   
			    gsQuery=rdSession.createSQLQuery(gsSql);
			    List gcList=gsQuery.list();
			    Iterator gsIT=gcList.iterator();
			    while(gsIT.hasNext())
			     {
			    	 Object[] ex=(Object[])gsIT.next();
			    	 sb.append("<QuestionPaper>");
					 sb.append("\n");
					 sb.append("<questionPaperId>");
			         sb.append(ex[0]);
			         sb.append("</questionPaperId>");
			         sb.append("\n");
			         sb.append("<instructions>");
			         sb.append(ex[1]);
			         sb.append("</instructions>");
			         sb.append("\n");
			         sb.append("<paperTitle>");
			         sb.append(ex[2]);
			         sb.append("</paperTitle>");
			         sb.append("\n");
			         sb.append("<level>");
			         sb.append(ex[3]);
			         sb.append("</level>");
			         sb.append("\n");
			         sb.append("<status>");
			         sb.append(ex[4]);
			         sb.append("</status>");
			         sb.append("\n");
			         sb.append("<description>");
			         sb.append(ex[5]);
			         sb.append("</description>");
			         sb.append("\n");
			         sb.append("<remarks>");
			         sb.append(ex[6]);
			         sb.append("</remarks>");
			         sb.append("\n");
			         sb.append("<createdDate>");
			         sb.append(ex[7]);
			         sb.append("</createdDate>");
			         sb.append("\n");
			         sb.append("<modifiedDate>");
			         sb.append(ex[8]);
			         sb.append("</modifiedDate>");
			         sb.append("\n");
			         sb.append("<schoolId>");
			         sb.append(ex[9]);
			         sb.append("</schoolId>");
			         sb.append("\n");
			         sb.append("<branchId>");
			         sb.append(ex[10]);
			         sb.append("</branchId>");
			         sb.append("\n");
			         sb.append("<classId>");
			         sb.append(ex[11]);
			         sb.append("</classId>");
			         sb.append("\n");
			         sb.append("<className>");
			         sb.append(ex[12]);
			         sb.append("</className>");
			         sb.append("\n");
					 sb.append("<sectionId>");
					 sb.append(ex[13]);
					 sb.append("</sectionId>");
					 sb.append("\n");
					 sb.append("<sectionName>");
					 sb.append(ex[14]);
					 sb.append("</sectionName>");
					 sb.append("\n");
					    sb.append("<subjectId>");
				         sb.append(ex[15]);
				         sb.append("</subjectId>");
				         sb.append("\n");
						 sb.append("<subjectTypeId>");
						 sb.append(ex[16]);
						 sb.append("</subjectTypeId>");
						 sb.append("\n");
						 sb.append("<subjectName>");
						 sb.append(ex[17]);
						 sb.append("</subjectName>");
						 sb.append("\n");
			         sb.append("</QuestionPaper>");
			    	}
			}
			sb.append("</QuestionPapers>");
					    String str= sb.toString();
						 tx.commit();
					return str;
			
		
		}
		catch(Exception localException)
		{
			System.out.println(localException);
			
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    
			    sb.append("could not delete QuestionPaper info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    string= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (tx!=null)
				  tx.rollback();
		
			
		}
		finally
		{
			rdSession.close();
		
		}
		return string;
	}

}
