package com.gwebitsol.core.assessments;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="PaperSection")
public class PaperSectionPojo {
	private int paperSectionId;
	private String sectionTitle;
	private String instructions;
	private int questionPaperId;
	private int schoolId;
	private int branchId;
	
	public int getPaperSectionId() {
		return paperSectionId;
	}
	public void setPaperSectionId(int paperSectionId) {
		this.paperSectionId = paperSectionId;
	}
	public String getSectionTitle() {
		return sectionTitle;
	}
	public void setSectionTitle(String sectionTitle) {
		this.sectionTitle = sectionTitle;
	}
	public String getInstructions() {
		return instructions;
	}
	public void setInstructions(String instructions) {
		this.instructions = instructions;
	}
	public int getQuestionPaperId() {
		return questionPaperId;
	}
	public void setQuestionPaperId(int questionPaperId) {
		this.questionPaperId = questionPaperId;
	}
	public int getSchoolId() {
		return schoolId;
	}
	public void setSchoolId(int schoolId) {
		this.schoolId = schoolId;
	}
	public int getBranchId() {
		return branchId;
	}
	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}
	
	QuestionList questionList = new QuestionList();

	public QuestionList getQuestionList() {
		return questionList;
	}
	public void setQuestionList(QuestionList questionList) {
		this.questionList = questionList;
	}
	
	@XmlElementWrapper(name="Questions")
	@XmlElement(name="Question")
	
	public List<QuestionsPaperSectionPojo> getQuestionsPaperSectionPojo() {
		return questionList.getQuestionsPaperSectionPojo();
	}
	
	public void setQuestionsPaperSectionPojo(List<QuestionsPaperSectionPojo> questionsPaperSectionPojo) {
		questionList.setQuestionsPaperSectionPojo(questionsPaperSectionPojo);
	}
}
