package com.gwebitsol.core.assessments;

import java.util.Iterator;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class AnswerDao {
	Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
	Transaction tx = null;
	public String addAnswer(AnswerPojo answerPojo) {
			String strg= null;
			 StringBuffer sb= new StringBuffer();
			 try {
					tx = rdSession.beginTransaction();
					Integer i=(Integer) rdSession.save(answerPojo);
					
					tx.commit();
					sb.append("<answer>");
					sb.append("\n");
					sb.append("<id>");
					sb.append(i);
								  sb.append("</id>");
								  sb.append("\n");
								  sb.append("</answer>");
								  strg= sb.toString();
		
							} catch (Exception localException) {
								
								System.out.println(localException);
								
								   sb.append("<Response>");
								    sb.append("\n");
								    sb.append("<Result>");
								    sb.append("\n");
								    sb.append("Fail");
								    sb.append("\n");
								    sb.append("</Result>");
								    sb.append("\n");
								    sb.append("<Description>");
								    
								    sb.append("could not inserted answer info");
								    sb.append("</Description>");
								    sb.append("\n");
								    sb.append("<Exception>");
								    sb.append(localException);
								    sb.append("</Exception>");
								    sb.append("</Response>");
								     strg= sb.toString();
								   MDTransactionWriter.exceptionlog.info(localException);
								  if (tx!=null)
								   tx.rollback();
			
							} finally {
								rdSession.close();
	    	 		
							}
					return strg;
					}
	

	public String deleteAnswer(int id,int schoolId,int branchId) {
		StringBuffer sb=new StringBuffer();
		String strg= null;
		try {
				tx = rdSession.beginTransaction();
				
				AnswerPojo answer = (AnswerPojo) rdSession.get(AnswerPojo.class,id);
				   
				   int branid = answer.getBranchId();
				   int sclid = answer.getSchoolId();
				   rdSession.evict(answer);             
				   if(branchId==branid&&schoolId==sclid)
				   {
				Query empQuery=rdSession.createSQLQuery("update gbl_sm_tbl_student_answer set IsDeleted ='Y' where answerId='"+id+"'");
				empQuery.executeUpdate();
						            tx.commit();
								    strg="<delete>Answer id deleted</delete>";
								    sb.append("<Answer>");
								    sb.append("\n");
								    sb.append("<id>");
									sb.append("\n");
									sb.append(strg);
									sb.append("</id>");
									sb.append("\n");
									sb.append("</Answer>");
									String str= sb.toString();
									return str;
						}
				   else
				   {
				    strg = "student answer is not deleted";
				    sb.append("<Answer>");
				    sb.append("\n");
				    sb.append(strg);
				    sb.append("</Answer>");
				    String str = sb.toString();
				    return str;
				   }
					}
						catch(Exception localException)
						{
							System.out.println(localException);
							
							   sb.append("<Response>");
							    sb.append("\n");
							    sb.append("<Result>");
							    sb.append("\n");
							    sb.append("Fail");
							    sb.append("\n");
							    sb.append("</Result>");
							    sb.append("\n");
							    sb.append("<Description>");
							    
							    sb.append("could not delete answer info");
							    sb.append("</Description>");
							    sb.append("\n");
							    sb.append("<Exception>");
							    sb.append(localException);
							    sb.append("</Exception>");
							    sb.append("</Response>");
							     strg= sb.toString();
							   MDTransactionWriter.exceptionlog.info(localException);
							  if (tx!=null)
							   tx.rollback();
						}
						finally
						{
						
						rdSession.close();
						}
					return strg;
				
	}

	public String updateAnswer(AnswerPojo answerPojo,int schoolId,int branchId) {
		StringBuffer sb= new StringBuffer();
		String string= null;
		try {
				tx = rdSession.beginTransaction();
				
				AnswerPojo answer = (AnswerPojo) rdSession.get(AnswerPojo.class,answerPojo.getAnswerId());
				   
				if(branchId==answer.getBranchId()&&schoolId==answer.getSchoolId())
				    
				   rdSession.evict(answer);
				
				        rdSession.update(answerPojo);
					    tx.commit();
					 	string = "<update>answer succssfully updated</update>";
						sb.append("<answer>");
						sb.append("\n");
					    sb.append("<id>");
						sb.append("\n");
						sb.append(string);
						sb.append("</id>");
						sb.append("\n");
						sb.append("</answer>");
						String str= sb.toString();			    
						return str;
								
						}catch (Exception localException) {
							System.out.println(localException);
							
							   sb.append("<Response>");
							    sb.append("\n");
							    sb.append("<Result>");
							    sb.append("\n");
							    sb.append("Fail");
							    sb.append("\n");
							    sb.append("</Result>");
							    sb.append("\n");
							    sb.append("<Description>");
							    
							    sb.append("could not update answer info");
							    sb.append("</Description>");
							    sb.append("\n");
							    sb.append("<Exception>");
							    sb.append(localException);
							    sb.append("</Exception>");
							    sb.append("</Response>");
							     string= sb.toString();
							   MDTransactionWriter.exceptionlog.info(localException);
							  if (tx!=null)
							   tx.rollback();
							} 
							finally {
									rdSession.close();
									}
						return string;
	}
	public String getAllAnswer(int PNO, int size,int schoolId,int branchId) {
		StringBuffer sb= new StringBuffer();
		String string=null;
		AnswerPojo sub=null;
						
		try
			{
			tx = rdSession.beginTransaction();
			
			 if(("all") != null)
			   {
			    int fset = (PNO-1)*size;
			    String gsSql ="select count(*) from gbl_sm_tbl_student_answer as sa where sa.IsDeleted <> 'Y' or sa.IsDeleted IS NULL and sa.SchoolId ='" + schoolId + "'  and sa.BranchId ='" + branchId + "'";
			    Query gsQuery=rdSession.createSQLQuery(gsSql);
			    Object noRecords= gsQuery.uniqueResult();
			    sb.append("<StudentAnswers>");
			    sb.append("\n");
			    sb.append("<noRecords>"+noRecords+"</noRecords>");
			    sb.append("\n");
			    
			     if (PNO > 0 & size > 0){
			     gsSql="SELECT sa.AnswerId,sa.QuestionPaperId,qp.PaperTitle,sa.StudentId,st.StudentNumber,st.FirstName,st.MiddleName,st.LastName,sa.QuestionId, q.QuestionTitle,sa.StudentChoice,sa.StudentScore,sa.StudentAnswer,sa.`Status`,sa.SchoolId,sa.BranchId FROM gbl_sm_tbl_student_answer sa JOIN gbl_sm_tbl_question_paper qp JOIN gbl_sm_tbl_student st JOIN gbl_sm_tbl_question q ON sa.QuestionPaperId = qp.QuestionPaperId and sa.StudentId = st.StudentId and sa.QuestionId = q.QuestionId where sa.IsDeleted <> 'Y' or sa.IsDeleted IS NULL and sa.SchoolId ='" + schoolId + "'  and sa.BranchId ='" + branchId + "' limit "+size+" offset "+fset;}
			     else {
			      gsSql="SELECT sa.AnswerId,sa.QuestionPaperId,qp.PaperTitle,sa.StudentId,st.StudentNumber,st.FirstName,st.MiddleName,st.LastName,sa.QuestionId, q.QuestionTitle,sa.StudentChoice,sa.StudentScore,sa.StudentAnswer,sa.`Status`,sa.SchoolId,sa.BranchId FROM gbl_sm_tbl_student_answer sa JOIN gbl_sm_tbl_question_paper qp JOIN gbl_sm_tbl_student st JOIN gbl_sm_tbl_question q ON sa.QuestionPaperId = qp.QuestionPaperId and sa.StudentId = st.StudentId and sa.QuestionId = q.QuestionId where sa.IsDeleted <> 'Y' or sa.IsDeleted IS NULL and sa.SchoolId ='" + schoolId + "'  and sa.BranchId ='" + branchId + "'";
			     } 
			   
			    gsQuery=rdSession.createSQLQuery(gsSql);
			    List gcList=gsQuery.list();
			    Iterator gsIT=gcList.iterator();
			    while(gsIT.hasNext())
			     {
			    	 Object[] ex=(Object[])gsIT.next();
			    	 sb.append("<StudentAnswer>");
			    	 sb.append("\n");
				     sb.append("<answerId>");
				     sb.append(ex[0]);
				     sb.append("</answerId>");
				     sb.append("\n");
				     sb.append("<questionPaperId>");
				     sb.append(ex[1]);
				     sb.append("</questionPaperId>");
				     sb.append("\n");
				     sb.append("<paperTitle>");
				     sb.append(ex[2]);
				     sb.append("</paperTitle>");
				     sb.append("\n");
				     sb.append("<studentId>");
				     sb.append(ex[3]);
				     sb.append("</studentId>");
				     sb.append("\n");
				     sb.append("<studentNumber>");
				     sb.append(ex[4]);
				     sb.append("</studentNumber>");
				     sb.append("\n");
				     sb.append("<firstName>");
				     sb.append(ex[5]);
				     sb.append("</firstName>");
				     sb.append("\n");
				     sb.append("<middleName>");
				     sb.append(ex[6]);
				     sb.append("</middleName>");
				     sb.append("\n");
				     sb.append("<lastName>");
					 sb.append(ex[7]);
					 sb.append("</lastName>");
					 sb.append("\n");
					 sb.append("<questionId>");
					 sb.append(ex[8]);
					 sb.append("</questionId>");
					 sb.append("\n");
					 sb.append("<questionTitle>");
					 sb.append(ex[9]);
					 sb.append("</questionTitle>");
					 sb.append("\n");
						sb.append("<studentChoice>");
						sb.append(ex[10]);
						sb.append("</studentChoice>");
						 sb.append("\n");
						sb.append("<studentScore>");
						sb.append(ex[11]);
						sb.append("</studentScore>");
						sb.append("\n");
						sb.append("<studentAnswer>");
						sb.append(ex[12]);
						sb.append("</studentAnswer>");
						sb.append("\n");
						sb.append("<status>");
						sb.append(ex[13]);
						sb.append("</status>");
						sb.append("\n");
						sb.append("<schoolId>");
						sb.append(ex[14]);
						sb.append("</schoolId>");
						sb.append("\n");
						sb.append("<branchId>");
						sb.append(ex[15]);
						sb.append("</branchId>");
						sb.append("\n");
						 sb.append("</StudentAnswer>");
							}
						}
							sb.append("</StudentAnswers>");
								 string= sb.toString();
									tx.commit();
								
						}
						catch(Exception localException)
						{
							System.out.println(localException);
							
							   sb.append("<Response>");
							    sb.append("\n");
							    sb.append("<Result>");
							    sb.append("\n");
							    sb.append("Fail");
							    sb.append("\n");
							    sb.append("</Result>");
							    sb.append("\n");
							    sb.append("<Description>");
							    
							    sb.append("could not getall answer info");
							    sb.append("</Description>");
							    sb.append("\n");
							    sb.append("<Exception>");
							    sb.append(localException);
							    sb.append("</Exception>");
							    sb.append("</Response>");
							     string= sb.toString();
							   MDTransactionWriter.exceptionlog.info(localException);
							  if (tx!=null)
							   tx.rollback();
						}
						finally
						{
							rdSession.close();
						
						}
						return string;
					
					}
	public String getByIdAnswer(int id,int schoolId,int branchId) {
		StringBuffer sb= new StringBuffer();
		String strg= null;
		try {
			tx = rdSession.beginTransaction();
			List list=rdSession.createSQLQuery("SELECT sa.AnswerId,sa.QuestionPaperId,qp.PaperTitle,stu.ClassId,cls.ClassName,stu.SectionId,sec.SectionName,sa.StudentId,st.StudentNumber,st.FirstName,st.MiddleName,st.LastName,sa.QuestionId, q.QuestionTitle,sa.StudentChoice,sa.StudentScore,sa.StudentAnswer,sa.`Status`,sa.SchoolId,sa.BranchId FROM gbl_sm_tbl_student_answer sa JOIN gbl_sm_tbl_question_paper qp on sa.QuestionPaperId = qp.QuestionPaperId JOIN gbl_sm_tbl_question q ON sa.QuestionId = q.QuestionId JOIN gbl_sm_tbl_student st on sa.StudentId = st.StudentId JOIN gbl_sm_tbl_student_education stu on stu.StudentId = st.StudentId JOIN gbl_sm_tbl_class cls on stu.ClassId = cls.ClassId JOIN gbl_sm_tbl_section sec on stu.SectionId = sec.SectionId where sa.IsDeleted <> 'Y' or sa.IsDeleted IS NULL and AnswerId ='" + id + "' and sa.SchoolId ='" + schoolId + "'  and sa.BranchId ='" + branchId + "';").list();
		     Iterator it=list.iterator();
		    		  
				        while(it.hasNext())
				        {
				       	 Object[] ex=(Object[])it.next();
				    	 sb.append("<StudentAnswer>");
				    	 sb.append("\n");
					     sb.append("<answerId>");
					     sb.append(ex[0]);
					     sb.append("</answerId>");
					     sb.append("\n");
					     sb.append("<questionPaperId>");
					     sb.append(ex[1]);
					     sb.append("</questionPaperId>");
					     sb.append("\n");
					     sb.append("<paperTitle>");
					     sb.append(ex[2]);
					     sb.append("</paperTitle>");
					     sb.append("\n");
					     sb.append("<classId>");
					     sb.append(ex[3]);
					     sb.append("</classId>");
					     sb.append("\n");
					     sb.append("<className>");
					     sb.append(ex[4]);
					     sb.append("</className>");
					     sb.append("\n");
					     sb.append("<sectionId>");
					     sb.append(ex[5]);
					     sb.append("</sectionId>");
					     sb.append("\n");  
					     sb.append("<sectionName>");
					     sb.append(ex[6]);
					     sb.append("</sectionName>");
					     sb.append("\n");
					     sb.append("<studentId>");
					     sb.append(ex[7]);
					     sb.append("</studentId>");
					     sb.append("\n");
					     sb.append("<studentNumber>");
					     sb.append(ex[8]);
					     sb.append("</studentNumber>");
					     sb.append("\n");
					     sb.append("<firstName>");
					     sb.append(ex[9]);
					     sb.append("</firstName>");
					     sb.append("\n");
					     sb.append("<middleName>");
					     sb.append(ex[10]);
					     sb.append("</middleName>");
					     sb.append("\n");
					     sb.append("<lastName>");
						 sb.append(ex[11]);
						 sb.append("</lastName>");
						 sb.append("\n");
						 sb.append("<questionId>");
						 sb.append(ex[12]);
						 sb.append("</questionId>");
						 sb.append("\n");
						 sb.append("<questionTitle>");
						 sb.append(ex[13]);
						 sb.append("</questionTitle>");
						 sb.append("\n");
							sb.append("<studentChoice>");
							sb.append(ex[14]);
							sb.append("</studentChoice>");
							 sb.append("\n");
							sb.append("<studentScore>");
							sb.append(ex[15]);
							sb.append("</studentScore>");
							sb.append("\n");
							sb.append("<studentAnswer>");
							sb.append(ex[16]);
							sb.append("</studentAnswer>");
							sb.append("\n");
							sb.append("<status>");
							sb.append(ex[17]);
							sb.append("</status>");
							sb.append("\n");
							sb.append("<schoolId>");
							sb.append(ex[18]);
							sb.append("</schoolId>");
							sb.append("\n");
							sb.append("<branchId>");
							sb.append(ex[19]);
							sb.append("</branchId>");
							sb.append("\n");
							 sb.append("</StudentAnswer>");
					    strg= sb.toString();
				        }
						
							
							} 	catch (Exception localException) {
								System.out.println(localException);
								
								   sb.append("<Response>");
								    sb.append("\n");
								    sb.append("<Result>");
								    sb.append("\n");
								    sb.append("Fail");
								    sb.append("\n");
								    sb.append("</Result>");
								    sb.append("\n");
								    sb.append("<Description>");
								    sb.append("could not getbyid answer info");
								    sb.append("</Description>");
								    sb.append("\n");
								    sb.append("<Exception>");
								    sb.append(localException);
								    sb.append("</Exception>");
								    sb.append("</Response>");
								    sb.append("</answerId>");
								    sb.append("</Answer>");
								     strg= sb.toString();
								   MDTransactionWriter.exceptionlog.info(localException);
								  if (tx!=null)
								   tx.rollback();
								} finally {
									rdSession.close();
								}
						return strg;
	}


	public String getAnswerbyquestion(int questionId,int schoolId,int branchId) {
		StringBuffer sb= new StringBuffer();
		String strg= null;
		try {
			tx = rdSession.beginTransaction();
			List list=rdSession.createSQLQuery("SELECT sa.QuestionId,sa.AnswerId,sa.QuestionPaperId,qp.PaperTitle,sa.StudentId,st.StudentNumber,st.FirstName,st.MiddleName,st.LastName,q.QuestionTitle,sa.StudentChoice,sa.StudentScore,sa.StudentAnswer,sa.`Status`,sa.SchoolId,sa.BranchId FROM gbl_sm_tbl_student_answer sa JOIN gbl_sm_tbl_question_paper qp JOIN gbl_sm_tbl_student st JOIN gbl_sm_tbl_question q ON sa.QuestionPaperId = qp.QuestionPaperId and sa.StudentId = st.StudentId and sa.QuestionId = q.QuestionId where sa.IsDeleted <> 'Y' or sa.IsDeleted IS NULL and q.QuestionId ='" + questionId + "' and sa.SchoolId ='" + schoolId + "'  and sa.BranchId ='" + branchId + "' ;").list();
		     Iterator it=list.iterator();
		    		  
				        while(it.hasNext())
				        {
				       	 Object[] ex=(Object[])it.next();
				    	 sb.append("<QuestionbyAnswer>");
				    	 sb.append("\n");
						 sb.append("<questionId>");
						 sb.append(ex[0]);
						 sb.append("</questionId>");
						 sb.append("\n");
					     sb.append("<answerId>");
					     sb.append(ex[1]);
					     sb.append("</answerId>");
					     sb.append("\n");
					     sb.append("<questionPaperId>");
					     sb.append(ex[2]);
					     sb.append("</questionPaperId>");
					     sb.append("\n");
					     sb.append("<paperTitle>");
					     sb.append(ex[3]);
					     sb.append("</paperTitle>");
					     sb.append("\n");
					     sb.append("<studentId>");
					     sb.append(ex[4]);
					     sb.append("</studentId>");
					     sb.append("\n");
					     sb.append("<studentNumber>");
					     sb.append(ex[5]);
					     sb.append("</studentNumber>");
					     sb.append("\n");
					     sb.append("<firstName>");
					     sb.append(ex[6]);
					     sb.append("</firstName>");
					     sb.append("\n");
					     sb.append("<middleName>");
					     sb.append(ex[7]);
					     sb.append("</middleName>");
					     sb.append("\n");
					     sb.append("<lastName>");
						 sb.append(ex[8]);
						 sb.append("</lastName>");
						 sb.append("\n");
						 sb.append("<questionTitle>");
						 sb.append(ex[9]);
						 sb.append("</questionTitle>");
						 sb.append("\n");
							sb.append("<studentChoice>");
							sb.append(ex[10]);
							sb.append("</studentChoice>");
							 sb.append("\n");
							sb.append("<studentScore>");
							sb.append(ex[11]);
							sb.append("</studentScore>");
							sb.append("\n");
							sb.append("<studentAnswer>");
							sb.append(ex[12]);
							sb.append("</studentAnswer>");
							sb.append("\n");
							sb.append("<status>");
							sb.append(ex[13]);
							sb.append("</status>");
							sb.append("\n");
							sb.append("<schoolId>");
							sb.append(ex[14]);
							sb.append("</schoolId>");
							sb.append("\n");
							sb.append("<branchId>");
							sb.append(ex[15]);
							sb.append("</branchId>");
							sb.append("\n");
							 sb.append("</QuestionbyAnswer>");
					    strg= sb.toString();
				        }
						
							
							} 	catch (Exception localException) {
								System.out.println(localException);
								
								   sb.append("<Response>");
								    sb.append("\n");
								    sb.append("<Result>");
								    sb.append("\n");
								    sb.append("Fail");
								    sb.append("\n");
								    sb.append("</Result>");
								    sb.append("\n");
								    sb.append("<Description>");
								    sb.append("could not getbyid answer info");
								    sb.append("</Description>");
								    sb.append("\n");
								    sb.append("<Exception>");
								    sb.append(localException);
								    sb.append("</Exception>");
								    sb.append("</Response>");
								    sb.append("</answerId>");
								    sb.append("</Answer>");
								     strg= sb.toString();
								   MDTransactionWriter.exceptionlog.info(localException);
								  if (tx!=null)
								   tx.rollback();
								} finally {
									rdSession.close();
								}
						return strg;
	}
}
