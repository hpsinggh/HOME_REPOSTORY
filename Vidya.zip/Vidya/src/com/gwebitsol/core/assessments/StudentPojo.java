package com.gwebitsol.core.assessments;


import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="Student")
public class StudentPojo {
	
	private int studentId;
	private int classId;
	private String sectionId;
	
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public int getClassId() {
		return classId;
	}
	public void setClassId(int classId) {
		this.classId = classId;
	}
	public String getSectionId() {
		return sectionId;
	}
	public void setSectionId(String sectionId) {
		this.sectionId = sectionId;
	}
	
}
