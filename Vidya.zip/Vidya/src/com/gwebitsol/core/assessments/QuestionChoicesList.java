package com.gwebitsol.core.assessments;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="QuestionChoices")
public class QuestionChoicesList {
	List<QuestionChoice> questionchoice;

	public List<QuestionChoice> getQuestionchoice() {
		return questionchoice;
	}

	public void setQuestionchoice(List<QuestionChoice> questionchoice) {
		this.questionchoice = questionchoice;
	}

}
