package com.gwebitsol.core.assessments;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="Question")
public class QuestionPojo {
	private int questionId;
	private String questionTitle;
	private String questiondescription;
	private String answer;
	private int maxScore;
	private int questiontypeId;
	private int schoolId;
	private int branchId;
	private int subjectId;
	private int unitId;
	private int chapterId;
	private int topicId;
	private int courseId;
	
	private String  createdDate;
	 
	 DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	  Date date = new Date();
	  String modifiedDate=dateFormat.format(date);
	 
	  
	  public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	protected String getModifiedDate() {
	  return modifiedDate;
	 }
	 protected void setModifiedDate(String modifiedDate) {
	  this.modifiedDate = modifiedDate;
	 }
	
	public int getQuestiontypeId() {
		return questiontypeId;
	}
	public void setQuestiontypeId(int questiontypeId) {
		this.questiontypeId = questiontypeId;
	}
	public int getQuestionId() {
		return questionId;
	}
	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}
	public String getQuestionTitle() {
		return questionTitle;
	}
	public void setQuestionTitle(String questionTitle) {
		this.questionTitle = questionTitle;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public int getMaxScore() {
		return maxScore;
	}
	public void setMaxScore(int maxScore) {
		this.maxScore = maxScore;
	}
	public String getQuestiondescription() {
		return questiondescription;
	}
	public void setQuestiondescription(String questiondescription) {
		this.questiondescription = questiondescription;
	}
	public int getSchoolId() {
		return schoolId;
	}
	public void setSchoolId(int schoolId) {
		this.schoolId = schoolId;
	}
	public int getBranchId() {
		return branchId;
	}
	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}
	public int getSubjectId() {
		return subjectId;
	}
	public void setSubjectId(int subjectId) {
		this.subjectId = subjectId;
	}
	public int getUnitId() {
		return unitId;
	}
	public void setUnitId(int unitId) {
		this.unitId = unitId;
	}
	public int getChapterId() {
		return chapterId;
	}
	public void setChapterId(int chapterId) {
		this.chapterId = chapterId;
	}
	public int getTopicId() {
		return topicId;
	}
	public void setTopicId(int topicId) {
		this.topicId = topicId;
	}
	public int getCourseId() {
		return courseId;
	}
	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}
	
	
	QuestionChoicesList qcList = new QuestionChoicesList();
	
	
	public QuestionChoicesList getQcList() {
		return qcList;
	}
	public void setQcList(QuestionChoicesList qcList) {
		this.qcList = qcList;
	}
	@XmlElementWrapper(name="QuestionChoices")
	@XmlElement(name="QuestionChoice")
	
	public List<QuestionChoice> getQuestionchoice() {
		return qcList.getQuestionchoice();
	}
	
	public void setQuestionchoice(List<QuestionChoice> questionchoice) {
		qcList.setQuestionchoice(questionchoice);
	}
	
}