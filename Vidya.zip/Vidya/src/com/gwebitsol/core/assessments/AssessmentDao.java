package com.gwebitsol.core.assessments;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class AssessmentDao {
	
	public String addAssessment(AssessmentPojo ap) {
		Session addempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction addempTx=null;
		String strg= null;
		StringBuffer sb=new StringBuffer();
		try
		{
		
			addempTx=addempSession.beginTransaction();
			
			int assessmentId;
			assessmentId=(Integer)addempSession.save(ap);
			List studentList=ap.getStuList().getStudentPojo();
			Iterator stuItr=studentList.iterator();
			String insertVals="";
			 StringBuffer flSB=new StringBuffer();
			 boolean isStuProcessed=false;
			while(stuItr.hasNext())
			{
				
				StudentPojo stuPojoObj=(StudentPojo)stuItr.next();
				insertVals="";
			if(ap.getQuestionPaperId()!=null && !"".equalsIgnoreCase(ap.getQuestionPaperId()) && stuPojoObj.getStudentId()!=0)
			{
				isStuProcessed=true;
				String[] qpidSplit=null;
				qpidSplit = ap.getQuestionPaperId().split(",");
				 for(int qpidCount=0;qpidCount<=qpidSplit.length-1;qpidCount++)
			    {
					 if(qpidCount!=0){
					 insertVals+=", ("+assessmentId+","+stuPojoObj.getClassId()+","+stuPojoObj.getSectionId()+","+stuPojoObj.getStudentId()+","+qpidSplit[qpidCount]+")";
					 }else{
						 insertVals+="("+assessmentId+","+stuPojoObj.getClassId()+","+stuPojoObj.getSectionId()+","+stuPojoObj.getStudentId()+","+qpidSplit[qpidCount]+")";
					 }
			    }
				 String insertQuery="insert into gbl_sm_tbl_assessment_assign(assessmentId,classId,sectionId,studentId,QuestionPaperId) VALUES"+insertVals;
				 Query query =addempSession.createSQLQuery(insertQuery);
				 query.executeUpdate();
			}
			}
			if(!isStuProcessed && ap.getQuestionPaperId()!=null && !"".equalsIgnoreCase(ap.getQuestionPaperId()))
			{
				
				String classIds="";
				String sectionIds="";
				if(ap.getSectionId()!=null && !"".equalsIgnoreCase(ap.getSectionId()))
				{
					sectionIds+=ap.getSectionId();
				}else
				{
					if(ap.getClassId()!=0){
						classIds+=ap.getClassId();
					}else{
						classIds=(String)addempSession.createSQLQuery("SELECT GROUP_CONCAT(DISTINCT classid ORDER BY classid) as classIds FROM gbl_sm_tbl_class where (IsDeleted<>'y' or IsDeleted is null) and BranchId = '"+ap.getBranchId()+"' and SchoolId = '"+ap.getSchoolId()+"'").addScalar("classIds", Hibernate.STRING).uniqueResult();
						
					}
					sectionIds=(String)addempSession.createSQLQuery("SELECT GROUP_CONCAT(DISTINCT sectionid ORDER BY sectionid) as sectionIds FROM gbl_sm_tbl_section where (IsDeleted<>'y' or IsDeleted is null) and classid in ("+classIds+") and BranchId = '"+ap.getBranchId()+"' and SchoolId = '"+ap.getSchoolId()+"'").addScalar("sectionIds", Hibernate.STRING).uniqueResult();
					
				}
				 String insertQuery="select classId,sectionId,studentId from gbl_sm_tbl_student_education where sectionid in ("+sectionIds+") and BranchId = '"+ap.getBranchId()+"' and SchoolId = '"+ap.getSchoolId()+"'";
				 Query gsQuery=addempSession.createSQLQuery(insertQuery);
				    List gcList=gsQuery.list();
				    Iterator gsIT=gcList.iterator();
				    while(gsIT.hasNext())
				     {
				    	Object[] stuDetails=(Object[])gsIT.next();
				    	
							String[] qpidSplit=null;
							qpidSplit = ap.getQuestionPaperId().split(",");
							insertVals="";
							 for(int qpidCount=0;qpidCount<=qpidSplit.length-1;qpidCount++)
						    {
								 if(qpidCount!=0){
								 insertVals+=", ("+assessmentId+","+stuDetails[0]+","+stuDetails[1]+","+stuDetails[2]+","+qpidSplit[qpidCount]+")";
								 }else{
									 insertVals+="("+assessmentId+","+stuDetails[0]+","+stuDetails[1]+","+stuDetails[2]+","+qpidSplit[qpidCount]+")";
								 }
						    }
							 String insertQuery1="insert into gbl_sm_tbl_assessment_assign(assessmentId,classId,sectionId,studentId,QuestionPaperId) VALUES"+insertVals;
							 Query query1 =addempSession.createSQLQuery(insertQuery1);
							 query1.executeUpdate();
						}
				     
			}
			
			addempTx.commit();
			sb.append("<Assessment>");
			sb.append("\n");
			sb.append("<Assessmentid>");
			sb.append(assessmentId);
			sb.append("</Assessmentid>");
			sb.append("</Assessment>");
			strg=sb.toString();
			}
		
		catch(Exception localException)
		{
			
			System.out.println(localException);
			
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    
			    sb.append("could not inserted assessment info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			     strg= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (addempTx!=null)
				  addempTx.rollback();
		}
		finally
		{			
			addempSession.close();
		}
		return strg;
	}

	public String updateAssessment(AssessmentPojo ap,int schoolId,int branchId) {
		Session upempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction upempTx=null;
		StringBuffer sb=new StringBuffer();
		
		String outStr=null;
		try
		{
			upempTx=upempSession.beginTransaction();
			AssessmentPojo grade = (AssessmentPojo) upempSession.get(AssessmentPojo.class,ap.getAssessmentId());
			upempSession.evict(grade);
			if(branchId==grade.getBranchId()&&schoolId==grade.getSchoolId())
			upempSession.update(ap);
			upempTx.commit();
			sb.append("<Assessment>");
			sb.append("\n");
			sb.append("update sucessfully");
			sb.append("</Assessment>");
			String str=sb.toString();
			return str;
		   
   		 	}
		
		catch(Exception localException)
		{
			System.out.println(localException);
			
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    
			    sb.append("could not update assessment info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    outStr= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (outStr!=null)
				  upempTx.rollback();
		}
		finally
		{			
			upempSession.close();
		}
		return outStr;
	}

	public String deleteAssessment(int assessmentId,int schoolId,int branchId) {
		Session delempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction delempTx=null;
		StringBuffer sb=new StringBuffer();
		
		String outStr=null;
		try
		{
			delempTx=delempSession.beginTransaction();
			
			AssessmentPojo assessment = (AssessmentPojo) delempSession.get(AssessmentPojo.class,assessmentId);
			   
			   int branid = assessment.getBranchId();
			   int sclid = assessment.getSchoolId();
			   delempSession.evict(assessment);           
			   if(branchId==branid&&schoolId==sclid)
			   {
			Query empQuery=delempSession.createSQLQuery("update gbl_sm_tbl_assessment set IsDeleted ='Y' where assessmentId='"+assessmentId+"'");
			empQuery.executeUpdate();
			delempTx.commit();
			sb.append("<Assessment>");
			sb.append("\n");
			sb.append("deleted sucessfully");
			sb.append("</Assessment>");
			String str=sb.toString();
			return str;
   		 	}
			   else
			   {
				outStr = "assessment is not deleted";
			    sb.append("<Assessment>");
			    sb.append("\n");
			    sb.append(outStr);
			    sb.append("</Assessment>");
			    String str = sb.toString();
			    return str;
			   }
				}
		catch(Exception localException)
		{
			System.out.println(localException);
			
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    
			    sb.append("could not delete assessment info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    outStr= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (delempTx!=null)
				  delempTx.rollback();
		}
		finally
		{			
			delempSession.close();
		}
		return outStr;
	}

	public String getByIdAssessmentId(int assessmentId,int schoolId,int branchId) {
		Session gtempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gtTx=null;
			StringBuffer sb= new StringBuffer();
			System.out.println("hi dao impl success");
			String strg= null;
				try {
					gtTx = gtempSession.beginTransaction();
					List list=gtempSession.createSQLQuery("select ass.AssessmentId,ass.AssessmentTypeId,assty.TypeName,ass.AssessmentName,ass.MaxScore,ass.StartDate,ass.EndDate,ass.`Status`,ass.Description,ass.Remarks,ass.SchoolId,ass.BranchId,ass.CreatedDate,ass.ModifiedDate from gbl_sm_tbl_assessment as ass join gbl_sm_tbl_assessment_type as assty on ass.AssessmentTypeId = assty.AssessmentTypeId where (ass.isDeleted<>'y' or  ass.isDeleted is null) and ass.AssessmentId ='" + assessmentId + "' and ass.SchoolId ='" + schoolId + "'  and ass.BranchId ='" + branchId + "'").list();
				     Iterator it=list.iterator();
				     sb.append("<Assessments>");
					    sb.append("\n");
					    boolean lboolrecordExist=false;
					    int previousClsId=0;
						int previousSecId=0;
						int previousStuId=0;
						String qparerIds="";
						StringBuffer sbQuePapId= new StringBuffer();
						        while(it.hasNext())
						        {
								Object[] ex=(Object[])it.next();
								sb.append("<Assessment>");
							    sb.append("\n");
						        sb.append("<assessmentId>");
							    sb.append(ex[0]);
							    sb.append("</assessmentId>");
							    sb.append("\n");
							    sb.append("<assessmentTypeId>");
							    sb.append(ex[1]);
							    sb.append("</assessmentTypeId>");
							    sb.append("\n");
							    sb.append("<typeName>");
								sb.append(ex[2]);
								sb.append("</typeName>");
								 sb.append("\n");
								sb.append("<assessmentName>");
							    sb.append(ex[3]);
							    sb.append("</assessmentName>");
							    sb.append("\n");
								sb.append("<maxScore>");
								sb.append(ex[4]);
								sb.append("</maxScore>");
								sb.append("\n");
							    sb.append("<startDate>");
							    sb.append(ex[5]);
							    sb.append("</startDate>");
							    sb.append("\n");
							    sb.append("<endDate>");
								sb.append(ex[6]);
								sb.append("</endDate>");
								 sb.append("\n");
								sb.append("<status>");
								sb.append(ex[7]);
								sb.append("</status>");
								 sb.append("\n");
								sb.append("<description>");
								sb.append(ex[8]);
								sb.append("</description>");
								sb.append("\n");
								sb.append("<remarks>");
								sb.append(ex[9]);
								sb.append("</remarks>");
								sb.append("\n");
								sb.append("<schoolId>");
								sb.append(ex[10]);
								sb.append("</schoolId>");
								sb.append("\n");
								sb.append("<branchId>");
								sb.append(ex[11]);
								sb.append("</branchId>");
								sb.append("\n");
								sb.append("<createdDate>");
								sb.append(ex[12]);
								sb.append("</createdDate>");
								sb.append("\n");
								sb.append("<modifiedDate>");
								sb.append(ex[13]);
								sb.append("</modifiedDate>");
								sb.append("\n");
								
							      if(assessmentId!=0)
							      {
							     String  gsSql="select assas.AssessmentId, assas.ClassId,cls.ClassName,assas.SectionId,sec.SectionName,assas.StudentId,st.StudentNumber,st.FirstName,st.MiddleName,st.LastName,assas.QuestionPaperId,qp.PaperTitle from gbl_sm_tbl_assessment_assign as assas join gbl_sm_tbl_assessment as ass on  assas.AssessmentId= ass.AssessmentId join  gbl_sm_tbl_class as  cls on assas.ClassId=cls.ClassId join gbl_sm_tbl_section as sec on assas.SectionId=sec.SectionId join gbl_sm_tbl_student as st on assas.StudentId=st.StudentId join gbl_sm_tbl_question_paper as qp on assas.QuestionPaperId=qp.QuestionPaperId where  assas.AssessmentId='"+assessmentId+"' order by classid,sectionid";
							      Query gsQuery = gtempSession.createSQLQuery(gsSql);
									List parList1 = gsQuery.list();
									sb.append("<classes>");
									sb.append("\n");
									Iterator paIT = parList1.iterator();
									
									
									while (paIT.hasNext()) {
										Object[] paArr = (Object[]) paIT.next();
										if(previousClsId!=(Integer)paArr[1])
										{
											if(previousClsId!=0)
											{
												
												sb.append("</student>");
												sb.append("\n");
												sb.append("</students>");
												sb.append("\n");
												sb.append("</section>");
												sb.append("\n");
												sb.append("</sections>");
												sb.append("\n");
												sb.append("</class>");
												sb.append("\n");
											}
											previousClsId=(Integer)paArr[1];
										sb.append("<class>");
										sb.append("\n");
										sb.append("<classId>"+paArr[1]+"</classId>");
										sb.append("\n");
										sb.append("<className>"+paArr[2]+"</className>");
										sb.append("\n");
										sb.append("<sections>");
										sb.append("\n");
										previousSecId=0;
										}
										if(previousSecId!=(Integer)paArr[3]){
											if(previousSecId!=0)
											{
												
												sb.append("</student>");
												sb.append("\n");
												sb.append("</students>");
												sb.append("\n");
												sb.append("</section>");
												sb.append("\n");
											}
											previousSecId=(Integer)paArr[3];
										sb.append("<section>");
										sb.append("\n");
										sb.append("<sectionId>" + paArr[3] + "</sectionId>");
										sb.append("\n");
										sb.append("<sectionName>" + paArr[4] + "</sectionName>");
										sb.append("\n");
										sb.append("<students>");
										sb.append("\n");
										previousStuId=0;
										}
										if(previousStuId!=(Integer)paArr[5])
										{
											if(previousStuId!=0)
											{
												sb.append("</student>");
											     sb.append("\n");
											}
											previousStuId=(Integer)paArr[5];
										sb.append("<student>");
										sb.append("\n");
										sb.append("<studentId>" + paArr[5] + "</studentId>");
										sb.append("\n");
										sb.append("<studentNumber>" + paArr[6] + "</studentNumber>");
										sb.append("\n");
										sb.append("<firstName>" + paArr[7] + "</firstName>");
										sb.append("\n");
										sb.append("<middleName>" + paArr[8] + "</middleName>");
										sb.append("\n");
										sb.append("<lastName>" + paArr[9] + "</lastName>");
										sb.append("\n");
										if(qparerIds.indexOf((Integer)paArr[10])==-1)
										{
											if(qparerIds.equalsIgnoreCase(""))
											{
												sbQuePapId.append("<QuestioPapers>");
												sbQuePapId.append("\n");
												
											}
											qparerIds+=paArr[10]+",";
											sbQuePapId.append("<QuestioPaper>");
											sbQuePapId.append("\n");
											sbQuePapId.append("<questionPaperId>" + paArr[10] + "</questionPaperId>");
											sbQuePapId.append("\n");
											sbQuePapId.append("<paperTitle>" + paArr[11] + "</paperTitle>");
											sbQuePapId.append("\n");
											sbQuePapId.append("</QuestioPaper>");
											sbQuePapId.append("\n");
										}
										}
										}
									lboolrecordExist=true;
		
						        }
							      
						        
						        if(lboolrecordExist)
						        {
							      sb.append("</student>");
									sb.append("\n");
									sb.append("</students>");
									sb.append("\n");
									sb.append("</section>");
									sb.append("\n");
									sb.append("</sections>");
									sb.append("\n");
									sb.append("</class>");
									sb.append("\n");
									sb.append("</classes>");
									sb.append("\n");
									sbQuePapId.append("</QuestioPapers>");
									sbQuePapId.append("\n");
									sb.append(sbQuePapId);
						        }
						        
						        sb.append("</Assessment>");
						        sb.append("\n");
						        }
						        
						        sb.append("</Assessments>");
						        strg= sb.toString();
						        
						
				} 	catch (Exception localException) {
					System.out.println(localException);
					
					   sb.append("<Response>");
					    sb.append("\n");
					    sb.append("<Result>");
					    sb.append("\n");
					    sb.append("Fail");
					    sb.append("\n");
					    sb.append("</Result>");
					    sb.append("\n");
					    sb.append("<Description>");
					    
					    sb.append("could not getbyid assessment info");
					    sb.append("</Description>");
					    sb.append("\n");
					    sb.append("<Exception>");
					    sb.append(localException);
					    sb.append("</Exception>");
					    sb.append("</Response>");
				        sb.append("</assessmentId>");
				        sb.append("</Assessment>");
					    strg= sb.toString();
					   MDTransactionWriter.exceptionlog.info(localException);
					  if (gtTx!=null)
						  gtTx.rollback();
					} finally {
						gtempSession.close();
					}
			return strg;
	}

	public String getAllAssessment(int PNO, int size,int schoolId,int branchId) {
		Session rdSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb= new StringBuffer();
		String string=null;
		//AssessmentPojo ex=null;
		
		try
		{
			tx = rdSession.beginTransaction();
			
			 if(("all") != null)
			   {
			    int fset = (PNO-1)*size;
			    String gsSql ="select count(*) from gbl_sm_tbl_assessment as a where (a.IsDeleted <> 'Y' or a.IsDeleted IS NULL) and a.SchoolId ='"+schoolId+"' and a.BranchId ='"+branchId+"'";
			    Query gsQuery=rdSession.createSQLQuery(gsSql);
			    Object noRecords= gsQuery.uniqueResult();
			    sb.append("<Assessments>");
			    sb.append("\n");
			    sb.append("<noRecords>"+noRecords+"</noRecords>");
			    sb.append("\n");
			    
			     if (PNO > 0 & size > 0){
			     gsSql="select ass.AssessmentId,ass.AssessmentTypeId,assty.TypeName,ass.AssessmentName,ass.MaxScore,ass.StartDate,ass.EndDate,ass.`Status`,ass.Description,ass.Remarks,ass.SchoolId,ass.BranchId,ass.CreatedDate,ass.ModifiedDate from gbl_sm_tbl_assessment as ass join gbl_sm_tbl_assessment_type as assty on ass.AssessmentTypeId = assty.AssessmentTypeId where (ass.isDeleted<>'y' or  ass.isDeleted is null)  and ass.SchoolId ='"+schoolId+"'  and ass.BranchId ='"+branchId+"' limit "+size+" offset "+fset;
			     }
			     else {
			      gsSql="select ass.AssessmentId,ass.AssessmentTypeId,assty.TypeName,ass.AssessmentName,ass.MaxScore,ass.StartDate,ass.EndDate,ass.`Status`,ass.Description,ass.Remarks,ass.SchoolId,ass.BranchId,ass.CreatedDate,ass.ModifiedDate from gbl_sm_tbl_assessment as ass join gbl_sm_tbl_assessment_type as assty on ass.AssessmentTypeId = assty.AssessmentTypeId where (ass.isDeleted<>'y' or  ass.isDeleted is null) and ass.SchoolId ='"+schoolId+"'  and ass.BranchId ='"+branchId+"'";
			     } 
			   
			    gsQuery=rdSession.createSQLQuery(gsSql);
			    List gcList=gsQuery.list();
			    Iterator it=gcList.iterator();
			    /* sb.append("<Assessments>");
				    sb.append("\n");*/
				    boolean lboolrecordExist=false;
				    int previousClsId=0;
					int previousSecId=0;
					int previousStuId=0;
					String qparerIds="";
					StringBuffer sbQuePapId= new StringBuffer();
					        while(it.hasNext())
					        {
							Object[] ex=(Object[])it.next();
							sb.append("<Assessment>");
						    sb.append("\n");
					        sb.append("<assessmentId>");
						    sb.append(ex[0]);
						    sb.append("</assessmentId>");
						    sb.append("\n");
						    sb.append("<assessmentTypeId>");
						    sb.append(ex[1]);
						    sb.append("</assessmentTypeId>");
						    sb.append("\n");
						    sb.append("<typeName>");
							sb.append(ex[2]);
							sb.append("</typeName>");
							 sb.append("\n");
							sb.append("<assessmentName>");
						    sb.append(ex[3]);
						    sb.append("</assessmentName>");
						    sb.append("\n");
							sb.append("<maxScore>");
							sb.append(ex[4]);
							sb.append("</maxScore>");
							sb.append("\n");
						    sb.append("<startDate>");
						    sb.append(ex[5]);
						    sb.append("</startDate>");
						    sb.append("\n");
						    sb.append("<endDate>");
							sb.append(ex[6]);
							sb.append("</endDate>");
							 sb.append("\n");
							sb.append("<status>");
							sb.append(ex[7]);
							sb.append("</status>");
							 sb.append("\n");
							sb.append("<description>");
							sb.append(ex[8]);
							sb.append("</description>");
							sb.append("\n");
							sb.append("<remarks>");
							sb.append(ex[9]);
							sb.append("</remarks>");
							sb.append("\n");
							sb.append("<schoolId>");
							sb.append(ex[10]);
							sb.append("</schoolId>");
							sb.append("\n");
							sb.append("<branchId>");
							sb.append(ex[11]);
							sb.append("</branchId>");
							sb.append("\n");
							sb.append("<createdDate>");
							sb.append(ex[12]);
							sb.append("</createdDate>");
							sb.append("\n");
							sb.append("<modifiedDate>");
							sb.append(ex[13]);
							sb.append("</modifiedDate>");
							sb.append("\n");
							
						    int assessmentId=(Integer)ex[0];
						   /* int assid = (assessmentId-1)*size;
						    if(assessmentId>0 & size>0){*/
						   /* sb.append("<assessmentId>" +assessmentId+ "</assessmentId>");
						    sb.append("\n");*/
						      if(assessmentId!=0)
						      {
						     String  gsSqls="select assas.AssessmentId, assas.ClassId,cls.ClassName,assas.SectionId,sec.SectionName,assas.StudentId,st.StudentNumber,st.FirstName,st.MiddleName,st.LastName,assas.QuestionPaperId,qp.PaperTitle from gbl_sm_tbl_assessment_assign as assas join gbl_sm_tbl_assessment as ass on  assas.AssessmentId= ass.AssessmentId join  gbl_sm_tbl_class as  cls on assas.ClassId=cls.ClassId join gbl_sm_tbl_section as sec on assas.SectionId=sec.SectionId join gbl_sm_tbl_student as st on assas.StudentId=st.StudentId join gbl_sm_tbl_question_paper as qp on assas.QuestionPaperId=qp.QuestionPaperId where  assas.AssessmentId='"+assessmentId+"' order by classid,sectionid";
						      Query gsQuerys = rdSession.createSQLQuery(gsSqls);
								List parList1 = gsQuerys.list();
								sb.append("<classes>");
								sb.append("\n");
								Iterator paIT = parList1.iterator();
								  previousClsId=0;
									 previousSecId=0;
									 previousStuId=0;
									 qparerIds="";
								
								while (paIT.hasNext()) {
									Object[] paArr = (Object[]) paIT.next();
									if(previousClsId!=(Integer)paArr[1])
									{
										if(previousClsId!=0)
										{
											
											sb.append("</student>");
											sb.append("\n");
											sb.append("</students>");
											sb.append("\n");
											sb.append("</section>");
											sb.append("\n");
											sb.append("</sections>");
											sb.append("\n");
											sb.append("</class>");
											sb.append("\n");
										}
										previousClsId=(Integer)paArr[1];
									sb.append("<class>");
									sb.append("\n");
									sb.append("<classId>"+paArr[1]+"</classId>");
									sb.append("\n");
									sb.append("<className>"+paArr[2]+"</className>");
									sb.append("\n");
									sb.append("<sections>");
									sb.append("\n");
									previousSecId=0;
									}
									if(previousSecId!=(Integer)paArr[3]){
										if(previousSecId!=0)
										{
											
											sb.append("</student>");
											sb.append("\n");
											sb.append("</students>");
											sb.append("\n");
											sb.append("</section>");
											sb.append("\n");
										}
										previousSecId=(Integer)paArr[3];
									sb.append("<section>");
									sb.append("\n");
									sb.append("<sectionId>" + paArr[3] + "</sectionId>");
									sb.append("\n");
									sb.append("<sectionName>" + paArr[4] + "</sectionName>");
									sb.append("\n");
									sb.append("<students>");
									sb.append("\n");
									previousStuId=0;
									}
									if(previousStuId!=(Integer)paArr[5])
									{
										if(previousStuId!=0)
										{
											sb.append("</student>");
										     sb.append("\n");
										}
										previousStuId=(Integer)paArr[5];
									sb.append("<student>");
									sb.append("\n");
									sb.append("<studentId>" + paArr[5] + "</studentId>");
									sb.append("\n");
									sb.append("<studentNumber>" + paArr[6] + "</studentNumber>");
									sb.append("\n");
									sb.append("<firstName>" + paArr[7] + "</firstName>");
									sb.append("\n");
									sb.append("<middleName>" + paArr[8] + "</middleName>");
									sb.append("\n");
									sb.append("<lastName>" + paArr[9] + "</lastName>");
									sb.append("\n");
									if(qparerIds.indexOf((Integer)paArr[10])==-1)
									{
										if(qparerIds.equalsIgnoreCase(""))
										{
											sbQuePapId.append("<QuestioPapers>");
											sbQuePapId.append("\n");
											
										}
										qparerIds+=paArr[10]+",";
										sbQuePapId.append("<QuestioPaper>");
										sbQuePapId.append("\n");
										sbQuePapId.append("<questionPaperId>" + paArr[10] + "</questionPaperId>");
										sbQuePapId.append("\n");
										sbQuePapId.append("<paperTitle>" + paArr[11] + "</paperTitle>");
										sbQuePapId.append("\n");
										sbQuePapId.append("</QuestioPaper>");
										sbQuePapId.append("\n");
									}
									}
									}
								lboolrecordExist=true;
	
					        }
						      
					        
					        if(lboolrecordExist)
					        {
						      sb.append("</student>");
								sb.append("\n");
								sb.append("</students>");
								sb.append("\n");
								sb.append("</section>");
								sb.append("\n");
								sb.append("</sections>");
								sb.append("\n");
								sb.append("</class>");
								sb.append("\n");
								sb.append("</classes>");
								sb.append("\n");
								sbQuePapId.append("</QuestioPapers>");
								sbQuePapId.append("\n");
								sb.append(sbQuePapId);
								
					        }
					        sb.append("</Assessment>");
						    sb.append("\n");
						    sbQuePapId=new StringBuffer();
						   }
			   }
			  				//tx.commit();
					        sb.append("</Assessments>");
					        //sb.append("\n");
					        string= sb.toString();
					      
							//return string;
		}
		catch(Exception localException)
		{
			System.out.println(localException);
			
				sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    
			    sb.append("could not getall assessment info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			     string= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (tx!=null)
				  tx.rollback();
		}
		finally
		{
			rdSession.close();
		
		}
		return string;
	}

	
}
