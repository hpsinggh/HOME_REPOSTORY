package com.gwebitsol.core.assessments;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class AssessmentScoreDao {
	Session addempSession=MDHibernateUtil.getSessionFactory().openSession();
	Transaction addempTx=null;
	public String addAssessmentScore(AssessmentScore as) {
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			addempTx=addempSession.beginTransaction();
			Integer in=(Integer)addempSession.save(as);
			System.out.println(in);
			
			addempTx.commit();
			
			
			sb.append("<AssessmentScore>");
			sb.append("\n");
			sb.append("<assessmentScoreId>");
			sb.append(in);
			sb.append("</assessmentScoreId>");
			sb.append("</AssessmentScore>");
			outStr=sb.toString();
			
		   
   		 	}
		
		catch(Exception localException)
		{
			System.out.println(localException);
			
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    
			    sb.append("could not inserted assessmentScoreId info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    outStr= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (addempTx!=null)
				  addempTx.rollback();
		}
		finally
		{			
			addempSession.close();
		}
		return outStr;
	}

	public String updateAssessmentScore(AssessmentScore as,int schoolId,int branchId) {
		Session upempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction upempTx=null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			upempTx=upempSession.beginTransaction();
			AssessmentScore assessmentscore = (AssessmentScore) upempSession.get(AssessmentScore.class,as.getAssessmentScoreId());
			upempSession.evict(assessmentscore);
			if(branchId==assessmentscore.getBranchId()&&schoolId==assessmentscore.getSchoolId())  
	        upempSession.update(as);
			upempTx.commit();
			sb.append("<AssessmentScore>");
			sb.append("\n");
			sb.append("update sucessfully");
			sb.append("</AssessmentScore>");
			String str=sb.toString();
			return str;
   		 	}
		
		catch(Exception localException)
		{
			System.out.println(localException);
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    sb.append("could not update AssessmentScore info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    outStr= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (outStr!=null)
				  upempTx.rollback();
		}
		finally
		{			
			upempSession.close();
		}
		return outStr;
	}

	public String deleteAssessmentScore(int assessmentScoreId,int schoolId,int branchId) {
		Session delempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction delempTx=null;
		StringBuffer sb=new StringBuffer();
		
		String outStr=null;
		try
		{
			delempTx=delempSession.beginTransaction();
			
			AssessmentScore assessment = (AssessmentScore) delempSession.get(AssessmentScore.class,assessmentScoreId);
			   
			   int branid = assessment.getBranchId();
			   int sclid = assessment.getSchoolId();
			   delempSession.evict(assessment);           
			   if(branchId==branid&&schoolId==sclid)
			   {
			Query empQuery=delempSession.createSQLQuery("update gbl_sm_tbl_assessment_score set IsDeleted ='Y' where assessmentScoreId='"+assessmentScoreId+"'");
			empQuery.executeUpdate();
			delempTx.commit();
			sb.append("<AssessmentScore>");
			sb.append("\n");
			sb.append("deleted sucessfully");
			sb.append("</AssessmentScore>");
			String str=sb.toString();
			return str;
   		 	}
			   else
			   {
				outStr = "assessmentscore is not deleted";
			    sb.append("<AssessmentScore>");
			    sb.append("\n");
			    sb.append(outStr);
			    sb.append("</AssessmentScore>");
			    String str = sb.toString();
			    return str;
			   }
				}
		catch(Exception localException)
		{
			System.out.println(localException);
			
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    
			    sb.append("could not delete assessmentscore info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    outStr= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (delempTx!=null)
				  delempTx.rollback();
		}
		finally
		{			
			delempSession.close();
		}
		return outStr;
	}


	@SuppressWarnings("rawtypes")
	public String getAssessmentScore(int assessmentScoreId,int schoolId,int branchId) {
		Session gtempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gtTx=null;
			StringBuffer sb= new StringBuffer();
			System.out.println("hi dao impl success");
			String strg= null;
				try {
						gtTx = gtempSession.beginTransaction();
						List list=gtempSession.createSQLQuery("select ac.AssessmentScoreId,ac.Score,ac.AssessmentId,ass.AssessmentName,ac.StudentId,stu.FirstName,stu.MiddleName,stu.LastName,ac.GradeId,gr.GradeName,ac.SchoolId,ac.BranchId from  gbl_sm_tbl_assessment_score as ac join gbl_sm_tbl_assessment as ass on ac.AssessmentId=ass.AssessmentId join gbl_sm_tbl_student as stu on ac.StudentId=stu.StudentId join gbl_sm_tbl_grade as gr on ac.GradeId=gr.GradeId where ac.IsDeleted<>'y' or ac.IsDeleted is Null and ac.AssessmentScoreId= '" + assessmentScoreId + "' and ac.schoolId='" + schoolId + "' and ac.branchId='" + branchId + "';").list();
					     Iterator it=list.iterator();
					     sb.append("<AssessmentScore>");
					     sb.append("\n");
					     while(it.hasNext())
					     {
					      Object[] ex=(Object[])it.next();
					      sb.append("<assessmemtScoreId>");
					         sb.append(ex[0]);
					         sb.append("</assessmemtScoreId>");
					         sb.append("\n");
					         sb.append("<score>");
					         sb.append(ex[1]);
					         sb.append("</score>");
					         sb.append("\n");
					         sb.append("<assessmentId>");
					         sb.append(ex[2]);
					         sb.append("</assessmentId>");
					         sb.append("\n");
					         sb.append("<assessmentName>");
					         sb.append(ex[3]);
					         sb.append("</assessmentName>");
					         sb.append("\n");
					         sb.append("<studentId>");
					         sb.append(ex[4]);
					         sb.append("</studentId>");
					         sb.append("\n");
					         sb.append("<firstName>");
					         sb.append(ex[5]);
					         sb.append("</firstName>");
					         sb.append("\n");
					         sb.append("<middleName>");
					         sb.append(ex[6]);
					         sb.append("</middleName>");
					         sb.append("\n");
					         sb.append("<lastName>");
					         sb.append(ex[7]);
					         sb.append("</lastName>");
					         sb.append("\n");
					         sb.append("<gradeId>");
					         sb.append(ex[8]);
					         sb.append("</gradeId>");
					         sb.append("\n");
					         sb.append("<gradeName>");
					         sb.append(ex[9]);
					         sb.append("</gradeName>");
					         sb.append("\n");
								sb.append("<schoolId>");
								sb.append(ex[10]);
								sb.append("</schoolId>");
								sb.append("\n");
								sb.append("<branchId>");
								sb.append(ex[11]);
								sb.append("</branchId>");
								sb.append("\n");
					     	}
							 sb.append("</AssessmentScore>");
							 strg= sb.toString();
						
				} 	catch (Exception localException) {
					System.out.println(localException);
					
					   sb.append("<Response>");
					    sb.append("\n");
					    sb.append("<Result>");
					    sb.append("\n");
					    sb.append("Fail");
					    sb.append("\n");
					    sb.append("</Result>");
					    sb.append("\n");
					    sb.append("<Description>");
					    
					    sb.append("could not get AssessmentScore info");
					    sb.append("</Description>");
					    sb.append("\n");
					    sb.append("<Exception>");
					    sb.append(localException);
					    sb.append("</Exception>");
					    sb.append("</Response>");
					    sb.append("</assessmemtScoreId>");
					    sb.append("</AssessmentScore>");
					    strg= sb.toString();
					   MDTransactionWriter.exceptionlog.info(localException);
					  if (strg!=null)
						  gtTx.rollback();
					} finally {
						gtempSession.close();
					}
			return strg;
	}
	public String getAllAssessmentScore(int PNO, int size,int schoolId,int branchId) {
		Session rdSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb= new StringBuffer();
		String string=null;
		//PaperSectionPojo ex=null;
		
		try
		{
			tx = rdSession.beginTransaction();
			 
			if(("all") != null)
			   {
			    int fset = (PNO-1)*size;
			    String gsSql ="select count(*) from gbl_sm_tbl_assessment_score as ac where ac.IsDeleted<>'y' or ac.IsDeleted is Null  and ac.schoolId='" + schoolId + "' and ac.branchId='" + branchId + "'";
			    Query gsQuery=rdSession.createSQLQuery(gsSql);
			    Object noRecords= gsQuery.uniqueResult();
			    sb.append("<AssessmentScores>");
			    sb.append("\n");
			    sb.append("<noRecords>"+noRecords+"</noRecords>");
			    sb.append("\n");
			    
			     if (PNO > 0 & size > 0){
			     gsSql="select ac.AssessmentScoreId,ac.Score,ac.AssessmentId,ass.AssessmentName,ac.StudentId,stu.FirstName,stu.MiddleName,stu.LastName,ac.GradeId,gr.GradeName,ac.SchoolId,ac.BranchId from  gbl_sm_tbl_assessment_score as ac join gbl_sm_tbl_assessment as ass on ac.AssessmentId=ass.AssessmentId join gbl_sm_tbl_student as stu on ac.StudentId=stu.StudentId join gbl_sm_tbl_grade as gr on ac.GradeId=gr.GradeId where ac.IsDeleted<>'y' or ac.IsDeleted is Null  and ac.schoolId='" + schoolId + "' and ac.branchId='" + branchId + "' limit "+size+" offset "+fset;}
			     else {
			      gsSql="select ac.AssessmentScoreId,ac.Score,ac.AssessmentId,ass.AssessmentName,ac.StudentId,stu.FirstName,stu.MiddleName,stu.LastName,ac.GradeId,gr.GradeName,ac.SchoolId,ac.BranchId from  gbl_sm_tbl_assessment_score as ac join gbl_sm_tbl_assessment as ass on ac.AssessmentId=ass.AssessmentId join gbl_sm_tbl_student as stu on ac.StudentId=stu.StudentId join gbl_sm_tbl_grade as gr on ac.GradeId=gr.GradeId where ac.IsDeleted<>'y' or ac.IsDeleted is Null  and ac.schoolId='" + schoolId + "' and ac.branchId='" + branchId + "'";
			     } 
			   
			    gsQuery=rdSession.createSQLQuery(gsSql);
			    List gcList=gsQuery.list();
			    Iterator gsIT=gcList.iterator();
			    while(gsIT.hasNext())
			     {
			        Object[] ex=(Object[])gsIT.next();
			        	 sb.append("<AssessmentScore>");
			        	 sb.append("\n");
			        	 sb.append("<assessmemtScoreId>");
				         sb.append(ex[0]);
				         sb.append("</assessmemtScoreId>");
				         sb.append("\n");
				         sb.append("<score>");
				         sb.append(ex[1]);
				         sb.append("</score>");
				         sb.append("\n");
				         sb.append("<assessmentId>");
				         sb.append(ex[2]);
				         sb.append("</assessmentId>");
				         sb.append("\n");
				         sb.append("<assessmentName>");
				         sb.append(ex[3]);
				         sb.append("</assessmentName>");
				         sb.append("\n");
				         sb.append("<studentId>");
				         sb.append(ex[4]);
				         sb.append("</studentId>");
				         sb.append("\n");
				         sb.append("<firstName>");
				         sb.append(ex[5]);
				         sb.append("</firstName>");
				         sb.append("\n");
				         sb.append("<middleName>");
				         sb.append(ex[6]);
				         sb.append("</middleName>");
				         sb.append("\n");
				         sb.append("<lastName>");
				         sb.append(ex[7]);
				         sb.append("</lastName>");
				         sb.append("\n");
				         sb.append("<gradeId>");
				         sb.append(ex[8]);
				         sb.append("</gradeId>");
				         sb.append("\n");
				         sb.append("<gradeName>");
				         sb.append(ex[9]);
				         sb.append("</gradeName>");
				         sb.append("\n");
				     	sb.append("<schoolId>");
						sb.append(ex[10]);
						sb.append("</schoolId>");
						sb.append("\n");
						sb.append("<branchId>");
						sb.append(ex[11]);
						sb.append("</branchId>");
						sb.append("\n");
				         sb.append("</AssessmentScore>");       
			     }
				     	}
						 sb.append("</AssessmentScores>");
						 string= sb.toString();
		}
		catch(Exception localException)
		{
			System.out.println(localException);
			
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    
			    sb.append("could not getall AssessmentScores info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    string= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (string!=null)
				  tx.rollback();
		}
		finally
		{
			rdSession.close();
		
		}
		return string;
	}

}
