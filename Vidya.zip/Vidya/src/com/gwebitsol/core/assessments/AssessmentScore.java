package com.gwebitsol.core.assessments;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="AssessmentScore")
public class AssessmentScore {
	private int assessmentScoreId;
	private int assessmentId;
	private int studentId;
	private int gradeId;
	private int score;
	private int schoolId;
	private int branchId;
	
	public int getAssessmentScoreId() {
		return assessmentScoreId;
	}
	public void setAssessmentScoreId(int assessmentScoreId) {
		this.assessmentScoreId = assessmentScoreId;
	}
	public int getAssessmentId() {
		return assessmentId;
	}
	public void setAssessmentId(int assessmentId) {
		this.assessmentId = assessmentId;
	}
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public int getGradeId() {
		return gradeId;
	}
	public void setGradeId(int gradeId) {
		this.gradeId = gradeId;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	public int getSchoolId() {
		return schoolId;
	}
	public void setSchoolId(int schoolId) {
		this.schoolId = schoolId;
	}
	public int getBranchId() {
		return branchId;
	}
	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}
}
