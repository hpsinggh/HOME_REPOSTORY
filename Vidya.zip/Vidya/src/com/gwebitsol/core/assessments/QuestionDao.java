package com.gwebitsol.core.assessments;

import java.util.Iterator;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class QuestionDao {
	
	
	public String addQuestion(QuestionPojo brp) {
		  Session addempSession=MDHibernateUtil.getSessionFactory().openSession();
		  Transaction addempTx=null;
		  StringBuffer sb=new StringBuffer();
		  String outStr=null;
		  Integer questionId = null;
		  String sqlstr = null;
		  try
		  {
		   addempTx=addempSession.beginTransaction();
		   questionId=(Integer)addempSession.save(brp);
		   addempTx.commit();
		   addempTx=addempSession.beginTransaction();
		   List<QuestionChoice> questionchoice = brp.getQcList().getQuestionchoice();
		   if(questionchoice!=null){
		   for (int i = 0; i <= questionchoice.size()-1; i++) 
		   {
		    QuestionChoice qc = questionchoice.get(i);
		    String choicetag = qc.getChoiceTag();
		    String choice = qc.getChoice();
		    String answerchoice = qc.getAnswerChoice();
		    if((choicetag!=null && !"".equalsIgnoreCase(choicetag)) ||
		      (choice!=null && !"".equalsIgnoreCase(choice)) ||
		      (answerchoice!=null && !"".equalsIgnoreCase(answerchoice)) ){ 
		    sqlstr = "insert into gbl_sm_tbl_question_choices(QuestionId,ChoiceTag,Choice,answerChoice) values ('"+ questionId+ "','" + choicetag + "','" + choice+ "','" + answerchoice + "');";
		    SQLQuery stpar = addempSession.createSQLQuery(sqlstr);
		    
		    stpar.executeUpdate();
		    }
		    
		   }
		   
		   }
		   addempTx.commit();
		   sb.append("<Question>");
		   sb.append("\n");
		   sb.append("<questionId>");
		   sb.append(questionId);
		   sb.append("</questionId>");
		   sb.append("</Question>");
		   outStr=sb.toString();
		    }
		       
		  
		  catch(Exception localException)
		  {
		   System.out.println(localException);
		   
		      sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not inserted Question info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       outStr= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (addempTx!=null)
		      addempTx.rollback();
		  }
		  finally
		  {   
		   addempSession.close();
		  }
		  return outStr;
		 }

	public String updateQuestion(QuestionPojo brp,int schoolId,int branchId) {
		Session upempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction upempTx=null;
		StringBuffer sb=new StringBuffer();
		String sqlstr=null;
		String outStr=null;
		try
		{
			upempTx=upempSession.beginTransaction();
			QuestionPojo question = (QuestionPojo) upempSession.get(QuestionPojo.class,brp.getQuestionId());
			if(branchId==question.getBranchId()&&schoolId==question.getSchoolId())  
			upempSession.evict(question); 
			upempSession.update(brp);
			
			int questionId = brp.getQuestionId();
			List<QuestionChoice> questionchoice = brp.getQcList().getQuestionchoice();
			for (int i = 0; i <= questionchoice.size()-1; i++) 
			{
				QuestionChoice qc = questionchoice.get(i);
				String choicetag = qc.getChoiceTag();
				String choice = qc.getChoice();
				String answerchoice = qc.getAnswerChoice();
				
				if(questionId==0)
				{
					sqlstr = "insert into gbl_sm_tbl_question_choices(QuestionId,ChoiceTag,Choice,answerChoice) values ('" + questionId+ "','" + choicetag + "','" + choice+ "','" + answerchoice + "');";
					SQLQuery stpar = upempSession.createSQLQuery(sqlstr);
					
					stpar.executeUpdate();
					
				}
				else
				{
				sqlstr = "update gbl_sm_tbl_question_choices set  answerChoice='" + answerchoice + "' , Choice='" + choice + "' , ChoiceTag='"+choicetag+"' where questionId='"+questionId+"' and questionChoiceId='"+qc.getQuestionChoiceId()+"';";
				Query gsQuery = upempSession.createSQLQuery(sqlstr);
				gsQuery.executeUpdate();
				}
			} 
			
				upempTx.commit();
				sb.append("<Question>");
				sb.append("\n");
				sb.append("update successfully");
				sb.append("</Question>");
				String str=sb.toString();
				return str;
			   
	   		 	}
			
			catch(Exception localException)
			{
				System.out.println(localException);
				
				   sb.append("<Response>");
				    sb.append("\n");
				    sb.append("<Result>");
				    sb.append("\n");
				    sb.append("Fail");
				    sb.append("\n");
				    sb.append("</Result>");
				    sb.append("\n");
				    sb.append("<Description>");
				    
				    sb.append("could not inserted Question info");
				    sb.append("</Description>");
				    sb.append("\n");
				    sb.append("<Exception>");
				    sb.append(localException);
				    sb.append("</Exception>");
				    sb.append("</Response>");
				    outStr= sb.toString();
				   MDTransactionWriter.exceptionlog.info(localException);
				  if (upempTx!=null)
					  upempTx.rollback();
			}
			finally
			{			
				upempSession.close();
			}
			return outStr;
	}

	public String deleteQuestion(int questionId,int schoolId,int branchId) {
		Session delempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction delempTx=null;
		StringBuffer sb=new StringBuffer();

		String outStr=null;
		try
		{
			delempTx=delempSession.beginTransaction();
			
			QuestionPojo question = (QuestionPojo) delempSession.get(QuestionPojo.class,questionId);
			   
			   int branid = question.getBranchId();
			   int sclid = question.getSchoolId();
			                
			   if(branchId==branid&&schoolId==sclid)
			   
			   delempSession.evict(question);
			
			Query empQuery=delempSession.createSQLQuery("update gbl_sm_tbl_question set IsDeleted ='Y' where questionId='"+questionId+"'");
			empQuery.executeUpdate();
				delempTx.commit();
				sb.append("<Question>");
				sb.append("\n");
				sb.append("delete successfully");
				sb.append("</Question>");
				String str=sb.toString();
				return str;
			   
	   		 	}
			
			catch(Exception localException)
			{
				System.out.println(localException);
				
				   sb.append("<Response>");
				    sb.append("\n");
				    sb.append("<Result>");
				    sb.append("\n");
				    sb.append("Fail");
				    sb.append("\n");
				    sb.append("</Result>");
				    sb.append("\n");
				    sb.append("<Description>");
				    
				    sb.append("could not delete question info");
				    sb.append("</Description>");
				    sb.append("\n");
				    sb.append("<Exception>");
				    sb.append(localException);
				    sb.append("</Exception>");
				    sb.append("</Response>");
				    outStr= sb.toString();
				   MDTransactionWriter.exceptionlog.info(localException);
				  if (delempTx!=null)
					  delempTx.rollback();
			}
			finally
			{			
				delempSession.close();
			}
			return outStr;
	}

	public String getByIdQuestion(int questionId,int schoolId,int branchId) {
		Session gtempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gtempTx=null;
		StringBuffer sb=new StringBuffer();

		
		System.out.println("hi success");
		String strg= null;
			try {
				gtempTx = gtempSession.beginTransaction();
				List list=gtempSession.createSQLQuery("SELECT q.QuestionId,q.QuestionTypeId,qt.TypeName,q.QuestionTitle,q.Answer,q.MaxScore,q.QuestionDescription,q.CreatedDate,q.ModifiedDate,q.SchoolId,q.BranchId,q.SubjectId,sub.SubjectTypeId,sbt.SubjectName,q.UnitId,unt.UnitName,q.ChapterId,ch.ChapterName,q.TopicId,tp.TopicName,q.CourseId,cr.CourseName,sub.ClassId,cls.ClassName,sub.SectionId,sec.SectionName FROM gbl_sm_tbl_question q JOIN gbl_sm_tbl_questiontype qt JOIN gbl_sm_tbl_subjects sub JOIN gbl_sm_tbl_subject_type sbt JOIN gbl_sm_tbl_units unt JOIN gbl_sm_tbl_chapter ch JOIN gbl_sm_tbl_topic tp JOIN gbl_sm_tbl_course cr JOIN gbl_sm_tbl_class cls  JOIN gbl_sm_tbl_section sec ON q.QuestionTypeId = qt.QuestionTypeId and q.SubjectId = sub.SubjectId and sub.SubjectTypeId = sbt.SubjectTypeId and q.UnitId = unt.UnitId and q.ChapterId = ch.ChapterId and q.TopicId = tp.TopicId and q.CourseId = cr.CourseId and sub.ClassId = cls.ClassId and sub.SectionId = sec.SectionId where q.IsDeleted <> 'Y' or q.IsDeleted IS NULL and q.QuestionId = '" + questionId + "' and q.SchoolId ='" + schoolId + "' and q.BranchId ='" + branchId + "' ;").list();
			     Iterator it=list.iterator();
			     sb.append("<Questions>");
			     sb.append("\n");
			     while(it.hasNext())
			     {
			      Object[] ex=(Object[])it.next();
			      sb.append("<Question>");
				     sb.append("\n");
			      	 sb.append("<questionId>");
			         sb.append(ex[0]);
			         sb.append("</questionId>");
			         sb.append("\n");
			         sb.append("<questionTypeId>");
			         sb.append(ex[1]);
			         sb.append("</questionTypeId>");
			         sb.append("\n");
			         sb.append("<typeName>");
			         sb.append(ex[2]);
			         sb.append("</typeName>");
			         sb.append("\n");
			         sb.append("<questionTitle>");
			         sb.append(ex[3]);
			         sb.append("</questionTitle>");
			         sb.append("\n");
			      /*   sb.append("<multipleAnswer>");
			         sb.append(ex[4]);
			         sb.append("</multipleAnswer>");
			         sb.append("\n");*/
			         sb.append("<answer>");
			         sb.append(ex[4]);
			         sb.append("</answer>");
			         sb.append("\n");
			         sb.append("<maxScore>");
			         sb.append(ex[5]);
			         sb.append("</maxScore>");
			         sb.append("\n");
			         sb.append("<questionDescription>");
			         sb.append(ex[6]);
			         sb.append("</questionDescription>");
			         sb.append("\n");
			         sb.append("<createdDate>");
			         sb.append(ex[7]);
			         sb.append("</createdDate>");
			         sb.append("\n");
			         sb.append("<modifiedDate>");
			         sb.append(ex[8]);
			         sb.append("</modifiedDate>");
			         sb.append("\n");
						sb.append("<schoolId>");
						sb.append(ex[9]);
						sb.append("</schoolId>");
						sb.append("\n");
						sb.append("<branchId>");
						sb.append(ex[10]);
						sb.append("</branchId>");
						sb.append("\n");
						sb.append("<subjectId>");
						sb.append(ex[11]);
						sb.append("</subjectId>");
						sb.append("\n");
						sb.append("<subjectTypeId>");
						sb.append(ex[12]);
						sb.append("</subjectTypeId>");
						sb.append("\n");
						sb.append("<subjectName>");
						sb.append(ex[13]);
						sb.append("</subjectName>");
						sb.append("\n");
						sb.append("<unitId>");
						sb.append(ex[14]);
						sb.append("</unitId>");
						sb.append("\n");
						sb.append("<unitName>");
						sb.append(ex[15]);
						sb.append("</unitName>");
						sb.append("\n");
						sb.append("<chapterId>");
						sb.append(ex[16]);
						sb.append("</chapterId>");
						sb.append("\n");
						sb.append("<chapterName>");
						sb.append(ex[17]);
						sb.append("</chapterName>");
						sb.append("\n");
						sb.append("<topicId>");
						sb.append(ex[18]);
						sb.append("</topicId>");
						sb.append("\n");
						sb.append("<topicName>");
						sb.append(ex[19]);
						sb.append("</topicName>");
						sb.append("\n");
						sb.append("<courseId>");
						sb.append(ex[20]);
						sb.append("</courseId>");
						sb.append("\n");
						sb.append("<courseName>");
						sb.append(ex[21]);
						sb.append("</courseName>");
						sb.append("\n");
						sb.append("<classId>");
						sb.append(ex[22]);
						sb.append("</classId>");
						sb.append("\n");
						sb.append("<className>");
						sb.append(ex[23]);
						sb.append("</className>");
						sb.append("\n");
						sb.append("<sectionId>");
						sb.append(ex[24]);
						sb.append("</sectionId>");
						sb.append("\n");
						sb.append("<sectionName>");
						sb.append(ex[25]);
						sb.append("</sectionName>");
						sb.append("\n");
						sb.append("</Question>");
					     sb.append("\n");
						
					     if(questionId!=0)
					     {
					    	 String  gsSql="select qc.QuestionChoiceId,qc.QuestionId,qs.QuestionTitle,qc.ChoiceTag,qc.Choice,qc.AnswerChoice from gbl_sm_tbl_question_choices qc join gbl_sm_tbl_question qs on qs.QuestionId = qc.QuestionId where qc.QuestionId = '" + questionId + "' order by qc.QuestionChoiceId,qc.QuestionId";
						      Query gsQuery = gtempSession.createSQLQuery(gsSql);
						      List parList1 = gsQuery.list();
						      sb.append("<QuestionChoices>");
								sb.append("\n");
								Iterator IT = parList1.iterator();
							     while(IT.hasNext())
							     {
							      Object[] ex1=(Object[])IT.next();
							         sb.append("<QuestionChoice>");
								     sb.append("\n");
							         sb.append("<questionChoiceId>");
							         sb.append(ex1[0]);
							         sb.append("</questionChoiceId>");
							         sb.append("\n");
							         sb.append("<questionId>");
							         sb.append(ex1[1]);
							         sb.append("</questionId>");
							         sb.append("\n");
							         sb.append("<questionTitle>");
							         sb.append(ex1[2]);
							         sb.append("</questionTitle>");
							         sb.append("\n");
							         sb.append("<choiceTag>");
							         sb.append(ex1[3]);
							         sb.append("</choiceTag>");
							         sb.append("\n");
							         sb.append("<choice>");
							         sb.append(ex1[4]);
							         sb.append("</choice>");
							         sb.append("\n");
							         sb.append("<answerChoice>");
							         sb.append(ex1[5]);
							         sb.append("</answerChoice>");
							         sb.append("\n");
							         
							         sb.append("</QuestionChoice>");
								     sb.append("\n");
							         
					     	}
							     
					     }
							     sb.append("</QuestionChoices>");
									sb.append("\n");
						
			     }
					 sb.append("</Questions>");
					 strg= sb.toString();
			     
					
			} 	catch (Exception localException) {
				System.out.println(localException);
				
				   sb.append("<Response>");
				    sb.append("\n");
				    sb.append("<Result>");
				    sb.append("\n");
				    sb.append("Fail");
				    sb.append("\n");
				    sb.append("</Result>");
				    sb.append("\n");
				    sb.append("<Description>");
				    
				    sb.append("could not get question by id info");
				    sb.append("</Description>");
				    sb.append("\n");
				    sb.append("<Exception>");
				    sb.append(localException);
				    sb.append("</Exception>");
				    sb.append("</Response>");
				    sb.append("</questionId>");
				    sb.append("</Question>");
				     strg= sb.toString();
				   MDTransactionWriter.exceptionlog.info(localException);
				  if (gtempTx!=null)
					  gtempTx.rollback();
				} finally {
					gtempSession.close();
				}
		return strg;
	}

	public String getAllQuestion(int PNO, int size,int schoolId,int branchId) {
		Session rdSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb= new StringBuffer();
		String string=null;
		String sqlstr=null;
		//QuestionPojo ex=null;
		
		try
		{
			tx = rdSession.beginTransaction();
			
			 if(("all") != null)
			   {
			    int fset = (PNO-1)*size;
			    String gsSql ="select count(*) from gbl_sm_tbl_question as q where q.IsDeleted <> 'Y' or q.IsDeleted IS NULL and q.SchoolId ='" + schoolId + "' and q.BranchId ='" + branchId + "'";
			    Query gsQuery=rdSession.createSQLQuery(gsSql);
			    Object noRecords= gsQuery.uniqueResult();
			    sb.append("<Questions>");
			    sb.append("\n");
			    sb.append("<noRecords>"+noRecords+"</noRecords>");
			    sb.append("\n");
			    
			     if (PNO > 0 & size > 0){
			     gsSql="SELECT q.QuestionId,q.QuestionTypeId,qt.TypeName,q.QuestionTitle,q.Answer,q.MaxScore,q.QuestionDescription,q.CreatedDate,q.ModifiedDate,q.SchoolId,q.BranchId,q.SubjectId,sub.SubjectTypeId,sbt.SubjectName,q.UnitId,unt.UnitName,q.ChapterId,ch.ChapterName,q.TopicId,tp.TopicName,q.CourseId,cr.CourseName,sub.ClassId,cls.ClassName,sub.SectionId,sec.SectionName FROM gbl_sm_tbl_question q JOIN gbl_sm_tbl_questiontype qt JOIN gbl_sm_tbl_subjects sub JOIN gbl_sm_tbl_subject_type sbt JOIN gbl_sm_tbl_units unt JOIN gbl_sm_tbl_chapter ch JOIN gbl_sm_tbl_topic tp JOIN gbl_sm_tbl_course cr JOIN gbl_sm_tbl_class cls  JOIN gbl_sm_tbl_section sec ON q.QuestionTypeId = qt.QuestionTypeId and q.SubjectId = sub.SubjectId and sub.SubjectTypeId = sbt.SubjectTypeId and q.UnitId = unt.UnitId and q.ChapterId = ch.ChapterId and q.TopicId = tp.TopicId and q.CourseId = cr.CourseId and sub.ClassId = cls.ClassId and sub.SectionId = sec.SectionId where q.IsDeleted <> 'Y' or q.IsDeleted IS NULL and  q.SchoolId ='" + schoolId + "' and q.BranchId ='" + branchId + "'  limit "+size+" offset "+fset;}
			     else {
			      gsSql="SELECT q.QuestionId,q.QuestionTypeId,qt.TypeName,q.QuestionTitle,q.Answer,q.MaxScore,q.QuestionDescription,q.CreatedDate,q.ModifiedDate,q.SchoolId,q.BranchId,q.SubjectId,sub.SubjectTypeId,sbt.SubjectName,q.UnitId,unt.UnitName,q.ChapterId,ch.ChapterName,q.TopicId,tp.TopicName,q.CourseId,cr.CourseName,sub.ClassId,cls.ClassName,sub.SectionId,sec.SectionName FROM gbl_sm_tbl_question q JOIN gbl_sm_tbl_questiontype qt JOIN gbl_sm_tbl_subjects sub JOIN gbl_sm_tbl_subject_type sbt JOIN gbl_sm_tbl_units unt JOIN gbl_sm_tbl_chapter ch JOIN gbl_sm_tbl_topic tp JOIN gbl_sm_tbl_course cr JOIN gbl_sm_tbl_class cls  JOIN gbl_sm_tbl_section sec ON q.QuestionTypeId = qt.QuestionTypeId and q.SubjectId = sub.SubjectId and sub.SubjectTypeId = sbt.SubjectTypeId and q.UnitId = unt.UnitId and q.ChapterId = ch.ChapterId and q.TopicId = tp.TopicId and q.CourseId = cr.CourseId and sub.ClassId = cls.ClassId and sub.SectionId = sec.SectionId where q.IsDeleted <> 'Y' or q.IsDeleted IS NULL and  q.SchoolId ='" + schoolId + "' and q.BranchId ='" + branchId + "'";
			     } 
			   
			    gsQuery=rdSession.createSQLQuery(gsSql);
			    List gcList=gsQuery.list();
			    Iterator gsIT=gcList.iterator();
			    while(gsIT.hasNext())
			     {
			    	 Object[] ex=(Object[])gsIT.next();
			    	 sb.append("<Question>");
				     sb.append("\n");
			      	 sb.append("<questionId>");
			         sb.append(ex[0]);
			         sb.append("</questionId>");
			         sb.append("\n");
			         sb.append("<questionTypeId>");
			         sb.append(ex[1]);
			         sb.append("</questionTypeId>");
			         sb.append("\n");
			         sb.append("<typeName>");
			         sb.append(ex[2]);
			         sb.append("</typeName>");
			         sb.append("\n");
			         sb.append("<questionTitle>");
			         sb.append(ex[3]);
			         sb.append("</questionTitle>");
			         sb.append("\n");
			      /*   sb.append("<multipleAnswer>");
			         sb.append(ex[4]);
			         sb.append("</multipleAnswer>");
			         sb.append("\n");*/
			         sb.append("<answer>");
			         sb.append(ex[4]);
			         sb.append("</answer>");
			         sb.append("\n");
			         sb.append("<maxScore>");
			         sb.append(ex[5]);
			         sb.append("</maxScore>");
			         sb.append("\n");
			         sb.append("<questionDescription>");
			         sb.append(ex[6]);
			         sb.append("</questionDescription>");
			         sb.append("\n");
			         sb.append("<createdDate>");
			         sb.append(ex[7]);
			         sb.append("</createdDate>");
			         sb.append("\n");
			         sb.append("<modifiedDate>");
			         sb.append(ex[8]);
			         sb.append("</modifiedDate>");
			         sb.append("\n");
						sb.append("<schoolId>");
						sb.append(ex[9]);
						sb.append("</schoolId>");
						sb.append("\n");
						sb.append("<branchId>");
						sb.append(ex[10]);
						sb.append("</branchId>");
						sb.append("\n");
						sb.append("<subjectId>");
						sb.append(ex[11]);
						sb.append("</subjectId>");
						sb.append("\n");
						sb.append("<subjectTypeId>");
						sb.append(ex[12]);
						sb.append("</subjectTypeId>");
						sb.append("\n");
						sb.append("<subjectName>");
						sb.append(ex[13]);
						sb.append("</subjectName>");
						sb.append("\n");
						sb.append("<unitId>");
						sb.append(ex[14]);
						sb.append("</unitId>");
						sb.append("\n");
						sb.append("<unitName>");
						sb.append(ex[15]);
						sb.append("</unitName>");
						sb.append("\n");
						sb.append("<chapterId>");
						sb.append(ex[16]);
						sb.append("</chapterId>");
						sb.append("\n");
						sb.append("<chapterName>");
						sb.append(ex[17]);
						sb.append("</chapterName>");
						sb.append("\n");
						sb.append("<topicId>");
						sb.append(ex[18]);
						sb.append("</topicId>");
						sb.append("\n");
						sb.append("<topicName>");
						sb.append(ex[19]);
						sb.append("</topicName>");
						sb.append("\n");
						sb.append("<courseId>");
						sb.append(ex[20]);
						sb.append("</courseId>");
						sb.append("\n");
						sb.append("<courseName>");
						sb.append(ex[21]);
						sb.append("</courseName>");
						sb.append("\n");
						sb.append("<classId>");
						sb.append(ex[22]);
						sb.append("</classId>");
						sb.append("\n");
						sb.append("<className>");
						sb.append(ex[23]);
						sb.append("</className>");
						sb.append("\n");
						sb.append("<sectionId>");
						sb.append(ex[24]);
						sb.append("</sectionId>");
						sb.append("\n");
						sb.append("<sectionName>");
						sb.append(ex[25]);
						sb.append("</sectionName>");
						sb.append("\n");
						sb.append("</Question>");
					     sb.append("\n");
						
					     int questionId=(Integer)ex[0]; 
					     
					     if(questionId!=0)
					     {
					    	 String  gsSqls="select qc.QuestionChoiceId,qc.QuestionId,qs.QuestionTitle,qc.ChoiceTag,qc.Choice,qc.AnswerChoice from gbl_sm_tbl_question_choices qc join gbl_sm_tbl_question qs on qs.QuestionId = qc.QuestionId where qc.QuestionId = '" + questionId + "' order by qc.QuestionChoiceId,qc.QuestionId";
						      Query gsQuerys = rdSession.createSQLQuery(gsSqls);
						      List parList1 = gsQuerys.list();
						      sb.append("<QuestionChoices>");
								sb.append("\n");
								Iterator IT = parList1.iterator();
							     while(IT.hasNext())
							     {
							      Object[] ex1=(Object[])IT.next();
							         sb.append("<QuestionChoice>");
								     sb.append("\n");
							         sb.append("<questionChoiceId>");
							         sb.append(ex1[0]);
							         sb.append("</questionChoiceId>");
							         sb.append("\n");
							         sb.append("<questionId>");
							         sb.append(ex1[1]);
							         sb.append("</questionId>");
							         sb.append("\n");
							         sb.append("<questionTitle>");
							         sb.append(ex1[2]);
							         sb.append("</questionTitle>");
							         sb.append("\n");
							         sb.append("<choiceTag>");
							         sb.append(ex1[3]);
							         sb.append("</choiceTag>");
							         sb.append("\n");
							         sb.append("<choice>");
							         sb.append(ex1[4]);
							         sb.append("</choice>");
							         sb.append("\n");
							         sb.append("<answerChoice>");
							         sb.append(ex1[5]);
							         sb.append("</answerChoice>");
							         sb.append("\n");
							         
							         sb.append("</QuestionChoice>");
								     sb.append("\n");
							         
					     	}
							     
					     }
							     sb.append("</QuestionChoices>");
									sb.append("\n");
			     }
			     }
					 sb.append("</Questions>");
					 string= sb.toString();
			    }
		catch(Exception localException)
		{
			System.out.println(localException);
			
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    
			    sb.append("could not getall question info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			     string= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (tx!=null)
				  tx.rollback();
		}
		finally
		{
			rdSession.close();
		
		}
		return string;
	}
}
