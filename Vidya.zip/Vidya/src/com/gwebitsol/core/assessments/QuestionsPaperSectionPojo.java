package com.gwebitsol.core.assessments;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="Question")
public class QuestionsPaperSectionPojo {
	private int questionPaperSectionId;
	private int questionId;
	private String questionTitle;
	
	
	public int getQuestionPaperSectionId() {
		return questionPaperSectionId;
	}
	public void setQuestionPaperSectionId(int questionPaperSectionId) {
		this.questionPaperSectionId = questionPaperSectionId;
	}
	public int getQuestionId() {
		return questionId;
	}
	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}
	public String getQuestionTitle() {
		return questionTitle;
	}
	public void setQuestionTitle(String questionTitle) {
		this.questionTitle = questionTitle;
	}
}
