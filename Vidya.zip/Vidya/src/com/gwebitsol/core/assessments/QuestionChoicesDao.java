package com.gwebitsol.core.assessments;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.assessments.SubjectScoresPojo;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class QuestionChoicesDao {
	Session addempSession=MDHibernateUtil.getSessionFactory().openSession();
	Transaction addempTx=null;
	StringBuffer sb=new StringBuffer();
	public String addQuestionChoices(QuestionChoice qc) {
		String outStr=null;
		try
			{
				addempTx=addempSession.beginTransaction();
		        Integer in=(Integer)addempSession.save(qc);
				System.out.println(in);
				addempTx.commit();
				sb.append("<QuestionChoice>");
				sb.append("\n");
				sb.append("<questionChoiceId>");
				sb.append(in);
				sb.append("</questionChoiceId>");
				sb.append("</QuestionChoice>");
				outStr=sb.toString();
	   		 }
			
				catch(Exception localException)
				{
				System.out.println(localException);
				    sb.append("<Response>");
				    sb.append("\n");
				    sb.append("<Result>");
				    sb.append("\n");
				    sb.append("Fail");
				    sb.append("\n");
				    sb.append("</Result>");
				    sb.append("\n");
				    sb.append("<Description>");
				    sb.append("could not inserted questionChoice info");
				    sb.append("</Description>");
				    sb.append("\n");
				    sb.append("<Exception>");
				    sb.append(localException);
				    sb.append("</Exception>");
				    sb.append("</Response>");
				    outStr= sb.toString();
				   MDTransactionWriter.exceptionlog.info(localException);
				  if (addempTx!=null)
					  addempTx.rollback();
			}
			finally
			{			
				addempSession.close();
			}
			return outStr;
		}
	public String updateQuestionChoices(QuestionChoice qc,int schoolId,int branchId) {
		Session upempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction upempTx=null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			upempTx=upempSession.beginTransaction();
			QuestionChoice field = (QuestionChoice) upempSession.get(QuestionChoice.class,qc.getQuestionChoiceId());
			upempSession.evict(field);
			if(branchId==field.getBranchId()&&schoolId==field.getSchoolId())
				upempSession.update(qc);
				upempTx.commit();
				sb.append("<QuestionChoice>");
				sb.append("\n");
				sb.append("update successfully");
				sb.append("</QuestionChoice>");
				String str=sb.toString();
				return str;
	   		 	}
			catch(Exception localException)
			{
					System.out.println(localException);
					sb.append("<Response>");
				    sb.append("\n");
				    sb.append("<Result>");
				    sb.append("\n");
				    sb.append("Fail");
				    sb.append("\n");
				    sb.append("</Result>");
				    sb.append("\n");
				    sb.append("<Description>");
				    sb.append("could not update QuestionChoice info");
				    sb.append("</Description>");
				    sb.append("\n");
				    sb.append("<Exception>");
				    sb.append(localException);
				    sb.append("</Exception>");
				    sb.append("</Response>");
				    outStr= sb.toString();
				    MDTransactionWriter.exceptionlog.info(localException);
				    if (upempTx!=null)
					upempTx.rollback();
			}
			finally
			{			
					upempSession.close();
			}
					return outStr;
	}
	public String deleteQuestionChoices(int questionChoiceId,int schoolId,int branchId) {
		Session delempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction delempTx=null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			delempTx=delempSession.beginTransaction();
			QuestionChoice field = (QuestionChoice) delempSession.get(QuestionChoice.class,questionChoiceId);
			   
			   int branid = field.getBranchId();
			   int sclid = field.getSchoolId();
			   delempSession.evict(field);         
			   if(branchId==branid&&schoolId==sclid)
			   {
			Query empQuery=delempSession.createSQLQuery("update gbl_sm_tbl_question_choices set IsDeleted ='Y' where questionChoiceId='"+questionChoiceId+"'");
			empQuery.executeUpdate();
			delempTx.commit();
			sb.append("<QuestionChoice>");
			sb.append("\n");
			sb.append("delete successfully");
			sb.append("</QuestionChoice>");
			String str=sb.toString();
			return str;
		}	
		}
			catch(Exception localException)
			{
				System.out.println(localException);		
				    sb.append("<Response>");
				    sb.append("\n");
				    sb.append("<Result>");
				    sb.append("\n");
				    sb.append("Fail");
				    sb.append("\n");
				    sb.append("</Result>");
				    sb.append("\n");
				    sb.append("<Description>");
				    sb.append("could not delete QuestionChoice info");
				    sb.append("</Description>");
				    sb.append("\n");
				    sb.append("<Exception>");
				    sb.append(localException);
				    sb.append("</Exception>");
				    sb.append("</Response>");
				    outStr= sb.toString();
				   MDTransactionWriter.exceptionlog.info(localException);
				  if (delempTx!=null)
					  delempTx.rollback();
			}
			finally
			{			
				delempSession.close();
			}
			return outStr;
	}
	public String getQuestionChoices(int questionChoiceId,int schoolId,int branchId) {
		Session gtempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gtempTx=null;
		StringBuffer sb=new StringBuffer();
		System.out.println("hi success");
		String strg= null;
			try {
				gtempTx = gtempSession.beginTransaction();
				List list=gtempSession.createSQLQuery("Select qc.QuestionChoiceId,qc.QuestionId,q.QuestionTitle,qc.ChoiceTag,qc.Choice,qc.AnswerChoice from gbl_sm_tbl_question_choices as qc join gbl_sm_tbl_question as q on qc.QuestionId = q.QuestionId where qc.IsDeleted <> 'Y' or qc.IsDeleted IS NULL and QuestionChoiceId = '" + questionChoiceId + "' and qc.SchoolId ='" + schoolId + "'  and qc.BranchId ='" + branchId + "' ;").list();
			     Iterator it=list.iterator();
			    		    sb.append("<QuestionChoice>");
					        sb.append("\n");
					        while(it.hasNext())
					        {
							Object[] ex=(Object[])it.next();
					        sb.append("<questionChoiceId>");
						    sb.append(ex[0]);
						    sb.append("</questionChoiceId>");
						    sb.append("\n");
						    sb.append("<questionId>");
						    sb.append(ex[1]);
						    sb.append("</questionId>");
						    sb.append("\n");
						    sb.append("<choiceTag>");
							sb.append(ex[2]);
							sb.append("</choiceTag>");
							 sb.append("\n");
							sb.append("<choice>");
							sb.append(ex[3]);
							sb.append("</choice>");
							 sb.append("\n");
							sb.append("<answerChoice>");
							sb.append(ex[4]);
							sb.append("</answerChoice>");
							sb.append("\n");
					        }
							sb.append("</QuestionChoice>");
						    strg= sb.toString();
												
			} 	catch (Exception localException) {
				System.out.println(localException);
				   	sb.append("<Response>");
				    sb.append("\n");
				    sb.append("<Result>");
				    sb.append("\n");
				    sb.append("Fail");
				    sb.append("\n");
				    sb.append("</Result>");
				    sb.append("\n");
				    sb.append("<Description>");
				    sb.append("could not getby QuestionChoice info");
				    sb.append("</Description>");
				    sb.append("\n");
				    sb.append("<Exception>");
				    sb.append(localException);
				    sb.append("</Exception>");
				    sb.append("</Response>");
				    sb.append("</questionChoiceId>");
				    sb.append("</QuestionChoice>");
				    strg= sb.toString();
				   MDTransactionWriter.exceptionlog.info(localException);
				  if (gtempTx!=null)
					  gtempTx.rollback();
				} finally {
					gtempSession.close();
				}
		return strg;
	}
	public String getAllQuestionChoices(int PNO, int size,int schoolId,int branchId) {
		Session rdSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb= new StringBuffer();
		String string=null;
		//ScoreSheetPojo ex=null;
		try
		{
			tx = rdSession.beginTransaction();
			
			if(("all") != null)
			   {
			    int fset = (PNO-1)*size;
			    String gsSql ="select count(*) from gbl_sm_tbl_question_choices as qc where qc.IsDeleted <> 'Y' or qc.IsDeleted IS NULL and qc.SchoolId ='" + schoolId + "'  and qc.BranchId ='" + branchId + "'";
			    Query gsQuery=rdSession.createSQLQuery(gsSql);
			    Object noRecords= gsQuery.uniqueResult();
			    sb.append("<QuestionChoices>");
			    sb.append("\n");
			    sb.append("<noRecords>"+noRecords+"</noRecords>");
			    sb.append("\n");
			    
			     if (PNO > 0 & size > 0){
			     gsSql="Select qc.QuestionChoiceId,qc.QuestionId,q.QuestionTitle,qc.ChoiceTag,qc.Choice,qc.AnswerChoice from gbl_sm_tbl_question_choices as qc join gbl_sm_tbl_question as q on qc.QuestionId = q.QuestionId where qc.IsDeleted <> 'Y' or qc.IsDeleted IS NULL and qc.SchoolId ='" + schoolId + "'  and qc.BranchId ='" + branchId + "' limit "+size+" offset "+fset;}
			     else {
			      gsSql="Select qc.QuestionChoiceId,qc.QuestionId,q.QuestionTitle,qc.ChoiceTag,qc.Choice,qc.AnswerChoice from gbl_sm_tbl_question_choices as qc join gbl_sm_tbl_question as q on qc.QuestionId = q.QuestionId where qc.IsDeleted <> 'Y' or qc.IsDeleted IS NULL and qc.SchoolId ='" + schoolId + "'  and qc.BranchId ='" + branchId + "'";
			     } 
			   
			    gsQuery=rdSession.createSQLQuery(gsSql);
			    List gcList=gsQuery.list();
			    Iterator gsIT=gcList.iterator();
			    while(gsIT.hasNext())
			     {
			    	Object[] ex=(Object[])gsIT.next();
			    	sb.append("<QuestionChoice>");
					sb.append("\n");
			        sb.append("<questionChoiceId>");
				    sb.append(ex[0]);
				    sb.append("</questionChoiceId>");
				    sb.append("\n");
				    sb.append("<questionId>");
				    sb.append(ex[1]);
				    sb.append("</questionId>");
				    sb.append("\n");
				    sb.append("<choiceTag>");
					sb.append(ex[2]);
					sb.append("</choiceTag>");
					 sb.append("\n");
					sb.append("<choice>");
					sb.append(ex[3]);
					sb.append("</choice>");
					 sb.append("\n");
					sb.append("<answerChoice>");
					sb.append(ex[4]);
					sb.append("</answerChoice>");
					sb.append("\n");
					sb.append("</QuestionChoice>");
			}
		}
					 sb.append("</QuestionChoices>");
					 String str= sb.toString();
					 tx.commit();
					 return str;
		}
		catch(Exception localException)
		{
				System.out.println(localException);
				sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    sb.append("could not getall QuestionChoices info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    string= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			   if (tx!=null)
				  tx.rollback();
		}
		finally
		{
			rdSession.close();
		}
		return string;
	}
}
