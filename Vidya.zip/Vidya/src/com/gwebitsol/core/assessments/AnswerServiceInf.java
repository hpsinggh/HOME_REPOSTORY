package com.gwebitsol.core.assessments;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;
@Path("/answer")
public interface AnswerServiceInf {

@POST
@Consumes({"application/xml","application/json"})
@Produces({"application/xml","application/json"})
@Path("/add")
public Response addAnswer(AnswerPojo answerPojo,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);

@POST
@Consumes({"application/xml","application/json"})
@Produces({"application/xml","application/json"})
@Path("/delete")
public Response deleteAnswer(@QueryParam("id") int id,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);

@POST
@Consumes({"application/xml","application/json"})
@Produces({"application/xml","application/json"})
@Path("/update")
public Response updateAnswer(AnswerPojo answerPojo,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);

@GET

@Consumes({"application/xml","application/json"})
@Produces({"application/xml","application/json"})
@Path("/getall")
public Response getAllAnswer(@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName
		,@QueryParam("PNO") int PNO,@QueryParam("size") int size,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);

@GET
@Consumes({"application/xml","application/json"})
@Produces({"application/xml","application/json"})
@Path("/get")
public  Response getByIdAnswer(@QueryParam("id") int id,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);

@GET
@Consumes({"application/xml","application/json"})
@Produces({"application/xml","application/json"})
@Path("/getanswerbyquestion")
public  Response getAnswerbyquestion(@QueryParam("questionId") int questionId,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);

}
