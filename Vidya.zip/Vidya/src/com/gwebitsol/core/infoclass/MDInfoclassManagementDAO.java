/*
Proprietary Notice
This file contains confidential information of meldit Pvt. Ltd. (India)  and meldit Inc. (USA), 
which is available for the sole purpose of permitting the recipient for engineering and product development purposes.  
In consideration of receipt of this file, the recipient agrees to maintain such information in confidence and not to
reproduce or otherwise disclose this information to any person outside the group directly responsible for its contents.

Security
The information contained herein is proprietary to meldit Pvt. Ltd. (India)  and meldit Inc. (USA) and may not be used, 
reproduced or disclosed.  The recipient of this file, by its retention and use, agrees to protect the same and the 
information contained therein from distribution, loss and theft.
__________________________________________________________________________________________________________________________________________________________________________________
*/

package com.gwebitsol.core.infoclass;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.datastore.MDFolderManagementDAO;
import com.gwebitsol.core.infoclass.MDCreateTableFromInfoFields;
import com.gwebitsol.core.infoclass.MDICFieldsPOJO;
import com.gwebitsol.core.objectcontroller.device.MDDeviceManagementDAO;
import com.gwebitsol.core.objectcontroller.object.MDObjectManagementDAO;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class MDInfoclassManagementDAO 
{
	DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	Date date = new Date();
	String d=dateFormat.format(date);

	@SuppressWarnings("rawtypes")
	public String addInfoClass(String infoclassName,String infoclassType,ArrayList<MDICFieldsPOJO> icL,int userID)
	{
		Session icSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;	
		
		int infoclasstype=0;
		String str=null;
		String acl=null;
		
		int pfid =(Integer)icSession.createSQLQuery("select folderid from mdfolder where foldername='infoclass'").uniqueResult();
		
		try{
			transaction=icSession.beginTransaction();
			
			
			List list=icSession.createSQLQuery("select * from MDOBJECTINFOCLASSDEFCONTAINER where infoclassname='"+infoclassName+"'").list();
			if(list!=null && list.size()>0)
			{
				str="Infoclass with this name already exists...";
			}
			else
			{
				if(userID==1)
				{
					acl="U#1:111";
				}
				else
				{
					acl="U#1:111;U#"+userID+":111";
				}
			MDCreateTableFromInfoFields mdcrtif=new MDCreateTableFromInfoFields();
			String outStr=mdcrtif.createTable(infoclassName, icL);
			if(outStr!="fail")
			{		
			if(infoclassType.equalsIgnoreCase("Object"))
			{
				infoclasstype=1;
			}
			else if(infoclassType.equalsIgnoreCase("Device"))
			{
				infoclasstype=2;
			}
			else if(infoclassType.equalsIgnoreCase("Organization"))
			{
				infoclasstype=3;
			}
			
			String addICSql="INSERT INTO MDOBJECTINFOCLASSDEFCONTAINER(INFOCLASSNAME,CREATEDBY,CREATEDDATE,ACL,PARENTFOLDERID,MODIFIEDBY,MODIFIEDDATE,TYPE) " +
					"values('"+infoclassName+"',"+userID+",'"+d+"','"+acl+"',"+pfid+",0,'0000-00-00 00:00:00',"+infoclasstype+")";
		
			Query icQuery=icSession.createSQLQuery(addICSql);
			icQuery.executeUpdate();
			
			int infoclassid=(Integer)icSession.createSQLQuery("select infoclassid from MDOBJECTINFOCLASSDEFCONTAINER where infoclassname='"+infoclassName+"'").uniqueResult();

			for (int i=0; i<icL.size(); i++) 
			{ 
				MDICFieldsPOJO  fieldObj = (MDICFieldsPOJO )icL.get(i);
				String name=fieldObj.getFieldName();
				String displayName=fieldObj.getFieldDisplayType();
				String type=fieldObj.getFieldType();
				String pfgrp=fieldObj.getParentFieldGroup();
				String order=fieldObj.getOrder_1();
				int size=fieldObj.getFieldSize();
				String null_1="NOT NULL";
				String index="no";

				if(index.equals(true))                
				{
					index=fieldObj.getIndex_1();
				}
				String addIcfSql="INSERT INTO MDOBJINFOCLASSFIELDS(INFOCLASSID,FIELDNAME,DISPLAYTYPE,FIELDTYPE,PARENTFIELDGROUP,ORDER_1,FIELDSIZE,NULL_1,INDEX_1) " +
						"VALUES("+infoclassid+",'"+name+"','"+displayName+"','"+type+"','"+pfgrp+"','"+order+"',"+size+",'"+null_1+"','"+index+"')";
				
		
				Query icQuery1=icSession.createSQLQuery(addIcfSql);
				icQuery1.executeUpdate();

			}
			str="<status>infoclass created</status>";
			}
			else
			{
				str="<status>error while creating infoclass</status>";
			}
			}
		}
		catch(Exception localexception)
		{
			transaction.rollback();
			
			Query icQuery1=icSession.createSQLQuery("drop view view_"+infoclassName);
			icQuery1.executeUpdate();
			
			Query icQuery2=icSession.createSQLQuery("drop table "+infoclassName);
			icQuery2.executeUpdate();
			
			str="<status>error while creating infoclass</status>";
			MDTransactionWriter.exceptionlog.info(localexception);
		}
		finally
		{
			
			transaction.commit();	
			icSession.close();
		}
		
		return str;
	}

	//this method will add new columns to infoclass table
	//drop the old view and creates a new view
	public String editInfoclass(String infoclassName,ArrayList<MDICFieldsPOJO> icL,int userID)
	{
		Session eiSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction eiTx=null;
		
		String outStr=null;
		StringBuffer sb=new StringBuffer();
		String name=null;
		try
		{
			eiTx=eiSession.beginTransaction();
			sb.append("alter table "+infoclassName+" add ");
			for (int i=0; i<icL.size(); i++) 
			{ 
				System.out.println("Entered into loop");
				MDICFieldsPOJO  fieldObj = (MDICFieldsPOJO )icL.get(i);
				name=fieldObj.getFieldName();
				String type=fieldObj.getFieldType();
				int size=fieldObj.getFieldSize();
				String null_1=fieldObj.getNull_1();

				if("String".equalsIgnoreCase(type))
				{
					fieldObj.setFieldType("VARCHAR");
					type=fieldObj.getFieldType();		
				}
				else if("Integer".equalsIgnoreCase(type))
				{
					fieldObj.setFieldType("INT");
					type=fieldObj.getFieldType();	
				}
					sb.append(name);
					sb.append(" ");
					sb.append(type);
					sb.append(" (");
					sb.append(size);
					sb.append(") ");
					sb.append(null_1);
					sb.append(",add ");
			}
			String st=",";
			String st1=" ";
			int lastComma=sb.lastIndexOf(st);
			int lastSpace=sb.lastIndexOf(st1);
			sb.delete(lastComma, lastSpace);
			
			Query icQuery=eiSession.createSQLQuery(sb.toString());
			icQuery.executeUpdate();
			sb.setLength(0);
			
			Query icQuery1=eiSession.createSQLQuery("drop view view_"+infoclassName);
			icQuery1.executeUpdate();
			
			Query icQuery2=eiSession.createSQLQuery("create view view_"+infoclassName+" as select * from "+infoclassName);
			icQuery2.executeUpdate();
			
			Query icQuery3=eiSession.createSQLQuery("update MDOBJECTINFOCLASSDEFCONTAINER set MODIFIEDDATE='"+d+"' ,MODIFIEDBY="+userID+" where infoclassName='"+infoclassName+"'");
			icQuery3.executeUpdate();
			
			int infoclassid=(Integer)eiSession.createSQLQuery("select infoclassid from MDOBJECTINFOCLASSDEFCONTAINER where infoclassname='"+infoclassName+"'").uniqueResult();

			for (int i=0; i<icL.size(); i++) 
			{ 
				MDICFieldsPOJO  fieldObj = (MDICFieldsPOJO )icL.get(i);
				String fieldname=fieldObj.getFieldName();
				String displayName=fieldObj.getFieldDisplayType();
				String type=fieldObj.getFieldType();
				String pfgrp=fieldObj.getParentFieldGroup();
				String order=fieldObj.getOrder_1();
				int size=fieldObj.getFieldSize();
				String null_1="NOT NULL";
				String index="no";
				if(index.equals(true))
				{
					index=fieldObj.getIndex_1();
				}
				String addIcfSql="INSERT INTO MDOBJINFOCLASSFIELDS(INFOCLASSID,FIELDNAME,DISPLAYTYPE,FIELDTYPE,PARENTFIELDGROUP,ORDER_1,FIELDSIZE,NULL_1,INDEX_1) " +
						"VALUES("+infoclassid+",'"+fieldname+"','"+displayName+"','"+type+"','"+pfgrp+"','"+order+"',"+size+",'"+null_1+"','"+index+"')";
				
		
				Query icQuery4=eiSession.createSQLQuery(addIcfSql);
				icQuery4.executeUpdate();
			}
				eiTx.commit();
				outStr="infoclass is edited";
			
		}
		catch(Exception localException)
		{
			eiTx.rollback();
			outStr="fail";
		}
		finally
		{
			sb=null;
			eiSession.close();
		}
		return outStr;
	}
	
	@SuppressWarnings({ "deprecation", "rawtypes" })
	public String getInfoClassFields(String infoclassname)

	{
		Session gicSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gictransaction = null;	
		StringBuffer infFieldsSB=new StringBuffer();
		String infoclassType=null;
		String ginfXMLString=null;
		try
		{
			gictransaction=gicSession.beginTransaction();
		
		int infoclassid=(Integer)gicSession.createSQLQuery("select infoclassid from MDOBJECTINFOCLASSDEFCONTAINER where infoclassname='"+infoclassname+"'").uniqueResult();
		int infoType=(Integer)gicSession.createSQLQuery("select type from MDOBJECTINFOCLASSDEFCONTAINER where infoclassname='"+infoclassname+"'").uniqueResult();
	
		if(infoType==1)
		{
			infoclassType="Object";
		}
		else if(infoType==2)
		{
			infoclassType="Device";
		}
		else if(infoType==3)
		{
			infoclassType="Organization";
		}
		
		String infSql2="select  * from mdobjinfoclassfields where infoclassid="+infoclassid+" group by parentfieldgroup order by fieldid";
		Query ginfQuery1=gicSession.createSQLQuery(infSql2).addScalar("FIELDID",Hibernate.INTEGER).addScalar("PARENTFIELDGROUP",Hibernate.STRING);
		List ginfList1=ginfQuery1.list();
		infFieldsSB.append("<MD_Infoclass>");
		infFieldsSB.append("\n");
		infFieldsSB.append("<InfoclassType>"+infoclassType+"</InfoclassType>");
		infFieldsSB.append("\n");
		Iterator ginfIT=ginfList1.iterator();
		while(ginfIT.hasNext())
		{
			Object[] infObj1=(Object[])ginfIT.next();
			infFieldsSB.append("<SectionName name='"+infObj1[1]+"'>");
			infFieldsSB.append("\n");
			String pfg=(String)infObj1[1];
			System.out.println(pfg);
			String infSql1="select * from mdobjinfoclassfields  where infoclassid="+infoclassid+" and parentfieldgroup='"+pfg+"'";
			Query ginfQuery=gicSession.createSQLQuery(infSql1).addScalar("fieldid",Hibernate.INTEGER).addScalar("infoclassid",Hibernate.INTEGER).addScalar("fieldname",Hibernate.STRING).addScalar("displaytype",Hibernate.STRING).addScalar("fieldtype",Hibernate.STRING);
			List ginfList=ginfQuery.list();
			Iterator it=ginfList.iterator();
			while(it.hasNext())
			{
				Object[] infObj=(Object[])it.next();
				infFieldsSB.append("<field>");
				infFieldsSB.append("\n");
				infFieldsSB.append("<fieldname>");
				infFieldsSB.append(infObj[2]);
				infFieldsSB.append("</fieldname>");
				infFieldsSB.append("\n");
				infFieldsSB.append("<fielddisplaytype>");
				infFieldsSB.append(infObj[3]);
				infFieldsSB.append("</fielddisplaytype>");
				infFieldsSB.append("\n");
				infFieldsSB.append("<fieldtype>");
				infFieldsSB.append(infObj[4]);
				infFieldsSB.append("</fieldtype>");
				infFieldsSB.append("\n");
				infFieldsSB.append("</field>");
			}
			infFieldsSB.append("\n");
			infFieldsSB.append("</SectionName>");	
		}	
		infFieldsSB.append("\n");
		infFieldsSB.append("</MD_Infoclass>");
		
		ginfXMLString=infFieldsSB.toString();
		infFieldsSB.setLength(0);
		gictransaction.commit();
		}
		catch(Exception localexception)
		{
			gictransaction.rollback();
			infFieldsSB.setLength(0);
			ginfXMLString = "No infoclass is registered with this name";
			MDTransactionWriter.exceptionlog.info(localexception);
		}
		finally
		{
			gicSession.close();
			infFieldsSB=null;
		}

		return ginfXMLString;
	}

	@SuppressWarnings({ "deprecation", "rawtypes" })
	public String getAllInfoClasses(int uid)
	  {
	    Session iacSession = MDHibernateUtil.getSessionFactory().openSession();
	    Transaction iactransaction = null;
	    StringBuffer infFieldsSB = new StringBuffer();
	    
	    String infXMLString = null;
	    try
	    {
	      iactransaction = iacSession.beginTransaction();

	      String infSql1 = "select * from mdobjectinfoclassdefcontainer where acl like '%U#"+uid+":%' order by infoclassname ASC";
	      Query ginfQuery = iacSession.createSQLQuery(infSql1).addScalar("infoclassid", Hibernate.INTEGER).addScalar("infoclassname", Hibernate.STRING);

	      if (ginfQuery != null)
	      {
	        List ginfList = ginfQuery.list();
	        infFieldsSB.append("<MD_infoclass>");
	        Iterator it = ginfList.iterator();
	        while (it.hasNext())
	        {
	          Object[] infObj = (Object[])it.next();
	          infFieldsSB.append("<infoclassName>");
	          infFieldsSB.append(infObj[1]);
	          infFieldsSB.append("</infoclassName>");
	          infFieldsSB.append("\n");
	        }
	        infFieldsSB.append("</MD_infoclass>");

	        infXMLString = infFieldsSB.toString();
	        iactransaction.commit();
	      }
	      else
	      {
	        infXMLString = "No infoclass is registered";
	        MDTransactionWriter.exceptionlog.info(infXMLString);
	      }
	    }
	    catch (Exception localexception) 
	    {
	    	iactransaction.rollback();
	    	infFieldsSB.setLength(0);
	    	MDTransactionWriter.exceptionlog.info(localexception);
	    	infXMLString = "fail";
	    }
	    finally
	    {
	      iacSession.close();
	      infFieldsSB=null;
	    }

	    return infXMLString;
	  }
	
	@SuppressWarnings({ "deprecation", "rawtypes" })
	public String getInfoclass(String Type,int uid)
	{
		  	Session icSession = MDHibernateUtil.getSessionFactory().openSession();
		    Transaction ictransaction = null;
		    StringBuffer infFieldsSB = new StringBuffer();
		    String infXMLString = null;
		    int infoclasstype=0;
		    try
		    {
		      ictransaction = icSession.beginTransaction();
		      if(Type.equalsIgnoreCase("Object"))
		      {
		    	  infoclasstype=1;
		      }
		      else if(Type.equalsIgnoreCase("Device"))
		      {
		    	  infoclasstype=2;  
		      }
		      else if(Type.equalsIgnoreCase("Organization"))
		      {
		    	 infoclasstype=3;  
		      }
		      
		      String infSql1 = "select * from mdobjectinfoclassdefcontainer where type="+infoclasstype+" and acl like '%U#"+uid+":%'";
		      Query ginfQuery = icSession.createSQLQuery(infSql1).addScalar("infoclassid", Hibernate.INTEGER).addScalar("infoclassname", Hibernate.STRING);
		        
		      List ginfList = ginfQuery.list();
		      if(ginfList !=null && ginfList.size()>0)
		      {
		        infFieldsSB.append("<MD_infoclass>");
		        Iterator it = ginfList.iterator();
		        while (it.hasNext())
		        {
		          Object[] infObj = (Object[])it.next();
		          infFieldsSB.append("<infoclassName>");
		          infFieldsSB.append(infObj[1]);
		          infFieldsSB.append("</infoclassName>");
		          infFieldsSB.append("\n");
		        }
		        infFieldsSB.append("</MD_infoclass>");
		       
		      }
		      else
		      {
		    	  infFieldsSB.append("<MD_infoclass>");
		    	  infFieldsSB.append("\n"); 
			      infFieldsSB.append("<infoclassName>No infoclass</infoclassName>");
			      infFieldsSB.append("\n"); 
			      infFieldsSB.append("</MD_infoclass>");
		    	  
		      }
		        ictransaction.commit();
		        infXMLString = infFieldsSB.toString();
		        infFieldsSB.setLength(0);
		      
		    }
		    catch (Exception localexception) 
		    {
		    	ictransaction.rollback();
		    	infFieldsSB.setLength(0);
		    	MDTransactionWriter.exceptionlog.info(localexception);
		    	infXMLString = "fail";
		    }
		    finally
		    {
		      icSession.close();
		      infFieldsSB=null;
		    }

		    return infXMLString;
		
	}


	@SuppressWarnings({ "deprecation", "rawtypes" })
	public String deleteInfoClass(String infoclassName,String infoclassType)
	{
		Session diSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction diTx = null;
		String outStr=null;
		try
		{
			diTx=diSession.beginTransaction();
			
			int infoID=(Integer)diSession.createSQLQuery("select infoclassid from mdobjectinfoclassdefcontainer where infoclassname='"+infoclassName+"'").uniqueResult();
			
			if(infoclassType.equalsIgnoreCase("Object"))
			{
				MDObjectManagementDAO dmom=new MDObjectManagementDAO();
				String doSql="select * from  mdfolder where infoclassid="+infoID;
				Query doQuery=diSession.createSQLQuery(doSql).addScalar("foldername",Hibernate.STRING);
				List doList=doQuery.list();
				if(doList!=null && doList.size()>0)
				{
				Iterator doIT=doList.iterator();
				while(doIT.hasNext())
				{
					String objectName=(String)doIT.next();
					dmom.deleteObject(objectName, infoclassName);
				}
				}
				else{}
			}
			else if(infoclassType.equalsIgnoreCase("Device"))
			{
				MDDeviceManagementDAO mddm=new MDDeviceManagementDAO();
				String ddSql="select * from mdfolder where infoclassid="+infoID;
				Query doQuery=diSession.createSQLQuery(ddSql).addScalar("foldername",Hibernate.STRING);
				List doList=doQuery.list();
				if(doList!=null && doList.size()>0)
				{
				Iterator doIT=doList.iterator();
				while(doIT.hasNext())
				{
					String deviceName=(String)doIT.next();
					mddm.deleteDevice(deviceName, infoclassName);
				}
				}
				else{}
			}
			else if(infoclassType.equalsIgnoreCase("Organization"))
			{
				MDFolderManagementDAO mdfm=new MDFolderManagementDAO();
				String ddSql="select * from mdfolder where infoclassid="+infoID;
				Query doQuery=diSession.createSQLQuery(ddSql).addScalar("folderid",Hibernate.INTEGER);
				List doList=doQuery.list();
				if(doList!=null && doList.size()>0)
				{
				Iterator doIT=doList.iterator();
				while(doIT.hasNext())
				{
					int folderID=(Integer)doIT.next();
					mdfm.deleteAllSubFolders(folderID);
				}
				}
				else{}
			}
			
			Query diQuery=diSession.createSQLQuery("delete from mdobjinfoclassfields where infoclassid="+infoID);
			diQuery.executeUpdate();
			
			Query diQuery1=diSession.createSQLQuery("drop table "+infoclassName);
			diQuery1.executeUpdate();
			
			Query diQuery2=diSession.createSQLQuery("drop view view_"+infoclassName);
			diQuery2.executeUpdate();
			
			Query diQuery3=diSession.createSQLQuery("delete from mdobjectinfoclassdefcontainer where infoclassname='"+infoclassName+"'");
			diQuery3.executeUpdate();
			
			diTx.commit();
			
			outStr="<status> infoclass "+infoclassName+" is deleted</status>";
		}
		catch(Exception localException)
		{
			diTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			outStr="<status> error while deleting infoclass </status>";
		}
		finally
		{
			diSession.close();
		}
		
		
		return outStr;
	}

	public String addInfoclasses(String infoclassName, String infoclassType, ArrayList<MDICFieldsPOJO> icL, int userID) {
		Session icSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;	
		
		int infoclasstype=0;
		String str=null;
		String acl=null;
		
		int pfid =(Integer)icSession.createSQLQuery("select folderid from mdfolder where foldername='infoclass'").uniqueResult();

		try{
			transaction=icSession.beginTransaction();
			
			
			List list=icSession.createSQLQuery("select * from MDOBJECTINFOCLASSDEFCONTAINER where infoclassname='"+infoclassName+"'").list();
			if(list!=null && list.size()>0)
			{
				str="Infoclass with this name already exists...";
			}
			else
			{
				if(userID==1)
				{
					acl="U#1:111";
				}
				else
				{
					acl="U#1:111;U#"+userID+":111";
				}
			MDCreateTableFromInfoFields mdcrtif=new MDCreateTableFromInfoFields();
			String outStr=mdcrtif.createTable(infoclassName, icL);
			if(outStr!="fail")
			{		
			if(infoclassType.equalsIgnoreCase("Object"))
			{
				infoclasstype=1;
			}
			else if(infoclassType.equalsIgnoreCase("Device"))
			{
				infoclasstype=2;
			}
			else if(infoclassType.equalsIgnoreCase("Organization"))
			{
				infoclasstype=3;
			}
			
			String addICSql="INSERT INTO MDOBJECTINFOCLASSDEFCONTAINER(INFOCLASSNAME,CREATEDBY,CREATEDDATE,ACL,PARENTFOLDERID,MODIFIEDBY,MODIFIEDDATE,TYPE) " +
					"values('"+infoclassName+"',"+userID+",'"+d+"','"+acl+"',"+pfid+",0,'0000-00-00 00:00:00',"+infoclasstype+")";
		
			Query icQuery=icSession.createSQLQuery(addICSql);
			icQuery.executeUpdate();
			
			int infoclassid=(Integer)icSession.createSQLQuery("select infoclassid from MDOBJECTINFOCLASSDEFCONTAINER where infoclassname='"+infoclassName+"'").uniqueResult();

			for (int i=0; i<icL.size(); i++) 
			{ 
				MDICFieldsPOJO  fieldObj = (MDICFieldsPOJO )icL.get(i);
				String name=fieldObj.getFieldName();
				String displayName=fieldObj.getFieldDisplayType();
				String type=fieldObj.getFieldType();
				String pfgrp=fieldObj.getParentFieldGroup();
				String order=fieldObj.getOrder_1();
				int size=fieldObj.getFieldSize();
				String null_1="NOT NULL";
				String index="no";

				if(index.equals(true))                
				{
					index=fieldObj.getIndex_1();
				}
				String addIcfSql="INSERT INTO MDOBJINFOCLASSFIELDS(INFOCLASSID,FIELDNAME,DISPLAYTYPE,FIELDTYPE,PARENTFIELDGROUP,ORDER_1,FIELDSIZE,NULL_1,INDEX_1) " +
						"VALUES("+infoclassid+",'"+name+"','"+displayName+"','"+type+"','"+pfgrp+"','"+order+"',"+size+",'"+null_1+"','"+index+"')";
				
		
				Query icQuery1=icSession.createSQLQuery(addIcfSql);
				icQuery1.executeUpdate();

			}
			str="<status>infoclass created</status>";
			}
			else
			{
				str="<status>error while creating infoclass</status>";
			}
			}
		}
		catch(Exception localexception)
		{
			transaction.rollback();
			
			Query icQuery1=icSession.createSQLQuery("drop view view_"+infoclassName);
			icQuery1.executeUpdate();
			
			Query icQuery2=icSession.createSQLQuery("drop table "+infoclassName);
			icQuery2.executeUpdate();
			
			str="<status>error while creating infoclass</status>";
			MDTransactionWriter.exceptionlog.info(localexception);
		}
		finally
		{
			
			transaction.commit();	
			icSession.close();
		}
		
		return str;
	}
	
}

