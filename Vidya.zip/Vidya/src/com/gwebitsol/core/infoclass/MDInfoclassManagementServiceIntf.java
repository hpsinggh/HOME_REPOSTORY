/*
Proprietary Notice
This file contains confidential information of meldit Pvt. Ltd. (India)  and meldit Inc. (USA), 
which is available for the sole purpose of permitting the recipient for engineering and product development purposes.  
In consideration of receipt of this file, the recipient agrees to maintain such information in confidence and not to
reproduce or otherwise disclose this information to any person outside the group directly responsible for its contents.

Security
The information contained herein is proprietary to meldit Pvt. Ltd. (India)  and meldit Inc. (USA) and may not be used, 
reproduced or disclosed.  The recipient of this file, by its retention and use, agrees to protect the same and the 
information contained therein from distribution, loss and theft.
__________________________________________________________________________________________________________________________________________________________________________________
*/

package com.gwebitsol.core.infoclass;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

import com.gwebitsol.core.infoclass.Infoclass;

@Path("/infoclassmanagement/")
public interface MDInfoclassManagementServiceIntf 
{
	
	@Path("/add/")
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	public Response addInfoclass(Infoclass mdIC,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@Path("/addinf/")
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	public Response addInfoclasses(Infoclass mdIC,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@Path("/getdetails")
	@GET
	@Produces({"application/xml","application/json"})
	public Response getInfoclassFields(@QueryParam("infoclassName") String infoclassName,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@Path("/getall/")
	@GET
	@Produces({"application/xml","application/json"})
	public Response getInfoclassList(@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@Path("/getinfoclass/")
	@GET
	@Produces({"application/xml","application/json"})
	public Response getInfoclass(@QueryParam("type") String type,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@Path("/delete")
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	public Response deleteInfoclass(@QueryParam("infoclassName") String infoclassName,@QueryParam("infoclassType") String infoclassType,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@Path("/update/")
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	public Response updateInfoclass(Infoclass mdIC,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
		
}
