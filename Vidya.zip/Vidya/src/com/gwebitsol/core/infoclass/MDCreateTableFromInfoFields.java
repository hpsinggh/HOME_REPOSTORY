/*
Proprietary Notice
This file contains confidential information of meldit Pvt. Ltd. (India)  and meldit Inc. (USA), 
which is available for the sole purpose of permitting the recipient for engineering and product development purposes.  
In consideration of receipt of this file, the recipient agrees to maintain such information in confidence and not to
reproduce or otherwise disclose this information to any person outside the group directly responsible for its contents.

Security
The information contained herein is proprietary to meldit Pvt. Ltd. (India)  and meldit Inc. (USA) and may not be used, 
reproduced or disclosed.  The recipient of this file, by its retention and use, agrees to protect the same and the 
information contained therein from distribution, loss and theft.
__________________________________________________________________________________________________________________________________________________________________________________
*/

package com.gwebitsol.core.infoclass;

import java.util.ArrayList;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.infoclass.MDICFieldsPOJO;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class MDCreateTableFromInfoFields 
{
	Session icSession=MDHibernateUtil.getSessionFactory().openSession();
	Transaction transaction = null;	
	public String createTable(String infoclassName,ArrayList<MDICFieldsPOJO> icL)
	{
		String outStr=null;
		String str="String";
		String str1="Integer";
		StringBuffer sb=new StringBuffer();

		try
		{
		transaction=icSession.beginTransaction();
		sb.append("CREATE TABLE ");
		sb.append(infoclassName);
		sb.append("(indexid INT(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,componentid INT(11) NOT NULL,");
		for (int i=0; i<icL.size(); i++) 
		{ 
			System.out.println("Entered into loop");
			MDICFieldsPOJO  fieldObj = (MDICFieldsPOJO )icL.get(i);
			String name=fieldObj.getFieldName();
			String type=fieldObj.getFieldType();
			int size=fieldObj.getFieldSize();
			String null_1=fieldObj.getNull_1();

			if(str.equalsIgnoreCase(type))
			{
				fieldObj.setFieldType("VARCHAR");
				type=fieldObj.getFieldType();	
			}
			else if(str1.equalsIgnoreCase(type))
			{
				fieldObj.setFieldType("INT");
				type=fieldObj.getFieldType();	
			}
			
				sb.append(name);
				sb.append(" ");
				sb.append(type);
				sb.append("(");
				sb.append(size);
				sb.append(") ");
				sb.append(null_1);
				sb.append(",");
		

		}
		String st=",";
		int lastComma=sb.lastIndexOf(st);
		sb.deleteCharAt(lastComma);
		sb.append(")");
		Query icQuery2=icSession.createSQLQuery(sb.toString());
		icQuery2.executeUpdate();
		sb.setLength(0);
		System.out.println("table created");
		String sql1="create view view_"+infoclassName+" as select * from "+infoclassName;
		Query icQuery3=icSession.createSQLQuery(sql1);
		icQuery3.executeUpdate();
		transaction.commit();
		outStr="table created";
		}
		catch(Exception localException)
		{
			transaction.rollback();
			sb.setLength(0);
			MDTransactionWriter.exceptionlog.info(localException);
			outStr="fail";
		}
		finally
		{
		icSession.close();
		sb=null;
		}
		return outStr;
	}
	
}
