/*
Proprietary Notice
This file contains confidential information of meldit Pvt. Ltd. (India)  and meldit Inc. (USA), 
which is available for the sole purpose of permitting the recipient for engineering and product development purposes.  
In consideration of receipt of this file, the recipient agrees to maintain such information in confidence and not to
reproduce or otherwise disclose this information to any person outside the group directly responsible for its contents.

Security
The information contained herein is proprietary to meldit Pvt. Ltd. (India)  and meldit Inc. (USA) and may not be used, 
reproduced or disclosed.  The recipient of this file, by its retention and use, agrees to protect the same and the 
information contained therein from distribution, loss and theft.
__________________________________________________________________________________________________________________________________________________________________________________
*/

package com.gwebitsol.core.infoclass;

public class MDInfoClassFields 
{
String fieldName;
String fieldType;
String fieldSize;
String null_1;
String index_1;
public String getFieldName() {
	return fieldName;
}
public void setFieldName(String fieldName) {
	this.fieldName = fieldName;
}
public String getFieldType() {
	return fieldType;
}
public void setFieldType(String fieldType) {
	this.fieldType = fieldType;
}
public String getFieldSize() {
	return fieldSize;
}
public void setFieldSize(String fieldSize) {
	this.fieldSize = fieldSize;
}
public String getNull_1() {
	return null_1;
}
public void setNull_1(String null_1) {
	this.null_1 = null_1;
}
public String getIndex_1() {
	return index_1;
}
public void setIndex_1(String index_1) {
	this.index_1 = index_1;
}
}
