/*
Proprietary Notice
This file contains confidential information of meldit Pvt. Ltd. (India)  and meldit Inc. (USA), 
which is available for the sole purpose of permitting the recipient for engineering and product development purposes.  
In consideration of receipt of this file, the recipient agrees to maintain such information in confidence and not to
reproduce or otherwise disclose this information to any person outside the group directly responsible for its contents.

Security
The information contained herein is proprietary to meldit Pvt. Ltd. (India)  and meldit Inc. (USA) and may not be used, 
reproduced or disclosed.  The recipient of this file, by its retention and use, agrees to protect the same and the 
information contained therein from distribution, loss and theft.
__________________________________________________________________________________________________________________________________________________________________________________
*/

package com.gwebitsol.core.infoclass;

public class MDICFieldsPOJO 
{
private int fieldID;
private int infoclassID;
private String fieldName;
private String fieldDisplayType;
private String fieldType;
private int fieldSize;
private String null_1;
private String index_1;
private String parentFieldGroup;
private String order_1;
public int getFieldID() {
	return fieldID;
}
public void setFieldID(int fieldID) {
	this.fieldID = fieldID;
}
public int getInfoclassID() {
	return infoclassID;
}
public void setInfoclassID(int infoclassID) {
	this.infoclassID = infoclassID;
}
public String getFieldName() {
	return fieldName;
}
public void setFieldName(String fieldName) {
	this.fieldName = fieldName;
}
public String getFieldType() {
	return fieldType;
}
public void setFieldType(String fieldType) {
	this.fieldType = fieldType;
}
public int getFieldSize() {
	return fieldSize;
}
public void setFieldSize(int fieldSize) {
	this.fieldSize = fieldSize;
}
public String getNull_1() {
	return null_1;
}
public void setNull_1(String null_1) {
	this.null_1 = null_1;
}
public String getIndex_1() {
	return index_1;
}
public void setIndex_1(String index_1) {
	this.index_1 = index_1;
}
public String getFieldDisplayType() {
	return fieldDisplayType;
}
public void setFieldDisplayType(String fieldDisplayType) {
	this.fieldDisplayType = fieldDisplayType;
}
public String getParentFieldGroup() {
	return parentFieldGroup;
}
public void setParentFieldGroup(String parentFieldGroup) {
	this.parentFieldGroup = parentFieldGroup;
}
public String getOrder_1() {
	return order_1;
}
public void setOrder_1(String order_1) {
	this.order_1 = order_1;
}
}