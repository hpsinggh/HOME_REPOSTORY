package com.gwebitsol.core.infoclass;
/*
Proprietary Notice
This file contains confidential information of meldit Pvt. Ltd. (India)  and meldit Inc. (USA), 
which is available for the sole purpose of permitting the recipient for engineering and product development purposes.  
In consideration of receipt of this file, the recipient agrees to maintain such information in confidence and not to
reproduce or otherwise disclose this information to any person outside the group directly responsible for its contents.

Security
The information contained herein is proprietary to meldit Pvt. Ltd. (India)  and meldit Inc. (USA) and may not be used, 
reproduced or disclosed.  The recipient of this file, by its retention and use, agrees to protect the same and the 
information contained therein from distribution, loss and theft.
__________________________________________________________________________________________________________________________________________________________________________________
*/

/*package com.gwebitsol.core.infoclass;


public class MDICFields 
{
		
	private String icfName;
	private String icfcType;
	private String icfType;
	private int icfSize;
	private String icfStatus;
	private String isIndex;
	
	public String getIcfName() {
		return icfName;
	}
	public void setIcfName(String icfName) {
		this.icfName = icfName;
	}
	public String getIcfType() {
		return icfType;
	}
	public void setIcfType(String icfType) {
		this.icfType = icfType;
	}
	public int getIcfSize() {
		return icfSize;
	}
	public void setIcfSize(int icfSize) {
		this.icfSize = icfSize;
	}
	public String getIcfStatus() {
		return icfStatus;
	}
	public void setIcfStatus(String icfStatus) {
		this.icfStatus = icfStatus;
	}
	public String getIsIndex() {
		return isIndex;
	}
	public void setIsIndex(String isIndex) {
		this.isIndex = isIndex;
	}
	public String getIcfcType() {
		return icfcType;
	}
	public void setIcfcType(String icfcType) {
		this.icfcType = icfcType;
	}
	
	
}
*/