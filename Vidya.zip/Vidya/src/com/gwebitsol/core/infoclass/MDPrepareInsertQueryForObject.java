/*
Proprietary Notice
This file contains confidential information of meldit Pvt. Ltd. (India)  and meldit Inc. (USA), 
which is available for the sole purpose of permitting the recipient for engineering and product development purposes.  
In consideration of receipt of this file, the recipient agrees to maintain such information in confidence and not to
reproduce or otherwise disclose this information to any person outside the group directly responsible for its contents.

Security
The information contained herein is proprietary to meldit Pvt. Ltd. (India)  and meldit Inc. (USA) and may not be used, 
reproduced or disclosed.  The recipient of this file, by its retention and use, agrees to protect the same and the 
information contained therein from distribution, loss and theft.
__________________________________________________________________________________________________________________________________________________________________________________
*/

package com.gwebitsol.core.infoclass;

import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.util.MDHibernateUtil;

public class MDPrepareInsertQueryForObject 
{
	private static Logger exceptionlog=Logger.getLogger("exceptionlog");
	@SuppressWarnings("rawtypes")
	public String prepareQuery(String infoclassName,int infoclassID)
	{
		String queryStr=null;
		Session qSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx=null;
		StringBuffer sSB=new StringBuffer();
		String fieldName=null;
		try
		{
			tx=qSession.beginTransaction();
			String sql="select * from mdobjinfoclassfields where infoclassid="+infoclassID;
			Query sQuery=qSession.createSQLQuery(sql);
			List sList=sQuery.list();
			Iterator it=sList.iterator();
			sSB.append("insert into "+infoclassName+"(componentid,");	
			int i=0;
			while(it.hasNext())
			{
				System.out.println("entered into loop");
				Object[] infFieldsNameObj=(Object[])it.next();
				fieldName=(String)infFieldsNameObj[2];
				System.out.println(fieldName);
				sSB.append(fieldName);
				sSB.append(",");
				i++;
			}
			System.out.println(i);
			System.out.println("exited from loop");
			int k=sSB.lastIndexOf(",");
			sSB.deleteCharAt(k);
			sSB.append(")values(");
			System.out.println(sSB.toString());

			queryStr=sSB.toString();
			sSB.setLength(0);
			tx.commit();

		}
		catch(Exception e)
		{
			exceptionlog.info(e);
			sSB.setLength(0);
			tx.rollback();
		}
		finally
		{
			qSession.close();
			sSB=null;
		}
		return queryStr;
	}
}
