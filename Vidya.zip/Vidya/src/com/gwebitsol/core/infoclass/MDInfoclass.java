package com.gwebitsol.core.infoclass;
/*
Proprietary Notice
This file contains confidential information of meldit Pvt. Ltd. (India)  and meldit Inc. (USA), 
which is available for the sole purpose of permitting the recipient for engineering and product development purposes.  
In consideration of receipt of this file, the recipient agrees to maintain such information in confidence and not to
reproduce or otherwise disclose this information to any person outside the group directly responsible for its contents.

Security
The information contained herein is proprietary to meldit Pvt. Ltd. (India)  and meldit Inc. (USA) and may not be used, 
reproduced or disclosed.  The recipient of this file, by its retention and use, agrees to protect the same and the 
information contained therein from distribution, loss and theft.
__________________________________________________________________________________________________________________________________________________________________________________
*/

/*package com.gwebitsol.core.infoclass;


import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="infoclass")
public class MDInfoclass
{
	
	private String infoclassName;
	private String infoclassType;
	public String getInfoclassName() {
		return infoclassName;
	}

	public void setInfoclassName(String infoclassName) {
		this.infoclassName = infoclassName;
	}

	public String getInfoclassType() {
		return infoclassType;
	}

	public void setInfoclassType(String infoclassType) {
		this.infoclassType = infoclassType;
	}

	public Wrapper getWrapper() {
		return wrapper;
	}

	public void setWrapper(Wrapper wrapper) {
		this.wrapper = wrapper;
	}



	private Wrapper wrapper = new Wrapper();
		
	@XmlElementWrapper(name="Fields")
    @XmlElement(name="Field")
    public List<MDICFields> getIcFields() {
        return wrapper.getIcFields();
    }

    public void setIcFields(List<MDICFields> icFields) {
        wrapper.setIcFields(icFields);
    }
    
}
*/