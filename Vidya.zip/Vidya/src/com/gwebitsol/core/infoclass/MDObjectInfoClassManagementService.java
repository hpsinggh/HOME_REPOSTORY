/*
Proprietary Notice
This file contains confidential information of meldit Pvt. Ltd. (India)  and meldit Inc. (USA), 
which is available for the sole purpose of permitting the recipient for engineering and product development purposes.  
In consideration of receipt of this file, the recipient agrees to maintain such information in confidence and not to
reproduce or otherwise disclose this information to any person outside the group directly responsible for its contents.

Security
The information contained herein is proprietary to meldit Pvt. Ltd. (India)  and meldit Inc. (USA) and may not be used, 
reproduced or disclosed.  The recipient of this file, by its retention and use, agrees to protect the same and the 
information contained therein from distribution, loss and theft.
__________________________________________________________________________________________________________________________________________________________________________________
*/

package com.gwebitsol.core.infoclass;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.gwebitsol.core.infoclass.Infoclass;
import com.gwebitsol.core.infoclass.MDICFieldsPOJO;
import com.gwebitsol.core.infoclass.MDInfoclassManagementDAO;
import com.gwebitsol.core.infoclass.MDInfoclassManagementServiceIntf;
import com.gwebitsol.core.security.MDVerifyConnectionID;
import com.gwebitsol.core.security.MDVerifyDatastoreName;
import com.gwebitsol.core.usermanagement.MDGetUserFromID;
import com.gwebitsol.core.util.MDTransactionWriter;

public class MDObjectInfoClassManagementService implements MDInfoclassManagementServiceIntf
{
	
	@Context private HttpServletRequest hsr;
	@SuppressWarnings("rawtypes")
	public Response addInfoclass(Infoclass mdIC,int userID,int connectionID,String datastoreName)
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			
			if(ret==1 )//&& rtVal==1)
			{
			String icName=mdIC.getInfoclassName();
			String icType=mdIC.getInfoclassType();
			System.out.println(icName);
			System.out.println(icType);
			ArrayList<MDICFieldsPOJO> icAL=new ArrayList<MDICFieldsPOJO>();
			
			System.out.println("pojo initiated");
			Iterator it=mdIC.getSections().iterator();
			System.out.println(it.toString());
			while(it.hasNext())
			{
		
				System.out.println("entered into first loop");
				Section s=(Section)it.next();
				System.out.println(s.getName());
				
				Iterator it1=s.getIcFields().iterator(); 
				while(it1.hasNext())
				{
					System.out.println("entered into second loop");
					
					InfoclassFields inf=(InfoclassFields)it1.next();
					MDICFieldsPOJO icFP=new MDICFieldsPOJO();
					icFP.setFieldName(inf.getLabelName());
					icFP.setFieldDisplayType(inf.getCompType());
					icFP.setFieldType(inf.getParamType());
					icFP.setParentFieldGroup(s.getName());
					icFP.setFieldSize(inf.getParamSize());
					icFP.setOrder_1(inf.getOrder());
					icFP.setNull_1("NOT NULL");
					icFP.setIndex_1(inf.getIndex());
					icAL.add(icFP);		
				}
				
			}
			System.out.println(icAL.size());
			System.out.println("iteration over");
			
			MDInfoclassManagementDAO ImDAO= new MDInfoclassManagementDAO();
			XMLString=ImDAO.addInfoClass(icName,icType,icAL,userID);
			if(XMLString.equals("<status>error while creating infoclass</status>"))
				statusStr="failed";
			else
				statusStr="success";
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			MDTransactionWriter.writeLog(datastoreName,"IMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				XMLString="<status>you are not authorised user</status>";
			}

		}catch(Exception e)
		{
			e.printStackTrace();
			throw new WebApplicationException(e, Response.Status.INTERNAL_SERVER_ERROR);
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}
	
	@SuppressWarnings("rawtypes")
	public Response updateInfoclass(Infoclass mdIC, int userID,int connectionID, String datastoreName) 
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			
			if(ret==1 )//&& rtVal==1)
			{
			String icName=mdIC.getInfoclassName();
			//String icType=mdIC.getInfoclassType();
			ArrayList<MDICFieldsPOJO> icAL=new ArrayList<MDICFieldsPOJO>();
			
			System.out.println("pojo initiated");
			Iterator it=mdIC.getSections().iterator();
			System.out.println(it.toString());
			while(it.hasNext())
			{
		
				System.out.println("entered into first loop");
				Section s=(Section)it.next();
				System.out.println(s.getName());
				
				Iterator it1=s.getIcFields().iterator();
				while(it1.hasNext())
				{
					System.out.println("entered into second loop");
					
					InfoclassFields inf=(InfoclassFields)it1.next();
					MDICFieldsPOJO icFP=new MDICFieldsPOJO();
					icFP.setFieldName(inf.getLabelName());
					icFP.setFieldDisplayType(inf.getCompType());
					icFP.setFieldType(inf.getParamType());
					icFP.setParentFieldGroup(s.getName());
					icFP.setFieldSize(inf.getParamSize());
					icFP.setOrder_1(inf.getOrder());
					icFP.setNull_1("NOT NULL");
					icFP.setIndex_1(inf.getIndex());
					icAL.add(icFP);	
					
				}
				
			}
			System.out.println(icAL.size());
			System.out.println("iteration over");
			
			MDInfoclassManagementDAO ImDAO= new MDInfoclassManagementDAO();
			XMLString=ImDAO.editInfoclass(icName, icAL, userID);
			if(XMLString.equals("<status>error while editing infoclass</status>"))
				statusStr="failed";
			else
				statusStr="success";
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			MDTransactionWriter.writeLog(datastoreName,"IMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				XMLString="<status>you are not authorised user</status>";
			}

		}catch(Exception e)
		{
			e.printStackTrace();
			throw new WebApplicationException(e, Response.Status.INTERNAL_SERVER_ERROR);
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}
	
	
	public Response getInfoclassFields(String infoclassName,int userID,int connectionID,String datastoreName)
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			
			if(ret==1 )//&& rtVal==1)
			{
			MDInfoclassManagementDAO ImDAO= new MDInfoclassManagementDAO();
			XMLString=ImDAO.getInfoClassFields(infoclassName);
			if(XMLString.equals("No infoclass is registered with this name"))
				statusStr="failed";
			else
				statusStr="success";
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			MDTransactionWriter.writeLog(datastoreName,"IMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				XMLString="<status>you are not authorised user</status>";
			}

		}catch(Exception e)
		{
			e.printStackTrace();
			throw new WebApplicationException(e, Response.Status.INTERNAL_SERVER_ERROR);
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}
	public Response getInfoclassList(int userID,int connectionID,String datastoreName)
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			
			if(ret==1 )//&& rtVal==1)
			{
			MDInfoclassManagementDAO ImDAO= new MDInfoclassManagementDAO();
			XMLString=ImDAO.getAllInfoClasses(userID);
			if(XMLString.equals("No infoclass is registered"))
				statusStr="failed";
			else
				statusStr="success";
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			MDTransactionWriter.writeLog(datastoreName,"IMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				XMLString="<status>you are not authorised user</status>";
			}

		}catch(Exception e)
		{
			e.printStackTrace();
			throw new WebApplicationException(e, Response.Status.INTERNAL_SERVER_ERROR);
		}
		
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}
	
	public Response deleteInfoclass(String infoclassName,String infoclassType, int userID,int connectionID,String datastoreName) 
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			
			if(ret==1 )//&& rtVal==1)
			{
			MDInfoclassManagementDAO ImDAO= new MDInfoclassManagementDAO();
			XMLString=ImDAO.deleteInfoClass(infoclassName,infoclassType);
			if(XMLString.equals("<status> error while deleting infoclass </status>"))
				statusStr="failed";
			else
				statusStr="success";
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			MDTransactionWriter.writeLog(datastoreName,"IMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				XMLString="<status>you are not authorised user</status>";
			}

		}catch(Exception e)
		{
			e.printStackTrace();
			throw new WebApplicationException(e, Response.Status.INTERNAL_SERVER_ERROR);
		}
		
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}

	public Response getInfoclass(String type, int userID, int connectionID,String datastoreName) 
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			
			if(ret==1 )//&& rtVal==1)
			{
			MDInfoclassManagementDAO ImDAO= new MDInfoclassManagementDAO();
			XMLString=ImDAO.getInfoclass(type,userID);
			if(XMLString.equals("fail"))
				statusStr="failed";
			else
				statusStr="success";
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			MDTransactionWriter.writeLog(datastoreName,"IMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				XMLString="<status>you are not authorised user</status>";
			}

		}catch(Exception e)
		{
			e.printStackTrace();
			throw new WebApplicationException(e, Response.Status.INTERNAL_SERVER_ERROR);
		}
		
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}

	public Response addInfoclasses(Infoclass mdIC, int userID, int connectionID, String datastoreName) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			ArrayList<MDICFieldsPOJO> icAL=new ArrayList<MDICFieldsPOJO>();
			if(ret==1 )//&& rtVal==1)
			{
			String icName=mdIC.getInfoclassName();
			String icType=mdIC.getInfoclassType();
			System.out.println(icName);
			System.out.println(icType);
			Iterator it=mdIC.getSections().iterator();
			System.out.println(it.toString());
			while(it.hasNext())
			{
		
				System.out.println("entered into first loop");
				Section s=(Section)it.next();
				System.out.println(s.getName());
				System.out.println("pojo initiated");
				Iterator it1=s.getIcFields().iterator(); 
				
				while(it1.hasNext())
				{
			
					
					System.out.println("entered into second loop");
					
					InfoclassFields inf=(InfoclassFields)it1.next();
					MDICFieldsPOJO icFP=new MDICFieldsPOJO();
					icFP.setFieldName(inf.getLabelName());
					icFP.setFieldDisplayType(inf.getCompType());
					icFP.setFieldType(inf.getParamType());
					icFP.setParentFieldGroup(s.getName());
					icFP.setFieldSize(inf.getParamSize());
					icFP.setOrder_1(inf.getOrder());
					icFP.setNull_1("NOT NULL");
					icFP.setIndex_1(inf.getIndex());
					icAL.add(icFP);		
					
				}
				
			}
			System.out.println(icAL.size());
			System.out.println("iteration over");
			
			MDInfoclassManagementDAO ImDAO= new MDInfoclassManagementDAO();
			XMLString=ImDAO.addInfoclasses(icName,icType,icAL,userID);
			if(XMLString.equals("<status>error while creating infoclass</status>"))
				statusStr="failed";
			else
				statusStr="success";
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			MDTransactionWriter.writeLog(datastoreName,"IMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				XMLString="<status>you are not authorised user</status>";
			}

		}catch(Exception e)
		{
			e.printStackTrace();
			throw new WebApplicationException(e, Response.Status.INTERNAL_SERVER_ERROR);
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}
	
	
	
}
