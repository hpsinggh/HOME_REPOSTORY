package com.gwebitsol.core.curriculum;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import com.gwebitsol.core.security.MDValidation;
import com.gwebitsol.core.usermanagement.MDGetUserFromID;
import com.gwebitsol.core.util.MDTransactionWriter;

public class AttendenceServiceImpl implements AttendenceServiceInf {
	@Context 
	private HttpServletRequest hsr;
	public Response addAttendence(AttendencePojo attendencePojo,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
			MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
			String status=null;
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date date = new Date();
			String startDate=dateFormat.format(date);
			Long sl=System.currentTimeMillis();
			 attendencePojo.setSchoolId(schoolId);
			   attendencePojo.setBranchId(branchId);
				try
					{	
					MDValidation mdv = new MDValidation();  
					   int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
					   System.out.println("verifiedvalue::"+ret);	
					   
					   MDGetUserFromID mdgufid = new MDGetUserFromID();
					   String requester = mdgufid.getUserName(userID);
							   
					if(ret==1 )//&& rtVal==1)
					{
						AttendenceDao dao= new AttendenceDao ();
						status=dao.addAttendence(attendencePojo);
						System.out.println("output is "+status);
					
						String endDate=dateFormat.format(new Date());
						Long el=System.currentTimeMillis();
						MDTransactionWriter.writeLog(datastoreName,"AttendenceServiceImpl_addAttendence",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
					}else
					{
						status="you are not authorised user";
					}
					}
						catch(Exception localException)
						{
							MDTransactionWriter.errorlog.debug(localException);
							MDTransactionWriter.errorlog.info(localException);
							status="failed in service layer";
							System.out.println(localException);
						}
						
		
				return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
		}

	public Response deleteAttendence(int attendanceId,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
			MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
				
			String status=null;
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date date = new Date();
			String startDate=dateFormat.format(date);
			Long sl=System.currentTimeMillis();
				
			try
				{	
				MDValidation mdv = new MDValidation();  
				  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
				   System.out.println("verifiedvalue::"+ret);	
				   
				   MDGetUserFromID mdgufid = new MDGetUserFromID();
				   String requester = mdgufid.getUserName(userID);
				if(ret==1 ){//&& rtVal==1){
				AttendenceDao dao= new AttendenceDao ();
				status=dao.deleteAttendence(attendanceId, schoolId,branchId);
				
				String endDate=dateFormat.format(new Date());	
				Long el=System.currentTimeMillis();
				//status="user validation successfull";
				MDTransactionWriter.writeLog(datastoreName,"AttendenceServiceImpl_deleteAttendence",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
				}else
				{
					status="you are not authorised user";
				}
			}
			
			catch(Exception localException)
			{
				MDTransactionWriter.errorlog.debug(localException);
				MDTransactionWriter.errorlog.info(localException);
				status="failed in service layer";
			}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
		}
	public Response updateAttendence(AttendencePojo attendencePojo,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
			MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
			String status=null;
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date date = new Date();
			String startDate=dateFormat.format(date);
			Long sl=System.currentTimeMillis();
			attendencePojo.setSchoolId(schoolId);
			attendencePojo.setBranchId(branchId);
			try
			{	
				MDValidation mdv = new MDValidation();  
				  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
				   System.out.println("verifiedvalue::"+ret);
				   MDGetUserFromID mdgufid = new MDGetUserFromID();
				   String requester = mdgufid.getUserName(userID);
			if(ret==1 ){
				AttendenceDao dao= new AttendenceDao ();
				status=dao.updateAttendence(attendencePojo, schoolId,branchId);
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				//status="user validation successfull";
				MDTransactionWriter.writeLog(datastoreName,"AttendenceServiceImpl_updateAttendence",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
				}else
				{
					status="you are not authorised user";
				}
			}
			  	catch(Exception localException)
				{
				  MDTransactionWriter.errorlog.debug(localException);
				  MDTransactionWriter.errorlog.info(localException);
				  status="failed in service layer";
			   }
	    return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
		}
		

	public Response getAllAttendence(int userID, int connectionID,String datastoreName,int PNO,int size,int schoolId,int branchId,int classId,int sectionId,String AttendenceDate) {
			MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
			String status=null;
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date date = new Date();
			String startDate=dateFormat.format(date);
			Long sl=System.currentTimeMillis();
			try{
				MDValidation mdv = new MDValidation();  
				  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
				   System.out.println("verifiedvalue::"+ret);	
				   MDGetUserFromID mdgufid = new MDGetUserFromID();
				   String requester = mdgufid.getUserName(userID);
				   
				if(ret==1 ){
				AttendenceDao dao= new AttendenceDao ();
				status=dao.getAllAttendence(PNO,size,schoolId,branchId,classId,sectionId,AttendenceDate);
				System.out.println(status);
				String endDate=dateFormat.format(new Date());
				  Long el=System.currentTimeMillis();
				 MDTransactionWriter.writeLog(datastoreName,"AttendenceServiceImpl_getAllAttendence",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
				}else
				{
					status="you are not authorised user";
				}
			}catch(Exception localException)
			   {
				  MDTransactionWriter.errorlog.debug(localException);
				  MDTransactionWriter.errorlog.info(localException);
				  status="failed in service layer";
			   }
			return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
		}

	public Response getByIdAttendence(int attendanceId,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
			MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
			
			String status=null;
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date date = new Date();
			String startDate=dateFormat.format(date);
			Long sl=System.currentTimeMillis();
			try
		{
				MDValidation mdv = new MDValidation();  
				  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
				   System.out.println("verifiedvalue::"+ret);	
				   MDGetUserFromID mdgufid = new MDGetUserFromID();
				   String requester = mdgufid.getUserName(userID);
				   
				   if(ret==1 ){
					   AttendenceDao dao= new AttendenceDao();
					   status=dao.getByIdAttendence(attendanceId,schoolId,branchId);
					   System.out.println(status);
					   String endDate=dateFormat.format(new Date());
					   Long el=System.currentTimeMillis();
					   MDTransactionWriter.writeLog(datastoreName,"AttendenceServiceImpl_getByIdAttendence",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
				   }else
				   {
					   status="you are not authorised user";
				   }
			}
			catch(Exception localException)
			{
				MDTransactionWriter.errorlog.debug(localException);
				MDTransactionWriter.errorlog.info(localException);
				status="failed in service layer";
			}
			return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
		}
}

	