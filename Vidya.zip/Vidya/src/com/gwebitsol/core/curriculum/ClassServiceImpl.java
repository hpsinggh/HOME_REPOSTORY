package com.gwebitsol.core.curriculum;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import com.gwebitsol.core.security.MDValidation;
import com.gwebitsol.core.usermanagement.MDGetUserFromID;
import com.gwebitsol.core.util.MDTransactionWriter;

public class ClassServiceImpl implements ClassServiceInf{

	@Context 
	private HttpServletRequest hsr;

	public Response addClass(ClassPojo classPojo,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
					MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
					String status=null;
					DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					Date date = new Date();
					String startDate=dateFormat.format(date);
					Long sl=System.currentTimeMillis();
					classPojo.setSchoolId(schoolId);
					classPojo.setBranchId(branchId);
						try
							{
							MDValidation mdv = new MDValidation();  
							  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
							   System.out.println("verifiedvalue::"+ret);
							   MDGetUserFromID mdgufid = new MDGetUserFromID();
							   String requester = mdgufid.getUserName(userID);
							   
							if(ret==1 )//&& rtVal==1)
							{
							 ClassDao dao=new ClassDao();
								status=dao.addClass(classPojo);
								String endDate=dateFormat.format(new Date());
								Long el=System.currentTimeMillis();
								MDTransactionWriter.writeLog(datastoreName,"ClassServiceImpl_addClass",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
							
							}else
							{
								status="you are not authorised user";
							}
							}
								catch(Exception localException)
								{
									MDTransactionWriter.errorlog.debug(localException);
									MDTransactionWriter.errorlog.info(localException);
									status="failed in service layer";
									System.out.println(localException);
								}
				
						return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
				}
	
	
	public Response deleteClass(int classId,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		
		try
	{	
			MDValidation mdv = new MDValidation();  
			  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			   System.out.println("verifiedvalue::"+ret);
			   
			   MDGetUserFromID mdgufid = new MDGetUserFromID();
			   String requester = mdgufid.getUserName(userID);
			if(ret==1 )//&& rtVal==1)
			{
			 ClassDao dao=new ClassDao();
				status=dao.deleteClass(classId,schoolId,branchId);
		
		String endDate=dateFormat.format(new Date());	
		Long el=System.currentTimeMillis();
		//status="user validation successfull";
			MDTransactionWriter.writeLog(datastoreName,"ClassServiceImpl_deleteClass",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
	}else
	{
		status="you are not authorised user";
	}
	}
	catch(Exception localException)
	{
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
		status="failed in service layer";
	}
return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();	
}
	public Response updateClass(ClassPojo classPojo,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		classPojo.setSchoolId(schoolId);
		classPojo.setBranchId(branchId);
		try
		{	
			MDValidation mdv = new MDValidation();  
			  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			   System.out.println("verifiedvalue::"+ret);
			   
			   MDGetUserFromID mdgufid = new MDGetUserFromID();
			   String requester = mdgufid.getUserName(userID);
		if(ret==1 )//&& rtVal==1)
		{
			ClassDao dao=new ClassDao();
			status=dao.updateClass(classPojo,schoolId,branchId);
		  String endDate=dateFormat.format(new Date());
		  Long el=System.currentTimeMillis();
		  //status="user validation successfull";
		  MDTransactionWriter.writeLog(datastoreName,"ClassServiceImpl_updateClass",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
		}else
		{
			status="you are not authorised user";
		}
		}
		  catch(Exception localException)
		   {
			  MDTransactionWriter.errorlog.debug(localException);
			  MDTransactionWriter.errorlog.info(localException);
			  status="failed in service layer";
		   }
    return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}
	
	
	public Response getAllClasses(int userID, int connectionID,String datastoreName,int PNO, int size,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		
		
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try{
			MDValidation mdv = new MDValidation();  
			  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			   System.out.println("verifiedvalue::"+ret);
			   
			   MDGetUserFromID mdgufid = new MDGetUserFromID();
			   String requester = mdgufid.getUserName(userID);
		if(ret==1 )//&& rtVal==1)
		{
			ClassDao dao=new ClassDao();
			status=dao.getAllClasses( PNO,size,schoolId,branchId);
			System.out.println(status);
			String endDate=dateFormat.format(new Date());
			  Long el=System.currentTimeMillis();
			 MDTransactionWriter.writeLog(datastoreName,"ClassServiceImpl_getAllClasses",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
		}else
		{
			status="you are not authorised user";
		}
		}catch(Exception localException)
		   {
			  MDTransactionWriter.errorlog.debug(localException);
			  MDTransactionWriter.errorlog.info(localException);
			  status="failed in service layer";
		   }
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}
	
	

	public Response getByIdClass(int classId,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
			MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
			String status=null;
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date date = new Date();
			String startDate=dateFormat.format(date);
			Long sl=System.currentTimeMillis();
			try
				{	
				MDValidation mdv = new MDValidation();  
				  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
				   System.out.println("verifiedvalue::"+ret);
				   
				   MDGetUserFromID mdgufid = new MDGetUserFromID();
				   String requester = mdgufid.getUserName(userID);
				if(ret==1 ){//&& rtVal==1){
					ClassDao dao=new ClassDao();
				   status=dao.getByIdClass(classId,schoolId,branchId);
				 System.out.println(status);
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				//status1="user validation successfull";
				MDTransactionWriter.writeLog(datastoreName,"ClassServiceImpl_getByIdClass",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
		}else
		{
			status="you are not authorised user";
		}
	}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			status="failed in service layer";
			//System.out.println(localException);
		  }
	 return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
		}

}
