package com.gwebitsol.core.curriculum;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

@Path("/period")
public interface PeriodServiceInf {
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/add")
    public Response addPeriod(PeriodPojo periodPojo,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);
	
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/update")
	public Response updatePeriod(PeriodPojo periodPojo,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);
	
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/delete") 
	public Response deletePeriod(@QueryParam("periodId") int  periodId,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);
	
	@GET
	@Consumes({"application/xml", "application/json"})
	@Produces({"application/xml", "application/json"})
	@Path("/getbyid")
	public Response getByIdPeriod(@QueryParam("periodId") int periodId,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);
	
	@GET
	@Consumes({"application/xml", "application/json"})
	@Produces({"application/xml", "application/json"})
	@Path("/getall")
	public Response getAllPeriod(@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("PNO") int PNO,@QueryParam("size") int size,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId,@QueryParam("classId") int classId,@QueryParam("sectionId") int sectionId,@QueryParam("weekDay") String weekDay,@QueryParam("periodNo") int periodNo);
	@GET
	@Consumes({"application/xml", "application/json"})
	@Produces({"application/xml", "application/json"})
	@Path("/getperiodbydays")
	public Response getPeriodByDays(@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/sectionperiods")
    public Response addSectionPeriods(SectionPeriod sectionPeriod,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);
	}



