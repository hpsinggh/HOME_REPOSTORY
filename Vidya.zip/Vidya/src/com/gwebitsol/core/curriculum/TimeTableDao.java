package com.gwebitsol.core.curriculum;

import java.util.Iterator;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class TimeTableDao {
	
	public String addTimeTable(TimeTablePojo per) {
		Session addempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction addempTx=null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			addempTx=addempSession.beginTransaction();
	        Integer in=(Integer)addempSession.save(per);
			System.out.println(in);
			addempTx.commit();
			sb.append("<TimeTable>");
			sb.append("\n");
			sb.append("<TimeTableId>");
			sb.append(in);
			sb.append("</TimeTableId>");
			sb.append("</TimeTable>");
			String str=sb.toString();
			return str;
   		 	}
		
		catch(Exception localException)
		{
			System.out.println(localException);
			localException.printStackTrace();
			sb.append("<Response>");
			   sb.append("\n");
			   sb.append("<Result>");
			   sb.append("\n");
			   sb.append("Fail");
			   sb.append("\n");
			   sb.append("</Result>");
			   sb.append("\n");
			   sb.append("<Description>");
			   sb.append("could not inserted timetable info");
			   sb.append("</Description>");
			   sb.append("\n");
			   sb.append("<Exception>");
			   sb.append(localException);
			   sb.append("</Exception>");
			   sb.append("</Response>");
			   outStr=sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (addempTx!=null)
				  addempTx.rollback();
			  } finally {
				  addempSession.close(); 
			  }
			  return outStr;
			 }

	public String updateTimeTable(TimeTablePojo per,int schoolId,int branchId) {
		Session upempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction upempTx=null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			upempTx=upempSession.beginTransaction();
			 /*upempSession.update(per);
				upempTx.commit();*/
			TimeTablePojo tt = (TimeTablePojo) upempSession.get(TimeTablePojo.class,per.getTimeTableId());
			upempSession.evict(tt);
			   if(schoolId==tt.getSchoolId()&&branchId==tt.getBranchId())
				   upempSession.update(per);		     
			   upempTx.commit();
				sb.append("<TimeTable>");
				sb.append("update successfully");
				sb.append("</TimeTable>");
				String str=sb.toString();
				return str;
			   
	   		 	}
			
			catch(Exception localException)
			{System.out.println(localException);
			localException.printStackTrace();
			sb.append("<Response>");
			   sb.append("\n");
			   sb.append("<Result>");
			   sb.append("\n");
			   sb.append("Fail");
			   sb.append("\n");
			   sb.append("</Result>");
			   sb.append("\n");
			   sb.append("<Description>");
			   sb.append("could not update timetable item");
			   sb.append("</Description>");
			   sb.append("\n");
			   sb.append("<Exception>");
			   sb.append(localException);
			   sb.append("</Exception>");
			   sb.append("</Response>");
			   outStr=sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (upempTx!=null)
				  upempTx.rollback();
			  } finally {
				  upempSession.close(); 
			  }
			  return outStr;
			 }
	

	public String deleteTimeTable(int timeTableId,int schoolId,int branchId) {
		Session delempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction delempTx=null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			delempTx=delempSession.beginTransaction();
			/*TimeTablePojo brp=new TimeTablePojo();
			brp.setTimeTableId(timeTableId);
			delempSession.delete(brp);
			delempTx.commit();*/
			delempTx = delempSession.beginTransaction();
			TimeTablePojo diarytable = (TimeTablePojo) delempSession.get(TimeTablePojo.class,timeTableId);					   
			delempSession.evict(diarytable);
			   if(schoolId==diarytable.getSchoolId()&&branchId==diarytable.getBranchId())
			   {
			   Query empQuery=delempSession.createSQLQuery("update gbl_sm_tbl_timetable set isDeleted='y' where timeTableId='"+timeTableId+"'");
			   empQuery.executeUpdate();
			   delempTx.commit();
				sb.append("<TimeTable>");
				sb.append("delete successfully");
				sb.append("</TimeTable>");
				String str=sb.toString();
				return str;
			   }else{
				   outStr = " TimeTable is not deleted";
				   sb.append("<TimeTable>");
				   sb.append(outStr);
				   sb.append("</TimeTable>");
				    String str = sb.toString();
				    return str;
				   }
		}
			catch(Exception localException)
			{
				System.out.println(localException);
				localException.printStackTrace();
				sb.append("<Response>");
				   sb.append("\n");
				   sb.append("<Result>");
				   sb.append("\n");
				   sb.append("Fail");
				   sb.append("\n");
				   sb.append("</Result>");
				   sb.append("\n");
				   sb.append("<Description>");
				   sb.append("could not delete timetable item");
				   sb.append("</Description>");
				   sb.append("\n");
				   sb.append("<Exception>");
				   sb.append(localException);
				   sb.append("</Exception>");
				   sb.append("</Response>");
				   outStr=sb.toString();
				   MDTransactionWriter.exceptionlog.info(localException);
				  if (delempTx!=null)
					  delempTx.rollback();
				  } finally {
					  delempSession.close(); 
				  }
				  return outStr;
				 }

	@SuppressWarnings("rawtypes")
	public String getByIdTimeTable(int timeTableId,int schoolId,int branchId) {
		Session addempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction addempTx=null;
		StringBuffer sb=new StringBuffer();
		String strg= null;
			try {
				addempTx = addempSession.beginTransaction();
				Query query=addempSession.createSQLQuery("SELECT tt.TimeTableId,tt.ClassId,cls.ClassName,tt.SectionId,sec.SectionName,tt.TimeTableTitle,tt.Sharable,"
			     		+ "tt.Description,tt.Remarks,tt.CreatedDate,tt.ModifiedDate,tt.SchoolId,tt.BranchId FROM gbl_sm_tbl_timetable as tt "
			     		+ "join gbl_sm_tbl_section as sec on sec.SectionId=tt.SectionId"
			     		+ " join gbl_sm_tbl_class as cls on cls.ClassId= tt.ClassId where (tt.isDeleted<>'y' or tt.isDeleted is null) and TimeTableId='"+timeTableId+"' "
			     				+ "and tt.schoolId='"+schoolId+"' and tt.branchId='"+branchId+"'");
			    List gcList=query.list();
			    Iterator gsIT=gcList.iterator();
			     while(gsIT.hasNext())
			     {
			      Object[] mdcArr=(Object[])gsIT.next();
			  
			      sb.append("<timetable>");
			      sb.append("\n");
			      sb.append("<timeTableId>"+mdcArr[0]+"</timeTableId>");
			      sb.append("\n");
			      sb.append("<classId>" + mdcArr[1]+ "</classId>");
			      sb.append("\n");
			      sb.append("<className>" + mdcArr[2]+ "</className>");
			      sb.append("\n");
			      sb.append("<sectionId>" + mdcArr[3] + "</sectionId>");
			      sb.append("\n");
			      sb.append("<sectionName>" + mdcArr[4]+ "</sectionName>");
			      sb.append("\n");
			      sb.append("<timeTableTitle>" + mdcArr[5] + "</timeTableTitle>");
			      sb.append("\n");
			      sb.append("<sharable>" +  mdcArr[6]+ "</sharable>");
			      sb.append("\n");
			      sb.append("<description>" +  mdcArr[7]+ "</description>");
			      sb.append("\n");
			      sb.append("<remarks>" + mdcArr[8] + "</remarks>");
			      sb.append("\n");
			      sb.append("<createdDate>" + mdcArr[9] + "</createdDate>");
			      sb.append("\n");
			      sb.append("<modifiedDate>" + mdcArr[10] + "</modifiedDate>");
			      sb.append("\n");
			      sb.append("<schoolId>" + mdcArr[11] + "</schoolId>");
			      sb.append("\n");
			      sb.append("<branchId>" + mdcArr[12] + "</branchId>");
			      sb.append("\n");
			      sb.append("</timetable>");
					String str= sb.toString();
					return str;
			}
					
			} 	catch (Exception localException) {
				System.out.println(localException);
				localException.printStackTrace();
				sb.append("<Response>");
				   sb.append("\n");
				   sb.append("<Result>");
				   sb.append("\n");
				   sb.append("Fail");
				   sb.append("\n");
				   sb.append("</Result>");
				   sb.append("\n");
				   sb.append("<Description>");
				   sb.append("could not getby timetable single item");
				   sb.append("</Description>");
				   sb.append("\n");
				   sb.append("<Exception>");
				   sb.append(localException);
				   sb.append("</Exception>");
				   sb.append("</Response>");
				   strg=sb.toString();
				   MDTransactionWriter.exceptionlog.info(localException);
				  if (addempTx!=null)
					  addempTx.rollback();
				  } finally {
					  addempSession.close(); 
				  }
				  return strg;
				 }

	@SuppressWarnings("rawtypes")
	public String getAllTimeTable(int PNO, int size, int schoolId,int branchId) {
			  String xmlString=null;
			  Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
			  Transaction stgTx=null;
			  StringBuffer sb = new StringBuffer();
			  try
			  {
			   stgTx=stgSession.beginTransaction();
			    int fset = (PNO-1)*size;
			    String gsSql ="select count(*) from gbl_sm_tbl_timetable where (isDeleted<>'y' or isDeleted is	null) and schoolId='"+schoolId+"' and branchId='"+branchId+"' ";
			    Query gsQuery=stgSession.createSQLQuery(gsSql);
			    Object noRecords= gsQuery.uniqueResult();
			    sb.append("<timetables>");
			    sb.append("\n");
			    sb.append("<noRecords>"+noRecords+"</noRecords>");
			    sb.append("\n");
			    
			     if (PNO > 0 & size > 0){
			     gsSql="SELECT tt.TimeTableId,tt.ClassId,cls.ClassName,tt.SectionId,sec.SectionName,tt.TimeTableTitle,tt.Sharable,"
			     		+ "tt.Description,tt.Remarks,tt.CreatedDate,tt.ModifiedDate,tt.SchoolId,tt.BranchId FROM gbl_sm_tbl_timetable as tt "
			     		+ "join gbl_sm_tbl_section as sec on sec.SectionId=tt.SectionId"
			     		+ " join gbl_sm_tbl_class as cls on cls.ClassId= tt.ClassId where (tt.isDeleted<>'y' or tt.isDeleted is null)  "
			     				+ "and tt.schoolId='"+schoolId+"' and tt.branchId='"+branchId+"' limit "+size+" offset "+fset;
			     }
			     else {
			      gsSql="SELECT tt.TimeTableId,tt.ClassId,cls.ClassName,tt.SectionId,sec.SectionName,tt.TimeTableTitle,tt.Sharable,"
			     		+ "tt.Description,tt.Remarks,tt.CreatedDate,tt.ModifiedDate,tt.SchoolId,tt.BranchId FROM gbl_sm_tbl_timetable as tt "
			     		+ "join gbl_sm_tbl_section as sec on sec.SectionId=tt.SectionId"
			     		+ " join gbl_sm_tbl_class as cls on cls.ClassId= tt.ClassId where (tt.isDeleted<>'y' or tt.isDeleted is null)  "
			     				+ "and tt.schoolId='"+schoolId+"' and tt.branchId='"+branchId+"'";
			     } 
			    
			    gsQuery=stgSession.createSQLQuery(gsSql);
			    List gcList=gsQuery.list();
			    Iterator gsIT=gcList.iterator();
			     while(gsIT.hasNext())
			     {
			      Object[] mdcArr=(Object[])gsIT.next();
			      sb.append("<timetable>");
			      sb.append("\n");
			      sb.append("<timeTableId>"+mdcArr[0]+"</timeTableId>");
			      sb.append("\n");
			      sb.append("<classId>" + mdcArr[1]+ "</classId>");
			      sb.append("\n");
			      sb.append("<className>" + mdcArr[2]+ "</className>");
			      sb.append("\n");
			      sb.append("<sectionId>" + mdcArr[3] + "</sectionId>");
			      sb.append("\n");
			      sb.append("<sectionName>" + mdcArr[4]+ "</sectionName>");
			      sb.append("\n");
			      sb.append("<timeTableTitle>" + mdcArr[5] + "</timeTableTitle>");
			      sb.append("\n");
			      sb.append("<sharable>" +  mdcArr[6]+ "</sharable>");
			      sb.append("\n");
			      sb.append("<description>" +  mdcArr[7]+ "</description>");
			      sb.append("\n");
			      sb.append("<remarks>" + mdcArr[8] + "</remarks>");
			      sb.append("\n");
			      sb.append("<createdDate>" + mdcArr[9] + "</createdDate>");
			      sb.append("\n");
			      sb.append("<modifiedDate>" + mdcArr[10] + "</modifiedDate>");
			      sb.append("\n");
			      sb.append("<schoolId>" + mdcArr[11] + "</schoolId>");
			      sb.append("\n");
			      sb.append("<branchId>" + mdcArr[12] + "</branchId>");
			      sb.append("\n");
			      sb.append("</timetable>");
			     }
			    
			    stgTx.commit();
			    sb.append("</timetables>");
			    sb.append("\n");

			    xmlString=sb.toString();
			   }  
		catch(Exception localException)
		{
			localException.printStackTrace();
			sb.append("<Response>");
			   sb.append("\n");
			   sb.append("<Result>");
			   sb.append("\n");
			   sb.append("Fail");
			   sb.append("\n");
			   sb.append("</Result>");
			   sb.append("\n");
			   sb.append("<Description>");
			   sb.append("could not getall timetable info");
			   sb.append("</Description>");
			   sb.append("\n");
			   sb.append("<Exception>");
			   sb.append(localException);
			   sb.append("</Exception>");
			   sb.append("</Response>");
			   xmlString=sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (stgTx!=null)
				  stgTx.rollback();
			  } finally {
				  stgSession.close(); 
			  }
			  return xmlString;
			 }
}
