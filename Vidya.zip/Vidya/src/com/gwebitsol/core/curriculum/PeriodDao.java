
package com.gwebitsol.core.curriculum;

import java.util.Iterator;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class PeriodDao {
	
	public String addPeriod(PeriodPojo periodPojo) {
		Session rdSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx=null;
		StringBuffer sb=new StringBuffer();
		String strg=null;
		try
		{
			tx=rdSession.beginTransaction();
			String str=periodPojo.getDays();
			str.split(":",7);
			System.out.println(str);			
	        Integer in=(Integer)rdSession.save(periodPojo);
			System.out.println(in);
			tx.commit();
			sb.append("<Period>");
			sb.append("\n");
			sb.append("<PeriodId>");
			sb.append(in);
			sb.append("</PeriodId>");
			sb.append("</Period>");
			strg=sb.toString();	
		   }
		catch(Exception localException)
		{
			System.out.println(localException);
			localException.printStackTrace();
		   sb.append("<Response>");
		   sb.append("\n");
		   sb.append("<Result>");
		   sb.append("\n");
		   sb.append("Fail");
		   sb.append("\n");
		   sb.append("</Result>");
		   sb.append("\n");
		   sb.append("<Description>");
		   sb.append("could not inserted Period info");
		   sb.append("</Description>");
		   sb.append("\n");
		   sb.append("<Exception>");
		   sb.append(localException);
		   sb.append("</Exception>");
		   sb.append("</Response>");
		    strg=sb.toString();
		   MDTransactionWriter.exceptionlog.info(localException);
		  if (tx!=null)
			  tx.rollback();
		  } finally {
		   rdSession.close(); 
		  }
		  return strg;
		 }

	public String updatePeriod(PeriodPojo periodPojo,int schoolId,int branchId) {
		Session rdSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx=null;
		StringBuffer sb=new StringBuffer();
		String strg=null;
		try
		{
			tx=rdSession.beginTransaction();
			 /*rdSession.update(periodPojo);
			 tx.commit();*/
			PeriodPojo pp = (PeriodPojo) rdSession.get(PeriodPojo.class,periodPojo.getPeriodId());
			rdSession.evict(pp);
			   if(schoolId==pp.getSchoolId()&&branchId==pp.getBranchId())
			   rdSession.update(periodPojo);
			     
			   tx.commit();
				sb.append("<Period>");
				sb.append("update successfully");
				sb.append("</Period>");
				 strg=sb.toString();
				 }
			catch(Exception localException)
			{
				System.out.println(localException);
				localException.printStackTrace();
				   sb.append("<Response>");
				   sb.append("\n");
				   sb.append("<Result>");
				   sb.append("\n");
				   sb.append("Fail");
				   sb.append("\n");
				   sb.append("</Result>");
				   sb.append("\n");
				   sb.append("<Description>");
				   sb.append("could not updateperiod info");
				   sb.append("</Description>");
				   sb.append("\n");
				   sb.append("<Exception>");
				   sb.append(localException);
				   sb.append("</Exception>");
				   sb.append("</Response>");
				    strg=sb.toString();
				   MDTransactionWriter.exceptionlog.info(localException);
				  if (tx!=null)
				   tx.rollback();
				  } finally {
				   rdSession.close(); 
				  }
				  return strg;
				 }

	public String deletePeriod(int periodId,int schoolId,int branchId) {
		Session rdSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx=null;
		StringBuffer sb=new StringBuffer();
		String strg=null;
		try
		{
			tx=rdSession.beginTransaction();
			/*periodPojo brp=new PeriodPojo();
			brp.setPeriodId(periodId);
			rdSession.delete(brp);
				tx.commit();*/
			PeriodPojo pp = (PeriodPojo) rdSession.get(PeriodPojo.class,periodId);					   
			   rdSession.evict(pp);
			   if(schoolId==pp.getSchoolId()&&branchId==pp.getBranchId())
			   {
			   Query empQuery=rdSession.createSQLQuery("update gbl_sm_tbl_period set isDeleted='y' where periodId='"+periodId+"'");
			   empQuery.executeUpdate();
			   tx.commit();
				sb.append("<Period>");
				sb.append("delete successfully");
				sb.append("</Period>");
				 strg=sb.toString();
			}
			   else{
				   strg = " Period is not deleted";
				   sb.append("<Period>");
				   sb.append("\n");
				   sb.append(strg);
				   sb.append("</Period>");
				    String str = sb.toString();
				    return str;
				   }
		}
			catch(Exception localException)
			{
				System.out.println(localException);
					localException.printStackTrace();
			   sb.append("<Response>");
			   sb.append("\n");
			   sb.append("<Result>");
			   sb.append("\n");
			   sb.append("Fail");
			   sb.append("\n");
			   sb.append("</Result>");
			   sb.append("\n");
			   sb.append("<Description>");
			   sb.append("could not deleted period info");
			   sb.append("</Description>");
			   sb.append("\n");
			   sb.append("<Exception>");
			   sb.append(localException);
			   sb.append("</Exception>");
			   sb.append("</Response>");
			    strg=sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (tx!=null)
			   tx.rollback();
			  } finally {
			   rdSession.close(); 
			  }
			  return strg;
			 }

	@SuppressWarnings("rawtypes")
	public String getByIdPeriod(int periodId,int schoolId,int branchId) {
		Session rdSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx=null;
		StringBuffer sb=new StringBuffer();
		String strg= null;
			try {
				tx = rdSession.beginTransaction();
				Query query=rdSession.createSQLQuery("SELECT period.PeriodId,period.TimeTableId,tt.TimeTableTitle,period.SubjectId,subtype.SubjectName,period.EmployeeId,staff.StaffNumber,staff.FirstName,staff.MiddleName,staff.LastName,period.SequenceNo,period.Days,period.PeriodTitle,period.StartTime,period.EndTime,period.Description,period.SchoolId,period.BranchId,tt.ClassId,cls.ClassName,tt.SectionId,sec.SectionName,period.LunchBreak FROM gbl_sm_tbl_period as period left outer join gbl_sm_tbl_timetable as tt on tt.TimeTableId=period.TimeTableId left outer join gbl_sm_tbl_staff as staff on staff.EmployeeId=period.EmployeeId left outer join gbl_sm_tbl_subjects as sub on sub.SubjectId= period.SubjectId left outer join gbl_sm_tbl_subject_type as subtype on sub.SubjectTypeId=subtype.SubjectTypeId left outer join gbl_sm_tbl_class as cls on tt.ClassId=cls.ClassId left outer join gbl_sm_tbl_section as sec on tt.SectionId=sec.SectionId where (period.isDeleted<>'y' or period.isDeleted is null) and period.PeriodId='"+periodId+"' "
								+ "and period.schoolId='"+schoolId+"'and period.branchId='"+branchId+"'");
			    List gcList=query.list();
			    Iterator gsIT=gcList.iterator();
			     while(gsIT.hasNext())
			     {
			      Object[] mdcArr=(Object[])gsIT.next();
			  
			      sb.append("<period>");
			      sb.append("\n");
			      sb.append("<periodId>"+mdcArr[0]+"</periodId>");
			      sb.append("\n");
			      sb.append("<timeTableId>" + mdcArr[1]+ "</timeTableId>");
			      sb.append("\n");
			      sb.append("<timeTableTitle>" + mdcArr[2]+ "</timeTableTitle>");
			      sb.append("\n");
			      sb.append("<subjectId>" + mdcArr[3] + "</subjectId>");
			      sb.append("\n");
			      sb.append("<subjectName>" + mdcArr[4]+ "</subjectName>");
			      sb.append("\n");
			      sb.append("<employeeId>" + mdcArr[5] + "</employeeId>");
			      sb.append("\n");
			      sb.append("<staffNumber>" +  mdcArr[6]+ "</staffNumber>");
			      sb.append("\n");
			      sb.append("<firstName>" + mdcArr[7] + "</firstName>");
			      sb.append("\n");
			      sb.append("<middleName>" + mdcArr[8] + "</middleName>");
			      sb.append("\n");
			      sb.append("<lastName>" + mdcArr[9] + "</lastName>");
			      sb.append("\n");
			      sb.append("<sequenceNo>" + mdcArr[10] + "</sequenceNo>");
			      sb.append("\n");
			      sb.append("<days>" + mdcArr[11] + "</days>");
			      sb.append("\n");
			      sb.append("<periodTitle>" + mdcArr[12] + "</periodTitle>");
			      sb.append("\n");
			      sb.append("<startTime>" + mdcArr[13] + "</startTime>");
			      sb.append("\n");
			      sb.append("<endTime>" + mdcArr[14] + "</endTime>");
			      sb.append("\n");
			      sb.append("<description>" + mdcArr[15] + "</description>");
			      sb.append("\n");
			      sb.append("<schoolId>" + mdcArr[16] + "</schoolId>");
			      sb.append("\n");
			      sb.append("<branchId>" + mdcArr[17] + "</branchId>");
			      sb.append("\n");
			      sb.append("<classId>" + mdcArr[18]+ "</classId>");
			      sb.append("\n");
			      sb.append("<className>" + mdcArr[19] + "</className>");
			      sb.append("\n");
			      sb.append("<sectionId>" + mdcArr[20]+ "</sectionId>");
			      sb.append("\n");
			      sb.append("<sectionName>" + mdcArr[21] + "</sectionName>");
			      sb.append("\n");  
			      sb.append("<lunchBreak>" + mdcArr[22]+ "</lunchBreak>");
			      sb.append("\n"); 
			      sb.append("</period>");
					String str= sb.toString();
					return str;
			}
					
			} 	catch (Exception localException) {
				System.out.println(localException);
					localException.printStackTrace();
			   sb.append("<Response>");
			   sb.append("\n");
			   sb.append("<Result>");
			   sb.append("\n");
			   sb.append("Fail");
			   sb.append("\n");
			   sb.append("</Result>");
			   sb.append("\n");
			   sb.append("<Description>");
			   sb.append("could not get by single period ");
			   sb.append("</Description>");
			   sb.append("\n");
			   sb.append("<Exception>");
			   sb.append(localException);
			   sb.append("</Exception>");
			   sb.append("</Response>");
			    strg=sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (tx!=null)
			   tx.rollback();
			  } finally {
			   rdSession.close(); 
			  }
			  return strg;
			 }

	@SuppressWarnings("rawtypes")
	public String getAllPeriods(int PNO, int size,int schoolId,int branchId,int classId,int sectionId,String weekDay,int periodNo) {
			  String xmlString=null;
			  Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
			  Transaction stgTx=null;
			  StringBuffer sb = new StringBuffer();
			  try
			  {
			   stgTx=stgSession.beginTransaction();
			    int fset = (PNO-1)*size;
			    
			    String filterWhere="";
			    if(classId!=0){
			    	filterWhere+=" and tt.ClassId="+classId;	
			    	if(sectionId!=0){
						filterWhere +=  " and tt.SectionId="+sectionId;
			    	}
			    }
			    if(weekDay != null){
			    	filterWhere+=" and period.Days in('"+weekDay+"')";	
			    }
			    if(periodNo != 0){
			    	filterWhere+=" and period.SequenceNo= "+ periodNo;	
			    }
			    String gsSql ="SELECT count(*) FROM gbl_sm_tbl_period as period left outer join gbl_sm_tbl_timetable as tt on tt.TimeTableId=period.TimeTableId left outer join gbl_sm_tbl_staff as staff on staff.EmployeeId=period.EmployeeId left outer join gbl_sm_tbl_subjects as sub on sub.SubjectId= period.SubjectId left outer join gbl_sm_tbl_subject_type as subtype on sub.SubjectTypeId=subtype.SubjectTypeId left outer join gbl_sm_tbl_class as cls on tt.ClassId=cls.ClassId left outer join gbl_sm_tbl_section as sec on tt.SectionId=sec.SectionId where (period.isDeleted<>'y' or period.isDeleted is null) and period.schoolId='"+schoolId+"' and period.branchId='"+branchId+"'"+filterWhere+" ";
			    Query gsQuery=stgSession.createSQLQuery(gsSql);
			    Object noRecords= gsQuery.uniqueResult();
			    sb.append("<periods>");
			    sb.append("\n");
			    sb.append("<noRecords>"+noRecords+"</noRecords>");
			    sb.append("\n");
			    
			     if (PNO > 0 & size > 0){
			     gsSql="SELECT period.PeriodId,period.TimeTableId,tt.TimeTableTitle,period.SubjectId,subtype.SubjectName,period.EmployeeId,staff.StaffNumber,staff.FirstName,staff.MiddleName,staff.LastName,period.SequenceNo,period.Days,period.PeriodTitle,period.StartTime,period.EndTime,period.Description,period.SchoolId,period.BranchId,tt.ClassId,cls.ClassName,tt.SectionId,sec.SectionName,period.LunchBreak FROM gbl_sm_tbl_period as period left outer join gbl_sm_tbl_timetable as tt on tt.TimeTableId=period.TimeTableId left outer join gbl_sm_tbl_staff as staff on staff.EmployeeId=period.EmployeeId left outer join gbl_sm_tbl_subjects as sub on sub.SubjectId= period.SubjectId left outer join gbl_sm_tbl_subject_type as subtype on sub.SubjectTypeId=subtype.SubjectTypeId left outer join gbl_sm_tbl_class as cls on tt.ClassId=cls.ClassId left outer join gbl_sm_tbl_section as sec on tt.SectionId=sec.SectionId where (period.isDeleted<>'y' or period.isDeleted is null) and period.schoolId='"+schoolId+"'and period.branchId='"+branchId+"'"+filterWhere+" limit "+size+" offset "+fset;
			     }
			     else {
			      gsSql="SELECT period.PeriodId,period.TimeTableId,tt.TimeTableTitle,period.SubjectId,subtype.SubjectName,period.EmployeeId,staff.StaffNumber,staff.FirstName,staff.MiddleName,staff.LastName,period.SequenceNo,period.Days,period.PeriodTitle,period.StartTime,period.EndTime,period.Description,period.SchoolId,period.BranchId,tt.ClassId,cls.ClassName,tt.SectionId,sec.SectionName,period.LunchBreak FROM gbl_sm_tbl_period as period left outer join gbl_sm_tbl_timetable as tt on tt.TimeTableId=period.TimeTableId left outer join gbl_sm_tbl_staff as staff on staff.EmployeeId=period.EmployeeId left outer join gbl_sm_tbl_subjects as sub on sub.SubjectId= period.SubjectId left outer join gbl_sm_tbl_subject_type as subtype on sub.SubjectTypeId=subtype.SubjectTypeId left outer join gbl_sm_tbl_class as cls on tt.ClassId=cls.ClassId left outer join gbl_sm_tbl_section as sec on tt.SectionId=sec.SectionId where (period.isDeleted<>'y' or period.isDeleted is null) and period.schoolId='"+schoolId+"'and period.branchId='"+branchId+"'"+filterWhere+"";
			     } 
			    
			    gsQuery=stgSession.createSQLQuery(gsSql);
			    List gcList=gsQuery.list();
			    Iterator gsIT=gcList.iterator();
			     while(gsIT.hasNext())
			     {
			      Object[] mdcArr=(Object[])gsIT.next();
			      sb.append("<period>");
			      sb.append("\n");
			      sb.append("<periodId>"+mdcArr[0]+"</periodId>");
			      sb.append("\n");
			      sb.append("<timeTableId>" + mdcArr[1]+ "</timeTableId>");
			      sb.append("\n");
			      sb.append("<timeTableTitle>" + mdcArr[2]+ "</timeTableTitle>");
			      sb.append("\n");
			      sb.append("<subjectId>" + mdcArr[3] + "</subjectId>");
			      sb.append("\n");
			      sb.append("<subjectName>" + mdcArr[4]+ "</subjectName>");
			      sb.append("\n");
			      sb.append("<employeeId>" + mdcArr[5] + "</employeeId>");
			      sb.append("\n");
			      sb.append("<staffNumber>" +  mdcArr[6]+ "</staffNumber>");
			      sb.append("\n");
			      sb.append("<firstName>" + mdcArr[7] + "</firstName>");
			      sb.append("\n");
			      sb.append("<middleName>" + mdcArr[8] + "</middleName>");
			      sb.append("\n");
			      sb.append("<lastName>" + mdcArr[9] + "</lastName>");
			      sb.append("\n");
			      sb.append("<sequenceNo>" + mdcArr[10] + "</sequenceNo>");
			      sb.append("\n");
			      sb.append("<days>" + mdcArr[11] + "</days>");
			      sb.append("\n");
			      sb.append("<periodTitle>" + mdcArr[12] + "</periodTitle>");
			      sb.append("\n");
			      sb.append("<startTime>" + mdcArr[13] + "</startTime>");
			      sb.append("\n");
			      sb.append("<endTime>" + mdcArr[14] + "</endTime>");
			      sb.append("\n");
			      sb.append("<description>" + mdcArr[15] + "</description>");
			      sb.append("\n");
			      sb.append("<schoolId>" + mdcArr[16] + "</schoolId>");
			      sb.append("\n");
			      sb.append("<branchId>" + mdcArr[17] + "</branchId>");
			      sb.append("\n");
			      sb.append("<classId>" + mdcArr[18]+ "</classId>");
			      sb.append("\n");
			      sb.append("<className>" + mdcArr[19] + "</className>");
			      sb.append("\n");
			      sb.append("<sectionId>" + mdcArr[20]+ "</sectionId>");
			      sb.append("\n");
			      sb.append("<sectionName>" + mdcArr[21] + "</sectionName>");
			      sb.append("\n");  
			      sb.append("<lunchBreak>" + mdcArr[22]+ "</lunchBreak>");
			      sb.append("\n");
			      sb.append("</period>");
			     }
			    
			    stgTx.commit();
			    sb.append("</periods>");
			    sb.append("\n");
			    xmlString=sb.toString();
			   }
			    catch(Exception localException)
				{
					System.out.println(localException);
					localException.printStackTrace();
					   sb.append("<Response>");
					   sb.append("\n");
					   sb.append("<Result>");
					   sb.append("\n");
					   sb.append("Fail");
					   sb.append("\n");
					   sb.append("</Result>");
					   sb.append("\n");
					   sb.append("<Description>");
					   sb.append("could not get all period info");
					   sb.append("</Description>");
					   sb.append("\n");
					   sb.append("<Exception>");
					   sb.append(localException);
					   sb.append("</Exception>");
					   sb.append("</Response>");
					   xmlString=sb.toString();
					   MDTransactionWriter.exceptionlog.info(localException);
					  if (stgTx!=null)
						  stgTx.rollback();
					  } finally {
						  stgSession.close(); 
					  }
					  return xmlString;
					 }

	@SuppressWarnings("rawtypes")
	public String getPeriodByDays(int schoolId, int branchId) {
		 String xmlString=null;
		  Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		  Transaction stgTx=null;
		  StringBuffer sb = new StringBuffer();
		  String s=null;
		  int i1=0;
		  try
		  {
		   stgTx=stgSession.beginTransaction();
		   Query query=stgSession.createSQLQuery("SELECT periodId,sequenceNo,days,periodTitle FROM gbl_sm_tbl_period  where schoolId='"+schoolId+"' and branchId='"+branchId+"'");
		   List list=query.list();
		   Iterator i=list.iterator();
		   while(i.hasNext()){
			   Object mdcArr[]=( Object[])i.next();
			  // PeriodPojo pp=new PeriodPojo();
			     sb.append("<periodId>"+mdcArr[0]+"</periodId>");
			      sb.append("\n");			     
			      sb.append("<sequenceNo>" + mdcArr[1] + "</sequenceNo>");
			      sb.append("\n");
			      sb.append("<days>" + mdcArr[2] + "</days>");
			      sb.append("\n");
			      s=(String) mdcArr[2];
			      s.split(":");
			      
			      // sequence no is int and days is itrate
			     
			      for(int i2=0;i2<s.length();i2++){
			    	  i1=(Integer) mdcArr[1];
			    	  System.out.println("<days>" +s +"</days>");
			    	  System.out.println(i1);
			      
			      }
			      
			      sb.append("<periodTitle>" + mdcArr[3] + "</periodTitle>");
		   }
		   
		  }
		   catch(Exception localException)
			{
				System.out.println(localException);
				localException.printStackTrace();
				   sb.append("<Response>");
				   sb.append("\n");
				   sb.append("<Result>");
				   sb.append("\n");
				   sb.append("Fail");
				   sb.append("\n");
				   sb.append("</Result>");
				   sb.append("\n");
				   sb.append("<Description>");
				   sb.append("could not get all period info");
				   sb.append("</Description>");
				   sb.append("\n");
				   sb.append("<Exception>");
				   sb.append(localException);
				   sb.append("</Exception>");
				   sb.append("</Response>");
				   xmlString=sb.toString();
				   MDTransactionWriter.exceptionlog.info(localException);
				  if (stgTx!=null)
					  stgTx.rollback();
				  } finally {
					  stgSession.close(); 
				  }
				  return xmlString;
	}
	public String addSectionPeriods(SectionPeriod sectionPeriod) {
		Session rdSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx=null;
		StringBuffer sb=new StringBuffer();
		String strg=null;
		try
		{
			tx=rdSession.beginTransaction();			
	        Integer in=(Integer)rdSession.save(sectionPeriod);
	        
	        //List list = rdSession.createSQLQuery("  where Days REGEXP '"+days+"')").list();
			//Iterator it=list.iterator();
			System.out.println(in);
			tx.commit();
			sb.append("<sectionPeriod>");
			sb.append("<sectionPeriodId>");
			sb.append(in);
			sb.append("</sectionPeriodId>");
			sb.append("</sectionPeriod>");
			strg=sb.toString();	
		   }
		catch(Exception localException)
		{
			System.out.println(localException);
			localException.printStackTrace();
		   sb.append("<Response>");
		   sb.append("\n");
		   sb.append("<Result>");
		   sb.append("\n");
		   sb.append("Fail");
		   sb.append("\n");
		   sb.append("</Result>");
		   sb.append("\n");
		   sb.append("<Description>");
		   sb.append("could not inserted Period info");
		   sb.append("</Description>");
		   sb.append("\n");
		   sb.append("<Exception>");
		   sb.append(localException);
		   sb.append("</Exception>");
		   sb.append("</Response>");
		    strg=sb.toString();
		   MDTransactionWriter.exceptionlog.info(localException);
		  if (tx!=null)
			  tx.rollback();
		  } finally {
		   rdSession.close(); 
		  }
		  return strg;
		 }
}

