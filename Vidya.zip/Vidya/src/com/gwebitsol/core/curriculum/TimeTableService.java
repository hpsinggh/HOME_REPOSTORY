package com.gwebitsol.core.curriculum;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import com.gwebitsol.core.security.MDValidation;
import com.gwebitsol.core.usermanagement.MDGetUserFromID;
import com.gwebitsol.core.util.MDTransactionWriter;

public class TimeTableService implements TimeTableServiceIntf {
	@Context 
	private HttpServletRequest hsr;
	
	public Response addTimeTable(TimeTablePojo per,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String XMLString=null;
	    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		per.setSchoolId(schoolId);
		per.setBranchId(branchId);
		try
		{
			MDValidation mdv = new MDValidation();  
			  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			   System.out.println("verifiedvalue::"+ret);			
			   
			   MDGetUserFromID mdgufid = new MDGetUserFromID();
			   String requester = mdgufid.getUserName(userID);
			   if(ret==1 )//&& rtVal==1)
			   {
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				
				TimeTableDao brdao=new TimeTableDao();
				XMLString=brdao.addTimeTable(per);
				
				System.out.println(XMLString);
				MDTransactionWriter.writeLog(datastoreName,"TimeTableService_addTimeTable",requester,startDate,endDate,sl,el,XMLString,hsr.getRemoteHost());
		}else
		{
			XMLString="you are not authorised user";
		}
		}
		
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
		   XMLString="failed in service layer";
		}
	
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}

	public Response updateTimeTable(TimeTablePojo per,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String XMLString=null;
	    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		per.setSchoolId(schoolId);
		per.setBranchId(branchId);
		try
		{	MDValidation mdv = new MDValidation();  
		  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
		   System.out.println("verifiedvalue::"+ret);
		   
		   MDGetUserFromID mdgufid = new MDGetUserFromID();
		   String requester = mdgufid.getUserName(userID);
		if(ret==1 )//&& rtVal==1)
		{
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				
				TimeTableDao brdao=new TimeTableDao();
				XMLString=brdao.updateTimeTable(per,schoolId,branchId);
				
				System.out.println(XMLString);
				MDTransactionWriter.writeLog(datastoreName,"TimeTableService_updateTimeTable",requester,startDate,endDate,sl,el,XMLString,hsr.getRemoteHost());
		}else
		{
			XMLString="you are not authorised user";
		}
		}
		
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
		   XMLString="failed in service layer";
		}
	
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}

	public Response deleteTimeTable(int timeTableId,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		
		try
			{	
			MDValidation mdv = new MDValidation();  
			  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			   System.out.println("verifiedvalue::"+ret);
			   
			   MDGetUserFromID mdgufid = new MDGetUserFromID();
			   String requester = mdgufid.getUserName(userID);
			if(ret==1 )//&& rtVal==1)
			{
			TimeTableDao brdao=new TimeTableDao();
		status=brdao.deleteTimeTable(timeTableId,schoolId,branchId);
		
		String endDate=dateFormat.format(new Date());	
		Long el=System.currentTimeMillis();
		
			MDTransactionWriter.writeLog(datastoreName,"TimeTableService_deleteTimeTable",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
	}else
	{
		status="you are not authorised user";
	}
	}
	catch(Exception localException)
	{
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
		status="failed in service layer";
	}
return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response getByIdTimeTable(int timeTableId,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		
		String status1=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{	
			MDValidation mdv = new MDValidation();  
			  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			   System.out.println("verifiedvalue::"+ret);
			   
			   MDGetUserFromID mdgufid = new MDGetUserFromID();
			   String requester = mdgufid.getUserName(userID);
			if(ret==1 )//&& rtVal==1)
			{
			TimeTableDao ex=new TimeTableDao();
			 status1=ex.getByIdTimeTable(timeTableId,schoolId,branchId);
			 
			 System.out.println(status1);
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			//status1="user validation successfull";
			MDTransactionWriter.writeLog(datastoreName,"TimeTableService_getByIdTimeTable",requester,startDate,endDate,sl,el,status1,hsr.getRemoteHost());		
	}else
	{
		status1="you are not authorised user";
	}
	}
	catch(Exception localException)
	{
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
		status1="failed in service layer";
		//System.out.println(localException);
	}
 return Response.ok().type(MediaType.APPLICATION_XML).entity(status1).build();
	}

	public Response getAllTimeTable(int userID, int connectionID,String datastoreName,int PNO, int size,int schoolId,int branchId) {
MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		
		
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try{	
			MDValidation mdv = new MDValidation();  
		  int ret =mdv.allvalidations(userID, connectionID, datastoreName, schoolId, branchId);
		   System.out.println("verifiedvalue::"+ret);
		   
		   MDGetUserFromID mdgufid = new MDGetUserFromID();
		   String requester = mdgufid.getUserName(userID);
		if(ret==1 )//&& rtVal==1)
		{
			TimeTableDao ex=new TimeTableDao();
			status=ex.getAllTimeTable( PNO, size, schoolId,branchId);
			
			System.out.println(status);
			String endDate=dateFormat.format(new Date());
			  Long el=System.currentTimeMillis();
			 MDTransactionWriter.writeLog(datastoreName,"TimeTableService_getAllTimeTable",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		

		}else
		{
			status="you are not authorised user";
		}
		}catch(Exception localException)
		   {
			  MDTransactionWriter.errorlog.debug(localException);
			  MDTransactionWriter.errorlog.info(localException);
			  status="failed in service layer";
		   }
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

}
