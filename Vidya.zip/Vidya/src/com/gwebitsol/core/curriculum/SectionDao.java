package com.gwebitsol.core.curriculum;

import java.util.Iterator;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class SectionDao {
	
	public String addSection(SectionPojo per) {
		Session addempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction addempTx=null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			addempTx=addempSession.beginTransaction();
	        Integer in=(Integer)addempSession.save(per);
			System.out.println(in);
			addempTx.commit();
			sb.append("<Section>");
			sb.append("\n");
			sb.append("<sectionId>");
			sb.append(in);
			sb.append("</sectionId>");
			sb.append("</Section>");
			outStr=sb.toString();
			}
		catch(Exception localException)
		{
			System.out.println(localException);
				localException.printStackTrace();
		   sb.append("<Response>");
		   sb.append("\n");
		   sb.append("<Result>");
		   sb.append("\n");
		   sb.append("Fail");
		   sb.append("\n");
		   sb.append("</Result>");
		   sb.append("\n");
		   sb.append("<Description>");
		   sb.append("could not inserted section info");
		   sb.append("</Description>");
		   sb.append("\n");
		   sb.append("<Exception>");
		   sb.append(localException);
		   sb.append("</Exception>");
		   sb.append("</Response>");
		   outStr=sb.toString();
		   MDTransactionWriter.exceptionlog.info(localException);
		  if (addempTx!=null)
			  addempTx.rollback();
		  } finally {
			  addempSession.close(); 
		  }
		  return outStr;
		 }

	public String updateSection(SectionPojo per,int schoolId,int branchId) {
		Session upempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction upempTx=null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			upempTx=upempSession.beginTransaction();
			SectionPojo sp = (SectionPojo) upempSession.get(SectionPojo.class,per.getSectionId());
			upempSession.evict(sp);
			   if(schoolId==sp.getSchoolId()&&branchId==sp.getBranchId())
				  upempSession.update(per);
			   		upempTx.commit();
				sb.append("<Section>");
				sb.append("update successfully");
				sb.append("</Section>");
				outStr=sb.toString();
			}
			catch(Exception localException)
			{
			System.out.println(localException);
				localException.printStackTrace();
		   sb.append("<Response>");
		   sb.append("\n");
		   sb.append("<Result>");
		   sb.append("\n");
		   sb.append("Fail");
		   sb.append("\n");
		   sb.append("</Result>");
		   sb.append("\n");
		   sb.append("<Description>");
		   sb.append("could not updated section info");
		   sb.append("</Description>");
		   sb.append("\n");
		   sb.append("<Exception>");
		   sb.append(localException);
		   sb.append("</Exception>");
		   sb.append("</Response>");
		   outStr=sb.toString();
		   MDTransactionWriter.exceptionlog.info(localException);
		  if (upempTx!=null)
			  upempTx.rollback();
		  } finally {
			  upempSession.close(); 
		  }
		  return outStr;
		 }

	public String deletePeriod(int sectionId,int schoolId,int branchId) {
		Session delempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction delempTx=null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			delempTx=delempSession.beginTransaction();
			
			/*SectionPojo brp=new SectionPojo();
			brp.setSectionId(sectionId);
			delempSession.delete(brp);
				delempTx.commit();*/
			SectionPojo sp = (SectionPojo) delempSession.get(SectionPojo.class,sectionId);					   
			delempSession.evict(sp);
			   if(schoolId==sp.getSchoolId()&&branchId==sp.getBranchId())
			   {
			   Query empQuery=delempSession.createSQLQuery("update gbl_sm_tbl_section set isDeleted='y' where sectionId='"+sectionId+"'");
			   empQuery.executeUpdate();
			   delempTx.commit();
				sb.append("<Section>");
				sb.append("delete successfully");
				sb.append("</Section>");
				String str=sb.toString();
				return str;
			   
	   		 	}else{
	   		 	outStr = " Section is not deleted";
					   sb.append("<Section>");
					   sb.append(outStr);
					   sb.append("</Section>");
					    String str = sb.toString();
					    return str;
					   }
		}
			catch(Exception localException)
			{

				System.out.println(localException);
					localException.printStackTrace();
			   sb.append("<Response>");
			   sb.append("\n");
			   sb.append("<Result>");
			   sb.append("\n");
			   sb.append("Fail");
			   sb.append("\n");
			   sb.append("</Result>");
			   sb.append("\n");
			   sb.append("<Description>");
			   sb.append("could not deleted section item");
			   sb.append("</Description>");
			   sb.append("\n");
			   sb.append("<Exception>");
			   sb.append(localException);
			   sb.append("</Exception>");
			   sb.append("</Response>");
			   outStr=sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (delempTx!=null)
				  delempTx.rollback();
			  } finally {
				  delempSession.close(); 
			  }
			  return outStr;
			 }

	@SuppressWarnings("rawtypes")
	public String getByIdSection(int sectionId,int schoolId,int branchId) {
		Session addempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction addempTx=null;
		StringBuffer sb=new StringBuffer();
		String strg= null;
			try {
		addempTx = addempSession.beginTransaction();
		Query query=addempSession.createSQLQuery("SELECT section.SectionId,section.ClassId,cls.ClassName,section.RoomId,room.RoomNo,room.RoomName,section.EmployeeId,staff.StaffNumber,staff.FirstName,staff.MiddleName,staff.LastName,section.CaptainId,section.NoOfStudents,section.SectionName,section.Description,section.Remarks,section.CreatedDate,section.ModifiedDate,section.SchoolId,section.BranchId FROM gbl_sm_tbl_section as section join gbl_sm_tbl_room as room on room.RoomId=section.RoomId  join gbl_sm_tbl_class as cls on cls.ClassId= section.ClassId left outer join gbl_sm_tbl_staff as staff  on section.EmployeeId=staff.EmployeeId where (section.isDeleted<>'y' or  section.isDeleted is null) and section.SectionId='"+sectionId+"'and section.schoolId='"+schoolId+"' and section.branchId='"+branchId+"'");
	    List gcList=query.list();
	    Iterator gsIT=gcList.iterator();
	     while(gsIT.hasNext())
	     {
	      Object[] mdcArr=(Object[])gsIT.next();
	      sb.append("<section>");
	      sb.append("<sectionId>"+mdcArr[0]+"</sectionId>");
	      sb.append("\n");
	      sb.append("<classId>" + mdcArr[1]+ "</classId>");
	      sb.append("\n");
	      sb.append("<className>" + mdcArr[2]+ "</className>");
	      sb.append("\n");
	      sb.append("<roomId>" + mdcArr[3] + "</roomId>");
	      sb.append("\n");
	      sb.append("<roomNo>" + mdcArr[4]+ "</roomNo>");
	      sb.append("\n");
	      sb.append("<roomName>" + mdcArr[5] + "</roomName>");
	      sb.append("\n");
	      sb.append("<employeeId>" +  mdcArr[6]+ "</employeeId>");
	      sb.append("\n");
	      sb.append("<staffNumber>" + mdcArr[7] + "</staffNumber>");   
	      sb.append("\n");
	      sb.append("<firstName>" + mdcArr[8] + "</firstName>");
	      sb.append("\n");
	      sb.append("<middleName>" + mdcArr[9]+ "</middleName>");
	      sb.append("\n");
	      sb.append("<lastName>" + mdcArr[10] + "</lastName>");
	      sb.append("\n");
	      int captainId=(Integer)mdcArr[11];
	      sb.append("<captainId>" +captainId+ "</captainId>");
	      sb.append("\n");
	      if(captainId!=0)
	      {
	      String gsSql="select stu.StudentId,stu.StudentNumber,stu.FirstName,stu.MiddleName,stu.LastName from gbl_sm_tbl_student as stu where (stu.isDeleted<>'y' or  stu.isDeleted is null) and stu.StudentId='"+captainId+"'";
	      query = addempSession.createSQLQuery(gsSql);
			List parList1 = query.list();
			Iterator paIT = parList1.iterator();
			 //sb.append("<studentDetails>");
				//sb.append("\n");
			while (paIT.hasNext()) {
				Object[] paArr = (Object[]) paIT.next();
				//sb.append("<student>");
				//sb.append("\n");
				//sb.append("<studentId>" + paArr[0] + "</studentId>");
				//sb.append("\n");
				sb.append("<studentnumber>"+paArr[1]+"</studentnumber>");
				sb.append("\n");
				sb.append("<studentfirstName>" + paArr[2] + "</studentfirstName>");
				sb.append("\n");
				sb.append("<studentmiddleName>" + paArr[3] + "</studentmiddleName>");
				sb.append("\n");
				sb.append("<studentlastName>" + paArr[4] + "</studentlastName>");
				sb.append("\n");						
			}
	      }else{
	    	  sb.append("<studentnumber></studentnumber>");
				sb.append("\n");
				sb.append("<studentfirstName></studentfirstName>");
				sb.append("\n");
				sb.append("<studentmiddleName></studentmiddleName>");
				sb.append("\n");
				sb.append("<studentlastName></studentlastName>");
				sb.append("\n");
	      }
	     
	      sb.append("<noOfStudents>" + mdcArr[12]+ "</noOfStudents>");
	      sb.append("\n");
	      sb.append("<sectionName>" + mdcArr[13] + "</sectionName>");
	      sb.append("\n");
	      sb.append("<description>" +  mdcArr[14]+ "</description>");
	      sb.append("\n");
	      sb.append("<remarks>" + mdcArr[15] + "</remarks>");
	      sb.append("\n");
	      sb.append("<createdDate>" + mdcArr[16] + "</createdDate>");
	      sb.append("\n");
	      sb.append("<modifiedDate>" + mdcArr[17] + "</modifiedDate>");
	      sb.append("\n");
	      sb.append("<schoolId>" + mdcArr[18] + "</schoolId>");
	      sb.append("\n");
	      sb.append("<branchId>" + mdcArr[19] + "</branchId>");
	      sb.append("\n");
	      sb.append("</section>");
			String str= sb.toString();
			return str;
	     }	
			} 	catch (Exception localException) {

				System.out.println(localException);
					localException.printStackTrace();
			   sb.append("<Response>");
			   sb.append("\n");
			   sb.append("<Result>");
			   sb.append("\n");
			   sb.append("Fail");
			   sb.append("\n");
			   sb.append("</Result>");
			   sb.append("\n");
			   sb.append("<Description>");
			   sb.append("could not getby section single item");
			   sb.append("</Description>");
			   sb.append("\n");
			   sb.append("<Exception>");
			   sb.append(localException);
			   sb.append("</Exception>");
			   sb.append("</Response>");
			   strg=sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (addempTx!=null)
				  addempTx.rollback();
			  } finally {
				  addempSession.close(); 
			  }
			  return strg;
			 }

	@SuppressWarnings("rawtypes")
	public String getAllSection(int PNO, int size,int schoolId,int branchId,String classId) {
			  String xmlString=null;
			  Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
			  Transaction stgTx=null;
			  StringBuffer sb = new StringBuffer();
			  try
			  {
			   stgTx=stgSession.beginTransaction();
			    int fset = (PNO-1)*size;
			    String filterWhere="";		
			    if(classId!=null){
			    	filterWhere=" and section.ClassId in ("+classId+")";			    	
			    }
			    
			    String	gsSql ="select count(*) from gbl_sm_tbl_section section where (isDeleted<>'y' or isDeleted is null) and schoolId='"+schoolId+"' and branchId='"+branchId+"'"+filterWhere+"";
			    Query gsQuery=stgSession.createSQLQuery(gsSql);
			    Object noRecords= gsQuery.uniqueResult();
			    sb.append("<sections>");
			    sb.append("\n");
			    sb.append("<noRecords>"+noRecords+"</noRecords>");
			    sb.append("\n");
			    
			     if (PNO > 0 & size > 0){
			     gsSql="SELECT section.SectionId,section.ClassId,cls.ClassName,section.RoomId,room.RoomNo,room.RoomName,section.EmployeeId,staff.StaffNumber,staff.FirstName,staff.MiddleName,staff.LastName,section.CaptainId,section.NoOfStudents,section.SectionName,section.Description,section.Remarks,section.CreatedDate,section.ModifiedDate,section.SchoolId,section.BranchId FROM gbl_sm_tbl_section as section join gbl_sm_tbl_room as room on room.RoomId=section.RoomId  join gbl_sm_tbl_class as cls on cls.ClassId= section.ClassId left outer join gbl_sm_tbl_staff as staff  on section.EmployeeId=staff.EmployeeId where (section.isDeleted<>'y' or  section.isDeleted is null) and section.schoolId='"+schoolId+"' and section.branchId='"+branchId+"'"+filterWhere+" limit "+size+" offset "+fset;
			     }
			     else {
			      gsSql="SELECT section.SectionId,section.ClassId,cls.ClassName,section.RoomId,room.RoomNo,room.RoomName,section.EmployeeId,staff.StaffNumber,staff.FirstName,staff.MiddleName,staff.LastName,section.CaptainId,section.NoOfStudents,section.SectionName,section.Description,section.Remarks,section.CreatedDate,section.ModifiedDate,section.SchoolId,section.BranchId FROM gbl_sm_tbl_section as section join gbl_sm_tbl_room as room on room.RoomId=section.RoomId  join gbl_sm_tbl_class as cls on cls.ClassId= section.ClassId left outer join gbl_sm_tbl_staff as staff  on section.EmployeeId=staff.EmployeeId where (section.isDeleted<>'y' or  section.isDeleted is null) and section.schoolId='"+schoolId+"' and section.branchId='"+branchId+"'"+filterWhere+"";
			     } 
			    gsQuery=stgSession.createSQLQuery(gsSql);
			    List gcList=gsQuery.list();
			    Iterator gsIT=gcList.iterator();
			     while(gsIT.hasNext())
			     {
			      Object[] mdcArr=(Object[])gsIT.next();
			      sb.append("<section>");
			      sb.append("\n");
			      sb.append("<sectionId>"+mdcArr[0]+"</sectionId>");
			      sb.append("\n");
			      sb.append("<classId>" + mdcArr[1]+ "</classId>");
			      sb.append("\n");
			      sb.append("<className>" + mdcArr[2]+ "</className>");
			      sb.append("\n");
			      sb.append("<roomId>" + mdcArr[3] + "</roomId>");
			      sb.append("\n");
			      sb.append("<roomNo>" + mdcArr[4]+ "</roomNo>");
			      sb.append("\n");
			      sb.append("<roomName>" + mdcArr[5] + "</roomName>");
			      sb.append("\n");
			      sb.append("<employeeId>" +  mdcArr[6]+ "</employeeId>");
			      sb.append("\n");
			      sb.append("<staffNumber>" + mdcArr[7] + "</staffNumber>");   
			      sb.append("\n");
			      sb.append("<firstName>" + mdcArr[8] + "</firstName>");
			      sb.append("\n");
			      sb.append("<middleName>" + mdcArr[9]+ "</middleName>");
			      sb.append("\n");
			      sb.append("<lastName>" + mdcArr[10] + "</lastName>");
			      sb.append("\n");
			      int captainId=(Integer)mdcArr[11];
			      sb.append("<captainId>" +captainId+ "</captainId>");
			      sb.append("\n");
			      if(captainId!=0)
			      {
			      gsSql="select stu.StudentId,stu.StudentNumber,stu.FirstName,stu.MiddleName,stu.LastName from gbl_sm_tbl_student as stu where (stu.isDeleted<>'y' or  stu.isDeleted is null) and stu.StudentId='"+captainId+"'";
			      gsQuery = stgSession.createSQLQuery(gsSql);
					List parList1 = gsQuery.list();
					Iterator paIT = parList1.iterator();
					 //sb.append("<studentDetails>");
						//sb.append("\n");
					while (paIT.hasNext()) {
						Object[] paArr = (Object[]) paIT.next();
						//sb.append("<student>");
						//sb.append("\n");
						//sb.append("<studentId>" + paArr[0] + "</studentId>");
						//sb.append("\n");
						sb.append("<studentnumber>"+paArr[1]+"</studentnumber>");
						sb.append("\n");
						sb.append("<studentfirstName>" + paArr[2] + "</studentfirstName>");
						sb.append("\n");
						sb.append("<studentmiddleName>" + paArr[3] + "</studentmiddleName>");
						sb.append("\n");
						sb.append("<studentlastName>" + paArr[4] + "</studentlastName>");
						sb.append("\n");						
					}
			      }else{
			    	  sb.append("<studentnumber></studentnumber>");
						sb.append("\n");
						sb.append("<studentfirstName></studentfirstName>");
						sb.append("\n");
						sb.append("<studentmiddleName></studentmiddleName>");
						sb.append("\n");
						sb.append("<studentlastName></studentlastName>");
						sb.append("\n");
			      }
			      sb.append("<noOfStudents>" + mdcArr[12]+ "</noOfStudents>");
			      sb.append("\n");
			      sb.append("<sectionName>" + mdcArr[13] + "</sectionName>");
			      sb.append("\n");
			      sb.append("<description>" +  mdcArr[14]+ "</description>");
			      sb.append("\n");
			      sb.append("<remarks>" + mdcArr[15] + "</remarks>");
			      sb.append("\n");
			      sb.append("<createdDate>" + mdcArr[16] + "</createdDate>");
			      sb.append("\n");
			      sb.append("<modifiedDate>" + mdcArr[17] + "</modifiedDate>");
			      sb.append("\n");
			      sb.append("<schoolId>" + mdcArr[18] + "</schoolId>");
			      sb.append("\n");
			      sb.append("<branchId>" + mdcArr[19] + "</branchId>");
			      sb.append("\n");
			      sb.append("</section>");
			     }
			    
			    stgTx.commit();
			    sb.append("</sections>");
			    sb.append("\n");

			    xmlString=sb.toString();
			  }
		catch(Exception localException)
		{

			System.out.println(localException);
				localException.printStackTrace();
		   sb.append("<Response>");
		   sb.append("\n");
		   sb.append("<Result>");
		   sb.append("\n");
		   sb.append("Fail");
		   sb.append("\n");
		   sb.append("</Result>");
		   sb.append("\n");
		   sb.append("<Description>");
		   sb.append("could not getall section info");
		   sb.append("</Description>");
		   sb.append("\n");
		   sb.append("<Exception>");
		   sb.append(localException);
		   sb.append("</Exception>");
		   sb.append("</Response>");
		   xmlString=sb.toString();
		   MDTransactionWriter.exceptionlog.info(localException);
		  if (stgTx!=null)
			  stgTx.rollback();
		  } finally {
			  stgSession.close(); 
		  }
		  return xmlString;
		 }
	@SuppressWarnings("rawtypes")
	public String getByClassIdSection(int classId,int schoolId,int branchId) {
		Session addempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction addempTx=null;
		StringBuffer sb=new StringBuffer();
		String strg= null;
			try {
		addempTx = addempSession.beginTransaction();
		Query query=addempSession.createSQLQuery("SELECT section.SectionId,section.ClassId,cls.ClassName,section.RoomId,room.RoomNo,room.RoomName,"
			     		+ "section.EmployeeId,staff.StaffNumber,staff.FirstName,staff.MiddleName,staff.LastName,section.CaptainId,"
			     		+ "section.NoOfStudents,section.SectionName,section.Description,section.Remarks,section.CreatedDate,"
			     		+ "section.ModifiedDate,section.SchoolId,section.BranchId FROM gbl_sm_tbl_section as section join gbl_sm_tbl_room as room on "
			     		+ "room.RoomId=section.RoomId  join gbl_sm_tbl_class as cls on cls.ClassId= section.ClassId join "
			     		+ "gbl_sm_tbl_staff as staff  on section.EmployeeId=staff.EmployeeId where section.isDeleted<>'y' or  "
			     		+ "section.isDeleted is null and section.ClassId='"+classId+"'and section.schoolId='"+schoolId+"' and section.branchId='"+branchId+"'");
	    List gcList=query.list();
	    Iterator gsIT=gcList.iterator();
	    sb.append("<sections>");
	      sb.append("\n");
	     while(gsIT.hasNext())
	     {
	      Object[] mdcArr=(Object[])gsIT.next();
	  
	      sb.append("<section>");
	      sb.append("\n");
	      sb.append("<sectionId>"+mdcArr[0]+"</sectionId>");
	      sb.append("\n");
	      sb.append("<classId>" + mdcArr[1]+ "</classId>");
	      sb.append("\n");
	      sb.append("<className>" + mdcArr[2]+ "</className>");
	      sb.append("\n");
	      sb.append("<roomId>" + mdcArr[3] + "</roomId>");
	      sb.append("\n");
	      sb.append("<roomNo>" + mdcArr[4]+ "</roomNo>");
	      sb.append("\n");
	      sb.append("<roomName>" + mdcArr[5] + "</roomName>");
	      sb.append("\n");
	      sb.append("<employeeId>" +  mdcArr[6]+ "</employeeId>");
	      sb.append("\n");
	      sb.append("<staffNumber>" + mdcArr[7] + "</staffNumber>");
	      sb.append("\n");
	      sb.append("<firstName>" + mdcArr[8] + "</firstName>");
	      sb.append("\n");
	      sb.append("<middleName>" + mdcArr[9]+ "</middleName>");
	      sb.append("\n");
	      sb.append("<lastName>" + mdcArr[10] + "</lastName>");
	      sb.append("\n");
	      sb.append("<captainId>" +  mdcArr[11]+ "</captainId>");
	      sb.append("\n");
	    
	      sb.append("<studentNumber>" + mdcArr[12] + "</studentNumber>");
	      sb.append("\n");
	      sb.append("<firstName>" + mdcArr[13] + "</firstName>");
	      sb.append("\n");
	      sb.append("<middleName>" + mdcArr[14]+ "</middleName>");
	      sb.append("\n");
	      sb.append("<lastName>" + mdcArr[15] + "</lastName>");
	      sb.append("\n");
	      sb.append("<noOfStudents>" + mdcArr[16]+ "</noOfStudents>");
	      sb.append("\n");
	      sb.append("<sectionName>" + mdcArr[17] + "</sectionName>");
	      sb.append("\n");
	      sb.append("<description>" +  mdcArr[18]+ "</description>");
	      sb.append("\n");
	      sb.append("<remarks>" + mdcArr[19] + "</remarks>");
	      sb.append("\n");
	      sb.append("<createdDate>" + mdcArr[20] + "</createdDate>");
	      sb.append("\n");
	      sb.append("<modifiedDate>" + mdcArr[21] + "</modifiedDate>");
	      sb.append("\n");
	      sb.append("<schoolId>" + mdcArr[22] + "</schoolId>");
	      sb.append("\n");
	      sb.append("<branchId>" + mdcArr[23] + "</branchId>");
	      sb.append("\n");
	      sb.append("</section>");
			
	     }	
	     sb.append("</sections>");
	     sb.append("\n");
	     String str= sb.toString();
			return str;
			} 	catch (Exception localException) {

				System.out.println(localException);
					localException.printStackTrace();
			   sb.append("<Response>");
			   sb.append("\n");
			   sb.append("<Result>");
			   sb.append("\n");
			   sb.append("Fail");
			   sb.append("\n");
			   sb.append("</Result>");
			   sb.append("\n");
			   sb.append("<Description>");
			   sb.append("could not getby section single item");
			   sb.append("</Description>");
			   sb.append("\n");
			   sb.append("<Exception>");
			   sb.append(localException);
			   sb.append("</Exception>");
			   sb.append("</Response>");
			   strg=sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (addempTx!=null)
				  addempTx.rollback();
			  } finally {
				  addempSession.close(); 
			  }
			  return strg;
			 }

}
