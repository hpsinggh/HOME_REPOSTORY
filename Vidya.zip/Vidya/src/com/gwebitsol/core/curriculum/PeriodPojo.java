package com.gwebitsol.core.curriculum;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="Period")
public class PeriodPojo {
	private int periodId;
	private int timeTableId;
	private int subjectId;
	private int employeeId;
	private String periodTitle;
	private String description;
	private String startTime;
	private String endTime;
	private String days;
	private int sequenceNo;
	private int schoolId;
	private int branchId;
	
	public int getTimeTableId() {
		return timeTableId;
	}
	public void setTimeTableId(int timeTableId) {
		this.timeTableId = timeTableId;
	}
	public int getSubjectId() {
		return subjectId;
	}
	public void setSubjectId(int subjectId) {
		this.subjectId = subjectId;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	
	public int getPeriodId() {
		return periodId;
	}
	public void setPeriodId(int periodId) {
		this.periodId = periodId;
	}
	public String getPeriodTitle() {
		return periodTitle;
	}
	public void setPeriodTitle(String periodTitle) {
		this.periodTitle = periodTitle;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public String getDays() {
		return days;
	}
	public void setDays(String days) {
		this.days = days;
	}
	public int getSequenceNo() {
		return sequenceNo;
	}
	public void setSequenceNo(int sequenceNo) {
		this.sequenceNo = sequenceNo;
	}
	public int getSchoolId() {
		return schoolId;
	}
	public void setSchoolId(int schoolId) {
		this.schoolId = schoolId;
	}
	public int getBranchId() {
		return branchId;
	}
	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}	

}
