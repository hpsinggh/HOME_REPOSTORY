package com.gwebitsol.core.curriculum;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="TimeTable")
public class TimeTablePojo {
	private int timeTableId;
	private int sectionId;
	private int classId;
	private String timeTableTitle;
	private String sharable;
	private String description;
	private String remarks;
	private int schoolId;
	private int branchId;
	private String createdDate;
	DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	Date date = new Date();
	 String modifiedDate=dateFormat.format(date);
	
	 public int getClassId() {
			return classId;
		}
		public void setClassId(int classId) {
			this.classId = classId;
		}
	public int getTimeTableId() {
		return timeTableId;
	}
	public void setTimeTableId(int timeTableId) {
		this.timeTableId = timeTableId;
	}
	public int getSectionId() {
		return sectionId;
	}
	public void setSectionId(int sectionId) {
		this.sectionId = sectionId;
	}
	public String getTimeTableTitle() {
		return timeTableTitle;
	}
	public void setTimeTableTitle(String timeTableTitle) {
		this.timeTableTitle = timeTableTitle;
	}
	public String getSharable() {
		return sharable;
	}
	public void setSharable(String sharable) {
		this.sharable = sharable;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public int getSchoolId() {
		return schoolId;
	}
	public void setSchoolId(int schoolId) {
		this.schoolId = schoolId;
	}
	public int getBranchId() {
		return branchId;
	}
	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}	
	
}
