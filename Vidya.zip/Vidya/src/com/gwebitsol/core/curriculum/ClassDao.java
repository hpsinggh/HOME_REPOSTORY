package com.gwebitsol.core.curriculum;

import java.util.Iterator;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

@Repository
public class ClassDao {
	
	public String addClass(ClassPojo classPojo) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
					String strg= null;
					 StringBuffer sb= new StringBuffer();
					 try {
							tx = rdSession.beginTransaction();
							Integer i=(Integer) rdSession.save(classPojo);
							System.out.println(i);
							tx.commit();
							sb.append("<class>");
							sb.append("\n");
							sb.append("<ClassId>");
							sb.append(i);
							sb.append("</ClassId>");
							sb.append("\n");
							sb.append("</class>");
							strg= sb.toString();							
						}
					 catch (Exception localException) {
							System.out.println(localException);
	 						localException.printStackTrace();
						   sb.append("<Response>");
						   sb.append("\n");
						   sb.append("<Result>");
						   sb.append("\n");
						   sb.append("Fail");
						   sb.append("\n");
						   sb.append("</Result>");
						   sb.append("\n");
						   sb.append("<Description>");
						   sb.append("could not inserted class info");
						   sb.append("</Description>");
						   sb.append("\n");
						   sb.append("<Exception>");
						   sb.append(localException);
						   sb.append("</Exception>");
						   sb.append("</Response>");
						    strg=sb.toString();
						   MDTransactionWriter.exceptionlog.info(localException);
						  if (tx!=null)
						   tx.rollback();
						  } finally {
						   rdSession.close(); 
						  }
						  return strg;
						 }
	
		public String deleteClass(int classId,int schoolId,int branchId) {
			Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
			Transaction tx = null;
			StringBuffer sb=new StringBuffer();
			String strg= null;
			try {
					tx = rdSession.beginTransaction();
					/*ClassPojo c=new ClassPojo();
					c.setClassId(id);
					rdSession.delete(c);
					tx.commit();*/
					ClassPojo cp = (ClassPojo) rdSession.get(ClassPojo.class,classId);					   
					   rdSession.evict(cp);
					   if(schoolId==cp.getSchoolId()&&branchId==cp.getBranchId())
					   {
					   Query empQuery=rdSession.createSQLQuery("update gbl_sm_tbl_class set isDeleted='y' where classId='"+classId+"'");
					   empQuery.executeUpdate();
					   tx.commit();
				    sb.append("<classes>");
				    sb.append("\n");
				    sb.append("<id>");
					sb.append("\n");
					sb.append("class id is deleted");
					sb.append("</id>");
					sb.append("\n");
					sb.append("</classes>");
					strg= sb.toString();
			}else{
				   strg = " class is not deleted";
				   sb.append("<class>");
				   sb.append("\n");
				   sb.append(strg);
				   sb.append("</class>");
				    String str = sb.toString();
				    return str;
				   }
			}
			catch(Exception localException)
			{
				System.out.println(localException);
				localException.printStackTrace();
			   sb.append("<Response>");
			   sb.append("\n");
			   sb.append("<Result>");
			   sb.append("\n");
			   sb.append("Fail");
			   sb.append("\n");
			   sb.append("</Result>");
			   sb.append("\n");
			   sb.append("<Description>");
			   sb.append("could not deleted class item");
			   sb.append("</Description>");
			   sb.append("\n");
			   sb.append("<Exception>");
			   sb.append(localException);
			   sb.append("</Exception>");
			   sb.append("</Response>");
			   strg=sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (tx!=null)
			   tx.rollback();
			  } finally {
			   rdSession.close(); 
			  }
			  return strg;
			 }
	
	public String updateClass(ClassPojo classPojo,int schoolId,int branchId) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb= new StringBuffer();
		String strg= null;
			try {
					tx = rdSession.beginTransaction();
					/*rdSession.update(classPojo);
					tx.commit();*/
					ClassPojo cp = (ClassPojo) rdSession.get(ClassPojo.class,classPojo.getClassId());
					rdSession.evict(cp);
					   if(schoolId==cp.getSchoolId()&&branchId==cp.getBranchId())
					   rdSession.update(classPojo);    
					   tx.commit();
					sb.append("<classes>");
				    sb.append("<id>");
					sb.append("class succssfully updated");
					sb.append("</id>");
					sb.append("\n");
					sb.append("</classes>");
					strg= sb.toString();	    
					} catch (Exception localException) {
						System.out.println(localException);
						localException.printStackTrace();
					   sb.append("<Response>");
					   sb.append("\n");
					   sb.append("<Result>");
					   sb.append("\n");
					   sb.append("Fail");
					   sb.append("\n");
					   sb.append("</Result>");
					   sb.append("\n");
					   sb.append("<Description>");
					   sb.append("could not updated class item");
					   sb.append("</Description>");
					   sb.append("\n");
					   sb.append("<Exception>");
					   sb.append(localException);
					   sb.append("</Exception>");
					   sb.append("</Response>");
					   strg=sb.toString();
					   MDTransactionWriter.exceptionlog.info(localException);
					  if (tx!=null)
					   tx.rollback();
					  } finally {
					   rdSession.close(); 
					  }
					  return strg;
					 }
	
	@SuppressWarnings("rawtypes")
	public String getByIdClass(int classId,int schoolId,int branchId) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb= new StringBuffer();
		System.out.println("hi dao impl success");
		String strg= null;
		
			try {
				tx = rdSession.beginTransaction();
				Query query=rdSession.createSQLQuery("SELECT cls.ClassId,cls.ClassName,cls.Description,cls.CreatedDate,cls.ModifiedDate,"
			     		+ "cls.SchoolId,cls.BranchId FROM gbl_sm_tbl_class as cls where cls.isDeleted<>'y' "
			     		+ "or cls.isDeleted is null and ClassId='"+classId+"' and cls.schoolId='"+schoolId+"' and cls.branchId='"+branchId+"' ");
			    List gcList=query.list();
			    Iterator gsIT=gcList.iterator();
			     while(gsIT.hasNext())
			     {
			      Object[] mdcArr=(Object[])gsIT.next();
			      sb.append("<class>");
			      sb.append("\n");
			      sb.append("<classId>"+mdcArr[0]+"</classId>");
			      sb.append("\n");
			      sb.append("<className>" + mdcArr[1]+ "</className>");
			      sb.append("\n");
			      sb.append("<description>" + mdcArr[2] + "</description>");
			      sb.append("\n");
			      sb.append("<createdDate>" + mdcArr[3]+ "</createdDate>");
			      sb.append("\n");
			      sb.append("<modifiedDate>" + mdcArr[4] + "</modifiedDate>");
			      sb.append("\n");
			      sb.append("<schoolId>" + mdcArr[5] + "</schoolId>");
			      sb.append("\n");
			      sb.append("<branchId>" + mdcArr[6] + "</branchId>");
			      sb.append("\n");
			      sb.append("</class>");
					String str= sb.toString();
					return str;
			     }
		
					} catch (Exception localException) {
					System.out.println(localException);
					localException.printStackTrace();
				   sb.append("<Response>");
				   sb.append("\n");
				   sb.append("<Result>");
				   sb.append("\n");
				   sb.append("Fail");
				   sb.append("\n");
				   sb.append("</Result>");
				   sb.append("\n");
				   sb.append("<Description>");
				   sb.append("could not getby class items");
				   sb.append("</Description>");
				   sb.append("\n");
				   sb.append("<Exception>");
				   sb.append(localException);
				   sb.append("</Exception>");
				   sb.append("</Response>");
				   strg=sb.toString();
				   MDTransactionWriter.exceptionlog.info(localException);
				  if (tx!=null)
				   tx.rollback();
				  } finally {
				   rdSession.close(); 
				  }
				return strg;
			 }
	@SuppressWarnings("rawtypes")
	public String getAllClasses(int PNO, int size,int schoolId,int branchId){
			  String xmlString=null;
			  Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
			  Transaction stgTx=null;
			  StringBuffer sb = new StringBuffer();
			  try
			  {
			   stgTx=stgSession.beginTransaction();
			    int fset = (PNO-1)*size;
			    String gsSql ="select count(*) from gbl_sm_tbl_class where isDeleted<>'y' or isDeleted is null and schoolId='"+schoolId+"' and branchId='"+branchId+"' ";
			    Query gsQuery=stgSession.createSQLQuery(gsSql);
			    Object noRecords= gsQuery.uniqueResult();
			    sb.append("<classes>");
			    sb.append("\n");
			    sb.append("<noRecords>"+noRecords+"</noRecords>");
			    sb.append("\n");
			    
			     if (PNO > 0 & size > 0){
			     gsSql="SELECT cls.ClassId,cls.ClassName,cls.Description,cls.CreatedDate,cls.ModifiedDate,"
			     		+ "cls.SchoolId,cls.BranchId FROM gbl_sm_tbl_class as cls where cls.isDeleted<>'y' "
			     		+ "or cls.isDeleted is null and cls.schoolId='"+schoolId+"' and cls.branchId='"+branchId+"' limit "+size+" offset "+fset;
			     }
			     else {
			      gsSql="SELECT cls.ClassId,cls.ClassName,cls.Description,cls.CreatedDate,cls.ModifiedDate,"
			     		+ "cls.SchoolId,cls.BranchId FROM gbl_sm_tbl_class as cls where cls.isDeleted<>'y' "
			     		+ "or cls.isDeleted is null and cls.schoolId='"+schoolId+"' and cls.branchId='"+branchId+"'";
			     } 
			   
			    gsQuery=stgSession.createSQLQuery(gsSql);
			    List gcList=gsQuery.list();
			    Iterator gsIT=gcList.iterator();
			     while(gsIT.hasNext())
			     {
			      Object[] mdcArr=(Object[])gsIT.next();
			      sb.append("<class>");
			      sb.append("\n");
			      sb.append("<classId>"+mdcArr[0]+"</classId>");
			      sb.append("\n");
			      sb.append("<className>" + mdcArr[1]+ "</className>");
			      sb.append("\n");
			      sb.append("<description>" + mdcArr[2] + "</description>");
			      sb.append("\n");
			      sb.append("<createdDate>" + mdcArr[3]+ "</createdDate>");
			      sb.append("\n");
			      sb.append("<modifiedDate>" + mdcArr[4] + "</modifiedDate>");
			      sb.append("\n");
			      sb.append("<schoolId>" + mdcArr[5] + "</schoolId>");
			      sb.append("\n");
			      sb.append("<branchId>" + mdcArr[6] + "</branchId>");
			      sb.append("\n");
			      sb.append("</class>");
			      sb.append("\n");
			     }
			    stgTx.commit();
			    sb.append("</classes>");
			    sb.append("\n");

			    xmlString=sb.toString();
			   }
			  catch(Exception localException)
			  {
			   stgTx.rollback();
			   localException.printStackTrace();
			   xmlString = "fail";
			   System.out.println("Could not Get classes");
			  }
			  finally
			  {
			   stgSession.close();
			  } 
			  return xmlString;

			 }
	}



