package com.gwebitsol.core.curriculum;
import java.util.Iterator;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;
@Repository
@Component
public class CurriculamDaoImpl  {

			public String addCurriculum(Curriculum curriculum) {
				Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
				Transaction tx = null;
				String strg= null;
				 StringBuffer sb= new StringBuffer();
				 try {
						tx = rdSession.beginTransaction();
						Integer i=(Integer) rdSession.save(curriculum);		 
						System.out.println(i);
						 tx.commit();
						 sb.append("<Curriculum>");
						  sb.append("\n");
						  sb.append("<CurriculumId>");
						  sb.append(i);
						  sb.append("</CurriculumId>");
						  sb.append("\n");
						  sb.append("</Curriculum>");
						  strg= sb.toString();	
						} catch (Exception localException) {
							System.out.println(localException);
							localException.printStackTrace();
						   sb.append("<Response>");
						   sb.append("\n");
						   sb.append("<Result>");
						   sb.append("\n");
						   sb.append("Fail");
						   sb.append("\n");
						   sb.append("</Result>");
						   sb.append("\n");
						   sb.append("<Description>");
						   sb.append("could not inserted curriculum item");
						   sb.append("</Description>");
						   sb.append("\n");
						   sb.append("<Exception>");
						   sb.append(localException);
						   sb.append("</Exception>");
						   sb.append("</Response>");
						   strg=sb.toString();
						   MDTransactionWriter.exceptionlog.info(localException);
						  if (tx!=null)
						   tx.rollback();
						  } finally {
						   rdSession.close(); 
						  }
						return strg;
					 }
			public String deleteCurriculum(int curriculumId,int schoolId,int branchId) {
				Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
				Transaction tx = null;
				StringBuffer sb=new StringBuffer();
				String strg= null;
				try {
						tx = rdSession.beginTransaction();
						/*Curriculum c=new Curriculum();
						c.setCurriculumId(id);
						rdSession.delete(c);
						tx.commit();*/
						Curriculum curlm = (Curriculum) rdSession.get(Curriculum.class,curriculumId);					   
						   rdSession.evict(curlm);
						   if(schoolId==curlm.getSchoolId()&&branchId==curlm.getBranchId())
						   {
						   Query empQuery=rdSession.createSQLQuery("update gbl_sm_tbl_curriculum set isDeleted='y' where curriculumId='"+curriculumId+"'");
						   empQuery.executeUpdate();
						   tx.commit();
						    sb.append("<curriculum>");
						    sb.append("\n");
						    sb.append("<id>");
							sb.append("curriculum item deleted");
							sb.append("</id>");
							sb.append("\n");
							sb.append("</curriculum>");
							 strg= sb.toString();
						  }else{
					   strg = " curriculum is not deleted";
					   sb.append("<curriculam>");
					   sb.append("\n");
					   sb.append(strg);
					   sb.append("</curriculum>");
					    String str = sb.toString();
					    return str;
					   }
				}
			catch(Exception localException)
			{
				System.out.println(localException);
				localException.printStackTrace();
			   sb.append("<Response>");
			   sb.append("\n");
			   sb.append("<Result>");
			   sb.append("\n");
			   sb.append("Fail");
			   sb.append("\n");
			   sb.append("</Result>");
			   sb.append("\n");
			   sb.append("<Description>");
			   sb.append("could not deleted curriculum item");
			   sb.append("</Description>");
			   sb.append("\n");
			   sb.append("<Exception>");
			   sb.append(localException);
			   sb.append("</Exception>");
			   sb.append("</Response>");
			   strg=sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (tx!=null)
			   tx.rollback();
			  } finally {
			   rdSession.close(); 
			  }
			return strg;
		 }
	
			public String updateCurriculum(Curriculum curriculum,int schoolId,int branchId) {
				Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
				Transaction tx = null;
				StringBuffer sb= new StringBuffer();
				String strg= null;
					try {
							tx = rdSession.beginTransaction();
							/*rdSession.update(curriculum);
							tx.commit();*/
							Curriculum curlm = (Curriculum) rdSession.get(Curriculum.class,curriculum.getCurriculumId());
							rdSession.evict(curlm);
							   if(schoolId==curlm.getSchoolId()&&branchId==curlm.getBranchId())
							   rdSession.update(curriculum);
							   tx.commit();
							    sb.append("<curriculum>");
							    sb.append("\n");
							    sb.append("<curriculumid>");
								sb.append("curriculum succssfully updated");
								sb.append("</curriculumid>");
								sb.append("\n");
								sb.append("</curriculum>");
								strg= sb.toString();
						} 	catch (Exception localException) {
							System.out.println(localException);
							localException.printStackTrace();
						   sb.append("<Response>");
						   sb.append("\n");
						   sb.append("<Result>");
						   sb.append("\n");
						   sb.append("Fail");
						   sb.append("\n");
						   sb.append("</Result>");
						   sb.append("\n");
						   sb.append("<Description>");
						   sb.append("could not updated curriculum item");
						   sb.append("</Description>");
						   sb.append("\n");
						   sb.append("<Exception>");
						   sb.append(localException);
						   sb.append("</Exception>");
						   sb.append("</Response>");
						   strg=sb.toString();
						   MDTransactionWriter.exceptionlog.info(localException);
						  if (tx!=null)
						   tx.rollback();
						  } finally {
						   rdSession.close(); 
						  }
						return strg;
					 }
				

			@SuppressWarnings("rawtypes")
			public String getAllCurriculums(int PNO, int size,int schoolId,int branchId,int classId,int sectionId,int subjectTypeId) {
					  String xmlString=null;
					  Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
					  Transaction stgTx=null;
					  StringBuffer sb = new StringBuffer();
					  try
					  {
					   stgTx=stgSession.beginTransaction();
					    int fset = (PNO-1)*size;
					    String filterWhere="";
					    String subInnerQuery=" and CurriculumId in (select CurriculumId from gbl_sm_tbl_subjects as sub where (sub.isDeleted<>'y' or sub.isDeleted is null) ";
					    boolean isFlterExist=false;
					    if(classId!=0){									  								    	
					    	subInnerQuery+=" and sub.ClassId="+classId;			    	
						if(sectionId!=0){
							subInnerQuery +=  " and sub.SectionId="+sectionId;						
						}
						isFlterExist=true;
						}
					    if(subjectTypeId!=0){
					    	subInnerQuery += " and sub.SubjectTypeId="+subjectTypeId;
					    	isFlterExist=true;
					    	} 
					    if(isFlterExist){
					    	filterWhere=subInnerQuery+")";
					    }
					    String gsSql ="select count(*) from gbl_sm_tbl_curriculum where isDeleted<>'y' or isDeleted is null and schoolId='"+schoolId+"' and branchId='"+branchId+"' "+filterWhere+" ";
					    Query gsQuery=stgSession.createSQLQuery(gsSql);
					    Object noRecords= gsQuery.uniqueResult();
					    int intNoRecords=0;
						if(noRecords!=null && Integer.parseInt(noRecords.toString())!=0)
						{
							intNoRecords=Integer.parseInt(noRecords.toString());
						}
					    sb.append("<curriculums>");
					    sb.append("\n");
					    sb.append("<noRecords>"+noRecords+"</noRecords>");
					    sb.append("\n");
					    if(intNoRecords!=0)
						{
					     if (PNO > 0 & size > 0){
					     gsSql="SELECT curlm.CurriculumId,curlm.CurriculumTitle,curlm.Description,curlm.CreatedDate,"
					     		+ "curlm.ModifiedDate,curlm.SchoolId,curlm.BranchId FROM gbl_sm_tbl_curriculum as curlm "
					     		+ " where (curlm.isDeleted<>'y' or curlm.isDeleted is null) "
					     		+ "and  curlm.schoolId='"+schoolId+"' and curlm.branchId='"+branchId+"'"+filterWhere+" limit "+size+" offset "+fset;
					     }
					     else {
					      gsSql="SELECT curlm.CurriculumId,curlm.CurriculumTitle,curlm.Description,curlm.CreatedDate,"
					     		+ "curlm.ModifiedDate,curlm.SchoolId,curlm.BranchId FROM gbl_sm_tbl_curriculum as curlm "
					     		+ " where (curlm.isDeleted<>'y' or curlm.isDeleted is null) "
					     		+ "and  curlm.schoolId='"+schoolId+"' and curlm.branchId='"+branchId+"'"+filterWhere+" ";
					     } 
					    gsQuery=stgSession.createSQLQuery(gsSql);
					    List gcList=gsQuery.list();
					    Iterator gsIT=gcList.iterator();
					    int curriculumId=0;
					     while(gsIT.hasNext())
					     {
					      Object[] mdcArr=(Object[])gsIT.next();
					      curriculumId=(Integer)mdcArr[0];				      
					      gsSql="SELECT sub.SubjectId,sub.SubjectTypeId,subtype.SubjectName,sub.ClassId,cls.ClassName,sub.SectionId,sec.SectionName FROM gbl_sm_tbl_curriculum as curlm, gbl_sm_tbl_subjects as sub, gbl_sm_tbl_class as cls, gbl_sm_tbl_section as sec,gbl_sm_tbl_subject_type as subtype where curlm.isDeleted<>'y' or curlm.isDeleted is null and sub.CurriculumId='"+curriculumId+"' and sub.ClassId=cls.ClassId and sub.SectionId=sec.SectionId and subtype.SubjectTypeId=sub.SubjectTypeId and curlm.schoolId='"+schoolId+"' and curlm.branchId='"+branchId +"'";
					      gsQuery=stgSession.createSQLQuery(gsSql);
						    List gcListSub=gsQuery.list();
						    Iterator gsITSub=gcListSub.iterator();
						    sb.append("<curriculum>");
						      sb.append("\n");
						      sb.append("<curriculumId>"+curriculumId+"</curriculumId>");
						      sb.append("\n");
					      while(gsITSub.hasNext())
					      {
					      Object[] subArr=(Object[])gsITSub.next();
					      
					      sb.append("<subjectId>"+subArr[0]+"</subjectId>");
					      sb.append("\n");
					      sb.append("<subjectTypeId>"+subArr[1]+"</subjectTypeId>");
					      sb.append("\n");
					      sb.append("<subjectName>"+subArr[2]+"</subjectName>");
					      sb.append("\n");
					      sb.append("<classId>"+subArr[3]+"</classId>");
					      sb.append("\n");
					      sb.append("<className>"+subArr[4]+"</className>");
					      sb.append("\n");
					      sb.append("<sectionId>"+subArr[5]+"</sectionId>");
					      sb.append("\n");
					      sb.append("<sectionName>"+subArr[6]+"</sectionName>");
					      sb.append("\n");
					      break;
					      }
					      sb.append("<curriculumTitle>" + mdcArr[1]+ "</curriculumTitle>");
					      sb.append("\n");
					      sb.append("<description>" + mdcArr[2]+ "</description>");
					      sb.append("\n");
					      sb.append("<createdDate>" + mdcArr[3] + "</createdDate>");
					      sb.append("\n");
					      sb.append("<modifiedDate>" + mdcArr[4]+ "</modifiedDate>");
					      sb.append("\n");
					      sb.append("<schoolId>" + mdcArr[5] + "</schoolId>");
					      sb.append("\n");
					      sb.append("<branchId>" + mdcArr[6] + "</branchId>");
					      sb.append("\n");
					      sb.append("</curriculum>");
					     }
						}
					    stgTx.commit();
					    sb.append("</curriculums>");
					    sb.append("\n");

					    xmlString=sb.toString();
					   } 
				catch(Exception localException)
				{
					System.out.println(localException);
					localException.printStackTrace();
				   sb.append("<Response>");
				   sb.append("\n");
				   sb.append("<Result>");
				   sb.append("\n");
				   sb.append("Fail");
				   sb.append("\n");
				   sb.append("</Result>");
				   sb.append("\n");
				   sb.append("<Description>");
				   sb.append("could notgetall curriculum items");
				   sb.append("</Description>");
				   sb.append("\n");
				   sb.append("<Exception>");
				   sb.append(localException);
				   sb.append("</Exception>");
				   sb.append("</Response>");
				   xmlString=sb.toString();
				   MDTransactionWriter.exceptionlog.info(localException);
				  if (stgTx!=null)
					  stgTx.rollback();
				  } finally {
					  stgSession.close(); 
				  }
				return xmlString;
			 }

			@SuppressWarnings("rawtypes")
			public String getByIdCurriculum(int curriculumId,int schoolId,int branchId) {
				Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
				Transaction tx = null;
				StringBuffer sb= new StringBuffer();
				String strg= null;
					try {
							tx = rdSession.beginTransaction();
							Query query=rdSession.createSQLQuery("SELECT curlm.CurriculumId,curlm.CurriculumTitle,curlm.Description,curlm.CreatedDate,"
					     		+ "curlm.ModifiedDate,curlm.SchoolId,curlm.BranchId FROM gbl_sm_tbl_curriculum as curlm "
					     		+ " where (curlm.isDeleted<>'y' or curlm.isDeleted is null) "
					     		+ "and curlm.CurriculumId='"+curriculumId+"' and curlm.schoolId='"+schoolId+"' and curlm.branchId='"+branchId+"' ");
					    List gcList=query.list();
					    Iterator gsIT=gcList.iterator();
					     while(gsIT.hasNext())
					     {
					      Object[] mdcArr=(Object[])gsIT.next();
					  
					      curriculumId=(Integer)mdcArr[0];				      
					     String gsSql="SELECT sub.SubjectId,sub.SubjectTypeId,subtype.SubjectName,sub.ClassId,cls.ClassName,sub.SectionId,sec.SectionName FROM gbl_sm_tbl_curriculum as curlm, gbl_sm_tbl_subjects as sub, gbl_sm_tbl_class as cls, gbl_sm_tbl_section as sec,gbl_sm_tbl_subject_type as subtype where curlm.isDeleted<>'y' or curlm.isDeleted is null and sub.CurriculumId='"+curriculumId+"' and sub.ClassId=cls.ClassId and sub.SectionId=sec.SectionId and subtype.SubjectTypeId=sub.SubjectTypeId and curlm.schoolId='"+schoolId+"' and curlm.branchId='"+branchId +"'";
					      query=rdSession.createSQLQuery(gsSql);
						    List gcListSub=query.list();
						    Iterator gsITSub=gcListSub.iterator();
						    sb.append("<curriculum>");
						      sb.append("\n");
						      sb.append("<curriculumId>"+curriculumId+"</curriculumId>");
						      sb.append("\n");
					      while(gsITSub.hasNext())
					      {
					      Object[] subArr=(Object[])gsITSub.next();
					      
					      sb.append("<subjectId>"+subArr[0]+"</subjectId>");
					      sb.append("\n");
					      sb.append("<subjectTypeId>"+subArr[1]+"</subjectTypeId>");
					      sb.append("\n");
					      sb.append("<subjectName>"+subArr[2]+"</subjectName>");
					      sb.append("\n");
					      sb.append("<classId>"+subArr[3]+"</classId>");
					      sb.append("\n");
					      sb.append("<className>"+subArr[4]+"</className>");
					      sb.append("\n");
					      sb.append("<sectionId>"+subArr[5]+"</sectionId>");
					      sb.append("\n");
					      sb.append("<sectionName>"+subArr[6]+"</sectionName>");
					      sb.append("\n");
					      break;
					      }
					      sb.append("<curriculumTitle>" + mdcArr[1]+ "</curriculumTitle>");
					      sb.append("\n");
					      sb.append("<description>" + mdcArr[2]+ "</description>");
					      sb.append("\n");
					      sb.append("<createdDate>" + mdcArr[3] + "</createdDate>");
					      sb.append("\n");
					      sb.append("<modifiedDate>" + mdcArr[4]+ "</modifiedDate>");
					      sb.append("\n");
					      sb.append("<schoolId>" + mdcArr[5] + "</schoolId>");
					      sb.append("\n");
					      sb.append("<branchId>" + mdcArr[6] + "</branchId>");
					      sb.append("\n");
					      sb.append("</curriculum>");
							String str= sb.toString();
							return str;
					     }
					} 	catch (Exception localException) {
						System.out.println(localException);
						localException.printStackTrace();
					   sb.append("<Response>");
					   sb.append("\n");
					   sb.append("<Result>");
					   sb.append("\n");
					   sb.append("Fail");
					   sb.append("\n");
					   sb.append("</Result>");
					   sb.append("\n");
					   sb.append("<Description>");
					   sb.append("could notgetby curriculum items");
					   sb.append("</Description>");
					   sb.append("\n");
					   sb.append("<Exception>");
					   sb.append(localException);
					   sb.append("</Exception>");
					   sb.append("</Response>");
					   sb.append("</curriculamid>");
					   sb.append("</curriculum>");
					   strg=sb.toString();
					   MDTransactionWriter.exceptionlog.info(localException);
					  if (tx!=null)
					   tx.rollback();
					  } finally {
					   rdSession.close(); 
					  }
					return strg;
				 }
}
			
			
