package com.gwebitsol.core.curriculum;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import com.gwebitsol.core.security.MDValidation;
import com.gwebitsol.core.usermanagement.MDGetUserFromID;
import com.gwebitsol.core.util.MDTransactionWriter;

public class PeriodService implements PeriodServiceInf {
	@Context 
	private HttpServletRequest hsr;
	public Response addPeriod(PeriodPojo periodPojo,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		 MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
			String status=null;
		    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date date = new Date();
			String startDate=dateFormat.format(date);
			Long sl=System.currentTimeMillis();
			periodPojo.setSchoolId(schoolId);
			periodPojo.setBranchId(branchId);
			try
			{
				MDValidation mdv = new MDValidation();  
				  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
				   System.out.println("verifiedvalue::"+ret);
				   MDGetUserFromID mdgufid = new MDGetUserFromID();
				   String requester = mdgufid.getUserName(userID);
			if(ret==1 )//&& rtVal==1)
			{
					PeriodDao brdao=new PeriodDao();
					status=brdao.addPeriod(periodPojo);
					System.out.println(status);
					String endDate=dateFormat.format(new Date());
					Long el=System.currentTimeMillis();
					MDTransactionWriter.writeLog(datastoreName,"PeriodService_addPeriod",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());
			}else
			{
				status="you are not authorised user";
			}
			}
			
			catch(Exception localException)
			{
				MDTransactionWriter.errorlog.debug(localException);
				MDTransactionWriter.errorlog.info(localException);
				status="failed in service layer";
			}
		
			return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
		
	}

	public Response updatePeriod(PeriodPojo periodPojo,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String status=null;
	    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		periodPojo.setSchoolId(schoolId);
		periodPojo.setBranchId(branchId);
		try
		{	MDValidation mdv = new MDValidation();  
		  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
		   System.out.println("verifiedvalue::"+ret);
		   
		   MDGetUserFromID mdgufid = new MDGetUserFromID();
		   String requester = mdgufid.getUserName(userID);
		if(ret==1 )//&& rtVal==1)
		{
				PeriodDao brdao=new PeriodDao();
				status=brdao.updatePeriod(periodPojo, schoolId,branchId);
				System.out.println(status);
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				
				MDTransactionWriter.writeLog(datastoreName,"PeriodService_updatePeriod",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());
		}
		else
		{
			status="you are not authorised user";
		}
		}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			status="failed in service layer";
		}
	
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response deletePeriod(int periodId,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		
		try
	{	
			MDValidation mdv = new MDValidation();  
			  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			   System.out.println("verifiedvalue::"+ret);
			   
			   MDGetUserFromID mdgufid = new MDGetUserFromID();
			   String requester = mdgufid.getUserName(userID);
			if(ret==1 )//&& rtVal==1)
			{
			PeriodDao brdao=new PeriodDao();
		status=brdao.deletePeriod(periodId, schoolId,branchId);
		
		String endDate=dateFormat.format(new Date());	
		Long el=System.currentTimeMillis();
		
			MDTransactionWriter.writeLog(datastoreName,"PeriodService_deletePeriod",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
	}else
	{
		status="you are not authorised user";
	}
	}
	catch(Exception localException)
	{
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
		status="failed in service layer";
	}
return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();	
	}

	public Response getByIdPeriod(int periodId,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try{	
		
			MDValidation mdv = new MDValidation();  
			  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			   System.out.println("verifiedvalue::"+ret);
			   
			   MDGetUserFromID mdgufid = new MDGetUserFromID();
			   String requester = mdgufid.getUserName(userID);
	if(ret==1 )//&& rtVal==1)
	{
			PeriodDao ex=new PeriodDao();
			 status=ex.getByIdPeriod(periodId, schoolId,branchId);
			 
			 System.out.println(status);
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			//status1="user validation successfull";
			MDTransactionWriter.writeLog(datastoreName,"PeriodService_getByIdPeriod",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
	}else
	{
		status="you are not authorised user";
	}
	}
	catch(Exception localException)
	{
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
		status="failed in service layer";
		//System.out.println(localException);
	}
 return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response getAllPeriod(int userID, int connectionID,String datastoreName,int PNO, int size,int schoolId,int branchId,int classId,int sectionId,String weekDay,int periodNo) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try{	
			MDValidation mdv = new MDValidation();  
			int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
		   System.out.println("verifiedvalue::"+ret);
		   
		   MDGetUserFromID mdgufid = new MDGetUserFromID();
		   String requester = mdgufid.getUserName(userID);
		if(ret==1 )//&& rtVal==1)
		{
			PeriodDao ex=new PeriodDao();
			/*status=ex.getAllPeriod();*/
			 status=ex.getAllPeriods( PNO, size, schoolId,branchId,classId,sectionId, weekDay,periodNo);
			System.out.println(status);
			
			System.out.println(status);
			String endDate=dateFormat.format(new Date());
			  Long el=System.currentTimeMillis();
			 MDTransactionWriter.writeLog(datastoreName,"PeriodService_getAllPeriod",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		

		}else
		{
			status="you are not authorised user";
		}
		}catch(Exception localException)
		   {
			  MDTransactionWriter.errorlog.debug(localException);
			  MDTransactionWriter.errorlog.info(localException);
			  status="failed in service layer";
		   }
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response getPeriodByDays(int userid, int connectionid, String datastoreName,int schoolId,
			int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try{	
			MDValidation mdv = new MDValidation();  
			int ret =mdv.allvalidations(userid, connectionid, datastoreName,schoolId,branchId);
		   System.out.println("verifiedvalue::"+ret);
		   
		   MDGetUserFromID mdgufid = new MDGetUserFromID();
		   String requester = mdgufid.getUserName(userid);
		if(ret==1 )//&& rtVal==1)
		{
			PeriodDao ex=new PeriodDao();
			/*status=ex.getAllPeriod();*/
			 status=ex.getPeriodByDays(schoolId,branchId);
			System.out.println(status);
			
			System.out.println(status);
			String endDate=dateFormat.format(new Date());
			  Long el=System.currentTimeMillis();
			 MDTransactionWriter.writeLog(datastoreName,"PeriodService_getPeriodByDays",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		

		}else
		{
			status="you are not authorised user";
		}
		}catch(Exception localException)
		   {
			  MDTransactionWriter.errorlog.debug(localException);
			  MDTransactionWriter.errorlog.info(localException);
			  status="failed in service layer";
		   }
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}
	// sectionperiods
	public Response addSectionPeriods(SectionPeriod sectionPeriod,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		 MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
			String status=null;
		    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date date = new Date();
			String startDate=dateFormat.format(date);
			Long sl=System.currentTimeMillis();
			sectionPeriod.setSchoolId(schoolId);
			sectionPeriod.setBranchId(branchId);
			try
			{
				MDValidation mdv = new MDValidation();  
				  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
				   System.out.println("verifiedvalue::"+ret);
				   MDGetUserFromID mdgufid = new MDGetUserFromID();
				   String requester = mdgufid.getUserName(userID);
				   
			if(ret==1 )//&& rtVal==1)
			{
					PeriodDao brdao=new PeriodDao();
					status=brdao.addSectionPeriods(sectionPeriod);
					System.out.println(status);
					String endDate=dateFormat.format(new Date());
					Long el=System.currentTimeMillis();
					MDTransactionWriter.writeLog(datastoreName,"PeriodService_addSectionPeriods",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());
			}else
			{
				status="you are not authorised user";
			}
			}
			
			catch(Exception localException)
			{
				MDTransactionWriter.errorlog.debug(localException);
				MDTransactionWriter.errorlog.info(localException);
				status="failed in service layer";
			}
		
			return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
		
	}
	}


