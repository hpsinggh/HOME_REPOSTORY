package com.gwebitsol.core.curriculum;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.springframework.stereotype.Component;
import com.gwebitsol.core.security.MDValidation;
import com.gwebitsol.core.usermanagement.MDGetUserFromID;
import com.gwebitsol.core.util.MDTransactionWriter;
@Component
public class CurriculamServiceImpl implements CurriculamServiceInf{
	
	@Context 
	private HttpServletRequest hsr;
	public Response addCurriculum(Curriculum curriculum,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
				
					MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
				
					String status=null;
					DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					Date date = new Date();
					String startDate=dateFormat.format(date);
					Long sl=System.currentTimeMillis();
					curriculum.setSchoolId(schoolId);
					curriculum.setBranchId(branchId);
						try
							{	MDValidation mdv = new MDValidation();  
							  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
							   System.out.println("verifiedvalue::"+ret);
							   
							   MDGetUserFromID mdgufid = new MDGetUserFromID();
							   String requester = mdgufid.getUserName(userID);
							if(ret==1 ){
							 CurriculamDaoImpl dao= new CurriculamDaoImpl();
								status=dao.addCurriculum(curriculum);
								String endDate=dateFormat.format(new Date());
								Long el=System.currentTimeMillis();
								MDTransactionWriter.writeLog(datastoreName,"CurriculamServiceImpl_addCurriculum",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
							}else
							{
								status="you are not authorised user";
							}
						}catch(Exception localException)
								{
									MDTransactionWriter.errorlog.debug(localException);
									MDTransactionWriter.errorlog.info(localException);
									status="failed in service layer";
									System.out.println(localException);
								}
				
						return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
				}
	
	
	public Response deleteCurriculum(int curriculumId,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		
		try
	{	
			MDValidation mdv = new MDValidation();  
			  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			   System.out.println("verifiedvalue::"+ret);
			   
			   MDGetUserFromID mdgufid = new MDGetUserFromID();
			   String requester = mdgufid.getUserName(userID);
			if(ret==1 ){
	
			CurriculamDaoImpl dao= new CurriculamDaoImpl();
		status=dao.deleteCurriculum(curriculumId,schoolId, branchId);
		
		String endDate=dateFormat.format(new Date());	
		Long el=System.currentTimeMillis();
		//status="user validation successfull";
			MDTransactionWriter.writeLog(datastoreName,"CurriculamServiceImpl_deleteCurriculum",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
	}else
	{
		status="you are not authorised user";
	}
	}
	catch(Exception localException)
	{
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
		status="failed in service layer";
	}
return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();	
}
	public Response updateCurriculum(Curriculum curriculum,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		curriculum.setSchoolId(schoolId);
		curriculum.setBranchId(branchId);
		try
		{	
			MDValidation mdv = new MDValidation();  
		  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
		   System.out.println("verifiedvalue::"+ret);
		   
		   MDGetUserFromID mdgufid = new MDGetUserFromID();
		   String requester = mdgufid.getUserName(userID);
		if(ret==1 ){
			CurriculamDaoImpl dao=new CurriculamDaoImpl();
		   status=dao.updateCurriculum(curriculum,schoolId, branchId);
		  String endDate=dateFormat.format(new Date());
		  Long el=System.currentTimeMillis();
		  //status="user validation successfull";
		  MDTransactionWriter.writeLog(datastoreName,"CurriculamServiceImpl_updateCurriculum",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
		}else
		{
			status="you are not authorised user";
		}
		}
		  catch(Exception localException)
		   {
			  MDTransactionWriter.errorlog.debug(localException);
			  MDTransactionWriter.errorlog.info(localException);
			  status="failed in service layer";
		   }
    return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}
	
	
	public Response getAllCurriculums(int userID, int connectionID,String datastoreName,int PNO, int size,int schoolId,int branchId,int classId,int sectionId,int subjectTypeId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());				
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try{
			MDValidation mdv = new MDValidation();  
			  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			   System.out.println("verifiedvalue::"+ret);
			   
			   MDGetUserFromID mdgufid = new MDGetUserFromID();
			   String requester = mdgufid.getUserName(userID);
			if(ret==1 ){
		
			CurriculamDaoImpl dao=new CurriculamDaoImpl();
			   status=dao.getAllCurriculums( PNO, size,schoolId, branchId,classId, sectionId, subjectTypeId);
			System.out.println(status);
			String endDate=dateFormat.format(new Date());
			  Long el=System.currentTimeMillis();
			 MDTransactionWriter.writeLog(datastoreName,"CurriculamServiceImpl_getAllCurriculums",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
			}
			 else
				{
					status="you are not authorised user";
				}
			}catch(Exception localException)
		   {
			  MDTransactionWriter.errorlog.debug(localException);
			  MDTransactionWriter.errorlog.info(localException);
			  status="failed in service layer";
		   }
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}
	
	
	public Response getByIdCurriculum(int curriculumId,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
			MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
			
			String status=null;
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date date = new Date();
			String startDate=dateFormat.format(date);
			Long sl=System.currentTimeMillis();
			try
		{	
				MDValidation mdv = new MDValidation();  
				  int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
				   System.out.println("verifiedvalue::"+ret);
				   
				   MDGetUserFromID mdgufid = new MDGetUserFromID();
				   String requester = mdgufid.getUserName(userID);
				if(ret==1 ){
		
			CurriculamDaoImpl dao=new CurriculamDaoImpl();
				   status=dao.getByIdCurriculum(curriculumId,schoolId, branchId);
				 System.out.println(status);
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				//status1="user validation successfull";
				MDTransactionWriter.writeLog(datastoreName,"CurriculamServiceImpl_getByIdCurriculum",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
		}else
		{
			status="you are not authorised user";
		}
		}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			status="failed in service layer";
			//System.out.println(localException);
		  }
	 return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
		}


	}

