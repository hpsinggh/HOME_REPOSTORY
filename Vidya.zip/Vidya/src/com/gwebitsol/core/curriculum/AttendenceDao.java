package com.gwebitsol.core.curriculum;


import java.util.Iterator;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class AttendenceDao {
	
	public String addAttendence(AttendencePojo attendencePojo) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		String strg= null;
		 StringBuffer sb= new StringBuffer();
		 try {
				tx = rdSession.beginTransaction();
				/*Integer i=(Integer) rdSession.save(attendencePojo);	 
				System.out.println(i);
				tx.commit();*/
				
			/*	Classes classSelected=(Classes)classItr.next();
					int clsid=classSelected.getClassId();
					List sectionsList=classSelected.getSections();
					Iterator secItr=sectionsList.iterator();
				
					while(secItr.hasNext())
					{
						Section sec=(Section)secItr.next();
						if("".equalsIgnoreCase(secids)){
						 secids+=sec.getSectionId();
						 ttids+=sec.getTimeTableId();
						}else{
							secids+=","+sec.getSectionId();
							 ttids+=","+sec.getTimeTableId();
						}
							*/
				  int clsid=attendencePojo.getClassId();
				  int secid=attendencePojo.getSectionId();
				  int empid=attendencePojo.getEmployeeId();
				  String dte=attendencePojo.getDate();
				  int sclid=attendencePojo.getSchoolId();
				  int brnid=attendencePojo.getBranchId();
				  String pedid=attendencePojo.getPeriodId();
				  String prst=attendencePojo.getPresent();
				  	String stuid=attendencePojo.getStudentId();
				  	String mdate=attendencePojo.getModifiedDate();
	
				Query icQuery=rdSession.createSQLQuery("CALL `attendance`('"+clsid+"', '"+secid+"', '"+empid+"', '"+dte+"',"
						+ " '"+prst+"', '"+stuid+"', '"+sclid+"', '"+brnid+"', '"+pedid+"','"+mdate+"')");
				icQuery.executeUpdate();
				tx.commit();
				sb.append("<attendence>");
				sb.append("\n");
				//sb.append("<attendenceids>");
				//sb.append(i);
				sb.append("successfully attendence inserted");
				sb.append("\n");
				sb.append("</attendence>");
				strg= sb.toString();
		 		}		
		 			catch (Exception localException){
		 						System.out.println(localException);
		 						localException.printStackTrace();
							   sb.append("<Response>");
							   sb.append("\n");
							   sb.append("<Result>");
							   sb.append("\n");
							   sb.append("Fail");
							   sb.append("\n");
							   sb.append("</Result>");
							   sb.append("\n");
							   sb.append("<Description>");
							   sb.append("could not inserted attandance info");
							   sb.append("</Description>");
							   sb.append("\n");
							   sb.append("<Exception>");
							   sb.append(localException);
							   sb.append("</Exception>");
							   sb.append("</Response>");
							    strg=sb.toString();
							   MDTransactionWriter.exceptionlog.info(localException);
							  if (tx!=null)
							   tx.rollback();
							  } finally {
							   rdSession.close(); 
							  }
							  return strg;
							 }
		

	public String deleteAttendence(int attendanceId,int schoolId,int branchId) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb=new StringBuffer();
		String strg= null;
		try {
				tx = rdSession.beginTransaction();
				/*AttendencePojo attendence=new AttendencePojo();				
				attendence.setAttendenceId(id);
				rdSession.delete(attendence);	
				tx.commit();*/
				AttendencePojo ap = (AttendencePojo) rdSession.get(AttendencePojo.class,attendanceId);					   
				   rdSession.evict(ap);
				   if(schoolId==ap.getSchoolId()&&branchId==ap.getBranchId())
				   {
				   Query empQuery=rdSession.createSQLQuery("update gbl_sm_tbl_attendence set isDeleted='y' where attendenceId='"+attendanceId+"'");
				   empQuery.executeUpdate();
				   tx.commit();
				sb.append("<attendence>");
			    sb.append("\n");
			    sb.append("<id>");
				sb.append("\n");
				sb.append("attendence item deleted");
				sb.append("</id>");
				sb.append("\n");
				sb.append("</attendence>");
				strg= sb.toString();	
				}else{
					   strg = " attendence is not deleted";
					   sb.append("<attendence>");
					   sb.append(strg);
					   sb.append("</attendence>");
					    String str = sb.toString();
					    return str;
					   }
		}
				catch(Exception localException)
				{
					System.out.println(localException);
					localException.printStackTrace();
				   sb.append("<Response>");
				   sb.append("\n");
				   sb.append("<Result>");
				   sb.append("\n");
				   sb.append("Fail");
				   sb.append("\n");
				   sb.append("</Result>");
				   sb.append("\n");
				   sb.append("<Description>");
				   sb.append("could not deleted attandance item");
				   sb.append("</Description>");
				   sb.append("\n");
				   sb.append("<Exception>");
				   sb.append(localException);
				   sb.append("</Exception>");
				   sb.append("</Response>");
				   strg=sb.toString();
				   MDTransactionWriter.exceptionlog.info(localException);
				  if (tx!=null)
				   tx.rollback();
				  } finally {
				   rdSession.close(); 
				  }
				  return strg;
				 }
			
	public String updateAttendence(AttendencePojo attendencePojo,int schoolId,int branchId) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb= new StringBuffer();
		String strg= null;
		try {
				tx = rdSession.beginTransaction();
				/*rdSession.update(attendencePojo);
				tx.commit();*/
				AttendencePojo ap = (AttendencePojo) rdSession.get(AttendencePojo.class,attendencePojo.getAttendenceId());
				rdSession.evict(ap);
				  if(schoolId==ap.getSchoolId()&&branchId==ap.getBranchId())
				   rdSession.update(attendencePojo); 
				   tx.commit();
				sb.append("<attendence>");
				sb.append("\n");
			    sb.append("<attendenceid>");
				sb.append("\n");
				sb.append("attendence succssfully updated");
				sb.append("</attendenceid>");
				sb.append("\n");
				sb.append("</attendence>");
				strg= sb.toString();		
				}
			catch (Exception localException) {
					System.out.println(localException);
					localException.printStackTrace();
				   sb.append("<Response>");
				   sb.append("\n");
				   sb.append("<Result>");
				   sb.append("\n");
				   sb.append("Fail");
				   sb.append("\n");
				   sb.append("</Result>");
				   sb.append("\n");
				   sb.append("<Description>");
				   sb.append("could not update attandance item");
				   sb.append("</Description>");
				   sb.append("\n");
				   sb.append("<Exception>");
				   sb.append(localException);
				   sb.append("</Exception>");
				   sb.append("</Response>");
				   strg=sb.toString();
				   MDTransactionWriter.exceptionlog.info(localException);
				  if (tx!=null)
				   tx.rollback();
				  } finally {
				   rdSession.close(); 
				  }
				  return strg;
				 }
						
/*
	public String getAllAttendence(){
		StringBuffer sb= new StringBuffer();
		String strg=null;
		AttendencePojo sub=null;
						
		try
			{
				tx = rdSession.beginTransaction();
				@SuppressWarnings("unchecked")
				List<AttendencePojo> list=rdSession.createCriteria(AttendencePojo.class).list();
				sb.append("<Attendence>");
				for(Iterator<AttendencePojo> it=list.iterator();it.hasNext();){
				sub=(AttendencePojo)it.next();
				if(sub==null){
								System.out.println("there is no Attendence object");
								}else{
										sb.append("\n");
								        sb.append("<attendenceId>");
									    sb.append(sub.getAttendenceId());
									    sb.append("</attendenceId>");
									    sb.append("\n");
								        sb.append("<studentId>");
									    sb.append(sub.getStudentId());
									    sb.append("</studentId>");
									    sb.append("\n");
									    sb.append("<periodId>");
										sb.append(sub.getPeriodId());
										sb.append("</periodId>");
										sb.append("\n");
										sb.append("<date>");
										sb.append(sub.getDate());
										sb.append("</date>");
										sb.append("\n");
										sb.append("<employeeId>");
										sb.append(sub.getEmployeeId());
										sb.append("</employeeId>");
										sb.append("\n");
								        sb.append("<present>");
									    sb.append(sub.getPresent());
									    sb.append("</present>");
									    sb.append("\n");								
								        sb.append("<ClassId>");
									    sb.append(sub.getClassId());
									    sb.append("</ClassId>");						
									    sb.append("\n");
								        sb.append("<sectionId>");
									    sb.append(sub.getSectionId());
									    sb.append("</sectionId>");
									    sb.append("\n");
									    sb.append("<createdDate>");
									    sb.append(sub.getCreatedDate());
									    sb.append("</createdDate>");
									    sb.append("<modifiedDate>");
									    sb.append(sub.getModifiedDate());
									    sb.append("</modifiedDate>");
							}
						}
							sb.append("</Attendence>");
							String str= sb.toString();
							 tx.commit();
							 return str;
						}
						catch(Exception localException)
						{
							System.out.println(localException);
							localException.printStackTrace();
						   sb.append("<Response>");
						   sb.append("\n");
						   sb.append("<Result>");
						   sb.append("\n");
						   sb.append("Fail");
						   sb.append("\n");
						   sb.append("</Result>");
						   sb.append("\n");
						   sb.append("<Description>");
						   sb.append("could not getall attandance items");
						   sb.append("</Description>");
						   sb.append("\n");
						   sb.append("<Exception>");
						   sb.append(localException);
						   sb.append("</Exception>");
						   sb.append("</Response>");
						   strg=sb.toString();
						   MDTransactionWriter.exceptionlog.info(localException);
						  if (tx!=null)
						   tx.rollback();
						  } finally {
						   rdSession.close(); 
						  }
						  return strg;
						 }*/

	@SuppressWarnings("rawtypes")
	public String getByIdAttendence(int attendanceId,int schoolId,int branchId) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb= new StringBuffer();
		String strg= null;
		try{
			tx = rdSession.beginTransaction();
			Query query=rdSession.createSQLQuery("SELECT atdn.AttendenceId,atdn.PeriodId,period.PeriodTitle,atdn.StudentId,stu.StudentNumber,stu.FirstName,stu.MiddleName,stu.LastName,atdn.ClassId,cls.ClassName,atdn.SectionId,sec.SectionName,atdn.Date,atdn.Present,atdn.CreatedDate,atdn.ModifiedDate,atdn.SchoolId,atdn.BranchId,atdn.EmployeeId FROM gbl_sm_tbl_attendence as atdn left outer join gbl_sm_tbl_period as period on atdn.PeriodId=period.PeriodId left outer join gbl_sm_tbl_section as sec on atdn.SectionId=sec.SectionId left outer join gbl_sm_tbl_class as cls on atdn.ClassId=cls.ClassId left outer join gbl_sm_tbl_student as stu  on atdn.StudentId=stu.StudentId  where  (atdn.isDeleted<>'y' or atdn.isDeleted is null) "
			     		+ " and atdn.AttendenceId='"+attendanceId+"' and atdn.schoolId='"+schoolId+"' and atdn.branchId='"+branchId+"'");
		    List gcList=query.list();
		    Iterator gsIT=gcList.iterator();
		     while(gsIT.hasNext())
		     {
		      Object[] mdcArr=(Object[])gsIT.next();
		  
		      sb.append("<attendence>");
		      sb.append("\n");
		      sb.append("<attendenceId>"+mdcArr[0]+"</attendenceId>");
		      sb.append("\n");
		      sb.append("<periodId>" + mdcArr[1]+ "</periodId>");
		      sb.append("\n");
		      sb.append("<periodTitle>" + mdcArr[2] + "</periodTitle>");
		      sb.append("\n");
		      sb.append("<studentId>" + mdcArr[3]+ "</studentId>");
		      sb.append("\n");
		      sb.append("<studentNumber>" + mdcArr[4]+ "</studentNumber>");
		      sb.append("\n");
		      sb.append("<firstName>" + mdcArr[5] + "</firstName>");
		      sb.append("\n");
		      sb.append("<middleName>" + mdcArr[6]+ "</middleName>");
		      sb.append("\n");
		      sb.append("<lastName>" + mdcArr[7] + "</lastName>");
		      sb.append("\n");
		      sb.append("<classId>" + mdcArr[8]+ "</classId>");
		      sb.append("\n");
		      sb.append("<className>" + mdcArr[9]+ "</className>");
		      sb.append("\n");
		      sb.append("<sectionId>" + mdcArr[10] + "</sectionId>");
		      sb.append("\n");
		      sb.append("<sectionName>" + mdcArr[11]+ "</sectionName>");
		      sb.append("\n");
		      sb.append("<date>" +  mdcArr[12]+ "</date>");
		      sb.append("\n");
		      sb.append("<present>" + mdcArr[13] + "</present>");
		      sb.append("\n");
		      sb.append("<createdDate>" +  mdcArr[14]+ "</createdDate>");
		      sb.append("\n");
		      sb.append("<modifiedDate>" + mdcArr[15] + "</modifiedDate>");
		      sb.append("\n");	
		      sb.append("<schoolId>" + mdcArr[16] + "</schoolId>");
		      sb.append("\n");
		      sb.append("<branchId>" + mdcArr[17] + "</branchId>");
		      sb.append("\n");			  
		      sb.append("<employeeId>" + mdcArr[18] + "</employeeId>");
		      int employeeId=(Integer) mdcArr[18] ;
		      //sb.append("<studentId>" +studentId+ "</studentId>");
		      //sb.append("\n");
		      if(employeeId!=0)			    	
		      {
		       String gsSql="select staff.EmployeeId,staff.StaffNumber,staff.FirstName,staff.MiddleName,staff.LastName from gbl_sm_tbl_staff as staff where (staff.isDeleted<>'y' or  staff.isDeleted is null) and staff.EmployeeId='"+employeeId+"'";
		       query = rdSession.createSQLQuery(gsSql);
				List parList1 = query.list();
				Iterator paIT = parList1.iterator();
				while (paIT.hasNext()) {
					Object[] paArr = (Object[]) paIT.next();
					
				      sb.append("<staffNumber>" + paArr[1] + "</staffNumber>");
				      sb.append("\n");
				      sb.append("<firstName>" + paArr[2] + "</firstName>");
				      sb.append("\n");
				      sb.append("<middleName>" + paArr[3]+ "</middleName>");
				      sb.append("\n");
				      sb.append("<lastName>" + paArr[4] + "</lastName>");
				      sb.append("\n");					
				}
		      }else{
		    	  sb.append("<staffNumber></staffNumber>");
					sb.append("\n");
					sb.append("<firstName></firstName>");
					sb.append("\n");
					sb.append("<middleName></middleName>");
					sb.append("\n");
					sb.append("<lastName></lastName>");
					sb.append("\n");
		      }
		      sb.append("\n");
		      sb.append("</attendence>");
				String str= sb.toString();
				return str;
		}
							} 	catch (Exception localException) {
								System.out.println(localException);
								localException.printStackTrace();
							   sb.append("<Response>");
							   sb.append("\n");
							   sb.append("<Result>");
							   sb.append("\n");
							   sb.append("Fail");
							   sb.append("\n");
							   sb.append("</Result>");
							   sb.append("\n");
							   sb.append("<Description>");
							   sb.append("could not getby attandance item");
							   sb.append("</Description>");
							   sb.append("\n");
							   sb.append("<Exception>");
							   sb.append(localException);
							   sb.append("</Exception>");
							   sb.append("</Response>");
							   strg=sb.toString();
							   MDTransactionWriter.exceptionlog.info(localException);
							  if (tx!=null)
							   tx.rollback();
							  } finally {
							   rdSession.close(); 
							  }
							  return strg;
							 }
	

		@SuppressWarnings("rawtypes")
		public String getAllAttendence(int PNO, int size,int schoolId,int branchId,int classId,int sectionId,String AttendenceDate) {
			  
			  String xmlString=null;
			  Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
			  Transaction stgTx=null;
			  StringBuffer sb = new StringBuffer();
			  try
			  {
			   stgTx=stgSession.beginTransaction();
			    int fset = (PNO-1)*size;
			    String filterWhere="";
			    if(classId!=0){
			    	filterWhere+=" and atdn.ClassId="+classId;	
			    	if(sectionId!=0){
						filterWhere +=  " and atdn.SectionId="+sectionId;
			    	}
			    }
					if(AttendenceDate != null ){
						filterWhere += " and atdn.date in('"+AttendenceDate+"')";
			    }
			    
			    String gsSql ="SELECT count(*) FROM gbl_sm_tbl_attendence as atdn left outer join gbl_sm_tbl_period as period on atdn.PeriodId=period.PeriodId left outer join gbl_sm_tbl_section as sec on atdn.SectionId=sec.SectionId left outer join gbl_sm_tbl_class as cls on atdn.ClassId=cls.ClassId left outer join gbl_sm_tbl_student as stu  on atdn.StudentId=stu.StudentId  where  (atdn.isDeleted<>'y' or atdn.isDeleted is null) and atdn.schoolId='"+schoolId+"' and atdn.branchId='"+branchId+"'"+filterWhere+"";
			    Query gsQuery=stgSession.createSQLQuery(gsSql);
			    Object noRecords= gsQuery.uniqueResult();
			    sb.append("<Attendences>");
			    sb.append("\n");
			    sb.append("<noRecords>"+noRecords+"</noRecords>");
			    sb.append("\n");			    
			     if (PNO > 0 & size > 0){
			     gsSql="SELECT atdn.AttendenceId,atdn.PeriodId,period.PeriodTitle,atdn.StudentId,stu.StudentNumber,stu.FirstName,stu.MiddleName,stu.LastName,atdn.ClassId,cls.ClassName,atdn.SectionId,sec.SectionName,atdn.Date,atdn.Present,atdn.CreatedDate,atdn.ModifiedDate,atdn.SchoolId,atdn.BranchId,atdn.EmployeeId FROM gbl_sm_tbl_attendence as atdn left outer join gbl_sm_tbl_period as period on atdn.PeriodId=period.PeriodId left outer join gbl_sm_tbl_section as sec on atdn.SectionId=sec.SectionId left outer join gbl_sm_tbl_class as cls on atdn.ClassId=cls.ClassId left outer join gbl_sm_tbl_student as stu  on atdn.StudentId=stu.StudentId  where  (atdn.isDeleted<>'y' or atdn.isDeleted is null) and atdn.schoolId='"+schoolId+"' and atdn.branchId='"+branchId+"'"+filterWhere+" limit "+size+" offset "+fset;
			     }
			     else {
			      gsSql="SELECT atdn.AttendenceId,atdn.PeriodId,period.PeriodTitle,atdn.StudentId,stu.StudentNumber,stu.FirstName,stu.MiddleName,stu.LastName,atdn.ClassId,cls.ClassName,atdn.SectionId,sec.SectionName,atdn.Date,atdn.Present,atdn.CreatedDate,atdn.ModifiedDate,atdn.SchoolId,atdn.BranchId,atdn.EmployeeId FROM gbl_sm_tbl_attendence as atdn left outer join gbl_sm_tbl_period as period on atdn.PeriodId=period.PeriodId left outer join gbl_sm_tbl_section as sec on atdn.SectionId=sec.SectionId left outer join gbl_sm_tbl_class as cls on atdn.ClassId=cls.ClassId left outer join gbl_sm_tbl_student as stu  on atdn.StudentId=stu.StudentId  where  (atdn.isDeleted<>'y' or atdn.isDeleted is null) and  atdn.schoolId='"+schoolId+"' and atdn.branchId='"+branchId+"'"+filterWhere+" order by classId,sectionId,date desc";
			     } 			   
			    gsQuery=stgSession.createSQLQuery(gsSql);
			    List gcList=gsQuery.list();
			    Iterator gsIT=gcList.iterator();
			     while(gsIT.hasNext())
			     {
			      Object[] mdcArr=(Object[])gsIT.next();
			      sb.append("<attendence>");
			      sb.append("\n");
			      sb.append("<attendenceId>"+mdcArr[0]+"</attendenceId>");
			      sb.append("\n");
			      sb.append("<periodId>" + mdcArr[1]+ "</periodId>");
			      sb.append("\n");
			      sb.append("<periodTitle>" + mdcArr[2] + "</periodTitle>");
			      sb.append("\n");
			      sb.append("<studentId>" + mdcArr[3]+ "</studentId>");
			      sb.append("\n");
			      sb.append("<studentNumber>" + mdcArr[4]+ "</studentNumber>");
			      sb.append("\n");
			      sb.append("<firstName>" + mdcArr[5] + "</firstName>");
			      sb.append("\n");
			      sb.append("<middleName>" + mdcArr[6]+ "</middleName>");
			      sb.append("\n");
			      sb.append("<lastName>" + mdcArr[7] + "</lastName>");
			      sb.append("\n");
			      sb.append("<classId>" + mdcArr[8]+ "</classId>");
			      sb.append("\n");
			      sb.append("<className>" + mdcArr[9]+ "</className>");
			      sb.append("\n");
			      sb.append("<sectionId>" + mdcArr[10] + "</sectionId>");
			      sb.append("\n");
			      sb.append("<sectionName>" + mdcArr[11]+ "</sectionName>");
			      sb.append("\n");
			      sb.append("<date>" +  mdcArr[12]+ "</date>");
			      sb.append("\n");
			      sb.append("<present>" + mdcArr[13] + "</present>");
			      sb.append("\n");
			      sb.append("<createdDate>" +  mdcArr[14]+ "</createdDate>");
			      sb.append("\n");
			      sb.append("<modifiedDate>" + mdcArr[15] + "</modifiedDate>");
			      sb.append("\n");	
			      sb.append("<schoolId>" + mdcArr[16] + "</schoolId>");
			      sb.append("\n");
			      sb.append("<branchId>" + mdcArr[17] + "</branchId>");
			      sb.append("\n");			  
			      sb.append("<employeeId>" + mdcArr[18] + "</employeeId>");
			      int employeeId=(Integer) mdcArr[18] ;
			      //sb.append("<studentId>" +studentId+ "</studentId>");
			      //sb.append("\n");
			      if(employeeId!=0)			    	
			      {
			       gsSql="select staff.EmployeeId,staff.StaffNumber,staff.FirstName,staff.MiddleName,staff.LastName from gbl_sm_tbl_staff as staff where (staff.isDeleted<>'y' or  staff.isDeleted is null) and staff.EmployeeId='"+employeeId+"'";
			       gsQuery = stgSession.createSQLQuery(gsSql);
					List parList1 = gsQuery.list();
					Iterator paIT = parList1.iterator();
					while (paIT.hasNext()) {
						Object[] paArr = (Object[]) paIT.next();
						
					      sb.append("<staffNumber>" + paArr[1] + "</staffNumber>");
					      sb.append("\n");
					      sb.append("<firstName>" + paArr[2] + "</firstName>");
					      sb.append("\n");
					      sb.append("<middleName>" + paArr[3]+ "</middleName>");
					      sb.append("\n");
					      sb.append("<lastName>" + paArr[4] + "</lastName>");
					      sb.append("\n");					
					}
			      }else{
			    	  sb.append("<staffNumber></staffNumber>");
						sb.append("\n");
						sb.append("<firstName></firstName>");
						sb.append("\n");
						sb.append("<middleName></middleName>");
						sb.append("\n");
						sb.append("<lastName></lastName>");
						sb.append("\n");
			      }
			      sb.append("\n");
			      sb.append("</attendence>");
			      sb.append("\n");
			     }
			    stgTx.commit();
			    sb.append("</Attendences>");
			    sb.append("\n");
			    xmlString=sb.toString();
			   }
			  
			  catch(Exception localException)
			  {
			   stgTx.rollback();
			   localException.printStackTrace();
			   xmlString = "fail";
			   System.out.println("Could not Get attendances");
			  }
			  finally
			  {
			   stgSession.close();
			  } 
			  return xmlString;

		}

}
