package com.gwebitsol.core.curriculum;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="SectionPeriods")
public class SectionPeriod {
	int sectionPeriodsId;
	int classId;
	int sectionId;
	int periods;
	String weekday;
	int schoolId;
	int branchId;
	
	public int getSchoolId() {
		return schoolId;
	}
	public void setSchoolId(int schoolId) {
		this.schoolId = schoolId;
	}
	public int getBranchId() {
		return branchId;
	}
	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}
	public int getSectionPeriodsId() {
		return sectionPeriodsId;
	}
	public void setSectionPeriodsId(int sectionPeriodsId) {
		this.sectionPeriodsId = sectionPeriodsId;
	}
	public int getClassId() {
		return classId;
	}
	public void setClassId(int classId) {
		this.classId = classId;
	}
	public int getSectionId() {
		return sectionId;
	}
	public void setSectionId(int sectionId) {
		this.sectionId = sectionId;
	}
	public int getPeriods() {
		return periods;
	}
	public void setPeriods(int periods) {
		this.periods = periods;
	}
	public String getWeekday() {
		return weekday;
	}
	public void setWeekday(String weekday) {
		this.weekday = weekday;
	}

}
