package com.gwebitsol.core.taskactionitem;

import java.text.DateFormat;

import java.text.SimpleDateFormat;
import java.util.Date;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement(name="TaskActionItems")
public class TaskActionItem {
	private int actionItemId;
	private String assignedTo;
	private String actionTitle;
	private String actionDescritpoin;
	private String status;
	private String requestedDateTime;
	private String completionDateTime;
	private String remarks;
	private String createdDate; 
	private int schoolId;
	private int branchId;
	
	DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	Date date = new Date();
	String modifiedDate=dateFormat.format(date);
	
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public int getActionItemId() {
		return actionItemId;
	}
	public void setActionItemId(int actionItemId) {
		this.actionItemId = actionItemId;
	}
	public String getAssignedTo() {
		return assignedTo;
	}
	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}
	public String getActionTitle() {
		return actionTitle;
	}
	public void setActionTitle(String actionTitle) {
		this.actionTitle = actionTitle;
	}
	public String getActionDescritpoin() {
		return actionDescritpoin;
	}
	public void setActionDescritpoin(String actionDescritpoin) {
		this.actionDescritpoin = actionDescritpoin;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRequestedDateTime() {
		return requestedDateTime;
	}
	public void setRequestedDateTime(String requestedDateTime) {
		this.requestedDateTime = requestedDateTime;
	}
	public String getCompletionDateTime() {
		return completionDateTime;
	}
	public void setCompletionDateTime(String completionDateTime) {
		this.completionDateTime = completionDateTime;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public int getSchoolId() {
		return schoolId;
	}
	public void setSchoolId(int schoolId) {
		this.schoolId = schoolId;
	}
	public int getBranchId() {
		return branchId;
	}
	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}
}
