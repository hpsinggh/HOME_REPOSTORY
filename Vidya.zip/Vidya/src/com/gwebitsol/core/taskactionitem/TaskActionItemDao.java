package com.gwebitsol.core.taskactionitem;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.note.Note;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class TaskActionItemDao {
	
	public String addAction(TaskActionItem tai) {
		Session addempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction addempTx=null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			addempTx=addempSession.beginTransaction();
			Integer in=(Integer)addempSession.save(tai);
			System.out.println(in);
			addempTx.commit();
			sb.append("<TaskActionItem>");
			sb.append("\n");
			sb.append("<actionItemId>");
			sb.append(in);
			sb.append("</actionItemId>");
			sb.append("</TaskActionItem>");
			outStr=sb.toString();
   		 	}
		catch(Exception localException)
		{
				System.out.println(localException);
				sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    sb.append("could not inserted actionItemId info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    outStr= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (addempTx!=null)
				  addempTx.rollback();
		}
		finally
		{			
			addempSession.close();
		}
		return outStr;
	}
	public String deleteAction(int actionItemId,int schoolId,int branchId) {
		Session delempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction delempTx=null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			delempTx=delempSession.beginTransaction();
			TaskActionItem answer = (TaskActionItem) delempSession.get(TaskActionItem.class,actionItemId);
			   int branid = answer.getBranchId();
			   int sclid = answer.getSchoolId();
			   delempSession.evict(answer);             
			   if(branchId==branid&&schoolId==sclid)
			   {
			Query empQuery=delempSession.createSQLQuery("update gbl_tbl_task_action_item set IsDeleted ='Y' where actionItemId='"+actionItemId+"'");
			empQuery.executeUpdate();
			delempTx.commit();
			sb.append("<TaskActionItem>");
			sb.append("\n");
			sb.append("deleted sucessfully");
			sb.append("</TaskActionItem>");
			String str=sb.toString();
			return str;
   		 	}
		}
		catch(Exception localException)
		{
			System.out.println(localException);
			    sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    sb.append("could not delete TaskActionItem info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    outStr= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (outStr!=null)
				  delempTx.rollback();
		}
		finally
		{			
			delempSession.close();
		}
		return outStr;
	}
	public String updateAction(TaskActionItem tai,int schoolId,int branchId) {
		Session upempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction upempTx=null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			upempTx=upempSession.beginTransaction();
			TaskActionItem answer = (TaskActionItem) upempSession.get(TaskActionItem.class,tai.getActionItemId());
			   
			if(branchId==answer.getBranchId()&&schoolId==answer.getSchoolId())
			    
				upempSession.evict(answer);
	        upempSession.update(tai);
			upempTx.commit();
			sb.append("<TaskActionItem>");
			sb.append("\n");
			sb.append("update sucessfully");
			sb.append("</TaskActionItem>");
			String str=sb.toString();
			return str;
   		 	}
		catch(Exception localException)
		{
			System.out.println(localException);
			    sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    sb.append("could not updateAction info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    outStr= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (outStr!=null)
				  upempTx.rollback();
		}
		finally
		{			
			upempSession.close();
		}
		return outStr;
	}
	public String getAllActions(int PNO, int size,int schoolId,int branchId) {
		Session rdSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb= new StringBuffer();
		String string=null;
		try
		{
			tx = rdSession.beginTransaction();
			
			 if(("all") != null)
			   {
			    int fset = (PNO-1)*size;
			    String gsSql ="select count(*) from gbl_tbl_task_action_item";
			    Query gsQuery=rdSession.createSQLQuery(gsSql);
			    Object noRecords= gsQuery.uniqueResult();
			    sb.append("<Actions>");
			    sb.append("\n");
			    sb.append("<noRecords>"+noRecords+"</noRecords>");
			    sb.append("\n");
			     if (PNO > 0 & size > 0){
			     gsSql="Select ai.ActionItemId,ai.AssignedTo,em.FIRSTNAME,em.MIDDLENAME,em.LASTNAME,ai.ActionTitle,ai.ActionDescritpoin,ai.`Status`,ai.RequestedDateTime,ai.CompletionDateTime,ai.Remarks,ai.CreatedDate,ai.ModifiedDate,ai.SchoolId,ai.BranchId from gbl_tbl_task_action_item as ai join mdemployees as em on ai.AssignedTo = em.EMPLOYEEID where ai.IsDeleted <> 'Y' or ai.IsDeleted IS NULL and ai.SchoolId ='" + schoolId + "'  and ai.BranchId ='" + branchId + "' limit "+size+" offset "+fset;}
			     else {
			      gsSql="Select ai.ActionItemId,ai.AssignedTo,em.FIRSTNAME,em.MIDDLENAME,em.LASTNAME,ai.ActionTitle,ai.ActionDescritpoin,ai.`Status`,ai.RequestedDateTime,ai.CompletionDateTime,ai.Remarks,ai.CreatedDate,ai.ModifiedDate,ai.SchoolId,ai.BranchId from gbl_tbl_task_action_item as ai join mdemployees as em on ai.AssignedTo = em.EMPLOYEEID where ai.IsDeleted <> 'Y' or ai.IsDeleted IS NULL and ai.SchoolId ='" + schoolId + "'  and ai.BranchId ='" + branchId + "'";
			     } 
			    gsQuery=rdSession.createSQLQuery(gsSql);
			    List gcList=gsQuery.list();
			    Iterator gsIT=gcList.iterator();
			    while(gsIT.hasNext())
			     {
			    	 Object[] ex=(Object[])gsIT.next();
			    	 sb.append("<Action>");
			         sb.append("\n");
			      	 sb.append("<actionItemId>");
			         sb.append(ex[0]);
			         sb.append("</actionItemId>");
			         sb.append("\n");
			         sb.append("<assignedTo>");
			         sb.append(ex[1]);
			         sb.append("</assignedTo>");
			         sb.append("\n");
			         sb.append("<firstName>");
			         sb.append(ex[2]);
			         sb.append("</firstName>");
			         sb.append("\n");
			         sb.append("<middleName>");
			         sb.append(ex[3]);
			         sb.append("</middleName>");
			         sb.append("\n");
			      	 sb.append("<lastName>");
			         sb.append(ex[4]);
			         sb.append("</lastName>");
			         sb.append("\n");
			         sb.append("<actionTitle>");
			         sb.append(ex[5]);
			         sb.append("</actionTitle>");
			         sb.append("\n");
			         sb.append("<actionDescritpoin>");
			         sb.append(ex[6]);
			         sb.append("</actionDescritpoin>");
			         sb.append("\n");
			         sb.append("<status>");
			         sb.append(ex[7]);
			         sb.append("</status>");
			         sb.append("\n");
			         sb.append("<requestedDateTime>");
			         sb.append(ex[8]);
			         sb.append("</requestedDateTime>");
			         sb.append("\n");
			         sb.append("<completionDateTime>");
			         sb.append(ex[9]);
			         sb.append("</completionDateTime>");
			         sb.append("\n");
			         sb.append("<remarks>");
			         sb.append(ex[10]);
			         sb.append("</remarks>");
			         sb.append("\n");
			         sb.append("<createdDate>");
			         sb.append(ex[11]);
			         sb.append("</createdDate>");
			         sb.append("\n");
			         sb.append("<modifiedDate>");
			         sb.append(ex[12]);
			         sb.append("</modifiedDate>");
			         sb.append("\n");
			    	 sb.append("<schoolId>");
			         sb.append(ex[13]);
			         sb.append("</schoolId>");
			         sb.append("\n");
			    	 sb.append("<branchId>");
			         sb.append(ex[14]);
			         sb.append("</branchId>");
			         sb.append("\n");
			         sb.append("</Action>");
			}
		}
			sb.append("</Actions>");
					    String str= sb.toString();
						 tx.commit();
					return str;
		}
		catch(Exception localException)
		{
			System.out.println(localException);
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    sb.append("could not getall Notes info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    string= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (string!=null)
				  tx.rollback();
		}
		finally
		{
			rdSession.close();
		}
		return string;
	}
	public String getActionsbyactionitemid(int actionItemId,int schoolId,int branchId) {
		Session gtempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gtTx=null;
			StringBuffer sb= new StringBuffer();
			System.out.println("hi dao impl success");
			String strg= null;
				try {
						 gtTx = gtempSession.beginTransaction();
						 List list=gtempSession.createSQLQuery("Select ai.ActionItemId,ai.AssignedTo,em.FIRSTNAME,em.MIDDLENAME,em.LASTNAME,ai.ActionTitle,ai.ActionDescritpoin,ai.`Status`,ai.RequestedDateTime,ai.CompletionDateTime,ai.Remarks,ai.CreatedDate,ai.ModifiedDate,ai.SchoolId,ai.BranchId from gbl_tbl_task_action_item as ai join mdemployees as em on ai.AssignedTo = em.EMPLOYEEID where ai.IsDeleted <> 'Y' or ai.IsDeleted IS NULL and ActionItemId ='" + actionItemId + "' and ai.SchoolId ='" + schoolId + "'  and ai.BranchId ='" + branchId + "';").list();
					     Iterator it=list.iterator();
					     sb.append("<Actionbyactionitemids>");
					     sb.append("\n");
					     while(it.hasNext())
					     {
					      Object[] ex=(Object[])it.next();
					         sb.append("<Actionbyactionitemid>");
					         sb.append("\n");
					      	 sb.append("<actionItemId>");
					         sb.append(ex[0]);
					         sb.append("</actionItemId>");
					         sb.append("\n");
					         sb.append("<assignedTo>");
					         sb.append(ex[1]);
					         sb.append("</assignedTo>");
					         sb.append("\n");
					         sb.append("<firstName>");
					         sb.append(ex[2]);
					         sb.append("</firstName>");
					         sb.append("\n");
					         sb.append("<middleName>");
					         sb.append(ex[3]);
					         sb.append("</middleName>");
					         sb.append("\n");
					      	 sb.append("<lastName>");
					         sb.append(ex[4]);
					         sb.append("</lastName>");
					         sb.append("\n");
					         sb.append("<actionTitle>");
					         sb.append(ex[5]);
					         sb.append("</actionTitle>");
					         sb.append("\n");
					         sb.append("<actionDescritpoin>");
					         sb.append(ex[6]);
					         sb.append("</actionDescritpoin>");
					         sb.append("\n");
					         sb.append("<status>");
					         sb.append(ex[7]);
					         sb.append("</status>");
					         sb.append("\n");
					         sb.append("<requestedDateTime>");
					         sb.append(ex[8]);
					         sb.append("</requestedDateTime>");
					         sb.append("\n");
					         sb.append("<completionDateTime>");
					         sb.append(ex[9]);
					         sb.append("</completionDateTime>");
					         sb.append("\n");
					         sb.append("<remarks>");
					         sb.append(ex[10]);
					         sb.append("</remarks>");
					         sb.append("\n");
					         sb.append("<createdDate>");
					         sb.append(ex[11]);
					         sb.append("</createdDate>");
					         sb.append("\n");
					         sb.append("<modifiedDate>");
					         sb.append(ex[12]);
					         sb.append("</modifiedDate>");
					         sb.append("\n");
					    	 sb.append("<schoolId>");
					         sb.append(ex[13]);
					         sb.append("</schoolId>");
					         sb.append("\n");
					    	 sb.append("<branchId>");
					         sb.append(ex[14]);
					         sb.append("</branchId>");
					         sb.append("\n");
					         sb.append("</Actionbyactionitemid>");
					     	}
							 sb.append("</Actionbyactionitemids>");
							 strg= sb.toString();
				            } catch (Exception localException) {
					    System.out.println(localException);
					    sb.append("<Response>");
					    sb.append("\n");
					    sb.append("<Result>");
					    sb.append("\n");
					    sb.append("Fail");
					    sb.append("\n");
					    sb.append("</Result>");
					    sb.append("\n");
					    sb.append("<Description>");
					    sb.append("could not getActionbyid info");
					    sb.append("</Description>");
					    sb.append("\n");
					    sb.append("<Exception>");
					    sb.append(localException);
					    sb.append("</Exception>");
					    sb.append("</Response>");
					    sb.append("</noteId>");
					    sb.append("</Note>");
					    strg= sb.toString();
					   MDTransactionWriter.exceptionlog.info(localException);
					  if (strg!=null)
						  gtTx.rollback();
					} finally {
						gtempSession.close();
					}
			return strg;
	}

}
