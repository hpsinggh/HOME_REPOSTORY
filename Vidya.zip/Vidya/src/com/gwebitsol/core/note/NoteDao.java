package com.gwebitsol.core.note;
import java.util.Iterator;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.assessments.AnswerPojo;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;
public class NoteDao {
	
	public String addNote(Note nt) {
		Session addempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction addempTx=null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			addempTx=addempSession.beginTransaction();
			Integer in=(Integer)addempSession.save(nt);
			System.out.println(in);
			addempTx.commit();
			sb.append("<Note>");
			sb.append("\n");
			sb.append("<noteId>");
			sb.append(in);
			sb.append("</noteId>");
			sb.append("</Note>");
			outStr=sb.toString();
   		 	}
		catch(Exception localException)
		{
				System.out.println(localException);
				sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    sb.append("could not inserted noteId info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    outStr= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (addempTx!=null)
				  addempTx.rollback();
		}
		finally
		{			
			addempSession.close();
		}
		return outStr;
	}
	public String deleteNote(int noteId,int schoolId,int branchId) {
		Session delempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction delempTx=null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			delempTx=delempSession.beginTransaction();
			Note answer = (Note) delempSession.get(Note.class,noteId);
			   
			   int branid = answer.getBranchId();
			   int sclid = answer.getSchoolId();
			   delempSession.evict(answer);             
			   if(branchId==branid&&schoolId==sclid)
			   {
			Query empQuery=delempSession.createSQLQuery("update gbl_tbl_notes set IsDeleted ='Y' where noteId='"+noteId+"'");
			empQuery.executeUpdate();
			delempTx.commit();
			sb.append("<Note>");
			sb.append("\n");
			sb.append("deleted sucessfully");
			sb.append("</Note>");
			String str=sb.toString();
			return str;
   		 	}
		}
		catch(Exception localException)
		{
			System.out.println(localException);
			    sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    sb.append("could not delete Note info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    outStr= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (outStr!=null)
				  delempTx.rollback();
		}
		finally
		{			
			delempSession.close();
		}
		return outStr;
	}
	public String updateNote(Note nt,int schoolId,int branchId) {
		Session upempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction upempTx=null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			upempTx=upempSession.beginTransaction();
			Note answer = (Note) upempSession.get(Note.class,nt.getNoteId());
			   
			if(branchId==answer.getBranchId()&&schoolId==answer.getSchoolId())
			    
				upempSession.evict(answer);
	        upempSession.update(nt);
			upempTx.commit();
			sb.append("<Note>");
			sb.append("\n");
			sb.append("update sucessfully");
			sb.append("</Note>");
			String str=sb.toString();
			return str;
   		 	}
		catch(Exception localException)
		{
			System.out.println(localException);
			    sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    sb.append("could not update Note info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    outStr= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (outStr!=null)
				  upempTx.rollback();
		}
		finally
		{			
			upempSession.close();
		}
		return outStr;
	}
	public String getAllNote(int PNO, int size,int schoolId,int branchId) {
		Session rdSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb= new StringBuffer();
		String string=null;
		try
		{
			tx = rdSession.beginTransaction();
			
			 if(("all") != null)
			   {
			    int fset = (PNO-1)*size;
			    String gsSql ="select count(*) from gbl_tbl_notes";
			    Query gsQuery=rdSession.createSQLQuery(gsSql);
			    Object noRecords= gsQuery.uniqueResult();
			    sb.append("<Notes>");
			    sb.append("\n");
			    sb.append("<noRecords>"+noRecords+"</noRecords>");
			    sb.append("\n");
			     if (PNO > 0 & size > 0){
			     gsSql="Select nt.NoteId,nt.NoteTitle,nt.DateTime,nt.`Status`,nt.NoteDescription,nt.CreatedDate,nt.ModifiedDate,nt.SchoolId,nt.BranchId from gbl_tbl_notes as nt where nt.IsDeleted <> 'Y' or nt.IsDeleted IS NULL and nt.SchoolId ='" + schoolId + "'  and nt.BranchId ='" + branchId + "' limit "+size+" offset "+fset;}
			     else {
			      gsSql="Select nt.NoteId,nt.NoteTitle,nt.DateTime,nt.`Status`,nt.NoteDescription,nt.CreatedDate,nt.ModifiedDate,nt.SchoolId,nt.BranchId from gbl_tbl_notes as nt where nt.IsDeleted <> 'Y' or nt.IsDeleted IS NULL and nt.SchoolId ='" + schoolId + "'  and nt.BranchId ='" + branchId + "'";
			     } 
			    gsQuery=rdSession.createSQLQuery(gsSql);
			    List gcList=gsQuery.list();
			    Iterator gsIT=gcList.iterator();
			    while(gsIT.hasNext())
			     {
			    	 Object[] ex=(Object[])gsIT.next();
			    	 	 sb.append("<Note>");
					     sb.append("\n");
					     sb.append("<noteId>");
				         sb.append(ex[0]);
				         sb.append("</noteId>");
				         sb.append("\n");
				         sb.append("<noteTitle>");
				         sb.append(ex[1]);
				         sb.append("</noteTitle>");
				         sb.append("\n");
				         sb.append("<dateTime>");
				         sb.append(ex[2]);
				         sb.append("</dateTime>");
				         sb.append("\n");
				         sb.append("<status>");
				         sb.append(ex[3]);
				         sb.append("</status>");
				         sb.append("\n");
				         sb.append("<noteDescription>");
				         sb.append(ex[4]);
				         sb.append("</noteDescription>");
				         sb.append("\n");
				         sb.append("<createdDate>");
				         sb.append(ex[5]);
				         sb.append("</createdDate>");
				         sb.append("\n");
				         sb.append("<modifiedDate>");
				         sb.append(ex[6]);
				         sb.append("</modifiedDate>");
				         sb.append("\n");
				    	 sb.append("<schoolId>");
				         sb.append(ex[7]);
				         sb.append("</schoolId>");
				         sb.append("\n");
				    	 sb.append("<branchId>");
				         sb.append(ex[8]);
				         sb.append("</branchId>");
				         sb.append("\n");
				         sb.append("</Note>");
			}
		}
			sb.append("</Notes>");
					    String str= sb.toString();
						 tx.commit();
					return str;
		}
		catch(Exception localException)
		{
			System.out.println(localException);
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    sb.append("could not getall Notes info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    string= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (string!=null)
				  tx.rollback();
		}
		finally
		{
			rdSession.close();
		}
		return string;
	}
	public String getNotebyid(int noteId,int schoolId,int branchId) {
		Session gtempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gtTx=null;
			StringBuffer sb= new StringBuffer();
			System.out.println("hi dao impl success");
			String strg= null;
				try {
						 gtTx = gtempSession.beginTransaction();
						 List list=gtempSession.createSQLQuery("Select nt.NoteId,nt.NoteTitle,nt.DateTime,nt.`Status`,nt.NoteDescription,nt.CreatedDate,nt.ModifiedDate,nt.SchoolId,si.SchoolName,nt.BranchId,sb.BranchName from gbl_tbl_notes as nt join gbl_sm_tbl_school_info as si on nt.SchoolId=si.SchoolId join gbl_sm_tbl_school_branch as sb  on nt.BranchId=sb.SchoolBranchId where nt.IsDeleted <> 'Y' or nt.IsDeleted IS NULL and NoteId ='" + noteId + "' and nt.SchoolId ='" + schoolId + "'  and nt.BranchId ='" + branchId + "' ;").list();
					     Iterator it=list.iterator();
					     sb.append("<Note>");
					     sb.append("\n");
					     while(it.hasNext())
					     {
					      Object[] ex=(Object[])it.next();
					      	 sb.append("<noteId>");
					         sb.append(ex[0]);
					         sb.append("</noteId>");
					         sb.append("\n");
					         sb.append("<noteTitle>");
					         sb.append(ex[1]);
					         sb.append("</noteTitle>");
					         sb.append("\n");
					     	 sb.append("<schoolId>");
					         sb.append(ex[7]);
					         sb.append("</schoolId>");
					         sb.append("\n");
					         sb.append("<schoolName>");
					         sb.append(ex[8]);
					         sb.append("</schoolName>");
					         sb.append("\n");
					    	 sb.append("<branchId>");
					         sb.append(ex[9]);
					         sb.append("</branchId>");
					         sb.append("\n");
					         sb.append("<branchName>");
					         sb.append(ex[10]);
					         sb.append("</branchName>");
					         sb.append("\n");
					         sb.append("<dateTime>");
					         sb.append(ex[2]);
					         sb.append("</dateTime>");
					         sb.append("\n");
					         sb.append("<status>");
					         sb.append(ex[3]);
					         sb.append("</status>");
					         sb.append("\n");
					         sb.append("<noteDescription>");
					         sb.append(ex[4]);
					         sb.append("</noteDescription>");
					         sb.append("\n");
					         sb.append("<createdDate>");
					         sb.append(ex[5]);
					         sb.append("</createdDate>");
					         sb.append("\n");
					         sb.append("<modifiedDate>");
					         sb.append(ex[6]);
					         sb.append("</modifiedDate>");
					         sb.append("\n");
					     	}
							 sb.append("</Note>");
							 strg= sb.toString();
				            } catch (Exception localException) {
					    System.out.println(localException);
					    sb.append("<Response>");
					    sb.append("\n");
					    sb.append("<Result>");
					    sb.append("\n");
					    sb.append("Fail");
					    sb.append("\n");
					    sb.append("</Result>");
					    sb.append("\n");
					    sb.append("<Description>");
					    sb.append("could not getNotebyid info");
					    sb.append("</Description>");
					    sb.append("\n");
					    sb.append("<Exception>");
					    sb.append(localException);
					    sb.append("</Exception>");
					    sb.append("</Response>");
					    sb.append("</noteId>");
					    sb.append("</Note>");
					    strg= sb.toString();
					   MDTransactionWriter.exceptionlog.info(localException);
					  if (strg!=null)
						  gtTx.rollback();
					} finally {
						gtempSession.close();
					}
			return strg;
	}
}
