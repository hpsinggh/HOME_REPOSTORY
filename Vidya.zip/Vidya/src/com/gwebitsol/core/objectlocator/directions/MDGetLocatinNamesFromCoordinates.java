package com.gwebitsol.core.objectlocator.directions;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

@Path("/getlocationfrompoints/")
public interface MDGetLocatinNamesFromCoordinates 
{
	@Path("/get")
	@GET
	@Produces({"application/xml","application/json"})
	public Response getLocationNames(@QueryParam ("latitude") String latitude,@QueryParam ("longitude") String longitude);

	@Path("/getinterpoints")
	@GET
	@Produces({"application/xml","application/json"})
	public Response getInterPoints(@QueryParam ("sourceName") String sourceName,@QueryParam ("destinationName") String destinationName);
}
