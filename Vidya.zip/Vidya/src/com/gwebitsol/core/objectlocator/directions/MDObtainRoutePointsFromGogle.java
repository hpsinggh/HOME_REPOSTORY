package com.gwebitsol.core.objectlocator.directions;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.net.URL;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.cxf.helpers.IOUtils;
import org.apache.cxf.io.CachedOutputStream;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

public class MDObtainRoutePointsFromGogle 
{

	public String getAddressList(String msource,String mdestination) throws Exception
	{

		String serviceURL = "http://maps.googleapis.com/maps/api/directions";
		String uri=serviceURL+"/xml?origin="+msource+"&destination="+mdestination+"&sensor=false";

		URL url = new URL(uri.toString());
		InputStream in = url.openStream();
		String localAddressString=getStringFromInputStream(in);
		return getListFromXML(localAddressString);

	}
	private static String getStringFromInputStream(InputStream in) throws Exception 
	{
		CachedOutputStream bos = new CachedOutputStream();
		IOUtils.copy(in, bos);
		in.close();
		bos.close();
		return bos.getOut().toString();
	}
	private static String getListFromXML(String st) throws IOException
	{

		XPathFactory factory = XPathFactory.newInstance();
		XPath xpath = factory.newXPath();
		String finalListString="";
		String localsb=st;
		StringBuffer addressBuffer=new StringBuffer();
		try 
		{
			MDGetLocationDetailsFromCoordinates getLocationFromCoordinates=new MDGetLocationDetailsFromCoordinates();
			InputSource inputXml = new InputSource(new StringReader(localsb));
			String XPATH_EXPRESSION = "/DirectionsResponse/route/leg/step";
			NodeList nodes = (NodeList) xpath.evaluate(XPATH_EXPRESSION, inputXml, XPathConstants.NODESET);
			StringBuffer xmlBuffer=new StringBuffer();
			for (int i = 0, n = nodes.getLength(); i < n; i++) 
			{
				NodeList chin = nodes.item(i).getChildNodes();
//				String localStr=chin.item(3).getTextContent();//this shows error thats why for temparory i made it comment
//				xmlBuffer.append(localStr.replaceAll("\\s+", " "));//this shows error thats why for temparory i made it comment
				xmlBuffer.append(",");
			}
			int k=xmlBuffer.lastIndexOf(",");
			xmlBuffer.deleteCharAt(k);
			String secondlocalStr=xmlBuffer.toString().trim();
			String[] lcst=secondlocalStr.split(",");
			
			addressBuffer.append("<addresslist>");
			addressBuffer.append("\n");
			for(int m=0;m<lcst.length;m++)
			{
				String localStr=lcst[m].trim();
				String s1[]=localStr.split(" ");
				Double lat=Double.parseDouble(s1[0]);
				Double longt=Double.parseDouble(s1[1]);
				addressBuffer.append("<longlat>"+longt+","+lat+"</longlat>");
				//addressBuffer.append("<address>");
				addressBuffer.append(getLocationFromCoordinates.getDet(lat, longt));
				//addressBuffer.append("</address>");
				addressBuffer.append("\n");
			}
			addressBuffer.append("</addresslist>");
			finalListString=addressBuffer.toString();
			xmlBuffer.setLength(0);
			addressBuffer.setLength(0);
			
		} 
		catch (XPathExpressionException ex)
		{
			ex.printStackTrace();
		} 
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return finalListString;
	}
}
