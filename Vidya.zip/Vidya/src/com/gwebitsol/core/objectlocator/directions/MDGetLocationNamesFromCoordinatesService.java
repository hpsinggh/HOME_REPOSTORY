package com.gwebitsol.core.objectlocator.directions;


import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.log4j.Logger;

import com.gwebitsol.core.objectlocator.directions.MDGetLocatinNamesFromCoordinates;
import com.gwebitsol.core.objectlocator.directions.MDGetLocationDetailsFromCoordinates;
import com.gwebitsol.core.objectlocator.directions.MDObtainRoutePointsFromGogle;

public class MDGetLocationNamesFromCoordinatesService implements MDGetLocatinNamesFromCoordinates
{
	private static Logger exceptionlog=Logger.getLogger("exceptionLog");
	
	public Response getLocationNames(String lat,String longt)
	{
		String XMLString=null;
		Double localLat=Double.parseDouble(lat);
		Double localLongt=Double.parseDouble(longt);
		
		try
		{
				
			MDGetLocationDetailsFromCoordinates getLocation=new MDGetLocationDetailsFromCoordinates();
			XMLString="<MD_Response>"+"\n"+getLocation.getDet(localLat,localLongt)+"\n"+"</MD_Response>";
		}
		catch(Exception localException)
		{
			exceptionlog.info(localException);
			XMLString="<MD_Response>failed in DAO layed</MD_Response>";
		}
		
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}
	public Response getInterPoints(String sourceName,String destinationName)
	{

		String XMLString=null;
		try
		{
				
			MDObtainRoutePointsFromGogle getPoints=new MDObtainRoutePointsFromGogle();
			XMLString="<MD_Response>"+"\n"+getPoints.getAddressList(sourceName, destinationName)+"\n"+"</MD_Response>";
		}
		catch(Exception localException)
		{
			exceptionlog.info(localException);
			XMLString="<MD_Response>failed in DAO layed</MD_Response>";
		}
		
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}
}
