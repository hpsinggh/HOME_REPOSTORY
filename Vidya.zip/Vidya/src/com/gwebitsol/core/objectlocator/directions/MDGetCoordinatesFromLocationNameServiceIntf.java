package com.gwebitsol.core.objectlocator.directions;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

@Path("/getcoordinates/")
public interface MDGetCoordinatesFromLocationNameServiceIntf
{
	@GET
	@Produces({"application/xml","application/json"})
	@Path("/get")
	public Response getCoordinatesFromName(@QueryParam("locationName") String locationName);

}
