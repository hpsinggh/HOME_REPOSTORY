package com.gwebitsol.core.objectlocator.directions;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.gwebitsol.core.objectlocator.directions.MDGetCoordinatesFromLocationNameServiceIntf;
import com.gwebitsol.core.objectlocator.directions.MDGetLocationDetailsFromCoordinates;
import com.gwebitsol.core.util.MDTransactionWriter;


public class MDGetCoordinatesFromLocationNameService implements MDGetCoordinatesFromLocationNameServiceIntf
{
	
	public Response getCoordinatesFromName(String locationName)
	{
		String XMLString=null;
		try
		{
			MDGetLocationDetailsFromCoordinates getLocation=new MDGetLocationDetailsFromCoordinates();
			XMLString="<MD_Response>"+"\n"+getLocation.getGeoLocation(locationName)+"\n"+"</MD_Response>";
		}
		catch(Exception localException)
		{
			MDTransactionWriter.exceptionlog.info(localException);
			XMLString="<MD_Response>failed in DAO layed</MD_Response>";
		}
		
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
		
	}
	
}
