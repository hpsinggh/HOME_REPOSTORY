package com.gwebitsol.core.objectlocator.directions;

import java.net.URL;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.cxf.io.CachedOutputStream;
import org.apache.cxf.helpers.IOUtils;
import org.apache.log4j.Logger;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.gwebitsol.core.util.MDTransactionWriter;

public class MDGetLocationDetailsFromCoordinates
{
	private static Logger exceptionlog=Logger.getLogger("exceptionLog");
	public String getDet(Double lat,Double lang) throws Exception
	{
		/*float nLat=lat;
		float nLang=lang;*/
		String addressString=null;
		String finalString=null;
		StringBuffer detailsString=new StringBuffer();
		String serviceURL = "http://maps.googleapis.com/maps/api/geocode";
		String uri=serviceURL+"/xml?latlng="+lat+","+lang+"&sensor=false";
		System.out.println(lat);
		System.out.println(lang);
		try
		{
			System.out.println("entered into try block");
		URL url = new URL(uri.toString());
		System.out.println(url);
		InputStream in = url.openStream();
		addressString=getStringFromInputStream(in);
		System.out.println(addressString);
		detailsString.append("<address>");
		detailsString.append(getAddressFromXML(addressString));
		detailsString.append("</address>");
		finalString=detailsString.toString();
		detailsString.setLength(0);
		}
		catch(Exception localException)
		{
			exceptionlog.info(localException);
		}
		return finalString;
	}
	private static String getStringFromInputStream(InputStream in) throws Exception
	{
		CachedOutputStream bos = new CachedOutputStream();
		IOUtils.copy(in, bos);
		in.close();
		bos.close();
		return bos.getOut().toString();
	}
	private static String getAddressFromXML(String st) throws IOException
	{

		XPathFactory factory = XPathFactory.newInstance();

		XPath xpath = factory.newXPath();
		String nodeString="";
		String localsb=st;
		try
		{
			InputSource inputXml = new InputSource(new StringReader(localsb));
			String XPATH_EXPRESSION = "/GeocodeResponse/result/formatted_address";
			NodeList nodes = (NodeList) xpath.evaluate(XPATH_EXPRESSION, inputXml, XPathConstants.NODESET);
			for (int i = 0; i < 1; i++) 
			{
				//nodeString = nodes.item(i).getTextContent(); //this shows error thats why for temparory i made it comment
			}
		} 
		catch (XPathExpressionException ex)
		{
			ex.printStackTrace();
		} 
		return nodeString;
	}
public String getGeoLocation(String locationName)
{
	String serviceURL = "http://maps.googleapis.com/maps/api/geocode";
	String uri=serviceURL+"/xml?address="+locationName+"&sensor=false";
	String outXML=null;
	String latlangt=null;
	try
		{
	    URL url = new URL(uri.toString());
	    InputStream in = url.openStream();
	    outXML= getStringFromInputStream(in);
	    latlangt=getLatitudeFromXML(outXML)+" "+getLongitudeFromXML(outXML);
		}
		catch(Exception localException)
		{
			MDTransactionWriter.exceptionlog.info(localException);
		}
	return latlangt;
}
private static String getLatitudeFromXML(String st) throws IOException
{
	String latstr=null;
  XPathFactory factory = XPathFactory.newInstance();
  XPath xpath = factory.newXPath();
  String nodeString="";
  String localsb=st;
  try {
        InputSource inputXml = new InputSource(new StringReader(localsb));
        String XPATH_EXPRESSION = "/GeocodeResponse/result/geometry/location/lat";
        NodeList nodes = (NodeList) xpath.evaluate(XPATH_EXPRESSION, inputXml, XPathConstants.NODESET);
        for (int i = 0; i < 1; i++) 
        {
        	//nodeString = nodes.item(i).getTextContent();//this shows error thats why for temparory i made it comment
        	latstr=nodeString;
        	//System.out.print("latitude is : "+nodeString);
        }
  }
  catch (XPathExpressionException ex) 
  {
        System.out.print("XPath Error");
  }
  return latstr;
}
 private static String getLongitudeFromXML(String st) throws IOException
	{
		String langstr=null;
	  XPathFactory factory = XPathFactory.newInstance();
	  XPath xpath = factory.newXPath();
	  String nodeString="";
	  String localsb=st;
	  try {
	        InputSource inputXml = new InputSource(new StringReader(localsb));
	        String XPATH_EXPRESSION = "/GeocodeResponse/result/geometry/location/lng";
	        NodeList nodes = (NodeList) xpath.evaluate(XPATH_EXPRESSION, inputXml, XPathConstants.NODESET);
	        for (int i = 0; i < 1; i++) 
	        {
	        	//nodeString = nodes.item(i).getTextContent();//this shows error thats why for temparory i made it comment
	        	langstr=nodeString;
	        	//System.out.print("longitude is : "+nodeString);
	        }
	  } catch (XPathExpressionException ex) 
	  {
	        System.out.print("XPath Error");
	  } 
	  return langstr;
	}
  
  
}