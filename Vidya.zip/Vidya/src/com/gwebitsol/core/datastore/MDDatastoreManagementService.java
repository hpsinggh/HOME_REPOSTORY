/*
Proprietary Notice
This file contains confidential information of meldit Pvt. Ltd. (India)  and meldit Inc. (USA), 
which is available for the sole purpose of permitting the recipient for engineering and product development purposes.  
In consideration of receipt of this file, the recipient agrees to maintain such information in confidence and not to
reproduce or otherwise disclose this information to any person outside the group directly responsible for its contents.

Security
The information contained herein is proprietary to meldit Pvt. Ltd. (India)  and meldit Inc. (USA) and may not be used, 
reproduced or disclosed.  The recipient of this file, by its retention and use, agrees to protect the same and the 
information contained therein from distribution, loss and theft.
__________________________________________________________________________________________________________________________________________________________________________________
*/

package com.gwebitsol.core.datastore;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.gwebitsol.core.util.MDTransactionWriter;


public class MDDatastoreManagementService implements MDDatastoreManagementServiceIntf
{
	@Context private HttpServletRequest hsr;
	public Response createDatastore(MDDatastore mdDStore)
	{
		String XMLString=null;
		try
		{
		MDDatastoreManagementDAO mdDMDAO=new MDDatastoreManagementDAO();
		String datastoreName=mdDStore.getDatastoreName();
		String serverIP=mdDStore.getServerIP();
		String webserverIP=mdDStore.getWebserverIP();
		String webserverPort=mdDStore.getWebserverPort();
		String dbIP=mdDStore.getDbIP();
		String dbPassword=mdDStore.getDbPassword();
		String dbUsername=mdDStore.getDbUserName();
		String dbType=mdDStore.getDbType();
		String dbPort=mdDStore.getDbPort();
		String melditUsername=mdDStore.getMelditUserName();
		String melditPassword=mdDStore.getMelditPassword();
		String licenceKey=mdDStore.getLicenceKey();
		if(datastoreName==null || serverIP==null || webserverIP==null || webserverPort==null || dbIP==null || dbPassword==null || dbUsername==null || dbType==null || dbPort==null || melditUsername==null || melditPassword==null || licenceKey==null)
		{
			XMLString="All fields are required";
		}
		else
		{
		XMLString=mdDMDAO.createDataStore(hsr,datastoreName, serverIP, webserverIP, webserverPort, dbIP, dbPassword, dbUsername, dbType, dbPort, melditUsername, melditPassword, licenceKey);
		}
		}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			
		}
			return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}
	
	public Response addPrivileges(MDPrivilegesList mdprivi,int userid,int parentfolderid,String folderlevel,String foldertype) {
		
		String XMLString=null;
		try
		{
		MDDatastoreManagementDAO mdDMDAO=new MDDatastoreManagementDAO();
		
		XMLString =  mdDMDAO.addPrivileges(mdprivi,userid,parentfolderid,folderlevel,foldertype);
		}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			
		}
			return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
		
	}
}
