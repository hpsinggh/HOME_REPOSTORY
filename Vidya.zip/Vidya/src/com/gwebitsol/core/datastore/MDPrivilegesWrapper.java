package com.gwebitsol.core.datastore;

import java.util.ArrayList;
import java.util.List;

import com.gwebitsol.core.auth.MDPrvPOJO;

public class MDPrivilegesWrapper {
	
	List<MDPrvPOJO> mdprv = new ArrayList <MDPrvPOJO>();

	public List<MDPrvPOJO> getMdprv() {
		return mdprv;
	}

	public void setMdprv(List<MDPrvPOJO> mdprv) {
		this.mdprv = mdprv;
	}
	
	

}
