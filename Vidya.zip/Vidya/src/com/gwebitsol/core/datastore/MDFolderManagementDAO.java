/*
Proprietary Notice
This file contains confidential information of meldit Pvt. Ltd. (India)  and meldit Inc. (USA), 
which is available for the sole purpose of permitting the recipient for engineering and product development purposes.  
In consideration of receipt of this file, the recipient agrees to maintain such information in confidence and not to
reproduce or otherwise disclose this information to any person outside the group directly responsible for its contents.

Security
The information contained herein is proprietary to meldit Pvt. Ltd. (India)  and meldit Inc. (USA) and may not be used, 
reproduced or disclosed.  The recipient of this file, by its retention and use, agrees to protect the same and the 
information contained therein from distribution, loss and theft.
__________________________________________________________________________________________________________________________________________________________________________________
*/

package com.gwebitsol.core.datastore;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.gwebitsol.core.objectcontroller.device.MDDeviceManagementDAO;
import com.gwebitsol.core.objectcontroller.object.MDObjectManagementDAO;
import com.gwebitsol.core.organisation.MDOrganisationManagementDAO;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class MDFolderManagementDAO 
{
	DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	Date date = new Date();
	String d=dateFormat.format(date);
	
	@SuppressWarnings("rawtypes")
	Map mi=new HashMap();

	@SuppressWarnings("rawtypes")
	static Map mi2=new HashMap();
	
	public static void main(String args[])
	{
		MDFolderManagementDAO mdfm=new MDFolderManagementDAO();
		mdfm.getAllSubFolders(1);

	}

	@SuppressWarnings("unused")
	public String addFolder(MDFolder mdFolder,String folderType,String folderLevel,int uid)
	{
		Session afSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction afTx=afSession.beginTransaction();	
		StringBuffer sb=new StringBuffer();
			String str=null;
			String acl=null;
			String [] fldName=null;
			String foldertype=null;
			String folderlevel=null;
			String validationWhereclse=null;
			fldName = mdFolder.getFolderName().split("','");
		    try
		    {
		    	if(uid==1)
				{
					acl="U#1:111";
				}
				else
				{
					acl="U#1:111;U#"+uid+":111";
				}   	
		    	//folderlevel types
		    	if(folderLevel.equalsIgnoreCase("Leaf"))
				{
					folderlevel="L";
				}
				else if(folderLevel.equalsIgnoreCase("Parent"))
				{
					folderlevel="P";
				}
		    	//foldertypes
				if(folderType.equalsIgnoreCase("Menu"))
				{
					foldertype="M";
					validationWhereclse="where foldername='"+mdFolder.getFolderName()+"' and parentfolderid='"+mdFolder.getParentFolderId()+"' and folderType='M'";
					
				}
				else if(folderType.equalsIgnoreCase("PickListGroup"))
				{
					foldertype="PLG";
					validationWhereclse="where foldername='"+mdFolder.getFolderName()+"' and parentfolderid='"+mdFolder.getParentFolderId()+"' and folderType='PLG' and infoclassid='"+mdFolder.getInfoclassId()+"'";
				}
				else if(folderType.equalsIgnoreCase("DependencyPickList"))
				{
					foldertype="DPL";
					validationWhereclse="where foldername='"+mdFolder.getFolderName()+"' and parentfolderid='"+mdFolder.getParentFolderId()+"' and folderType='DPL'";
				}
				else if(folderType.equalsIgnoreCase("Object"))
				{
					foldertype="iO";
				}
				else if(folderType.equalsIgnoreCase("Organization"))
				{
					foldertype="iORG";
					validationWhereclse="where foldername='"+mdFolder.getFolderName()+"' and parentfolderid='"+mdFolder.getParentFolderId()+"' and folderType='iORG'";
				}
				else if(folderType.equalsIgnoreCase("Device"))
				{
					foldertype="iD";
				}
				else if(folderType.equalsIgnoreCase("Form"))
				{
					foldertype="Form";
					validationWhereclse="where foldername='"+mdFolder.getFolderName()+"' and parentfolderid='"+mdFolder.getParentFolderId()+"' and infoclassid='"+mdFolder.getInfoclassId()+"'and folderType='Form'";
				}
				else if(folderType.equalsIgnoreCase("Sub-Form"))
				{
					foldertype="S-Form";
					validationWhereclse="where foldername='"+mdFolder.getFolderName()+"' and parentfolderid='"+mdFolder.getParentFolderId()+"' and infoclassid='"+mdFolder.getInfoclassId()+"'and folderType='S-Form'";
				}
				else if(folderType.equalsIgnoreCase("Parent-Form"))
				{
					foldertype="P-Form";
					validationWhereclse="where foldername='"+mdFolder.getFolderName()+"' and parentfolderid='"+mdFolder.getParentFolderId()+"' and infoclassid='"+mdFolder.getInfoclassId()+"'and folderType='P-Form'";
				}
				else if(folderType.equalsIgnoreCase("WebApplication"))
				{
					foldertype="Wapp";
				}
				else if(folderType.equalsIgnoreCase("Datastore"))
				{
					foldertype="DST";
					validationWhereclse="where foldername='"+mdFolder.getFolderName()+"' and parentfolderid='"+mdFolder.getParentFolderId()+"' and folderType='DST'";
				}
				else if(folderType.equalsIgnoreCase("Functions"))
				{
					foldertype="FN";
					validationWhereclse="where foldername='"+mdFolder.getFolderName()+"' and parentfolderid='"+mdFolder.getParentFolderId()+"' and folderType='FN'";
				}
				else if(folderType.equalsIgnoreCase("Section"))
				{
					foldertype="S";
					validationWhereclse="where foldername='"+mdFolder.getFolderName()+"' and parentfolderid='"+mdFolder.getParentFolderId()+"' and infoclassid='"+mdFolder.getInfoclassId()+"'and folderType='S'";
				}
				else if(folderType.equalsIgnoreCase("VertualForm"))
				{
					foldertype="VForm";
					validationWhereclse="where foldername='"+mdFolder.getFolderName()+"' and parentfolderid='"+mdFolder.getParentFolderId()+"' and infoclassid='"+mdFolder.getInfoclassId()+"'and folderType='VForm'";
				}
				else if(folderType.equalsIgnoreCase("PickList"))
				{
					foldertype="PL";
					validationWhereclse="where foldername='"+mdFolder.getFolderName()+"' and parentfolderid='"+mdFolder.getParentFolderId()+"' and folderType='PL' and infoclassid='"+mdFolder.getInfoclassId()+"'";
				}
				else if(folderType.equalsIgnoreCase("Folder"))
				{
					foldertype="iF";
					validationWhereclse="where foldername='"+mdFolder.getFolderName()+"' and parentfolderid='"+mdFolder.getParentFolderId()+"' and folderType='iF'";
				}
				else if(folderType.equalsIgnoreCase("SubFolder"))
				{
					foldertype="iS-Folder";
					validationWhereclse="where foldername='"+mdFolder.getFolderName()+"' and parentfolderid='"+mdFolder.getParentFolderId()+"' and folderType='iS-Folder'";
				}
				else if(folderType.equalsIgnoreCase("Node"))
				{
					foldertype="iN";
				}
				else if(folderType.equalsIgnoreCase("SubNode"))
				{
					foldertype="iS-Node";	
				}
				
			Integer count=(Integer)afSession.createSQLQuery("select folderid from mdfolder "+validationWhereclse).uniqueResult();
			if(count!=null && count!=0)
		    {
		    	str="Provided name '"+mdFolder.getFolderName()+"' is already exist in system for folder type '"+mdFolder.getFolderType()+"'";
		    }
		    else
		    {
		    String fname =(String)afSession.createSQLQuery("select foldername from mdfolder where folderid='"+mdFolder.getParentFolderId()+"'").uniqueResult();
		    Integer fid=(Integer)afSession.createSQLQuery("select folderid from mdfolder where foldername='"+fname+"' and folderid='"+mdFolder.getParentFolderId()+"'").uniqueResult();
		    StringBuffer flSB=new StringBuffer();
		    sb.append("<folders>");
			for(int i=0;i<=fldName.length-1;i++)
			{ 
			flSB.append("INSERT INTO MDFOLDER (FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) VALUES('");
		    flSB.append(fldName[i]);
		    flSB.append("',");
		    flSB.append(fid);
		    flSB.append(",'"+mdFolder.getInfoclassId()+"','"+mdFolder.getStatus()+"','"+foldertype+"','");
		    flSB.append(d);
		    flSB.append("','0000-00-00 00:00:00','"+acl+"','"+uid+"','"+uid+"','"+folderlevel+"')");
			Query query =afSession.createSQLQuery(flSB.toString());
			query.executeUpdate();
			flSB.setLength(0);
			
			String upsqry="select folderid from mdfolder where foldername='"+fldName[i]+"'";
			Query icQuery7=afSession.createSQLQuery(upsqry);
					
			Object [] objfieldid= icQuery7.list().toArray();
			int folderid = (Integer) objfieldid[0];
			
			
			// Inserting Menus and Folders  into mdprivileges table
			if(folderType.equalsIgnoreCase("Menu") || folderType.equalsIgnoreCase("Folder"))
			{
			String prvSql="INSERT INTO MDPRIVILEGES(PRIVILEGENAME) VALUES('"+fldName[i]+"')";
			Query icQuery1=afSession.createSQLQuery(prvSql);
			icQuery1.executeUpdate();
			}
			sb.append("\n");
			sb.append("<folder>");
			sb.append("\n");
			sb.append("<folderName>");
			sb.append(fldName[i]);
			sb.append("</folderName>");
			sb.append("\n");
			sb.append("<folderid>");
			sb.append(folderid);
			sb.append("</folderid>");
			sb.append("\n");
			sb.append("</folder>");
			}
			sb.append("\n");
			 sb.append("</folders>");
			 str=sb.toString();
			 afTx.commit();
		    }
		    }
		    catch(Exception localException)
		    {
		    	afTx.rollback();
		    	MDTransactionWriter.exceptionlog.info(localException);
		    	str="addition of folder failed";
		    }
		    finally
		    {
		    	afSession.close();
		    }
		return str;
	}

	
	@SuppressWarnings({ "unchecked", "deprecation", "rawtypes" })
	public String getAllSubFolders(int parentFolderID)
	{
		Session gasfSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gasfTx =gasfSession.beginTransaction();	
		String rtnString=null;
		StringBuffer sb=new StringBuffer();
		List li=new ArrayList();
		try
		{
				gasfTx=gasfSession.beginTransaction();			
				String entSql="select * from mdfolder where folderid IN (select folderid from mdfolder where parentfolderid="+parentFolderID+")";
				Query entQuery=gasfSession.createSQLQuery(entSql).addScalar("folderid",Hibernate.INTEGER).addScalar("foldername",Hibernate.STRING).addScalar("parentfolderid",Hibernate.INTEGER);	
				List entList=entQuery.list();
				
			if(entList!=null && entList.size()>0)
			{
				Iterator entIT=entList.iterator();
				while(entIT.hasNext())
				{
					Object[] entObj=(Object[])entIT.next();
					System.out.println(entObj[1]);
					//int folderid=(Integer)entObj[0];
					String folderName=(String)entObj[1];
					//int pfid=(Integer)entObj[2];
					
					sb.append(folderName);
					sb.append(",");
					mi.put(entObj[0],entObj[2]);
				}
				int m=sb.lastIndexOf(",");
				sb.deleteCharAt(m);
				li.add(sb.toString());
				Set keys=new HashSet(mi.keySet());
				
				mi2.put(parentFolderID,li);
				if(keys.isEmpty())
				{}
				else 
				{
				MDFolderManagementDAO mdfm=new MDFolderManagementDAO();
				Iterator keysIT=keys.iterator();
				while(keysIT.hasNext())
				{
					int k=(Integer)keysIT.next();
					mdfm.getAllSubFolders(k);
					
				}
				}
				System.out.println(mi2);
			}
			else
			{
				
			}	
			gasfTx.commit();
		}
		catch(Exception localException)
		{
			gasfTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			rtnString="fail";
		}
		finally
		{
			gasfSession.close();
		}
		return rtnString;
	}
	
	@SuppressWarnings({ "rawtypes", "deprecation", "unchecked" })
	public int delSubFolder(int folderID)
	{
		int rtnString=0;
		Session dasfSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction dasfTx=null;
		Map mi =new HashMap();
		List delList=new ArrayList();
		try
		{
			dasfTx=dasfSession.beginTransaction();

			String entSql="select * from mdfolder where folderid IN (select folderid from mdfolder where parentfolderid="+folderID+")";
			Query entQuery=dasfSession.createSQLQuery(entSql).addScalar("folderid",Hibernate.INTEGER).addScalar("foldername",Hibernate.STRING)
					.addScalar("parentfolderid",Hibernate.INTEGER).addScalar("infoclassid",Hibernate.INTEGER).addScalar("foldertype",Hibernate.STRING);
			List entList=entQuery.list();
			if(entList!=null && entList.size()>0)
			{
			Iterator entIT=entList.iterator();
			while(entIT.hasNext())
			{
				Object[] entObj=(Object[])entIT.next();
				delList.add(entObj[1]);
				mi.put(entObj[0],entObj[2]);
				int folderid=(Integer)entObj[0];
				int infoclassid=(Integer)entObj[3];
				String infoclassName=(String)dasfSession.createSQLQuery("select infoclassname from mdobjectinfoclassdefcontainer where infoclassid="+infoclassid).uniqueResult();
				String folderName=(String)entObj[1];
				String folderType=(String)entObj[4];
				if(folderType.equalsIgnoreCase("O"))
				{
					int objectID=(Integer)dasfSession.createSQLQuery("select objectid from mdobject where objectname='"+folderName+"'").uniqueResult();	
					
					Query doQuery=dasfSession.createSQLQuery("delete from "+infoclassName+" where componentid="+objectID);
					doQuery.executeUpdate();
					
					String oSql="delete from mdobject where objectname='"+folderName+"'";
					Query oQuery=dasfSession.createSQLQuery(oSql);
					oQuery.executeUpdate();
				}
				else if(folderType.equalsIgnoreCase("D"))
				{
					int deviceID=(Integer)dasfSession.createSQLQuery("select deviceid from mddevice where devicename='"+folderName+"'").uniqueResult();
					
					Query ddQuery=dasfSession.createSQLQuery("delete from "+infoclassName+" where componentid="+deviceID);
					ddQuery.executeUpdate();
					
					String dSql="delete from mddevice where devicename='"+folderName+"'";
					Query dQuery=dasfSession.createSQLQuery(dSql);
					dQuery.executeUpdate();
					
				}
				else if(folderType.equalsIgnoreCase("F"))
				{
					Query dorgQuery=dasfSession.createSQLQuery("delete from "+infoclassName+" where componentid="+folderid);
					dorgQuery.executeUpdate();
					
					Query dorgQuery1=dasfSession.createSQLQuery("delete from "+infoclassName+" where componentid="+folderID);
					dorgQuery1.executeUpdate();
				}
			}
			}else{}
			Set keys=new HashSet(mi.keySet());	
			
			
		for(int j=0;j<delList.size();j++)
		{
			System.out.println("list"+delList.get(j));
			String sSql="delete from mdfolder where foldername='"+delList.get(j)+"'";
			Query sQuery=dasfSession.createSQLQuery(sSql);
			sQuery.executeUpdate();
		}
	
			MDFolderManagementDAO mdfm=new MDFolderManagementDAO();
			Iterator keysIT=keys.iterator();
			while(keysIT.hasNext())
			{
				int k=(Integer)keysIT.next();
				mdfm.delSubFolder(k);
				
			}
			dasfTx.commit();
			rtnString=1;
		}
		catch(Exception localException)
		{
			dasfTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			rtnString=0;
		}
		finally
		{
			dasfSession.close();
		}
		return rtnString;
	}

	public String deleteAllSubFolders(int folderID)
	{
		String rtnString=null;
		Session dasfSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction dasfTx=null;

		try
		{
			dasfTx=dasfSession.beginTransaction();
			int pfid=(Integer)dasfSession.createSQLQuery("select parentfolderid from mdfolder where folderid="+folderID).uniqueResult();
			if(pfid==5)
			{
				rtnString="This is the root Organisation. You cant delete this..";
			}
			else
			{
			MDFolderManagementDAO mdfm=new MDFolderManagementDAO();
			int result=mdfm.delSubFolder(folderID);
			if(result==1)
			{
			String sSql="delete from mdfolder where folderid="+folderID;
			Query sQuery=dasfSession.createSQLQuery(sSql);
			sQuery.executeUpdate();
			rtnString="all sub folders deleted";
			}
			else
			{
				rtnString="error occurred while deletion";
			}
			}
			dasfTx.commit();
		}
		catch(Exception localException)
		{
			dasfTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			rtnString="fail";
		}
		finally
		{
			dasfSession.close();
		}
		
		return rtnString;
	}
	
	@SuppressWarnings({ "deprecation", "rawtypes" })
	public String getSubFolders(int folderId,String folderName,String folderType, int infoclassId, String status, int uid)
	{
		Session gsfSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gsfTx =gsfSession.beginTransaction();	
		String sfXMLString=null;
		StringBuffer sfSB=new StringBuffer();
		
		try
		{
			gsfTx=gsfSession.beginTransaction();
		//Siva, 7/3/2014, Added ACLs also to response for privileges
		//Siva 11/23/2016, for studio, added query parameters and removed folderName uniqueness; can query by folderId or folderName but not both
			String sfSql = null;
			Query sfQuery = null;
			
			String rsSql=(String)gsfSession.createSQLQuery("select rolestring from mdusers where userid="+uid+"").uniqueResult();
			String[] rolestring = rsSql.split(";");
			for(String s:rolestring)
			{
			Integer ridSql=(Integer)gsfSession.createSQLQuery("select roleid from mdrole where rolename='"+s+"'").uniqueResult();
			
			if (folderId != 0) {
			sfSql="select * from mdfolder where parentfolderid="+folderId+" and (status= 'active' or status= 'null' or status='') and (acl like '%U#"+uid+":1%'  or acl like '%R#"+ridSql+":1%')";
					if (infoclassId != 0) {
						sfSql += " and infoclassid="+infoclassId;
					}
					if (folderType != null) {
					    sfSql += " and folderType = '"+folderType+"'";
					}
					if (status != null) {
						sfSql += " and status= '" + status +"'"; 
					}
					sfSql += ";";
			sfQuery=gsfSession.createSQLQuery(sfSql).addScalar("FolderID",Hibernate.INTEGER).addScalar("infoclassID",Hibernate.INTEGER).addScalar("FolderName",Hibernate.STRING)
					.addScalar("foldertype",Hibernate.STRING).addScalar("Status",Hibernate.STRING).addScalar("folderlevel",Hibernate.STRING).addScalar("ACL",Hibernate.STRING); 
			}
				else if (folderName != null) {
				sfSql="select * from mdfolder where parentfolderid in (select folderid from mdfolder where folderName = '"+folderName+ "') and (status= 'active' or status= 'null' or status='') and (acl like '%U#"+uid+":1%' or acl like '%R#"+ridSql+":1%')";
				if (infoclassId != 0) {
					sfSql += " and infoclassid="+infoclassId;
				}
				if (folderType != null) {
				    sfSql += " and folderType = '"+folderType+"'";
				}
				if (status != null) {
					sfSql += " and status= '" + status +"'"; 
				}
				sfSql += ";";
			sfQuery=gsfSession.createSQLQuery(sfSql).addScalar("FolderID",Hibernate.INTEGER).addScalar("infoclassID",Hibernate.INTEGER).addScalar("FolderName",Hibernate.STRING)
					.addScalar("foldertype",Hibernate.STRING).addScalar("Status",Hibernate.STRING).addScalar("folderlevel",Hibernate.STRING).addScalar("ACL",Hibernate.STRING);
				}
			}
			
			List sfList=sfQuery.list();
			Iterator it=sfList.iterator();
			
			sfSB.append("<folders>");
			sfSB.append("\n");
		while(it.hasNext())
		{
			Object[] fObj=(Object[])it.next();
			sfSB.append("<folder>");
			sfSB.append("\n");
			sfSB.append("<ID>"+fObj[0]+"</ID>");
			sfSB.append("\n");
			sfSB.append("<InfoclassId>"+fObj[1]+"</InfoclassId>");
			sfSB.append("\n");
			sfSB.append("<Name>"+fObj[2]+"</Name>");
			sfSB.append("\n");
			sfSB.append("<Type>"+fObj[3]+"</Type>");
			sfSB.append("\n");
			sfSB.append("<Status>"+fObj[4]+"</Status>");
			sfSB.append("\n");
			sfSB.append("<Level>"+fObj[5]+"</Level>");
			sfSB.append("\n");
			
			String[] acl = fObj[6].toString().split(";");
			int k = 0;
			int i = acl.length;
			String usrACL=null;
			String rightStr = null;
			
			while (k<i) {
				boolean b = acl[k].startsWith("U#"+uid);
				if (b==true) usrACL = acl[k];
				k++;		
			}
			
			String[] localStr=usrACL.split(":");
	
			if(localStr[1].equals("111"))
				rightStr="RWD";
			else if(localStr[1].equals("110"))
				rightStr="RW";
			else
				rightStr="R";

			
			sfSB.append("<ACL>"+rightStr+"</ACL>");
			sfSB.append("\n");
			sfSB.append("</folder>");
			sfSB.append("\n");
		}
			sfSB.append("</folders>");
			sfXMLString=sfSB.toString();
			sfSB.setLength(0);
			gsfTx.commit();
			
		}
		catch(Exception localException)
		{
			gsfTx.rollback();
			sfSB.setLength(0);
			sfXMLString="fail";
			MDTransactionWriter.exceptionlog.info(localException);
		}
		finally
		{
			gsfSession.close();
			sfSB=null;
		}
		return sfXMLString;
	}


	private String compare() {
		// TODO Auto-generated method stub
		return null;
	}

	@SuppressWarnings({ "rawtypes", "deprecation" })
	public String getFolderDetails(String folderName,int uid)
	{
		Session gfdSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gfdTx =gfdSession.beginTransaction();	
		String gfXMLString=null;
		StringBuffer gfSB=new StringBuffer();
		String foldertype=null;
		String folderlevel=null;
		int folderid=0;
		int infoclassid=0;
		
		try
		{

			gfdTx=gfdSession.beginTransaction();
			
			String rsSql=(String)gfdSession.createSQLQuery("select rolestring from mdusers where userid="+uid+"").uniqueResult();
			String[] rolestring = rsSql.split(";");
			for(String s:rolestring)
			{
			Integer ridSql=(Integer)gfdSession.createSQLQuery("select roleid from mdrole where rolename='"+s+"'").uniqueResult();
			
			String gfSql="select * from mdfolder where foldername='"+folderName+"'  and (status= 'active' or status= 'null' or status='')  and (acl like '%U#"+uid+":1%'  or acl like '%R#"+ridSql+":1%')";
			Query query=gfdSession.createSQLQuery(gfSql).addScalar("folderid",Hibernate.INTEGER).addScalar("infoclassid",Hibernate.INTEGER)
					.addScalar("foldertype",Hibernate.STRING).addScalar("folderlevel",Hibernate.STRING);
			List list=query.list();
			Iterator it=list.iterator();
			while(it.hasNext())
			{
				Object[] obj=(Object[])it.next();
				folderid=(Integer)obj[0];
				infoclassid=(Integer)obj[1];
				foldertype=(String)obj[2];
				folderlevel=(String)obj[3];
			}
			String infoclassName=(String)gfdSession.createSQLQuery("select infoclassname from mdobjectinfoclassdefcontainer where infoclassid="+infoclassid).uniqueResult();
			gfSB.append("<MD_Folder>");
			gfSB.append("\n");
			gfSB.append("<folderdetails>");
			gfSB.append("\n");
			gfSB.append("<Folder_ID>"+folderid+"</Folder_ID>");
			gfSB.append("\n");
			gfSB.append("<Infoclass_Name>"+infoclassName+"</Infoclass_Name>");
			gfSB.append("\n");
			gfSB.append("<Folder_Type>"+foldertype+"</Folder_Type>");
			gfSB.append("\n");
			gfSB.append("<Folder_Level>"+folderlevel+"</Folder_Level>");
			gfSB.append("\n");
			gfSB.append("</folderdetails>");
			gfSB.append("\n");
			
			if(foldertype.equalsIgnoreCase("O"))
			{
				int objectID=(Integer)gfdSession.createSQLQuery("select objectid from mdobject where objectname='"+folderName+"'").uniqueResult();
				MDObjectManagementDAO mdom=new MDObjectManagementDAO();
				String result=mdom.getObjectDetails(objectID);
				gfSB.append(result);
			}
			else if(foldertype.equalsIgnoreCase("D"))
			{
				int deviceID=(Integer)gfdSession.createSQLQuery("select deviceid from mddevice where devicename='"+folderName+"'").uniqueResult();
				MDDeviceManagementDAO mddm=new MDDeviceManagementDAO();
				String result=mddm.getDeviceDetails(deviceID);
				gfSB.append(result);
			}
			else if(foldertype.equalsIgnoreCase("F"))
			{
				MDOrganisationManagementDAO mdorgm=new MDOrganisationManagementDAO();
				String result=mdorgm.getOrganisationDetails(folderName);
				gfSB.append(result);
			}
			gfSB.append("\n");
			gfSB.append("</MD_Folder>");
			
			gfXMLString=gfSB.toString();
			gfSB.setLength(0);
			gfdTx.commit();
			}
		}
		
		catch(Exception localException)
		{
			gfdTx.rollback();
			gfSB.setLength(0);
			MDTransactionWriter.exceptionlog.info(localException);
			gfXMLString="fail";
			
		}
		
		finally
		{
			gfdSession.close();
			gfSB=null;
		}
		
		
		return gfXMLString;
	}
	public String moveFolder(String folderName,String destinationFolderName)
	{
		Session mfSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction mfTx =mfSession.beginTransaction();	
		String str=null;
		try
		{
			mfTx=mfSession.beginTransaction();
			
			int pfid =(Integer)mfSession.createSQLQuery("select folderid from mdfolder where foldername='"+destinationFolderName+"'").uniqueResult();
			
			Query query= mfSession.createSQLQuery("update mdfolder set parentfolderid="+pfid+",modifieddate='"+d+"' where foldername='"+folderName+"'");
			query.executeUpdate();
			
			mfTx.commit();
			str="folder:"+folderName+ "is moved to destination folder:"+destinationFolderName;
		}
		catch(Exception localException)
		{
			mfTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			str="failed to move the folder";
		}
		finally
		{
			mfSession.close();
		}
		return str;

	}
	
	public String deleteFolder(String folderName)

	{
		Session dfSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction dfTx =dfSession.beginTransaction();	
		String str=null;
		try
		{
			dfTx=dfSession.beginTransaction();
		    
		    Query dfQuery = dfSession.createSQLQuery("update mdfolder set status='deleted' where foldername='"+folderName+"'");
		    dfQuery.executeUpdate();
		    
	        dfTx.commit();
	        str="deletion of "+folderName+" folder is done successfully";
		 }
			catch (Exception localException)
			{
				dfTx.rollback();
				MDTransactionWriter.exceptionlog.info(localException);
				str="failure while deletion of folder";
			}
		finally
		{
			dfSession.close();
		}
		return str;
	}
	
	public String renameFolder(String oldName,String newName,int uid)
	{
		Session rfSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction rfTx =rfSession.beginTransaction();	
		String str=null;
		try
		{
			rfTx=rfSession.beginTransaction();
			
			int folderid=(Integer)rfSession.createSQLQuery("select folderid from mdfolder where foldername='"+oldName+"'").uniqueResult();
			
		    Query dfQuery = rfSession.createSQLQuery("update mdfolder set foldername='"+newName+"' , modifieddate='"+d+"' , modifiedby="+uid+" where folderid="+folderid);
		    dfQuery.executeUpdate();
		    
	        rfTx.commit();
	        str="folder renamed";
		 }
			catch (Exception localException)
			{
				rfTx.rollback();
				MDTransactionWriter.exceptionlog.info(localException);
				str="fail";
			}
		finally
		{
			rfSession.close();
		}
		return str;
		
	}
	
	public String updateFolder(MDFolder mdfolder, int uid) {
		Session afSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction afTx=afSession.beginTransaction();	
			String str=null;
			String acl=null;
			String foldername=mdfolder.getFolderName();
			int infid=mdfolder.getInfoclassId();
		    String st=mdfolder.getStatus();
		   String fl=mdfolder.getFolderLevel();
			try
		    {
		    	if(uid==1)
				{
					acl="U#1:111";
				}
				else
				{
					acl="U#1:111;U#"+uid+":111";
				}
		    String fname=(String)afSession.createSQLQuery("select foldername from mdfolder where folderid='"+mdfolder.getParentFolderId()+"'").uniqueResult();
		    Integer pfid=(Integer)afSession.createSQLQuery("select parentfolderid from mdfolder where foldername='"+fname+"'").uniqueResult();
		    Query dfQuery = afSession.createSQLQuery("update mdfolder set PARENTFOLDERID="+pfid+",infoclassid="+infid+",status='"+st+"',acl='"+acl+"',modifieddate='"+d+"',modifiedby="+uid+",folderlevel='"+fl+"' where foldername='"+foldername+"'");
		    dfQuery.executeUpdate();
			str="update of folder done";
		    
			 afTx.commit();
		    }
		    catch(Exception localException)
		    {
		    	afTx.rollback();
		    	MDTransactionWriter.exceptionlog.info(localException);
		    	str="update of folder failed";
		    }
		    finally
		    {
		    	afSession.close();
		    }
		return str;
	}
}
