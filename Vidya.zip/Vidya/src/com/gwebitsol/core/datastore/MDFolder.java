/*
Proprietary Notice
This file contains confidential information of meldit Pvt. Ltd. (India)  and meldit Inc. (USA), 
which is available for the sole purpose of permitting the recipient for engineering and product development purposes.  
In consideration of receipt of this file, the recipient agrees to maintain such information in confidence and not to
reproduce or otherwise disclose this information to any person outside the group directly responsible for its contents.

Security
The information contained herein is proprietary to meldit Pvt. Ltd. (India)  and meldit Inc. (USA) and may not be used, 
reproduced or disclosed.  The recipient of this file, by its retention and use, agrees to protect the same and the 
information contained therein from distribution, loss and theft.
__________________________________________________________________________________________________________________________________________________________________________________
*/

package com.gwebitsol.core.datastore;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "folder")
public class MDFolder
{
	private String folderId;
	private String folderName;
	private int parentFolderId;
	private String infoclassString;
	private int  infoclassId;
	private String status;
	private String folderType;
	private String folderLevel;
	
	
	public String getFolderId() {
		return folderId;
	}
	public void setFolderId(String folderId) {
		this.folderId = folderId;
	}
	public String getFolderName() {
		return folderName;
	}
	public void setFolderName(String folderName) {
		this.folderName = folderName;
	}

	public int getParentFolderId() {
		return parentFolderId;
	}
	public void setParentFolderId(int parentFolderId) {
		this.parentFolderId = parentFolderId;
	}
	public String getInfoclassString() {
		return infoclassString;
	}
	public void setInfoclassString(String infoclassString) {
		this.infoclassString = infoclassString;
	}
	public int getInfoclassId() {
		return infoclassId;
	}
	public void setInfoclassId(int infoclassId) {
		this.infoclassId = infoclassId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getFolderType() {
		return folderType;
	}
	public void setFolderType(String folderType) {
		this.folderType = folderType;
	}
	public String getFolderLevel() {
		return folderLevel;
	}
	public void setFolderLevel(String folderLevel) {
		this.folderLevel = folderLevel;
	}

	
}
