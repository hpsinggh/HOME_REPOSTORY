/*
Proprietary Notice
This file contains confidential information of meldit Pvt. Ltd. (India)  and meldit Inc. (USA), 
which is available for the sole purpose of permitting the recipient for engineering and product development purposes.  
In consideration of receipt of this file, the recipient agrees to maintain such information in confidence and not to
reproduce or otherwise disclose this information to any person outside the group directly responsible for its contents.

Security
The information contained herein is proprietary to meldit Pvt. Ltd. (India)  and meldit Inc. (USA) and may not be used, 
reproduced or disclosed.  The recipient of this file, by its retention and use, agrees to protect the same and the 
information contained therein from distribution, loss and theft.
__________________________________________________________________________________________________________________________________________________________________________________
*/

package com.gwebitsol.core.datastore;

import java.io.BufferedReader;
import java.io.FileReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.auth.MDPrvPOJO;
import com.gwebitsol.core.util.MDEncryptDecryptManager;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;


public class MDDatastoreManagementDAO {

	Session dsmSession = MDHibernateUtil.getSessionFactory().openSession();
	Transaction dsmTx = null;
	String querystring = ";";
	ArrayList<String> myList = new ArrayList<String>();
	StringBuffer sb = new StringBuffer();

	DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	Date date = new Date();
	String d = dateFormat.format(date);
	
	public String createDataStore(HttpServletRequest hsr, String datastoreName, String serverIP, String webserverIP,
			String webserverPort, String dbIP, String dbPassword, String dbUsername, String dbType, String dbPort,
			String melditUsername, String melditPassword, String licenceKey) {
		String str = null;
		try {
			dsmTx = dsmSession.beginTransaction();

			// read the file which contains DB creation statements and create a
			// arraylist of the statements, eliminating some given string
			// formats

			ServletContext sc = hsr.getSession().getServletContext();
			BufferedReader localBufferedReader = new BufferedReader(new FileReader(sc.getRealPath("DB/vidya.sql")));

			while ((str = localBufferedReader.readLine()) != null) {
				if (str.contains("--")) {
				} else if (str.contains("/*")) {
				} else if (str.contains("//")) {
				} else if (str.contains("COMMENT")) {
				}

				else {
					myList.add(str);
				}
			}

			// iterate the arraylist and execute the queries

			for (int i = 0; i < myList.size(); i++) {
				querystring = querystring + myList.get(i);
			}
			StringTokenizer st = new StringTokenizer(querystring, ";");
			while (st.hasMoreElements()) {
				String query = (String) st.nextElement();
				dsmTx = dsmSession.beginTransaction();
				Query dsmQuery = dsmSession.createSQLQuery(query);
				dsmQuery.executeUpdate();
			}

			String name = (String) dsmSession.createSQLQuery("select datastorename from mddatastore").uniqueResult();

			String ip = (String) dsmSession.createSQLQuery("select datastoredbip from mddatastore").uniqueResult();

			if (ip == null & name == null) {
				

				dsmTx = dsmSession.beginTransaction();

				// insert application
				
				sb.append(
						"INSERT INTO  mdapplication(APPNAME,TITLE,DESCRIPTION,UPDATEDDATETIME) "
						+ "VALUES('SchoolApp','EducationIntelligence','this app is for education','0000-00-00 00:00:00')");

				Query appQuery = dsmSession.createSQLQuery(sb.toString());
				appQuery.executeUpdate();
				sb.setLength(0);

				// insert school 
				
				sb.append(
						"INSERT INTO  gbl_sm_tbl_school_info(SchoolName,EstablishedOn,MobileNo,Email,Web,ContactPerson,Location,Photo,LandLine,Fax,Description,Remarks,CreatedDate,ModifiedDate,IsDeleted) "
						+ "VALUES('Gwebitsol','2015-12-05','9866533164','tatasiva@gwebitsol.in','www.gwebitsol.in','sivatata','Musheerabad','0x01101010','040-12345','8565','going to create a history','The best and good','"+d+"','0000-00-00 00:00:00','no')");

				Query schQuery = dsmSession.createSQLQuery(sb.toString());
				schQuery.executeUpdate();
				sb.setLength(0);

				
				int sclid = (Integer) dsmSession
						.createSQLQuery("select SchoolId from gbl_sm_tbl_school_info where SchoolName='Gwebitsol'")
						.uniqueResult();

				// insert branch 
				
				sb.append(
						"INSERT INTO  gbl_sm_tbl_school_branch(BranchName,Image,Priority,Status,Description,EstablishedOn,MobileNo,Email,Web,ContactPerson,Remarks,Location,LandLine,Fax,SchoolId,IsDeleted) "
						+ "VALUES('Kukatpalli','0x10101','1','active','2nd main branch','2016-05-05','9832832932','gwebkukat@gmail.com','www.gweb.in','Raghuveer','works for support','kukatpalli','040-129232','1234','"+sclid+"','no')");

				Query BrQuery = dsmSession.createSQLQuery(sb.toString());
				BrQuery.executeUpdate();
				sb.setLength(0);

				
				int brid = (Integer) dsmSession
						.createSQLQuery("select SchoolBranchId from gbl_sm_tbl_school_branch where SchoolId='"+sclid+"'")
						.uniqueResult();
				
				
				// insert values in mdprivileges tables
				sb.append(
						"INSERT INTO mdprivileges (PRIVILEGEID,PRIVILEGENAME) VALUES(1, 'Administration'),(2, 'Admission/Transfer'),(3, 'Class/Section'),(4, 'Assessments'),(5, 'Fees'),"
								+ "(6, 'Library'),(7, 'Infrastructure'),(8, 'Pedagogy'),(9, 'Settings'),(10, 'Parent'),(11, 'Student'),(12, 'Dairy'),(13, 'Staff'),(14, 'Role'),(15, 'User'),"
								+ "(16, 'School/Branch'),(17, 'Admission'),(18, 'Transfer'),(19, 'Class'),(20, 'Section'),(21, 'Timetable'),(22, 'Attendence'),"
								+ "(23, 'Period'),(24, 'Halltickets'),(25, 'Assessment'),(26, 'Question Paper'),(27, 'Paper Section'),(28, 'Question'),(29, 'Student Answer'),(30, 'Scoresheet'),(31, 'Structure'),"
								+ "(32, 'Fee Item'),(33, 'Payment'),(34, 'Subject'),(35, 'Catalogue'),(36, 'Issues'),(37, 'Book Reciept'),(38, 'Room'),(39, 'Floor'),(40, 'Field'),(41, 'Subjects'),"
								+ "(42, 'Text Book'),(43, 'Unit'),(44, 'Chapter'),(45, 'Topic'),(46, 'Course'),(47, 'Lession Plan'),(48, 'Curriculam'),(49, 'Teaching Plans'),(50, 'Assesment Mode'),"
								+ "(51, 'Assesment Type'),(52, 'Question Type'),(53, 'Room Type'),(54, 'Library Category'),(55, 'Library Section'),(56, 'Book Type'),(57, 'Event Type'),(58, 'Fee Item Type'),(59, 'Job Type'),(60, 'Job Title'),(61, 'Accolade Type'),(62, 'Result Type'),(63, 'Category'),(64, 'Sub Category'),(65, 'Payment Mode');");
			
				Query prvQuery = dsmSession.createSQLQuery(sb.toString());
				prvQuery.executeUpdate();
				sb.setLength(0);

				// create superadmin role

				sb.append(
						"INSERT INTO mdrole (ROLENAME,PRIVILEGESTRING,CREATEDBY,CREATEDDATE,MODIFIEDBY,MODIFIEDDATE,DESCRIPTION) VALUES "
								+ "('superadmin', '1:111;2:111;3:111;4:111;5:111;6:111;7:111;8:111;9:111;10:111;11:111;12:111;13:111;14:111;15:111;16:111;17:111;18:111;19:111;20:111;"
								+ "21:111;22:111;23:111;24:111;25:111;26:111;27:111;28:111;29:111;30:111;31:111;32:111;33:111;34:111;35:111;36:111;37:111;38:111;39:111;40:111;41:111;"
								+ "42:111;43:111;44:111;45:111;46:111;47:111;48:111;49:111;50:111;51:111;52:111;53:111;54:111;55:111;56:111', '"
								+ melditUsername + "', '" + d + "', 'null', "
								+ "'0000-00-00 00:00:00', 'Person having this role has access to all main and sub menus')");
				Query roleQuery = dsmSession.createSQLQuery(sb.toString());
				roleQuery.executeUpdate();
				sb.setLength(0);
				
				
				int id = (Integer) dsmSession
						.createSQLQuery("select roleid from mdrole where CREATEDBY='" + melditUsername + "'")
						.uniqueResult();

				
				MDEncryptDecryptManager enObj = new MDEncryptDecryptManager();
				String pwd = enObj.getEncryptedContent(melditPassword);
				
				
				// create admin user
				sb.append(
						"INSERT INTO MDUSERS(USERNAME,PASSWORD,PASSWORDEXPIRYDATE,STATUS,PHOTO,ROLESTRING,CREATEDDATE,MODIFIEDDATE,CREATEDBY,MODIFIEDBY,LOGINATTEMPTS,EMPLOYEEID,SCHOOLID,BRANCHID) "
								+ "VALUES('" + melditUsername + "','" + pwd
								+ "','2022-11-01','active','0X10101','superadmin;','" + d
								+ "','1991-02-01',1,1,0,'null','"+sclid+"','"+brid+"')");

				Query query = dsmSession.createSQLQuery(sb.toString());
				query.executeUpdate();
				sb.setLength(0);

				/* int id = (Integer) dsmSession
						.createSQLQuery("select userid from mdusers where username='" + melditUsername + "'")
						.uniqueResult(); */

				// insert datastore details into MDDatastore

				sb.append(
						"INSERT INTO MDDATASTORE(datastorename,melditengineip,webserverip,webserverport,datastoredbname,datastoredbip,datastoredbport,dbusername,"
								+ "dbpassword,melditusername,melditpassword,licencekey,createddate,createdby,modifieddate,modifiedby,acl) "
								+ "VALUES('" + datastoreName + "','" + serverIP + "','" + webserverIP + "','"
								+ webserverPort + "','" + dbType + "','" + dbIP + "','" + dbPort + "','" + dbUsername
								+ "','" + dbPassword + "','" + melditUsername + "','" + melditPassword + "','"
								+ licenceKey + "','" + d + "'," + id + ",'0000-00-00 00:00:00','null','R#" + id
								+ ":111')");

				Query query0 = dsmSession.createSQLQuery(sb.toString());
				query0.executeUpdate();
				sb.setLength(0);

				// insert first level items into MDFolder // MAIN MENU ITEMS

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('" + datastoreName + "',-1,0,'active','F','" + d
								+ "','0000-00-00 00:00:00','R#" + id + ":111'," + id + ",0,'P')");

				Query query1 = dsmSession.createSQLQuery(sb.toString());
				query1.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Administration',1,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'P')");

				Query query2 = dsmSession.createSQLQuery(sb.toString());
				query2.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Admission/Transfer',1,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'P')");

				Query query3 = dsmSession.createSQLQuery(sb.toString());
				query3.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Class/Section',1,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'P')");

				Query query4 = dsmSession.createSQLQuery(sb.toString());
				query4.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Assessments',1,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'P')");

				Query query5 = dsmSession.createSQLQuery(sb.toString());
				query5.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Fees',1,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'P')");

				Query query6 = dsmSession.createSQLQuery(sb.toString());
				query6.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Library',1,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'P')");

				Query query7 = dsmSession.createSQLQuery(sb.toString());
				query7.executeUpdate();
				sb.setLength(0);

				// SUB MENU ITEMS of Businessadmin //

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Infrastructure',1,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query8 = dsmSession.createSQLQuery(sb.toString());
				query8.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Pedagogy','1','0','active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query9 = dsmSession.createSQLQuery(sb.toString());
				query9.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Settings',1,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query10 = dsmSession.createSQLQuery(sb.toString());
				query10.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Parent',2,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query11 = dsmSession.createSQLQuery(sb.toString());
				query11.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Student',2,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query12 = dsmSession.createSQLQuery(sb.toString());
				query12.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Dairy',2,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query13 = dsmSession.createSQLQuery(sb.toString());
				query13.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Staff',2,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query14 = dsmSession.createSQLQuery(sb.toString());
				query14.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Role',2,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query15 = dsmSession.createSQLQuery(sb.toString());
				query15.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('User',2,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query16 = dsmSession.createSQLQuery(sb.toString());
				query16.executeUpdate();
				sb.setLength(0);

				// SUB MENU items of dashboard

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('School/Branch',2,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query17 = dsmSession.createSQLQuery(sb.toString());
				query17.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL)"
								+ " VALUES('Admission',3,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query18 = dsmSession.createSQLQuery(sb.toString());
				query18.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Transfer',3,0,'active','M','" + d + "','0000-00-00 00:00:00','R#"
								+ id + ":111'," + id + ",0,'L')");

				Query query19 = dsmSession.createSQLQuery(sb.toString());
				query19.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL)"
								+ " VALUES('Class',4,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query20 = dsmSession.createSQLQuery(sb.toString());
				query20.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Section',4,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query21 = dsmSession.createSQLQuery(sb.toString());
				query21.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Timetable',4,0,'active','M','" + d + "','0000-00-00 00:00:00','R#"
								+ id + ":111'," + id + ",0,'L')");

				Query query22 = dsmSession.createSQLQuery(sb.toString());
				query22.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Attendence',4,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id + ":111',"
								+ id + ",0,'L')");

				Query query23 = dsmSession.createSQLQuery(sb.toString());
				query23.executeUpdate();
				sb.setLength(0);

				// SUB MENU ITEMS of Systemadmin

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL)"
								+ " VALUES('Period',4,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'P')");

				Query query24 = dsmSession.createSQLQuery(sb.toString());
				query24.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Halltickets',4,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'P')");

				Query query25 = dsmSession.createSQLQuery(sb.toString());
				query25.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Assessment',5,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query26 = dsmSession.createSQLQuery(sb.toString());
				query26.executeUpdate();
				sb.setLength(0);

				// SUB MENU OF MANAGEMENT // sub sub menu of systemadmin

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Question Paper',5,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query27 = dsmSession.createSQLQuery(sb.toString());
				query27.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Paper Section',5,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query28 = dsmSession.createSQLQuery(sb.toString());
				query28.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Question',5,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query29 = dsmSession.createSQLQuery(sb.toString());
				query29.executeUpdate();
				sb.setLength(0);

				// SUB MENU OF ADMIN

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Student Answer',5,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query30 = dsmSession.createSQLQuery(sb.toString());
				query30.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Scoresheet',5,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query31 = dsmSession.createSQLQuery(sb.toString());
				query31.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Structure',6,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query32 = dsmSession.createSQLQuery(sb.toString());
				query32.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Fee Item',6,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query33 = dsmSession.createSQLQuery(sb.toString());
				query33.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Payment',6,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query34 = dsmSession.createSQLQuery(sb.toString());
				query34.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Subject',7,0,'active','M','" + d + "','0000-00-00 00:00:00','R#"
								+ id + ":111'," + id + ",0,'L')");

				Query query35 = dsmSession.createSQLQuery(sb.toString());
				query35.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Catalogue',7,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query36 = dsmSession.createSQLQuery(sb.toString());
				query36.executeUpdate();
				sb.setLength(0);

				// SUB MENU OF MESSAGES

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Issues',7,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query37 = dsmSession.createSQLQuery(sb.toString());
				query37.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Sent Items',7,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query38 = dsmSession.createSQLQuery(sb.toString());
				query38.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Book Reciept',7,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query39 = dsmSession.createSQLQuery(sb.toString());
				query39.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Room',8,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query40 = dsmSession.createSQLQuery(sb.toString());
				query40.executeUpdate();
				sb.setLength(0);

				// SUB MENU of SalesAndBilling

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Floor',8,0,'active','M','" + d + "','0000-00-00 00:00:00','R#"
								+ id + ":111'," + id + ",0,'L')");

				Query query41 = dsmSession.createSQLQuery(sb.toString());
				query41.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Field',8,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query42 = dsmSession.createSQLQuery(sb.toString());
				query42.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Subjects',9,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query43 = dsmSession.createSQLQuery(sb.toString());
				query43.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Text Book',9,0,'active','M','" + d + "','0000-00-00 00:00:00','R#"
								+ id + ":111'," + id + ",0,'L')");

				Query query44 = dsmSession.createSQLQuery(sb.toString());
				query44.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Unit',9,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id + ":111',"
								+ id + ",0,'L')");

				Query query45 = dsmSession.createSQLQuery(sb.toString());
				query45.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Chapter',9,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id + ":111',"
								+ id + ",0,'L')");

				Query query46 = dsmSession.createSQLQuery(sb.toString());
				query46.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Topic',9,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query47 = dsmSession.createSQLQuery(sb.toString());
				query47.executeUpdate();
				sb.setLength(0);

				// SUM MENU OF REPORTS

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL)"
								+ " VALUES('Course',9,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'P')");

				Query query48 = dsmSession.createSQLQuery(sb.toString());
				query48.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Lession Plan',9,0,'active','M','" + d + "','0000-00-00 00:00:00','R#"
								+ id + ":111'," + id + ",0,'P')");

				Query query49 = dsmSession.createSQLQuery(sb.toString());
				query49.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Curriculam',9,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query50 = dsmSession.createSQLQuery(sb.toString());
				query50.executeUpdate();
				sb.setLength(0);

				// SUB MENU OF CORE

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Teaching Plans',9,0,'active','M','" + d + "','0000-00-00 00:00:00','R#"
								+ id + ":111'," + id + ",0,'L')");

				Query query51 = dsmSession.createSQLQuery(sb.toString());
				query51.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Assesment Mode',10,0,'active','M','" + d + "','0000-00-00 00:00:00','R#"
								+ id + ":111'," + id + ",0,'L')");

				Query query52 = dsmSession.createSQLQuery(sb.toString());
				query52.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Assesment Type',48,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query53 = dsmSession.createSQLQuery(sb.toString());
				query53.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Question Type',48,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query54 = dsmSession.createSQLQuery(sb.toString());
				query54.executeUpdate();
				sb.setLength(0);

				// SUB MENU of SalesANDMarketing

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Room Type',49,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query55 = dsmSession.createSQLQuery(sb.toString());
				query55.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
								+ "VALUES('Library Category',49,0,'active','M','" + d + "','0000-00-00 00:00:00','R#"
								+ id + ":111'," + id + ",0,'L')");

				Query query56 = dsmSession.createSQLQuery(sb.toString());
				query56.executeUpdate();
				sb.setLength(0);

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL)"
								+ " VALUES('Library Section',49,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query57 = dsmSession.createSQLQuery(sb.toString());
				query57.executeUpdate();
				sb.setLength(0);
				
				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL)"
								+ " VALUES('Book Type',49,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query58 = dsmSession.createSQLQuery(sb.toString());
				query58.executeUpdate();
				sb.setLength(0);
				
				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL)"
								+ " VALUES('Event Type',49,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query59 = dsmSession.createSQLQuery(sb.toString());
				query59.executeUpdate();
				sb.setLength(0);
				
				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL)"
								+ " VALUES('Fee Item Type',49,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query60 = dsmSession.createSQLQuery(sb.toString());
				query60.executeUpdate();
				sb.setLength(0);
				
				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL)"
								+ " VALUES('Job Type',49,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query61 = dsmSession.createSQLQuery(sb.toString());
				query61.executeUpdate();
				sb.setLength(0);
				
				
				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL)"
								+ " VALUES('Job Title',49,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query62 = dsmSession.createSQLQuery(sb.toString());
				query62.executeUpdate();
				sb.setLength(0);
				
				
				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL)"
								+ " VALUES('Accolade Type',49,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query63 = dsmSession.createSQLQuery(sb.toString());
				query63.executeUpdate();
				sb.setLength(0);
				
				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL)"
								+ " VALUES('Result Type',49,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query64 = dsmSession.createSQLQuery(sb.toString());
				query64.executeUpdate();
				sb.setLength(0);
				
				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL)"
								+ " VALUES('Category',49,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query65 = dsmSession.createSQLQuery(sb.toString());
				query65.executeUpdate();
				sb.setLength(0);
				

				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL)"
								+ " VALUES('Sub Category',49,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query66 = dsmSession.createSQLQuery(sb.toString());
				query66.executeUpdate();
				sb.setLength(0);
				
				sb.append(
						"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL)"
								+ " VALUES('Payment Mode',49,0,'active','M','" + d + "','0000-00-00 00:00:00','R#" + id
								+ ":111'," + id + ",0,'L')");

				Query query67 = dsmSession.createSQLQuery(sb.toString());
				query67.executeUpdate();
				sb.setLength(0);
				
				// INSERT LICENCE INFORMATION

				sb.append(
						"INSERT INTO MDLICENCEINFO (LICENCENAME,LICENCEKEY,COMPANYNAME,COMPANYADDRESS,COMPANYCONTACTINFO,ACTIVATEDDATE,EXPIRYDATE,NOOFLICENCEDUSERS) "
								+ "VALUES('meldit','" + licenceKey + "','meldit','india','meldit@nivistatech.com','" + d
								+ "','0000-00-00 00:00:00',30)");

				Query query68 = dsmSession.createSQLQuery(sb.toString());
				query68.executeUpdate();
				sb.setLength(0);

				dsmTx.commit();
				str = "successful creation of datastore";

				// Siva Tata, 5/7/2014; closed open BufferedReader
			//	localBufferedReader.close();
			} else {
				str = "Datastore Already Exists";
			}

		} catch (Exception localException) {
			dsmTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			str = "fail";
		} finally {
			dsmSession.close();

		}
		return str;
	}
	
	public String addPrivileges(MDPrivilegesList mdprivi,int userid,int parentfolderid,String folderlevel,String foldertype) {
		Session dsmSession = MDHibernateUtil.getSessionFactory().openSession();
		String str = null;

		try {
			dsmTx = dsmSession.beginTransaction();

			List<MDPrvPOJO> prvlist = mdprivi.getMdprv();

			Iterator csIT = prvlist.iterator();

			while (csIT.hasNext()) {
				MDPrvPOJO prvobj = (MDPrvPOJO) csIT.next();
				dsmSession.save(prvobj);
				
				 String rolestr = (String) dsmSession
				.createSQLQuery("select ROLESTRING from mdusers where USERID='" + userid + "'")
				.uniqueResult();
				 
				 String[] roles= rolestr.split(";");
				 for(int i=0;i<=roles.length-1;i++)
				 {
			    	
			    	String role = roles[i];
				 
			    	if(role!=null)
			    	{
			    	int roleid = (Integer) dsmSession
							.createSQLQuery("select ROLEID from mdrole where ROLENAME='" + role + "'")
							.uniqueResult();

			    	String foldername  = prvobj.getPrivilegeName();

			    	String mdf=
							"INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) "
									+ "VALUES('"+ foldername+"','"+parentfolderid+"',0,'active','"+foldertype+"','" + d
									+ "','0000-00-00 00:00:00','R#" + roleid + ":111'," + userid + ",0,'"+folderlevel+"')";
					Query query1 = dsmSession.createSQLQuery(mdf);
					query1.executeUpdate();
			    	}

				 }
			}
			dsmTx.commit();
			str = "success";
		} catch (Exception localException) {
			dsmTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			str = "fail";
		} finally {
			dsmSession.close();

		}
		return str;
	}
}
