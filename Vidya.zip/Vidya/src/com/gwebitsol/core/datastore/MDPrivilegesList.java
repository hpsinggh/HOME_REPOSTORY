package com.gwebitsol.core.datastore;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

import com.gwebitsol.core.auth.MDPrvPOJO;

@XmlRootElement(name="MD_Privileges")

public class MDPrivilegesList implements Serializable{

MDPrivilegesWrapper mdpw = new MDPrivilegesWrapper();
	
	@XmlElementWrapper(name="privileges")
    @XmlElement(name="privilege")
	public List<MDPrvPOJO> getMdprv() {
		return mdpw.getMdprv();
	}

	public void setMdprv(List<MDPrvPOJO> mdprv) {
		mdpw.setMdprv(mdprv);
	}
}
