/*
Proprietary Notice
This file contains confidential information of meldit Pvt. Ltd. (India)  and meldit Inc. (USA), 
which is available for the sole purpose of permitting the recipient for engineering and product development purposes.  
In consideration of receipt of this file, the recipient agrees to maintain such information in confidence and not to
reproduce or otherwise disclose this information to any person outside the group directly responsible for its contents.

Security
The information contained herein is proprietary to meldit Pvt. Ltd. (India)  and meldit Inc. (USA) and may not be used, 
reproduced or disclosed.  The recipient of this file, by its retention and use, agrees to protect the same and the 
information contained therein from distribution, loss and theft.
__________________________________________________________________________________________________________________________________________________________________________________
*/

package com.gwebitsol.core.datastore;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

import com.gwebitsol.core.datastore.MDFolder;

@Path("/foldermanagement/")
public interface MDFolderManagementServiceIntf 
{
	@POST
	@Consumes({"application/xml","application/xml"})
	@Produces({"application/xml","application/xml"})
	@Path("/addfolder/")
	public Response addFolder(MDFolder mdfolder,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@POST
	@Produces ({"application/xml","application/json"})
	@Path("/getsubfolders/")
	public Response getSubFolder(@QueryParam("folderId") int folderId,@QueryParam("folderName") String folderName,
			@QueryParam("folderType") String folderType, @QueryParam("infoclassId") int infoclassId,
			@QueryParam("status") String status,
			@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,
			@QueryParam("datastoreName") String datastoreName);
	
	@PUT
	@Consumes()
	@Produces()
	@Path("/deletefolder")
	public Response deleteFolder(@QueryParam("folderName") String foldername,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@PUT
	@Consumes()
	@Produces()
	@Path("/delallsubfolders")
	public Response deleteAllSubFolder(@QueryParam("folderid") int folderid,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@PUT
	@Consumes()
	@Produces()
	@Path("/movefolder")
	public Response moveFolder(@QueryParam("folderName") String foldername,@QueryParam("destinationFolderName") String destinationFolderName,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@GET
	@Produces({"application/xml","application/json"})
	@Path("/getfolderdetails")
	public Response getFolderDetails(@QueryParam("folderName") String folderName,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@POST
	@Produces({"application/xml","application/xml"})
	@Path("/renamefolder/")
	public Response renameFolder(@QueryParam("oldName") String oldName,@QueryParam("newName") String newName,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@POST
	@Produces({"application/xml","application/xml"})
	@Path("/updatefolder/")
	public Response updateFolder(MDFolder mdfolder,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
}
