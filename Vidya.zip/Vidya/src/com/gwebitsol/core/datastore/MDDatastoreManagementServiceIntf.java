/*
Proprietary Notice
This file contains confidential information of meldit Pvt. Ltd. (India)  and meldit Inc. (USA), 
which is available for the sole purpose of permitting the recipient for engineering and product development purposes.  
In consideration of receipt of this file, the recipient agrees to maintain such information in confidence and not to
reproduce or otherwise disclose this information to any person outside the group directly responsible for its contents.

Security
The information contained herein is proprietary to meldit Pvt. Ltd. (India)  and meldit Inc. (USA) and may not be used, 
reproduced or disclosed.  The recipient of this file, by its retention and use, agrees to protect the same and the 
information contained therein from distribution, loss and theft.
__________________________________________________________________________________________________________________________________________________________________________________
*/

package com.gwebitsol.core.datastore;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

@Path("/registration/")
public interface MDDatastoreManagementServiceIntf 
{
	@Path("/register")
	@POST
	@Consumes({"application/xml", "application/json"})
	@Produces({"application/xml", "application/json"})
	public Response createDatastore(MDDatastore mdDatastore);
	
	@Path("/addprivileges")
	@Produces({ "application/xml", "application/json" })
	@Consumes({ "application/xml", "application/json" })
	@POST
	public Response addPrivileges(MDPrivilegesList mdprivi, @QueryParam("userid") int userid,
			@QueryParam("parentfolderid") int parentfolderid, @QueryParam("folderlevel") String folderlevel,
			@QueryParam("foldertype") String foldertype);
}
