/*
Proprietary Notice
This file contains confidential information of meldit Pvt. Ltd. (India)  and meldit Inc. (USA), 
which is available for the sole purpose of permitting the recipient for engineering and product development purposes.  
In consideration of receipt of this file, the recipient agrees to maintain such information in confidence and not to
reproduce or otherwise disclose this information to any person outside the group directly responsible for its contents.

Security
The information contained herein is proprietary to meldit Pvt. Ltd. (India)  and meldit Inc. (USA) and may not be used, 
reproduced or disclosed.  The recipient of this file, by its retention and use, agrees to protect the same and the 
information contained therein from distribution, loss and theft.
__________________________________________________________________________________________________________________________________________________________________________________
*/


package com.gwebitsol.core.datastore;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="MDRegistration")
public class MDDatastore 
{
	private String datastoreName;
	private String serverIP;
	private String webserverIP;
	private String webserverPort;
	private String dbIP;
	private String dbPassword;
	private String dbUserName;
	private String dbType;
	private String dbPort;
	private String melditUserName;
	private String melditPassword;
	private String licenceKey;
	public String getDatastoreName() {
		return datastoreName;
	}
	public void setDatastoreName(String datastoreName) {
		this.datastoreName = datastoreName;
	}
	public String getServerIP() {
		return serverIP;
	}
	public void setServerIP(String serverIP) {
		this.serverIP = serverIP;
	}
	public String getWebserverIP() {
		return webserverIP;
	}
	public void setWebserverIP(String webserverIP) {
		this.webserverIP = webserverIP;
	}
	public String getWebserverPort() {
		return webserverPort;
	}
	public void setWebserverPort(String webserverPort) {
		this.webserverPort = webserverPort;
	}
	public String getDbIP() {
		return dbIP;
	}
	public void setDbIP(String dbIP) {
		this.dbIP = dbIP;
	}
	public String getDbPassword() {
		return dbPassword;
	}
	public void setDbPassword(String dbPassword) {
		this.dbPassword = dbPassword;
	}
	public String getDbUserName() {
		return dbUserName;
	}
	public void setDbUserName(String dbUserName) {
		this.dbUserName = dbUserName;
	}
	public String getDbType() {
		return dbType;
	}
	public void setDbType(String dbType) {
		this.dbType = dbType;
	}
	public String getDbPort() {
		return dbPort;
	}
	public void setDbPort(String dbPort) {
		this.dbPort = dbPort;
	}
	public String getMelditUserName() {
		return melditUserName;
	}
	public void setMelditUserName(String melditUserName) {
		this.melditUserName = melditUserName;
	}
	public String getMelditPassword() {
		return melditPassword;
	}
	public void setMelditPassword(String melditPassword) {
		this.melditPassword = melditPassword;
	}
	public String getLicenceKey() {
		return licenceKey;
	}
	public void setLicenceKey(String licenceKey) {
		this.licenceKey = licenceKey;
	}
	
			
}
