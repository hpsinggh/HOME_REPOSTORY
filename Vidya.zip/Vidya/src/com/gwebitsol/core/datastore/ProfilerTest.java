/*
Proprietary Notice
This file contains confidential information of meldit Pvt. Ltd. (India)  and meldit Inc. (USA), 
which is available for the sole purpose of permitting the recipient for engineering and product development purposes.  
In consideration of receipt of this file, the recipient agrees to maintain such information in confidence and not to
reproduce or otherwise disclose this information to any person outside the group directly responsible for its contents.

Security
The information contained herein is proprietary to meldit Pvt. Ltd. (India)  and meldit Inc. (USA) and may not be used, 
reproduced or disclosed.  The recipient of this file, by its retention and use, agrees to protect the same and the 
information contained therein from distribution, loss and theft.
__________________________________________________________________________________________________________________________________________________________________________________
*/

package com.gwebitsol.core.datastore;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;



public class ProfilerTest 

{
	
	public static void main(String args[]) throws SQLException
	{
		ProfilerTest pt=new ProfilerTest();
		pt.executeProfiler();
	}
	
	public String executeProfiler() throws SQLException
	{
		Connection con = DriverManager.getConnection("jdbc:mysql://52.74.126.180:3306/vidya?user=vidya&password=meldit");
	    Statement stmt = null;
		StringBuffer sb=new StringBuffer();
		String str=null;
	    try {
	    	stmt = (Statement) con.createStatement();
		BufferedReader localBufferedReader = new BufferedReader(new FileReader("D:/swati/profiler.sql"));
		//stmt.execute("DELIMITER $$");
		
		while ((str = localBufferedReader.readLine()) != null) 
		 {
			
			sb.append(str);
			//sb.append("\n");
			
		 }
		
		 stmt.execute(sb.toString());
		//stmt.execute("DELIMITER ;");
		//System.out.println(sb.toString());
		
	   
		/*String query=sb.toString();
  		dsmTx=dsmSession.beginTransaction();
  	    Query dsmQuery=dsmSession.createSQLQuery(query);
  	    dsmQuery.executeUpdate();*/
		 
	
	    } catch (IOException e) 
	    {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "success";
	}

}
