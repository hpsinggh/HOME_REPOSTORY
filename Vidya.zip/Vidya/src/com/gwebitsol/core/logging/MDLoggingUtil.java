package com.gwebitsol.core.logging;

import java.util.Date;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.http.HttpServlet;

import org.apache.log4j.PropertyConfigurator;

import com.gwebitsol.core.security.LogoutThread;
import com.gwebitsol.core.util.MDTransactionWriter;

public class MDLoggingUtil extends HttpServlet 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void init()
	{
		String prefix =  getServletContext().getRealPath("/");
		String file = getInitParameter("LOG4J-INIT-FILE");


		if(file != null)
		{
			PropertyConfigurator.configure(prefix+file);
			System.out.println("Log4J Logging started: " + prefix+file);
			MDTransactionWriter.MDLoggerTest();
			
		}
		else
		{
			System.out.println("Log4J Is not configured for your Application: " + prefix + file);
			
		} 

		Thread logoutTh=new Thread(new LogoutThread());
		/*Thread calAutoTh=new Thread(new CallMDGetAutoThread());
	 	calAutoTh.start();*/

		logoutTh.start();
	}
	
	public void contextInitialized(ServletContextEvent event) {
		ServletContext context = event.getServletContext();
		System.setProperty("rootPath", context.getRealPath("/"));
		
	}
	
	
}

