/*
Proprietary Notice
This file contains confidential information of meldit Pvt. Ltd. (India)  and meldit Inc. (USA), 
which is available for the sole purpose of permitting the recipient for engineering and product development purposes.  
In consideration of receipt of this file, the recipient agrees to maintain such information in confidence and not to
reproduce or otherwise disclose this information to any person outside the group directly responsible for its contents.

Security
The information contained herein is proprietary to meldit Pvt. Ltd. (India)  and meldit Inc. (USA) and may not be used, 
reproduced or disclosed.  The recipient of this file, by its retention and use, agrees to protect the same and the 
information contained therein from distribution, loss and theft.
__________________________________________________________________________________________________________________________________________________________________________________
*/

package com.gwebitsol.core.eventmanager;

public class MDListener 
{

	private int listenerID;
	private String listenerName;
	private String ListenerType;
	private String programName;
	private String listenerStatus;
	private String createdDateTime;
	private String updatedDateTime;
	private String listenerDescription;
	public int getListenerID() {
		return listenerID;
	}
	public void setListenerID(int listenerID) {
		this.listenerID = listenerID;
	}
	public String getListenerName() {
		return listenerName;
	}
	public void setListenerName(String listenerName) {
		this.listenerName = listenerName;
	}
	public String getListenerType() {
		return ListenerType;
	}
	public void setListenerType(String listenerType) {
		ListenerType = listenerType;
	}
	public String getProgramName() {
		return programName;
	}
	public void setProgramName(String programName) {
		this.programName = programName;
	}
	public String getListenerStatus() {
		return listenerStatus;
	}
	public void setListenerStatus(String listenerStatus) {
		this.listenerStatus = listenerStatus;
	}
	public String getCreatedDateTime() {
		return createdDateTime;
	}
	public void setCreatedDateTime(String createdDateTime) {
		this.createdDateTime = createdDateTime;
	}
	public String getUpdatedDateTime() {
		return updatedDateTime;
	}
	public void setUpdatedDateTime(String updatedDateTime) {
		this.updatedDateTime = updatedDateTime;
	}
	public String getListenerDescription() {
		return listenerDescription;
	}
	public void setListenerDescription(String listenerDescription) {
		this.listenerDescription = listenerDescription;
	}
}
