/*
Proprietary Notice
This file contains confidential information of meldit Pvt. Ltd. (India)  and meldit Inc. (USA), 
which is available for the sole purpose of permitting the recipient for engineering and product development purposes.  
In consideration of receipt of this file, the recipient agrees to maintain such information in confidence and not to
reproduce or otherwise disclose this information to any person outside the group directly responsible for its contents.

Security
The information contained herein is proprietary to meldit Pvt. Ltd. (India)  and meldit Inc. (USA) and may not be used, 
reproduced or disclosed.  The recipient of this file, by its retention and use, agrees to protect the same and the 
information contained therein from distribution, loss and theft.
__________________________________________________________________________________________________________________________________________________________________________________
*/

package com.gwebitsol.core.eventmanager;
public class MDEvent
{
	private int eventID;
	private String eventName;
	private String eventType;
	private String eventOwner;
	private String eventListeners;
	private String eventStatus;
	private String createdDateTime;
	private String updatedDateTime;
	public int getEventID() {
		return eventID;
	}
	public void setEventID(int eventID) {
		this.eventID = eventID;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public String getEventType() {
		return eventType;
	}
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	public String getEventOwner() {
		return eventOwner;
	}
	public void setEventOwner(String eventOwner) {
		this.eventOwner = eventOwner;
	}
	
	public String getEventListeners() {
		return eventListeners;
	}
	public void setEventListeners(String eventListeners) {
		this.eventListeners = eventListeners;
	}
	public String getEventStatus() {
		return eventStatus;
	}
	public void setEventStatus(String eventStatus) {
		this.eventStatus = eventStatus;
	}
	public String getCreatedDateTime() {
		return createdDateTime;
	}
	public void setCreatedDateTime(String createdDateTime) {
		this.createdDateTime = createdDateTime;
	}
	public String getUpdatedDateTime() {
		return updatedDateTime;
	}
	public void setUpdatedDateTime(String updatedDateTime) {
		this.updatedDateTime = updatedDateTime;
	}


}
