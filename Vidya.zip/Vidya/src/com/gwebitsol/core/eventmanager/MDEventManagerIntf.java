/*
Proprietary Notice
This file contains confidential information of meldit Pvt. Ltd. (India)  and meldit Inc. (USA), 
which is available for the sole purpose of permitting the recipient for engineering and product development purposes.  
In consideration of receipt of this file, the recipient agrees to maintain such information in confidence and not to
reproduce or otherwise disclose this information to any person outside the group directly responsible for its contents.

Security
The information contained herein is proprietary to meldit Pvt. Ltd. (India)  and meldit Inc. (USA) and may not be used, 
reproduced or disclosed.  The recipient of this file, by its retention and use, agrees to protect the same and the 
information contained therein from distribution, loss and theft.
__________________________________________________________________________________________________________________________________________________________________________________
*/

package com.gwebitsol.core.eventmanager;

import com.gwebitsol.core.eventmanager.MDEvent;
import com.gwebitsol.core.eventmanager.MDListener;

public interface MDEventManagerIntf 
{
	
	//This method is used to add events to MDEvent table
	public void registerEvent(MDEvent mdevent);
	
	//This method is used to add listeners to MDListener table
	//public void registerListener(MDListener listener);
	
	//This method is used to add listener to MDEvent table
	public void assignListenerToEvent(String eventName,String listenerName);
	
	//This method is used to load event name and event parameters with values to
	//the eventstore DB Table
	
	public void loadEventToEventStore(String eventName,String eventParameter,String eventParameterValues);
	
		
	/*public void receiveEvent();
	public void notifyEventToListeners();*/
}
