/*
Proprietary Notice
This file contains confidential information of meldit Pvt. Ltd. (India)  and meldit Inc. (USA), 
which is available for the sole purpose of permitting the recipient for engineering and product development purposes.  
In consideration of receipt of this file, the recipient agrees to maintain such information in confidence and not to
reproduce or otherwise disclose this information to any person outside the group directly responsible for its contents.

Security
The information contained herein is proprietary to meldit Pvt. Ltd. (India)  and meldit Inc. (USA) and may not be used, 
reproduced or disclosed.  The recipient of this file, by its retention and use, agrees to protect the same and the 
information contained therein from distribution, loss and theft.
__________________________________________________________________________________________________________________________________________________________________________________
*/

package com.gwebitsol.core.eventmanager;

/*
 * A process that monitors the events. The Event Monitor picks up the Events that 
 * are triggered and gives the Events and their Listener list to the Event Notifier
 */
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.util.MDHibernateUtil;

public class MDEventMonitor implements Runnable
{
	Session session=MDHibernateUtil.getSessionFactory().openSession();
	Transaction transaction = null;	
	public void run() 
	{
		try{
			transaction=session.beginTransaction();
			String sql="select * from mdeventstore where eventstatus='inprogress'";
			Query q=session.createSQLQuery(sql);
			List l=q.list();
			Iterator it=l.iterator();
			while(it.hasNext())
			{
				Object[] o=(Object[])it.next();
				System.out.println("storeid:" +o[0]);

			}
			transaction.commit();
		}catch(Exception e)
		{
			e.printStackTrace();
		}

		session.close();


	}
}
