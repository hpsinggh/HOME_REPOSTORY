/*
Proprietary Notice
This file contains confidential information of meldit Pvt. Ltd. (India)  and meldit Inc. (USA), 
which is available for the sole purpose of permitting the recipient for engineering and product development purposes.  
In consideration of receipt of this file, the recipient agrees to maintain such information in confidence and not to
reproduce or otherwise disclose this information to any person outside the group directly responsible for its contents.

Security
The information contained herein is proprietary to meldit Pvt. Ltd. (India)  and meldit Inc. (USA) and may not be used, 
reproduced or disclosed.  The recipient of this file, by its retention and use, agrees to protect the same and the 
information contained therein from distribution, loss and theft.
__________________________________________________________________________________________________________________________________________________________________________________
*/

package com.gwebitsol.core.eventmanager;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.util.MDHibernateUtil;

public class MDAddListenerIDsToList
{
	Session session=MDHibernateUtil.getSessionFactory().openSession();
	Transaction transaction = null;	

	public ArrayList add(String eventName)
	{
		ArrayList al=new ArrayList();
		try
		{
			transaction=session.beginTransaction();
			String sql="select * from mdevents where eventname='"+eventName+"'";
			Query eventQuery=session.createSQLQuery(sql);
			List eventList=eventQuery.list();
			Iterator it=eventList.iterator();
			StringBuffer sb=new StringBuffer();
			while(it.hasNext())
			{
				Object[] obj=(Object[])it.next();
				sb.append(obj[4]);

			}
			String str=sb.toString();
			StringTokenizer stg=new StringTokenizer(str,",");
			while (stg.hasMoreElements()) 
			{
				al.add(stg.nextElement());
			}

			transaction.commit();

		}
		catch(Exception e)
		{
			e.printStackTrace();

		}
		finally
		{
			session.close();
		}
		return al;
	}
}
