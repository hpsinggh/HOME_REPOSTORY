/*
Proprietary Notice
This file contains confidential information of meldit Pvt. Ltd. (India)  and meldit Inc. (USA), 
which is available for the sole purpose of permitting the recipient for engineering and product development purposes.  
In consideration of receipt of this file, the recipient agrees to maintain such information in confidence and not to
reproduce or otherwise disclose this information to any person outside the group directly responsible for its contents.

Security
The information contained herein is proprietary to meldit Pvt. Ltd. (India)  and meldit Inc. (USA) and may not be used, 
reproduced or disclosed.  The recipient of this file, by its retention and use, agrees to protect the same and the 
information contained therein from distribution, loss and theft.
__________________________________________________________________________________________________________________________________________________________________________________
*/

package com.gwebitsol.core.eventmanager;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/*
 * The Event notifier identifies all the event listeners from the Listener Store 
 * and then call them giving the Event details.
 */
public class MDEventNotifier 
{
	private String eventName;
	private List _listeners = new ArrayList();
	public synchronized void notifyEventToListeners(int[] listenerIDs) 
	{
		//get the list of listeners
		Iterator i = _listeners.iterator();
		while(i.hasNext())  
		{

			((MDEventListener)i.next()).handleEvent(eventName);
			//remove the completed listener from the array
		}
	}
}
