/*
Proprietary Notice
This file contains confidential information of meldit Pvt. Ltd. (India)  and meldit Inc. (USA), 
which is available for the sole purpose of permitting the recipient for engineering and product development purposes.  
In consideration of receipt of this file, the recipient agrees to maintain such information in confidence and not to
reproduce or otherwise disclose this information to any person outside the group directly responsible for its contents.

Security
The information contained herein is proprietary to meldit Pvt. Ltd. (India)  and meldit Inc. (USA) and may not be used, 
reproduced or disclosed.  The recipient of this file, by its retention and use, agrees to protect the same and the 
information contained therein from distribution, loss and theft.
__________________________________________________________________________________________________________________________________________________________________________________
*/

package com.gwebitsol.core.eventmanager;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.gwebitsol.core.eventmanager.MDEvent;
import com.gwebitsol.core.eventmanager.MDListener;
import com.gwebitsol.core.util.MDHibernateUtil;

/*
 * The Event Manager serializes the Event and the Event Notifier is informed 
 * that the Event Id is added to the Event Store. In this case Event Notifier 
 * receives the Event ID from the Event Manager.
 * EvenetManager is responsible for registering events,listeners,add events to event
 * store  and inform to event notifier 
 */

public class MDEventManager implements MDEventManagerIntf
{
	private String eventName;
	private List _listeners = new ArrayList();

	private static Logger transactionLog=Logger.getLogger("transactionLog");
	private static Logger exceptionLog=Logger.getLogger("exceptionLog");
	

	public void registerEvent(MDEvent event)
	{
		SessionFactory factory=MDHibernateUtil.getSessionFactory();
		Session evnSession=factory.openSession();
		Transaction transaction = null;
		try{
			transactionLog.info("Event regisration starting");
			transaction=evnSession.beginTransaction();
			evnSession.save(event);
			transaction.commit();

		}
		catch(Exception localexception)
		{
			exceptionLog.info("",localexception);
		}
		finally
		{
			evnSession.close();
		}
		
	}


	public void registerListener(MDListener listener)
	{
		SessionFactory factory=MDHibernateUtil.getSessionFactory();
		Session lisSession=factory.openSession();
		Transaction transaction = null;	
		try{
			transactionLog.info("Listener regisration starting");
			transaction=lisSession.beginTransaction();
			lisSession.save(listener);
			transaction.commit();
		}
		catch(Exception localexception)
		{
			exceptionLog.info("",localexception);
		}
		finally
		{
			lisSession.close();
		}
			
	}


	public void assignListenerToEvent(String eventName,String listenerName)
	{
		SessionFactory factory=MDHibernateUtil.getSessionFactory();
		Session aleSession=factory.openSession();
		Transaction transaction = null;	
		try{
			transactionLog.info("Assigning Listener to Event");
			transaction=aleSession.beginTransaction();

			String aleSql0="select eventlisteners from mdevents where eventname='"+eventName+"'";
			String oldlistenerid=(String)aleSession.createSQLQuery(aleSql0).uniqueResult();

			String aleSql="select listenerid from mdlistener where listenername='"+listenerName+"'";
			int listenerid=(Integer)aleSession.createSQLQuery(aleSql).uniqueResult();

			String aleSql1="update mdevents set eventlisteners='"+oldlistenerid+","+listenerid+"' where eventname='"+eventName+"'";
			Query aleQuery=aleSession.createSQLQuery(aleSql1);
			aleQuery.executeUpdate();
			transaction.commit();
		}
		catch(Exception localexception)
		{
			exceptionLog.info("",localexception);
		}
		finally
		{
			aleSession.close();
		}
		

	}

	public void loadEventToEventStore(String eventName,String eventParameter,String eventParameterValues)
	{
		
	}
	
	
}
