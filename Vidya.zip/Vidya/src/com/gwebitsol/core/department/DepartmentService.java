package com.gwebitsol.core.department;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.gwebitsol.core.note.NoteDao;
import com.gwebitsol.core.security.MDValidation;
import com.gwebitsol.core.security.MDVerifyConnectionID;
import com.gwebitsol.core.security.MDVerifyDatastoreName;
import com.gwebitsol.core.taskactionitem.TaskActionItemDao;
import com.gwebitsol.core.usermanagement.MDGetUserFromID;
import com.gwebitsol.core.util.MDTransactionWriter;

public class DepartmentService implements DepartmentIntf {
	@Context 
	private HttpServletRequest hsr;
	public Response addDepartment(Department dt, int userid, int connectionid, String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		String XMLString=null;
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		dt.setBranchId(branchId);
		dt.setSchoolId(schoolId);
			try
				{	
				MDValidation mdv = new MDValidation();  
				   int ret =mdv.allvalidations(userid, connectionid, datastoreName,schoolId,branchId);
				   System.out.println("verifiedvalue::"+ret);
				if(ret==1 )//&& rtVal==1)
				{
					DepartmentDao dao= new DepartmentDao();
					status=dao.addDepartment(dt);
					String endDate=dateFormat.format(new Date());
					Long el=System.currentTimeMillis();
					MDTransactionWriter.writeLog("sai","CMS","requester",startDate,endDate,sl,el,status,hsr.getRemoteHost());		
				}else
				{
					XMLString="you are not authorised user";
				}
				
			}

					catch(Exception localException)
					{
						MDTransactionWriter.errorlog.debug(localException);
						MDTransactionWriter.errorlog.info(localException);
						status="failed in service layer";
						System.out.println(localException);
					}
	
			return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response deleteDepartment(int departmentId, int userid, int connectionid, String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		String XMLString=null;
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
			
		try
			{	
			MDValidation mdv = new MDValidation();  
			   int ret =mdv.allvalidations(userid, connectionid, datastoreName,schoolId,branchId);
			   System.out.println("verifiedvalue::"+ret);
			if(ret==1 )//&& rtVal==1)
			{
				DepartmentDao dao= new DepartmentDao();
				status=dao.deleteDepartment(departmentId,schoolId,branchId);
			
			String endDate=dateFormat.format(new Date());	
			Long el=System.currentTimeMillis();
			//status="user validation successfull";
			MDTransactionWriter.writeLog("sai","CMS","requester",startDate,endDate,sl,el,status,hsr.getRemoteHost());		
		}
			else
			{
				XMLString="you are not authorised user";
			}
			
		}

		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			status="failed in service layer";
		}
	return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response updateDepartment(Department dt, int userid, int connectionid, String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		String XMLString=null;
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		dt.setBranchId(branchId);
		dt.setSchoolId(schoolId);
		try
		{	
			MDValidation mdv = new MDValidation();  
			   int ret =mdv.allvalidations(userid, connectionid, datastoreName,schoolId,branchId);
			   System.out.println("verifiedvalue::"+ret);
			if(ret==1 )//&& rtVal==1)
			{
			DepartmentDao dao= new DepartmentDao();
			status=dao.updateDepartment(dt,schoolId,branchId);
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			//status="user validation successfull";
			MDTransactionWriter.writeLog("sai","CMS","requester",startDate,endDate,sl,el,status,hsr.getRemoteHost());		
		}
			else
			{
				XMLString="you are not authorised user";
			}
			
		}

		  	catch(Exception localException)
			{
			  MDTransactionWriter.errorlog.debug(localException);
			  MDTransactionWriter.errorlog.info(localException);
			  status="failed in service layer";
		   }
    return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response getAllDepartment(int userid, int connectionid, String datastoreName, int PNO, int size,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String XMLString=null;
		
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try{
			MDValidation mdv = new MDValidation();  
			   int ret =mdv.allvalidations(userid, connectionid, datastoreName, schoolId, branchId);
			   System.out.println("verifiedvalue::"+ret);
			if(ret==1 )//&& rtVal==1)
			{
			
			DepartmentDao dao= new DepartmentDao();
			status=dao.getAllDepartment(PNO,size,schoolId,branchId);
			System.out.println(status);
			String endDate=dateFormat.format(new Date());
			  Long el=System.currentTimeMillis();
			 MDTransactionWriter.writeLog("sai","CMS","requester",startDate,endDate,sl,el,status,hsr.getRemoteHost());		

		}
			else
			{
				XMLString="you are not authorised user";
			}
			
		}

			catch(Exception localException)
		   {
			  MDTransactionWriter.errorlog.debug(localException);
			  MDTransactionWriter.errorlog.info(localException);
			  status="failed in service layer";
		   }
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response getDepartmentbydepartmentid(int departmentId, int userid, int connectionid, String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		String XMLString=null;
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
	{	
			MDValidation mdv = new MDValidation();  
			   int ret =mdv.allvalidations(userid, connectionid, datastoreName, schoolId, branchId);
			   System.out.println("verifiedvalue::"+ret);
			if(ret==1 )//&& rtVal==1)
			{
			
			DepartmentDao dao= new DepartmentDao();
			status=dao.getDepartmentbydepartmentid(departmentId,schoolId,branchId);
			 System.out.println(status);
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			//status1="user validation successfull";
			MDTransactionWriter.writeLog("sai","CMS","requester",startDate,endDate,sl,el,status,hsr.getRemoteHost());		
	}
			else
			{
				XMLString="you are not authorised user";
			}
			
		}

	catch(Exception localException)
	{
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
		status="failed in service layer";
		//System.out.println(localException);
	  }
 return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}
}
