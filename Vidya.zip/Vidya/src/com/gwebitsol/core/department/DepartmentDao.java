package com.gwebitsol.core.department;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.note.Note;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;
public class DepartmentDao {
	
	public String addDepartment(Department dt) {
		Session addempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction addempTx=null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		String sqlstr = null;
		try
		{
			addempTx=addempSession.beginTransaction();
			int employeeId;
			int departmentId;
			departmentId=(Integer)addempSession.save(dt);
			
			String fat = dt.getEmployeeId(); 
			
			String[] x = fat.split(",");
			
			 for(int i=0;i<=x.length-1;i++)
			 {
			 employeeId  = Integer.parseInt(x[i]);         
	         sqlstr = "insert into gbl_tbl_branch_department(DepartmentId,EmployeeId) values ('"+departmentId+"','"+employeeId+"');";
		     SQLQuery stpar = addempSession.createSQLQuery(sqlstr);
	         stpar.executeUpdate();
			 } 
			addempTx.commit();
			sb.append("<Department>");
			sb.append("\n");
			sb.append("<departmentId>");
			sb.append(departmentId);
			sb.append("</departmentId>");
			sb.append("</Department>");
			outStr=sb.toString();
   		 	}
		catch(Exception localException)
		{
			System.out.println(localException);
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    sb.append("could not inserted department info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    outStr= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (addempTx!=null)
				  addempTx.rollback();
		}
		finally
		{			
			addempSession.close();
		}
		return outStr;
	}
	public String deleteDepartment(int departmentId,int schoolId,int branchId) {
		Session delempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction delempTx=null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			delempTx=delempSession.beginTransaction();
			Department answer = (Department) delempSession.get(Department.class,departmentId);
			   
			   int branid = answer.getBranchId();
			   int sclid = answer.getSchoolId();
			   delempSession.evict(answer);             
			   if(branchId==branid&&schoolId==sclid)
			   {
			Query empQuery=delempSession.createSQLQuery("update gbl_tbl_department set IsDeleted ='Y' where departmentId='"+departmentId+"'");
			empQuery.executeUpdate();
			delempTx.commit();
			sb.append("<Department>");
			sb.append("\n");
			sb.append("deleted sucessfully");
			sb.append("</Department>");
			String str=sb.toString();
			return str;
   		 	}
		}
		catch(Exception localException)
		{
			System.out.println(localException);
			    sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    sb.append("could not delete department info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    outStr= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (outStr!=null)
				  delempTx.rollback();
		}
		finally
		{			
			delempSession.close();
		}
		return outStr;
	}
	public String updateDepartment(Department dt,int schoolId,int branchId) {
		Session upempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction upempTx=null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			upempTx=upempSession.beginTransaction();
			Department answer = (Department) upempSession.get(Department.class,dt.getDepartmentId());
			   
			if(branchId==answer.getBranchId()&&schoolId==answer.getSchoolId())
			    
				upempSession.evict(answer);
	        upempSession.update(dt);
			upempTx.commit();
			sb.append("<Department>");
			sb.append("\n");
			sb.append("update sucessfully");
			sb.append("</Department>");
			String str=sb.toString();
			return str;
   		 	}
		catch(Exception localException)
		{
			System.out.println(localException);
			    sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    sb.append("could not updatedDepartment info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    outStr= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (outStr!=null)
				  upempTx.rollback();
		}
		finally
		{			
			upempSession.close();
		}
		return outStr;
	}
	public String getAllDepartment(int PNO, int size,int schoolId,int branchId) {
		Session rdSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb= new StringBuffer();
		String string=null;
		try
		{
			tx = rdSession.beginTransaction();
			
			 if(("all") != null)
			   {
			    int fset = (PNO-1)*size;
			    String gsSql ="select count(*) from gbl_tbl_department";
			    Query gsQuery=rdSession.createSQLQuery(gsSql);
			    Object noRecords= gsQuery.uniqueResult();
			    sb.append("<Departments>");
			    sb.append("\n");
			    sb.append("<noRecords>"+noRecords+"</noRecords>");
			    sb.append("\n");
			     if (PNO > 0 & size > 0){
			     gsSql="Select dt.DepartmentId,dt.DepartmentName,bd.EmployeeId,md.FirstName,md.MiddleName,md.LastName,dt.SchoolId,dt.BranchId from gbl_tbl_department as dt join gbl_sm_tbl_staff as md join gbl_tbl_branch_department as bd on bd.EmployeeId = md.EmployeeId and  dt.DepartmentId = bd.DepartmentId where dt.IsDeleted <> 'Y' or dt.IsDeleted IS NULL and dt.SchoolId ='" + schoolId + "'  and dt.BranchId ='" + branchId + "' limit "+size+" offset "+fset;}
			     else {
			      gsSql="Select dt.DepartmentId,dt.DepartmentName,bd.EmployeeId,md.FirstName,md.MiddleName,md.LastName,dt.SchoolId,dt.BranchId from gbl_tbl_department as dt join gbl_sm_tbl_staff as md join gbl_tbl_branch_department as bd on bd.EmployeeId = md.EmployeeId and  dt.DepartmentId = bd.DepartmentId where dt.IsDeleted <> 'Y' or dt.IsDeleted IS NULL and dt.SchoolId ='" + schoolId + "'  and dt.BranchId ='" + branchId + "' ";
			     } 
			    gsQuery=rdSession.createSQLQuery(gsSql);
			    List gcList=gsQuery.list();
			    Iterator gsIT=gcList.iterator();
			    while(gsIT.hasNext())
			     {
			    	 Object[] ex=(Object[])gsIT.next();
			    	 sb.append("<Department>");
			         sb.append("\n");
			      	 sb.append("<departmentId>");
			         sb.append(ex[0]);
			         sb.append("</departmentId>");
			         sb.append("\n");
			         sb.append("<departmentName>");
			         sb.append(ex[1]);
			         sb.append("</departmentName>");
			         sb.append("\n");
			         sb.append("<employeeId>");
			         sb.append(ex[2]);
			         sb.append("</employeeId>");
			         sb.append("\n");
			         sb.append("<firstName>");
			         sb.append(ex[3]);
			         sb.append("</firstName>");
			         sb.append("\n");
			      	 sb.append("<middleName>");
			         sb.append(ex[4]);
			         sb.append("</middleName>");
			         sb.append("\n");
			         sb.append("<lastName>");
			         sb.append(ex[5]);
			         sb.append("</lastName>");
			         sb.append("\n");
			    	 sb.append("<schoolId>");
			         sb.append(ex[6]);
			         sb.append("</schoolId>");
			         sb.append("\n");
			    	 sb.append("<branchId>");
			         sb.append(ex[7]);
			         sb.append("</branchId>");
			         sb.append("\n");
			         sb.append("</Department>");
			}
		}
			sb.append("</Departments>");
					    String str= sb.toString();
						 tx.commit();
					return str;
		}
		catch(Exception localException)
		{
			System.out.println(localException);
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    sb.append("could not getall Departments info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    string= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (string!=null)
				  tx.rollback();
		}
		finally
		{
			rdSession.close();
		}
		return string;
	}
	public String getDepartmentbydepartmentid(int departmentId,int schoolId,int branchId) {
		Session gtempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gtTx=null;
			StringBuffer sb= new StringBuffer();
			System.out.println("hi dao impl success");
			String strg= null;
				try {
						 gtTx = gtempSession.beginTransaction();
						 List list=gtempSession.createSQLQuery("Select dt.DepartmentId,dt.DepartmentName,bd.EmployeeId,md.FirstName,md.MiddleName,md.LastName,dt.SchoolId,dt.BranchId from gbl_tbl_department as dt join gbl_sm_tbl_staff as md join gbl_tbl_branch_department as bd on bd.EmployeeId = md.EmployeeId and  dt.DepartmentId = bd.DepartmentId where dt.IsDeleted <> 'Y' or dt.IsDeleted IS NULL and dt.DepartmentId ='" + departmentId + "' and dt.SchoolId ='" + schoolId + "'  and dt.BranchId ='" + branchId + "' ;").list();
					     Iterator it=list.iterator();
					     sb.append("<Departments>");
					     sb.append("\n");
					     while(it.hasNext())
					     {
					      Object[] ex=(Object[])it.next();
					      sb.append("<Department>");
					         sb.append("\n");
					      	 sb.append("<departmentId>");
					         sb.append(ex[0]);
					         sb.append("</departmentId>");
					         sb.append("\n");
					         sb.append("<departmentName>");
					         sb.append(ex[1]);
					         sb.append("</departmentName>");
					         sb.append("\n");
					         sb.append("<employeeId>");
					         sb.append(ex[2]);
					         sb.append("</employeeId>");
					         sb.append("\n");
					         sb.append("<firstName>");
					         sb.append(ex[3]);
					         sb.append("</firstName>");
					         sb.append("\n");
					      	 sb.append("<middleName>");
					         sb.append(ex[4]);
					         sb.append("</middleName>");
					         sb.append("\n");
					         sb.append("<lastName>");
					         sb.append(ex[5]);
					         sb.append("</lastName>");
					         sb.append("\n");
					    	 sb.append("<schoolId>");
					         sb.append(ex[6]);
					         sb.append("</schoolId>");
					         sb.append("\n");
					    	 sb.append("<branchId>");
					         sb.append(ex[7]);
					         sb.append("</branchId>");
					         sb.append("\n");
					         sb.append("</Department>");
					     	}
							 sb.append("</Departments>");
							 strg= sb.toString();
				            } catch (Exception localException) {
					    System.out.println(localException);
					    sb.append("<Response>");
					    sb.append("\n");
					    sb.append("<Result>");
					    sb.append("\n");
					    sb.append("Fail");
					    sb.append("\n");
					    sb.append("</Result>");
					    sb.append("\n");
					    sb.append("<Description>");
					    sb.append("could not getActionbyid info");
					    sb.append("</Description>");
					    sb.append("\n");
					    sb.append("<Exception>");
					    sb.append(localException);
					    sb.append("</Exception>");
					    sb.append("</Response>");
					    sb.append("</noteId>");
					    sb.append("</Note>");
					    strg= sb.toString();
					   MDTransactionWriter.exceptionlog.info(localException);
					  if (strg!=null)
						  gtTx.rollback();
					} finally {
						gtempSession.close();
					}
			return strg;
	}
}
