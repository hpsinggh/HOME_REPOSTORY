
package com.gwebitsol.core.parent;

import java.math.BigInteger;
import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.gwebitsol.core.address.AddressPojo;
import com.gwebitsol.core.search.MDSearchManagementDAO;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

@Repository
@Component
public class ParentDao {

	Integer parid = null;

	StringBuffer parentID = new StringBuffer();

	public String createParent(ParentPojo rp) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String parentreg = null;

		try {
			rdTx = rdSession.beginTransaction();
			/*
			 * String rdSql =
			 * "insert into parent_personal_info (FirstName,LastName,DOB,Qualification,Remarks,CreatedDate,ModifiedDate)"
			 * +" values('"+ rp.getFirstName() + "','" + rp.getLastName() +
			 * "','" + rp.getDOB() + "','" + rp.getQualification() + "','" +
			 * rp.getRemarks() + "','" + rp.getCreatedDate() + "','" +
			 * rp.getModifiedDate() + "')";
			 * 
			 * Query rdQuery = (Query) rdSession.createSQLQuery(rdSql);
			 * 
			 * int stat = rdQuery.executeUpdate(); System.out.println(stat);
			 * 
			 * String rdsql1 = "select max(Id) from parent_personal_info";
			 * 
			 * List parents = rdSession.createQuery(rdsql1).list(); Integer
			 * parentid = (Integer) parents.get(0);
			 * 
			 * System.out.println("result is "+parentid);
			 * 
			 * 
			 * ParentPojo rpx = (ParentPojo) rp;
			 */
			Integer parid = (Integer) rdSession.save(rp);
			System.out.println(parid);
			rdTx.commit();
			parentID.append("<Parent>");
			parentID.append("\n");
			parentID.append("<id>");
			parentID.append("\n");
			parentID.append(parid);
			parentID.append("</id>");
			parentID.append("\n");
			parentID.append("</Parent>");
			parentreg = parentID.toString();
		} catch (Exception localException) {

			localException.printStackTrace();
			System.out.println(localException);

			parentID.append("<Response>");
			parentID.append("\n");
			parentID.append("<Result>");
			parentID.append("\n");
			parentID.append("Fail");
			parentID.append("\n");
			parentID.append("</Result>");
			parentID.append("\n");
			parentID.append("<Description>");
			parentID.append("could not inserted parent info");
			parentID.append("</Description>");
			parentID.append("\n");
			parentID.append("<Exception>");
			parentID.append(localException);
			parentID.append("</Exception>");
			parentID.append("</Response>");

			parentreg = parentID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		} finally {
			rdSession.close();
		}
		return parentreg;

	}

	public String updateParent(ParentPojo rp, int schoolid, int branchid) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String parentreg = null;
		System.out.println(rp.getFirstName());
		try {
			rdTx = rdSession.beginTransaction();

			ParentPojo mdclpojo = (ParentPojo) rdSession.get(ParentPojo.class, rp.getParentId());

			if (branchid == mdclpojo.getBranchId() && schoolid == mdclpojo.getSchoolId())

				rdSession.evict(mdclpojo);

			rdSession.update(rp);

			rdTx.commit();

			parentreg = "parent is succssfully updated";
			parentID.append("<Parent>");
			parentID.append("\n");
			parentID.append(parentreg);
			parentID.append("</Parent>");
			String str = parentID.toString();
			return str;
		} catch (Exception localException) {
			localException.printStackTrace();
			System.out.println(localException);

			parentID.append("<Response>");
			parentID.append("\n");
			parentID.append("<Result>");
			parentID.append("\n");
			parentID.append("Fail");
			parentID.append("\n");
			parentID.append("</Result>");
			parentID.append("\n");
			parentID.append("<Description>");
			parentID.append("could not updated parent info");
			parentID.append("</Description>");
			parentID.append("\n");
			parentID.append("<Exception>");
			parentID.append(localException);
			parentID.append("</Exception>");
			parentID.append("</Response>");

			parentreg = parentID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		} finally {
			rdSession.close();
		}
		return parentreg;
	}

	public String deleteParent(int parentId, int schoolid, int branchid) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String parentreg = null;

		try {
			rdTx = rdSession.beginTransaction();

			parentreg = "select count(ParentId) from gbl_sm_tbl_student_parent where ParentId='" + parentId + "'";
			BigInteger numprv = (BigInteger) rdSession.createSQLQuery(parentreg).uniqueResult();
			if (numprv.intValue() > 0) {
				parentreg = "This parent has a kids, so can't be deleted";
			} else {
				ParentPojo mdclpojo = (ParentPojo) rdSession.get(ParentPojo.class, parentId);

				rdSession.evict(mdclpojo);

				if (branchid == mdclpojo.getBranchId() && schoolid == mdclpojo.getSchoolId()) {
					Query empQuery = rdSession.createSQLQuery(
							"update gbl_sm_tbl_parent set isDeleted='y' where ParentId='" + parentId + "'");
					empQuery.executeUpdate();

					parentreg = "parent is deleted successfully";

				} else {
					parentreg = "parent is not deleted";

				}
			}

			rdTx.commit();

			parentID.append("<Parent>");
			parentID.append("\n");
			parentID.append(parentreg);
			parentID.append("</Parent>");
			String str = parentID.toString();
			return str;

		} catch (Exception localException) {
			localException.printStackTrace();
			System.out.println(localException);

			parentID.append("<Response>");
			parentID.append("\n");
			parentID.append("<Result>");
			parentID.append("\n");
			parentID.append("Fail");
			parentID.append("\n");
			parentID.append("</Result>");
			parentID.append("\n");
			parentID.append("<Description>");
			parentID.append("could not deleted parent info");
			parentID.append("</Description>");
			parentID.append("\n");
			parentID.append("<Exception>");
			parentID.append(localException);
			parentID.append("</Exception>");
			parentID.append("</Response>");

			parentreg = parentID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();

		} finally {
			rdSession.close();
		}
		return parentreg;
	}

	public String getParent(int id, int schoolid, int branchid) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String parentreg = null;
		String gsSql = null;
		try {
			rdTx = rdSession.beginTransaction();

			gsSql = "select gbl_sm_tbl_parent.*, gbl_sm_tbl_jobtype.JobTypeName" + " from gbl_sm_tbl_parent"
					+ " join gbl_sm_tbl_jobtype on gbl_sm_tbl_parent.JobTypeId = gbl_sm_tbl_jobtype.JobTypeId "
					+ " where gbl_sm_tbl_parent.IsDeleted is null and ParentId ='" + id
					+ "' and gbl_sm_tbl_parent.SchoolId='" + schoolid + "' and gbl_sm_tbl_parent.BranchId='" + branchid
					+ "';";

			Query gsQuery = rdSession.createSQLQuery(gsSql);
			List gcList = gsQuery.list();
			Iterator gsIT = gcList.iterator();
			while (gsIT.hasNext()) {
				Object[] mdcArr = (Object[]) gsIT.next();
				parentID.append("<parent>");
				parentID.append("\n");
				parentID.append("<parentId>" + mdcArr[0] + "</parentId>");
				parentID.append("\n");
				parentID.append("<jobTypeId>" + mdcArr[1] + "</jobTypeId>");
				parentID.append("\n");
				parentID.append("<jobTypeName>" + mdcArr[21] + "</jobTypeName>");
				parentID.append("\n");
				parentID.append("<userId>" + mdcArr[2] + "</userId>");
				parentID.append("\n");
				parentID.append("<photo>" + mdcArr[3] + "</photo>");
				parentID.append("\n");
				parentID.append("<firstName>" + mdcArr[4] + "</firstName>");
				parentID.append("\n");
				parentID.append("<middleName>" + mdcArr[5] + "</middleName>");
				parentID.append("\n");
				parentID.append("<lastName>" + mdcArr[6] + "</lastName>");
				parentID.append("\n");
				parentID.append("<dOB>" + mdcArr[7] + "</dOB>");
				parentID.append("\n");
				parentID.append("<qualification>" + mdcArr[8] + "</qualification>");
				parentID.append("\n");
				parentID.append("<jobTitle>" + mdcArr[9] + "</jobTitle>");
				parentID.append("\n");
				parentID.append("<jobRole>" + mdcArr[10] + "</jobRole>");
				parentID.append("\n");
				parentID.append("<annualSalary>" + mdcArr[11] + "</annualSalary>");
				parentID.append("\n");
				parentID.append("<gender>" + mdcArr[12] + "</gender>");
				parentID.append("\n");
				parentID.append("<emailId>" + mdcArr[13] + "</emailId>");
				parentID.append("\n");
				parentID.append("<mobileNumber>" + mdcArr[14] + "</mobileNumber>");
				parentID.append("\n");
				parentID.append("<remarks>" + mdcArr[15] + "</remarks>");
				parentID.append("\n");
				parentID.append("<createdDate>" + mdcArr[16] + "</createdDate>");
				parentID.append("\n");
				parentID.append("<modifiedDate>" + mdcArr[17] + "</modifiedDate>");
				parentID.append("\n");
				parentID.append("<schoolId>" + mdcArr[18] + "</schoolId>");
				parentID.append("\n");
				parentID.append("<branchId>" + mdcArr[19] + "</branchId>");
				parentID.append("\n");
				parentID.append("<isDeleted>" + mdcArr[20] + "</isDeleted>");
				parentID.append("\n");
				gsSql = "select gbl_sm_tbl_student.StudentId , gbl_sm_tbl_student.StudentNumber,gbl_sm_tbl_student.FirstName,gbl_sm_tbl_student.MiddleName,gbl_sm_tbl_student.LastName,"
						+ "gbl_sm_tbl_student_education.ClassId,gbl_sm_tbl_class.ClassName,gbl_sm_tbl_student_education.SectionId,gbl_sm_tbl_section.SectionName "
						+ " from gbl_sm_tbl_student "
						+ "join gbl_sm_tbl_student_parent on gbl_sm_tbl_student_parent.StudentId=gbl_sm_tbl_student.StudentId "
						+ "join gbl_sm_tbl_student_education on gbl_sm_tbl_student_education.StudentId=gbl_sm_tbl_student.StudentId "
						+ "join gbl_sm_tbl_class on gbl_sm_tbl_student_education.ClassId=gbl_sm_tbl_class.ClassId "
						+ "join gbl_sm_tbl_section on gbl_sm_tbl_student_education.SectionId=gbl_sm_tbl_section.SectionId "
						+ "where gbl_sm_tbl_student.IsDeleted is null and gbl_sm_tbl_student_education.CurrentFlg ='active' and gbl_sm_tbl_student_parent.ParentId='"
						+ mdcArr[0] + "';";

				gsQuery = rdSession.createSQLQuery(gsSql);
				List parList1 = gsQuery.list();
				Iterator paIT = parList1.iterator();
				parentID.append("<studentDetails>");
				parentID.append("\n");
				while (paIT.hasNext()) {
					Object[] paArr = (Object[]) paIT.next();
					parentID.append("<student>");
					parentID.append("\n");
					parentID.append("<studentId>" + paArr[0] + "</studentId>");
					parentID.append("\n");
					parentID.append("<studentnumber>" + paArr[1] + "</studentnumber>");
					parentID.append("\n");
					parentID.append("<studentfirstName>" + paArr[2] + "</studentfirstName>");
					parentID.append("\n");
					parentID.append("<studentmiddleName>" + paArr[3] + "</studentmiddleName>");
					parentID.append("\n");
					parentID.append("<studentlastName>" + paArr[4] + "</studentlastName>");
					parentID.append("\n");
					parentID.append("<classId>" + paArr[5] + "</classId>");
					parentID.append("\n");
					parentID.append("<className>" + paArr[6] + "</className>");
					parentID.append("\n");
					parentID.append("<sectionId>" + paArr[7] + "</sectionId>");
					parentID.append("\n");
					parentID.append("<sectionName>" + paArr[8] + "</sectionName>");
					parentID.append("\n");
					parentID.append("</student>");
					parentID.append("\n");
				}
				parentID.append("</studentDetails>");
				parentID.append("\n");
				parentID.append("</parent>");
				parentID.append("\n");
			}

			rdTx.commit();

			parentreg = parentID.toString();
		} catch (HibernateException localException) {
			System.out.println(localException);
			localException.printStackTrace();
			parentID.append("<Response>");
			parentID.append("\n");
			parentID.append("<Result>");
			parentID.append("\n");
			parentID.append("Fail");
			parentID.append("\n");
			parentID.append("</Result>");
			parentID.append("\n");
			parentID.append("<Description>");
			parentID.append("could not get Parent info");
			parentID.append("</Description>");
			parentID.append("\n");
			parentID.append("<Exception>");
			parentID.append(localException);
			parentID.append("</Exception>");
			parentID.append("</Response>");

			parentreg = parentID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		} finally {
			rdSession.close();
		}
		return parentreg;
	}

	@SuppressWarnings("unused")
	public String getAllParentsInfo(int PNO, int size, String studentNumber, int classId, int sectionId, int schoolid,
			int branchid) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String xmlString = null;
		// Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		// Transaction stgTx=null;

		try {
			rdTx = rdSession.beginTransaction();
			String filterWhere = "";
			String subQryEducation = "";
			if (studentNumber != null && "".equalsIgnoreCase(studentNumber)) {
				filterWhere = " and gbl_sm_tbl_parent.ParentId in (select distinct ParentId from gbl_sm_tbl_student_parent where gbl_sm_tbl_student_parent.StudentId in (select distinct StudentId from gbl_sm_tbl_student where StudentNumber ='"
						+ studentNumber + "')";
			} else if (classId != 0) {
				filterWhere = " and gbl_sm_tbl_parent.ParentId in (select distinct ParentId from gbl_sm_tbl_student_parent where gbl_sm_tbl_student_parent.StudentId in (";

				subQryEducation = " select distinct StudentId from gbl_sm_tbl_student_education where "
					//	+ " gbl_sm_tbl_student_education.SchoolId='"+ schoolid + "' and gbl_sm_tbl_student_education.BranchId='" + branchid+ "' and "
								+ " gbl_sm_tbl_student_education.ClassId = '" + classId + "'";
				if (sectionId != 0) {
					subQryEducation += " and gbl_sm_tbl_student_education.SectionId = '" + sectionId + "' ";
				}
				filterWhere += subQryEducation + " ))";
			}
			int fset = (PNO - 1) * size;
			String gsSql = "select count(*) from gbl_sm_tbl_parent where (gbl_sm_tbl_parent.IsDeleted is null or  gbl_sm_tbl_parent.IsDeleted<>'y') "
				//	+ "and gbl_sm_tbl_parent.SchoolId='"+ schoolid + "' and gbl_sm_tbl_parent.BranchId='" + branchid + "'" 
				+ filterWhere + ";";
			Query gsQuery = rdSession.createSQLQuery(gsSql);
			Object noRecords = gsQuery.uniqueResult();
			int intNoRecords = 0;
			if (noRecords != null && Integer.parseInt(noRecords.toString()) != 0) {
				intNoRecords = Integer.parseInt(noRecords.toString());
			}

			parentID.append("<Parents>");
			parentID.append("\n");
			parentID.append("<noRecords>" + noRecords + "</noRecords>");
			parentID.append("\n");

			if (intNoRecords != 0) {
				if (PNO > 0 & size > 0) {
					gsSql = "select gbl_sm_tbl_parent.*, gbl_sm_tbl_jobtype.JobTypeName" + " from gbl_sm_tbl_parent"
							+ " join gbl_sm_tbl_jobtype on gbl_sm_tbl_parent.JobTypeId = gbl_sm_tbl_jobtype.JobTypeId "
							+ " where (gbl_sm_tbl_parent.IsDeleted is null or  gbl_sm_tbl_parent.IsDeleted<>'y') "
						//	+ " and gbl_sm_tbl_parent.SchoolId='"+ schoolid + "' and gbl_sm_tbl_parent.BranchId='" + branchid + "'" 
							+ filterWhere + " limit "
							+ size + " offset " + fset + ";";
				}

				else {
					gsSql = "select gbl_sm_tbl_parent.*, gbl_sm_tbl_jobtype.JobTypeName" + " from gbl_sm_tbl_parent"
							+ " join gbl_sm_tbl_jobtype on gbl_sm_tbl_parent.JobTypeId = gbl_sm_tbl_jobtype.JobTypeId"
							+ " where (gbl_sm_tbl_parent.IsDeleted is null or  gbl_sm_tbl_parent.IsDeleted<>'y')"
					//		+ " and gbl_sm_tbl_parent.SchoolId='"+ schoolid + "' and gbl_sm_tbl_parent.BranchId='" + branchid + "'" 
							+ filterWhere + ";";

				}
				gsQuery = rdSession.createSQLQuery(gsSql);
				List gcList = gsQuery.list();
				Iterator gsIT = gcList.iterator();
				while (gsIT.hasNext()) {
					Object[] mdcArr = (Object[]) gsIT.next();
					parentID.append("<parent>");
					parentID.append("\n");
					parentID.append("<parentId>" + mdcArr[0] + "</parentId>");
					parentID.append("\n");
					parentID.append("<jobTypeId>" + mdcArr[1] + "</jobTypeId>");
					parentID.append("\n");
					parentID.append("<jobTypeName>" + mdcArr[21] + "</jobTypeName>");
					parentID.append("\n");
					parentID.append("<userId>" + mdcArr[2] + "</userId>");
					parentID.append("\n");
					parentID.append("<photo>" + mdcArr[3] + "</photo>");
					parentID.append("\n");
					parentID.append("<firstName>" + mdcArr[4] + "</firstName>");
					parentID.append("\n");
					parentID.append("<middleName>" + mdcArr[5] + "</middleName>");
					parentID.append("\n");
					parentID.append("<lastName>" + mdcArr[6] + "</lastName>");
					parentID.append("\n");
					parentID.append("<dOB>" + mdcArr[7] + "</dOB>");
					parentID.append("\n");
					parentID.append("<qualification>" + mdcArr[8] + "</qualification>");
					parentID.append("\n");
					parentID.append("<jobTitle>" + mdcArr[9] + "</jobTitle>");
					parentID.append("\n");
					parentID.append("<jobRole>" + mdcArr[10] + "</jobRole>");
					parentID.append("\n");
					parentID.append("<annualSalary>" + mdcArr[11] + "</annualSalary>");
					parentID.append("\n");
					parentID.append("<gender>" + mdcArr[12] + "</gender>");
					parentID.append("\n");
					parentID.append("<emailId>" + mdcArr[13] + "</emailId>");
					parentID.append("\n");
					parentID.append("<mobileNumber>" + mdcArr[14] + "</mobileNumber>");
					parentID.append("\n");
					parentID.append("<remarks>" + mdcArr[15] + "</remarks>");
					parentID.append("\n");
					parentID.append("<createdDate>" + mdcArr[16] + "</createdDate>");
					parentID.append("\n");
					parentID.append("<modifiedDate>" + mdcArr[17] + "</modifiedDate>");
					parentID.append("\n");
					parentID.append("<schoolId>" + mdcArr[18] + "</schoolId>");
					parentID.append("\n");
					parentID.append("<branchId>" + mdcArr[19] + "</branchId>");
					parentID.append("\n");
					parentID.append("<isDeleted>" + mdcArr[20] + "</isDeleted>");
					parentID.append("\n");
					gsSql = "select gbl_sm_tbl_student.StudentId , gbl_sm_tbl_student.StudentNumber,gbl_sm_tbl_student.FirstName,gbl_sm_tbl_student.MiddleName,gbl_sm_tbl_student.LastName,"
							+ "gbl_sm_tbl_student_education.ClassId,gbl_sm_tbl_class.ClassName,gbl_sm_tbl_student_education.SectionId,gbl_sm_tbl_section.SectionName "
							+ " from gbl_sm_tbl_student "
							+ "join gbl_sm_tbl_student_parent on gbl_sm_tbl_student_parent.StudentId=gbl_sm_tbl_student.StudentId "
							+ "join gbl_sm_tbl_student_education on gbl_sm_tbl_student_education.StudentId=gbl_sm_tbl_student.StudentId "
							+ "join gbl_sm_tbl_class on gbl_sm_tbl_student_education.ClassId=gbl_sm_tbl_class.ClassId "
							+ "join gbl_sm_tbl_section on gbl_sm_tbl_student_education.SectionId=gbl_sm_tbl_section.SectionId "
							+ "where gbl_sm_tbl_student.IsDeleted is null and gbl_sm_tbl_student_education.CurrentFlg ='active' and gbl_sm_tbl_student_parent.ParentId='"
							+ mdcArr[0] + "';";

					gsQuery = rdSession.createSQLQuery(gsSql);
					List parList1 = gsQuery.list();
					Iterator paIT = parList1.iterator();
					parentID.append("<studentDetails>");
					parentID.append("\n");
					while (paIT.hasNext()) {
						Object[] paArr = (Object[]) paIT.next();
						parentID.append("<student>");
						parentID.append("\n");
						parentID.append("<studentId>" + paArr[0] + "</studentId>");
						parentID.append("\n");
						parentID.append("<studentnumber>" + paArr[1] + "</studentnumber>");
						parentID.append("\n");
						parentID.append("<studentfirstName>" + paArr[2] + "</studentfirstName>");
						parentID.append("\n");
						parentID.append("<studentmiddleName>" + paArr[3] + "</studentmiddleName>");
						parentID.append("\n");
						parentID.append("<studentlastName>" + paArr[4] + "</studentlastName>");
						parentID.append("\n");
						parentID.append("<classId>" + paArr[5] + "</classId>");
						parentID.append("\n");
						parentID.append("<className>" + paArr[6] + "</className>");
						parentID.append("\n");
						parentID.append("<sectionId>" + paArr[7] + "</sectionId>");
						parentID.append("\n");
						parentID.append("<sectionName>" + paArr[8] + "</sectionName>");
						parentID.append("\n");
						parentID.append("</student>");
						parentID.append("\n");

					}
					parentID.append("</studentDetails>");
					parentID.append("\n");
					parentID.append("</parent>");
					parentID.append("\n");
				}
			}
			rdTx.commit();
			parentID.append("</Parents>");
			parentID.append("\n");
			xmlString = parentID.toString();
		}

		catch (Exception localException) {
			System.out.println(localException);
			localException.printStackTrace();
			parentID.append("<Response>");
			parentID.append("\n");
			parentID.append("<Result>");
			parentID.append("\n");
			parentID.append("Fail");
			parentID.append("\n");
			parentID.append("</Result>");
			parentID.append("\n");
			parentID.append("<Description>");
			parentID.append("could not get Parents info");
			parentID.append("</Description>");
			parentID.append("\n");
			parentID.append("<Exception>");
			parentID.append(localException);
			parentID.append("</Exception>");
			parentID.append("</Response>");

			xmlString = parentID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		} finally {
			rdSession.close();
		}
		return xmlString;
	}

	public String addParentForDiffBranch(ParentPojo pp) {

		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String parentreg = null;
		String bqry = null;
		try {
			rdTx = rdSession.beginTransaction();

			String fname = pp.getFirstName();
			String mname = pp.getMiddleName();
			String lname = pp.getLastName();
			String gen = pp.getGender();
			String dob = pp.getDob();
		
			String mailid = pp.getEmailId();
			String contactnum = pp.getMobileNumber();

			rdTx = rdSession.beginTransaction();

			String selectsearch = "select * from gbl_sm_tbl_parent where IsDeleted is null ";
			
			if(fname!=null && mname!=null && lname!=null)
			{
				selectsearch+= "and FirstName ='" + fname + "' and MiddleName ='"+mname
						+ "' and LastName='" + lname+"'";
			}
			if(mailid!=null)
			{
				selectsearch+= " and EmailId ='" + mailid+"'" ;
			}
			
			if(contactnum!=null)
			{
				selectsearch+=" and MobileNumber='" + contactnum+"'";
			}
			if(dob!=null)
			{
				selectsearch+=" and DOB ='" + dob+"'";
			}
			if(gen!=null)
			{
				selectsearch+=" and Gender='"+gen+"'" ;
			}	
			List list = rdSession.createSQLQuery(selectsearch).list();

			if (list.size() > 0) {
				Iterator gsIT = list.iterator();
				parentID.append("<Parents>");
				parentID.append("\n");
				while (gsIT.hasNext()) {
					Object[] mdcArr = (Object[]) gsIT.next();
					parentID.append("<parent>");
					parentID.append("\n");
					parentID.append("<parentId>" + mdcArr[0] + "</parentId>");
					parentID.append("\n");
					parentID.append("<jobTypeId>" + mdcArr[1] + "</jobTypeId>");
					parentID.append("\n");
					parentID.append("<userId>" + mdcArr[2] + "</userId>");
					parentID.append("\n");
					parentID.append("<photo>" + mdcArr[3] + "</photo>");
					parentID.append("\n");
					parentID.append("<firstName>" + mdcArr[4] + "</firstName>");
					parentID.append("\n");
					parentID.append("<middleName>" + mdcArr[5] + "</middleName>");
					parentID.append("\n");
					parentID.append("<lastName>" + mdcArr[6] + "</lastName>");
					parentID.append("\n");
					parentID.append("<dOB>" + mdcArr[7] + "</dOB>");
					parentID.append("\n");
					parentID.append("<qualification>" + mdcArr[8] + "</qualification>");
					parentID.append("\n");
					parentID.append("<jobTitle>" + mdcArr[9] + "</jobTitle>");
					parentID.append("\n");
					parentID.append("<jobRole>" + mdcArr[10] + "</jobRole>");
					parentID.append("\n");
					parentID.append("<annualSalary>" + mdcArr[11] + "</annualSalary>");
					parentID.append("\n");
					parentID.append("<gender>" + mdcArr[12] + "</gender>");
					parentID.append("\n");
					parentID.append("<emailId>" + mdcArr[13] + "</emailId>");
					parentID.append("\n");
					parentID.append("<mobileNumber>" + mdcArr[14] + "</mobileNumber>");
					parentID.append("\n");
					parentID.append("<remarks>" + mdcArr[15] + "</remarks>");
					parentID.append("\n");
					parentID.append("<createdDate>" + mdcArr[16] + "</createdDate>");
					parentID.append("\n");
					parentID.append("<modifiedDate>" + mdcArr[17] + "</modifiedDate>");
					parentID.append("\n");
					parentID.append("<schoolId>" + mdcArr[18] + "</schoolId>");
					parentID.append("\n");
					parentID.append("<branchId>" + mdcArr[19] + "</branchId>");
					parentID.append("\n");
					parentID.append("<isDeleted>" + mdcArr[20] + "</isDeleted>");
					parentID.append("\n");
					parentID.append("</parent>");
					parentID.append("\n");
			} 

					rdTx.commit();
					parentID.append("</Parents>");
					parentID.append("\n");
					parentreg = parentID.toString();
			}else {
				Integer parid = (Integer) rdSession.save(pp);
				System.out.println(parid);
				rdTx.commit();
				parentID.append("<Parent>");
				parentID.append("\n");
				parentID.append("<id>");
				parentID.append("\n");
				parentID.append(parid);
				parentID.append("</id>");
				parentID.append("\n");
				parentID.append("</Parent>");
				parentreg = parentID.toString();
			}
		} catch (Exception localException) {

			localException.printStackTrace();
			System.out.println(localException);

			parentID.append("<Response>");
			parentID.append("\n");
			parentID.append("<Result>");
			parentID.append("\n");
			parentID.append("Fail");
			parentID.append("\n");
			parentID.append("</Result>");
			parentID.append("\n");
			parentID.append("<Description>");
			parentID.append("could not inserted parent info");
			parentID.append("</Description>");
			parentID.append("\n");
			parentID.append("<Exception>");
			parentID.append(localException);
			parentID.append("</Exception>");
			parentID.append("</Response>");

			parentreg = parentID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		} finally {
			rdSession.close();
		}
		return parentreg;

	}

}
