
package com.gwebitsol.core.parent;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

@Path("/parent")

public interface ParentServiceIntf {
	@POST
	@Consumes({ "application/xml", "application/json" })
	@Produces({ "application/xml", "application/json" })
	@Path("/addparent/")
	public Response createParent(ParentPojo pp, @QueryParam("userid") int userid,
			@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
			@QueryParam("schoolid") int schoolid,@QueryParam("branchid") int branchid);

	@POST
	@Consumes({ "application/xml", "application/json" })
	@Produces({ "application/xml", "application/json" })
	@Path("/updateparent/")
	public Response updateParent(ParentPojo pp, @QueryParam("userid") int userid,
			@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
			@QueryParam("schoolid") int schoolid,@QueryParam("branchid") int branchid);

	@POST
	@Consumes({ "application/xml", "application/json" })
	@Produces({ "application/xml", "application/json" })
	@Path("/deleteparent/")
	public Response deleteParent(@QueryParam("parentId") int parentId, @QueryParam("userid") int userid,
			@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
			@QueryParam("schoolid") int schoolid,@QueryParam("branchid") int branchid);

	@GET
	@POST
	@Consumes({ "application/xml", "application/json" })
	@Produces({ "application/xml", "application/json" })
	@Path("/getparent/")
	public Response getParent(@QueryParam("parentId") int parentId, @QueryParam("userid") int userid,
			@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
			@QueryParam("schoolid") int schoolid,@QueryParam("branchid") int branchid);

	@GET
	@Consumes({ "application/xml", "application/json" })
	@Produces({ "application/xml", "application/json" })
	@Path("/getallparentsinfo/")
	public Response getAllParentsInfo(@QueryParam("userid") int userid, @QueryParam("connectionid") int connectionid,
			@QueryParam("studentNo") String studentNo,	@QueryParam("classId") int classId,	@QueryParam("sectionId") int sectionId,
			@QueryParam("datastoreName") String datastoreName, @QueryParam("PNO") int PNO, @QueryParam("size") int size,
			@QueryParam("schoolid") int schoolid,@QueryParam("branchid") int branchid);

	
	@POST
	@Consumes({ "application/xml", "application/json" })
	@Produces({ "application/xml", "application/json" })
	@Path("/addparentindifferentbranch/")
	public Response addParentInDifferentBranch(ParentPojo pp, @QueryParam("userid") int userid,
	@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
	@QueryParam("schoolid") int schoolid,@QueryParam("branchid") int branchid);

	
}
