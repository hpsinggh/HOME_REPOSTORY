
package com.gwebitsol.core.parent;

import java.text.DateFormat;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response;

import org.springframework.stereotype.Service;
import org.springframework.stereotype.Service;

import com.gwebitsol.core.security.MDValidation;
import com.gwebitsol.core.security.MDVerifyConnectionID;
import com.gwebitsol.core.security.MDVerifyConnectionID;
import com.gwebitsol.core.security.MDVerifyDatastoreName;
import com.gwebitsol.core.security.MDVerifyDatastoreName;
import com.gwebitsol.core.usermanagement.MDGetUserFromID;
import com.gwebitsol.core.usermanagement.MDGetUserFromID;
import com.gwebitsol.core.util.MDTransactionWriter;
import com.gwebitsol.core.util.MDTransactionWriter;

@Service
public class ParentService implements ParentServiceIntf {

	@Context
	private HttpServletRequest hsr;

	public Response createParent(ParentPojo pp, int userid, int connectionid, String datastoreName,int schoolid, int branchId) {

		MDTransactionWriter.accesslog.info("Request from:" + hsr.getRemoteHost());

		String status = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();

		pp.setBranchId(branchId);
		pp.setSchoolId(schoolid);
		
		try {
			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName,schoolid, branchId);
			System.out.println("verifiedvalue::"+ret);
			
			MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userid);

			if (ret == 1) // && rtVal==1)
			{
				ParentDao pd = new ParentDao();
				status = pd.createParent(pp);
				System.out.println(status);
				Long el = System.currentTimeMillis();
				String endDate = dateFormat.format(new Date());
				// status= "user validation is successfull";
				MDTransactionWriter.writeLog(datastoreName, "MMS", requester, startDate, endDate, sl, el, status,
						hsr.getRemoteHost());
			} else {
				status = "you are not authorised user";
			}
		} catch (Exception localException) {

			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status = "failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response updateParent(ParentPojo pp, int userid, int connectionid, String datastoreName, int schoolid, int branchId) {

		MDTransactionWriter.accesslog.info("Request from:" + hsr.getRemoteHost());

		System.out.println(pp.getFirstName());
		System.out.println(pp.getQualification());

		String status = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();

		pp.setBranchId(branchId);
		pp.setSchoolId(schoolid);
		
		try {
			
			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName, schoolid, branchId);
			System.out.println("verifiedvalue::"+ret);

			MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userid);
			
			if (ret == 1) // && rtVal==1)
			{
				ParentDao pd = new ParentDao();
				status = pd.updateParent(pp,schoolid, branchId);
				System.out.println(status);
				Long el = System.currentTimeMillis();
				String endDate = dateFormat.format(new Date());
				// status= "user validation is successfull";
				MDTransactionWriter.writeLog(datastoreName, "MMS", requester, startDate, endDate, sl, el, status,
						hsr.getRemoteHost());

			} else {
				status = "you are not authorised user";
			}
		} catch (Exception localException) {

			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status = "failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response deleteParent(int parentId, int userid, int connectionid, String datastoreName, int schoolid, int branchId) {

		MDTransactionWriter.accesslog.info("Request from:" + hsr.getRemoteHost());

		String status = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();

		try {
			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName, schoolid, branchId);
			System.out.println("verifiedvalue::"+ret);
			
			MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userid);

			if (ret == 1) // && rtVal==1)
			{
				ParentDao pd = new ParentDao();

				status = pd.deleteParent(parentId,schoolid, branchId);
				System.out.println(status);
				Long el = System.currentTimeMillis();
				String endDate = dateFormat.format(new Date());
				// status= "user validation is successfull";
				MDTransactionWriter.writeLog(datastoreName, "MMS", requester, startDate, endDate, sl, el, status,
						hsr.getRemoteHost());
			} else {
				status = "you are not authorised user";
			}
		} catch (Exception localException) {

			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status = "failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();

	}

	public Response getParent(int id, int userid, int connectionid, String datastoreName, int schoolid, int branchId) {

		String status = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();

		try {
			
			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName, schoolid, branchId);
			System.out.println("verifiedvalue::"+ret);
			
			MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userid);

			if (ret == 1) // && rtVal==1)
			{
				ParentDao pd = new ParentDao();
				status = pd.getParent(id, schoolid, branchId);
				System.out.println(status);
				Long el = System.currentTimeMillis();
				String endDate = dateFormat.format(new Date());
				// status= "user validation is successfull";
				MDTransactionWriter.writeLog(datastoreName, "MMS", requester, startDate, endDate, sl, el, status,
						hsr.getRemoteHost());
			} else {
				status = "you are not authorised user";
			}
		} catch (Exception localException) {

			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status = "failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	
	public Response getAllParentsInfo(int userid, int connectionid,String studentNo,int classId,int SectionId,String datastoreName, int PNO, int size, int schoolid, int branchId) {
		
		String status = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();

		try {
			
			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName,schoolid, branchId);
			System.out.println("verifiedvalue::"+ret);
			
			MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userid);

			if (ret == 1) // && rtVal==1)
			{
				ParentDao pd = new ParentDao();
				status = pd.getAllParentsInfo(PNO, size,studentNo,classId,SectionId,schoolid, branchId);
						
				System.out.println(status);
				Long el = System.currentTimeMillis();
				String endDate = dateFormat.format(new Date());
				// status= "user validation is successfull";
				MDTransactionWriter.writeLog(datastoreName, "MMS", requester, startDate, endDate, sl, el, status,
						hsr.getRemoteHost());

			} else {
				status = "you are not authorised user";
			}
		} catch (Exception localException) {
			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status = "failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	
	public Response addParentInDifferentBranch(ParentPojo pp, int userid, int connectionid, String datastoreName,
			int schoolid, int branchid) {
		MDTransactionWriter.accesslog.info("Request from:" + hsr.getRemoteHost());

		String status = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();

		pp.setBranchId(branchid);
		pp.setSchoolId(schoolid);
		
		try {
			
			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName,schoolid, branchid);
			System.out.println("verifiedvalue::"+ret);

			MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userid);
			
			if (ret == 1) // && rtVal==1)
			{
				ParentDao pd = new ParentDao();
				status = pd.addParentForDiffBranch(pp);
				System.out.println(status);
				Long el = System.currentTimeMillis();
				String endDate = dateFormat.format(new Date());
				// status= "user validation is successfull";
				MDTransactionWriter.writeLog(datastoreName, "MMS", requester, startDate, endDate, sl, el, status,
						hsr.getRemoteHost());
			} else {
				status = "you are not authorised user";
			}
		} catch (Exception localException) {

			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status = "failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

}

