package com.gwebitsol.core.staff;

import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

@Repository
@Component
public class StaffExperienceDao {

	StringBuffer StaffID = new StringBuffer();

	public String addStaffExperience(StaffExperiencePojo sep) {

		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String staffexpreg = null;

		try {
			rdTx = rdSession.beginTransaction();

			Integer staffexpid = (Integer) rdSession.save(sep);
			rdTx.commit();
			StaffID.append("<StaffExperience>");
			StaffID.append("\n");
			StaffID.append("<id>");
			StaffID.append("\n");
			StaffID.append(staffexpid);
			StaffID.append("</id>");
			StaffID.append("\n");
			StaffID.append("</StaffExperience>");
			staffexpreg = StaffID.toString();
		} catch (Exception localException) {

			localException.printStackTrace();
			System.out.println(localException);

			StaffID.append("<Response>");
			StaffID.append("\n");
			StaffID.append("<Result>");
			StaffID.append("\n");
			StaffID.append("Fail");
			StaffID.append("\n");
			StaffID.append("</Result>");
			StaffID.append("\n");
			StaffID.append("<Description>");
			StaffID.append("could not inserted staff experience info");
			StaffID.append("</Description>");
			StaffID.append("\n");
			StaffID.append("<Exception>");
			StaffID.append(localException);
			StaffID.append("</Exception>");
			StaffID.append("</Response>");

			staffexpreg = StaffID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		} finally {
			rdSession.close();
		}
		return staffexpreg;
	}

	public String updatestaffExperience(StaffExperiencePojo sep,int schoolid,int branchid) {

		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String staffexpreg = null;

		try {
			rdTx = rdSession.beginTransaction();

			StaffExperiencePojo mdclpojo = (StaffExperiencePojo) rdSession.get(StaffExperiencePojo.class,sep.getStaffExpId());
			if(branchid==mdclpojo.getBranchId()&&schoolid==mdclpojo.getSchoolId())
			rdSession.evict(mdclpojo);
			
			rdSession.update(sep);

			rdTx.commit();

			staffexpreg = "staffexperience is succssfully updated";

			StaffID.append("<StaffExperience>");
			StaffID.append("\n");
			StaffID.append(staffexpreg);
			StaffID.append("</StaffExperience>");
			String str = StaffID.toString();
			return str;
		} catch (Exception localException) {
			localException.printStackTrace();
			System.out.println(localException);

			StaffID.append("<Response>");
			StaffID.append("\n");
			StaffID.append("<Result>");
			StaffID.append("\n");
			StaffID.append("Fail");
			StaffID.append("\n");
			StaffID.append("</Result>");
			StaffID.append("\n");
			StaffID.append("<Description>");
			StaffID.append("could not updated staff experience info");
			StaffID.append("</Description>");
			StaffID.append("\n");
			StaffID.append("<Exception>");
			StaffID.append(localException);
			StaffID.append("</Exception>");
			StaffID.append("</Response>");

			staffexpreg = StaffID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();

		} finally {
			rdSession.close();
		}
		return staffexpreg;
	}

	public String deleteStaffExperience(int staffExpId, int schoolid,int branchid) {

		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String staffexpreg = null;

		try {

			rdTx = rdSession.beginTransaction();

			StaffExperiencePojo mdclpojo = (StaffExperiencePojo) rdSession.get(StaffExperiencePojo.class,staffExpId);
			
			rdSession.evict(mdclpojo);
			
			if(branchid==mdclpojo.getBranchId()&&schoolid==mdclpojo.getSchoolId())
			{
			Query empQuery=rdSession.createSQLQuery("update gbl_sm_tbl_staff_experience set isDeleted='y' where StaffExpId='"+staffExpId+"'");
			
			empQuery.executeUpdate();
			
			rdTx.commit();
			staffexpreg = "staffexperience succssfully deleted";
			StaffID.append("<StaffExperience>");
			StaffID.append("\n");
			StaffID.append(staffexpreg);
			StaffID.append("</StaffExperience>");
			String str = StaffID.toString();
			return str;
			}else
			{
				staffexpreg = "staff experience is not deleted";
				StaffID.append("<StaffExperience>");
				StaffID.append("\n");
				StaffID.append(staffexpreg);
				StaffID.append("</StaffExperience>");
				String str = StaffID.toString();
				return str;
			}
		} catch (Exception localException) {
			localException.printStackTrace();
			System.out.println(localException);

			StaffID.append("<Response>");
			StaffID.append("\n");
			StaffID.append("<Result>");
			StaffID.append("\n");
			StaffID.append("Fail");
			StaffID.append("\n");
			StaffID.append("</Result>");
			StaffID.append("\n");
			StaffID.append("<Description>");
			StaffID.append("could not deleted staff experience info");
			StaffID.append("</Description>");
			StaffID.append("\n");
			StaffID.append("<Exception>");
			StaffID.append(localException);
			StaffID.append("</Exception>");
			StaffID.append("</Response>");

			staffexpreg = StaffID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		} finally {
			rdSession.close();
		}
		return staffexpreg;
	}

	public String getStaffExperienceByEmpId(int employeeid,int schoolid,int branchid) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String staffexpreg = null;
		String gsSql = null;
		try {
			rdTx = rdSession.beginTransaction();

			gsSql="select gbl_sm_tbl_staff_experience.*, gbl_sm_tbl_staff.FirstName, gbl_sm_tbl_staff.MiddleName,"
						+" gbl_sm_tbl_staff.LastName,gbl_sm_tbl_staff.StaffNumber,gbl_sm_tbl_jobtitle.Title"
						+" from gbl_sm_tbl_staff_experience"
						+" join gbl_sm_tbl_staff on gbl_sm_tbl_staff_experience.EmployeeId = gbl_sm_tbl_staff.EmployeeId"
						+" join gbl_sm_tbl_jobtitle on gbl_sm_tbl_staff_experience.JobTitleId=gbl_sm_tbl_jobtitle.JobTitleId "
						+" where gbl_sm_tbl_staff_experience.IsDeleted is null and gbl_sm_tbl_staff_experience.EmployeeId ='"+employeeid+"' and gbl_sm_tbl_staff_experience.SchoolId='"+schoolid+"' and gbl_sm_tbl_staff_experience.BranchId='"+branchid+"';";
						
			Query gsQuery=rdSession.createSQLQuery(gsSql);
			List gcList=gsQuery.list();
			Iterator gsIT=gcList.iterator();
				while(gsIT.hasNext())
				{
					Object[] mdcArr=(Object[])gsIT.next();
					StaffID.append("<StaffExperience>");
					StaffID.append("\n");
					StaffID.append("<staffExpId>"+mdcArr[0]+"</staffExpId>");
					StaffID.append("\n");
					StaffID.append("<employeeId>" + mdcArr[1]+ "</employeeId>");
					StaffID.append("\n");
					StaffID.append("<staffFirstName>" + mdcArr[13] + "</staffFirstName>");
					StaffID.append("\n");
					StaffID.append("<staffMiddleName>" + mdcArr[14] + "</staffMiddleName>");
					StaffID.append("\n");
					StaffID.append("<staffLastName>" + mdcArr[15]+ "</staffLastName>");
					StaffID.append("\n");
					StaffID.append("<staffNumber>" + mdcArr[16] + "</staffNumber>");
					StaffID.append("\n");
					StaffID.append("<jobTitleId>" + mdcArr[2]+ "</jobTitleId>");
					StaffID.append("\n");
					StaffID.append("<jobTitleName>" + mdcArr[17] + "</jobTitleName>");
					StaffID.append("\n");
					StaffID.append("<previousInstitution>" + mdcArr[3] + "</previousInstitution>");
					StaffID.append("\n");
					StaffID.append("<workedFrom>" + mdcArr[4]+ "</workedFrom>");
					StaffID.append("\n");
					StaffID.append("<workedTo>" + mdcArr[5] + "</workedTo>");
					StaffID.append("\n");
					StaffID.append("<jobRole>" +  mdcArr[6]+ "</jobRole>");
					StaffID.append("\n");
					StaffID.append("<remarks>" + mdcArr[7] + "</remarks>");
					StaffID.append("\n");
					StaffID.append("<createdDate>" + mdcArr[8] + "</createdDate>");
					StaffID.append("\n");
					StaffID.append("<modifiedDate>" + mdcArr[9] + "</modifiedDate>");
					StaffID.append("\n");
					StaffID.append("<schoolId>" + mdcArr[10] + "</schoolId>");
					StaffID.append("\n");
					StaffID.append("<branchId>" + mdcArr[11] + "</branchId>");
					StaffID.append("\n");
					StaffID.append("<isDeleted>" + mdcArr[12] + "</isDeleted>");
					StaffID.append("\n");
					StaffID.append("</StaffExperience>");
					StaffID.append("\n");
			
			}
			rdTx.commit();
			staffexpreg=StaffID.toString();
		} catch (HibernateException localException) {
			localException.printStackTrace();
			System.out.println(localException);

			StaffID.append("<Response>");
			StaffID.append("\n");
			StaffID.append("<Result>");
			StaffID.append("\n");
			StaffID.append("Fail");
			StaffID.append("\n");
			StaffID.append("</Result>");
			StaffID.append("\n");
			StaffID.append("<Description>");
			StaffID.append("could not get staff experience info");
			StaffID.append("</Description>");
			StaffID.append("\n");
			StaffID.append("<Exception>");
			StaffID.append(localException);
			StaffID.append("</Exception>");
			StaffID.append("</Response>");

			staffexpreg = StaffID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		} finally {
			rdSession.close();
		}
		return staffexpreg;
	}

	public String getStaffExperienceByStfExpAndEmpId(int staffExpId, int employeeid, int schoolid, int branchid) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String staffexpreg = null;
		String gsSql = null;
		
		try {
			
			rdTx = rdSession.beginTransaction();
			gsSql="select gbl_sm_tbl_staff_experience.*, gbl_sm_tbl_staff.FirstName, gbl_sm_tbl_staff.MiddleName,"
						+" gbl_sm_tbl_staff.LastName,gbl_sm_tbl_staff.StaffNumber,gbl_sm_tbl_jobtitle.Title"
						+" from gbl_sm_tbl_staff_experience"
						+" join gbl_sm_tbl_staff on gbl_sm_tbl_staff_experience.EmployeeId = gbl_sm_tbl_staff.EmployeeId"
						+" join gbl_sm_tbl_jobtitle on gbl_sm_tbl_staff_experience.JobTitleId=gbl_sm_tbl_jobtitle.JobTitleId "
						+" where gbl_sm_tbl_staff_experience.IsDeleted is null and gbl_sm_tbl_staff_experience.StaffExpId='"+staffExpId+"' and gbl_sm_tbl_staff_experience.EmployeeId ='"+employeeid
						+"' and gbl_sm_tbl_staff_experience.SchoolId='"+schoolid+"' and gbl_sm_tbl_staff_experience.BranchId='"+branchid+"';";
						
			Query gsQuery=rdSession.createSQLQuery(gsSql);
			List gcList=gsQuery.list();
			Iterator gsIT=gcList.iterator();
				while(gsIT.hasNext())
				{
					Object[] mdcArr=(Object[])gsIT.next();
					StaffID.append("<StaffExperience>");
					StaffID.append("\n");
					StaffID.append("<staffExpId>"+mdcArr[0]+"</staffExpId>");
					StaffID.append("\n");
					StaffID.append("<employeeId>" + mdcArr[1]+ "</employeeId>");
					StaffID.append("\n");
					StaffID.append("<staffFirstName>" + mdcArr[13] + "</staffFirstName>");
					StaffID.append("\n");
					StaffID.append("<staffMiddleName>" + mdcArr[14] + "</staffMiddleName>");
					StaffID.append("\n");
					StaffID.append("<staffLastName>" + mdcArr[15]+ "</staffLastName>");
					StaffID.append("\n");
					StaffID.append("<staffNumber>" + mdcArr[16] + "</staffNumber>");
					StaffID.append("\n");
					StaffID.append("<jobTitleId>" + mdcArr[2]+ "</jobTitleId>");
					StaffID.append("\n");
					StaffID.append("<jobTitleName>" + mdcArr[17] + "</jobTitleName>");
					StaffID.append("\n");
					StaffID.append("<previousInstitution>" + mdcArr[3] + "</previousInstitution>");
					StaffID.append("\n");
					StaffID.append("<workedFrom>" + mdcArr[4]+ "</workedFrom>");
					StaffID.append("\n");
					StaffID.append("<workedTo>" + mdcArr[5] + "</workedTo>");
					StaffID.append("\n");
					StaffID.append("<jobRole>" +  mdcArr[6]+ "</jobRole>");
					StaffID.append("\n");
					StaffID.append("<remarks>" + mdcArr[7] + "</remarks>");
					StaffID.append("\n");
					StaffID.append("<createdDate>" + mdcArr[8] + "</createdDate>");
					StaffID.append("\n");
					StaffID.append("<modifiedDate>" + mdcArr[9] + "</modifiedDate>");
					StaffID.append("\n");
					StaffID.append("<schoolId>" + mdcArr[10] + "</schoolId>");
					StaffID.append("\n");
					StaffID.append("<branchId>" + mdcArr[11] + "</branchId>");
					StaffID.append("\n");
					StaffID.append("<isDeleted>" + mdcArr[12] + "</isDeleted>");
					StaffID.append("\n");
					StaffID.append("</StaffExperience>");
					StaffID.append("\n");
			
			}
			rdTx.commit();
			staffexpreg=StaffID.toString();
		} catch (HibernateException localException) {
			localException.printStackTrace();
			System.out.println(localException);

			StaffID.append("<Response>");
			StaffID.append("\n");
			StaffID.append("<Result>");
			StaffID.append("\n");
			StaffID.append("Fail");
			StaffID.append("\n");
			StaffID.append("</Result>");
			StaffID.append("\n");
			StaffID.append("<Description>");
			StaffID.append("could not get staff experience info");
			StaffID.append("</Description>");
			StaffID.append("\n");
			StaffID.append("<Exception>");
			StaffID.append(localException);
			StaffID.append("</Exception>");
			StaffID.append("</Response>");

			staffexpreg = StaffID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		} finally {
			rdSession.close();
		}
		return staffexpreg;
	}

	public String getAllStaffExp(int PNO, int size,int schoolid,int branchid) {
		String xmlString=null;
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		
		try
		{
			rdTx=rdSession.beginTransaction();
		
				int fset = (PNO-1)*size;
				String gsSql ="select count(*) from gbl_sm_tbl_staff_experience where gbl_sm_tbl_staff_experience.IsDeleted is null and gbl_sm_tbl_staff_experience.SchoolId='"
						+ schoolid + "' and gbl_sm_tbl_staff_experience.BranchId='" + branchid + "';";
				Query gsQuery=rdSession.createSQLQuery(gsSql);
				Object noRecords= gsQuery.uniqueResult();
				int intNoRecords=0;
				   if(noRecords!=null && Integer.parseInt(noRecords.toString())!=0)
				   {
				    intNoRecords=Integer.parseInt(noRecords.toString());
				   }
		
				  
				StaffID.append("<StaffExperience>");
				StaffID.append("\n");
				StaffID.append("<noRecords>"+noRecords+"</noRecords>");
				StaffID.append("\n");
				 if(intNoRecords!=0)
				   {
					if (PNO > 0 & size > 0){
					gsSql="select gbl_sm_tbl_staff_experience.*, gbl_sm_tbl_staff.FirstName, gbl_sm_tbl_staff.MiddleName,"
						+" gbl_sm_tbl_staff.LastName,gbl_sm_tbl_staff.StaffNumber,gbl_sm_tbl_jobtitle.Title"
						+" from gbl_sm_tbl_staff_experience"
						+" join gbl_sm_tbl_staff on  gbl_sm_tbl_staff_experience.EmployeeId = gbl_sm_tbl_staff.EmployeeId"
						+" join gbl_sm_tbl_jobtitle on gbl_sm_tbl_staff_experience.JobTitleId=gbl_sm_tbl_jobtitle.JobTitleId "
						+" where gbl_sm_tbl_staff_experience.IsDeleted is null and gbl_sm_tbl_staff_experience.SchoolId='"+schoolid+"' and gbl_sm_tbl_staff_experience.BranchId='"+branchid+"' limit "+size+" offset "+fset+";";
					
					}
					else {
						gsSql="select gbl_sm_tbl_staff_experience.*, gbl_sm_tbl_staff.FirstName, gbl_sm_tbl_staff.MiddleName,"
						+" gbl_sm_tbl_staff.LastName,gbl_sm_tbl_staff.StaffNumber,gbl_sm_tbl_jobtitle.Title"
						+" from gbl_sm_tbl_staff_experience"
						+" join gbl_sm_tbl_staff on  gbl_sm_tbl_staff_experience.EmployeeId = gbl_sm_tbl_staff.EmployeeId"
						+" join gbl_sm_tbl_jobtitle on gbl_sm_tbl_staff_experience.JobTitleId=gbl_sm_tbl_jobtitle.JobTitleId"
						+" where gbl_sm_tbl_staff_experience.IsDeleted is null and gbl_sm_tbl_staff_experience.SchoolId='"+schoolid+"' and gbl_sm_tbl_staff_experience.BranchId='"+branchid+"';";
						
					}	
				
				gsQuery=rdSession.createSQLQuery(gsSql);
				List gcList=gsQuery.list();
				Iterator gsIT=gcList.iterator();
					while(gsIT.hasNext())
					{
						Object[] mdcArr=(Object[])gsIT.next();
						StaffID.append("<StaffExperience>");
						StaffID.append("\n");
						StaffID.append("<staffExpId>"+mdcArr[0]+"</staffExpId>");
						StaffID.append("\n");
						StaffID.append("<employeeId>" + mdcArr[1]+ "</employeeId>");
						StaffID.append("\n");
						StaffID.append("<staffFirstName>" + mdcArr[13] + "</staffFirstName>");
						StaffID.append("\n");
						StaffID.append("<staffMiddleName>" + mdcArr[14] + "</staffMiddleName>");
						StaffID.append("\n");
						StaffID.append("<staffLastName>" + mdcArr[15]+ "</staffLastName>");
						StaffID.append("\n");
						StaffID.append("<staffNumber>" + mdcArr[16] + "</staffNumber>");
						StaffID.append("\n");
						StaffID.append("<jobTitleId>" + mdcArr[2]+ "</jobTitleId>");
						StaffID.append("\n");
						StaffID.append("<jobTitleName>" + mdcArr[17] + "</jobTitleName>");
						StaffID.append("\n");
						StaffID.append("<previousInstitution>" + mdcArr[3] + "</previousInstitution>");
						StaffID.append("\n");
						StaffID.append("<workedFrom>" + mdcArr[4]+ "</workedFrom>");
						StaffID.append("\n");
						StaffID.append("<workedTo>" + mdcArr[5] + "</workedTo>");
						StaffID.append("\n");
						StaffID.append("<jobRole>" +  mdcArr[6]+ "</jobRole>");
						StaffID.append("\n");
						StaffID.append("<remarks>" + mdcArr[7] + "</remarks>");
						StaffID.append("\n");
						StaffID.append("<createdDate>" + mdcArr[8] + "</createdDate>");
						StaffID.append("\n");
						StaffID.append("<modifiedDate>" + mdcArr[9] + "</modifiedDate>");
						StaffID.append("\n");
						StaffID.append("<schoolId>" + mdcArr[10] + "</schoolId>");
						StaffID.append("\n");
						StaffID.append("<branchId>" + mdcArr[11] + "</branchId>");
						StaffID.append("\n");
						StaffID.append("<isDeleted>" + mdcArr[12] + "</isDeleted>");
						StaffID.append("\n");
						StaffID.append("</StaffExperience>");
						StaffID.append("\n");
					}
				   }
				rdTx.commit();
				StaffID.append("</StaffExperience>");
				StaffID.append("\n");

				xmlString=StaffID.toString();
		}	
		catch(Exception localException)
		{
			localException.printStackTrace();
			System.out.println(localException);

			StaffID.append("<Response>");
			StaffID.append("\n");
			StaffID.append("<Result>");
			StaffID.append("\n");
			StaffID.append("Fail");
			StaffID.append("\n");
			StaffID.append("</Result>");
			StaffID.append("\n");
			StaffID.append("<Description>");
			StaffID.append("could not get staff experience info");
			StaffID.append("</Description>");
			StaffID.append("\n");
			StaffID.append("<Exception>");
			StaffID.append(localException);
			StaffID.append("</Exception>");
			StaffID.append("</Response>");
			xmlString = StaffID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		}
		finally
		{
			rdSession.close();
		}	
		return xmlString;
	}

	

}
