package com.gwebitsol.core.staff;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.stereotype.Service;

import com.gwebitsol.core.security.MDValidation;
import com.gwebitsol.core.security.MDVerifyConnectionID;
import com.gwebitsol.core.security.MDVerifyDatastoreName;
import com.gwebitsol.core.usermanagement.MDGetUserFromID;
import com.gwebitsol.core.util.MDTransactionWriter;

@Service
public class StaffSubjectsService implements StaffSubjectsServiceIntf {

	@Context
	private HttpServletRequest hsr;

	public Response addStaffSubjects(StaffSubjectsPojo sep, int userid, int connectionid, String datastoreName, int schoolid,int branchId) {

		MDTransactionWriter.accesslog.info("Request from:" + hsr.getRemoteHost());

		String status = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();
		
		sep.setBranchId(branchId);
		sep.setSchoolId(schoolid);

		try {

			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName, schoolid, branchId);
			System.out.println("verifiedvalue::"+ret);
			
			if (ret == 1) // && rtVal==1)
			{
				StaffSubjectsDao ad = new StaffSubjectsDao();
				status = ad.addStaffSubjects(sep);
				System.out.println(status);
				Long el = System.currentTimeMillis();
				String endDate = dateFormat.format(new Date());
				// status= "user validation is successfull";
				MDTransactionWriter.writeLog("SCHOOL", "MMS", "srinu", startDate, endDate, sl, el, status,
						hsr.getRemoteHost());
			} else {
				status = "you are not authorised user";
			}
		} catch (Exception localException) {

			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status = "failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response updateStaffSubjects(StaffSubjectsPojo sep, int userid, int connectionid, String datastoreName, int schoolid,int branchId) {
		MDTransactionWriter.accesslog.info("Request from:" + hsr.getRemoteHost());

		String status = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();

		sep.setBranchId(branchId);
		sep.setSchoolId(schoolid);
		
		try {

			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName, schoolid, branchId);
			System.out.println("verifiedvalue::"+ret);
			if (ret == 1) // && rtVal==1)
			{

				StaffSubjectsDao ad = new StaffSubjectsDao();
				status = ad.updateStaffSubjects(sep, schoolid, branchId);
				System.out.println(status);
				Long el = System.currentTimeMillis();
				String endDate = dateFormat.format(new Date());
				// status= "user validation is successfull";
				MDTransactionWriter.writeLog("SCHOOL", "MMS", "srinu", startDate, endDate, sl, el, status,
						hsr.getRemoteHost());
			} else {
				status = "you are not authorised user";
			}
		} catch (Exception localException) {

			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status = "failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response deleteStaffSubjects(int staffSubId, int userid, int connectionid, String datastoreName, int schoolid,int branchId) {

		MDTransactionWriter.accesslog.info("Request from:" + hsr.getRemoteHost());

		String status = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();

		try {

			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName, schoolid, branchId);
			System.out.println("verifiedvalue::"+ret);
			
			if (ret == 1) // && rtVal==1)
			{
				StaffSubjectsDao ad = new StaffSubjectsDao();
				status = ad.deleteStaffSubjects(staffSubId, schoolid, branchId);
				System.out.println(status);
				Long el = System.currentTimeMillis();
				String endDate = dateFormat.format(new Date());
				// status= "user validation is successfull";
				MDTransactionWriter.writeLog("SCHOOL", "MMS", "srinu", startDate, endDate, sl, el, status,
						hsr.getRemoteHost());
			} else {
				status = "you are not authorised user";
			}
		} catch (Exception localException) {

			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status = "failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response getStaffSubjectsByEmpId(int employeeid, int userid, int connectionid, String datastoreName, int schoolid,int branchId) {

		MDTransactionWriter.accesslog.info("Request from:" + hsr.getRemoteHost());

		String status = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();

		try {

			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName, schoolid, branchId);
			System.out.println("verifiedvalue::"+ret);
			
			if (ret == 1) // && rtVal==1)
			{
				StaffSubjectsDao ad = new StaffSubjectsDao();
				status = ad.getStaffSubjectsByEmpId(employeeid,schoolid, branchId);
				System.out.println(status);
				Long el = System.currentTimeMillis();
				String endDate = dateFormat.format(new Date());
				// status= "user validation is successfull";
				MDTransactionWriter.writeLog("SCHOOL", "MMS", "srinu", startDate, endDate, sl, el, status,
						hsr.getRemoteHost());
			} else {
				status = "you are not authorised user";
			}
		} catch (Exception localException) {

			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status = "failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response getStaffSubjectsByStfSubAndEmpId(int staffSubId, int employeeid, int userid, int connectionid,
			String datastoreName, int schoolid, int branchid) {
		
		MDTransactionWriter.accesslog.info("Request from:" + hsr.getRemoteHost());

		String status = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();

		try {

			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName, schoolid, branchid);
			System.out.println("verifiedvalue::"+ret);
			
			if (ret == 1) // && rtVal==1)
			{
				StaffSubjectsDao ad = new StaffSubjectsDao();
				status = ad.getStaffSubjectsByStfSubAndEmpId(staffSubId,employeeid,schoolid, branchid);
				System.out.println(status);
				Long el = System.currentTimeMillis();
				String endDate = dateFormat.format(new Date());
				// status= "user validation is successfull";
				MDTransactionWriter.writeLog("SCHOOL", "MMS", "srinu", startDate, endDate, sl, el, status,
						hsr.getRemoteHost());
			} else {
				status = "you are not authorised user";
			}
		} catch (Exception localException) {

			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status = "failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}
	
	public Response getAllStaffSubjects(int userid, int connectionid, String datastoreName) {

		MDTransactionWriter.accesslog.info("Request from:" + hsr.getRemoteHost());

		String status = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();

		try {
			MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userid);

			System.out.println(connectionid);
			MDVerifyConnectionID mdvcid = new MDVerifyConnectionID();
			int ret = mdvcid.verifyConnectionID(userid, connectionid);

			MDVerifyDatastoreName mdvdsn = new MDVerifyDatastoreName();
			int rtVal = mdvdsn.verifyDatastoreName(datastoreName);

			System.out.println("request making user:: " + requester);
			System.out.println("connectionid verification value:: " + ret);
			System.out.println("datastore verification value :: " + rtVal);
			if (ret == 1) // && rtVal==1)
			{
				StaffSubjectsDao ad = new StaffSubjectsDao();
				status = ad.getAllStaffSubjects();
				System.out.println(status);
				Long el = System.currentTimeMillis();
				String endDate = dateFormat.format(new Date());
				// status= "user validation is successfull";
				MDTransactionWriter.writeLog("SCHOOL", "MMS", "srinu", startDate, endDate, sl, el, status,
						hsr.getRemoteHost());
			} else {
				status = "you are not authorised user";
			}
		} catch (Exception localException) {

			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status = "failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response getAllStaffSubs(int userid, int connectionid, String datastoreName, int PNO, int size, int schoolid,int branchId) {
		
		MDTransactionWriter.accesslog.info("Request from:" + hsr.getRemoteHost());

		String status = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();

		try {

			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName, schoolid, branchId);
			System.out.println("verifiedvalue::"+ret);
			
			if (ret == 1) // && rtVal==1)
			{
				StaffSubjectsDao ad = new StaffSubjectsDao();
				status = ad.getAllStaffSubs(PNO,size, schoolid, branchId);
						
				System.out.println(status);
				Long el = System.currentTimeMillis();
				String endDate = dateFormat.format(new Date());
				// status= "user validation is successfull";
				MDTransactionWriter.writeLog("SCHOOL", "MMS", "srinu", startDate, endDate, sl, el, status,
						hsr.getRemoteHost());
			} else {
				status = "you are not authorised user";
			}
		} catch (Exception localException) {

			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status = "failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	
	
	public Response addStaffSubjectsOnExperience(StaffSubjectsPojo sep, int userid, int connectionid,
			String datastoreName, int schoolid,int branchId) {
	
		MDTransactionWriter.accesslog.info("Request from:" + hsr.getRemoteHost());

		String status = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();
		
		sep.setBranchId(branchId);
		sep.setSchoolId(schoolid);

		try {

			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName,schoolid, branchId);
			System.out.println("verifiedvalue::"+ret);
			
			if (ret == 1) // && rtVal==1)
			{
				StaffSubjectsDao ad = new StaffSubjectsDao();
				status = ad.addStaffSubjectsOnExperience(sep);
				System.out.println(status);
				Long el = System.currentTimeMillis();
				String endDate = dateFormat.format(new Date());
				// status= "user validation is successfull";
				MDTransactionWriter.writeLog("SCHOOL", "MMS", "srinu", startDate, endDate, sl, el, status,
						hsr.getRemoteHost());
			} else {
				status = "you are not authorised user";
			}
		} catch (Exception localException) {

			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status = "failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	

}
