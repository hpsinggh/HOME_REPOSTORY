package com.gwebitsol.core.staff;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.stereotype.Component;

@XmlRootElement(name = "StaffSubjects")
@Component

public class StaffSubjectsPojo implements Serializable {

	int staffSubId;
	int employeeId;
	String staffExpId;
	int subjectId;
	String lastUsed;
	String description;
	String createdDate;
	String isDeleted;
	int classIdTaught;
	int monthsTaught;
	
	int branchId;
	int schoolId;
	
	public int getBranchId() {
		return branchId;
	}

	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}

	public int getSchoolId() {
		return schoolId;
	}

	public void setSchoolId(int schoolId) {
		this.schoolId = schoolId;
	}

	public int getMonthsTaught() {
		return monthsTaught;
	}

	public void setMonthsTaught(int monthsTaught) {
		this.monthsTaught = monthsTaught;
	}

	
	public String getStaffExpId() {
		return staffExpId;
	}

	public void setStaffExpId(String staffExpId) {
		this.staffExpId = staffExpId;
	}


	DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	Date date = new Date();
	String modifiedDate = dateFormat.format(date);

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public int getStaffSubId() {
		return staffSubId;
	}

	public void setStaffSubId(int staffSubId) {
		this.staffSubId = staffSubId;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public int getSubjectId() {
		return subjectId;
	}

	public void setSubjectId(int subjectId) {
		this.subjectId = subjectId;
	}

	public String getLastUsed() {
		return lastUsed;
	}

	public void setLastUsed(String lastUsed) {
		this.lastUsed = lastUsed;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(String isDeleted) {
		this.isDeleted = isDeleted;
	}

	public int getClassIdTaught() {
		return classIdTaught;
	}

	public void setClassIdTaught(int classIdTaught) {
		this.classIdTaught = classIdTaught;
	}

}
