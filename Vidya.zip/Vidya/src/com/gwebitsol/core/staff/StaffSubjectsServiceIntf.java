package com.gwebitsol.core.staff;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

@Path("/staffsubjects/")

public interface StaffSubjectsServiceIntf {

	@POST
	@Path("/addstaffsubjects/")
	@Consumes({ "application/xml", "application/json" })
	@Produces({ "application/xml", "application/json" })

	public Response addStaffSubjects(StaffSubjectsPojo sep, @QueryParam("userid") int userid,
			@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
			@QueryParam("schoolid") int schoolid,@QueryParam("branchid") int branchid);

	@POST
	@Path("/updatestaffsubjects/")
	@Consumes({ "application/xml", "application/json" })
	@Produces({ "application/xml", "application/json" })
	public Response updateStaffSubjects(StaffSubjectsPojo sep, @QueryParam("userid") int userid,
			@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
			@QueryParam("schoolid") int schoolid,@QueryParam("branchid") int branchid);

	@POST
	@Path("/deletestaffsubjects/")
	@Consumes({ "application/xml", "application/json" })
	@Produces({ "application/xml", "application/json" })
	public Response deleteStaffSubjects(@QueryParam("staffSubId") int staffSubId, @QueryParam("userid") int userid,
			@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
			@QueryParam("schoolid") int schoolid,@QueryParam("branchid") int branchid);

	@GET
	@Path("/getstaffsubjects/")
	@Consumes({ "application/xml", "application/json" })
	@Produces({ "application/xml", "application/json" })
	public Response getStaffSubjectsByEmpId(@QueryParam("employeeid") int employeeid, @QueryParam("userid") int userid,
			@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
			@QueryParam("schoolid") int schoolid,@QueryParam("branchid") int branchid);

	@GET
	@Path("/getstaffsinglesubject/")
	@Consumes({ "application/xml", "application/json" })
	@Produces({ "application/xml", "application/json" })
	public Response getStaffSubjectsByStfSubAndEmpId(@QueryParam("staffSubId") int staffSubId,
			@QueryParam("employeeid") int employeeid, @QueryParam("userid") int userid,
			@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
			@QueryParam("schoolid") int schoolid, @QueryParam("branchid") int branchid);

	@GET
	@Path("/getallstaffsubjects/")
	@Consumes({ "application/xml", "application/json" })
	@Produces({ "application/xml", "application/json" })
	public Response getAllStaffSubjects(@QueryParam("userid") int userid, @QueryParam("connectionid") int connectionid,
			@QueryParam("datastoreName") String datastoreName);

	@GET
	@Path("/getallstaffsubs/")
	@Consumes({ "application/xml", "application/json" })
	@Produces({ "application/xml", "application/json" })
	public Response getAllStaffSubs(@QueryParam("userid") int userid, @QueryParam("connectionid") int connectionid,
			@QueryParam("datastoreName") String datastoreName, @QueryParam("PNO") int PNO, @QueryParam("size") int size,
			@QueryParam("schoolid") int schoolid,@QueryParam("branchid") int branchid);

	@POST
	@Path("/addstaffsubjectsandexperience/")
	@Consumes({ "application/xml", "application/json" })
	@Produces({ "application/xml", "application/json" })

	public Response addStaffSubjectsOnExperience(StaffSubjectsPojo sep, @QueryParam("userid") int userid,
			@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
			@QueryParam("schoolid") int schoolid,@QueryParam("branchid") int branchid);

}
