package com.gwebitsol.core.staff;

import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.gwebitsol.core.student.StudentEducationPojo;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

@Repository
@Component
public class StaffEducationDao {

	StringBuffer StaffID = new StringBuffer();

	public String addStaffEducation(StaffEducationPojo sep) {

		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String staffedureg = null;

		try {

			rdTx = rdSession.beginTransaction();

			Integer staffeduid = (Integer) rdSession.save(sep);
			rdTx.commit();
			StaffID.append("<StaffEducation>");
			StaffID.append("\n");
			StaffID.append("<id>");
			StaffID.append("\n");
			StaffID.append(staffeduid);
			StaffID.append("</id>");
			StaffID.append("\n");
			StaffID.append("</StaffEducation>");
			staffedureg = StaffID.toString();
		} catch (Exception localException) {
			localException.printStackTrace();
			System.out.println(localException);

			StaffID.append("<Response>");
			StaffID.append("\n");
			StaffID.append("<Result>");
			StaffID.append("\n");
			StaffID.append("Fail");
			StaffID.append("\n");
			StaffID.append("</Result>");
			StaffID.append("\n");
			StaffID.append("<Description>");
			StaffID.append("could not inserted staff education info");
			StaffID.append("</Description>");
			StaffID.append("\n");
			StaffID.append("<Exception>");
			StaffID.append(localException);
			StaffID.append("</Exception>");
			StaffID.append("</Response>");

			staffedureg = StaffID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		} finally {
			rdSession.close();
		}
		return staffedureg;
	}

	public String updateStaffEducation(StaffEducationPojo sep,int schoolid,int branchid) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String staffedureg = null;

		try {
			rdTx = rdSession.beginTransaction();

			/*String vcSql="select StaffEduId from gbl_sm_tbl_staff_education where StaffEduId="+sep.getStaffEdId();
			int Stfedid =(Integer)rdSession.createSQLQuery(vcSql).uniqueResult();
			*/
			
			int edid = sep.getStaffEdId();
			StaffEducationPojo mdclpojo = (StaffEducationPojo) rdSession.get(StaffEducationPojo.class,edid);
			
			int branid = mdclpojo.getBranchId();
			int sclid = mdclpojo.getSchoolId();
	
			if(branchid==branid&&schoolid==sclid)
			
			rdSession.evict(mdclpojo);
			rdSession.update(sep);	
			
			rdTx.commit();

			staffedureg = "staffeducation is succssfully updated";

			StaffID.append("<StaffEducation>");
			StaffID.append("\n");
			StaffID.append(staffedureg);
			StaffID.append("</StaffEducation>");
			String str = StaffID.toString();
			return str;
		} catch (Exception localException) {
			localException.printStackTrace();
			System.out.println(localException);

			StaffID.append("<Response>");
			StaffID.append("\n");
			StaffID.append("<Result>");
			StaffID.append("\n");
			StaffID.append("Fail");
			StaffID.append("\n");
			StaffID.append("</Result>");
			StaffID.append("\n");
			StaffID.append("<Description>");
			StaffID.append("could not updated staff education info");
			StaffID.append("</Description>");
			StaffID.append("\n");
			StaffID.append("<Exception>");
			StaffID.append(localException);
			StaffID.append("</Exception>");
			StaffID.append("</Response>");

			staffedureg = StaffID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		} finally {
			rdSession.close();
		}
		return staffedureg;
	}

	public String deleteStaffEducation(int staffEdId,int schoolid,int branchid) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String staffedureg = null;

		try {
			rdTx = rdSession.beginTransaction();
		
			StaffEducationPojo mdclpojo = (StaffEducationPojo) rdSession.get(StaffEducationPojo.class,staffEdId);
			
			int branid = mdclpojo.getBranchId();
			int sclid = mdclpojo.getSchoolId();
		    rdSession.evict(mdclpojo);
			
			if(branchid==branid&&schoolid==sclid)
			{
			 Query empQuery=rdSession.createSQLQuery("update gbl_sm_tbl_staff_education set isDeleted='y' where StaffEduId='"+staffEdId+"'");
			 empQuery.executeUpdate();
			/*StaffEducationPojo ap = new StaffEducationPojo();
			ap.setStaffEdId(staffEdId);
			rdSession.delete(ap);*/
			rdTx.commit();
			staffedureg = "staff education is succssfully deleted";
			StaffID.append("<StaffEducation>");
			StaffID.append("\n");
			StaffID.append(staffedureg);
			StaffID.append("</StaffEducation>");
			String str = StaffID.toString();
			return str;
			}
			else
			{
				staffedureg = "staff education is not deleted";
				StaffID.append("<StaffEducation>");
				StaffID.append("\n");
				StaffID.append(staffedureg);
				StaffID.append("</StaffEducation>");
				String str = StaffID.toString();
				return str;
			}
		} catch (Exception localException) {
			localException.printStackTrace();
			System.out.println(localException);

			StaffID.append("<Response>");
			StaffID.append("\n");
			StaffID.append("<Result>");
			StaffID.append("\n");
			StaffID.append("Fail");
			StaffID.append("\n");
			StaffID.append("</Result>");
			StaffID.append("\n");
			StaffID.append("<Description>");
			StaffID.append("could not deleted staff education info");
			StaffID.append("</Description>");
			StaffID.append("\n");
			StaffID.append("<Exception>");
			StaffID.append(localException);
			StaffID.append("</Exception>");
			StaffID.append("</Response>");

			staffedureg = StaffID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();

		} finally {
			rdSession.close();
		}
		return staffedureg;
	}

	public String getStaffEducationByEmpId(int employeeid,int schoolid,int branchid) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String staffedureg = null;
		String gsSql = null;
		try {
			rdTx = rdSession.beginTransaction();

			gsSql="select gbl_sm_tbl_staff_education.*, gbl_sm_tbl_staff.FirstName, gbl_sm_tbl_staff.MiddleName,"
						+" gbl_sm_tbl_staff.LastName, gbl_sm_tbl_staff.StaffNumber, gbl_sm_tbl_grade.GradeName,"
						+" gbl_sm_tbl_staff_accolades.AccoladeTitle"
						+" from gbl_sm_tbl_staff_education"
						+" join gbl_sm_tbl_staff on gbl_sm_tbl_staff_education.EmployeeId = gbl_sm_tbl_staff.EmployeeId"
						+" join gbl_sm_tbl_grade on gbl_sm_tbl_staff_education.GradeId=gbl_sm_tbl_grade.GradeId"
						+" join gbl_sm_tbl_staff_accolades on gbl_sm_tbl_staff_education.AccoladeId=gbl_sm_tbl_staff_accolades.AccoladeId"
						+" where gbl_sm_tbl_staff_education.IsDeleted is null and gbl_sm_tbl_staff_education.EmployeeId ='"+employeeid+"' and gbl_sm_tbl_staff_education.SchoolId='"+schoolid+"' and gbl_sm_tbl_staff_education.BranchId='"+branchid+"';";
		
			Query gsQuery=rdSession.createSQLQuery(gsSql);
			List gcList=gsQuery.list();
			Iterator gsIT=gcList.iterator();
				while(gsIT.hasNext())
				{
					Object[] mdcArr=(Object[])gsIT.next();
					StaffID.append("<staffeducation>");
					StaffID.append("\n");
					StaffID.append("<staffEduId>"+mdcArr[0]+"</staffEduId>");
					StaffID.append("\n");
					StaffID.append("<employeeId>" + mdcArr[1]+ "</employeeId>");
					StaffID.append("\n");
					StaffID.append("<staffFirstName>" + mdcArr[15] + "</staffFirstName>");
					StaffID.append("\n");
					StaffID.append("<staffMiddleName>" + mdcArr[16] + "</staffMiddleName>");
					StaffID.append("\n");
					StaffID.append("<staffLastName>" + mdcArr[17]+ "</staffLastName>");
					StaffID.append("\n");
					StaffID.append("<staffNumber>" + mdcArr[18] + "</staffNumber>");
					StaffID.append("\n");
					StaffID.append("<accoladeId>" + mdcArr[2]+ "</accoladeId>");
					StaffID.append("\n");
					StaffID.append("<accoladeTitle>" + mdcArr[20]+ "</accoladeTitle>");
					StaffID.append("\n");
					StaffID.append("<gradeId>" + mdcArr[3] + "</gradeId>");
					StaffID.append("\n");
					StaffID.append("<gradeName>" + mdcArr[19]+ "</gradeName>");
					StaffID.append("\n");
					StaffID.append("<passedInClass>" + mdcArr[4]+ "</passedInClass>");
					StaffID.append("\n");
					StaffID.append("<qualification>" + mdcArr[5] + "</qualification>");
					StaffID.append("\n");
					StaffID.append("<yearofPass>" +  mdcArr[6]+ "</yearofPass>");
					StaffID.append("\n");
					StaffID.append("<university>" + mdcArr[7] + "</university>");
					StaffID.append("\n");
					StaffID.append("<percentScore>" + mdcArr[8] + "</percentScore>");
					StaffID.append("\n");
					StaffID.append("<remarks>" + mdcArr[9] + "</remarks>");
					StaffID.append("\n");
					StaffID.append("<createdDate>" + mdcArr[10] + "</createdDate>");
					StaffID.append("\n");
					StaffID.append("<modifiedDate>" + mdcArr[11]+ "</modifiedDate>");
					StaffID.append("\n");
					StaffID.append("<schoolId>" + mdcArr[12]+ "</schoolId>");
					StaffID.append("\n");
					StaffID.append("<branchId>" + mdcArr[13]+ "</branchId>");
					StaffID.append("\n");
					StaffID.append("<isdeleted>" + mdcArr[14]+ "</isdeleted>");
					StaffID.append("\n");
					StaffID.append("</staffeducation>");
					StaffID.append("\n");
			}
			rdTx.commit();
			staffedureg=StaffID.toString();
		} catch (HibernateException localException) {
			localException.printStackTrace();
			System.out.println(localException);

			StaffID.append("<Response>");
			StaffID.append("\n");
			StaffID.append("<Result>");
			StaffID.append("\n");
			StaffID.append("Fail");
			StaffID.append("\n");
			StaffID.append("</Result>");
			StaffID.append("\n");
			StaffID.append("<Description>");
			StaffID.append("could not get staff education info");
			StaffID.append("</Description>");
			StaffID.append("\n");
			StaffID.append("<Exception>");
			StaffID.append(localException);
			StaffID.append("</Exception>");
			StaffID.append("</Response>");

			staffedureg = StaffID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		} finally {
			rdSession.close();
		}
		return staffedureg;
	}


   public String getStaffEducationByStfAndEmpId(int staffEdId, int employeeid, int schoolid, int branchid) {
	   Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
	   Transaction rdTx = null;
	   String staffedureg = null;
		String gsSql = null;
		try {
			rdTx = rdSession.beginTransaction();

			gsSql="select gbl_sm_tbl_staff_education.*, gbl_sm_tbl_staff.FirstName, gbl_sm_tbl_staff.MiddleName,"
						+" gbl_sm_tbl_staff.LastName, gbl_sm_tbl_staff.StaffNumber, gbl_sm_tbl_grade.GradeName,"
						+" gbl_sm_tbl_staff_accolades.AccoladeTitle"
						+" from gbl_sm_tbl_staff_education"
						+" join gbl_sm_tbl_staff on gbl_sm_tbl_staff_education.EmployeeId = gbl_sm_tbl_staff.EmployeeId"
						+" join gbl_sm_tbl_grade on gbl_sm_tbl_staff_education.GradeId=gbl_sm_tbl_grade.GradeId"
						+" join gbl_sm_tbl_staff_accolades on gbl_sm_tbl_staff_education.AccoladeId=gbl_sm_tbl_staff_accolades.AccoladeId"
						+" where gbl_sm_tbl_staff_education.IsDeleted is null and gbl_sm_tbl_staff_education.EmployeeId ='"+employeeid+"' and gbl_sm_tbl_staff_education.StaffEduId='"+staffEdId
						+"' and gbl_sm_tbl_staff_education.SchoolId='"+schoolid+"' and gbl_sm_tbl_staff_education.BranchId='"+branchid+"';";
		
			Query gsQuery=rdSession.createSQLQuery(gsSql);
			List gcList=gsQuery.list();
			Iterator gsIT=gcList.iterator();
				while(gsIT.hasNext())
				{
					Object[] mdcArr=(Object[])gsIT.next();
					StaffID.append("<staffeducation>");
					StaffID.append("\n");
					StaffID.append("<staffEduId>"+mdcArr[0]+"</staffEduId>");
					StaffID.append("\n");
					StaffID.append("<employeeId>" + mdcArr[1]+ "</employeeId>");
					StaffID.append("\n");
					StaffID.append("<staffFirstName>" + mdcArr[15] + "</staffFirstName>");
					StaffID.append("\n");
					StaffID.append("<staffMiddleName>" + mdcArr[16] + "</staffMiddleName>");
					StaffID.append("\n");
					StaffID.append("<staffLastName>" + mdcArr[17]+ "</staffLastName>");
					StaffID.append("\n");
					StaffID.append("<staffNumber>" + mdcArr[18] + "</staffNumber>");
					StaffID.append("\n");
					StaffID.append("<accoladeId>" + mdcArr[2]+ "</accoladeId>");
					StaffID.append("\n");
					StaffID.append("<accoladeTitle>" + mdcArr[20]+ "</accoladeTitle>");
					StaffID.append("\n");
					StaffID.append("<gradeId>" + mdcArr[3] + "</gradeId>");
					StaffID.append("\n");
					StaffID.append("<gradeName>" + mdcArr[19]+ "</gradeName>");
					StaffID.append("\n");
					StaffID.append("<passedInClass>" + mdcArr[4]+ "</passedInClass>");
					StaffID.append("\n");
					StaffID.append("<qualification>" + mdcArr[5] + "</qualification>");
					StaffID.append("\n");
					StaffID.append("<yearofPass>" +  mdcArr[6]+ "</yearofPass>");
					StaffID.append("\n");
					StaffID.append("<university>" + mdcArr[7] + "</university>");
					StaffID.append("\n");
					StaffID.append("<percentScore>" + mdcArr[8] + "</percentScore>");
					StaffID.append("\n");
					StaffID.append("<remarks>" + mdcArr[9] + "</remarks>");
					StaffID.append("\n");
					StaffID.append("<createdDate>" + mdcArr[10] + "</createdDate>");
					StaffID.append("\n");
					StaffID.append("<modifiedDate>" + mdcArr[11]+ "</modifiedDate>");
					StaffID.append("\n");
					StaffID.append("<schoolId>" + mdcArr[12]+ "</schoolId>");
					StaffID.append("\n");
					StaffID.append("<branchId>" + mdcArr[13]+ "</branchId>");
					StaffID.append("\n");
					StaffID.append("<isdeleted>" + mdcArr[14]+ "</isdeleted>");
					StaffID.append("\n");
					StaffID.append("</staffeducation>");
					StaffID.append("\n");
			}
			rdTx.commit();
			staffedureg=StaffID.toString();
		} catch (HibernateException localException) {
			localException.printStackTrace();
			System.out.println(localException);

			StaffID.append("<Response>");
			StaffID.append("\n");
			StaffID.append("<Result>");
			StaffID.append("\n");
			StaffID.append("Fail");
			StaffID.append("\n");
			StaffID.append("</Result>");
			StaffID.append("\n");
			StaffID.append("<Description>");
			StaffID.append("could not get staff education info");
			StaffID.append("</Description>");
			StaffID.append("\n");
			StaffID.append("<Exception>");
			StaffID.append(localException);
			StaffID.append("</Exception>");
			StaffID.append("</Response>");

			staffedureg = StaffID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		} finally {
			rdSession.close();
		}
		return staffedureg;
	}
	
	@SuppressWarnings("unused")
	public String getAllStfEdu(int PNO, int size,int schoolid,int branchid) 
	{
		String xmlString=null;
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		try
		{
			rdTx=rdSession.beginTransaction();
			
			    int fset = (PNO-1)*size;
				String gsSql ="select count(*) from gbl_sm_tbl_staff_education where gbl_sm_tbl_staff_education.IsDeleted is null and gbl_sm_tbl_staff_education.SchoolId='"
						+ schoolid + "' and gbl_sm_tbl_staff_education.BranchId='" + branchid + "';";
				Query gsQuery=rdSession.createSQLQuery(gsSql);
				Object noRecords= gsQuery.uniqueResult();
				int intNoRecords=0;
				   if(noRecords!=null && Integer.parseInt(noRecords.toString())!=0)
				   {
				    intNoRecords=Integer.parseInt(noRecords.toString());
				   }
				 
				
				StaffID.append("<staffeducation>");
				StaffID.append("\n");
				StaffID.append("<noRecords>"+noRecords+"</noRecords>");
				StaffID.append("\n");
				   if(intNoRecords!=0)
				   {
					if (PNO > 0 & size > 0){
					gsSql="select gbl_sm_tbl_staff_education.*, gbl_sm_tbl_staff.FirstName, gbl_sm_tbl_staff.MiddleName,"
						+" gbl_sm_tbl_staff.LastName, gbl_sm_tbl_staff.StaffNumber, gbl_sm_tbl_grade.GradeName,"
						+" gbl_sm_tbl_staff_accolades.AccoladeTitle"
						+" from gbl_sm_tbl_staff_education"
						+" join gbl_sm_tbl_staff on  gbl_sm_tbl_staff_education.EmployeeId = gbl_sm_tbl_staff.EmployeeId"
						+" join gbl_sm_tbl_grade on gbl_sm_tbl_staff_education.GradeId=gbl_sm_tbl_grade.GradeId"
						+" join gbl_sm_tbl_staff_accolades on gbl_sm_tbl_staff_education.AccoladeId=gbl_sm_tbl_staff_accolades.AccoladeId "
						+" where gbl_sm_tbl_staff_education.IsDeleted is null and gbl_sm_tbl_staff_education.SchoolId='"+schoolid+"' and gbl_sm_tbl_staff_education.BranchId='"+branchid+"' limit "+size+" offset "+fset+";";}
					else {
						gsSql="select gbl_sm_tbl_staff_education.*, gbl_sm_tbl_staff.FirstName, gbl_sm_tbl_staff.MiddleName,"
						+" gbl_sm_tbl_staff.LastName, gbl_sm_tbl_staff.StaffNumber, gbl_sm_tbl_grade.GradeName,"
						+" gbl_sm_tbl_staff_accolades.AccoladeTitle"
						+" from gbl_sm_tbl_staff_education"
						+" join gbl_sm_tbl_staff on  gbl_sm_tbl_staff_education.EmployeeId = gbl_sm_tbl_staff.EmployeeId"
						+" join gbl_sm_tbl_grade on gbl_sm_tbl_staff_education.GradeId=gbl_sm_tbl_grade.GradeId"
						+" join gbl_sm_tbl_staff_accolades on gbl_sm_tbl_staff_education.AccoladeId=gbl_sm_tbl_staff_accolades.AccoladeId"
						+" where gbl_sm_tbl_staff_education.IsDeleted is null and gbl_sm_tbl_staff_education.SchoolId='"+schoolid+"' and gbl_sm_tbl_staff_education.BranchId='"+branchid+"';";
					}	
				
				gsQuery=rdSession.createSQLQuery(gsSql);
				List gcList=gsQuery.list();
				Iterator gsIT=gcList.iterator();
					while(gsIT.hasNext())
					{
						Object[] mdcArr=(Object[])gsIT.next();
						StaffID.append("<staffeducation>");
						StaffID.append("\n");
						StaffID.append("<staffEduId>"+mdcArr[0]+"</staffEduId>");
						StaffID.append("\n");
						StaffID.append("<employeeId>" + mdcArr[1]+ "</employeeId>");
						StaffID.append("\n");
						StaffID.append("<staffFirstName>" + mdcArr[15] + "</staffFirstName>");
						StaffID.append("\n");
						StaffID.append("<staffMiddleName>" + mdcArr[16] + "</staffMiddleName>");
						StaffID.append("\n");
						StaffID.append("<staffLastName>" + mdcArr[17]+ "</staffLastName>");
						StaffID.append("\n");
						StaffID.append("<staffNumber>" + mdcArr[18] + "</staffNumber>");
						StaffID.append("\n");
						StaffID.append("<accoladeId>" + mdcArr[2]+ "</accoladeId>");
						StaffID.append("\n");
						StaffID.append("<accoladeTitle>" + mdcArr[20]+ "</accoladeTitle>");
						StaffID.append("\n");
						StaffID.append("<gradeId>" + mdcArr[3] + "</gradeId>");
						StaffID.append("\n");
						StaffID.append("<gradeName>" + mdcArr[19]+ "</gradeName>");
						StaffID.append("\n");
						StaffID.append("<passedInClass>" + mdcArr[4]+ "</passedInClass>");
						StaffID.append("\n");
						StaffID.append("<qualification>" + mdcArr[5] + "</qualification>");
						StaffID.append("\n");
						StaffID.append("<yearofPass>" +  mdcArr[6]+ "</yearofPass>");
						StaffID.append("\n");
						StaffID.append("<university>" + mdcArr[7] + "</university>");
						StaffID.append("\n");
						StaffID.append("<percentScore>" + mdcArr[8] + "</percentScore>");
						StaffID.append("\n");
						StaffID.append("<remarks>" + mdcArr[9] + "</remarks>");
						StaffID.append("\n");
						StaffID.append("<createdDate>" + mdcArr[10] + "</createdDate>");
						StaffID.append("\n");
						StaffID.append("<modifiedDate>" + mdcArr[11]+ "</modifiedDate>");
						StaffID.append("\n");
						StaffID.append("<schoolId>" + mdcArr[12]+ "</schoolId>");
						StaffID.append("\n");
						StaffID.append("<branchId>" + mdcArr[13]+ "</branchId>");
						StaffID.append("\n");
						StaffID.append("<isdeleted>" + mdcArr[14]+ "</isdeleted>");
						StaffID.append("\n");
						StaffID.append("</staffeducation>");
						StaffID.append("\n");
					}
				   }
				rdTx.commit();
				StaffID.append("</staffeducation>");
				StaffID.append("\n");

				xmlString=StaffID.toString();
			
		}	
		catch(Exception localException)
		{
			localException.printStackTrace();
			System.out.println(localException);

			StaffID.append("<Response>");
			StaffID.append("\n");
			StaffID.append("<Result>");
			StaffID.append("\n");
			StaffID.append("Fail");
			StaffID.append("\n");
			StaffID.append("</Result>");
			StaffID.append("\n");
			StaffID.append("<Description>");
			StaffID.append("could not get all staff education info");
			StaffID.append("</Description>");
			StaffID.append("\n");
			StaffID.append("<Exception>");
			StaffID.append(localException);
			StaffID.append("</Exception>");
			StaffID.append("</Response>");

			xmlString = StaffID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		}
		finally
		{
			rdSession.close();
		}	
		return xmlString;

	}

	

}
