package com.gwebitsol.core.staff;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.stereotype.Service;

import com.gwebitsol.core.security.MDValidation;
import com.gwebitsol.core.security.MDVerifyConnectionID;
import com.gwebitsol.core.security.MDVerifyDatastoreName;
import com.gwebitsol.core.usermanagement.MDGetUserFromID;
import com.gwebitsol.core.util.MDTransactionWriter;

@Service
public class StaffEducationService implements StaffEducationServiceIntf {

	@Context
	private HttpServletRequest hsr;

	public Response addStaffEducation(StaffEducationPojo sep, int userid, int connectionid, String datastoreName,int schoolid,int branchId) {

		MDTransactionWriter.accesslog.info("Request from:" + hsr.getRemoteHost());

		String status = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();

		sep.setBranchId(branchId);
		sep.setSchoolId(schoolid);
		
		try {

			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName,schoolid, branchId);
			System.out.println("verifiedvalue::"+ret);
			if (ret == 1) // && rtVal==1)
			{

				StaffEducationDao ad = new StaffEducationDao();
				status = ad.addStaffEducation(sep);
				System.out.println(status);
				Long el = System.currentTimeMillis();
				String endDate = dateFormat.format(new Date());
				// status= "user validation is successfull";
				MDTransactionWriter.writeLog("SCHOOL", "MMS", "srinu", startDate, endDate, sl, el, status,
						hsr.getRemoteHost());
			} else {
				status = "you are not authorised user";
			}
		} catch (Exception localException) {

			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status = "failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response updateStaffEducation(StaffEducationPojo sep, int userid, int connectionid, String datastoreName, int schoolid,int branchId) {
		MDTransactionWriter.accesslog.info("Request from:" + hsr.getRemoteHost());

		String status = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();

		sep.setBranchId(branchId);
		sep.setSchoolId(schoolid);
		
		try {

			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName, schoolid, branchId);
			System.out.println("verifiedvalue::"+ret);

			if (ret == 1) // && rtVal==1)
			{
				StaffEducationDao ad = new StaffEducationDao();
				status = ad.updateStaffEducation(sep,schoolid, branchId);
				System.out.println(status);
				Long el = System.currentTimeMillis();
				String endDate = dateFormat.format(new Date());
				// status= "user validation is successfull";
				MDTransactionWriter.writeLog("SCHOOL", "MMS", "srinu", startDate, endDate, sl, el, status,
						hsr.getRemoteHost());
			} else {
				status = "you are not authorised user";
			}
		} catch (Exception localException) {

			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status = "failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response deleteStaffEducation(int staffEdId, int userid, int connectionid, String datastoreName,int schoolid,int branchId) {

		MDTransactionWriter.accesslog.info("Request from:" + hsr.getRemoteHost());

		String status = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();
		
		StaffEducationPojo sep = new StaffEducationPojo();
		sep.setBranchId(branchId);
		sep.setSchoolId(schoolid);
		

		try {

			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName,schoolid, branchId);
			System.out.println("verifiedvalue::"+ret);
			if (ret == 1) // && rtVal==1)
			{
				StaffEducationDao ad = new StaffEducationDao();
				status = ad.deleteStaffEducation(staffEdId,schoolid, branchId);
				System.out.println(status);
				Long el = System.currentTimeMillis();
				String endDate = dateFormat.format(new Date());
				// status= "user validation is successfull";
				MDTransactionWriter.writeLog("SCHOOL", "MMS", "srinu", startDate, endDate, sl, el, status,
						hsr.getRemoteHost());
			} else {
				status = "you are not authorised user";
			}
		} catch (Exception localException) {

			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status = "failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response getStaffEducationByEmpId(int employeeid, int userid, int connectionid, String datastoreName,int schoolid,int branchId) {
		
		MDTransactionWriter.accesslog.info("Request from:" + hsr.getRemoteHost());
		String status = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();

		try {

			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName,schoolid, branchId);
			System.out.println("verifiedvalue::"+ret);
			if (ret == 1) // && rtVal==1)
			{
				StaffEducationDao ad = new StaffEducationDao();
				status = ad.getStaffEducationByEmpId(employeeid,schoolid, branchId);
				System.out.println(status);
				Long el = System.currentTimeMillis();
				String endDate = dateFormat.format(new Date());
				// status= "user validation is successfull";
				MDTransactionWriter.writeLog("SCHOOL", "MMS", "srinu", startDate, endDate, sl, el, status,
						hsr.getRemoteHost());
			} else {
				status = "you are not authorised user";
			}
		} catch (Exception localException) {

			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status = "failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response getStaffEducationByStfAndEmpId(int staffEdId, int employeeid, int userid, int connectionid,
			String datastoreName, int schoolid, int branchid) {
		
		MDTransactionWriter.accesslog.info("Request from:" + hsr.getRemoteHost());
		String status = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();

		try {

			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName,schoolid, branchid);
			System.out.println("verifiedvalue::"+ret);
			if (ret == 1) // && rtVal==1)
			{
				StaffEducationDao ad = new StaffEducationDao();
				status = ad.getStaffEducationByStfAndEmpId(staffEdId,employeeid,schoolid, branchid);
				System.out.println(status);
				Long el = System.currentTimeMillis();
				String endDate = dateFormat.format(new Date());
				// status= "user validation is successfull";
				MDTransactionWriter.writeLog("SCHOOL", "MMS", "srinu", startDate, endDate, sl, el, status,
						hsr.getRemoteHost());
			} else {
				status = "you are not authorised user";
			}
		} catch (Exception localException) {

			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status = "failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response getAllStfEdu(int userid, int connectionid, String datastoreName, int PNO, int size,int schoolid,int branchId) {
		MDTransactionWriter.accesslog.info("Request from:" + hsr.getRemoteHost());

		String status = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();

		try {

			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName,schoolid, branchId);
			System.out.println("verifiedvalue::"+ret);
			if (ret == 1) // && rtVal==1)
			{
				StaffEducationDao ad = new StaffEducationDao();
				status = ad.getAllStfEdu(PNO, size,schoolid, branchId);
						
				System.out.println(status);
				Long el = System.currentTimeMillis();
				String endDate = dateFormat.format(new Date());
				// status= "user validation is successfull";
				MDTransactionWriter.writeLog("SCHOOL", "MMS", "srinu", startDate, endDate, sl, el, status,
						hsr.getRemoteHost());
			} else {
				status = "you are not authorised user";
			}
		} catch (Exception localException) {

			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status = "failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	

}
