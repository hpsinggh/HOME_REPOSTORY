package com.gwebitsol.core.staff;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.stereotype.Component;

@XmlRootElement(name = "StaffAccolade")
@Component

public class StaffAccoladePojo implements Serializable{

	int accoladeId;
	int employeeId;
	int accoladeTypeId;
	String accoladeTitle;
	String description;
	String awardedDate;
	String medal;
	String prize;
	String remarks;
	String duration;
	int resultId;
	String createdDate;
	int branchId;
	int schoolId;
	
	

	public int getBranchId() {
		return branchId;
	}

	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}

	public int getSchoolId() {
		return schoolId;
	}

	public void setSchoolId(int schoolId) {
		this.schoolId = schoolId;
	}

	DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	Date date = new Date();
	String modifiedDate = dateFormat.format(date);
	

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public int getAccoladeId() {
		return accoladeId;
	}

	public void setAccoladeId(int accoladeId) {
		this.accoladeId = accoladeId;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public int getAccoladeTypeId() {
		return accoladeTypeId;
	}

	public void setAccoladeTypeId(int accoladeTypeId) {
		this.accoladeTypeId = accoladeTypeId;
	}

	public String getAccoladeTitle() {
		return accoladeTitle;
	}

	public void setAccoladeTitle(String accoladeTitle) {
		this.accoladeTitle = accoladeTitle;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getAwardedDate() {
		return awardedDate;
	}

	public void setAwardedDate(String awardedDate) {
		this.awardedDate = awardedDate;
	}

	public String getMedal() {
		return medal;
	}

	public void setMedal(String medal) {
		this.medal = medal;
	}

	public String getPrize() {
		return prize;
	}

	public void setPrize(String prize) {
		this.prize = prize;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public int getResultId() {
		return resultId;
	}

	public void setResultId(int resultId) {
		this.resultId = resultId;
	}

}
