package com.gwebitsol.core.staff;

import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

@Repository
@Component
public class StaffDao
{
	StringBuffer StaffID = new StringBuffer();

	public String addStaff(StaffPojo sp) {

		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String staffreg = null;

		try {

			rdTx = rdSession.beginTransaction();

			Integer staffid = (Integer) rdSession.save(sp);
			rdTx.commit();
			StaffID.append("<Staff>");
			StaffID.append("\n");
			StaffID.append("<id>");
			StaffID.append("\n");
			StaffID.append(staffid);
			StaffID.append("</id>");
			StaffID.append("\n");
			StaffID.append("</Staff>");
			staffreg = StaffID.toString();
		} catch (Exception localException) {

			System.out.println(localException);

			StaffID.append("<Response>");
			StaffID.append("\n");
			StaffID.append("<Result>");
			StaffID.append("\n");
			StaffID.append("Fail");
			StaffID.append("\n");
			StaffID.append("</Result>");
			StaffID.append("\n");
			StaffID.append("<Description>");
			StaffID.append("could not inserted address info");
			StaffID.append("</Description>");
			StaffID.append("\n");
			StaffID.append("<Exception>");
			StaffID.append(localException);
			StaffID.append("</Exception>");
			StaffID.append("</Response>");

			staffreg = StaffID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		} finally {
			rdSession.close();
		}
		return staffreg;
	}

	public String updateStaff(StaffPojo sp,int schoolid,int branchid) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String staffreg = null;

		try {
			rdTx = rdSession.beginTransaction();
			StaffPojo mdclpojo = (StaffPojo) rdSession.get(StaffPojo.class,sp.getEmployeeId());
			if(branchid==mdclpojo.getBranchId()&&schoolid==mdclpojo.getSchoolId())
			rdSession.evict(mdclpojo);
			rdSession.update(sp);
			rdTx.commit();
			staffreg = "staff is succssfully updated";
			StaffID.append("<Staff>");
			StaffID.append("\n");
			StaffID.append(staffreg);
			StaffID.append("</Staff>");
			String str = StaffID.toString();
			return str;
		} catch (Exception localException) {

			if (rdTx != null)
				rdTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			staffreg = "fail";

		} finally {
			rdSession.close();
		}
		return staffreg;
	}

	public String deleteStaff(int employeeId,int schoolid,int branchid) {

		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String staffreg = null;

		try {
			rdTx = rdSession.beginTransaction();

			StaffPojo mdclpojo = (StaffPojo) rdSession.get(StaffPojo.class,employeeId);
			
			rdSession.evict(mdclpojo);
			
			if(branchid==mdclpojo.getBranchId()&&schoolid==mdclpojo.getSchoolId())
			{
			Query empQuery=rdSession.createSQLQuery("update gbl_sm_tbl_staff set isDeleted='y' where EmployeeId='"+employeeId+"'");
			empQuery.executeUpdate();
			rdTx.commit();
			staffreg = "staff is succssfully deleted";
			StaffID.append("<Staff>");
			StaffID.append("\n");
			StaffID.append(staffreg);
			StaffID.append("</Staff>");
			String str = StaffID.toString();
			return str;
			}
			else
			{
				staffreg = "staff is not deleted";
				StaffID.append("<Staff>");
				StaffID.append("\n");
				StaffID.append(staffreg);
				StaffID.append("</Staff>");
				String str = StaffID.toString();
				return str;
			}
		} catch (Exception localException) {

			if (rdTx != null)
				rdTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			staffreg = "fail";

		} finally {
			rdSession.close();
		}
		return staffreg;
	}

	public String getStaffById(int employeeId,int schoolid,int branchid) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String staffreg = null;
		String gsSql = null;
		try {
			rdTx = rdSession.beginTransaction();

			gsSql="select gbl_sm_tbl_staff.*, gbl_sm_tbl_bloodgroup.BloodGroupName, gbl_sm_tbl_jobtitle.Title"
							+" from gbl_sm_tbl_staff"
							+" join gbl_sm_tbl_bloodgroup on gbl_sm_tbl_staff.BloodGroupId = gbl_sm_tbl_bloodgroup.BloodGroupId"
							+" join gbl_sm_tbl_jobtitle on gbl_sm_tbl_staff.JobTitleId=gbl_sm_tbl_jobtitle.JobTitleId"
							+" where gbl_sm_tbl_staff.IsDeleted is null and EmployeeId ='"+employeeId+"' and gbl_sm_tbl_staff.SchoolId='"+schoolid+"' and gbl_sm_tbl_staff.BranchId='"+branchid+"';";
							
			Query gsQuery=rdSession.createSQLQuery(gsSql);
			List gcList=gsQuery.list();
			Iterator gsIT=gcList.iterator();
				while(gsIT.hasNext())
				{
					Object[] mdcArr=(Object[])gsIT.next();
					StaffID.append("<Staff>");
					StaffID.append("\n");
					StaffID.append("<employeeId>"+mdcArr[0]+"</employeeId>");
					StaffID.append("\n");
					StaffID.append("<bloodGroupId>" + mdcArr[1]+ "</bloodGroupId>");
					StaffID.append("\n");
					StaffID.append("<bloodGroupName>" + mdcArr[20]+ "</bloodGroupName>");
					StaffID.append("\n");
					StaffID.append("<jobTitleId>" + mdcArr[2]+ "</jobTitleId>");
					StaffID.append("\n");
					StaffID.append("<jobTitleName>" + mdcArr[21]+ "</jobTitleName>");
					StaffID.append("\n");
					StaffID.append("<userId>" + mdcArr[3] + "</userId>");
					StaffID.append("\n");
					StaffID.append("<photo>" + mdcArr[4]+ "</photo>");
					StaffID.append("\n");
					StaffID.append("<staffNumber>" + mdcArr[5] + "</staffNumber>");
					StaffID.append("\n");
					StaffID.append("<firstName>" +  mdcArr[6]+ "</firstName>");
					StaffID.append("\n");
					StaffID.append("<middleName>" + mdcArr[7] + "</middleName>");
					StaffID.append("\n");
					StaffID.append("<lastName>" + mdcArr[8] + "</lastName>");
					StaffID.append("\n");
					StaffID.append("<gender>" + mdcArr[9] + "</gender>");
					StaffID.append("\n");
					StaffID.append("<dOB>" + mdcArr[10] + "</dOB>");
					StaffID.append("\n");
					StaffID.append("<dOJ>" + mdcArr[11]+ "</dOJ>");
					StaffID.append("\n");
					StaffID.append("<email>" + mdcArr[12] + "</email>");
					StaffID.append("\n");
					StaffID.append("<mobileNumber>" + mdcArr[13]+ "</mobileNumber>");
					StaffID.append("\n");
					StaffID.append("<remarks>" +  mdcArr[14]+ "</remarks>");
					StaffID.append("\n");
					StaffID.append("<createdDate>" +  mdcArr[15]+ "</createdDate>");
					StaffID.append("\n");
					StaffID.append("<modifiedDate>" +  mdcArr[16] + "</modifiedDate>");
					StaffID.append("\n");
					StaffID.append("<schoolId>" +  mdcArr[17] + "</schoolId>");
					StaffID.append("\n");
					StaffID.append("<branchId>" +  mdcArr[18] + "</branchId>");
					StaffID.append("\n");
					StaffID.append("<isDeleted>" +  mdcArr[19] + "</isDeleted>");
					StaffID.append("\n");
					StaffID.append("</Staff>");
					StaffID.append("\n");

			}
			rdTx.commit();
			staffreg=StaffID.toString();
		} catch (HibernateException localException) {
			localException.printStackTrace();
			System.out.println(localException);

			StaffID.append("<Response>");
			StaffID.append("\n");
			StaffID.append("<Result>");
			StaffID.append("\n");
			StaffID.append("Fail");
			StaffID.append("\n");
			StaffID.append("</Result>");
			StaffID.append("\n");
			StaffID.append("<Description>");
			StaffID.append("could not get staff education info");
			StaffID.append("</Description>");
			StaffID.append("\n");
			StaffID.append("<Exception>");
			StaffID.append(localException);
			StaffID.append("</Exception>");
			StaffID.append("</Response>");

			staffreg = StaffID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		} finally {
			rdSession.close();
		}
		return staffreg;
	}

	
	public String getAllStaffMem(int PNO, int size,int schoolid,int branchid) {
		String xmlString=null;
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		
		try
		{
			rdTx=rdSession.beginTransaction();
			
				int fset = (PNO-1)*size;
				String gsSql ="select count(*) from gbl_sm_tbl_staff where gbl_sm_tbl_staff.IsDeleted is null and gbl_sm_tbl_staff.SchoolId='"
						+ schoolid + "' and gbl_sm_tbl_staff.BranchId='" + branchid + "';";
				Query gsQuery=rdSession.createSQLQuery(gsSql);
				Object noRecords= gsQuery.uniqueResult();
				
				int intNoRecords=0;
				   if(noRecords!=null && Integer.parseInt(noRecords.toString())!=0)
				   {
				    intNoRecords=Integer.parseInt(noRecords.toString());
				   }

			
				
				StaffID.append("<staff>");
				StaffID.append("\n");
				StaffID.append("<noRecords>"+noRecords+"</noRecords>");
				StaffID.append("\n");
				   if(intNoRecords!=0)
				   {
					if (PNO > 0 & size > 0){
					gsSql="select gbl_sm_tbl_staff.*, gbl_sm_tbl_bloodgroup.BloodGroupName, gbl_sm_tbl_jobtitle.Title"
							+" from gbl_sm_tbl_staff"
							+" join gbl_sm_tbl_bloodgroup on gbl_sm_tbl_staff.BloodGroupId = gbl_sm_tbl_bloodgroup.BloodGroupId"
							+" join gbl_sm_tbl_jobtitle on gbl_sm_tbl_staff.JobTitleId=gbl_sm_tbl_jobtitle.JobTitleId "
							+" where gbl_sm_tbl_staff.IsDeleted is null and gbl_sm_tbl_staff.SchoolId='"+schoolid+"' and gbl_sm_tbl_staff.BranchId='"+branchid+"' limit "+size+" offset "+fset+";";	
					}
					else {
						gsSql="select gbl_sm_tbl_staff.*, gbl_sm_tbl_bloodgroup.BloodGroupName, gbl_sm_tbl_jobtitle.Title"
							+" from gbl_sm_tbl_staff"
							+" join gbl_sm_tbl_bloodgroup on gbl_sm_tbl_staff.BloodGroupId = gbl_sm_tbl_bloodgroup.BloodGroupId"
							+" join gbl_sm_tbl_jobtitle on gbl_sm_tbl_staff.JobTitleId=gbl_sm_tbl_jobtitle.JobTitleId "
						    +" where gbl_sm_tbl_staff.IsDeleted is null and gbl_sm_tbl_staff.SchoolId='"+schoolid+"' and gbl_sm_tbl_staff.BranchId='"+branchid+"';";
											
					}	
				
				gsQuery=rdSession.createSQLQuery(gsSql);
				List gcList=gsQuery.list();
				Iterator gsIT=gcList.iterator();
					while(gsIT.hasNext())
					{
						Object[] mdcArr=(Object[])gsIT.next();
						StaffID.append("<Staff>");
						StaffID.append("\n");
						StaffID.append("<employeeId>"+mdcArr[0]+"</employeeId>");
						StaffID.append("\n");
						StaffID.append("<bloodGroupId>" + mdcArr[1]+ "</bloodGroupId>");
						StaffID.append("\n");
						StaffID.append("<bloodGroupName>" + mdcArr[20]+ "</bloodGroupName>");
						StaffID.append("\n");
						StaffID.append("<jobTitleId>" + mdcArr[2]+ "</jobTitleId>");
						StaffID.append("\n");
						StaffID.append("<jobTitleName>" + mdcArr[21]+ "</jobTitleName>");
						StaffID.append("\n");
						StaffID.append("<userId>" + mdcArr[3] + "</userId>");
						StaffID.append("\n");
						StaffID.append("<photo>" + mdcArr[4]+ "</photo>");
						StaffID.append("\n");
						StaffID.append("<staffNumber>" + mdcArr[5] + "</staffNumber>");
						StaffID.append("\n");
						StaffID.append("<firstName>" +  mdcArr[6]+ "</firstName>");
						StaffID.append("\n");
						StaffID.append("<middleName>" + mdcArr[7] + "</middleName>");
						StaffID.append("\n");
						StaffID.append("<lastName>" + mdcArr[8] + "</lastName>");
						StaffID.append("\n");
						StaffID.append("<gender>" + mdcArr[9] + "</gender>");
						StaffID.append("\n");
						StaffID.append("<dOB>" + mdcArr[10] + "</dOB>");
						StaffID.append("\n");
						StaffID.append("<dOJ>" + mdcArr[11]+ "</dOJ>");
						StaffID.append("\n");
						StaffID.append("<email>" + mdcArr[12] + "</email>");
						StaffID.append("\n");
						StaffID.append("<mobileNumber>" + mdcArr[13]+ "</mobileNumber>");
						StaffID.append("\n");
						StaffID.append("<remarks>" +  mdcArr[14]+ "</remarks>");
						StaffID.append("\n");
						StaffID.append("<createdDate>" +  mdcArr[15]+ "</createdDate>");
						StaffID.append("\n");
						StaffID.append("<modifiedDate>" +  mdcArr[16] + "</modifiedDate>");
						StaffID.append("\n");
						StaffID.append("<schoolId>" +  mdcArr[17] + "</schoolId>");
						StaffID.append("\n");
						StaffID.append("<branchId>" +  mdcArr[18] + "</branchId>");
						StaffID.append("\n");
						StaffID.append("<isDeleted>" +  mdcArr[19] + "</isDeleted>");
						StaffID.append("\n");
						StaffID.append("</Staff>");
						StaffID.append("\n");
					}
				   }
				rdTx.commit();
				StaffID.append("</staff>");
				StaffID.append("\n");

				xmlString=StaffID.toString();
			}
			
		catch(Exception localException)
		{
			localException.printStackTrace();
			System.out.println(localException);

			StaffID.append("<Response>");
			StaffID.append("\n");
			StaffID.append("<Result>");
			StaffID.append("\n");
			StaffID.append("Fail");
			StaffID.append("\n");
			StaffID.append("</Result>");
			StaffID.append("\n");
			StaffID.append("<Description>");
			StaffID.append("could not get staff info");
			StaffID.append("</Description>");
			StaffID.append("\n");
			StaffID.append("<Exception>");
			StaffID.append(localException);
			StaffID.append("</Exception>");
			StaffID.append("</Response>");

			xmlString = StaffID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		}
		finally
		{
			rdSession.close();
		}	
		return xmlString;
	}

	/*
	 * public String addStaffAllInfo(StaffPojo saip) {
	 * 
	 * String staffreg = null;
	 * 
	 * StaffPojo sp=null;
	 * 
	 * StaffPojo staffinfo = new StaffPojo();
	 * 
	 * try {
	 * 
	 * rdTx = rdSession.beginTransaction();
	 * 
	 * staffinfo.setStaffaccolads(saip.getStaffaccolads());
	 * staffinfo.setStaffedu(saip.getStaffedu());
	 * staffinfo.setStaffexe(saip.getStaffexe());
	 * staffinfo.setStaffsub(saip.getStaffsub());
	 * 
	 * if(sp==staffinfo.getStaffaccolads()) { sp = sp; } else if
	 * (sp==staffinfo.getStaffedu()) { staffinfo=saip; } else
	 * if(sp==staffinfo.getStaffexe()) { staffinfo=saip; } else
	 * if(sp==staffinfo.getStaffsub()) { staffinfo=saip; }
	 * 
	 * Integer staffid = (Integer) rdSession.save(staffinfo); rdTx.commit();
	 * StaffID.append("<Staff>"); StaffID.append("\n"); StaffID.append("<id>");
	 * StaffID.append("\n"); StaffID.append(staffid); StaffID.append("</id>");
	 * StaffID.append("\n"); StaffID.append("</Staff>"); staffreg=
	 * StaffID.toString(); } catch (Exception localException) {
	 * 
	 * System.out.println(localException);
	 * 
	 * StaffID.append("<Response>"); StaffID.append("\n");
	 * StaffID.append("<Result>"); StaffID.append("\n"); StaffID.append("Fail");
	 * StaffID.append("\n"); StaffID.append("</Result>"); StaffID.append("\n");
	 * StaffID.append("<Description>"); StaffID.append(
	 * "could not inserted address info"); StaffID.append("</Description>");
	 * StaffID.append("\n"); StaffID.append("<Exception>");
	 * StaffID.append(localException); StaffID.append("</Exception>");
	 * StaffID.append("</Response>");
	 * 
	 * staffreg= StaffID.toString();
	 * MDTransactionWriter.exceptionlog.info(localException); if (rdTx!=null)
	 * rdTx.rollback(); } finally { rdSession.close(); } return staffreg; }
	 */

}