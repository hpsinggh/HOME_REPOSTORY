package com.gwebitsol.core.staff;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.stereotype.Component;

@XmlRootElement(name = "StaffEducation")
@Component

public class StaffEducationPojo implements Serializable{

	int staffEdId;
	int employeeId;
	String qualification;
	String yearofPass;
	String university;
	String passedInClass;
	
	int gradeId;
	double percentScore;
	String remarks;
	int accoladeId;
    String createdDate;
    
    int branchId;
	int schoolId;
	
	
    
    public int getBranchId() {
		return branchId;
	}

	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}

	public int getSchoolId() {
		return schoolId;
	}

	public void setSchoolId(int schoolId) {
		this.schoolId = schoolId;
	}

	DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	Date date = new Date();
	String modifiedDate = dateFormat.format(date);

	
	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public int getStaffEdId() {
		return staffEdId;
	}

	public void setStaffEdId(int staffEdId) {
		this.staffEdId = staffEdId;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public String getYearofPass() {
		return yearofPass;
	}

	public void setYearofPass(String yearofPass) {
		this.yearofPass = yearofPass;
	}

	public String getUniversity() {
		return university;
	}

	public void setUniversity(String university) {
		this.university = university;
	}

	public String getPassedInClass() {
		return passedInClass;
	}

	public void setPassedInClass(String passedInClass) {
		this.passedInClass = passedInClass;
	}

	public int getGradeId() {
		return gradeId;
	}

	public void setGradeId(int gradeId) {
		this.gradeId = gradeId;
	}

	public double getPercentScore() {
		return percentScore;
	}

	public void setPercentScore(double percentScore) {
		this.percentScore = percentScore;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public int getAccoladeId() {
		return accoladeId;
	}

	public void setAccoladeId(int accoladeId) {
		this.accoladeId = accoladeId;
	}

}
