
package com.gwebitsol.core.staff;

import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.gwebitsol.core.student.StudentPojo;
import com.gwebitsol.core.student.TransferPojo;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

@Repository
@Component

public class StaffAccoladeDao {

	StringBuffer StaffID = new StringBuffer();

	public String addStaffAccolade(StaffAccoladePojo sap) {

		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String staffaccreg = null;

		try {

			rdTx = rdSession.beginTransaction();

			Integer docid = (Integer) rdSession.save(sap);

			rdTx.commit();
			StaffID.append("<StaffAccolade>");
			StaffID.append("\n");
			StaffID.append("<id>");
			StaffID.append("\n");
			StaffID.append(docid);
			StaffID.append("</id>");
			StaffID.append("\n");
			StaffID.append("</StaffAccolade>");
			staffaccreg = StaffID.toString();
		} catch (Exception localException) {
			localException.printStackTrace();
			System.out.println(localException);

			StaffID.append("<Response>");
			StaffID.append("\n");
			StaffID.append("<Result>");
			StaffID.append("\n");
			StaffID.append("Fail");
			StaffID.append("\n");
			StaffID.append("</Result>");
			StaffID.append("\n");
			StaffID.append("<Description>");
			StaffID.append("could not inserted student accolade  info");
			StaffID.append("</Description>");
			StaffID.append("\n");
			StaffID.append("<Exception>");
			StaffID.append(localException);
			StaffID.append("</Exception>");
			StaffID.append("</Response>");

			staffaccreg = StaffID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		} finally {
			rdSession.close();
		}
		return staffaccreg;
	}

	public String updateStaffAccolade(StaffAccoladePojo sap,int schoolid,int branchid) {

		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String staffaccreg = null;

		try {
			rdTx = rdSession.beginTransaction();

			StaffAccoladePojo mdclpojo = (StaffAccoladePojo) rdSession.get(StaffAccoladePojo.class,sap.getAccoladeId());
			if(branchid==mdclpojo.getBranchId()&&schoolid==mdclpojo.getSchoolId())
			rdSession.evict(mdclpojo);
			rdSession.update(sap);

			rdTx.commit();

			staffaccreg = "student accolade is succssfully updated";

			StaffID.append("<StaffAccolade>");
			StaffID.append("\n");
			StaffID.append(staffaccreg);
			StaffID.append("</StaffAccolade>");
			String str = StaffID.toString();
			return str;
		} catch (Exception localException) {
			localException.printStackTrace();
			System.out.println(localException);

			StaffID.append("<Response>");
			StaffID.append("\n");
			StaffID.append("<Result>");
			StaffID.append("\n");
			StaffID.append("Fail");
			StaffID.append("\n");
			StaffID.append("</Result>");
			StaffID.append("\n");
			StaffID.append("<Description>");
			StaffID.append("could not updated student accolade  info");
			StaffID.append("</Description>");
			StaffID.append("\n");
			StaffID.append("<Exception>");
			StaffID.append(localException);
			StaffID.append("</Exception>");
			StaffID.append("</Response>");

			staffaccreg = StaffID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();

		} finally {
			rdSession.close();
		}
		return staffaccreg;
	}

	public String deleteStaffAccolade(int accoladeId,int schoolid,int branchid) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String staffaccreg = null;

		try {
			rdTx = rdSession.beginTransaction();

			StaffAccoladePojo mdclpojo = (StaffAccoladePojo) rdSession.get(StaffAccoladePojo.class,accoladeId);
			rdSession.evict(mdclpojo);
			if(branchid==mdclpojo.getBranchId()&&schoolid==mdclpojo.getSchoolId())
			{
			Query empQuery=rdSession.createSQLQuery("update gbl_sm_tbl_staff_accolades set isDeleted='y' where AccoladeId='"+accoladeId+"'");
			empQuery.executeUpdate();
			rdTx.commit();
			staffaccreg = "student accolade is succssfully deleted";
			StaffID.append("<StaffAccolade>");
			StaffID.append("\n");
			StaffID.append(staffaccreg);
			StaffID.append("</StaffAccolade>");
			String str = StaffID.toString();
			return str;
			}
			else
			{
				staffaccreg = "staff accolade is not deleted";
				StaffID.append("<StaffAccolade>");
				StaffID.append("\n");
				StaffID.append(staffaccreg);
				StaffID.append("</StaffAccolade>");
				String str = StaffID.toString();
				return str;
			}
		} catch (Exception localException) {
			localException.printStackTrace();
			System.out.println(localException);

			StaffID.append("<Response>");
			StaffID.append("\n");
			StaffID.append("<Result>");
			StaffID.append("\n");
			StaffID.append("Fail");
			StaffID.append("\n");
			StaffID.append("</Result>");
			StaffID.append("\n");
			StaffID.append("<Description>");
			StaffID.append("could not deleted student accolade  info");
			StaffID.append("</Description>");
			StaffID.append("\n");
			StaffID.append("<Exception>");
			StaffID.append(localException);
			StaffID.append("</Exception>");
			StaffID.append("</Response>");

			staffaccreg = StaffID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		} finally {
			rdSession.close();
		}
		return staffaccreg;
	}

	public String getStaffAccoladeByAccoladeAndEmpIds(int accoladeId,int employeeid,int schoolid,int branchid) {
		
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String staffaccreg = null;
		String gsSql = null;
		try {
			rdTx = rdSession.beginTransaction();

			gsSql="select gbl_sm_tbl_staff_accolades.*, gbl_sm_tbl_staff.FirstName, gbl_sm_tbl_staff.MiddleName,"
				+" gbl_sm_tbl_staff.LastName,gbl_sm_tbl_staff.StaffNumber,gbl_sm_tbl_assessment_type.TypeName,"
				+" gbl_sm_tbl_result.ResultName"
				+" from gbl_sm_tbl_staff_accolades"
				+" join gbl_sm_tbl_staff on  gbl_sm_tbl_staff_accolades.EmployeeId = gbl_sm_tbl_staff.EmployeeId"
				+" join gbl_sm_tbl_assessment_type on gbl_sm_tbl_staff_accolades.AccoladeTypeId=gbl_sm_tbl_assessment_type.AssessmentTypeId"
				+" join gbl_sm_tbl_result on gbl_sm_tbl_staff_accolades.ResultId=gbl_sm_tbl_result.ResultId "
				+" where gbl_sm_tbl_staff_accolades.IsDeleted is null and gbl_sm_tbl_staff_accolades.AccoladeId ='"+accoladeId+"' and gbl_sm_tbl_staff_accolades.EmployeeId='"+employeeid
				+"' and gbl_sm_tbl_staff_accolades.SchoolId='"+schoolid+"' and gbl_sm_tbl_staff_accolades.BranchId='"+branchid+"';";
				
			Query gsQuery=rdSession.createSQLQuery(gsSql);
			List gcList=gsQuery.list();
			Iterator gsIT=gcList.iterator();
				while(gsIT.hasNext())
				{
					Object[] mdcArr=(Object[])gsIT.next();
					StaffID.append("<StaffAccolade>");
					StaffID.append("\n");
					StaffID.append("<accoladeId>"+mdcArr[0]+"</accoladeId>");
					StaffID.append("\n");
					StaffID.append("<employeeId>"+mdcArr[1]+"</employeeId>");
					StaffID.append("\n");
					StaffID.append("<staffFirstName>" + mdcArr[16] + "</staffFirstName>");
					StaffID.append("\n");
					StaffID.append("<staffMiddleName>" + mdcArr[17] + "</staffMiddleName>");
					StaffID.append("\n");
					StaffID.append("<staffLastName>" + mdcArr[18]+ "</staffLastName>");
					StaffID.append("\n");
					StaffID.append("<staffNumber>" + mdcArr[19] + "</staffNumber>");
					StaffID.append("\n");
					StaffID.append("<accoladeTypeId>" + mdcArr[2]+ "</accoladeTypeId>");
					StaffID.append("\n");
					StaffID.append("<accoladeTypeName>" + mdcArr[20] + "</accoladeTypeName>");
					StaffID.append("\n");
					StaffID.append("<resultId>" + mdcArr[3]+ "</resultId>");
					StaffID.append("\n");
					StaffID.append("<resultName>" + mdcArr[21]+ "</resultName>");
					StaffID.append("\n");
					StaffID.append("<accoladeTitle>" + mdcArr[4] + "</accoladeTitle>");
					StaffID.append("\n");
					StaffID.append("<awardedDate>" + mdcArr[5]+ "</awardedDate>");
					StaffID.append("\n");
					StaffID.append("<duration>" + mdcArr[6] + "</duration>");
					StaffID.append("\n");
					StaffID.append("<prize>" +  mdcArr[7]+ "</prize>");
					StaffID.append("\n");
					StaffID.append("<medal>" + mdcArr[8] + "</medal>");
					StaffID.append("\n");
					StaffID.append("<description>" + mdcArr[9] + "</description>");
					StaffID.append("\n");
					StaffID.append("<remarks>" + mdcArr[10] + "</remarks>");
					StaffID.append("\n");
					StaffID.append("<createdDate>" + mdcArr[11] + "</createdDate>");
					StaffID.append("\n");
					StaffID.append("<modifiedDate>" + mdcArr[12]+ "</modifiedDate>");
					StaffID.append("\n");
					StaffID.append("<schoolId>" + mdcArr[13]+ "</schoolId>");
					StaffID.append("\n");
					StaffID.append("<branchId>" + mdcArr[14]+ "</branchId>");
					StaffID.append("\n");
					StaffID.append("<isDeleted>" + mdcArr[15]+ "</isDeleted>");
					StaffID.append("\n");
					StaffID.append("</StaffAccolade>");
					StaffID.append("\n");
				}
			
				rdTx.commit();
			staffaccreg=StaffID.toString();
		
		} catch (HibernateException localException) {
			localException.printStackTrace();
			System.out.println(localException);

			StaffID.append("<Response>");
			StaffID.append("\n");
			StaffID.append("<Result>");
			StaffID.append("\n");
			StaffID.append("Fail");
			StaffID.append("\n");
			StaffID.append("</Result>");
			StaffID.append("\n");
			StaffID.append("<Description>");
			StaffID.append("could not get all students accolade  info");
			StaffID.append("</Description>");
			StaffID.append("\n");
			StaffID.append("<Exception>");
			StaffID.append(localException);
			StaffID.append("</Exception>");
			StaffID.append("</Response>");

			staffaccreg = StaffID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		} finally {
			rdSession.close();
		}
		return staffaccreg;
	}
	
	public String getStaffAccoladeByEmployeeId(int employeeid, int schoolid, int branchid) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String staffaccreg = null;
		String gsSql = null;
		try {
			rdTx = rdSession.beginTransaction();

			gsSql="select gbl_sm_tbl_staff_accolades.*, gbl_sm_tbl_staff.FirstName, gbl_sm_tbl_staff.MiddleName,"
				+" gbl_sm_tbl_staff.LastName,gbl_sm_tbl_staff.StaffNumber, gbl_sm_tbl_accoladetype.TypeName,"
				+" gbl_sm_tbl_result.ResultName"
				+" from gbl_sm_tbl_staff_accolades"
				+" join gbl_sm_tbl_staff on  gbl_sm_tbl_staff_accolades.EmployeeId = gbl_sm_tbl_staff.EmployeeId"
				+" join gbl_sm_tbl_accoladetype on gbl_sm_tbl_staff_accolades.AccoladeTypeId=gbl_sm_tbl_accoladetype.AccoladeTypeId"
				+" join gbl_sm_tbl_result on gbl_sm_tbl_staff_accolades.ResultId=gbl_sm_tbl_result.ResultId "
				+" where gbl_sm_tbl_staff_accolades.IsDeleted is null and gbl_sm_tbl_staff_accolades.EmployeeId ='"+employeeid+"' and gbl_sm_tbl_staff_accolades.SchoolId='"+schoolid+"' and gbl_sm_tbl_staff_accolades.BranchId='"+branchid+"';";
				
			Query gsQuery=rdSession.createSQLQuery(gsSql);
			List gcList=gsQuery.list();
			Iterator gsIT=gcList.iterator();
				while(gsIT.hasNext())
				{
					Object[] mdcArr=(Object[])gsIT.next();
					StaffID.append("<StaffAccolade>");
					StaffID.append("\n");
					StaffID.append("<accoladeId>"+mdcArr[0]+"</accoladeId>");
					StaffID.append("\n");
					StaffID.append("<employeeId>"+mdcArr[1]+"</employeeId>");
					StaffID.append("\n");
					StaffID.append("<staffFirstName>" + mdcArr[16] + "</staffFirstName>");
					StaffID.append("\n");
					StaffID.append("<staffMiddleName>" + mdcArr[17] + "</staffMiddleName>");
					StaffID.append("\n");
					StaffID.append("<staffLastName>" + mdcArr[18]+ "</staffLastName>");
					StaffID.append("\n");
					StaffID.append("<staffNumber>" + mdcArr[19] + "</staffNumber>");
					StaffID.append("\n");
					StaffID.append("<accoladeTypeId>" + mdcArr[2]+ "</accoladeTypeId>");
					StaffID.append("\n");
					StaffID.append("<accoladeTypeName>" + mdcArr[20] + "</accoladeTypeName>");
					StaffID.append("\n");
					StaffID.append("<resultId>" + mdcArr[3]+ "</resultId>");
					StaffID.append("\n");
					StaffID.append("<resultName>" + mdcArr[21]+ "</resultName>");
					StaffID.append("\n");
					StaffID.append("<accoladeTitle>" + mdcArr[4] + "</accoladeTitle>");
					StaffID.append("\n");
					StaffID.append("<awardedDate>" + mdcArr[5]+ "</awardedDate>");
					StaffID.append("\n");
					StaffID.append("<duration>" + mdcArr[6] + "</duration>");
					StaffID.append("\n");
					StaffID.append("<prize>" +  mdcArr[7]+ "</prize>");
					StaffID.append("\n");
					StaffID.append("<medal>" + mdcArr[8] + "</medal>");
					StaffID.append("\n");
					StaffID.append("<description>" + mdcArr[9] + "</description>");
					StaffID.append("\n");
					StaffID.append("<remarks>" + mdcArr[10] + "</remarks>");
					StaffID.append("\n");
					StaffID.append("<createdDate>" + mdcArr[11] + "</createdDate>");
					StaffID.append("\n");
					StaffID.append("<modifiedDate>" + mdcArr[12]+ "</modifiedDate>");
					StaffID.append("\n");
					StaffID.append("<schoolId>" + mdcArr[13]+ "</schoolId>");
					StaffID.append("\n");
					StaffID.append("<branchId>" + mdcArr[14]+ "</branchId>");
					StaffID.append("\n");
					StaffID.append("<isDeleted>" + mdcArr[15]+ "</isDeleted>");
					StaffID.append("\n");
					StaffID.append("</StaffAccolade>");
					StaffID.append("\n");
				}
				rdTx.commit();
			staffaccreg=StaffID.toString();
		
		} catch (HibernateException localException) {
			localException.printStackTrace();
			System.out.println(localException);

			StaffID.append("<Response>");
			StaffID.append("\n");
			StaffID.append("<Result>");
			StaffID.append("\n");
			StaffID.append("Fail");
			StaffID.append("\n");
			StaffID.append("</Result>");
			StaffID.append("\n");
			StaffID.append("<Description>");
			StaffID.append("could not get all students accolade  info");
			StaffID.append("</Description>");
			StaffID.append("\n");
			StaffID.append("<Exception>");
			StaffID.append(localException);
			StaffID.append("</Exception>");
			StaffID.append("</Response>");

			staffaccreg = StaffID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		} finally {
			rdSession.close();
		}
		return staffaccreg;
	}

	@SuppressWarnings("unused")
	public String getAllStafAclds(int PNO, int size,int schoolid,int branchid) {
		String xmlString=null;
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		try
		{
			rdTx=rdSession.beginTransaction();
			
				int fset = (PNO-1)*size;
				String gsSql ="select count(*) from gbl_sm_tbl_staff_accolades where gbl_sm_tbl_staff_accolades.IsDeleted is null and gbl_sm_tbl_staff_accolades.SchoolId='"
						+ schoolid + "' and gbl_sm_tbl_staff_accolades.BranchId='" + branchid + "';";
				Query gsQuery=rdSession.createSQLQuery(gsSql);
				Object noRecords= gsQuery.uniqueResult();
				
				int intNoRecords=0;
				   if(noRecords!=null && Integer.parseInt(noRecords.toString())!=0)
				   {
				    intNoRecords=Integer.parseInt(noRecords.toString());
				   }
  
				StaffID.append("<StaffAccloades>");
				StaffID.append("\n");
				StaffID.append("<noRecords>"+noRecords+"</noRecords>");
				StaffID.append("\n");
				 if(intNoRecords!=0)
				   {
					if (PNO > 0 & size > 0){
					gsSql="select gbl_sm_tbl_staff_accolades.*, gbl_sm_tbl_staff.FirstName, gbl_sm_tbl_staff.MiddleName,"
				+" gbl_sm_tbl_staff.LastName,gbl_sm_tbl_staff.StaffNumber,gbl_sm_tbl_assessment_type.TypeName,"
				+" gbl_sm_tbl_result.ResultName"
				+" from gbl_sm_tbl_staff_accolades"
				+" join gbl_sm_tbl_staff on gbl_sm_tbl_staff_accolades.EmployeeId = gbl_sm_tbl_staff.EmployeeId"
				+" join gbl_sm_tbl_assessment_type on gbl_sm_tbl_staff_accolades.AccoladeTypeId=gbl_sm_tbl_assessment_type.AssessmentTypeId"
				+" join gbl_sm_tbl_result on gbl_sm_tbl_staff_accolades.ResultId=gbl_sm_tbl_result.ResultId "
				+" where gbl_sm_tbl_staff_accolades.IsDeleted is null and gbl_sm_tbl_staff_accolades.SchoolId='"+schoolid+"' and gbl_sm_tbl_staff_accolades.BranchId='"+branchid+"' limit "+size+" offset "+fset+";";}
					
					else {
						gsSql="select gbl_sm_tbl_staff_accolades.*, gbl_sm_tbl_staff.FirstName, gbl_sm_tbl_staff.MiddleName,"
				+" gbl_sm_tbl_staff.LastName,gbl_sm_tbl_staff.StaffNumber,gbl_sm_tbl_assessment_type.TypeName,"
				+" gbl_sm_tbl_result.ResultName"
				+" from gbl_sm_tbl_staff_accolades"
				+" join gbl_sm_tbl_staff on gbl_sm_tbl_staff_accolades.EmployeeId = gbl_sm_tbl_staff.EmployeeId"
				+" join gbl_sm_tbl_assessment_type on gbl_sm_tbl_staff_accolades.AccoladeTypeId=gbl_sm_tbl_assessment_type.AssessmentTypeId"
				+" join gbl_sm_tbl_result on gbl_sm_tbl_staff_accolades.ResultId=gbl_sm_tbl_result.ResultId"
				+" where gbl_sm_tbl_staff_accolades.IsDeleted is null and gbl_sm_tbl_staff_accolades.SchoolId='"+schoolid+"' and gbl_sm_tbl_staff_accolades.BranchId='"+branchid+"';";
				
			}	
				
				gsQuery=rdSession.createSQLQuery(gsSql);
				List gcList=gsQuery.list();
				Iterator gsIT=gcList.iterator();
					while(gsIT.hasNext())
					{
						Object[] mdcArr=(Object[])gsIT.next();
						StaffID.append("<StaffAccolade>");
						StaffID.append("\n");
						StaffID.append("<accoladeId>"+mdcArr[0]+"</accoladeId>");
						StaffID.append("\n");
						StaffID.append("<employeeId>"+mdcArr[1]+"</employeeId>");
						StaffID.append("\n");
						StaffID.append("<staffFirstName>" + mdcArr[16] + "</staffFirstName>");
						StaffID.append("\n");
						StaffID.append("<staffMiddleName>" + mdcArr[17] + "</staffMiddleName>");
						StaffID.append("\n");
						StaffID.append("<staffLastName>" + mdcArr[18]+ "</staffLastName>");
						StaffID.append("\n");
						StaffID.append("<staffNumber>" + mdcArr[19] + "</staffNumber>");
						StaffID.append("\n");
						StaffID.append("<accoladeTypeId>" + mdcArr[2]+ "</accoladeTypeId>");
						StaffID.append("\n");
						StaffID.append("<accoladeTypeName>" + mdcArr[20] + "</accoladeTypeName>");
						StaffID.append("\n");
						StaffID.append("<resultId>" + mdcArr[3]+ "</resultId>");
						StaffID.append("\n");
						StaffID.append("<resultName>" + mdcArr[21]+ "</resultName>");
						StaffID.append("\n");
						StaffID.append("<accoladeTitle>" + mdcArr[4] + "</accoladeTitle>");
						StaffID.append("\n");
						StaffID.append("<awardedDate>" + mdcArr[5]+ "</awardedDate>");
						StaffID.append("\n");
						StaffID.append("<duration>" + mdcArr[6] + "</duration>");
						StaffID.append("\n");
						StaffID.append("<prize>" +  mdcArr[7]+ "</prize>");
						StaffID.append("\n");
						StaffID.append("<medal>" + mdcArr[8] + "</medal>");
						StaffID.append("\n");
						StaffID.append("<description>" + mdcArr[9] + "</description>");
						StaffID.append("\n");
						StaffID.append("<remarks>" + mdcArr[10] + "</remarks>");
						StaffID.append("\n");
						StaffID.append("<createdDate>" + mdcArr[11] + "</createdDate>");
						StaffID.append("\n");
						StaffID.append("<modifiedDate>" + mdcArr[12]+ "</modifiedDate>");
						StaffID.append("\n");
						StaffID.append("<schoolId>" + mdcArr[13]+ "</schoolId>");
						StaffID.append("\n");
						StaffID.append("<branchId>" + mdcArr[14]+ "</branchId>");
						StaffID.append("\n");
						StaffID.append("<isDeleted>" + mdcArr[15]+ "</isDeleted>");
						StaffID.append("\n");
						StaffID.append("</StaffAccolade>");
						StaffID.append("\n");
					}
				   }
					rdTx.commit();
				StaffID.append("</StaffAccloades>");
				StaffID.append("\n");
				xmlString=StaffID.toString();
			
		}	
		catch(Exception localException)
		{
			localException.printStackTrace();
			System.out.println(localException);

			StaffID.append("<Response>");
			StaffID.append("\n");
			StaffID.append("<Result>");
			StaffID.append("\n");
			StaffID.append("Fail");
			StaffID.append("\n");
			StaffID.append("</Result>");
			StaffID.append("\n");
			StaffID.append("<Description>");
			StaffID.append("could not get all students accolade  info");
			StaffID.append("</Description>");
			StaffID.append("\n");
			StaffID.append("<Exception>");
			StaffID.append(localException);
			StaffID.append("</Exception>");
			StaffID.append("</Response>");

			xmlString = StaffID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		}
		finally
		{
			rdSession.close();
		}	
		return xmlString;

	}

	

}
