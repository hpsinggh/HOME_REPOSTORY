package com.gwebitsol.core.staff;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.stereotype.Component;

@XmlRootElement(name = "StaffExperience")
@Component
public class StaffExperiencePojo implements Serializable {

	int staffExpId;
	int employeeId;
	String previousInstitution;
	String workedFrom;
	String workedTo;
	int jobTitleId;
	String createdDate;
	String remarks;
	String jobRole;

	int branchId;
	int schoolId;
	
	
	public int getBranchId() {
		return branchId;
	}

	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}

	public int getSchoolId() {
		return schoolId;
	}

	public void setSchoolId(int schoolId) {
		this.schoolId = schoolId;
	}

	DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	Date date = new Date();
	String modifiedDate = dateFormat.format(date);

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public int getStaffExpId() {
		return staffExpId;
	}

	public void setStaffExpId(int staffExpId) {
		this.staffExpId = staffExpId;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getPreviousInstitution() {
		return previousInstitution;
	}

	public void setPreviousInstitution(String previousInstitution) {
		this.previousInstitution = previousInstitution;
	}

	public String getWorkedFrom() {
		return workedFrom;
	}

	public void setWorkedFrom(String workedFrom) {
		this.workedFrom = workedFrom;
	}

	public String getWorkedTo() {
		return workedTo;
	}

	public void setWorkedTo(String workedTo) {
		this.workedTo = workedTo;
	}

	public int getJobTitleId() {
		return jobTitleId;
	}

	public void setJobTitleId(int jobTitleId) {
		this.jobTitleId = jobTitleId;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getJobRole() {
		return jobRole;
	}

	public void setJobRole(String jobRole) {
		this.jobRole = jobRole;
	}

}
