package com.gwebitsol.core.staff;

import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

@Repository
@Component
public class StaffSubjectsDao {

	StringBuffer StaffID = new StringBuffer();

	public String addStaffSubjects(StaffSubjectsPojo ssp) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String staffsubreg = null;

		try {
			rdTx = rdSession.beginTransaction();

			Integer staffsubid = (Integer) rdSession.save(ssp);
			rdTx.commit();
			StaffID.append("<StaffSubjects>");
			StaffID.append("\n");
			StaffID.append("<id>");
			StaffID.append("\n");
			StaffID.append(staffsubid);
			StaffID.append("</id>");
			StaffID.append("\n");
			StaffID.append("</StaffSubjects>");
			staffsubreg = StaffID.toString();
		} catch (Exception localException) {
			localException.printStackTrace();
			System.out.println(localException);

			StaffID.append("<Response>");
			StaffID.append("\n");
			StaffID.append("<Result>");
			StaffID.append("\n");
			StaffID.append("Fail");
			StaffID.append("\n");
			StaffID.append("</Result>");
			StaffID.append("\n");
			StaffID.append("<Description>");
			StaffID.append("could not inserted staffsubjects info");
			StaffID.append("</Description>");
			StaffID.append("\n");
			StaffID.append("<Exception>");
			StaffID.append(localException);
			StaffID.append("</Exception>");
			StaffID.append("</Response>");

			staffsubreg = StaffID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		} finally {
			rdSession.close();
		}
		return staffsubreg;
	}

	public String updateStaffSubjects(StaffSubjectsPojo sep, int schoolid, int branchid) {

		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String staffsub = null;

		try {
			rdTx = rdSession.beginTransaction();

			StaffSubjectsPojo mdclpojo = (StaffSubjectsPojo) rdSession.get(StaffSubjectsPojo.class,
					sep.getStaffSubId());
			if (branchid == mdclpojo.getBranchId() && schoolid == mdclpojo.getSchoolId())
				rdSession.evict(mdclpojo);

			rdSession.update(sep);

			rdTx.commit();

			staffsub = "staffsubjects is succssfully updated";

			StaffID.append("<StaffSubjects>");
			StaffID.append("\n");
			StaffID.append(staffsub);
			StaffID.append("</StaffSubjects>");

			String str = StaffID.toString();
			return str;
		} catch (Exception localException) {
			localException.printStackTrace();
			System.out.println(localException);

			StaffID.append("<Response>");
			StaffID.append("\n");
			StaffID.append("<Result>");
			StaffID.append("\n");
			StaffID.append("Fail");
			StaffID.append("\n");
			StaffID.append("</Result>");
			StaffID.append("\n");
			StaffID.append("<Description>");
			StaffID.append("could not updated staffsubjects info");
			StaffID.append("</Description>");
			StaffID.append("\n");
			StaffID.append("<Exception>");
			StaffID.append(localException);
			StaffID.append("</Exception>");
			StaffID.append("</Response>");

			staffsub = StaffID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();

		} finally {
			rdSession.close();
		}
		return staffsub;
	}

	public String deleteStaffSubjects(int staffSubId, int schoolid, int branchid) {

		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String staffsub = null;

		try {
			rdTx = rdSession.beginTransaction();

			StaffSubjectsPojo mdclpojo = (StaffSubjectsPojo) rdSession.get(StaffSubjectsPojo.class, staffSubId);

			rdSession.evict(mdclpojo);

			if (branchid == mdclpojo.getBranchId() && schoolid == mdclpojo.getSchoolId()) {
				Query empQuery = rdSession.createSQLQuery(
						"update gbl_sm_tbl_staff_subjects set isDeleted='y' where StaffSubId='" + staffSubId + "'");
				empQuery.executeUpdate();

				rdTx.commit();
				staffsub = "staffsubject is succssfully deleted";
				StaffID.append("<StaffSubjects>");
				StaffID.append("\n");
				StaffID.append(staffsub);
				StaffID.append("</StaffSubjects>");
				String str = StaffID.toString();
				return str;
			} else {
				staffsub = "staff subjects is not deleted";
				StaffID.append("<StaffSubject>");
				StaffID.append("\n");
				StaffID.append(staffsub);
				StaffID.append("</StaffSubject>");
				String str = StaffID.toString();
				return str;
			}
		} catch (Exception localException) {
			localException.printStackTrace();
			System.out.println(localException);

			StaffID.append("<Response>");
			StaffID.append("\n");
			StaffID.append("<Result>");
			StaffID.append("\n");
			StaffID.append("Fail");
			StaffID.append("\n");
			StaffID.append("</Result>");
			StaffID.append("\n");
			StaffID.append("<Description>");
			StaffID.append("could not deleted staffsubjects info");
			StaffID.append("</Description>");
			StaffID.append("\n");
			StaffID.append("<Exception>");
			StaffID.append(localException);
			StaffID.append("</Exception>");
			StaffID.append("</Response>");

			staffsub = StaffID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		} finally {
			rdSession.close();
		}
		return staffsub;
	}

	public String getStaffSubjectsByEmpId(int employeeid, int schoolid, int branchid) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String staffsub = null;
		String gsSql = null;
		try {
			rdTx = rdSession.beginTransaction();

			gsSql = "select gbl_sm_tbl_staff_subjects.*, gbl_sm_tbl_staff.FirstName, gbl_sm_tbl_staff.MiddleName,"
					+ " gbl_sm_tbl_staff.LastName,gbl_sm_tbl_staff.StaffNumber,gbl_sm_tbl_subject_type.SubjectName,gbl_sm_tbl_class.ClassName"
					+ " from gbl_sm_tbl_staff_subjects"
					+ " join gbl_sm_tbl_staff on gbl_sm_tbl_staff_subjects.EmployeeId = gbl_sm_tbl_staff.EmployeeId"
					+ " join gbl_sm_tbl_subject_type on gbl_sm_tbl_staff_subjects.SubjectId=gbl_sm_tbl_subject_type.SubjectTypeId"
					+ " join gbl_sm_tbl_class on gbl_sm_tbl_staff_subjects.ClassIdTaught= gbl_sm_tbl_class.ClassId "
					+ " where gbl_sm_tbl_staff_subjects.IsDeleted is null and gbl_sm_tbl_staff_subjects.EmployeeId ='"
					+ employeeid + "' and gbl_sm_tbl_staff_subjects.SchoolId='" + schoolid
					+ "' and gbl_sm_tbl_staff_subjects.BranchId='" + branchid + "';";

			Query gsQuery = rdSession.createSQLQuery(gsSql);
			List gcList = gsQuery.list();
			Iterator gsIT = gcList.iterator();
			while (gsIT.hasNext()) {
				Object[] mdcArr = (Object[]) gsIT.next();
				StaffID.append("<StaffSubject>");
				StaffID.append("\n");
				StaffID.append("<staffSubId>" + mdcArr[0] + "</staffSubId>");
				StaffID.append("\n");
				StaffID.append("<employeeId>" + mdcArr[1] + "</employeeId>");
				StaffID.append("\n");
				StaffID.append("<staffFirstName>" + mdcArr[12] + "</staffFirstName>");
				StaffID.append("\n");
				StaffID.append("<staffMiddleName>" + mdcArr[13] + "</staffMiddleName>");
				StaffID.append("\n");
				StaffID.append("<staffLastName>" + mdcArr[14] + "</staffLastName>");
				StaffID.append("\n");
				StaffID.append("<staffNumber>" + mdcArr[15] + "</staffNumber>");
				StaffID.append("\n");
				StaffID.append("<subjectId>" + mdcArr[2] + "</subjectId>");
				StaffID.append("\n");
				StaffID.append("<subjectName>" + mdcArr[16] + "</subjectName>");
				StaffID.append("\n");
				StaffID.append("<classIdTaught>" + mdcArr[3] + "</classIdTaught>");
				StaffID.append("\n");
				StaffID.append("<className>" + mdcArr[17] + "</className>");
				StaffID.append("\n");
				StaffID.append("<lastUsed>" + mdcArr[4] + "</lastUsed>");
				StaffID.append("\n");
				StaffID.append("<monthsTaught>" + mdcArr[5] + "</monthsTaught>");
				StaffID.append("\n");
				StaffID.append("<description>" + mdcArr[6] + "</description>");
				StaffID.append("\n");
				StaffID.append("<createdDate>" + mdcArr[7] + "</createdDate>");
				StaffID.append("\n");
				StaffID.append("<modifiedDate>" + mdcArr[8] + "</modifiedDate>");
				StaffID.append("\n");
				StaffID.append("<schoolId>" + mdcArr[9] + "</schoolId>");
				StaffID.append("\n");
				StaffID.append("<branchId>" + mdcArr[10] + "</branchId>");
				StaffID.append("\n");
				StaffID.append("<isDeleted>" + mdcArr[11] + "</isDeleted>");
				StaffID.append("\n");
				StaffID.append("</StaffSubject>");
				StaffID.append("\n");
			}
			rdTx.commit();
			staffsub = StaffID.toString();

		} catch (HibernateException localException) {
			localException.printStackTrace();
			System.out.println(localException);

			StaffID.append("<Response>");
			StaffID.append("\n");
			StaffID.append("<Result>");
			StaffID.append("\n");
			StaffID.append("Fail");
			StaffID.append("\n");
			StaffID.append("</Result>");
			StaffID.append("\n");
			StaffID.append("<Description>");
			StaffID.append("could not get staffsubjects info");
			StaffID.append("</Description>");
			StaffID.append("\n");
			StaffID.append("<Exception>");
			StaffID.append(localException);
			StaffID.append("</Exception>");
			StaffID.append("</Response>");

			staffsub = StaffID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		} finally {
			rdSession.close();
		}
		return staffsub;
	}

	public String getStaffSubjectsByStfSubAndEmpId(int staffSubId, int employeeid, int schoolid, int branchid) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String staffsub = null;
		String gsSql = null;
		try {
			rdTx = rdSession.beginTransaction();

			gsSql = "select gbl_sm_tbl_staff_subjects.*, gbl_sm_tbl_staff.FirstName, gbl_sm_tbl_staff.MiddleName,"
					+ " gbl_sm_tbl_staff.LastName,gbl_sm_tbl_staff.StaffNumber,gbl_sm_tbl_subject_type.SubjectName,gbl_sm_tbl_class.ClassName"
					+ " from gbl_sm_tbl_staff_subjects"
					+ " join gbl_sm_tbl_staff on gbl_sm_tbl_staff_subjects.EmployeeId = gbl_sm_tbl_staff.EmployeeId"
					+ " join gbl_sm_tbl_subject_type on gbl_sm_tbl_staff_subjects.SubjectId=gbl_sm_tbl_subject_type.SubjectTypeId"
					+ " join gbl_sm_tbl_class on gbl_sm_tbl_staff_subjects.ClassIdTaught= gbl_sm_tbl_class.ClassId "
					+ " where gbl_sm_tbl_staff_subjects.IsDeleted is null and gbl_sm_tbl_staff_subjects.StaffSubId='"
					+ staffSubId + "' and gbl_sm_tbl_staff_subjects.EmployeeId ='" + employeeid
					+ "' and gbl_sm_tbl_staff_subjects.SchoolId='" + schoolid
					+ "' and gbl_sm_tbl_staff_subjects.BranchId='" + branchid + "';";

			Query gsQuery = rdSession.createSQLQuery(gsSql);
			List gcList = gsQuery.list();
			Iterator gsIT = gcList.iterator();
			while (gsIT.hasNext()) {
				Object[] mdcArr = (Object[]) gsIT.next();
				StaffID.append("<StaffSubject>");
				StaffID.append("\n");
				StaffID.append("<staffSubId>" + mdcArr[0] + "</staffSubId>");
				StaffID.append("\n");
				StaffID.append("<employeeId>" + mdcArr[1] + "</employeeId>");
				StaffID.append("\n");
				StaffID.append("<staffFirstName>" + mdcArr[12] + "</staffFirstName>");
				StaffID.append("\n");
				StaffID.append("<staffMiddleName>" + mdcArr[13] + "</staffMiddleName>");
				StaffID.append("\n");
				StaffID.append("<staffLastName>" + mdcArr[14] + "</staffLastName>");
				StaffID.append("\n");
				StaffID.append("<staffNumber>" + mdcArr[15] + "</staffNumber>");
				StaffID.append("\n");
				StaffID.append("<subjectId>" + mdcArr[2] + "</subjectId>");
				StaffID.append("\n");
				StaffID.append("<subjectName>" + mdcArr[16] + "</subjectName>");
				StaffID.append("\n");
				StaffID.append("<classIdTaught>" + mdcArr[3] + "</classIdTaught>");
				StaffID.append("\n");
				StaffID.append("<className>" + mdcArr[17] + "</className>");
				StaffID.append("\n");
				StaffID.append("<lastUsed>" + mdcArr[4] + "</lastUsed>");
				StaffID.append("\n");
				StaffID.append("<monthsTaught>" + mdcArr[5] + "</monthsTaught>");
				StaffID.append("\n");
				StaffID.append("<description>" + mdcArr[6] + "</description>");
				StaffID.append("\n");
				StaffID.append("<createdDate>" + mdcArr[7] + "</createdDate>");
				StaffID.append("\n");
				StaffID.append("<modifiedDate>" + mdcArr[8] + "</modifiedDate>");
				StaffID.append("\n");
				StaffID.append("<schoolId>" + mdcArr[9] + "</schoolId>");
				StaffID.append("\n");
				StaffID.append("<branchId>" + mdcArr[10] + "</branchId>");
				StaffID.append("\n");
				StaffID.append("<isDeleted>" + mdcArr[11] + "</isDeleted>");
				StaffID.append("\n");
				StaffID.append("</StaffSubject>");
				StaffID.append("\n");
			}
			rdTx.commit();
			staffsub = StaffID.toString();

		} catch (HibernateException localException) {
			localException.printStackTrace();
			System.out.println(localException);

			StaffID.append("<Response>");
			StaffID.append("\n");
			StaffID.append("<Result>");
			StaffID.append("\n");
			StaffID.append("Fail");
			StaffID.append("\n");
			StaffID.append("</Result>");
			StaffID.append("\n");
			StaffID.append("<Description>");
			StaffID.append("could not get staffsubjects info");
			StaffID.append("</Description>");
			StaffID.append("\n");
			StaffID.append("<Exception>");
			StaffID.append(localException);
			StaffID.append("</Exception>");
			StaffID.append("</Response>");

			staffsub = StaffID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		} finally {
			rdSession.close();
		}
		return staffsub;
	}

	public String getAllStaffSubjects() {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String staffsub = null;

		StaffSubjectsPojo ap = null;
		try {
			rdTx = rdSession.beginTransaction();

			// List<ParentPojo> parents = rdSession.createSQLQuery("select *
			// from parent_personal_info").list();

			List<StaffSubjectsPojo> list = rdSession.createCriteria(StaffSubjectsPojo.class).list();

			StaffID.append("<StaffSubjects>");
			for (Iterator<StaffSubjectsPojo> iterator = list.iterator(); iterator.hasNext();) {
				ap = (StaffSubjectsPojo) iterator.next();

				if (ap == null) {
					System.out.println("there is no staffsubjects object");
				} else {
					StaffID.append("\n");
					StaffID.append("<ClassIdTaught>" + ap.getClassIdTaught() + "</ClassIdTaught>");
					StaffID.append("\n");
					StaffID.append("<CreatedDate>" + ap.getCreatedDate() + "</CreatedDate>");
					StaffID.append("\n");
					StaffID.append("<Description>" + ap.getDescription() + "</Description>");
					StaffID.append("\n");
					StaffID.append("<EmployeeId>" + ap.getEmployeeId() + "</EmployeeId>");
					StaffID.append("\n");
					StaffID.append("<IsDeleted>" + ap.getIsDeleted() + "</IsDeleted>");
					StaffID.append("\n");
					StaffID.append("<LastUsed>" + ap.getLastUsed() + "</LastUsed>");
					StaffID.append("\n");
					StaffID.append("<ModifiedDate>" + ap.getModifiedDate() + "</ModifiedDate>");
					StaffID.append("\n");

					StaffID.append("<StaffSubId>" + ap.getStaffSubId() + "</StaffSubId>");
					StaffID.append("\n");
					StaffID.append("<SubjectId>" + ap.getSubjectId() + "</SubjectId>");
					StaffID.append("\n");
				}
			}
			StaffID.append("</StaffSubjects>");
			String str = StaffID.toString();
			rdTx.commit();
			return str;
		} catch (HibernateException localException) {
			localException.printStackTrace();
			System.out.println(localException);

			StaffID.append("<Response>");
			StaffID.append("\n");
			StaffID.append("<Result>");
			StaffID.append("\n");
			StaffID.append("Fail");
			StaffID.append("\n");
			StaffID.append("</Result>");
			StaffID.append("\n");
			StaffID.append("<Description>");
			StaffID.append("could not get all staffsubjects info");
			StaffID.append("</Description>");
			StaffID.append("\n");
			StaffID.append("<Exception>");
			StaffID.append(localException);
			StaffID.append("</Exception>");
			StaffID.append("</Response>");

			staffsub = StaffID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		} finally {
			rdSession.close();
		}

		return staffsub;
	}

	public String getAllStaffSubs(int PNO, int size, int schoolid, int branchid) {

		String xmlString = null;
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		StringBuffer sb = new StringBuffer();
		try {
			rdTx = rdSession.beginTransaction();

			int fset = (PNO - 1) * size;
			String gsSql = "select count(*) from gbl_sm_tbl_staff_subjects where gbl_sm_tbl_staff_subjects.IsDeleted is null and gbl_sm_tbl_staff_subjects.SchoolId='"
					+ schoolid + "' and gbl_sm_tbl_staff_subjects.BranchId='" + branchid + "';";
			Query gsQuery = rdSession.createSQLQuery(gsSql);
			Object noRecords = gsQuery.uniqueResult();

			int intNoRecords = 0;
			if (noRecords != null && Integer.parseInt(noRecords.toString()) != 0) {
				intNoRecords = Integer.parseInt(noRecords.toString());
			}

			StaffID.append("<StaffSubjects>");
			StaffID.append("\n");
			StaffID.append("<noRecords>" + noRecords + "</noRecords>");
			StaffID.append("\n");

			if (intNoRecords != 0) {
				if (PNO > 0 & size > 0) {
					gsSql = "select gbl_sm_tbl_staff_subjects.*, gbl_sm_tbl_staff.FirstName, gbl_sm_tbl_staff.MiddleName,"
							+ " gbl_sm_tbl_staff.LastName,gbl_sm_tbl_staff.StaffNumber,gbl_sm_tbl_subject_type.SubjectName,gbl_sm_tbl_class.ClassName"
							+ " from gbl_sm_tbl_staff_subjects"
							+ " join gbl_sm_tbl_staff on gbl_sm_tbl_staff_subjects.EmployeeId = gbl_sm_tbl_staff.EmployeeId"
							+ " join gbl_sm_tbl_subject_type on gbl_sm_tbl_staff_subjects.SubjectId=gbl_sm_tbl_subject_type.SubjectTypeId"
							+ " join gbl_sm_tbl_class on gbl_sm_tbl_staff_subjects.ClassIdTaught= gbl_sm_tbl_class.ClassId"
							+ " where gbl_sm_tbl_staff_subjects.IsDeleted is null and gbl_sm_tbl_staff_subjects.SchoolId='"
							+ schoolid + "' and gbl_sm_tbl_staff_subjects.BranchId='" + branchid + "' limit" + size
							+ " offset" + fset + ";";
				}

				else {
					gsSql = "select gbl_sm_tbl_staff_subjects.*, gbl_sm_tbl_staff.FirstName, gbl_sm_tbl_staff.MiddleName,"
							+ " gbl_sm_tbl_staff.LastName, gbl_sm_tbl_staff.StaffNumber,gbl_sm_tbl_subject_type.SubjectName, gbl_sm_tbl_class.ClassName"
							+ " from gbl_sm_tbl_staff_subjects"
							+ " join gbl_sm_tbl_staff on gbl_sm_tbl_staff_subjects.EmployeeId = gbl_sm_tbl_staff.EmployeeId"
							+ " join gbl_sm_tbl_subject_type on gbl_sm_tbl_staff_subjects.SubjectId=gbl_sm_tbl_subject_type.SubjectTypeId"
							+ " join gbl_sm_tbl_class on gbl_sm_tbl_staff_subjects.ClassIdTaught= gbl_sm_tbl_class.ClassId"
							+ " where gbl_sm_tbl_staff_subjects.IsDeleted is null and gbl_sm_tbl_staff_subjects.SchoolId='"
							+ schoolid + "' and gbl_sm_tbl_staff_subjects.BranchId='" + branchid + "';";

				}

				gsQuery = rdSession.createSQLQuery(gsSql);
				List gcList = gsQuery.list();
				Iterator gsIT = gcList.iterator();
				while (gsIT.hasNext()) {
					Object[] mdcArr = (Object[]) gsIT.next();
					StaffID.append("<StaffSubject>");
					StaffID.append("\n");
					StaffID.append("<staffSubId>" + mdcArr[0] + "</staffSubId>");
					StaffID.append("\n");
					StaffID.append("<employeeId>" + mdcArr[1] + "</employeeId>");
					StaffID.append("\n");
					StaffID.append("<staffFirstName>" + mdcArr[12] + "</staffFirstName>");
					StaffID.append("\n");
					StaffID.append("<staffMiddleName>" + mdcArr[13] + "</staffMiddleName>");
					StaffID.append("\n");
					StaffID.append("<staffLastName>" + mdcArr[14] + "</staffLastName>");
					StaffID.append("\n");
					StaffID.append("<staffNumber>" + mdcArr[15] + "</staffNumber>");
					StaffID.append("\n");
					StaffID.append("<subjectId>" + mdcArr[2] + "</subjectId>");
					StaffID.append("\n");
					StaffID.append("<subjectName>" + mdcArr[16] + "</subjectName>");
					StaffID.append("\n");
					StaffID.append("<classIdTaught>" + mdcArr[3] + "</classIdTaught>");
					StaffID.append("\n");
					StaffID.append("<className>" + mdcArr[17] + "</className>");
					StaffID.append("\n");
					StaffID.append("<lastUsed>" + mdcArr[4] + "</lastUsed>");
					StaffID.append("\n");
					StaffID.append("<monthsTaught>" + mdcArr[5] + "</monthsTaught>");
					StaffID.append("\n");
					StaffID.append("<description>" + mdcArr[6] + "</description>");
					StaffID.append("\n");
					StaffID.append("<createdDate>" + mdcArr[7] + "</createdDate>");
					StaffID.append("\n");
					StaffID.append("<modifiedDate>" + mdcArr[8] + "</modifiedDate>");
					StaffID.append("\n");
					StaffID.append("<schoolId>" + mdcArr[9] + "</schoolId>");
					StaffID.append("\n");
					StaffID.append("<branchId>" + mdcArr[10] + "</branchId>");
					StaffID.append("\n");
					StaffID.append("<isDeleted>" + mdcArr[11] + "</isDeleted>");
					StaffID.append("\n");
					StaffID.append("</StaffSubject>");
					StaffID.append("\n");
				}
			}
			rdTx.commit();
			StaffID.append("</StaffSubjects>");
			StaffID.append("\n");

			xmlString = StaffID.toString();
		} catch (Exception localException) {
			localException.printStackTrace();
			System.out.println(localException);

			StaffID.append("<Response>");
			StaffID.append("\n");
			StaffID.append("<Result>");
			StaffID.append("\n");
			StaffID.append("Fail");
			StaffID.append("\n");
			StaffID.append("</Result>");
			StaffID.append("\n");
			StaffID.append("<Description>");
			StaffID.append("could not get all staffsubjects info");
			StaffID.append("</Description>");
			StaffID.append("\n");
			StaffID.append("<Exception>");
			StaffID.append(localException);
			StaffID.append("</Exception>");
			StaffID.append("</Response>");
			xmlString = StaffID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		} finally {
			rdSession.close();
		}
		return xmlString;
	}

	public String addStaffSubjectsOnExperience(StaffSubjectsPojo ssp) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String staffsubreg = null;
		String sqlstr;
		try {

			rdTx = rdSession.beginTransaction();

			String expid = ssp.getStaffExpId();

			String array[] = expid.split(",");

			Integer stasubid = (Integer) rdSession.save(ssp);

			for (int i = 0; i <= array.length - 1; i++) {
				int stfexpid = Integer.parseInt(array[i]);

				sqlstr = "insert into gbl_sm_tbl_staffsub_staffexp(StaffSubId,StaffExpId) values ('" + stasubid + "','"
						+ stfexpid + "');";

				SQLQuery stpar = rdSession.createSQLQuery(sqlstr);
				stpar.executeUpdate();
			}

			rdTx.commit();
			StaffID.append("<StaffSubjects>");
			StaffID.append("\n");
			StaffID.append("<id>");
			StaffID.append("\n");
			StaffID.append(stasubid);
			StaffID.append("</id>");
			StaffID.append("\n");
			StaffID.append("</StaffSubjects>");
			staffsubreg = StaffID.toString();
		} catch (Exception localException) {
			localException.printStackTrace();
			System.out.println(localException);

			StaffID.append("<Response>");
			StaffID.append("\n");
			StaffID.append("<Result>");
			StaffID.append("\n");
			StaffID.append("Fail");
			StaffID.append("\n");
			StaffID.append("</Result>");
			StaffID.append("\n");
			StaffID.append("<Description>");
			StaffID.append("could not inserted staffsubjects info");
			StaffID.append("</Description>");
			StaffID.append("\n");
			StaffID.append("<Exception>");
			StaffID.append(localException);
			StaffID.append("</Exception>");
			StaffID.append("</Response>");

			staffsubreg = StaffID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		} finally {
			rdSession.close();
		}
		return staffsubreg;

	}

}
