package com.gwebitsol.core.staff;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.stereotype.Component;

@XmlRootElement(name = "StaffAllInfo")
@Component
public class StaffAllInfoPojo {

	List<StaffPojo> staffinfo;

	List<StaffEducationPojo> staffedu;

	List<StaffExperiencePojo> staffexe;

	List<StaffSubjectsPojo> staffsub;

	List<StaffAccoladePojo> staffaccolads;

	public List<StaffAccoladePojo> getStaffaccolads() {
		return staffaccolads;
	}

	public void setStaffaccolads(List<StaffAccoladePojo> staffaccolads) {
		this.staffaccolads = staffaccolads;
	}

	public List<StaffPojo> getStaffinfo() {
		return staffinfo;
	}

	public void setStaffinfo(List<StaffPojo> staffinfo) {
		this.staffinfo = staffinfo;
	}

	public List<StaffEducationPojo> getStaffedu() {
		return staffedu;
	}

	public void setStaffedu(List<StaffEducationPojo> staffedu) {
		this.staffedu = staffedu;
	}

	public List<StaffExperiencePojo> getStaffexe() {
		return staffexe;
	}

	public void setStaffexe(List<StaffExperiencePojo> staffexe) {
		this.staffexe = staffexe;
	}

	public List<StaffSubjectsPojo> getStaffsub() {
		return staffsub;
	}

	public void setStaffsub(List<StaffSubjectsPojo> staffsub) {
		this.staffsub = staffsub;
	}

}
