package com.gwebitsol.core.staff;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.stereotype.Service;

import com.gwebitsol.core.security.MDValidation;
import com.gwebitsol.core.security.MDVerifyConnectionID;
import com.gwebitsol.core.security.MDVerifyDatastoreName;
import com.gwebitsol.core.usermanagement.MDGetUserFromID;
import com.gwebitsol.core.util.MDTransactionWriter;

@Service
public class StaffService implements StaffServiceIntf {

	@Context
	private HttpServletRequest hsr;

	public Response addStaff(StaffPojo sp, int userid, int connectionid, String datastoreName,int schoolid,int branchId) {

		MDTransactionWriter.accesslog.info("Request from:" + hsr.getRemoteHost());

		String status = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();
		
		sp.setBranchId(branchId);
		sp.setSchoolId(schoolid);

		
		try {
			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName, schoolid, branchId);
			System.out.println("verifiedvalue::"+ret);
			
			if (ret == 1) // && rtVal==1)
			{
				StaffDao pd = new StaffDao();
				status = pd.addStaff(sp);
				System.out.println(status);
				Long el = System.currentTimeMillis();
				String endDate = dateFormat.format(new Date());
				// status= "user validation is successfull";
				MDTransactionWriter.writeLog("SCHOOL", "MMS", "srinu", startDate, endDate, sl, el, status,
						hsr.getRemoteHost());
			} else {
				status = "you are not authorised user";
			}
		} catch (Exception localException) {

			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status = "failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response updateStaff(StaffPojo sp, int userid, int connectionid, String datastoreName,int schoolid,int branchId) {
		MDTransactionWriter.accesslog.info("Request from:" + hsr.getRemoteHost());

		String status = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();
		sp.setBranchId(branchId);
		sp.setSchoolId(schoolid);
		
		try {
			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName,schoolid, branchId);
			System.out.println("verifiedvalue::"+ret);
			
			if (ret == 1) // && rtVal==1)
			{
				StaffDao pd = new StaffDao();
				status = pd.updateStaff(sp,schoolid, branchId);
				System.out.println(status);
				Long el = System.currentTimeMillis();
				String endDate = dateFormat.format(new Date());
				// status= "user validation is successfull";
				MDTransactionWriter.writeLog("SCHOOL", "MMS", "srinu", startDate, endDate, sl, el, status,
						hsr.getRemoteHost());
			} else {
				status = "you are not authorised user";
			}
		} catch (Exception localException) {

			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status = "failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response deleteStaff(int employeeId, int userid, int connectionid, String datastoreName, int schoolid,int branchId) {
		MDTransactionWriter.accesslog.info("Request from:" + hsr.getRemoteHost());

		String status = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();

		try {
			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName,schoolid, branchId);
			System.out.println("verifiedvalue::"+ret);
			
			if (ret == 1) // && rtVal==1)
			{
				StaffDao pd = new StaffDao();
				status = pd.deleteStaff(employeeId, schoolid, branchId);
				System.out.println(status);
				Long el = System.currentTimeMillis();
				String endDate = dateFormat.format(new Date());
				// status= "user validation is successfull";
				MDTransactionWriter.writeLog("SCHOOL", "MMS", "srinu", startDate, endDate, sl, el, status,
						hsr.getRemoteHost());
			} else {
				status = "you are not authorised user";
			}
		} catch (Exception localException) {

			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status = "failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response getStaffById(int employeeId, int userid, int connectionid, String datastoreName, int schoolid,int branchId) {
		MDTransactionWriter.accesslog.info("Request from:" + hsr.getRemoteHost());

		String status = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();

		try {
			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName, schoolid, branchId);
			System.out.println("verifiedvalue::"+ret);
			
			if (ret == 1) // && rtVal==1)
			{
				StaffDao pd = new StaffDao();
				status = pd.getStaffById(employeeId, schoolid, branchId);
				System.out.println(status);
				Long el = System.currentTimeMillis();
				String endDate = dateFormat.format(new Date());
				// status= "user validation is successfull";
				MDTransactionWriter.writeLog("SCHOOL", "MMS", "srinu", startDate, endDate, sl, el, status,
						hsr.getRemoteHost());
			} else {
				status = "you are not authorised user";
			}
		} catch (Exception localException) {

			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status = "failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	

	public Response getAllStaffMem(int userid, int connectionid, String datastoreName, int PNO, int size, int schoolid,int branchId) {
		MDTransactionWriter.accesslog.info("Request from:" + hsr.getRemoteHost());

		String status = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();

		try {
			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName,schoolid, branchId);
			System.out.println("verifiedvalue::"+ret);
			
			if (ret == 1) // && rtVal==1)
			{

				StaffDao pd = new StaffDao();
				status = pd.getAllStaffMem(PNO,size, schoolid, branchId);
						
				System.out.println(status);
				Long el = System.currentTimeMillis();
				String endDate = dateFormat.format(new Date());
				// status= "user validation is successfull";
				MDTransactionWriter.writeLog("SCHOOL", "MMS", "srinu", startDate, endDate, sl, el, status,
						hsr.getRemoteHost());
			} else {
				status = "you are not authorised user";
			}
		} catch (Exception localException) {

			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status = "failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	/*
	 * public Response addStaffAllInfo(StaffPojo saip, int userid, int
	 * connectionid, String datastoreName) { MDTransactionWriter.accesslog.info(
	 * "Request from:"+hsr.getRemoteHost());
	 * 
	 * String status= null; DateFormat dateFormat = new SimpleDateFormat(
	 * "yyyy-MM-dd HH:mm:ss"); Date date = new Date(); String
	 * startDate=dateFormat.format(date); Long sl=System.currentTimeMillis();
	 * 
	 * try{ MDGetUserFromID mdgufid=new MDGetUserFromID(); String
	 * requester=mdgufid.getUserName(userid);
	 * 
	 * System.out.println(connectionid); MDVerifyConnectionID mdvcid=new
	 * MDVerifyConnectionID(); int
	 * ret=mdvcid.verifyConnectionID(userid,connectionid);
	 * 
	 * MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName(); int
	 * rtVal=mdvdsn.verifyDatastoreName(datastoreName);
	 * 
	 * System.out.println("request making user:: "+requester);
	 * System.out.println("connectionid verification value:: "+ret);
	 * System.out.println("datastore verification value :: "+rtVal); if(ret==1
	 * )//&& rtVal==1) { StaffDao pd = new StaffDao(); status=
	 * pd.addStaffAllInfo(saip); System.out.println(status); Long
	 * el=System.currentTimeMillis(); String endDate=dateFormat.format(new
	 * Date()); //status= "user validation is successfull";
	 * MDTransactionWriter.writeLog("SCHOOL","MMS","srinu",startDate,endDate,sl,
	 * el,status,hsr.getRemoteHost()); } else { status=
	 * "you are not authorised user"; } }catch(Exception localException) {
	 * 
	 * MDTransactionWriter.exceptionlog.debug(localException);
	 * MDTransactionWriter.exceptionlog.info(localException); status=
	 * "failed in Service layer"; } return
	 * Response.ok().type(MediaType.APPLICATION_XML).entity(status).build(); }
	 */

}
