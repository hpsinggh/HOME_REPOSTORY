package com.gwebitsol.core.staff;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

@Path("/staff/")

public interface StaffServiceIntf {

	@POST
	@Path("/addstaff/")
	@Consumes({ "application/xml", "application/json" })
	@Produces({ "application/xml", "application/json" })
	public Response addStaff(StaffPojo sp, @QueryParam("userid") int userid,
			@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
			@QueryParam("schoolid") int schoolid,@QueryParam("branchid") int branchid);

	@POST
	@Path("/updatestaff/")
	@Consumes({ "application/xml", "application/json" })
	@Produces({ "application/xml", "application/json" })
	public Response updateStaff(StaffPojo sp, @QueryParam("userid") int userid,
			@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
			@QueryParam("schoolid") int schoolid,@QueryParam("branchid") int branchid);

	@POST
	@Path("/deletestaff/")
	@Consumes({ "application/xml", "application/json" })
	@Produces({ "application/xml", "application/json" })
	public Response deleteStaff(@QueryParam("employeeId") int employeeId, @QueryParam("userid") int userid,
			@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
			@QueryParam("schoolid") int schoolid,@QueryParam("branchid") int branchid);

	@GET
	@Path("/getstaffById/")
	@Consumes({ "application/xml", "application/json" })
	@Produces({ "application/xml", "application/json" })
	public Response getStaffById(@QueryParam("employeeId") int employeeId, @QueryParam("userid") int userid,
			@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
			@QueryParam("schoolid") int schoolid,@QueryParam("branchid") int branchid);

	@GET
	@Path("/getalstff/")
	@Consumes({ "application/xml", "application/json" })
	@Produces({ "application/xml", "application/json" })
	public Response getAllStaffMem(@QueryParam("userid") int userid, @QueryParam("connectionid") int connectionid,
			@QueryParam("datastoreName") String datastoreName, @QueryParam("PNO") int PNO, @QueryParam("size") int size,
			@QueryParam("schoolid") int schoolid,@QueryParam("branchid") int branchid);

}
