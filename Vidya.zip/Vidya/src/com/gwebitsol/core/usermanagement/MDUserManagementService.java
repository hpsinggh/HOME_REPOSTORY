package com.gwebitsol.core.usermanagement;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.apache.log4j.Logger;

import com.gwebitsol.core.security.MDValidation;
import com.gwebitsol.core.security.MDVerifyConnectionID;
import com.gwebitsol.core.security.MDVerifyDatastoreName;
import com.gwebitsol.core.usermanagement.MDUser;
import com.gwebitsol.core.usermanagement.MDUserManagementServiceIntf;
import com.gwebitsol.core.util.MDTransactionWriter;
import com.gwebitsol.core.util.MailSender;

public class MDUserManagementService implements MDUserManagementServiceIntf
{
	@Context private HttpServletRequest hsr;
	private static Logger transactionLog=Logger.getLogger("transactionLog");
	public Response addUser(MDUser mduser,int userID,int connectionID,String datastoreName,int companyId,int branchId)
	{
		System.out.println(mduser);
				MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
				String XMLString=null;
				String statusStr=null;
				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date date = new Date();
				String startDate=dateFormat.format(date);
				Long sl=System.currentTimeMillis();
				mduser.setCompanyId(companyId);
				mduser.setBranchId(branchId);
				try
				{
					MDValidation mdv = new MDValidation();  
					int ret =mdv.allvalidations(userID, connectionID, datastoreName, companyId, branchId);
					System.out.println("verifiedvalue::"+ret);
					if(ret==1 )//&& rtVal==1)
					{
						StringBuffer usSB=new StringBuffer();
						
						MDUserManagementDAO umDAO=new MDUserManagementDAO();
						XMLString=umDAO.addUser(mduser,userID);
						usSB.append("<operation>adduserservice</operation>");
						usSB.append("\n");
						if(XMLString.equals("user addition failed"))
							statusStr="failed";
						else
							statusStr="success";
						usSB.append("<status>"+XMLString+"</status>");
						transactionLog.info(usSB.toString());
						String endDate=dateFormat.format(new Date());
						Long el=System.currentTimeMillis();
						MDTransactionWriter.writeLog(datastoreName,"UserMS","requester",startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
					}
					else
					{
						XMLString="you are not authorised user";
					}
				}
				catch(Exception localException)
				{
					MDTransactionWriter.errorlog.debug(localException);
					MDTransactionWriter.errorlog.info(localException);
					XMLString="failed in service layer";
				}
		
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}
	public Response getUsers(int userID,int connectionID,String datastoreName,int companyId,int branchId)
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDValidation mdv = new MDValidation();  
			int ret =mdv.allvalidations(userID, connectionID, datastoreName, companyId, branchId);
			System.out.println("verifiedvalue::"+ret);
		
			if(ret==1 )//&& rtVal==1)
			{
				MDUserManagementDAO umDAO=new MDUserManagementDAO();
				XMLString=umDAO.getAllusers(companyId,branchId);
				if(XMLString.equals("fail"))
					statusStr="failed";
				else
					statusStr="success";	
				System.out.println("entered into service");
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				MDTransactionWriter.writeLog(datastoreName,"UserMS","requester",startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}
		}
	catch(Exception localException)
	{
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
		statusStr="failed in service layer";
	}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
		
	}
	public Response getUserDetails(String username,int userID,int connectionID,String datastoreName,int companyId,int branchId)
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDValidation mdv = new MDValidation();  
			int ret =mdv.allvalidations(userID, connectionID, datastoreName, companyId, branchId);
			System.out.println("verifiedvalue::"+ret);
			if(ret==1 )//&& rtVal==1)
			{
				MDUserManagementDAO umDAO=new MDUserManagementDAO();
				XMLString=umDAO.getUserdetails(username,companyId,branchId);
				if(XMLString.equals("<user doesnot exist>"))
					statusStr="failed";
				else
					statusStr="success";
				System.out.println("entered into service");
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				MDTransactionWriter.writeLog(datastoreName,"UserMS","requester",startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}
		}
	catch(Exception localException)
	{
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
		statusStr="failed in service layer";
	}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
		
	}
	
	public Response deleteUser(String username,int userID,int connectionID,String datastoreName,int companyId,int branchId)
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDValidation mdv = new MDValidation();  
			int ret =mdv.allvalidations(userID, connectionID, datastoreName, companyId, branchId);
			System.out.println("verifiedvalue::"+ret);
			
			if(ret==1 )//&& rtVal==1)
			{
				MDUserManagementDAO umDAO=new MDUserManagementDAO();
				XMLString=umDAO.deleteUser(username,userID,companyId,branchId);
				if(XMLString.equals("User deletion failed"))
					statusStr="failed";
				else
					statusStr="success";
				System.out.println("entered into service");
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				MDTransactionWriter.writeLog(datastoreName,"UserMS","requester",startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}
		}
	catch(Exception localException)
	{
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
		statusStr="failed in service layer";
	}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
		
	}
	
	public Response updateUser(MDUser mduser,int userID,int connectionID,String datastoreName,int companyId,int branchId)
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		mduser.setCompanyId(companyId);
		mduser.setBranchId(branchId);
		try
		{
			MDValidation mdv = new MDValidation();  
			int ret =mdv.allvalidations(userID, connectionID, datastoreName, companyId, branchId);
			System.out.println("verifiedvalue::"+ret);
			if(ret==1 )//&& rtVal==1)
			{
				MDUserManagementDAO umDAO=new MDUserManagementDAO();
				XMLString=umDAO.updateUser(mduser,userID,companyId,branchId);
				if(XMLString.equals("User updation failed"))
					statusStr="failed";
				else
					statusStr="success";
				
				System.out.println("entered into service");
				
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				MDTransactionWriter.writeLog(datastoreName,"UserMS","requester",startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}
		}
	catch(Exception localException)
	{
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
		statusStr="failed in service layer";
	}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
		
	}
	
	/*public Response getImageStream(int userID,int userid,int connectionID,String datastoreName)
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		InputStream bigInputStream=null;
		final ByteArrayOutputStream out = new ByteArrayOutputStream();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userid,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			
			if(ret==1 )//&& rtVal==1)
			{
			MDUserManagementDAO dmDAO=new MDUserManagementDAO();
			Image image=dmDAO.getUserImage(userID);
			if(image.equals(null))
				statusStr="fail";
			else
				statusStr="success";
			ImageIO.write((BufferedImage) image, "jpg", out);
			final byte[] imgData = out.toByteArray();
			bigInputStream = new ByteArrayInputStream(imgData);
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			MDTransactionWriter.writeLog(datastoreName,"UserMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				statusStr="fail";
			}
			return Response.ok(bigInputStream).build();
		}
		catch (final IOException e)
		{
			return Response.noContent().build();
		}	

	}*/
	public Response unlockUser(String username, String modifiedby,int userID,int connectionID,String datastoreName) 
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			
			if(ret==1 )//&& rtVal==1)
			{
				MDUserManagementDAO umDAO=new MDUserManagementDAO();
				XMLString=umDAO.unlockUser(username,modifiedby);
				if(XMLString.equals("fail"))
					statusStr="failed";
				else
					statusStr="success";
				System.out.println("entered into service");
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				MDTransactionWriter.writeLog(datastoreName,"UserMS","requester",startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}
		}
	catch(Exception localException)
	{
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
		statusStr="failed in service layer";
	}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}
	
	public Response changeUserPassword(int connectionID, int userID, String currentPassword,String newPassword,String datastoreName) 
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			
			if(ret==1 )//&& rtVal==1)
			{
				MDUserManagementDAO umDAO=new MDUserManagementDAO();
				XMLString=umDAO.changePassword(userID, currentPassword, newPassword);
				if(XMLString.equals("fail"))
					statusStr="failed";
				else
					statusStr="success";
				System.out.println("entered into service");
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				MDTransactionWriter.writeLog(datastoreName,"UserMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}
		}
	catch(Exception localException)
	{
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
		statusStr="failed in service layer";
	}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}
	
	
	public Response forgotUserName(String emailID, String dob) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String XMLString=null;
		@SuppressWarnings("unused")
		String statusStr=null;
		try{
		MDUserManagementDAO umDAO=new MDUserManagementDAO();
	    String userName=	umDAO.forgotUserName(emailID, dob);
	    if(userName != null&&!userName.equalsIgnoreCase("fail")){
	  Boolean status=  MailSender.sendMail(emailID,"Test Mail","Your User name is :: "+ userName);
	  if(status){
	    XMLString="Your User name is send to the following E_mail_ID :"+emailID+" please check once.";
	  }
	    }else{
	    	 XMLString="Your Email-ID OR DOB is wrong please provide valid Information";
	    }
		}catch (Exception localException) {
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			statusStr="failed in service layer";
			return Response.status(Status.EXPECTATION_FAILED).entity("Internal Server Error.").build();
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}
	
	public Response forgotPassword(String userName, String emailID) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String XMLString="FAILE";
		@SuppressWarnings("unused")
		String statusStr=null;
		try{
		MDUserManagementDAO umDAO=new MDUserManagementDAO();
	    String password=	umDAO.forgotPassword(userName, emailID);
	    if(password != null && !password.equalsIgnoreCase("fail")){
	  Boolean status=  MailSender.sendMail(emailID,"Test Mail","Your Password is :: "+ password);
	  if(status){
	    XMLString="Your Password  is send to the following E_mail_ID :"+emailID+" please check once.";
	  }
	    }else{
	    	 XMLString="Your UserName OR Email-ID is wrong please provide valid Information";
	    }
		}catch (Exception localException) {
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			statusStr="failed in service layer";
			return Response.status(Status.EXPECTATION_FAILED).entity("Internal Server Error.").build();
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}
	
		
}
