package com.gwebitsol.core.usermanagement;

import java.awt.Image;
import java.io.InputStream;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.Transaction;
import org.hibernate.Session;
import com.gwebitsol.core.usermanagement.MDUserPOJO;
import com.gwebitsol.core.util.MDEncryptDecryptManager;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;
import com.mysql.jdbc.Blob;

import javax.imageio.ImageIO;

public class MDUserManagementDAO 
{
	DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	Date date = new Date();
	String d=dateFormat.format(date);

	@SuppressWarnings("rawtypes")
	public String addUser(MDUser mduser,int userID) 

	{
		Session umgmtSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		String rtnString=null;
		
		try
		{ 
			tx=umgmtSession.beginTransaction();
			
			MDUserPOJO userPOJO=new MDUserPOJO();
			if(mduser.getUserName().isEmpty())
			{
				rtnString="Enter a valid username...";
			}
			else
			{
			userPOJO.setUserName(mduser.getUserName());
			userPOJO.setPassword(mduser.getPassword());
			userPOJO.setPasswordExpiryDate(mduser.getPasswordExpiryDate());
			userPOJO.setPhoto(mduser.getPhoto());
			userPOJO.setStatus("Active");
			userPOJO.setCreatedDate(new Date()); 
			userPOJO.setRoleString(mduser.getRoleName());
			userPOJO.setCreatedBy(userID);
			userPOJO.setModifiedBy(0);
			userPOJO.setModifiedDate(new Date());
			userPOJO.setEmployeeID(mduser.getEmployeeID());
			userPOJO.setCompanyId(mduser.getCompanyId());
			userPOJO.setBranchId(mduser.getBranchId());
			userPOJO.setGroupName(mduser.getGroupName());
			
			List list=umgmtSession.createSQLQuery("select * from mdusers where username='"+mduser.getUserName()+"'").list();
   		 	if(list!=null && list.size()>0)
   		 	{
   		 		rtnString="This Username has already been used, Give a unique Username..";
   			 
   		 	}
			else
			{
				if(mduser.getEmployeeID().equalsIgnoreCase(" "))
			{
				rtnString="Please Enter a Valid EmployeeID";
			}
			
			else
			{		
			List list1=umgmtSession.createSQLQuery("select * from mdusers where employeeid='"+mduser.getEmployeeID()+"' and status!='deleted'").list();
   		 	if(list1!=null && list1.size()>0)
   		 	{
   		 		rtnString="This employee has already been assigned a userID..";
   			 
   		 	}
   		 	else
   		 	{
            String passwd=mduser.getPassword();
            MDEncryptDecryptManager enObj=new MDEncryptDecryptManager();
            String pwd=enObj.getEncryptedContent(passwd);
            userPOJO.setPassword(pwd);
            umgmtSession.save(userPOJO);
            tx.commit();
            rtnString="User: "+mduser.getUserName()+" is added successfully";
   		 	}
			}
			}
			}
            

		}
		catch (Exception localexception) 
		{
			tx.rollback();
			MDTransactionWriter.exceptionlog.debug(localexception);
			rtnString="User addition failed";
		} 
		finally
		{
			umgmtSession.close();
		}
		
		return rtnString;
	}
	public String updateUser(MDUser  mduser,int userID,int companyId,int branchId) 
	{
		Session uuSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction uutx = null;
		String rtnString=null;
		try
		{
			uutx=uuSession.beginTransaction();
		    int id =(Integer)uuSession.createSQLQuery("select userid from mdusers where username= '"+mduser.getUserName()+"'  and schoolId='"+companyId+"' and branchId='"+branchId+"'").uniqueResult();
			MDUserPOJO muser=(MDUserPOJO)uuSession.load(MDUserPOJO.class, id);
			muser.setPasswordExpiryDate(mduser.getPasswordExpiryDate());
			if(mduser.getPhoto()!=null)
			{
			muser.setPhoto(mduser.getPhoto());
			}
			muser.setModifiedDate(new Date());
			muser.setModifiedBy(userID);
			if(branchId==muser.getBranchId()&&companyId==muser.getCompanyId())
			{
			uuSession.evict(muser);
			uuSession.update(muser);
			uutx.commit();
			rtnString="User details updated successfully";

		}
		}
		catch (Exception localexception)
		{
			uutx.rollback();
			MDTransactionWriter.exceptionlog.info(localexception);
			rtnString="User updation failed";
		} 
		finally
		{
			uuSession.close();
		}
		return rtnString;
	}

	@SuppressWarnings({ "deprecation", "rawtypes" })
	public String deleteUser(String userName,int userID,int companyId,int branchId) 
	{
		Session udSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction udtx = null;
		String rtnString=null;

		try
		{
			udtx=udSession.beginTransaction();
			
		    int uid =(Integer)udSession.createSQLQuery("select userid from mdusers where username= '"+userName+"' and schoolId='"+companyId+"' and branchId='"+branchId+"'").uniqueResult();
		    if(uid==1)
		    {
		    	rtnString="You cant delete this user..";
		    }
		    else
		    {
		    if(uid==userID)
		    {
		    	rtnString="You cant delete your own user account..";
		    }
		    else
		    {
		    
		    Query udQuery=udSession.createSQLQuery("update mdusers set status='deleted',rolestring=' ' where userid="+uid);
		    udQuery.executeUpdate();
		  
		    
		    String udSql2="SELECT * FROM MDFOLDER WHERE PARENTFOLDERID=1 AND ACL LIKE '%U#"+uid+":111%'";
			Query udQuery2=udSession.createSQLQuery(udSql2).addScalar("folderid",Hibernate.INTEGER).addScalar("acl",Hibernate.STRING);
			List udList=udQuery2.list();
			Iterator udIT=udList.iterator();
			while(udIT.hasNext())
			{
				Object[] udObj=(Object[])udIT.next();
				int folderID=(Integer)udObj[0];
				String acl=(String)udObj[1];
				String modifiedAcl=acl.replaceAll(";U#"+uid+":111","");
				
				Query udQuery3=udSession.createSQLQuery("update mdfolder set acl='"+modifiedAcl+"',modifieddate='"+d+"',modifiedby="+userID+" where folderid="+folderID);
				udQuery3.executeUpdate();
			}
		
				   
			String udSql3="delete from mdcurrentloggings where userid="+uid;
			
		
			Query udQuery4=udSession.createSQLQuery(udSql3);
			
		    		
	  
			   udQuery4.executeUpdate();
		
			rtnString="User deleted successfully";
		    }
		    }
		    
		    
		    udtx.commit();
		
		}
	
		catch (Exception localexception) 
		{
			udtx.rollback();
			MDTransactionWriter.exceptionlog.info(localexception);
			rtnString="User deletion failed";
		} 
		finally
		{
			udSession.close();
		}
		
		return rtnString;
	}	

	@SuppressWarnings({ "rawtypes", "deprecation" })
	public String getAllusers(int companyId,int branchId)
	{
		Session gaSession = MDHibernateUtil.getSessionFactory().openSession();
	    Transaction gaTx = null;
	    StringBuffer xmlStringBuffer=new StringBuffer();
	    String xmlString=null;
		
		try
		{
			gaTx=gaSession.beginTransaction();
			String gaSQL="select * from mdusers as md where md.SchoolId = '" + companyId + "'  and md.BranchId= '" + branchId + "' and status='active' or status='locked' order by username ASC";
			Query gaQuery=gaSession.createSQLQuery(gaSQL).addScalar("userid",Hibernate.INTEGER).addScalar("username",Hibernate.STRING)
					.addScalar("password",Hibernate.STRING).addScalar("passwordExpiryDate",Hibernate.STRING)
					.addScalar("ROLESTRING",Hibernate.STRING).addScalar("CREATEDDATE",Hibernate.STRING).addScalar("STATUS",Hibernate.STRING)
					.addScalar("EMPLOYEEID",Hibernate.STRING)
					.addScalar("schoolId",Hibernate.INTEGER).addScalar("branchId",Hibernate.INTEGER).addScalar("GROUPNAME",Hibernate.STRING);
			List user=gaQuery.list();
			
			System.out.println("No Of users  - " + user.size());
			xmlStringBuffer.append("<MD_users>");
			xmlStringBuffer.append("\n");
            for( Iterator it = user.iterator();it.hasNext();)
			{
            	Object[] user1=(Object[])it.next();
            	user1[2] = "*************";
            	xmlStringBuffer.append("<MD_user>");
    			xmlStringBuffer.append("\n");
				xmlStringBuffer.append("<userID>");
				xmlStringBuffer.append(user1[0]);
				xmlStringBuffer.append("</userID>");
				xmlStringBuffer.append("\n");
				xmlStringBuffer.append("<userName>");
				xmlStringBuffer.append(user1[1]);
				xmlStringBuffer.append("</userName>");
				xmlStringBuffer.append("\n");
				xmlStringBuffer.append("<password>");
				xmlStringBuffer.append(user1[2]);
				xmlStringBuffer.append("</password>");
				xmlStringBuffer.append("\n");
				xmlStringBuffer.append("<passwordExpiryDate>");
				xmlStringBuffer.append(user1[3]);
				xmlStringBuffer.append("</passwordExpiryDate>");
				xmlStringBuffer.append("\n");
				xmlStringBuffer.append("<roles>");
				xmlStringBuffer.append(user1[4]);
				xmlStringBuffer.append("</roles>");
				xmlStringBuffer.append("\n");
				xmlStringBuffer.append("<createddate>");
				xmlStringBuffer.append(user1[5]);
				xmlStringBuffer.append("</createddate>");
				xmlStringBuffer.append("\n");
				xmlStringBuffer.append("<status>");
				xmlStringBuffer.append(user1[6]);
				xmlStringBuffer.append("</status>");
				xmlStringBuffer.append("\n");
				xmlStringBuffer.append("<employeeid>");
				xmlStringBuffer.append(user1[7]);
				xmlStringBuffer.append("</employeeid>");
				xmlStringBuffer.append("\n");
				xmlStringBuffer.append("<companyId>");
				xmlStringBuffer.append(user1[8]);
				xmlStringBuffer.append("</companyId>");
				xmlStringBuffer.append("\n");
				xmlStringBuffer.append("<branchId>");
				xmlStringBuffer.append(user1[9]);
				xmlStringBuffer.append("</branchId>");
				xmlStringBuffer.append("\n");
				xmlStringBuffer.append("<groupName>");
				xmlStringBuffer.append(user1[10]);
				xmlStringBuffer.append("</groupName>");
				xmlStringBuffer.append("\n");
				xmlStringBuffer.append("</MD_user>");
				xmlStringBuffer.append("\n");
		
			} 
            xmlStringBuffer.append("</MD_users>");
            xmlString=xmlStringBuffer.toString();
            gaTx.commit();
            xmlStringBuffer.setLength(0);
		} 
		catch (Exception localexception) 
		{ 
			gaTx.rollback();
			xmlStringBuffer.setLength(0);
			xmlString="fail";
			MDTransactionWriter.exceptionlog.info(localexception);
		}
		finally
		{
			gaSession.close();
			xmlStringBuffer=null;
		}
		return xmlString;
	}

	
    public String getUserdetails(String userName,int companyId,int branchId)
	{
    	Session guSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction guTx = null;
		StringBuffer gusb=new StringBuffer();
		String uXMLStr=null;
		try
		{
		guTx=guSession.beginTransaction();
		
		Integer uid=(Integer)guSession.createSQLQuery("select userid from mdusers where username='"+userName+"' and schoolId='"+companyId+"' and branchId='"+branchId+"'").uniqueResult();
		if(uid!=null)
		{
		MDUserPOJO cuser = (MDUserPOJO)guSession.load(MDUserPOJO.class,uid);
		gusb.append("<MD_User_Details>");
		gusb.append("\n");
		gusb.append("<userid>"+uid+"</userid>");
		gusb.append("\n");
		gusb.append("<username>"+cuser.getUserName()+"</username>");
		gusb.append("\n");
		gusb.append("<password>*****************</password>");
		gusb.append("\n");
		gusb.append("<passwordExpiryDate>"+cuser.getPasswordExpiryDate()+"</passwordExpiryDate>");
		gusb.append("\n");
		gusb.append("<roles>"+cuser.getRoleString()+"</roles>");
		gusb.append("\n");
		gusb.append("<createddate>"+cuser.getCreatedDate()+"</createddate>");
		gusb.append("\n");
		gusb.append("<status>"+cuser.getStatus()+"</status>");
		gusb.append("\n");
		gusb.append("<employeeid>"+cuser.getEmployeeID()+"</employeeid>");
		gusb.append("\n");
		gusb.append("<companyid>"+cuser.getCompanyId()+"</companyid>");
		gusb.append("\n");
		gusb.append("<branchid>"+cuser.getBranchId()+"</branchid>");
		gusb.append("\n");
		gusb.append("<groupName>"+cuser.getGroupName()+"</groupName>");
		gusb.append("\n");
		gusb.append("</MD_User_Details>");
		uXMLStr=gusb.toString();
		guTx.commit();
		gusb.setLength(0);
		
		}
		else
		{
			uXMLStr="This user doesnot exist";
		}
		
		}catch(Exception localexception)
		{
			guTx.rollback();
			gusb.setLength(0);
			MDTransactionWriter.exceptionlog.info(localexception);
			uXMLStr="fail";
		}
		finally
		{
			guSession.close();
			gusb=null;
		}
		return uXMLStr;
	}
    
    @SuppressWarnings("deprecation")
	public Image getUserImage(int userID)
	{
		Session gimgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gimgTx = null;	
		PreparedStatement ps = null;
		ResultSet rs = null;
		Image img=null;
		try
		{
			gimgTx=gimgSession.beginTransaction();
			String sql="select photo from mdusers where userid="+userID;
			java.sql.Connection connection =gimgSession.connection();
			ps = (PreparedStatement) connection.prepareStatement(sql);
			rs = (ResultSet) ps.executeQuery();
			if (rs.next()) 
			{
				Blob bl=(Blob)rs.getBlob("photo");
				InputStream in=bl.getBinaryStream();
				img = ImageIO.read(in);
			}
			gimgTx.commit();
		}
		catch(Exception localException)
		{
			MDTransactionWriter.exceptionlog.info(localException);
		}
		finally
		{
			gimgSession.close();
		}
		return img;

	}
    
    
    public String unlockUser(String userName,String modifiedBy)
    {
    	Session ulUSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction ulUTx = null;	
    	String outStr=null;
    	DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    	Date date = new Date();
    	String d=dateFormat.format(date);
    	try
    	{
    		ulUTx=ulUSession.beginTransaction();
		    int uid =(Integer)ulUSession.createSQLQuery("select userid from mdusers where username= '"+userName+"'").uniqueResult();
		    
		    int modifiedby =(Integer)ulUSession.createSQLQuery("select userid from mdusers where username= '"+modifiedBy+"'").uniqueResult();
		    
		    String ulUSql="update mdusers set status='Active',loginattempts=0,modifiedby="+modifiedby+",modifieddate='"+d+"' where userid="+uid;
		    Query udQuery=ulUSession.createSQLQuery(ulUSql);
		    udQuery.executeUpdate();
    		
    		ulUTx.commit();
    		outStr="User unlocked successfully";
    	}
    	catch(Exception localException)
    	{
    		ulUTx.rollback();
    		MDTransactionWriter.exceptionlog.info(localException);
    		outStr="fail";
    	}
    	finally
    	{
    		ulUSession.close();
    	}
    	return outStr;
    }
    
    public String changePassword(int userID,String oldPassword,String newPassword)
    {
    	Session cpSession=MDHibernateUtil.getSessionFactory().openSession();
    	Transaction cpTx=null;
    	String rtnString=null;
    	DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    	Date date = new Date();
    	String d=dateFormat.format(date);
    	try
    	{
    		cpTx=cpSession.beginTransaction();
    		String password=(String)cpSession.createSQLQuery("select password from mdusers where userid="+userID).uniqueResult();
    		
    		 MDEncryptDecryptManager enObj=new MDEncryptDecryptManager();
             String pwd=enObj.getEncryptedContent(oldPassword);
             if(oldPassword.equalsIgnoreCase(newPassword))
             {
            	 rtnString="Old password and new password should not be same.";
             }
             else 
            	 {if(pwd.equals(password))
             {
            	 String pssword=enObj.getEncryptedContent(newPassword);
            	 
            	 Query cpQuery=cpSession.createSQLQuery("update mdusers set password='"+pssword+"',modifieddate='"+d+"' where userid="+userID);
            	 cpQuery.executeUpdate();
            	 rtnString="Password has been changed successfully.";
             }
             else
             {
            	 rtnString="The password you gave is incorrect.";
             }
            	 }
    		
    		cpTx.commit();
    		
    		
    	}
    	catch(Exception localException)
    	{
    		cpTx.rollback();
    		MDTransactionWriter.exceptionlog.info(localException);
    		rtnString="fail";
    	}
    	finally
    	{
    		cpSession.close();
    	}
    	return rtnString;
    }
    
    @SuppressWarnings("rawtypes")
	public String forgotUserName(String emailID, String dob)
    {
    	Session cpSession=MDHibernateUtil.getSessionFactory().openSession();
    	Transaction cpTx=null;
    	String rtnString=null;
    	try
    	{
    		cpTx=cpSession.beginTransaction();
    		//String cpSql="select username from mdusers where emailid = '"+ emailID +"' and dob = '"+ dob+"'";
    		String query="select EMPLOYEEID from mdemployees where emailid = '"+ emailID +"' and dob = '"+ dob+"'";
    		List outerlist=cpSession.createSQLQuery(query).list();
      		 if(outerlist!=null && outerlist.size()>0){
      			 for(int i=0;i<outerlist.size();i++){
      			String EMPLOYEEID=	(String) outerlist.get(i);
    		String cpSql="select username from mdusers where EMPLOYEEID='"+ EMPLOYEEID+"'";
    		List list=cpSession.createSQLQuery(cpSql).list();
    		 if(list!=null && list.size()>0){
    			 rtnString= (String) list.get(0);
    		 }
      			 }
      		 }
    		cpTx.commit();
    	}
    	catch(Exception localException)
    	{
    		cpTx.rollback();
    		MDTransactionWriter.exceptionlog.info(localException);
    		rtnString="fail";
    	}
    	finally
    	{
    		cpSession.close();
    	}
    	return rtnString;
    }
    
    @SuppressWarnings("rawtypes")
	public String forgotPassword(String userName, String emailID)
    {
    	Session cpSession=MDHibernateUtil.getSessionFactory().openSession();
    	Transaction cpTx=null;
    	String rtnString=null;
    	try
    	{
    		cpTx=cpSession.beginTransaction();
    		//String cpSql="select password from mdusers where username = '"+ userName +"' and emailid = '"+ emailID+"'";
    		String query="select EMPLOYEEID from mdemployees where EMAILID='"+ emailID+"'";
    		List outerlist=cpSession.createSQLQuery(query).list();
   		 if(outerlist!=null && outerlist.size()>0){
   			 for(int i=0;i<outerlist.size();i++){
   			String EMPLOYEEID=	(String) outerlist.get(i);
    		String cpSql="select password from mdusers where username='"+ userName +"' and EMPLOYEEID='"+ EMPLOYEEID+"'";
    		List list=cpSession.createSQLQuery(cpSql).list();
    		 if(list!=null && list.size()>0){
    			  MDEncryptDecryptManager enObj=new MDEncryptDecryptManager();
    			  rtnString=enObj.getDecryptedContent((String) list.get(0));
    		 }
   			 }
   		 }
    		cpTx.commit();
    	}
    	catch(Exception localException)
    	{
    		cpTx.rollback();
    		MDTransactionWriter.exceptionlog.info(localException);
    		rtnString="fail";
    	}
    	finally
    	{
    		cpSession.close();
    	}
    	return rtnString;
    }
}

