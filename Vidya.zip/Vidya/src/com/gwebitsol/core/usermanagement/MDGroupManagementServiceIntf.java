package com.gwebitsol.core.usermanagement;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

import com.gwebitsol.core.usermanagement.MDGroup;

@Path("/groupmanagement/")
public interface MDGroupManagementServiceIntf 
{
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/addgroup")
	public Response addGroup(MDGroup mdgroup,@QueryParam("username") String username,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@GET
	@Produces ({"application/xml","application/json"})
	@Path("/getallgroups")
	public Response getAllGroups(@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@GET
	@Produces ({"application/xml","application/json"})
	@Path("/getdetails")
	public Response getGroupDetails(@QueryParam ("groupName") String groupName,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
		
	@PUT
	@Consumes("application/xml")
	@Produces({"application/xml","application/json"})
	@Path("/updategroup")
	public Response updateGroup(MDGroup mdgroup,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@PUT
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/deletegroup")
	public Response deleteGroup(@QueryParam("groupname") String groupname,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/assignUsersToGroup")
	public Response assignUsersToGroup(@QueryParam("usernames") String usernames,@QueryParam("groupname") String groupname,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/removeUsersFromGroup")
	public Response removeUsersFromGroup(@QueryParam("usernames") String usernames,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
}
