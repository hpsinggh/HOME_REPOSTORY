package com.gwebitsol.core.usermanagement;

import java.util.Arrays;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="mduser")
public class MDUser
{
	private String userName;
	private String password;
	private String passwordExpiryDate;
	private String employeeID;
	private byte[] photo;
	private String roleName;
	private String groupName;
	private int branchId;
	private int companyId;
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPasswordExpiryDate() {
		return passwordExpiryDate;
	}
	public void setPasswordExpiryDate(String passwordExpiryDate) {
		this.passwordExpiryDate = passwordExpiryDate;
	}
	public String getEmployeeID() {
		return employeeID;
	}
	public void setEmployeeID(String employeeID) {
		this.employeeID = employeeID;
	}
	public byte[] getPhoto() {
		return photo;
	}
	public void setPhoto(byte[] photo) {
		this.photo = photo;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public int getBranchId() {
		return branchId;
	}
	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}
	public int getCompanyId() {
		return companyId;
	}
	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}
	@Override
	public String toString() {
		return "MDUser [userName=" + userName + ", password=" + password + ", passwordExpiryDate=" + passwordExpiryDate
				+ ", employeeID=" + employeeID + ", photo=" + Arrays.toString(photo) + ", roleName=" + roleName
				+ ", groupName=" + groupName + ", branchId=" + branchId + ", companyId=" + companyId + "]";
	}
	
}


