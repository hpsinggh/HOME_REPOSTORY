package com.gwebitsol.core.usermanagement;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="login_input")
public class MDLoginInput 
{
	private String username;
	private String password;
	private String datastoreName;
	
	private String branchName;
	private String schoolName;
	
	//private String connectionKey;
	
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getDatastoreName() {
		return datastoreName;
	}
	public void setDatastoreName(String datastoreName) {
		this.datastoreName = datastoreName;
	}
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public String getSchoolName() {
		return schoolName;
	}
	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}
	


	
	
	/*public String getConnectionKey() {
		return connectionKey;
	}
	public void setConnectionKey(String connectionKey) {
		this.connectionKey = connectionKey;
	}*/
	
	
}
