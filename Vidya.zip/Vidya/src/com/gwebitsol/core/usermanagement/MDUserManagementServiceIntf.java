package com.gwebitsol.core.usermanagement;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;
import com.gwebitsol.core.usermanagement.MDUser;

@Path("/usermanagement/")
public interface MDUserManagementServiceIntf 
{
	@POST
	@Consumes({"*/*"})
	@Produces({"application/xml","application/json"})
	@Path("/adduser/")
	public Response addUser(MDUser mduser,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("companyId") int companyId,@QueryParam("branchId") int branchId);
	
	@GET
	@Path("/getusers/")
	@Produces({"application/xml","application/json"})
	public Response getUsers(@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("companyId") int companyId,@QueryParam("branchId") int branchId);
	
	@PUT
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/updateuser")
	public Response updateUser(MDUser mdUser,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("companyId") int companyId,@QueryParam("branchId") int branchId);
	
	@PUT
	@Consumes()
	@Produces()
	@Path("/deleteuser")
	public Response deleteUser(@QueryParam("username") String username,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("companyId") int companyId,@QueryParam("branchId") int branchId);
	
	@GET
	@Produces ({"application/xml","application/json"})
	@Path("/getuserdetails")
	public Response getUserDetails(@QueryParam("username") String username,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("companyId") int companyId,@QueryParam("branchId") int branchId);
	
	/*@Path("/getuserimage")
	@Produces("image/*")
	@GET
	public Response getImageStream(@QueryParam("userID") int userID,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);*/
	
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/unlockuser")
	public Response unlockUser(@QueryParam("username") String username,@QueryParam("modifiedby") String modifiedby,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@POST
	@Consumes({"application/xml","application/xml"})
	@Produces({"application/xml","application/xml"})
	@Path("/changepassword")
	public Response changeUserPassword(@QueryParam("connectionid")int connectionid,@QueryParam("userid")int userid,@QueryParam("currentPassword")String currentPassword,@QueryParam("newPassword")String newPassword,@QueryParam("datastoreName") String datastoreName);
	
	@GET
	@Produces ("application/xml")
	@Path("/forgotUserName")
	public Response forgotUserName(@QueryParam("emailID") String emailID,@QueryParam("dob") String dob);
	
	@GET
	@Produces ("application/xml")
	@Path("/forgotPassword")
	public Response forgotPassword(@QueryParam("userName") String userName,@QueryParam("emailID") String emailID);
}
