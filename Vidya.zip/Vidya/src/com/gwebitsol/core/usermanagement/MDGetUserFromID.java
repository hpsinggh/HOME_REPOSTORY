package com.gwebitsol.core.usermanagement;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class MDGetUserFromID
{
	@SuppressWarnings({ "deprecation", "rawtypes" })
	public String getUserName(int userID)
	{
		Session udsession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gdTx = null;
		String username=null;
		try
		{
			gdTx=udsession.beginTransaction();
			String uSql="select username from mdusers where userid="+userID;
			Query uQuery=udsession.createSQLQuery(uSql).addScalar("username",Hibernate.STRING);
			List uList=uQuery.list();
			Iterator it=uList.iterator();
			while(it.hasNext())
			{
				username=(String)it.next();
			}

			gdTx.commit();

		}
		catch(Exception localException)
		{
			MDTransactionWriter.exceptionlog.info(localException);
			username="null";
			
		}
		finally
		{
			udsession.close();

		}
		return username;
	}


}
