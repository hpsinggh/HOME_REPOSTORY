package com.gwebitsol.core.usermanagement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.gwebitsol.core.security.MDVerifyConnectionID;
import com.gwebitsol.core.security.MDVerifyDatastoreName;
import com.gwebitsol.core.usermanagement.MDGroup;
import com.gwebitsol.core.usermanagement.MDGroupManagementServiceIntf;
import com.gwebitsol.core.usermanagement.MDGroupPOJO;
import com.gwebitsol.core.util.MDTransactionWriter;

public class MDGroupManagementService implements MDGroupManagementServiceIntf
{
	@Context private HttpServletRequest hsr;
	public Response addGroup(MDGroup mdgroup,String username,int userID,int connectionID,String datastoreName)
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String XMLString=null;
		String statusString=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
						
			MDGroupManagementDAO gDAO=new MDGroupManagementDAO();
			String groupName=mdgroup.getGroupName();
			String parentFolderName=mdgroup.getParentFolderName();
			String roleString=mdgroup.getRoleString();
			String description=mdgroup.getDescription();
			System.out.println("groupName is ::::"+groupName);
			System.out.println("parentFolderName is ::::"+parentFolderName);
			System.out.println("roleString is ::::"+roleString);
			System.out.println("description is ::::"+description);
			XMLString=gDAO.addGroup(groupName,parentFolderName,roleString,description);
			if(XMLString.equals("fail"))
				statusString="failed";
			else
				statusString="success";
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			
			MDTransactionWriter.writeLog(datastoreName,"GruopMS",requester,startDate,endDate,sl,el,statusString,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}
			
		}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			statusString="failed in service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}
	public Response getAllGroups(int userID,int connectionID,String datastoreName)
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String XMLString=null;
		String statusString=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
			MDGroupManagementDAO gmDAO=new MDGroupManagementDAO();
			XMLString=gmDAO.getAllGroups();
			if(XMLString.equals("fail"))
				statusString="failed";
			else
				statusString="success";
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			MDTransactionWriter.writeLog(datastoreName,"GruopMS",requester,startDate,endDate,sl,el,statusString,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}
		}
		catch(WebApplicationException waException)
		{
			MDTransactionWriter.exceptionlog.info(waException);
			XMLString="failed in service layed";
		}
		
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}
	
	public Response getGroupDetails(String groupName,int userID,int connectionID,String datastoreName)
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String XMLString=null;
		String statusString=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
			MDGroupManagementDAO gmDAO=new MDGroupManagementDAO();
			XMLString=gmDAO.getGroupDetails(groupName);
			if(XMLString.equals("fail"))
				statusString="failed";
			else
				statusString="success";
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			MDTransactionWriter.writeLog(datastoreName,"GroupMS",requester,startDate,endDate,sl,el,statusString,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}
		}
		catch(WebApplicationException waException)
		{
			MDTransactionWriter.exceptionlog.info(waException);
			XMLString="failed in service layed";
		}
		
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}
	
	public Response deleteGroup(String groupName,int userID,int connectionID,String datastoreName)
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String XMLString=null;
		String statusString=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
							
			MDGroupManagementDAO gmDAO=new MDGroupManagementDAO();
			XMLString=gmDAO.deleteGroup(groupName);
			if(XMLString.equals("group deletion failed"))
				statusString="failed";
			else
				statusString="success";
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			
			MDTransactionWriter.writeLog(datastoreName,"GroupMS",requester,startDate,endDate,sl,el,statusString,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}
		
		}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			statusString="failed in service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
		
	}
	
	public Response updateGroup(MDGroup mdgroup,int userID,int connectionID,String datastoreName)
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String XMLString=null;
		String statusString=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
			MDGroupManagementDAO gmDAO=new MDGroupManagementDAO();
			MDGroupPOJO mdGroupPojo=new MDGroupPOJO();
			XMLString=gmDAO.updateGroup(mdGroupPojo);
			if(XMLString.equals("group updation failed"))
				statusString="failed";
			else
				statusString="success";
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			
			MDTransactionWriter.writeLog(datastoreName,"GroupMS",requester,startDate,endDate,sl,el,statusString,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}
		
		}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			statusString="failed in service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
		
	}
	public Response assignUsersToGroup(String usernames, String groupname,int userID,int connectionID,String datastoreName) 
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String XMLString=null;
		String statusString=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
			MDGroupManagementDAO gmDAO=new MDGroupManagementDAO();
			XMLString=gmDAO.addUsersToGroup(usernames, groupname);
			if(XMLString.equals("failure while adding users to group"))
				statusString="failed";
			else
				statusString="success";
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			
			MDTransactionWriter.writeLog(datastoreName,"GroupMS",requester,startDate,endDate,sl,el,statusString,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}
			
		}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			statusString="failed in service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}
	public Response removeUsersFromGroup(String usernames,int userID,int connectionID,String datastoreName) 
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String XMLString=null;
		String statusString=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
			MDGroupManagementDAO gmDAO=new MDGroupManagementDAO();
			XMLString=gmDAO.removeUsersFromGroup(usernames);
			if(XMLString.equals("failure while removing users from group"))
				statusString="failed";
			else
				statusString="success";
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			
			MDTransactionWriter.writeLog(datastoreName,"GroupMS",requester,startDate,endDate,sl,el,statusString,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}
		
		}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			statusString="failed in service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}
	
}
