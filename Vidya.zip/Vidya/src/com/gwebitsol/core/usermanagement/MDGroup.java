package com.gwebitsol.core.usermanagement;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="group")
public class MDGroup
{
	private String groupName;
	private String parentFolderName;
	private String roleString;
	private String description;
	
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getParentFolderName() {
		return parentFolderName;
	}
	public void setParentFolderName(String parentFolderName) {
		this.parentFolderName = parentFolderName;
	}
	public String getRoleString() {
		return roleString;
	}
	public void setRoleString(String roleString) {
		this.roleString = roleString;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
	
}
