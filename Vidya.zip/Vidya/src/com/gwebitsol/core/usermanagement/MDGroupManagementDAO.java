package com.gwebitsol.core.usermanagement;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.Transaction;
import org.hibernate.Session;

import com.gwebitsol.core.usermanagement.MDGetUserFromID;
import com.gwebitsol.core.usermanagement.MDGroupPOJO;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;


public class MDGroupManagementDAO 
{
	
	public String addGroup(String groupName,String parentFolderName, String roleString,String description) 

	{
		Session agSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction agTransaction=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String d=dateFormat.format(date);
		String XMLstr=null;

		try
		{ 
			agTransaction=agSession.beginTransaction();
			
			int parentfolderid=(Integer)agSession.createSQLQuery("select folderid from mdfolder where foldername='"+parentFolderName+"'").uniqueResult();
			
			System.out.println(parentfolderid);
			
			String agSql="INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY) VALUES('"+groupName+"',"+parentfolderid+","+0+",'active','G','"+d+"','0000-00-00 00:00:00','U#1:111',"+1+","+0+")";
			Query agquery0=agSession.createSQLQuery(agSql);
			agquery0.executeUpdate();
			System.out.println("create folder");
			
			String agSql1="insert into MDGroups (groupname, parentfolderid, rolestring, status, createddate, modifieddate, createdby, modifiedby, description) " +
					"values ('"+groupName+"',"+parentfolderid+",'"+roleString+"','active','"+d+"','"+d+"',1,0,'"+description+"')";
			Query agquery1=agSession.createSQLQuery(agSql1);
			agquery1.executeUpdate();
	
			agTransaction.commit();
			XMLstr="success";

		}
		catch (Exception localException) 
		{
			agTransaction.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			XMLstr="fail";
			System.out.println(localException);
		}
		finally
		{
			agSession.close();
		}
		return XMLstr;

	}

	@SuppressWarnings({ "deprecation", "rawtypes" })
	public String getAllGroups()
	{
		
		Session gsession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction getGroupsTx = null;
		
		String respXMLString=null;
		StringBuffer groupsSB=new StringBuffer();
		
		try
		{
			getGroupsTx=gsession.beginTransaction();
			String grpSql="select * from mdgroups where status='active'";
			Query grpQuery=gsession.createSQLQuery(grpSql).addScalar("groupname",Hibernate.STRING);
			List objList=grpQuery.list();
			Iterator it=objList.iterator();
			groupsSB.append("<MD_Groups>");
			groupsSB.append("\n");
			while(it.hasNext())
			{
				String groupName=(String)it.next();
				groupsSB.append("<deviceName>"+groupName+"</deviceName>");
				groupsSB.append("\n");
			}
			groupsSB.append("</MD_Groups>");
			respXMLString=groupsSB.toString();
			groupsSB.setLength(0);
			getGroupsTx.commit();
			
		}
		catch(Exception localException)
		{
			groupsSB.setLength(0);
			MDTransactionWriter.exceptionlog.info(localException);
			respXMLString="fail";
		}
		finally
		{
			gsession.close();
			groupsSB=null;
		}
		return respXMLString;
	}
	
	@SuppressWarnings("rawtypes")
	public String getGroupDetails(String groupName)
	{
		
		Session gdsession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gdTx = null;
		
		String respXMLString=null;
		StringBuffer groupsSB=new StringBuffer();
		
		try
		{
			gdTx=gdsession.beginTransaction();
			
			Query gdQuery=gdsession.createSQLQuery("select * from mdgroups where groupname='"+groupName+"'");
			List objList=gdQuery.list();
			Iterator it=objList.iterator();
			groupsSB.append("<MD_Group>");
			groupsSB.append("\n");
			while(it.hasNext())
			{
				Object[] obj=(Object[])it.next();
				groupsSB.append("<groupID>"+obj[0]+"</groupID>");
				groupsSB.append("\n");
				groupsSB.append("<groupName>"+obj[1]+"</groupName>");
				groupsSB.append("\n");
				groupsSB.append("<roles>"+obj[3]+"</roles>");
				groupsSB.append("\n");
				groupsSB.append("<status>"+obj[4]+"</status>");
				groupsSB.append("\n");
				groupsSB.append("<createdDate>"+obj[5]+"</createdDate>");
				groupsSB.append("\n");
				groupsSB.append("<modifiedDate>"+obj[6]+"</modifiedDate>");
				groupsSB.append("\n");
				groupsSB.append("<description>"+obj[9]+"</description>");
				groupsSB.append("\n");
				int cuserID=(Integer)obj[7];
				int muserID=(Integer)obj[8];
				MDGetUserFromID getUser=new MDGetUserFromID();
				groupsSB.append("<createdBy>"+getUser.getUserName(cuserID)+"</createdBy>");
				groupsSB.append("\n");
				groupsSB.append("<modifiedBy>"+getUser.getUserName(muserID)+"</modifiedBy>");
				groupsSB.append("\n");
				
			}
			groupsSB.append("</MD_Group>");
			respXMLString=groupsSB.toString();
			groupsSB.setLength(0);
			gdTx.commit();
			
		}
		catch(Exception localException)
		{
			groupsSB.setLength(0);
			gdTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			respXMLString="fail";
		}
		finally
		{
			gdsession.close();
			groupsSB=null;
		}
		return respXMLString;
	}
	
	public String deleteGroup(String groupName ) 
	{
		Session gdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction gdtx = null;
		StringBuffer groupsSB=new StringBuffer();
		String rtnString=null;
		groupsSB.append("group: "+groupName+" is going to delete from engine");
		groupsSB.append("\n");
		try
		{
			gdtx=gdSession.beginTransaction();
			
		    int gid =(Integer)gdSession.createSQLQuery("select groupid from mdgroups where groupname='"+groupName+"'").uniqueResult();
		    
		    Query gdQuery=gdSession.createSQLQuery("update mdgroups set status='deleted' where groupid="+gid);
		    gdQuery.executeUpdate();
			gdtx.commit();
			groupsSB.append("group: "+groupName+"is deleted successfully");
			rtnString=groupsSB.toString();
			groupsSB.setLength(0);
		}
		catch (Exception localexception) 
		{
			gdtx.rollback();
			MDTransactionWriter.exceptionlog.info(localexception);
			groupsSB.append("group deletion failed");
			rtnString=groupsSB.toString();
			groupsSB.setLength(0);
		} 
		finally
		{
			groupsSB=null;
			gdSession.close();
		}
		
		return rtnString;
	}	

	
	public String updateGroup(MDGroupPOJO  mdgroup) 
	{
		Session ugSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction ugtx = null;
		StringBuffer ugSB=new StringBuffer();
		String rtnString=null;
		ugSB.append("Group: "+mdgroup.getGroupName()+" is going to update");
		ugSB.append("\n");
		try
		{
			ugtx=ugSession.beginTransaction();
		    int id =(Integer)ugSession.createSQLQuery("select groupid from mdgroups where groupname= "+mdgroup.getGroupName()).uniqueResult();
			MDGroupPOJO mgroup=(MDGroupPOJO)ugSession.load(MDGroupPOJO.class, id);
			mgroup.setGroupName(mdgroup.getGroupName());
			mgroup.setParentFolderID(mdgroup.getParentFolderID());
			mgroup.setRoleString(mdgroup.getRoleString());
			mgroup.setDescription(mdgroup.getDescription());
			ugSession.update(mgroup);
			ugtx.commit();
			ugSB.append("group: "+mdgroup.getGroupName()+" is updated successfully");
			rtnString=ugSB.toString();
			ugSB.setLength(0);

		}
		catch (Exception localexception)
		{
			ugtx.rollback();
			MDTransactionWriter.exceptionlog.info(localexception);
			ugSB.append("group updation failed");
			rtnString=ugSB.toString();
			ugSB.setLength(0);
		} 
		finally
		{
			ugSB=null;
			ugSession.close();
		}
		return rtnString;
	}
	
	
	public String addUsersToGroup(String userNameString,String groupName)
	{
		Session autgSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction autgTx = null;
		String autgString=null;
		try
		{
			autgTx=autgSession.beginTransaction();
			StringTokenizer st=new StringTokenizer(userNameString,",");
			while(st.hasMoreTokens())
			{
				Query autgQuery=autgSession.createSQLQuery("update mdusers set groupname='"+groupName+"' where username='"+st.nextToken()+"'");
				autgQuery.executeUpdate();
			}
			autgTx.commit();
			autgString="users added to group";
		}
		catch(Exception localException)
		{
			MDTransactionWriter.exceptionlog.info(localException);
			autgString="failure while adding users to group";
		}
		finally
		{
			autgSession.close();
		}
		return autgString;
		
	}
	
	public String removeUsersFromGroup(String userNameString)
	{
		Session rufgSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rufgTx = null;
		String rufgString=null;
		try
		{
			rufgTx=rufgSession.beginTransaction();
			StringTokenizer st=new StringTokenizer(userNameString,",");
			while(st.hasMoreTokens())
			{
				Query rufgQuery=rufgSession.createSQLQuery("update mdusers set groupname='null' where username='"+st.nextToken()+"'");
				rufgQuery.executeUpdate();
			}
			rufgTx.commit();
			rufgString="users removed from group";
			
		}
		catch(Exception localException)
		{
			MDTransactionWriter.exceptionlog.info(localException);
			rufgString="failure while removing users from group";
		}
		finally
		{
			rufgSession.close();
		}
		return rufgString;
	}
}





