package com.gwebitsol.core.address;

import java.awt.Image;
import java.io.InputStream;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.imageio.ImageIO;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;
import com.mysql.jdbc.Blob;

@Repository
@Component
public class ImageDao {

	StringBuffer ImageID = new StringBuffer();
	Session gimgSession=MDHibernateUtil.getSessionFactory().openSession();
	Transaction gimgTx = null;	
	PreparedStatement ps = null;
	ResultSet rs = null;
	String sql = null;
	Image img=null;
	public Image getImages(int employeeId,int studentId,int parentId,int schoolBranchId,int schoolId,int structureId,int roomId,int bookId)
	{
		try
		{
			gimgTx=gimgSession.beginTransaction();
			
			if(employeeId==0 && studentId>0 && parentId==0 && schoolBranchId==0 && schoolId==0 && structureId==0 && roomId==0 && bookId==0)
			{
				sql = "select photo from gbl_sm_tbl_student where StudentId='"+studentId+"';";
			}
			else if(employeeId==0 && studentId==0 && parentId>0 && schoolBranchId==0 && schoolId==0 && structureId==0 && roomId==0 && bookId==0)
			{
				sql = "select photo from gbl_sm_tbl_parent where ParentId='"+parentId+"';";
			}
			else if(employeeId>0 && studentId==0 && parentId==0 && schoolBranchId==0 && schoolId==0 && structureId==0 && roomId==0 && bookId==0)
			{
				sql = "select photo from gbl_sm_tbl_staff where EmployeeId='"+employeeId+"';";
			}
			
			else if(employeeId==0 && studentId==0 && parentId==0 && schoolBranchId==0 && schoolId==0 && structureId>0 && roomId==0 && bookId==0)
			{
				sql = "select photo from gbl_sm_tbl_structure where structureId='"+structureId+"';";
			}
			else if(employeeId==0 && studentId==0 && parentId==0 && schoolBranchId>0 && schoolId==0 && structureId==0 && roomId==0 && bookId==0)
			{
				sql = "select image from gbl_sm_tbl_school_branch where schoolBranchId='"+schoolBranchId+"';";
			}
			else if(employeeId==0 && studentId==0 && parentId==0 && schoolBranchId==0 && schoolId>0 && structureId==0 && roomId==0 && bookId==0)
			{
				sql = "select photo from gbl_sm_tbl_school_info where schoolId='"+schoolId+"';";
			}
			else if(employeeId==0 && studentId==0 && parentId==0 && schoolBranchId==0 && schoolId==0 && structureId==0 && roomId>0 && bookId==0)
			{
				sql = "select image from gbl_sm_tbl_room where roomId='"+roomId+"';";
			}
			else if(employeeId==0 && studentId==0 && parentId==0 && schoolBranchId==0 && schoolId==0 && structureId==0 && roomId==0 && bookId>0)
			{
				sql = "select image from gbl_sm_tbl_catalogue where bookId='"+bookId+"';";
			}
			java.sql.Connection connection =gimgSession.connection();
			ps = (PreparedStatement) connection.prepareStatement(sql);
			rs = (ResultSet) ps.executeQuery();
			if (rs.next()) 
			{
				Blob bl=(Blob)rs.getBlob("photo");
				InputStream in=bl.getBinaryStream();
				img = ImageIO.read(in);
			}
			

		}
		catch(Exception localException)
		{
			MDTransactionWriter.exceptionlog.info(localException);
		}
		finally
		{
			gimgTx.commit();
			gimgSession.close();
		}
		return img;

	}

}
