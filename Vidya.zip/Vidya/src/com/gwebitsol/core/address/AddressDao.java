
package com.gwebitsol.core.address;

import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.gwebitsol.core.parent.ParentDao;
import com.gwebitsol.core.security.MDCurrentLoggingsPOJO;
import com.gwebitsol.core.staff.StaffEducationPojo;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

@Repository
@Component

public class AddressDao {

	
	StringBuffer AddressID = new StringBuffer();

	public String addAddress(AddressPojo ap) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String addressreg = null;
		try {
			
			rdTx = rdSession.beginTransaction();

			Integer addrid = (Integer) rdSession.save(ap);
			System.out.println(addrid);
			rdTx.commit();
			AddressID.append("<Address>");
			AddressID.append("\n");
			AddressID.append("<id>");
			AddressID.append("\n");
			AddressID.append(addrid);
			AddressID.append("</id>");
			AddressID.append("\n");
			AddressID.append("</Address>");
			addressreg = AddressID.toString();
		} catch (Exception localException) {

			System.out.println(localException);
			localException.printStackTrace();
			AddressID.append("<Response>");
			AddressID.append("\n");
			AddressID.append("<Result>");
			AddressID.append("\n");
			AddressID.append("Fail");
			AddressID.append("\n");
			AddressID.append("</Result>");
			AddressID.append("\n");
			AddressID.append("<Description>");
			AddressID.append("could not inserted address info");
			AddressID.append("</Description>");
			AddressID.append("\n");
			AddressID.append("<Exception>");
			AddressID.append(localException);
			AddressID.append("</Exception>");
			AddressID.append("</Response>");

			addressreg = AddressID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		} finally {
			rdSession.close();
		}
		return addressreg;
	}

	public String updateAddress(AddressPojo ap, int schoolid,int branchid) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String Addreg = null;
        
		try {
			rdTx = rdSession.beginTransaction();
			
			AddressPojo mdclpojo = (AddressPojo) rdSession.get(AddressPojo.class,ap.getAddressId());
			
			if(branchid==mdclpojo.getBranchId()&&schoolid==mdclpojo.getSchoolId())
				
			rdSession.evict(mdclpojo);
			
			rdSession.update(ap);
				 
			rdTx.commit();

			Addreg = "address is succssfully updated";

			AddressID.append("<Address>");
			AddressID.append("\n");
			AddressID.append(Addreg);
			AddressID.append("</Address>");
			String str = AddressID.toString();
			return str;
		} catch (Exception localException) {
			System.out.println(localException);
			localException.printStackTrace();
			AddressID.append("<Response>");
			AddressID.append("\n");
			AddressID.append("<Result>");
			AddressID.append("\n");
		   	AddressID.append("Fail");
			AddressID.append("\n");
			AddressID.append("</Result>");
			AddressID.append("\n");
			AddressID.append("<Description>");
			AddressID.append("could not updated address info");
			AddressID.append("</Description>");
			AddressID.append("\n");
			AddressID.append("<Exception>");
			AddressID.append(localException);
			AddressID.append("</Exception>");
			AddressID.append("</Response>");

			Addreg = AddressID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		} finally {
			rdSession.close();
		}
		return Addreg;
	}

	public String deleteAddress(int id, int schoolid,int branchid) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String Addrreg = null;

		try {
			
			rdTx = rdSession.beginTransaction();

            AddressPojo mdclpojo = (AddressPojo) rdSession.get(AddressPojo.class,id);
			
            rdSession.evict(mdclpojo);
            
			if(branchid==mdclpojo.getBranchId()&&schoolid==mdclpojo.getSchoolId())
			{
			Query empQuery=rdSession.createSQLQuery("update gbl_sm_tbl_address set isDeleted='y' where AddressId='"+id+"'");
			empQuery.executeUpdate();
			rdTx.commit();
			Addrreg = "address is succssfully deleted";
			AddressID.append("<Address>");
			AddressID.append("\n");
			AddressID.append(Addrreg);
			AddressID.append("</Address>");
			String str = AddressID.toString();
			return str;
			}
			 else
			   {
				 Addrreg = "Address is not deleted";
				 AddressID.append("<Address>");
				 AddressID.append("\n");
				 AddressID.append(Addrreg);
				 AddressID.append("</Address>");
			    String str = AddressID.toString();
			    return str;
			   }
		} catch (Exception localException) {
			System.out.println(localException);
			localException.printStackTrace();
			AddressID.append("<Response>");
			AddressID.append("\n");
			AddressID.append("<Result>");
			AddressID.append("\n");
			AddressID.append("Fail");
			AddressID.append("\n");
			AddressID.append("</Result>");
			AddressID.append("\n");
			AddressID.append("<Description>");
			AddressID.append("could not deleted address info");
			AddressID.append("</Description>");
			AddressID.append("\n");
			AddressID.append("<Exception>");
			AddressID.append(localException);
			AddressID.append("</Exception>");
			AddressID.append("</Response>");

			Addrreg = AddressID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		} finally {
			rdSession.close();
		}
		return Addrreg;
	}

	public String getAddress(int addressId,int schoolid,int branchid,int parentid,int studentid,int staffid) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String addreg = null;
		String gsSql =null;
		try {
			
			rdTx = rdSession.beginTransaction();
			String filterWhere="";
			boolean haveOtherFilter=false;
			if(addressId!=0)
			{
				filterWhere=" and gbl_sm_tbl_address.AddressId='"+addressId+"'";
				haveOtherFilter=true;
			}else
			if(parentid!=0)
			{
				filterWhere=" and gbl_sm_tbl_address.ParentId='"+parentid+"'";
				haveOtherFilter=true;
			}else
			if(studentid!=0)
			{
				filterWhere=" and gbl_sm_tbl_address.StudentId='"+studentid+"'";
				haveOtherFilter=true;
			}else
			if(staffid!=0)
			{
				filterWhere=" and gbl_sm_tbl_address.StaffId='"+staffid+"'";
				haveOtherFilter=true;
			}
			if(branchid!=0)
			{
				if(haveOtherFilter=true)
				{
				filterWhere+=" and gbl_sm_tbl_address.BranchId='"+branchid+"'";
				}else
				{
					filterWhere=" and gbl_sm_tbl_address.ParentId is NULL and gbl_sm_tbl_address.StudentId is null and gbl_sm_tbl_address.StaffId is null and gbl_sm_tbl_address.BranchId='"+branchid+"'";
				}
			}
			
			gsSql="select gbl_sm_tbl_address.* from gbl_sm_tbl_address"
			+" where gbl_sm_tbl_address.IsDeleted is Null and gbl_sm_tbl_address.SchoolId='"+schoolid+"'"+filterWhere+";"; // 
		
			Query gsQuery=rdSession.createSQLQuery(gsSql);
			List gcList=gsQuery.list();
			Iterator gsIT=gcList.iterator();
			
			AddressID.append("<Addresses>");
			AddressID.append("\n");
				while(gsIT.hasNext())
				{
					Object[] mdcArr=(Object[])gsIT.next();
					AddressID.append("<address>");
					AddressID.append("\n");
					AddressID.append("<AddressID>"+mdcArr[0]+"</AddressID>");
					AddressID.append("\n");
					AddressID.append("<parentId>"+mdcArr[1]+"</parentId>");
					AddressID.append("\n");
					AddressID.append("<studentId>" + mdcArr[2]+ "</studentId>");
					AddressID.append("\n");
					AddressID.append("<staffId>" + mdcArr[3]+ "</staffId>");
					AddressID.append("\n");
					AddressID.append("<addressLine1>" + mdcArr[4]+ "</addressLine1>");
					AddressID.append("\n");
					AddressID.append("<addressLine2>" + mdcArr[5] + "</addressLine2>");
					AddressID.append("\n");
					AddressID.append("<street>" +  mdcArr[6]+ "</street>");
					AddressID.append("\n");
					AddressID.append("<villege>" + mdcArr[7] + "</villege>");
					AddressID.append("\n");
					AddressID.append("<mandal>" + mdcArr[8] + "</mandal>");
					AddressID.append("\n");
					AddressID.append("<district>" + mdcArr[9] + "</district>");
					AddressID.append("\n");
					AddressID.append("<state>" + mdcArr[10] + "</state>");
					AddressID.append("\n");
					AddressID.append("<country>" + mdcArr[11]+ "</country>");
					AddressID.append("\n");
					AddressID.append("<pin>" +  mdcArr[12]+ "</pin>");
					AddressID.append("\n");
					AddressID.append("<email>" +  mdcArr[13]+ "</email>");
					AddressID.append("\n");
					AddressID.append("<phone>" +  mdcArr[14] + "</phone>");
					AddressID.append("\n");
					AddressID.append("<remarks>" +  mdcArr[15] + "</remarks>");
					AddressID.append("\n");
					AddressID.append("<createdDate>" +  mdcArr[16] + "</createdDate>");
					AddressID.append("\n");
					AddressID.append("<modifiedDate>" +  mdcArr[17] + "</modifiedDate>");
					AddressID.append("\n");
					AddressID.append("<schoolId>" +  mdcArr[18] + "</schoolId>");
					AddressID.append("\n");
					AddressID.append("<branchId>" +  mdcArr[19] + "</branchId>");
					AddressID.append("\n");
					/*AddressID.append("<branchName>" + mdcArr[30] + "</branchName>");
					AddressID.append("\n");*/
					AddressID.append("<isDeleted>" +  mdcArr[20] + "</isDeleted>");
					AddressID.append("\n");		
					AddressID.append("<addressType>" +  mdcArr[21] + "</addressType>");
					AddressID.append("\n");		
					AddressID.append("</address>");
					AddressID.append("\n");
				}
				rdTx.commit();
				 AddressID.append("</Addresses>");
				 AddressID.append("\n");
			addreg=AddressID.toString();
		} catch (HibernateException localException) {
			System.out.println(localException);
			localException.printStackTrace();
			AddressID.append("<Response>");
			AddressID.append("\n");
			AddressID.append("<Result>");
			AddressID.append("\n");
			AddressID.append("Fail");
			AddressID.append("\n");
			AddressID.append("</Result>");
			AddressID.append("\n");
			AddressID.append("<Description>");
			AddressID.append("could not get address info");
			AddressID.append("</Description>");
			AddressID.append("\n");
			AddressID.append("<Exception>");
			AddressID.append(localException);
			AddressID.append("</Exception>");
			AddressID.append("</Response>");

			addreg = AddressID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		} finally {
			rdSession.close();
		}
		return addreg;
	}

	
	//getall Pagenation
	
	@SuppressWarnings("unused")
	public String getAllAddr(int PNO, int size, int schoolid,int branchid) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String xmlString=null;
		/*Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;*/
		//StringBuffer sb = new StringBuffer();
		try
		{
			rdTx=rdSession.beginTransaction();
			
				int fset = (PNO-1)*size;
				String gsSql ="select count(*) from gbl_sm_tbl_address where gbl_sm_tbl_address.IsDeleted is null and gbl_sm_tbl_address.SchoolId='"
						+ schoolid + "' and gbl_sm_tbl_address.BranchId='" + branchid + "';";
				Query gsQuery=rdSession.createSQLQuery(gsSql);
				Object noRecords= gsQuery.uniqueResult();
				AddressID.append("<Addresses>");
				AddressID.append("\n");
				AddressID.append("<noRecords>"+noRecords+"</noRecords>");
				AddressID.append("\n");
				
					if (PNO > 0 & size > 0){
					gsSql="select * from gbl_sm_tbl_address"
						+" where where gbl_sm_tbl_address.IsDeleted is null and gbl_sm_tbl_address.SchoolId='"+schoolid+"' and gbl_sm_tbl_address.BranchId='"+branchid+"' limit "+size+" offset "+fset+";";} 
					
					else {
						gsSql="select gbl_sm_tbl_address.* from gbl_sm_tbl_address"
						+" where gbl_sm_tbl_address.IsDeleted is null and gbl_sm_tbl_address.SchoolId='"+schoolid+"' and gbl_sm_tbl_address.BranchId='"+branchid+"';";
								
					}	
			
				gsQuery=rdSession.createSQLQuery(gsSql);
				List gcList=gsQuery.list();
				Iterator gsIT=gcList.iterator();
					while(gsIT.hasNext())
					{
						Object[] mdcArr=(Object[])gsIT.next();
						AddressID.append("<address>");
						AddressID.append("\n");
						AddressID.append("<AddressID>"+mdcArr[0]+"</AddressID>");
						AddressID.append("\n");
						AddressID.append("<parentId>"+mdcArr[1]+"</parentId>");
						AddressID.append("\n");
						AddressID.append("<studentId>" + mdcArr[2]+ "</studentId>");
						AddressID.append("\n");
						AddressID.append("<staffId>" + mdcArr[3]+ "</staffId>");
						AddressID.append("\n");
						AddressID.append("<addressLine1>" + mdcArr[4]+ "</addressLine1>");
						AddressID.append("\n");
						AddressID.append("<addressLine2>" + mdcArr[5] + "</addressLine2>");
						AddressID.append("\n");
						AddressID.append("<street>" +  mdcArr[6]+ "</street>");
						AddressID.append("\n");
						AddressID.append("<villege>" + mdcArr[7] + "</villege>");
						AddressID.append("\n");
						AddressID.append("<mandal>" + mdcArr[8] + "</mandal>");
						AddressID.append("\n");
						AddressID.append("<district>" + mdcArr[9] + "</district>");
						AddressID.append("\n");
						AddressID.append("<state>" + mdcArr[10] + "</state>");
						AddressID.append("\n");
						AddressID.append("<country>" + mdcArr[11]+ "</country>");
						AddressID.append("\n");
						AddressID.append("<pin>" +  mdcArr[12]+ "</pin>");
						AddressID.append("\n");
						AddressID.append("<email>" +  mdcArr[13]+ "</email>");
						AddressID.append("\n");
						AddressID.append("<phone>" +  mdcArr[14] + "</phone>");
						AddressID.append("\n");
						AddressID.append("<remarks>" +  mdcArr[15] + "</remarks>");
						AddressID.append("\n");
						AddressID.append("<createdDate>" +  mdcArr[16] + "</createdDate>");
						AddressID.append("\n");
						AddressID.append("<modifiedDate>" +  mdcArr[17] + "</modifiedDate>");
						AddressID.append("\n");
						AddressID.append("<schoolId>" +  mdcArr[18] + "</schoolId>");
						AddressID.append("\n");
						AddressID.append("<branchId>" +  mdcArr[19] + "</branchId>");
						AddressID.append("\n");
						/*AddressID.append("<branchName>" + mdcArr[30] + "</branchName>");
						AddressID.append("\n");*/
						AddressID.append("<isDeleted>" +  mdcArr[20] + "</isDeleted>");
						AddressID.append("\n");		
						AddressID.append("<addressType>" +  mdcArr[21] + "</addressType>");
						AddressID.append("\n");		
						AddressID.append("</address>");
						AddressID.append("\n");
					}
				
			    rdTx.commit();
			    AddressID.append("</Addresses>");
			    AddressID.append("\n");

				xmlString=AddressID.toString();	
		}	
		catch(Exception localException)
		{
			System.out.println(localException);
			localException.printStackTrace();
			AddressID.append("<Response>");
			AddressID.append("\n");
			AddressID.append("<Result>");
			AddressID.append("\n");
			AddressID.append("Fail");
			AddressID.append("\n");
			AddressID.append("</Result>");
			AddressID.append("\n");
			AddressID.append("<Description>");
			AddressID.append("could not get all address info");
			AddressID.append("</Description>");
			AddressID.append("\n");
			AddressID.append("<Exception>");
			AddressID.append(localException);
			AddressID.append("</Exception>");
			AddressID.append("</Response>");

			xmlString = AddressID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		}
		finally
		{
			rdSession.close();
		}	
		return xmlString;

	}
}