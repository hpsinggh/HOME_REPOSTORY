package com.gwebitsol.core.address;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.stereotype.Service;

import com.gwebitsol.core.util.MDTransactionWriter;

@Service
public class ImageService implements ImageServiceIntf {

	@Context
	private HttpServletRequest hsr;
	public Response getImage(int employeeId, int studentId, int parentId,int schoolBranchId,int schoolId,int structureId,int roomId,int bookId,
			int userid,int connectionid, String datastoreName) {
		
		String status = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		InputStream bigInputStream=null;
		final ByteArrayOutputStream out = new ByteArrayOutputStream();
		Long sl = System.currentTimeMillis();

		try {
			
				ImageDao isd = new ImageDao();
				Image image = isd.getImages(employeeId,studentId,parentId,schoolBranchId,schoolId,structureId,roomId,bookId);
				if(image.equals(null))
					status="fail";
				else
					status="success";
				ImageIO.write((BufferedImage) image, "jpg", out);
				final byte[] imgData = out.toByteArray();
				bigInputStream = new ByteArrayInputStream(imgData);
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				MDTransactionWriter.writeLog(datastoreName,"EmpMS","srinu",startDate,endDate,sl,el,status,hsr.getRemoteHost());
				
				return Response.ok(bigInputStream).build();
			
		} catch (Exception localException) {

			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status = "failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

}
