package com.gwebitsol.core.address;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

@Path("/image/")
public interface ImageServiceIntf {

	@Path("/getimg")
	@Produces("image/*")
	@GET
	public Response getImage(@QueryParam("employeeId") int employeeId, @QueryParam("studentId") int studentId,
			@QueryParam("parentId") int parentId,@QueryParam("schoolBranchId") int schoolBranchId,
			@QueryParam("schoolId") int schoolId,@QueryParam("structureId") int structureId,
			@QueryParam("roomId") int roomId,@QueryParam("bookId") int bookId,
			@QueryParam("userid") int userid,
			@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName);

}
