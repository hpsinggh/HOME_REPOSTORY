package com.gwebitsol.core.address;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

@Path("/address/")
public interface AddressServiceIntf {

	@POST
	@Consumes({ "application/xml", "application/json" })
	@Produces({ "application/xml", "application/json" })
	@Path("/addaddress/")
	public Response addAddress(AddressPojo ap, @QueryParam("userid") int userid,
			@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
			@QueryParam("schoolid") int schoolid,@QueryParam("branchid") int branchid);

	@POST
	@Consumes({ "application/xml", "application/json" })
	@Produces({ "application/xml", "application/json" })
	@Path("/updateaddress/")
	public Response updateAddress(AddressPojo ap, @QueryParam("userid") int userid,
			@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
			@QueryParam("schoolid") int schoolid,@QueryParam("branchid") int branchid);

	@POST
	@Consumes({ "application/xml", "application/json" })
	@Produces({ "application/xml", "application/json" })
	@Path("/deleteaddress/")
	public Response deleteAddress(@QueryParam("addressId") int addressId, @QueryParam("userid") int userid,
			@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
			@QueryParam("schoolid") int schoolid,@QueryParam("branchid") int branchid);

	@GET
	@Path("/getaddressById/")
	@Consumes({ "application/xml", "application/json" })
	@Produces({ "application/xml", "application/json" })
	public Response getAddressById(@QueryParam("addressId") int addressId, @QueryParam("userid") int userid,
			@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
			@QueryParam("schoolid") int schoolid,@QueryParam("branchid") int branchid,@QueryParam("parentid") int parentid,@QueryParam("studentid") int studentid,@QueryParam("staffid") int staffid);

	
	// pagenation

	@Path("/getalladdr/")
	@GET
	@Consumes({ "application/xml", "application/json" })
	@Produces({ "application/xml", "application/json" })
	public Response getAllAddresses(@QueryParam("userid") int userid, @QueryParam("connectionid") int connectionid,
			@QueryParam("datastoreName") String datastoreName, @QueryParam("PNO") int PNO, @QueryParam("size") int size,
			@QueryParam("schoolid") int schoolid,@QueryParam("branchid") int branchid);

}
