package com.gwebitsol.core.security;

import java.util.Date;

public class MDGenerateConnectionID
{
	public String generateConnectionID(String hostIP,String userName,Date date)
	{
		//from these three parameters we have to generate a random number
		//this random number will work as a connection id
		
		return "";
	}
}
