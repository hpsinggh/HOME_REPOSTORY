package com.gwebitsol.core.security;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.auth.MDGetPrivilegesDAO;
import com.gwebitsol.core.usermanagement.MDLoginInput;
import com.gwebitsol.core.util.MDEncryptDecryptManager;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class MDConnectionManagementDAO {

	@SuppressWarnings({ "deprecation", "rawtypes" })

	public String validateLogin(MDLoginInput loginInput) {
		Session vuSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction vuTx = null;
		String loginOutPut = null;
		int logAttempts = 0;
		int userID = 0;
		int connectionID = 0;

		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String logindatetime = dateFormat.format(date);

		Calendar cal = Calendar.getInstance();
		cal.getTime();
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
		String time = sdf.format(cal.getTime());

		String username = loginInput.getUsername();
		String password = loginInput.getPassword();
		String branchname = loginInput.getBranchName();
		String schoolname = loginInput.getSchoolName();

		StringBuffer cmSB = new StringBuffer();
		MDEncryptDecryptManager enObj = new MDEncryptDecryptManager();
		String pwd = enObj.getEncryptedContent(password);

		try {

			vuTx = vuSession.beginTransaction();

			Integer sclId = (Integer) vuSession
					.createSQLQuery("select SchoolId from gbl_sm_tbl_school_info where SchoolName='" + schoolname + "'")
					.uniqueResult();

			Integer branId = (Integer) vuSession
					.createSQLQuery("select SchoolBranchId from gbl_sm_tbl_school_branch where BranchName='"
							+ branchname + "' and SchoolId='" + sclId + "'")
					.uniqueResult();

			String stat = (String) vuSession
					.createSQLQuery("select status from mdusers where username='" + username + "'").uniqueResult();
			if (stat.equalsIgnoreCase("deleted")) {
				cmSB.append("<loginOutput>");
				cmSB.append("\n");
				cmSB.append("<status>This User has been deleted.Contact The Administrator</status>");
				cmSB.append("\n");
				cmSB.append("</loginOutput>");
			} else {
				List list = vuSession.createSQLQuery("select * from mdusers where username='" + username + "'").list();
				if (list.isEmpty()) {
					cmSB.append("<loginOutput>");
					cmSB.append("\n");
					cmSB.append("<status>Either username or password is wrong </status>");
					cmSB.append("\n");
					cmSB.append("</loginOutput>");

				} else {
					Integer uid = (Integer) vuSession.createSQLQuery("select userid from mdusers where username='"
							+ username + "' and password='" + pwd + "' and status='active'" + " and BranchId='" + branId
							+ "' and SchoolId='" + sclId + "'").uniqueResult();

					if (uid != null)

					{
						userID = uid;
						String status = (String) vuSession
								.createSQLQuery("select status from mdcurrentloggings where userid=" + uid)
								.uniqueResult();

						if (status != null) {
							cmSB.append("<loginOutput>");
							cmSB.append("\n");
							cmSB.append("<status>user already logged in somewhere</status>");
							cmSB.append("\n");
							cmSB.append("</loginOutput>");
						} else {

							connectionID = (Integer
									.parseInt(time.substring(0, 2) + time.substring(3, 5) + time.substring(6) + uid));
							MDCurrentLoggingsPOJO mdcl = new MDCurrentLoggingsPOJO();
							mdcl.setUserID(uid);
							mdcl.setStatus("loggedIn");
							mdcl.setLoginDateTime(logindatetime);
							mdcl.setConnectionID(connectionID);
							vuSession.save(mdcl);

							cmSB.append("<loginOutput>");
							cmSB.append("\n");
							cmSB.append("<status>success</status>");
							cmSB.append("\n");
							cmSB.append("<userID>" + userID + "</userID>");
							cmSB.append("\n");
							cmSB.append("<connectionID>" + connectionID + "</connectionID>");
							cmSB.append("\n");
							cmSB.append("<datastoreName>" + loginInput.getDatastoreName() + "</datastoreName>");
							cmSB.append("\n");
							cmSB.append("<branchId>" + branId + "</branchId>");
							cmSB.append("\n");
							cmSB.append("<schoolId>" + sclId + "</schoolId>");
							cmSB.append("\n");
							String Sql = null;

							Sql = "select ROLESTRING from mdusers where USERID='" + uid + "'";
							String role = (String) vuSession.createSQLQuery(Sql).uniqueResult();

							MDGetPrivilegesDAO mpd = new MDGetPrivilegesDAO();
							HashMap<String, String> privi = mpd.getPrivilegesMap(role);

							for (Map.Entry entry : privi.entrySet()) {
								System.out.print(entry.getKey() + " : " + entry.getValue());
								cmSB.append("<item id='" + entry.getKey() + "'>" + entry.getValue() + "</item>");
								cmSB.append("\n");
							}

							// String privivalue = privi.get(key)

							/*
							 * Sql =
							 * "select ROLEID from mdrole where ROLENAME='" +
							 * role + "';"; Integer rid = (Integer)
							 * vuSession.createSQLQuery(Sql).uniqueResult();
							 * 
							 * String cmSql =
							 * "SELECT * FROM MDFOLDER WHERE PARENTFOLDERID=1 AND ACL LIKE '%R#"
							 * + rid + ":1%'" +
							 * " AND FOLDERTYPE='M' ORDER BY FOLDERID ASC";
							 * Query cmQuery =
							 * vuSession.createSQLQuery(cmSql).addScalar(
							 * "FolderID", Hibernate.INTEGER)
							 * .addScalar("FolderName", Hibernate.STRING); List
							 * cmList = cmQuery.list(); Iterator it =
							 * cmList.iterator();
							 * 
							 * while (it.hasNext()) { Object[] cmObj =
							 * (Object[]) it.next();
							 * 
							 * cmSB.append("<item id='" + cmObj[0] + "'>" +
							 * cmObj[1] + "</item>"); cmSB.append("\n");
							 * 
							 * }
							 */
							cmSB.append("</loginOutput>");

							/*
							 * if (uid == 1) {
							 * 
							 * String cmSql =
							 * "SELECT * FROM MDFOLDER WHERE PARENTFOLDERID=1 AND ACL LIKE '%U#"
							 * + uid + ":1%'" +
							 * " AND FOLDERTYPE='M' ORDER BY FOLDERID ASC";
							 * Query cmQuery =
							 * vuSession.createSQLQuery(cmSql).addScalar(
							 * "FolderID", Hibernate.INTEGER)
							 * .addScalar("FolderName", Hibernate.STRING); List
							 * cmList = cmQuery.list(); Iterator it =
							 * cmList.iterator(); while (it.hasNext()) {
							 * Object[] cmObj = (Object[]) it.next();
							 * 
							 * cmSB.append("<item id='" + cmObj[0] + "'>" +
							 * cmObj[1] + "</item>"); cmSB.append("\n");
							 * 
							 * } cmSB.append("</loginOutput>"); } else {
							 */

						}
					}

					else {
						Integer loginattempts = (Integer) vuSession
								.createSQLQuery("select loginattempts from mdusers where username='" + username
										+ "' and status!='locked' and status!='deleted'")
								.uniqueResult();

						System.out.println("loginattempts---" + loginattempts);

						if (loginattempts != null) {
							logAttempts = loginattempts + 1;
							System.out.println("logAttempts---" + logAttempts);
							if (logAttempts == 4) {
								System.out.println("in if block logattempts=4");

								Query cmQuery1 = vuSession
										.createSQLQuery("update mdusers set status='locked',loginattempts="
												+ logAttempts + " where username='" + username + "'");
								cmQuery1.executeUpdate();

								cmSB.append("<loginOutput>");
								cmSB.append("\n");
								cmSB.append("<status>Account locked.Contact The Administrator</status>");
								cmSB.append("\n");
								cmSB.append("</loginOutput>");

							} else if (logAttempts < 4)

							{
								System.out.println("in if block logattempts<4");
								Query cmQuery2 = vuSession.createSQLQuery("update mdusers set loginattempts="
										+ logAttempts + " where username='" + username + "'");
								cmQuery2.executeUpdate();

								cmSB.append("<loginOutput>");
								cmSB.append("\n");
								cmSB.append("<status>Either username or password is wrong </status>");
								cmSB.append("\n");
								cmSB.append("</loginOutput>");
							}
						} else {
							cmSB.append("<loginOutput>");
							cmSB.append("\n");
							cmSB.append("<status>You cant login.Contact The Administrator</status>");
							cmSB.append("\n");
							cmSB.append("</loginOutput>");
						}
					}
				}
			}
			loginOutPut = cmSB.toString();
			vuTx.commit();
		}

		catch (Exception localException) {
			vuTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			loginOutPut = "fail";
			cmSB = null;
		}

		finally {
			vuSession.close();
			cmSB = null;
		}
		return loginOutPut;

	}

	public String forceLogin(MDLoginInput loginInput, String hostIP) {
		Session flSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction flTx = null;
		String outStr = null;
		String response = null;

		String username = loginInput.getUsername();
		String password = loginInput.getPassword();

		MDEncryptDecryptManager enObj = new MDEncryptDecryptManager();
		String pwd = enObj.getEncryptedContent(password);

		try {
			flTx = flSession.beginTransaction();
			Integer uid = (Integer) flSession.createSQLQuery("select userid from mdusers where username='" + username
					+ "' and password='" + pwd + "' and status='active'").uniqueResult();

			MDConnectionManagementDAO mdcm = new MDConnectionManagementDAO();
			String status = mdcm.userLogout(uid, hostIP);

			if (status.equalsIgnoreCase("you are logged out successfully")) {
				response = mdcm.validateLogin(loginInput);
			}
			outStr = response;
			flTx.commit();
		} catch (Exception localException) {
			flTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			outStr = "fail";
		} finally {
			flSession.close();
		}
		return outStr;
	}

	@SuppressWarnings("rawtypes")
	public String getLoginDetails(MDLoginInput loginInput, String hostIP) {
		Session flSession = MDHibernateUtil.getSessionFactory().openSession();
		String loginDetails = null;

		StringBuffer cmSB = new StringBuffer();
		String username = loginInput.getUsername();
		String password = loginInput.getPassword();

		MDEncryptDecryptManager enObj = new MDEncryptDecryptManager();
		String pwd = enObj.getEncryptedContent(password);
		try {
			Integer uid = (Integer) flSession.createSQLQuery("select userid from mdusers where username='" + username
					+ "' and password='" + pwd + "' and status='active'").uniqueResult();

			if (uid != null) {
				String cmSql = "select * from mdcurrentloggings where userid='" + uid + "'";
				Query cmQuery = flSession.createSQLQuery(cmSql);
				List cmList = cmQuery.list();
				Iterator it = cmList.iterator();
				cmSB.append("<logindetails>");
				while (it.hasNext()) {
					Object[] cmObj = (Object[]) it.next();
					cmSB.append("<userID>" + cmObj[1] + "</userID>");
					cmSB.append("\n");
					cmSB.append("<Status>" + cmObj[2] + "</Status>");
					cmSB.append("\n");
					cmSB.append("<LoginDateTime>" + cmObj[3] + "</LoginDateTime>");
					cmSB.append("\n");
					cmSB.append("<connectionID>" + cmObj[4] + "</connectionID>");
				}
				cmSB.append("</logindetails>");
				loginDetails = cmSB.toString();
			}
		} catch (Exception localException) {
			MDTransactionWriter.exceptionlog.info(localException);
			loginDetails = "fail";
		} finally {
			flSession.close();
		}
		return loginDetails;
	}

	public String userLogout(int userID, String hostIP) {
		Session ulSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction ulTx = null;
		String outStr = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String logoutdatetime = dateFormat.format(date);
		System.out.println(logoutdatetime);
		try {
			ulTx = ulSession.beginTransaction();

			String username = (String) ulSession.createSQLQuery("select username from mdusers where userid=" + userID)
					.uniqueResult();

			String logindatetime = (String) ulSession
					.createSQLQuery("select logindatetime from mdcurrentloggings where userid=" + userID)
					.uniqueResult();

			String ulSql = "insert into mdloginhistory(loginid,loginusername,logindatetime,hostip,logoutdatetime) values("
					+ userID + ",'" + username + "','" + logindatetime + "','" + hostIP + "','" + logoutdatetime + "')";
			Query ulQuery = ulSession.createSQLQuery(ulSql);
			ulQuery.executeUpdate();

			Query ulQuery1 = ulSession.createSQLQuery("update mdusers set loginattempts=0 where userid=" + userID);
			ulQuery1.executeUpdate();

			Query ulQuery2 = ulSession.createSQLQuery("delete from mdcurrentloggings where userid=" + userID);
			ulQuery2.executeUpdate();

			ulTx.commit();
			outStr = "you are logged out successfully";

		} catch (Exception localException) {
			ulTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			outStr = "error occured while logging out";
		} finally {
			ulSession.close();
		}
		return outStr;
	}

	@SuppressWarnings("rawtypes")
	public String userLoginHistory(int indexID, int userID) {
		Session ulhSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction ulhTx = null;
		String outStr = null;
		StringBuffer ulhSB = new StringBuffer();
		try {
			ulhTx = ulhSession.beginTransaction();
			String ulhSql = "select * from mdloginhistory where loginid=" + userID + " order by indexid desc limit "
					+ indexID + ",10";
			Query ulhQuery = ulhSession.createSQLQuery(ulhSql);

			List ulhList = ulhQuery.list();
			Iterator ulhIT = ulhList.iterator();

			ulhSB.append("<loginDetail>");
			ulhSB.append("\n");
			while (ulhIT.hasNext()) {
				Object[] ulhObj = (Object[]) ulhIT.next();
				ulhSB.append("<indexID>" + ulhObj[0] + "</indexID>");
				ulhSB.append("\n");
				ulhSB.append("<loginUserName>" + ulhObj[2] + "</loginUserName>");
				ulhSB.append("\n");
				ulhSB.append("<loginDateTime>" + ulhObj[3] + "</loginDateTime>");
				ulhSB.append("\n");
				ulhSB.append("<hostIP>" + ulhObj[4] + "</hostIP>");
				ulhSB.append("\n");
				ulhSB.append("<logoutDateTime>" + ulhObj[5] + "</logoutDateTime>");
				ulhSB.append("\n");
			}
			ulhSB.append("</loginDetail>");
			ulhSB.append("\n");
			outStr = ulhSB.toString();
			ulhTx.commit();

		} catch (Exception localException) {
			ulhTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			outStr = "fail";
			ulhSB = null;
		} finally {
			ulhSB = null;
			ulhSession.close();
		}
		return outStr;
	}
}
