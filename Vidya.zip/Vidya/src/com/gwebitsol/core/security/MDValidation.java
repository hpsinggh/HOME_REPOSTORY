package com.gwebitsol.core.security;

public class MDValidation {

	 int varified = 0;
	public int allvalidations(int userid, int connectionid, String datastoreName,int schoolid,int branchId) 
	{
	/*	MDGetUserFromID mdgufid = new MDGetUserFromID();
		String requester = mdgufid.getUserName(userid);*/
        System.out.println("------------------------------------------------------------------");
		System.out.println(connectionid);
		MDVerifyConnectionID mdvcid = new MDVerifyConnectionID();
		int ret = mdvcid.verifyConnectionID(userid, connectionid);

		MDVerifyDatastoreName mdvdsn = new MDVerifyDatastoreName();
		int rtVal = mdvdsn.verifyDatastoreName(datastoreName);
		
		MDVerifyCompany mdvbid = new MDVerifyCompany();
		int scbr = mdvbid.verifyBranchID(schoolid,branchId);
   
		if(ret==1&&rtVal==1&&scbr==1)
		{
			varified=1;
		}
		/*System.out.println("request making user:: " + requester);*/
		System.out.println("connectionid verification value:: " + ret);
		System.out.println("datastore verification value :: " + rtVal);
		System.out.println("branch and school verification value:: " + scbr);

		return varified;
		
	}
}
