package com.gwebitsol.core.security;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class MDVerifyDatastoreName 
{
	@SuppressWarnings({ "deprecation", "rawtypes" })
	public int verifyDatastoreName(String dataStoreName)
	{
		int rtVal=0;
		Session vdnSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction vdnTx = null;
		String datastoreName=null;
		
		try
		{
			vdnTx=vdnSession.beginTransaction();
			System.out.println(dataStoreName);
			
			String aiSql="select * from mddatastore where DATASTORENAME='"+dataStoreName+"'";
			Query objQuery=vdnSession.createSQLQuery(aiSql).addScalar("DATASTOREID",Hibernate.INTEGER).addScalar("DATASTORENAME",Hibernate.STRING);
			List objList=objQuery.list();
			Iterator it=objList.iterator();
			
			while(it.hasNext())
			{
				Object[] obj=(Object[])it.next();
				datastoreName=(String)obj[1];
			}
			if(datastoreName!=null)
			{
				rtVal=1;
			}
			vdnTx.commit();
			
		}
		catch(Exception localException)
		{
			vdnTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
		}
		finally
		{
			vdnSession.close();
		}
		
		return rtVal;
	}

}
