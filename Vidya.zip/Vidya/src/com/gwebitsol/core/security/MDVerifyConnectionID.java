package com.gwebitsol.core.security;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class MDVerifyConnectionID 
{
	public int verifyConnectionID(int userID,int connectionID)
	{
		int ret=0;
		Session vcSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction vcTx = null;
		int conID=0;
		try
		{
			vcTx=vcSession.beginTransaction();
			System.out.println(connectionID);
			
			String vcSql="select sno from mdcurrentloggings where userid="+userID;
			int sno=(Integer)vcSession.createSQLQuery(vcSql).uniqueResult();
			
			MDCurrentLoggingsPOJO mdclpojo = (MDCurrentLoggingsPOJO)vcSession.load(MDCurrentLoggingsPOJO.class,sno);
			conID=mdclpojo.getConnectionID();
			
			System.out.println(conID); 
			 
			if(conID==connectionID)
			{
				ret=1;
			}
			vcTx.commit();
			
		}
		catch(Exception localException)
		{
			vcTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
		}
		finally
		{
			vcSession.close();
		}
		
		return ret;
	}
}
