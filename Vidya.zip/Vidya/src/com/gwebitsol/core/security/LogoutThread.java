package com.gwebitsol.core.security;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class LogoutThread implements Runnable
{
	Session ltSession=MDHibernateUtil.getSessionFactory().openSession();
	Transaction ltTx=null;
	DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	Date date = new Date();
	String logoutdatetime=format.format(date);
	long loginTime = 0;
	@SuppressWarnings({ "deprecation", "rawtypes" })
	public void run() 
	{
		try
		{
			while(true)
			{
				ltTx=ltSession.beginTransaction();
				String ltSql="select * from mdcurrentloggings";
				Query ltQuery=ltSession.createSQLQuery(ltSql).addScalar("sno",Hibernate.INTEGER)
						.addScalar("userid",Hibernate.INTEGER).addScalar("status",Hibernate.STRING).addScalar("logindatetime",Hibernate.STRING);
				List ltList=ltQuery.list();
				Iterator ltIT=ltList.iterator();
				while(ltIT.hasNext())
				{
						Object[] obj=(Object[])ltIT.next();
						int userID=(Integer)obj[1];
						String logindatetime=(String)obj[3];
					
			    	
			    	    Date date = format.parse(logindatetime);
			    	    loginTime = date.getTime();
			    	
			    
				    	long curTime = System.currentTimeMillis();
				    	long diff = curTime- loginTime;
				    	System.out.println(diff);
				    	
							if(diff>32400000)
							{	
								String username=(String)ltSession.createSQLQuery("select username from mdusers where userid="+userID).uniqueResult();
								
								String ltSql1="insert into mdloginhistory(loginid,loginusername,logindatetime,hostip,logoutdatetime) values("+userID+",'"+username+"','"+logindatetime+"','adminIP','"+logoutdatetime+"')";
								Query ltQuery1=ltSession.createSQLQuery(ltSql1);
								ltQuery1.executeUpdate();
								
								Query ulQuery2=ltSession.createSQLQuery("update mdusers set loginattempts=0 where userid="+userID);
								ulQuery2.executeUpdate();

								Query ltQuery2=ltSession.createSQLQuery("delete from mdcurrentloggings where userid="+userID);
								ltQuery2.executeUpdate();
							}
				}	
				 	ltTx.commit();
					Thread.sleep(1000000);
		
			}
		}
		catch(Exception localException)
		{
			MDTransactionWriter.exceptionlog.info(localException);
		}
		
		finally
		{
		ltSession.close();
		}
	}

}
