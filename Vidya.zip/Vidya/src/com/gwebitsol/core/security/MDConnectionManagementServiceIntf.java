package com.gwebitsol.core.security;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

import com.gwebitsol.core.usermanagement.MDLoginInput;


@Path("/connection/")
public interface MDConnectionManagementServiceIntf 
{
	@Path("/login/")
	@POST
	@Consumes({"application/xml", "application/json"})
	@Produces({"application/xml", "application/json"})
	public Response login(MDLoginInput mdlogininput);
	
	@Path("/forcelogin/")
	@POST
	@Consumes({"application/xml", "application/json"})
	@Produces({"application/xml", "application/json"})
	public Response forceLogin(MDLoginInput mdlogininput);
	
	@Path("/getlogindetails/")
	@POST
	@Consumes({"application/xml", "application/json"})
	@Produces({"application/xml", "application/json"})
	public Response getLoginDetails(MDLoginInput mdlogininput);
	
	@Path("/logout")
	@POST
	@Produces({"application/xml", "application/json"})
	public Response logout(@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@Path("/loginhistory/")
	@POST
	@Consumes({"application/xml", "application/json"})
	@Produces({"application/xml", "application/json"})
	public Response loginHistory(@QueryParam("userid") int userid,@QueryParam("indexid") int indexid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
}
