package com.gwebitsol.core.security;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class MDVerifyCompany {

	public int verifyBranchID (int schoolid,int branchId)
	{
		Session vcSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction vcTx = null;
		int brVal =0;
		
		try
		{
			vcTx=vcSession.beginTransaction();
			System.out.println(branchId);
			
			Integer branId =(Integer)vcSession.createSQLQuery("select SchoolBranchId from gbl_sm_tbl_school_branch where SchoolBranchId='"+branchId+"'").uniqueResult(); 
    		
        	Integer SclId =(Integer)vcSession.createSQLQuery("select SchoolId from gbl_sm_tbl_school_info where SchoolId='"+schoolid+"'").uniqueResult(); 
    		
        /*		
			String aiSql="select BrnchId,SchoolId from gbl_sm_tbl_staff where BranchId='"+branchId+"'";
			Query objQuery=vcSession.createSQLQuery(aiSql).addScalar("BranchId",Hibernate.INTEGER).addScalar("SchoolName",Hibernate.STRING);
			List objList=objQuery.list();
			Iterator it=objList.iterator();
			while(it.hasNext())
			{
				Object[] obj=(Object[])it.next();
				branchId=(Integer) obj[1];
				schoolid = (Integer) obj[2];
			}*/
        	if(SclId==schoolid&&branId==branchId)
			{
				brVal=1;
			}
			vcTx.commit();
			
		}
		catch(Exception localException)
		{
			vcTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
		}
		finally
		{
			vcSession.close();
		}
		
		return brVal;
	}
}
