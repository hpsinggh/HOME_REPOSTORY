package com.gwebitsol.core.security;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.gwebitsol.core.security.MDConnectionManagementServiceIntf;
import com.gwebitsol.core.usermanagement.MDGetUserFromID;
import com.gwebitsol.core.usermanagement.MDLoginInput;
import com.gwebitsol.core.util.MDTransactionWriter;

public class MDConnectionManagementService implements MDConnectionManagementServiceIntf
{
	@Context private HttpServletRequest hsr;
	public Response login(MDLoginInput mdlogininput)
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
	{
			
			String requester=mdlogininput.getUsername();
			String datastoreName=mdlogininput.getDatastoreName();
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			if(rtVal==1)
			{

			MDConnectionManagementDAO cmDAO=new MDConnectionManagementDAO();
			XMLString=cmDAO.validateLogin(mdlogininput);
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			statusStr="user validation successfull";
			MDTransactionWriter.writeLog(datastoreName,"CMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
	
			}
			else
			{
				XMLString="Given datastore name is either wrong or it has not been registered till now...";
			}
	}
	catch(Exception localException)
	{
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
		statusStr="failed in service layer";
	}
			return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}

	public Response forceLogin(MDLoginInput mdLoginInput) 
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			String requester=mdLoginInput.getUsername();
			String datastoreName=mdLoginInput.getDatastoreName();
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			if(rtVal==1)
			{

			MDConnectionManagementDAO cmDAO=new MDConnectionManagementDAO();
			XMLString=cmDAO.forceLogin(mdLoginInput,hsr.getRemoteHost());
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			statusStr="user validation successfull";
			MDTransactionWriter.writeLog(datastoreName,"CMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			
			}
			else
			{
				XMLString="Given datastore name is either wrong or it has not been registered till now...";
			}
		
		}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			XMLString="failed in service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}
	
	
	public Response getLoginDetails(MDLoginInput mdLoginInput) 
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			String requester=mdLoginInput.getUsername();
			String datastoreName=mdLoginInput.getDatastoreName();
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			if(rtVal==1)
			{

			MDConnectionManagementDAO cmDAO=new MDConnectionManagementDAO();
			XMLString=cmDAO.getLoginDetails(mdLoginInput,hsr.getRemoteHost());
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			statusStr="user validation successfull";
			MDTransactionWriter.writeLog(datastoreName,"CMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			
			}
			else
			{
				XMLString="Given datastore name is either wrong or it has not been registered till now...";
			}
		
		}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			XMLString="failed in service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}
	

	
	public Response logout(int userID,int connectionID,String datastoreName)
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			/*System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 && rtVal==1)
			{*/

				MDConnectionManagementDAO cmDAO=new MDConnectionManagementDAO();
				XMLString=cmDAO.userLogout(userID,hsr.getRemoteHost());
				if(XMLString.equals("error occured while logging out"))
					statusStr="failed";
				else
					statusStr="success";	
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				MDTransactionWriter.writeLog(datastoreName,"CMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			/*}
			else
			{
				XMLString="you are not authorised user";
			}*/
		}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			XMLString="failed in service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();

	}

	public Response loginHistory(int userID,int indexid,int connectionID,String datastoreName) 
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
				MDConnectionManagementDAO cmDAO=new MDConnectionManagementDAO();
				XMLString=cmDAO.userLoginHistory(indexid,userID);
				if(XMLString.equals("fail"))
					statusStr="failed";
				else
					statusStr="success";	
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				MDTransactionWriter.writeLog(datastoreName,"CMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}
		}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			XMLString="failed in service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();

	}

	
	
	
}
