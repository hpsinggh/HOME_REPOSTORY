package com.gwebitsol.core.suggestion;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;
@Path("/suggestion/")
public interface MDSuggestionManagementServiceIntrf {
	
	@Path("/reportAProblem/")
	@POST
	@Consumes({"application/xml", "application/json"})
	@Produces({"application/xml", "application/json"})
	public Response reportAProblem(MDSuggestionPOJO pojo);
	@Path("/askAQuestion/")
	@POST
	@Consumes({"application/xml", "application/json"})
	@Produces({"application/xml", "application/json"})
	public Response askAQuestion(MDSuggestionPOJO pojo);
	@Path("/shareAnIdea/")
	@POST
	@Consumes({"application/xml", "application/json"})
	@Produces({"application/xml", "application/json"})
	public Response shareAnIdea(MDSuggestionPOJO pojo);

}
