package com.gwebitsol.core.suggestion;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class MDSuggestionDAO 
{
	private static Logger transactionlog=Logger.getLogger("transactionLog");
	public String save(MDSuggestionPOJO pojo)
	{
		Session session = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		String output=null;
		
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String logindatetime=dateFormat.format(date);
		try{
			transactionlog.info("begin in MDSuggestionDAO.save()"+logindatetime);
				tx=session.beginTransaction();
				session.save(pojo);
				output="success";
		}

		catch(Exception localException)
		{
			tx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			output="fail";
		}
		
		finally
		{
			session.close();
		}
		return output;

	}
	
}
