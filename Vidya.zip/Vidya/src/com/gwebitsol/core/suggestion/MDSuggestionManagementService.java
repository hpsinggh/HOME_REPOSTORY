package com.gwebitsol.core.suggestion;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.gwebitsol.core.util.MailSender;

public class MDSuggestionManagementService implements
		MDSuggestionManagementServiceIntrf {
	
	private String toEmail;
	public void setToEmail(String toEmail) {
		this.toEmail = toEmail;
	}

	public Response reportAProblem(MDSuggestionPOJO pojo) {
		pojo.setToEmail(toEmail);
		MDSuggestionDAO dao=new MDSuggestionDAO();
		String output=dao.save(pojo);
		if(output.equalsIgnoreCase("success")){
		Boolean status=	MailSender.sendMail(pojo.getToEmail(), pojo.getSuggestionType(), pojo.getPost(),pojo.getFromEmail());
		if(status=true){
			MailSender.sendMail(pojo.getFromEmail(), pojo.getSuggestionType(), "Thanks for using Report a problem.your Report has been sent to Administrator they will get back you Shortly.",pojo.getToEmail());
			return	Response.ok().type(MediaType.APPLICATION_XML).entity("<Response>success</Response>").build();
		}else{
			return	Response.status(Status.EXPECTATION_FAILED).type(MediaType.APPLICATION_XML).entity("<Response>fail</Response>").build();
		}
		}
        	return	Response.status(Status.EXPECTATION_FAILED).type(MediaType.APPLICATION_XML).entity("<Response>fail</Response>").build();
	}

	public Response askAQuestion(MDSuggestionPOJO pojo) {
		pojo.setToEmail(toEmail);
		MDSuggestionDAO dao=new MDSuggestionDAO();
		String output=dao.save(pojo);
		if(output.equalsIgnoreCase("success")){
		Boolean status=	MailSender.sendMail(pojo.getToEmail(), pojo.getSuggestionType(), pojo.getPost(),pojo.getFromEmail());
		if(status=true){
			MailSender.sendMail(pojo.getFromEmail(), pojo.getSuggestionType(), "Thank you for writing to Meldit and providing us the opportunity to assist you.",pojo.getToEmail());
			return	Response.ok().type(MediaType.APPLICATION_XML).entity("<Response>success</Response>").build();
		}else{
			return	Response.status(Status.EXPECTATION_FAILED).type(MediaType.APPLICATION_XML).entity("<Response>fail</Response>").build();
		}
		}
        	return	Response.status(Status.EXPECTATION_FAILED).type(MediaType.APPLICATION_XML).entity("<Response>fail</Response>").build();
	}

	public Response shareAnIdea(MDSuggestionPOJO pojo) {
		pojo.setToEmail(toEmail);
		MDSuggestionDAO dao=new MDSuggestionDAO();
		String output=dao.save(pojo);
		if(output.equalsIgnoreCase("success")){
		Boolean status=	MailSender.sendMail(pojo.getToEmail(), pojo.getSuggestionType(), pojo.getPost(),pojo.getFromEmail());
		if(status=true){
			MailSender.sendMail(pojo.getFromEmail(), pojo.getSuggestionType(), "Thanks for your idea, we will validate it and will get back you shortly",pojo.getToEmail());
			return	Response.ok().type(MediaType.APPLICATION_XML).entity("<Response>success</Response>").build();
		}else{
			return	Response.status(Status.EXPECTATION_FAILED).type(MediaType.APPLICATION_XML).entity("<Response>fail</Response>").build();
		}
		}
        	return	Response.status(Status.EXPECTATION_FAILED).type(MediaType.APPLICATION_XML).entity("<Response>fail</Response>").build();
	}

}
