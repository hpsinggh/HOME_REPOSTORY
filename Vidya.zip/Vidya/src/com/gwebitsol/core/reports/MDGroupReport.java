package com.gwebitsol.core.reports;

public class MDGroupReport {

}
