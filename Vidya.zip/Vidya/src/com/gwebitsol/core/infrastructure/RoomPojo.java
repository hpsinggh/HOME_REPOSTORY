
package com.gwebitsol.core.infrastructure;


import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.stereotype.Component;

@XmlRootElement(name="Room")
@Component
public class RoomPojo {
	private int roomId;
	private int floorId;
	private int roomTypeId;
	private int numberOfRows;
	private int numberOfColumns;
	private int numberOfSeatsPerRow;
	private int roomNo;
	private String roomName;
	private String roomDescription;
	private String aC;
	private int capacity;
	private String size;
	private String status;
	private String remarks;
	private int seatingNo;
	private int colnoRowSeats;
	private String allowAisles;
	private byte[] image;
	private int schoolId;
	private int branchId;
	private int seatingTypeId;
	private int structureId;
	
	public int getColnoRowSeats() {
		return colnoRowSeats;
	}
	public void setColnoRowSeats(int colnoRowSeats) {
		this.colnoRowSeats = colnoRowSeats;
	}
	public String getAllowAisles() {
		return allowAisles;
	}
	public void setAllowAisles(String allowAisles) {
		this.allowAisles = allowAisles;
	}
	
	public int getRoomId() {
		return roomId;
	}
	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}
	public int getFloorId() {
		return floorId;
	}
	public void setFloorId(int floorId) {
		this.floorId = floorId;
	}
	public int getRoomTypeId() {
		return roomTypeId;
	}
	public void setRoomTypeId(int roomTypeId) {
		this.roomTypeId = roomTypeId;
	}
	public int getRoomNo() {
		return roomNo;
	}
	public void setRoomNo(int roomNo) {
		this.roomNo = roomNo;
	}
	public String getRoomName() {
		return roomName;
	}
	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}
	public String getRoomDescription() {
		return roomDescription;
	}
	public void setRoomDescription(String roomDescription) {
		this.roomDescription = roomDescription;
	}
	public String getaC() {
		return aC;
	}
	public void setaC(String aC) {
		this.aC = aC;
	}
	public int getCapacity() {
		return capacity;
	}
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	public String getSize() {
		return size;
	}
	public void setSize(String size) {
		this.size = size;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public int getSeatingNo() {
		return seatingNo;
	}
	public void setSeatingNo(int seatingNo) {
		this.seatingNo = seatingNo;
	}
	public int getNumberOfRows() {
		return numberOfRows;
	}
	public void setNumberOfRows(int numberOfRows) {
		this.numberOfRows = numberOfRows;
	}
	public int getNumberOfColumns() {
		return numberOfColumns;
	}
	public void setNumberOfColumns(int numberOfColumns) {
		this.numberOfColumns = numberOfColumns;
	}
	public int getNumberOfSeatsPerRow() {
		return numberOfSeatsPerRow;
	}
	public void setNumberOfSeatsPerRow(int numberOfSeatsPerRow) {
		this.numberOfSeatsPerRow = numberOfSeatsPerRow;
	}
	public byte[] getImage() {
		return image;
	}
	public void setImage(byte[] image) {
		this.image = image;
	}
	public int getSchoolId() {
		return schoolId;
	}
	public void setSchoolId(int schoolId) {
		this.schoolId = schoolId;
	}
	public int getBranchId() {
		return branchId;
	}
	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}
	public int getSeatingTypeId() {
		return seatingTypeId;
	}
	public void setSeatingTypeId(int seatingTypeId) {
		this.seatingTypeId = seatingTypeId;
	}
	public int getStructureId() {
		return structureId;
	}
	public void setStructureId(int structureId) {
		this.structureId = structureId;
	}
}

