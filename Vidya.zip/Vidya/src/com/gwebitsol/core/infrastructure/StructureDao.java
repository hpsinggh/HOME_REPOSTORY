
package com.gwebitsol.core.infrastructure;
import java.util.Iterator;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.assessments.AnswerPojo;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;
public class StructureDao {
	Session addempSession=MDHibernateUtil.getSessionFactory().openSession();
	Transaction addempTx=null;
	
	public String addStructure(StructurePojo sp)
	{
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			addempTx=addempSession.beginTransaction();
			Integer in=(Integer)addempSession.save(sp);
			System.out.println(in);
			addempTx.commit();
			sb.append("<Structure>");
			sb.append("\n");
			sb.append("<Structureid>");
			sb.append(in);
			sb.append("</Structureid>");
			sb.append("</Structure>");
			outStr=sb.toString();
   		 	}
		
		catch(Exception localException)
		{
			System.out.println(localException);
		   sb.append("<Response>");
		    sb.append("\n");
		    sb.append("<Result>");
		    sb.append("\n");
		    sb.append("Fail");
		    sb.append("\n");
		    sb.append("</Result>");
		    sb.append("\n");
		    sb.append("<Description>");
		    sb.append("could not inserted structure info");
		    sb.append("</Description>");
		    sb.append("\n");
		    sb.append("<Exception>");
		    sb.append(localException);
		    sb.append("</Exception>");
		    sb.append("</Response>");
		    outStr= sb.toString();
		    MDTransactionWriter.exceptionlog.info(localException);
			  if (addempTx!=null)
				  addempTx.rollback();
			 
		}
		finally
		{			
			addempSession.close();
		}
		return outStr;
		}
	public String updateStructure(StructurePojo sp,int schoolId,int branchId) {
		Session upempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction upempTx=null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			upempTx=upempSession.beginTransaction();
			StructurePojo structure = (StructurePojo) upempSession.get(StructurePojo.class,sp.getStructureId());
			upempSession.evict(structure);
			if(branchId==structure.getBranchId()&&schoolId==structure.getSchoolId())
	        upempSession.update(sp);
			upempTx.commit();
			sb.append("<Structure>");
			sb.append("\n");
			sb.append("update sucessfully");
			sb.append("</Structure>");
			String str=sb.toString();
			return str;
   		 	}
		catch(Exception localException)
		{
			System.out.println(localException);
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    sb.append("could not update structure info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    outStr= sb.toString();
			    MDTransactionWriter.exceptionlog.info(localException);
				  if (upempTx!=null)
					  upempTx.rollback();
		}
		finally
		{			
			upempSession.close();
		}
		return outStr;
	}
	public String deleteStructurePojo(int structureId,int schoolId,int branchId) {
		Session delempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction delempTx=null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			delempTx=delempSession.beginTransaction();
			StructurePojo structure = (StructurePojo)delempSession.get(StructurePojo.class,structureId);
			   int branid = structure.getBranchId();
			   int sclid = structure.getSchoolId();
			   delempSession.evict(structure);             
			   if(branchId==branid&&schoolId==sclid)
			   {
			Query empQuery=delempSession.createSQLQuery("update gbl_sm_tbl_structure set IsDeleted ='Y' where structureId='"+structureId+"'");
			empQuery.executeUpdate();
	        delempTx.commit();	
	        sb.append("<Structure>");
			sb.append("\n");
			sb.append("deleted sucessfully");
			sb.append("</Structure>");
			String str=sb.toString();
			return str;
   		 	}
			   else
			   {
				   outStr = "structure is not deleted";
			    sb.append("<Structure>");
			    sb.append("\n");
			    sb.append(outStr);
			    sb.append("</Structure>");
			    String str = sb.toString();
			    return str;
			   }
				}
		catch(Exception localException)
		{
			System.out.println(localException);
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    sb.append("could not delete structure info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    outStr= sb.toString();
			    MDTransactionWriter.exceptionlog.info(localException);
				  if (delempTx!=null)
					  delempTx.rollback();
		}
		finally
		{			
			delempSession.close();
		}
		return outStr;
	}
	public String getByStructureId(int structureId,int schoolId,int branchId) {
		Session gtempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gtTx=null;
			StringBuffer sb= new StringBuffer();
			System.out.println("hi dao impl success");
			String strg= null;
				try {
					gtTx = gtempSession.beginTransaction();
					List list=gtempSession.createSQLQuery("SELECT st.StructureId,st.BranchId,sb.BranchName, st.StructureName,st.Location,st.Purpose,st.`Status`,st.Photo,st.Description, st.Remarks,st.CreatedDate,st.ModifiedDate,st.SchoolId FROM gbl_sm_tbl_structure as st  JOIN gbl_sm_tbl_school_branch as sb on st.BranchId = sb.SchoolBranchId where st.IsDeleted <> 'Y' or st.IsDeleted IS NULL and StructureId='" + structureId + "' and st.SchoolId ='" + schoolId + "' and st.BranchId ='" + branchId + "' ;").list();
				     Iterator it=list.iterator();
				     sb.append("<Structure>");
				     sb.append("\n");
				     while(it.hasNext())
				     {
				     Object[] ex=(Object[])it.next();
				     sb.append("<structureId>");
				     sb.append(ex[0]);
				     sb.append("</structureId>");
				     sb.append("\n");
				     sb.append("<branchId>");
				     sb.append(ex[1]);
				     sb.append("</branchId>");
				     sb.append("\n");
				     sb.append("<branchName>");
				     sb.append(ex[2]);
				     sb.append("</branchName>");
				     sb.append("\n");
				     sb.append("<structureName>");
				      sb.append(ex[3]);
				      sb.append("</structureName>");
				      sb.append("\n");
				      sb.append("<location>");
				      sb.append(ex[4]);
				      sb.append("</location>");
				      sb.append("\n");
				      sb.append("<purpose>");
				      sb.append(ex[5]);
				      sb.append("</purpose>");
				      sb.append("\n");
				      sb.append("<status>");
						sb.append(ex[6]);
						sb.append("</status>");
						sb.append("\n");
						 sb.append("<photo>");
							sb.append(ex[7]);
							sb.append("</photo>");
							sb.append("\n");
							sb.append("<description>");
							sb.append(ex[8]);
							sb.append("</description>");
							sb.append("\n");
						sb.append("<remarks>");
						sb.append(ex[9]);
						sb.append("</remarks>");
						sb.append("\n");
						 sb.append("<createdDate>");
				         sb.append(ex[10]);
				         sb.append("</createdDate>");
				         sb.append("\n");
				         sb.append("<modifiedDate>");
				         sb.append(ex[11]);
				         sb.append("</modifiedDate>");
							    sb.append("\n");
								sb.append("<schoolId>");
								sb.append(ex[12]);
								sb.append("</schoolId>");
								sb.append("\n");
				     }
									sb.append("</Structure>");
								    strg= sb.toString();
								
						
						
				} 	catch (Exception localException) {
					System.out.println(localException);
					
					   sb.append("<Response>");
					    sb.append("\n");
					    sb.append("<Result>");
					    sb.append("\n");
					    sb.append("Fail");
					    sb.append("\n");
					    sb.append("</Result>");
					    sb.append("\n");
					    sb.append("<Description>");
					    
					    sb.append("could not getbyid structure info");
					    sb.append("</Description>");
					    sb.append("\n");
					    sb.append("<Exception>");
					    sb.append(localException);
					    sb.append("</Exception>");
					    sb.append("</Response>");
					    sb.append("</structureId>");
					    sb.append("</Structure>");
					    strg= sb.toString();
					   MDTransactionWriter.exceptionlog.info(localException);
					  if (gtTx!=null)
						  gtTx.rollback();
					} finally {
						gtempSession.close();
					}
			return strg;
	}
	
	
	public String getAllstructure(int PNO, int size,int schoolId,int branchId) {
		Session rdSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb= new StringBuffer();
		String string=null;
	   // StructurePojo ex1=null;
		
		try
		{
			tx = rdSession.beginTransaction();
			
			 if(("all") != null)
			   {
			    int fset = (PNO-1)*size;
			    String gsSql ="select count(*) from gbl_sm_tbl_structure as st where st.IsDeleted <> 'Y' or st.IsDeleted IS NULL and st.SchoolId = '" + schoolId + "' and st.BranchId = '" + branchId + "'";
			    Query gsQuery=rdSession.createSQLQuery(gsSql);
			    Object noRecords= gsQuery.uniqueResult();
			    sb.append("<Structures>");
			    sb.append("\n");
			    sb.append("<noRecords>"+noRecords+"</noRecords>");
			    sb.append("\n");
			    
			     if (PNO > 0 & size > 0){
			     gsSql="SELECT st.StructureId,st.BranchId,sb.BranchName, st.StructureName,st.Location,st.Purpose,st.`Status`,st.Photo,st.Description, st.Remarks,st.CreatedDate,st.ModifiedDate,st.SchoolId FROM gbl_sm_tbl_structure as st  JOIN gbl_sm_tbl_school_branch as sb on  st.BranchId = sb.SchoolBranchId where st.IsDeleted <> 'Y' or st.IsDeleted IS NULL and st.SchoolId = '" + schoolId + "' and st.BranchId = '" + branchId + "' limit "+size+" offset "+fset;}
			     else {
			      gsSql="SELECT st.StructureId,st.BranchId,sb.BranchName, st.StructureName,st.Location,st.Purpose,st.`Status`,st.Photo,st.Description, st.Remarks,st.CreatedDate,st.ModifiedDate,st.SchoolId FROM gbl_sm_tbl_structure as st  JOIN gbl_sm_tbl_school_branch as sb on  st.BranchId = sb.SchoolBranchId where st.IsDeleted <> 'Y' or st.IsDeleted IS NULL and st.SchoolId = '" + schoolId + "' and st.BranchId = '" + branchId + "'";
			     } 
			   
			    gsQuery=rdSession.createSQLQuery(gsSql);
			    List gcList=gsQuery.list();
			    Iterator gsIT=gcList.iterator();
			    while(gsIT.hasNext())
			     {
			    	 Object[] ex=(Object[])gsIT.next();
			    	 sb.append("<Structure>");
					 sb.append("\n");
					 sb.append("<structureId>");
				     sb.append(ex[0]);
				     sb.append("</structureId>");
				     sb.append("\n");
				     sb.append("<branchId>");
				     sb.append(ex[1]);
				     sb.append("</branchId>");
				     sb.append("\n");
				     sb.append("<branchName>");
				     sb.append(ex[2]);
				     sb.append("</branchName>");
				     sb.append("\n");
				     sb.append("<structureName>");
				      sb.append(ex[3]);
				      sb.append("</structureName>");
				      sb.append("\n");
				      sb.append("<location>");
				      sb.append(ex[4]);
				      sb.append("</location>");
				      sb.append("\n");
				      sb.append("<purpose>");
				      sb.append(ex[5]);
				      sb.append("</purpose>");
				      sb.append("\n");
				      sb.append("<status>");
						sb.append(ex[6]);
						sb.append("</status>");
						sb.append("\n");
						 sb.append("<photo>");
							sb.append(ex[7]);
							sb.append("</photo>");
							sb.append("\n");
							sb.append("<description>");
							sb.append(ex[8]);
							sb.append("</description>");
							sb.append("\n");
						sb.append("<remarks>");
						sb.append(ex[9]);
						sb.append("</remarks>");
						sb.append("\n");
						 sb.append("<createdDate>");
				         sb.append(ex[10]);
				         sb.append("</createdDate>");
				         sb.append("\n");
				         sb.append("<modifiedDate>");
				         sb.append(ex[11]);
				         sb.append("</modifiedDate>");
							    sb.append("\n");
								sb.append("<schoolId>");
								sb.append(ex[12]);
								sb.append("</schoolId>");
								sb.append("\n");
					 sb.append("</Structure>");
					 sb.append("\n");
			     }
			    
			    tx.commit();
			    sb.append("</Structures>");

			    string=sb.toString();
			   }		   
			  } 
		catch (Exception localException) {
			System.out.println(localException);
			
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    sb.append("could not getbyid structure info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    sb.append("</structureId>");
			    sb.append("</Structure>");
			    string= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (tx!=null)
			   tx.rollback();
			} finally {
				rdSession.close();
			}
	return string;
}
}


