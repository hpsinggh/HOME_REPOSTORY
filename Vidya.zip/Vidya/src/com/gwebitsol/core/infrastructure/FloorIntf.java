
package com.gwebitsol.core.infrastructure;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

@Path("/floor/")
public interface FloorIntf {
	
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/add/")
    public Response addFloor(Floor fl,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);
	
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/update/")
	public Response updateFloor(Floor f1,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);
	
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/delete/")
	public Response deleteFloor(@QueryParam("floorId") int floorId,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);
	
	@GET
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/get/")
	public Response getByFloorId(@QueryParam("floorId") int floorId,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);
	
	@GET
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/getall/")
	public Response getAllFloor(@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName
			,@QueryParam("PNO") int PNO,@QueryParam("size") int size,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);
	@GET
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/getallfloorsbystructureid/")
	public Response getAllFloorsbyStructureid(@QueryParam("structureId") int structureId,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName
			,@QueryParam("PNO") int PNO,@QueryParam("size") int size,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);
}
