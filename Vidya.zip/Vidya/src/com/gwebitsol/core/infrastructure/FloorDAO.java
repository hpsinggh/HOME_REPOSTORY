
package com.gwebitsol.core.infrastructure;
import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;
@Repository
public class FloorDAO {
	Session addempSession=MDHibernateUtil.getSessionFactory().openSession();
	Transaction addempTx=null;
	public String addFloor(Floor fl)
	{
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			addempTx=addempSession.beginTransaction();
	        Integer in=(Integer)addempSession.save(fl);
			System.out.println(in);
			addempTx.commit();
			sb.append("<Floor>");
			sb.append("\n");
			sb.append("<Floorid>");
			sb.append(in);
			sb.append("</Floorid>");
			sb.append("</Floor>");
			outStr=sb.toString();
			
		   
   		 	}
		
		catch(Exception localException)
		{
			System.out.println(localException);
			
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    
			    sb.append("could not inserted floor info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    outStr= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (addempTx!=null)
				  addempTx.rollback();
		}
		finally
		{			
			addempSession.close();
		}
		return outStr;
		}
	public String updateFloor(Floor fl,int schoolId,int branchId) {
		Session upempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction upempTx=null;
		StringBuffer sb=new StringBuffer();
		
		String outStr=null;
		try
		{
			upempTx=upempSession.beginTransaction();
			Floor floor = (Floor) upempSession.get(Floor.class,fl.getFloorId());
			upempSession.evict(floor);
			if(branchId==floor.getBranchId()&&schoolId==floor.getSchoolId())
			upempSession.update(fl);
			upempTx.commit();
			sb.append("<Floor>");
			sb.append("\n");
			sb.append("update sucessfully");
			sb.append("</Floor>");
			String str=sb.toString();
			return str;
		   
   		 	}
		
		catch(Exception localException)
		{
			System.out.println(localException);
			
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    
			    sb.append("could not update floor info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    outStr= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (upempTx!=null)
				  upempTx.rollback();
		}
		finally
		{			
			upempSession.close();
		}
		return outStr;
	}
	public String deleteFloor(int floorId,int schoolId,int branchId) {
		Session delempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction delempTx=null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			delempTx=delempSession.beginTransaction();
			Floor floor = (Floor) delempSession.get(Floor.class,floorId);
			   int branid = floor.getBranchId();
			   int sclid = floor.getSchoolId();
			   delempSession.evict(floor);             
			   if(branchId==branid&&schoolId==sclid)
			   {
			Query empQuery=delempSession.createSQLQuery("update gbl_sm_tbl_floor set IsDeleted ='Y' where floorId='"+floorId+"'");
			empQuery.executeUpdate();
			delempTx.commit();
			sb.append("<Floor>");
			sb.append("\n");
			sb.append("deleted sucessfully");
			sb.append("</Floor>");
			String str=sb.toString();
			return str;
   		 	}
			   else
			   {
				   outStr = "floor is not deleted";
			    sb.append("<Floor>");
			    sb.append("\n");
			    sb.append(outStr);
			    sb.append("</Floor>");
			    String str = sb.toString();
			    return str;
			   }
				}
		catch(Exception localException)
		{
			System.out.println(localException);
			
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    
			    sb.append("could not delete floor info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    outStr= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (delempTx!=null)
				  delempTx.rollback();
		}
		finally
		{			
			delempSession.close();
		}
		return outStr;
	}
	
	public String getByIdFloor(int floorId,int schoolId,int branchId) {
		Session gtempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gtTx=null;
			StringBuffer sb= new StringBuffer();
			System.out.println("hi dao impl success");
			String strg= null;
				try {
						gtTx = gtempSession.beginTransaction();
						List list=gtempSession.createSQLQuery("Select f.FloorId,f.FloorNo,f.FloorName,f.Description,f.SchoolId,f.BranchId,f.StructureId,st.StructureName from gbl_sm_tbl_floor as f  left outer join gbl_sm_tbl_structure as st on f.StructureId =  st.StructureId where (f.IsDeleted <> 'Y' or f.IsDeleted IS NULL) and FloorId='" + floorId + "' and f.SchoolId ='" + schoolId + "'and f.BranchId ='" + branchId + "' ;").list();
					     Iterator it=list.iterator();
					    		    sb.append("<Floor>");
							        sb.append("\n");
							        while(it.hasNext())
							        {
									Object[] ex=(Object[])it.next();
							        sb.append("<floorId>");
								    sb.append(ex[0]);
								    sb.append("</floorId>");
								    sb.append("\n");
								    sb.append("<floorNo>");
								    sb.append(ex[1]);
								    sb.append("</floorNo>");
								    sb.append("\n");
								    sb.append("<floorName>");
									sb.append(ex[2]);
									sb.append("</floorName>");
									sb.append("\n");
									sb.append("<description>");
									sb.append(ex[3]);
									sb.append("</description>");
									sb.append("\n");
									sb.append("<schoolId>");
									sb.append(ex[4]);
									sb.append("</schoolId>");
									sb.append("\n");
									sb.append("<branchId>");
									sb.append(ex[5]);
									sb.append("</branchId>");
									sb.append("\n");
									sb.append("<structureId>");
									sb.append(ex[6]);
									sb.append("</structureId>");
									sb.append("\n");
									sb.append("<structureName>");
									sb.append(ex[7]);
									sb.append("</structureName>");
									sb.append("\n");
							        }
									sb.append("</Floor>");
								    strg= sb.toString();
								
						
				} 	catch (Exception localException) {
					System.out.println(localException);
					
					   sb.append("<Response>");
					    sb.append("\n");
					    sb.append("<Result>");
					    sb.append("\n");
					    sb.append("Fail");
					    sb.append("\n");
					    sb.append("</Result>");
					    sb.append("\n");
					    sb.append("<Description>");
					    
					    sb.append("could not getbyid floor info");
					    sb.append("</Description>");
					    sb.append("\n");
					    sb.append("<Exception>");
					    sb.append(localException);
					    sb.append("</Exception>");
					    sb.append("</Response>");
					    sb.append("</FloorId>");
					    sb.append("</Floor>");
					    strg= sb.toString();
					   MDTransactionWriter.exceptionlog.info(localException);
					  if (gtTx!=null)
						  gtTx.rollback();
					} finally {
						gtempSession.close();
					}
			return strg;
	}
	public String getAllFloor(int PNO, int size,int schoolId,int branchId) {

			Session rdSession=MDHibernateUtil.getSessionFactory().openSession();
			Transaction tx = null;
			StringBuffer sb= new StringBuffer();
			String string=null;
		    Floor ex=null;
			
			try
			{
				tx = rdSession.beginTransaction();
				
				 if(("all") != null)
				   {
				    int fset = (PNO-1)*size;
				    String gsSql ="select count(*) from gbl_sm_tbl_floor as f where (f.IsDeleted <> 'Y' or f.IsDeleted IS NULL) and f.SchoolId ='" + schoolId + "'and f.BranchId ='" + branchId + "'";
				    Query gsQuery=rdSession.createSQLQuery(gsSql);
				    Object noRecords= gsQuery.uniqueResult();
				    sb.append("<Floores>");
				    sb.append("\n");
				    sb.append("<noRecords>"+noRecords+"</noRecords>");
				    sb.append("\n");
				    
				     if (PNO > 0 & size > 0){
				     gsSql="Select f.FloorId,f.FloorNo,f.FloorName,f.Description,f.SchoolId,f.BranchId,f.StructureId,st.StructureName from gbl_sm_tbl_floor as f  left outer join gbl_sm_tbl_structure as st on f.StructureId =  st.StructureId where (f.IsDeleted <> 'Y' or f.IsDeleted IS NULL) and f.SchoolId ='" + schoolId + "'and f.BranchId ='" + branchId + "' limit "+size+" offset "+fset;}
				     else {
				      gsSql="Select f.FloorId,f.FloorNo,f.FloorName,f.Description,f.SchoolId,f.BranchId,f.StructureId,st.StructureName from gbl_sm_tbl_floor as f  left outer join gbl_sm_tbl_structure as st on f.StructureId =  st.StructureId where (f.IsDeleted <> 'Y' or f.IsDeleted IS NULL) and f.SchoolId ='" + schoolId + "'and f.BranchId ='" + branchId + "' ";
				     } 
				   
				    gsQuery=rdSession.createSQLQuery(gsSql);
				    List gcList=gsQuery.list();
				    Iterator gsIT=gcList.iterator();
				    while(gsIT.hasNext())
				     {
				      Object[] mdcArr=(Object[])gsIT.next();
				      sb.append("<floor>");
				      sb.append("\n");
				      sb.append("<floorId>"+mdcArr[0]+"</floorId>");
				      sb.append("\n");
				      sb.append("<floorNo>" + mdcArr[1]+ "</floorNo>");
				      sb.append("\n");
				      sb.append("<floorName>" + mdcArr[2]+ "</floorName>");
				      sb.append("\n");
				      sb.append("<description>" + mdcArr[3] + "</description>");
				      sb.append("\n");
				      sb.append("<schoolId>" + mdcArr[4] + "</schoolId>");
				      sb.append("\n");
				      sb.append("<branchId>" + mdcArr[5] + "</branchId>");
				      sb.append("\n");
				      sb.append("<structureId>"+mdcArr[6]+"</structureId>");
				      sb.append("\n");
				      sb.append("<structureName>"+mdcArr[7]+"</structureName>");
				      sb.append("</floor>");
				      sb.append("\n");
				     }
				    
				    tx.commit();
				    sb.append("</Floores>");
				    sb.append("\n");

				    string=sb.toString();
				   } 
				  } 
			catch (Exception localException) {
				System.out.println(localException);
				
				   sb.append("<Response>");
				    sb.append("\n");
				    sb.append("<Result>");
				    sb.append("\n");
				    sb.append("Fail");
				    sb.append("\n");
				    sb.append("</Result>");
				    sb.append("\n");
				    sb.append("<Description>");
				    sb.append("could not getbyid field info");
				    sb.append("</Description>");
				    sb.append("\n");
				    sb.append("<Exception>");
				    sb.append(localException);
				    sb.append("</Exception>");
				    sb.append("</Response>");
				    sb.append("</floorId>");
				    sb.append("</Floor>");
				    string= sb.toString();
				   MDTransactionWriter.exceptionlog.info(localException);
				  if (tx!=null)
				   tx.rollback();
				} finally {
					rdSession.close();
				}
		return string;
	}
	public String getAllFloorsbyStructureid(int PNO, int size, int structureId,int schoolId,int branchId) {
		Session gtempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gtTx=null;
			StringBuffer sb= new StringBuffer();
			System.out.println("hi dao impl success");
			String strg= null;
				try {
						gtTx = gtempSession.beginTransaction();
						 if(("all") != null)
						   {
						    int fset = (PNO-1)*size;
						    String gsSql ="select count(*) from gbl_sm_tbl_floor as f where (f.IsDeleted <> 'Y' or f.IsDeleted IS NULL)  and f.StructureId ='" + structureId + "' and f.SchoolId ='" + schoolId + "'and f.BranchId ='" + branchId + "'";
						    Query gsQuery=gtempSession.createSQLQuery(gsSql);
						    Object noRecords= gsQuery.uniqueResult();
						    sb.append("<Floores>");
						    sb.append("\n");
						    sb.append("<noRecords>"+noRecords+"</noRecords>");
						    sb.append("\n");
						    
						     if (PNO > 0 & size > 0){
						     gsSql="Select st.StructureId,f.FloorId,f.FloorNo,f.FloorName,f.Description,f.SchoolId,f.BranchId,f.StructureId,st.StructureName from gbl_sm_tbl_floor as f  left outer join gbl_sm_tbl_structure as st on f.StructureId = st.StructureId where (f.IsDeleted <> 'Y' or f.IsDeleted IS NULL) and f.StructureId ='" + structureId + "' and f.SchoolId ='" + schoolId + "'and f.BranchId ='" + branchId + "' limit "+size+" offset "+fset;}
						     else {
						      gsSql="Select st.StructureId,f.FloorId,f.FloorNo,f.FloorName,f.Description,f.SchoolId,f.BranchId,f.StructureId,st.StructureName from gbl_sm_tbl_floor as f  left outer join gbl_sm_tbl_structure as st on f.StructureId = st.StructureId where (f.IsDeleted <> 'Y' or f.IsDeleted IS NULL) and f.StructureId ='" + structureId + "' and f.SchoolId ='" + schoolId + "'and f.BranchId ='" + branchId + "' ";
						     } 
						   
						    gsQuery=gtempSession.createSQLQuery(gsSql);
						    List gcList=gsQuery.list();
						    Iterator gsIT=gcList.iterator();
						/*List list=gtempSession.createSQLQuery("Select st.StructureId,f.FloorId,f.FloorNo,f.FloorName,f.Description,f.SchoolId,f.BranchId,f.StructureId,st.StructureName from gbl_sm_tbl_floor as f  left outer join gbl_sm_tbl_structure as st on f.StructureId = st.StructureId where (f.IsDeleted <> 'Y' or f.IsDeleted IS NULL) and f.StructureId ='" + structureId + "' and f.SchoolId ='" + schoolId + "'and f.BranchId ='" + branchId + "' ;").list();
					     Iterator it=list.iterator();
					    		    sb.append("<Floores>");
							        sb.append("\n");*/
							        while(gsIT.hasNext())
							        {
									Object[] ex=(Object[])gsIT.next();
									sb.append("<floor>");
								    sb.append("\n");
							        sb.append("<floorId>");
								    sb.append(ex[1]);
								    sb.append("</floorId>");
								    sb.append("\n"); 
								    sb.append("<floorNo>");
								    sb.append(ex[2]);
								    sb.append("</floorNo>");
								    sb.append("\n");
								    sb.append("<floorName>");
									sb.append(ex[3]);
									sb.append("</floorName>");
									sb.append("\n");
									sb.append("<description>");
									sb.append(ex[4]);
									sb.append("</description>");
									sb.append("\n");
									sb.append("<schoolId>");
									sb.append(ex[5]);
									sb.append("</schoolId>");
									sb.append("\n");
									sb.append("<branchId>");
									sb.append(ex[6]);
									sb.append("</branchId>");
									sb.append("\n");
									sb.append("<structureId>");
									sb.append(ex[7]);
									sb.append("</structureId>");
									sb.append("\n");
									sb.append("<structureName>");
									sb.append(ex[8]);
									sb.append("</structureName>");
									sb.append("\n");
									sb.append("</floor>");
							        }
									sb.append("</Floores>");
								    strg= sb.toString();
								
						   }	
				} 	catch (Exception localException) {
					System.out.println(localException);
					
					   sb.append("<Response>");
					    sb.append("\n");
					    sb.append("<Result>");
					    sb.append("\n");
					    sb.append("Fail");
					    sb.append("\n");
					    sb.append("</Result>");
					    sb.append("\n");
					    sb.append("<Description>");
					    
					    sb.append("could not getbyid floor info");
					    sb.append("</Description>");
					    sb.append("\n");
					    sb.append("<Exception>");
					    sb.append(localException);
					    sb.append("</Exception>");
					    sb.append("</Response>");
					    sb.append("</FloorId>");
					    sb.append("</Floor>");
					    strg= sb.toString();
					   MDTransactionWriter.exceptionlog.info(localException);
					  if (gtTx!=null)
						  gtTx.rollback();
					} finally {
						gtempSession.close();
					}
			return strg;
	}
}

		
	

