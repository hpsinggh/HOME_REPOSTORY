
package com.gwebitsol.core.infrastructure;
import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;


import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

@Repository
public class RoomDao {
	Session addempSession=MDHibernateUtil.getSessionFactory().openSession();
	Transaction addempTx=null;
	public String addRoom(RoomPojo rp)
	{
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			addempTx=addempSession.beginTransaction();
			Integer in=(Integer)addempSession.save(rp);
			System.out.println(in);
			addempTx.commit();
			sb.append("<Room>");
			sb.append("\n");
			sb.append("<Roomid>");
			sb.append(in);
			sb.append("</Roomid>");
			sb.append("</Room>");
			outStr=sb.toString();
   		 	}
		
		catch(Exception localException)
		{
			System.out.println(localException);
			
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    
			    sb.append("could not inserted room info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    outStr= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (addempTx!=null)
				  addempTx.rollback();
		}
		finally
		{			
			addempSession.close();
		}
		return outStr;
		}
	
	public String updateRoom(RoomPojo rp,int schoolId,int branchId) {
		Session upempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction upempTx=null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			upempTx=upempSession.beginTransaction();
			RoomPojo room = (RoomPojo) upempSession.get(RoomPojo.class,rp.getRoomId());
			upempSession.evict(room);
			if(schoolId==room.getSchoolId()&&branchId==room.getBranchId())
			upempSession.update(rp);
			upempTx.commit();
			sb.append("<Room>");
			sb.append("\n");
			sb.append("update sucessfully");
			sb.append("</Room>");
			String str=sb.toString();
			return str;
   		 	}
		
		catch(Exception localException)
		{
			System.out.println(localException);
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    sb.append("could not update room info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    outStr= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (upempTx!=null)
				  upempTx.rollback();
		}
		finally
		{			
			upempSession.close();
		}
		return outStr;
	}
	public String deleteRoom(int roomId,int schoolId,int branchId) {
		Session delempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction delempTx=null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			delempTx=delempSession.beginTransaction();
			RoomPojo room = (RoomPojo)delempSession.get(RoomPojo.class,roomId);
			   int branid = room.getBranchId();
			   int sclid = room.getSchoolId();
			   delempSession.evict(room);             
			   if(branchId==branid&&schoolId==sclid)
			   {
			Query empQuery=delempSession.createSQLQuery("update gbl_sm_tbl_room set IsDeleted ='Y' where roomId='"+roomId+"'");
			empQuery.executeUpdate();
			delempTx.commit();
			sb.append("<Room>");
			sb.append("\n");
			sb.append("deleted sucessfully");
			sb.append("</Room>");
			String str=sb.toString();
			return str;
   		 	}
			   else
			   {
				outStr = "room is not deleted";
			    sb.append("<Room>");
			    sb.append("\n");
			    sb.append(outStr);
			    sb.append("</Room>");
			    String str = sb.toString();
			    return str;
			   }
				}
		catch(Exception localException)
		{
			System.out.println(localException);
			
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    
			    sb.append("could not delete room info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    outStr= sb.toString();
			    MDTransactionWriter.exceptionlog.info(localException);
				  if (delempTx!=null)
					  delempTx.rollback();
		}
		finally
		{			
			delempSession.close();
		}
		return outStr;
	}
	public String getByIdRoom(int roomId,int schoolId,int branchId) {
		Session gtempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gtTx=null;
			StringBuffer sb= new StringBuffer();
			System.out.println("hi dao impl success");
			String strg= null;
				try {
					gtTx = gtempSession.beginTransaction();
					List list=gtempSession.createSQLQuery("SELECT r.RoomId,r.FloorId,f.FloorName,r.RoomTypeId,rt.TypeName,r.RoomNo,r.NumberOfRows,r.NumberOfColumns,r.NumberOfSeatsPerRow,r.ColnoRowSeats,r.RoomName,r.AC,r.Capacity,r.Size,r.`Status`,r.RoomDescription,r.Remarks,r.SeatingNo,r.AllowAisles,r.Image,rt.TypeFlag,r.SchoolId,r.BranchId,r.SeatingTypeId,st.SeatingTypeNo,st.SeatingTitle FROM gbl_sm_tbl_room as r JOIN gbl_sm_tbl_floor as f JOIN gbl_sm_tbl_room_type as rt JOIN gbl_sm_tbl_seatingtype AS st ON r.FloorId = f.FloorId and r.RoomTypeId=rt.RoomTypeId and r.SeatingTypeId = st.SeatingTypeId where r.IsDeleted <> 'Y' or r.IsDeleted IS NULL and RoomId='" + roomId + "' and r.SchoolId ='" + schoolId + "'  and r.BranchId ='" + branchId + "' ;").list();
				     Iterator it=list.iterator();
				    		    sb.append("<Room>");
						        sb.append("\n");
						        while(it.hasNext()){
								Object[] ex=(Object[])it.next();
						        sb.append("<roomId>");
							    sb.append(ex[0]);
							    sb.append("</roomId>");
							    sb.append("\n");
							    sb.append("<floorId>");
							    sb.append(ex[1]);
							    sb.append("</floorId>");
							    sb.append("\n");
							    sb.append("<floorName>");
								sb.append(ex[2]);
								sb.append("</floorName>");
								 sb.append("\n");
								sb.append("<roomTypeId>");
								sb.append(ex[3]);
								sb.append("</roomTypeId>");
								 sb.append("\n");
								sb.append("<typename>");
								sb.append(ex[4]);
								sb.append("</typename>");
								sb.append("\n");
								sb.append("<roomNo>");
								sb.append(ex[5]);
								sb.append("</roomNo>");
								sb.append("\n");
								sb.append("<numberOfRows>");
								sb.append(ex[6]);
								sb.append("</numberOfRows>");
								sb.append("\n");
								sb.append("<numberOfColumns>");
								sb.append(ex[7]);
								sb.append("</numberOfColumns>");
								sb.append("\n");
								sb.append("<numberOfSeatsPerRow>");
								sb.append(ex[8]);
								sb.append("</numberOfSeatsPerRow>");
								sb.append("\n");
								sb.append("<colnoRowSeats>");
								sb.append(ex[9]);
								sb.append("</colnoRowSeats>");
								sb.append("\n");
								sb.append("<roomName>");
								sb.append(ex[10]);
								sb.append("</roomName>");
								sb.append("\n");
								sb.append("<ac>");
								sb.append(ex[11]);
								sb.append("</ac>");
								sb.append("\n");
								sb.append("<capacity>");
								sb.append(ex[12]);
								sb.append("</capacity>");
								sb.append("\n");
								sb.append("<size>");
								sb.append(ex[13]);
								sb.append("</size>");
								sb.append("\n");
								sb.append("<status>");
								sb.append(ex[14]);
								sb.append("</status>");
								sb.append("\n");
								sb.append("<roomDescription>");
								sb.append(ex[15]);
								sb.append("</roomDescription>");
								sb.append("\n");
								sb.append("<remarks>");
								sb.append(ex[16]);
								sb.append("</remarks>");
								sb.append("\n");
								sb.append("<seatingNo>");
								sb.append(ex[17]);
								sb.append("</seatingNo>");
								sb.append("\n");
								sb.append("<allowAisles>");
								sb.append(ex[18]);
								sb.append("</allowAisles>");
								sb.append("\n");
								sb.append("<image>");
								sb.append(ex[19]);
								sb.append("</image>");
								sb.append("\n");
								sb.append("<typeFlag>");
								sb.append(ex[20]);
								sb.append("</typeFlag>");
								sb.append("\n");
								sb.append("<schoolId>");
								sb.append(ex[21]);
								sb.append("</schoolId>");
								sb.append("\n");
								sb.append("<branchId>");
								sb.append(ex[22]);
								sb.append("</branchId>");
								sb.append("\n");
								sb.append("<seatingTypeId>");
								sb.append(ex[23]);
								sb.append("</seatingTypeId>");
								sb.append("\n");
								sb.append("<seatingTypeNo>");
								sb.append(ex[24]);
								sb.append("</seatingTypeNo>");
								sb.append("\n");
								sb.append("<seatingTitle>");
								sb.append(ex[25]);
								sb.append("</seatingTitle>");
								sb.append("\n");
						        }
								sb.append("</Room>");
							    strg= sb.toString();
							
					
					
			} 	catch (Exception localException) {
				System.out.println(localException);
				
				   sb.append("<Response>");
				    sb.append("\n");
				    sb.append("<Result>");
				    sb.append("\n");
				    sb.append("Fail");
				    sb.append("\n");
				    sb.append("</Result>");
				    sb.append("\n");
				    sb.append("<Description>");
				    
				    sb.append("could not getbyid room info");
				    sb.append("</Description>");
				    sb.append("\n");
				    sb.append("<Exception>");
				    sb.append(localException);
				    sb.append("</Exception>");
				    sb.append("</Response>");
				    sb.append("</fieldId>");
				    sb.append("</Field>");
				    strg= sb.toString();
				   MDTransactionWriter.exceptionlog.info(localException);
				  if (gtTx!=null)
					  gtTx.rollback();
				} finally {
					gtempSession.close();
				}
		return strg;
	}

	public String getAllroom(int PNO, int size,int schoolId,int branchId) {
		Session rdSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb= new StringBuffer();
		String string=null;
	   // RoomPojo ex=null;
		
		try
		{
			tx = rdSession.beginTransaction();
			
			if(("all") != null)
			   {
			    int fset = (PNO-1)*size;
			    String gsSql ="select count(*) from gbl_sm_tbl_room as r where r.IsDeleted <> 'Y' or r.IsDeleted IS NULL and r.SchoolId ='" + schoolId + "'  and r.BranchId ='" + branchId + "'";
			    Query gsQuery=rdSession.createSQLQuery(gsSql);
			    Object noRecords= gsQuery.uniqueResult();
			    sb.append("<Rooms>");
			    sb.append("\n");
			    sb.append("<noRecords>"+noRecords+"</noRecords>");
			    sb.append("\n");
			    
			     if (PNO > 0 & size > 0){
			     gsSql="SELECT r.RoomId,r.FloorId,f.FloorName,r.RoomTypeId,rt.TypeName,r.RoomNo,r.NumberOfRows,r.NumberOfColumns,r.NumberOfSeatsPerRow,r.ColnoRowSeats,r.RoomName,r.AC,r.Capacity,r.Size,r.`Status`,r.RoomDescription,r.Remarks,r.SeatingNo,r.AllowAisles,r.Image,rt.TypeFlag,r.SchoolId,r.BranchId,r.SeatingTypeId,st.SeatingTypeNo,st.SeatingTitle FROM gbl_sm_tbl_room as r JOIN gbl_sm_tbl_floor as f JOIN gbl_sm_tbl_room_type as rt JOIN gbl_sm_tbl_seatingtype AS st ON r.FloorId = f.FloorId and r.RoomTypeId=rt.RoomTypeId and r.SeatingTypeId = st.SeatingTypeId where r.IsDeleted <> 'Y' or r.IsDeleted IS NULL and r.SchoolId ='" + schoolId + "'  and r.BranchId ='" + branchId + "' limit "+size+" offset "+fset;}
			     else {
			      gsSql="SELECT r.RoomId,r.FloorId,f.FloorName,r.RoomTypeId,rt.TypeName,r.RoomNo,r.NumberOfRows,r.NumberOfColumns,r.NumberOfSeatsPerRow,r.ColnoRowSeats,r.RoomName,r.AC,r.Capacity,r.Size,r.`Status`,r.RoomDescription,r.Remarks,r.SeatingNo,r.AllowAisles,r.Image,rt.TypeFlag,r.SchoolId,r.BranchId,r.SeatingTypeId,st.SeatingTypeNo,st.SeatingTitle FROM gbl_sm_tbl_room as r JOIN gbl_sm_tbl_floor as f JOIN gbl_sm_tbl_room_type as rt JOIN gbl_sm_tbl_seatingtype AS st ON r.FloorId = f.FloorId and r.RoomTypeId=rt.RoomTypeId and r.SeatingTypeId = st.SeatingTypeId where r.IsDeleted <> 'Y' or r.IsDeleted IS NULL and r.SchoolId ='" + schoolId + "'  and r.BranchId ='" + branchId + "'";
			     } 
			   
			    gsQuery=rdSession.createSQLQuery(gsSql);
			    List gcList=gsQuery.list();
			    Iterator it=gcList.iterator();
		        while(it.hasNext())
		        {
				Object[] ex=(Object[])it.next();
				sb.append("<Room>");
				sb.append("\n");
		        sb.append("<roomId>");
			    sb.append(ex[0]);
			    sb.append("</roomId>");
			    sb.append("\n");
			    sb.append("<floorId>");
			    sb.append(ex[1]);
			    sb.append("</floorId>");
			    sb.append("\n");
			    sb.append("<floorName>");
				sb.append(ex[2]);
				sb.append("</floorName>");
				 sb.append("\n");
				sb.append("<roomTypeId>");
				sb.append(ex[3]);
				sb.append("</roomTypeId>");
				 sb.append("\n");
				sb.append("<typename>");
				sb.append(ex[4]);
				sb.append("</typename>");
				sb.append("\n");
				sb.append("<roomNo>");
				sb.append(ex[5]);
				sb.append("</roomNo>");
				sb.append("\n");
				sb.append("<numberOfRows>");
				sb.append(ex[6]);
				sb.append("</numberOfRows>");
				sb.append("\n");
				sb.append("<numberOfColumns>");
				sb.append(ex[7]);
				sb.append("</numberOfColumns>");
				sb.append("\n");
				sb.append("<numberOfSeatsPerRow>");
				sb.append(ex[8]);
				sb.append("</numberOfSeatsPerRow>");
				sb.append("\n");
				sb.append("<colnoRowSeats>");
				sb.append(ex[9]);
				sb.append("</colnoRowSeats>");
				sb.append("\n");
				sb.append("<roomName>");
				sb.append(ex[10]);
				sb.append("</roomName>");
				sb.append("\n");
				sb.append("<ac>");
				sb.append(ex[11]);
				sb.append("</ac>");
				sb.append("\n");
				sb.append("<capacity>");
				sb.append(ex[12]);
				sb.append("</capacity>");
				sb.append("\n");
				sb.append("<size>");
				sb.append(ex[13]);
				sb.append("</size>");
				sb.append("\n");
				sb.append("<status>");
				sb.append(ex[14]);
				sb.append("</status>");
				sb.append("\n");
				sb.append("<roomDescription>");
				sb.append(ex[15]);
				sb.append("</roomDescription>");
				sb.append("\n");
				sb.append("<remarks>");
				sb.append(ex[16]);
				sb.append("</remarks>");
				sb.append("\n");
				sb.append("<seatingNo>");
				sb.append(ex[17]);
				sb.append("</seatingNo>");
				sb.append("\n");
				sb.append("<allowAisles>");
				sb.append(ex[18]);
				sb.append("</allowAisles>");
				sb.append("\n");
				sb.append("<image>");
				sb.append(ex[19]);
				sb.append("</image>");
				sb.append("\n");
				sb.append("<typeFlag>");
				sb.append(ex[20]);
				sb.append("</typeFlag>");
				sb.append("\n");
				sb.append("<schoolId>");
				sb.append(ex[21]);
				sb.append("</schoolId>");
				sb.append("\n");
				sb.append("<branchId>");
				sb.append(ex[22]);
				sb.append("</branchId>");
				sb.append("\n");
				sb.append("<seatingTypeId>");
				sb.append(ex[23]);
				sb.append("</seatingTypeId>");
				sb.append("\n");
				sb.append("<seatingTypeNo>");
				sb.append(ex[24]);
				sb.append("</seatingTypeNo>");
				sb.append("\n");
				sb.append("<seatingTitle>");
				sb.append(ex[25]);
				sb.append("</seatingTitle>");
				sb.append("\n");
				sb.append("</Room>");
				 sb.append("\n");
			     }
			    
			    tx.commit();
			    sb.append("</Rooms>");

			    string=sb.toString();
			   }	   
			  } 
		catch (Exception localException) {
			System.out.println(localException);
			
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    sb.append("could not getbyid room info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    sb.append("</roomId>");
			    sb.append("</Room>");
			    string= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (tx!=null)
			   tx.rollback();
			} finally {
				rdSession.close();
			}
	return string;
}

	public String getAllRoomsbyfloorid(int PNO, int size,int structureId,int floorId,int schoolId,int branchId) {
		Session gtempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gtTx=null;
			StringBuffer sb= new StringBuffer();
			System.out.println("hi dao impl success");
			String strg= null;
				try {
					gtTx = gtempSession.beginTransaction();
					String filterWhere="";
				   
				     if(structureId!=0){
						filterWhere +=  " and f.StructureId="+structureId;
						 if(floorId!=0){									  								    	
						    	filterWhere+=" and f.FloorId="+floorId;	
						    }
						}
				    
					List list=gtempSession.createSQLQuery("SELECT r.FloorId,r.RoomId,f.FloorName,r.RoomTypeId,rt.TypeName,r.RoomNo,r.NumberOfRows,r.NumberOfColumns,r.NumberOfSeatsPerRow,r.ColnoRowSeats,r.RoomName,r.AC,r.Capacity,r.Size,r.`Status`,r.RoomDescription,r.Remarks,r.SeatingNo,r.AllowAisles,r.Image,rt.TypeFlag,r.SchoolId,r.BranchId,r.SeatingTypeId,st.SeatingTypeNo,st.SeatingTitle,f.StructureId,str.StructureName  FROM gbl_sm_tbl_room as r JOIN gbl_sm_tbl_floor as f JOIN gbl_sm_tbl_room_type as rt JOIN gbl_sm_tbl_seatingtype AS st JOIN gbl_sm_tbl_structure as str ON r.FloorId = f.FloorId and r.RoomTypeId=rt.RoomTypeId and r.SeatingTypeId = st.SeatingTypeId and f.StructureId = str.StructureId where r.IsDeleted <> 'Y' or r.IsDeleted IS NULL  and r.SchoolId ='" + schoolId + "'and r.BranchId ='" + branchId + "' " + filterWhere + ";").list();
				     Iterator it=list.iterator();
				    		    sb.append("<Floor>");
						        sb.append("\n");
						        while(it.hasNext()){
								Object[] ex=(Object[])it.next();
								sb.append("<Room>");
							    sb.append("\n");
						       sb.append("<floorId>");
							    sb.append(ex[0]);
							    sb.append("</floorId>");
							    sb.append("\n");
							    sb.append("<roomId>");
							    sb.append(ex[1]);
							    sb.append("</roomId>");
							    sb.append("\n");
							    sb.append("<floorName>");
								sb.append(ex[2]);
								sb.append("</floorName>");
								 sb.append("\n");
								sb.append("<roomTypeId>");
								sb.append(ex[3]);
								sb.append("</roomTypeId>");
								 sb.append("\n");
								sb.append("<typename>");
								sb.append(ex[4]);
								sb.append("</typename>");
								sb.append("\n");
								sb.append("<roomNo>");
								sb.append(ex[5]);
								sb.append("</roomNo>");
								sb.append("\n");
								sb.append("<numberOfRows>");
								sb.append(ex[6]);
								sb.append("</numberOfRows>");
								sb.append("\n");
								sb.append("<numberOfColumns>");
								sb.append(ex[7]);
								sb.append("</numberOfColumns>");
								sb.append("\n");
								sb.append("<numberOfSeatsPerRow>");
								sb.append(ex[8]);
								sb.append("</numberOfSeatsPerRow>");
								sb.append("\n");
								sb.append("<colnoRowSeats>");
								sb.append(ex[9]);
								sb.append("</colnoRowSeats>");
								sb.append("\n");
								sb.append("<roomName>");
								sb.append(ex[10]);
								sb.append("</roomName>");
								sb.append("\n");
								sb.append("<ac>");
								sb.append(ex[11]);
								sb.append("</ac>");
								sb.append("\n");
								sb.append("<capacity>");
								sb.append(ex[12]);
								sb.append("</capacity>");
								sb.append("\n");
								sb.append("<size>");
								sb.append(ex[13]);
								sb.append("</size>");
								sb.append("\n");
								sb.append("<status>");
								sb.append(ex[14]);
								sb.append("</status>");
								sb.append("\n");
								sb.append("<roomDescription>");
								sb.append(ex[15]);
								sb.append("</roomDescription>");
								sb.append("\n");
								sb.append("<remarks>");
								sb.append(ex[16]);
								sb.append("</remarks>");
								sb.append("\n");
								sb.append("<seatingNo>");
								sb.append(ex[17]);
								sb.append("</seatingNo>");
								sb.append("\n");
								sb.append("<allowAisles>");
								sb.append(ex[18]);
								sb.append("</allowAisles>");
								sb.append("\n");
								sb.append("<image>");
								sb.append(ex[19]);
								sb.append("</image>");
								sb.append("\n");
								sb.append("<typeFlag>");
								sb.append(ex[20]);
								sb.append("</typeFlag>");
								sb.append("\n");
								sb.append("<schoolId>");
								sb.append(ex[21]);
								sb.append("</schoolId>");
								sb.append("\n");
								sb.append("<branchId>");
								sb.append(ex[22]);
								sb.append("</branchId>");
								sb.append("\n");
								sb.append("<seatingTypeId>");
								sb.append(ex[23]);
								sb.append("</seatingTypeId>");
								sb.append("\n");
								sb.append("<seatingTypeNo>");
								sb.append(ex[24]);
								sb.append("</seatingTypeNo>");
								sb.append("\n");
								sb.append("<seatingTitle>");
								sb.append(ex[25]);
								sb.append("</seatingTitle>");
								sb.append("\n");
								sb.append("<structureId>");
								sb.append(ex[26]);
								sb.append("</structureId>");
								sb.append("\n");
								sb.append("<structureName>");
								sb.append(ex[27]);
								sb.append("</structureName>");
								sb.append("\n");
								sb.append("</Room>");
						        }
								sb.append("</Floor>");
							    strg= sb.toString();
							
					
					
			} 	catch (Exception localException) {
				System.out.println(localException);
				
				   sb.append("<Response>");
				    sb.append("\n");
				    sb.append("<Result>");
				    sb.append("\n");
				    sb.append("Fail");
				    sb.append("\n");
				    sb.append("</Result>");
				    sb.append("\n");
				    sb.append("<Description>");
				    
				    sb.append("could not getbyid room info");
				    sb.append("</Description>");
				    sb.append("\n");
				    sb.append("<Exception>");
				    sb.append(localException);
				    sb.append("</Exception>");
				    sb.append("</Response>");
				    sb.append("</fieldId>");
				    sb.append("</Field>");
				    strg= sb.toString();
				   MDTransactionWriter.exceptionlog.info(localException);
				  if (gtTx!=null)
					  gtTx.rollback();
				} finally {
					gtempSession.close();
				}
		return strg;
	}
}

