
package com.gwebitsol.core.infrastructure;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.stereotype.Service;

import com.gwebitsol.core.infrastructure.StructureDao;
import com.gwebitsol.core.security.MDValidation;
import com.gwebitsol.core.security.MDVerifyConnectionID;
import com.gwebitsol.core.security.MDVerifyDatastoreName;
import com.gwebitsol.core.usermanagement.MDGetUserFromID;
import com.gwebitsol.core.util.MDTransactionWriter;

@Service
public class RoomService implements RoomIntf{
	@Context 
	private HttpServletRequest hsr;
	public Response addRoom(RoomPojo rp, int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String XMLString=null;
	    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		rp.setSchoolId(schoolId);
		rp.setBranchId(branchId);
		try
		{
			MDValidation mdv = new MDValidation();  
			int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			System.out.println("verifiedvalue::"+ret);
			MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userID);
			if(ret==1 )//&& rtVal==1)
			{
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				RoomDao rpDAO=new RoomDao();
				XMLString=rpDAO.addRoom(rp);
				System.out.println(XMLString);
				MDTransactionWriter.writeLog(datastoreName,"RoomService_addRoom",requester,startDate,endDate,sl,el,XMLString,hsr.getRemoteHost());
		}
			else
			{
				XMLString="you are not authorised user";
			}
		}
		
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
		   XMLString="failed in service layer";
		}
	
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
				
	}
	public Response updateRoom(RoomPojo rp, int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String XMLString=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		rp.setSchoolId(schoolId);
		rp.setBranchId(branchId);
		try
		{
		MDValidation mdv = new MDValidation();  
		int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
		System.out.println("verifiedvalue::"+ret);
		MDGetUserFromID mdgufid = new MDGetUserFromID();
		String requester = mdgufid.getUserName(userID);
			if(ret==1 )//&& rtVal==1)
			{
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			RoomDao flDAO=new RoomDao();
			XMLString=flDAO.updateRoom(rp,schoolId,branchId);
			System.out.println(XMLString);
			MDTransactionWriter.writeLog(datastoreName,"RoomService_updateRoom",requester,startDate,endDate,sl,el,XMLString,hsr.getRemoteHost());
	}
			else
			{
				XMLString="you are not authorised user";
			}
		}
	catch(Exception localException)
	{
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
	   XMLString="failed in service layer";
	}

	return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}
	public Response deleteRoom(int roomId, int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		String XMLString=null;
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{	
			MDValidation mdv = new MDValidation();  
			int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			System.out.println("verifiedvalue::"+ret);
			MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userID);
		if(ret==1 )//&& rtVal==1)
		{
			
		RoomDao ex=new RoomDao();
		status=ex.deleteRoom(roomId,schoolId,branchId);
		
		String endDate=dateFormat.format(new Date());	
		Long el=System.currentTimeMillis();
		//status="user validation successfull";
			MDTransactionWriter.writeLog(datastoreName,"RoomService_deleteRoom",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
	}
	else
	{
		XMLString="you are not authorised user";
	}
	
		}
	catch(Exception localException)
	{
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
		status="failed in service layer";
	}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();	
	}
	public Response getByRoomId(int roomId, int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		String XMLString=null;
		String status1=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{	
			MDValidation mdv = new MDValidation();  
			int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			System.out.println("verifiedvalue::"+ret);
			MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userID);
			if(ret==1 )//&& rtVal==1)
			{
			RoomDao ex=new RoomDao();
			 status1=ex.getByIdRoom(roomId,schoolId,branchId);
			 System.out.println(status1);
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			//status1="user validation successfull";
			MDTransactionWriter.writeLog(datastoreName,"RoomService_getByRoomId",requester,startDate,endDate,sl,el,status1,hsr.getRemoteHost());		
			}
			else
			{
				XMLString="you are not authorised user";
			}
			
		}
		catch(Exception localException)
		{
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
		status1="failed in service layer";
		//System.out.println(localException);
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status1).build();
		}
	
	public Response getAllroom(int userID, int connectionID,String datastoreName, int PNO, int size,int schoolId,int branchId) {	
	MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
	String XMLString=null;
		
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try{
			MDValidation mdv = new MDValidation();  
			int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			System.out.println("verifiedvalue::"+ret);
			MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userID);
			if(ret==1 )//&& rtVal==1)
			{
			
			RoomDao ex=new RoomDao();
			status=ex.getAllroom(PNO,size,schoolId,branchId);
			System.out.println(status);
			String endDate=dateFormat.format(new Date());
			  Long el=System.currentTimeMillis();
			 MDTransactionWriter.writeLog(datastoreName,"RoomService_getAllroom",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		

		}
			else
			{
				XMLString="you are not authorised user";
			}
			
		}catch(Exception localException)
		   {
			  MDTransactionWriter.errorlog.debug(localException);
			  MDTransactionWriter.errorlog.info(localException);
			  status="failed in service layer";
		   }
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}
	public Response getAllRoomsbyfloorid(int structureId,int floorId, int userid, int connectionid, String datastoreName, int PNO,int size,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String XMLString=null;
			
			String status=null;
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date date = new Date();
			String startDate=dateFormat.format(date);
			Long sl=System.currentTimeMillis();
			try{
				MDValidation mdv = new MDValidation();  
				int ret =mdv.allvalidations(userid, connectionid, datastoreName,schoolId,branchId);
				System.out.println("verifiedvalue::"+ret);
				MDGetUserFromID mdgufid = new MDGetUserFromID();
				String requester = mdgufid.getUserName(userid);
				if(ret==1 )//&& rtVal==1)
				{
				
				RoomDao ex=new RoomDao();
				status=ex.getAllRoomsbyfloorid(PNO,size,structureId,floorId,schoolId,branchId);
				System.out.println(status);
				String endDate=dateFormat.format(new Date());
				  Long el=System.currentTimeMillis();
				 MDTransactionWriter.writeLog(datastoreName,"RoomService_getAllRoomsbyfloorid",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		

			}
				else
				{
					XMLString="you are not authorised user";
				}
				
			}catch(Exception localException)
			   {
				  MDTransactionWriter.errorlog.debug(localException);
				  MDTransactionWriter.errorlog.info(localException);
				  status="failed in service layer";
			   }
			return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	
}

