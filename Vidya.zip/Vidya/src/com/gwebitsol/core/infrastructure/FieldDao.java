
package com.gwebitsol.core.infrastructure;

import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;



import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

@Repository
public class FieldDao {
	Session addempSession=MDHibernateUtil.getSessionFactory().openSession();
	Transaction addempTx=null;
	
	public String addField(FieldPojo fp)
	{
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			addempTx=addempSession.beginTransaction();
			Integer in=(Integer)addempSession.save(fp);
			System.out.println(in);
			addempTx.commit();
			sb.append("<Field>");
			sb.append("\n");
			sb.append("<Fieldid>");
			sb.append(in);
			sb.append("</Fieldid>");
			sb.append("</Field>");
			outStr=sb.toString();
		   
   		 	}
		
		catch(Exception localException)
		{
			System.out.println(localException);
			
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    
			    sb.append("could not inserted field info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    outStr= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (addempTx!=null)
				  addempTx.rollback();
		}
		finally
		{			
			addempSession.close();
		}
		return outStr;
		}
	public String updateField(FieldPojo fp,int schoolId,int branchId) {
		Session upempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction upempTx=null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			upempTx=upempSession.beginTransaction();
			FieldPojo field = (FieldPojo) upempSession.get(FieldPojo.class,fp.getFieldId());
			upempSession.evict(field);
			if(branchId==field.getBranchId()&&schoolId==field.getSchoolId())
			upempSession.update(fp);
			upempTx.commit();
			sb.append("<Field>");
			sb.append("\n");
			sb.append("update sucessfully");
			sb.append("</Field>");
			String str=sb.toString();
			return str;
   		 	}
		catch(Exception localException)
		{
			System.out.println(localException);
			
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    
			    sb.append("could not update field info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    outStr= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (upempTx!=null)
				  upempTx.rollback();
		}
		finally
		{			
			upempSession.close();
		}
		return outStr;
	}
	public String deleteFieldPojo(int fieldId,int schoolId,int branchId) {
		Session delempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction delempTx=null;
		StringBuffer sb=new StringBuffer();
		
		String outStr=null;
		try
		{
			delempTx=delempSession.beginTransaction();
			FieldPojo field = (FieldPojo) delempSession.get(FieldPojo.class,fieldId);
			   int branid = field.getBranchId();
			   int sclid = field.getSchoolId();
			   delempSession.evict(field);             
			   if(branchId==branid&&schoolId==sclid)
			   {
			Query empQuery=delempSession.createSQLQuery("update gbl_sm_tbl_field set IsDeleted ='Y' where fieldId='"+fieldId+"'");
			empQuery.executeUpdate();
			delempTx.commit();
			sb.append("<Field>");
			sb.append("\n");
			sb.append("deleted sucessfully");
			sb.append("</Field>");
			String str=sb.toString();
			return str;
   		 	}
			   else
			   {
				   outStr = "field is not deleted";
			    sb.append("<Field>");
			    sb.append("\n");
			    sb.append(outStr);
			    sb.append("</Field>");
			    String str = sb.toString();
			    return str;
			   }
				}
		catch(Exception localException)
		{
			System.out.println(localException);
			
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    
			    sb.append("could not delete field info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    outStr= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (delempTx!=null)
				  delempTx.rollback();
		}
		finally
		{			
			delempSession.close();
		}
		return outStr;
	}
	public String getByIdFieldId(int fieldId,int schoolId,int branchId) {
		Session gtempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gtTx=null;
			StringBuffer sb= new StringBuffer();
			System.out.println("hi dao impl success");
			String strg= null;
				try {
						gtTx = gtempSession.beginTransaction();
						List list=gtempSession.createSQLQuery("SELECT f.FieldId,f.RoomTypeId,rt.TypeName,f.FieldNo,f.FieldName,f.Description,f.SchoolId,f.BranchId FROM gbl_sm_tbl_field as f INNER JOIN gbl_sm_tbl_room_type as rt ON f.RoomTypeId=rt.RoomTypeId where f.IsDeleted <> 'Y' or f.IsDeleted IS NULL and FieldId='" + fieldId + "' and f.SchoolId ='" + schoolId + "'and f.BranchId ='" + branchId + "' ;").list();
					     Iterator it=list.iterator();
					    		    sb.append("<Field>");
							        sb.append("\n");
							        while(it.hasNext())
							        {
									Object[] ex=(Object[])it.next();
							        sb.append("<fieldId>");
								    sb.append(ex[0]);
								    sb.append("</fieldId>");
								    sb.append("\n");
								    sb.append("<fieldNo>");
								    sb.append(ex[3]);
								    sb.append("</fieldNo>");
								    sb.append("\n");
								    sb.append("<fieldName>");
									sb.append(ex[4]);
									sb.append("</fieldName>");
									 sb.append("\n");
									sb.append("<description>");
									sb.append(ex[5]);
									sb.append("</description>");
									 sb.append("\n");
									sb.append("<roomTypeId>");
									sb.append(ex[1]);
									sb.append("</roomTypeId>");
									sb.append("\n");
									sb.append("<typename>");
									sb.append(ex[2]);
									sb.append("</typename>");
									sb.append("\n");
									sb.append("<schoolId>");
									sb.append(ex[6]);
									sb.append("</schoolId>");
									sb.append("\n");
									sb.append("<branchId>");
									sb.append(ex[7]);
									sb.append("</branchId>");
									sb.append("\n");
							        }
									sb.append("</Field>");
								    strg= sb.toString();
								
						
						
				} 	catch (Exception localException) {
					System.out.println(localException);
					
					   sb.append("<Response>");
					    sb.append("\n");
					    sb.append("<Result>");
					    sb.append("\n");
					    sb.append("Fail");
					    sb.append("\n");
					    sb.append("</Result>");
					    sb.append("\n");
					    sb.append("<Description>");
					    
					    sb.append("could not getbyid field info");
					    sb.append("</Description>");
					    sb.append("\n");
					    sb.append("<Exception>");
					    sb.append(localException);
					    sb.append("</Exception>");
					    sb.append("</Response>");
					    sb.append("</fieldId>");
					    sb.append("</Field>");
					    strg= sb.toString();
					   MDTransactionWriter.exceptionlog.info(localException);
					  if (gtTx!=null)
						  gtTx.rollback();
					} finally {
						gtempSession.close();
					}
			return strg;
	}
	public String getAllfield(int PNO, int size,int schoolId,int branchId) {
		Session rdSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb= new StringBuffer();
		String string=null;
	    FieldPojo ex1=null;
		
		try
		{
			tx = rdSession.beginTransaction();
			
			 if(("all") != null)
			   {
			    int fset = (PNO-1)*size;
			    String gsSql ="select count(*) from gbl_sm_tbl_field as f where f.IsDeleted <> 'Y' or f.IsDeleted IS NULL and f.SchoolId ='" + schoolId + "'and f.BranchId ='" + branchId + "'";
			    Query gsQuery=rdSession.createSQLQuery(gsSql);
			    Object noRecords= gsQuery.uniqueResult();
			    sb.append("<Fieldes>");
			    sb.append("\n");
			    sb.append("<noRecords>"+noRecords+"</noRecords>");
			    sb.append("\n");
			    
			     if (PNO > 0 & size > 0){
			     gsSql="SELECT f.FieldId,f.RoomTypeId,rt.TypeName,f.FieldNo,f.FieldName,f.Description,f.SchoolId,f.BranchId FROM gbl_sm_tbl_field as f JOIN gbl_sm_tbl_room_type as rt ON f.RoomTypeId=rt.RoomTypeId where f.IsDeleted <> 'Y' or f.IsDeleted IS NULL and f.SchoolId ='" + schoolId + "'and f.BranchId ='" + branchId + "' limit "+size+" offset "+fset;}
			     else {
			      gsSql="SELECT f.FieldId,f.RoomTypeId,rt.TypeName,f.FieldNo,f.FieldName,f.Description,f.SchoolId,f.BranchId FROM gbl_sm_tbl_field as f JOIN gbl_sm_tbl_room_type as rt ON f.RoomTypeId=rt.RoomTypeId where f.IsDeleted <> 'Y' or f.IsDeleted IS NULL and f.SchoolId ='" + schoolId + "'and f.BranchId ='" + branchId + "'";
			     } 
			   
			    gsQuery=rdSession.createSQLQuery(gsSql);
			    List gcList=gsQuery.list();
			    Iterator gsIT=gcList.iterator();
			    while(gsIT.hasNext())
			     {
			      Object[] mdcArr=(Object[])gsIT.next();
			      sb.append("<field>");
			      sb.append("\n");
			      sb.append("<fieldId>"+mdcArr[0]+"</fieldId>");
			      sb.append("\n");
			      sb.append("<typeName>" + mdcArr[2]+ "</typeName>");
			      sb.append("\n");
			      sb.append("<fieldNo>" + mdcArr[3]+ "</fieldNo>");
			      sb.append("\n");
			      sb.append("<fieldName>" + mdcArr[4] + "</fieldName>");
			      sb.append("\n");
			      sb.append("<description>" + mdcArr[5] + "</description>");
			      sb.append("\n");
			      sb.append("<roomTypeId>" + mdcArr[1]+ "</roomTypeId>");
			      sb.append("\n");
			      sb.append("<schoolId>" + mdcArr[6]+ "</schoolId>");
			      sb.append("\n");
			      sb.append("<branchId>" + mdcArr[7]+ "</branchId>");
			      sb.append("</field>");
			      sb.append("\n");
			     }
			    
			    tx.commit();
			    sb.append("</Fieldes>");
			    sb.append("\n");

			    string=sb.toString();
			   }
			  } 
		catch (Exception localException) {
			System.out.println(localException);
			
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    sb.append("could not getbyid field info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    sb.append("</fieldId>");
			    sb.append("</Field>");
			    string= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (tx!=null)
			   tx.rollback();
			} finally {
				rdSession.close();
			}
	return string;
}
}
