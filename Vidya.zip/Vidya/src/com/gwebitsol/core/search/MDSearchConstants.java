package com.gwebitsol.core.search;

public class MDSearchConstants {
	public static final String USER_URL="/usermanagement/getusers";
	public static final String OBJECT_URL="/objectmanagement/getObject";
	public static final String DEVICE_URL="/devicemanagement/getDevice";
	public static final String ROUTE_URL="/routemanagement/getRoute";
	public static final String SERVICE_URL="/servicemanagement/getService";

}
