package com.gwebitsol.core.search;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

import com.gwebitsol.core.assessments.AssessmentPojo;
import com.gwebitsol.core.assessments.QuestionPaperPojo;
import com.gwebitsol.core.assessments.QuestionPojo;
import com.gwebitsol.core.curriculum.AttendencePojo;
import com.gwebitsol.core.curriculum.PeriodPojo;
import com.gwebitsol.core.curriculum.SectionPojo;
import com.gwebitsol.core.curriculum.TimeTablePojo;
import com.gwebitsol.core.fee.FeeItemPojo;
import com.gwebitsol.core.fee.FeeStructure;
import com.gwebitsol.core.fee.Payment;
import com.gwebitsol.core.infrastructure.RoomPojo;
import com.gwebitsol.core.library.BookReceiptPojo;
import com.gwebitsol.core.library.CataloguePojo;
import com.gwebitsol.core.library.IssuePojo;
import com.gwebitsol.core.library.LibSubjectPojo;
import com.gwebitsol.core.padagogy.ChapterPojo;
import com.gwebitsol.core.padagogy.CoursePojo;
import com.gwebitsol.core.padagogy.LessonPlanPojo;
import com.gwebitsol.core.padagogy.ReferenceBookPojo;
import com.gwebitsol.core.padagogy.SubjectPojo;
import com.gwebitsol.core.padagogy.TopicPojo;
import com.gwebitsol.core.padagogy.UnitsPojo;
import com.gwebitsol.core.parent.ParentPojo;
import com.gwebitsol.core.school.SchoolBranchPojo;
import com.gwebitsol.core.staff.StaffAccoladePojo;
import com.gwebitsol.core.staff.StaffEducationPojo;
import com.gwebitsol.core.staff.StaffExperiencePojo;
import com.gwebitsol.core.staff.StaffPojo;
import com.gwebitsol.core.staff.StaffSubjectsPojo;
import com.gwebitsol.core.student.StudentEducationPojo;
import com.gwebitsol.core.student.StudentPojo;

@Path("/searchmanagement/")
public interface MDSearchManagementServiceIntf 
{
	@Path("/searchObj/")
	@POST
	@Consumes({"application/xml", "application/json"})
	@Produces({"application/xml", "application/json"})
	public Response searchObject(@QueryParam("infoclassname") String infoclassname,@QueryParam("searchParameter") String searchParameter,@QueryParam("searchParameterValue") String searchParameterValue,@QueryParam("criteria") String criteria,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@Path("/searchDev/")
	@POST
	@Consumes({"application/xml", "application/json"})
	@Produces({"application/xml", "application/json"})
	public Response searchDevice(@QueryParam("infoclassname") String infoclassname,@QueryParam("searchParameter") String searchParameter,@QueryParam("searchParameterValue") String searchParameterValue,@QueryParam("criteria") String criteria,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@Path("/applicationSearch")
	@GET
	@Produces("application/xml")
	public Response applicationSearch(@QueryParam("searchWord")String searchWord,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("rowStartIdx")final int rowStartIdx,@QueryParam("rowEndIdx")final int rowEndIdx);

	@Path("/attandancesearch")
	@POST
	@Consumes({"application/xml", "application/json"})
	@Produces({"application/xml", "application/json"})
	public Response searchAttendance(AttendencePojo attendencePojo,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@Path("/sectionsearch")
	@POST
	@Consumes({"application/xml", "application/json"})
	@Produces({"application/xml", "application/json"})
	public Response searchSection(SectionPojo sectionPojo,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@Path("/timetablesearch")
	@POST
	@Consumes({"application/xml", "application/json"})
	@Produces({"application/xml", "application/json"})
	public Response searchTimeTable(TimeTablePojo timeTablePojo,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@Path("/periodsearch")
	@POST
	@Consumes({"application/xml", "application/json"})
	@Produces({"application/xml", "application/json"})
	public Response searchPeriods(PeriodPojo periodPojo,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@Path("/coursesearch")
	@POST
	@Consumes({"application/xml", "application/json"})
	@Produces({"application/xml", "application/json"})
	public Response searchCourse(CoursePojo coursePojo,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@Path("/chaptersearch")
	@POST
	@Consumes({"application/xml", "application/json"})
	@Produces({"application/xml", "application/json"})
	public Response searchChapter(ChapterPojo chapterPojo,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	@Path("/topicsearch")
	@POST
	@Consumes({"application/xml", "application/json"})
	@Produces({"application/xml", "application/json"})
	public Response searchTopics(TopicPojo topicPojo,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@Path("/unitssearch")
	@POST
	@Consumes({"application/xml", "application/json"})
	@Produces({"application/xml", "application/json"})
	public Response searchUnits(UnitsPojo unitsPojo,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@Path("/referencebookssearch")
	@POST
	@Consumes({"application/xml", "application/json"})
	@Produces({"application/xml", "application/json"})
	public Response searchReferenceBook(ReferenceBookPojo referenceBookPojo,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@Path("/subjectsearch")
	@POST
	@Consumes({"application/xml", "application/json"})
	@Produces({"application/xml", "application/json"})
	public Response searchSubject(SubjectPojo subjectPojo,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@Path("/lessonplansearch")
	@POST
	@Consumes({"application/xml", "application/json"})
	@Produces({"application/xml", "application/json"})
	public Response searchLessonPlan(LessonPlanPojo lessonPlanPojo,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);

    
	   
	@Path("/searchStudent")
		@POST
		@Consumes({ "application/xml", "application/json" })
		@Produces({ "application/xml", "application/json" })
		public Response searchStudent(StudentPojo sp, @QueryParam("userid") int userid,
				@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
				@QueryParam("schoolid") int schoolid, @QueryParam("branchid") int branchid);

		@Path("/searchStudentEducation")
		@POST
		@Consumes({ "application/xml", "application/json" })
		@Produces({ "application/xml", "application/json" })
		public Response searchStudentEducation(StudentEducationPojo sep, @QueryParam("userid") int userid,
				@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
				@QueryParam("schoolid") int schoolid, @QueryParam("branchid") int branchid);

		@Path("/searchParent")
		@POST
		@Consumes({ "application/xml", "application/json" })
		@Produces({ "application/xml", "application/json" })
		public Response searchParent(ParentPojo pp, @QueryParam("userid") int userid,
				@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
				@QueryParam("schoolid") int schoolid, @QueryParam("branchid") int branchid);

		@Path("/searchStaff")
		@POST
		@Consumes({ "application/xml", "application/json" })
		@Produces({ "application/xml", "application/json" })
		public Response searchStaff(StaffPojo sp, @QueryParam("userid") int userid,
				@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
				@QueryParam("schoolid") int schoolid, @QueryParam("branchid") int branchid);

		@Path("/searchStaffEducation")
		@POST
		@Consumes({ "application/xml", "application/json" })
		@Produces({ "application/xml", "application/json" })
		public Response searchStaffEducation(StaffEducationPojo sep, @QueryParam("userid") int userid,
				@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
				@QueryParam("schoolid") int schoolid, @QueryParam("branchid") int branchid);

		@Path("/searchStaffExperience")
		@POST
		@Consumes({ "application/xml", "application/json" })
		@Produces({ "application/xml", "application/json" })
		public Response searchStaffExperience(StaffExperiencePojo sep, @QueryParam("userid") int userid,
				@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
				@QueryParam("schoolid") int schoolid, @QueryParam("branchid") int branchid);

		@Path("/searchStaffSubjects")
		@POST
		@Consumes({ "application/xml", "application/json" })
		@Produces({ "application/xml", "application/json" })
		public Response searchStaffSubjects(StaffSubjectsPojo ssp, @QueryParam("userid") int userid,
				@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
				@QueryParam("schoolid") int schoolid, @QueryParam("branchid") int branchid);

		@Path("/searchStaffAccolades")
		@POST
		@Consumes({ "application/xml", "application/json" })
		@Produces({ "application/xml", "application/json" })
		public Response searchStaffAccolades(StaffAccoladePojo sap, @QueryParam("userid") int userid,
				@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
				@QueryParam("schoolid") int schoolid, @QueryParam("branchid") int branchid);

	@Path("/assessment")
	@POST
	@Consumes({"application/xml", "application/json"})
	@Produces({"application/xml", "application/json"})
	public Response searchAssessment(AssessmentPojo ast,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@Path("/branch")
	@POST
	@Consumes({"application/xml", "application/json"})
	@Produces({"application/xml", "application/json"})
	public Response searchBranch(SchoolBranchPojo sbp,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@Path("/question")
	@POST
	@Consumes({"application/xml", "application/json"})
	@Produces({"application/xml", "application/json"})
	public Response searchQuestion(QuestionPojo qp,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@Path("/questionpaper")
	@POST
	@Consumes({"application/xml", "application/json"})
	@Produces({"application/xml", "application/json"})
	public Response searchQuestionPaper(QuestionPaperPojo qpp,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@Path("/room")
	@POST
	@Consumes({"application/xml", "application/json"})
	@Produces({"application/xml", "application/json"})
	public Response searchRoom(RoomPojo rp,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@Path("/searchbook")
	@POST
	@Consumes({"application/xml", "application/json"})
	@Produces({"application/xml", "application/json"})
	public Response searchBook(CataloguePojo cp,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);
	
	@Path("/searchlibsubject/")
	@POST
	@Consumes({"application/xml", "application/json"})
	@Produces({"application/xml", "application/json"})
	public Response searchLibSubject(LibSubjectPojo cp,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);
	
	@Path("/searchissues/")
	@POST
	@Consumes({"application/xml", "application/json"})
	@Produces({"application/xml", "application/json"})
	public Response searchIssues(IssuePojo ip,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);

	@Path("/searchbookrecipts/")
	@POST
	@Consumes({"application/xml", "application/json"})
	@Produces({"application/xml", "application/json"})
	public Response searchBookReceipt(BookReceiptPojo ip,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);

	@Path("/searchfeestructure/")
	@POST
	@Consumes({"application/xml", "application/json"})
	@Produces({"application/xml", "application/json"})
	public Response searchFeeStructure(FeeStructure cp,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);
	
	@Path("/searchfeeitems/")
	@POST
	@Consumes({"application/xml", "application/json"})
	@Produces({"application/xml", "application/json"})
	public Response searchFeeItems(FeeItemPojo ip,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);
	
	@Path("/searchpayment/")
	@POST
	@Consumes({"application/xml", "application/json"})
	@Produces({"application/xml", "application/json"})
	public Response searchPayment(Payment ip,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);

	@GET
	@Produces ({"application/xml","application/json"})
	@Path("/getparticularfieldsvalues")
	public Response getFieldValues(@QueryParam("infoclassName") String infoclassName,@QueryParam("fieldnames") String fieldnames,@QueryParam("filter") String filter,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("PNO") int PNO,@QueryParam("size") int size);
		
	

    	
}
