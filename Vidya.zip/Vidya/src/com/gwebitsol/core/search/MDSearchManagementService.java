package com.gwebitsol.core.search;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.gwebitsol.core.assessments.AssessmentPojo;
import com.gwebitsol.core.assessments.QuestionPaperPojo;
import com.gwebitsol.core.assessments.QuestionPojo;
import com.gwebitsol.core.curriculum.AttendencePojo;
import com.gwebitsol.core.curriculum.PeriodPojo;
import com.gwebitsol.core.curriculum.SectionPojo;
import com.gwebitsol.core.curriculum.TimeTablePojo;
import com.gwebitsol.core.fee.FeeItemPojo;
import com.gwebitsol.core.fee.FeeStructure;
import com.gwebitsol.core.fee.Payment;
import com.gwebitsol.core.infrastructure.RoomPojo;
import com.gwebitsol.core.library.BookReceiptPojo;
import com.gwebitsol.core.library.CataloguePojo;
import com.gwebitsol.core.library.IssuePojo;
import com.gwebitsol.core.library.LibSubjectPojo;
import com.gwebitsol.core.padagogy.ChapterPojo;
import com.gwebitsol.core.padagogy.CoursePojo;
import com.gwebitsol.core.padagogy.LessonPlanPojo;
import com.gwebitsol.core.padagogy.ReferenceBookPojo;
import com.gwebitsol.core.padagogy.SubjectPojo;
import com.gwebitsol.core.padagogy.TopicPojo;
import com.gwebitsol.core.padagogy.UnitsPojo;
import com.gwebitsol.core.parent.ParentPojo;
import com.gwebitsol.core.school.SchoolBranchPojo;
import com.gwebitsol.core.security.MDValidation;
import com.gwebitsol.core.security.MDVerifyConnectionID;
import com.gwebitsol.core.security.MDVerifyDatastoreName;
import com.gwebitsol.core.staff.StaffAccoladePojo;
import com.gwebitsol.core.staff.StaffEducationPojo;
import com.gwebitsol.core.staff.StaffExperiencePojo;
import com.gwebitsol.core.staff.StaffPojo;
import com.gwebitsol.core.staff.StaffSubjectsPojo;
import com.gwebitsol.core.student.StudentEducationPojo;
import com.gwebitsol.core.student.StudentPojo;
import com.gwebitsol.core.usermanagement.MDGetUserFromID;
import com.gwebitsol.core.util.MDTransactionWriter;

public class MDSearchManagementService implements MDSearchManagementServiceIntf
{
	
	@Context private HttpServletRequest hsr;
	public Response searchObject(String infoclassname,String searchParameter,String searchParameterValue,String criteria,int userID,int connectionID,String datastoreName) 
	{

		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
				MDSearchManagementDAO mdsmDAO=new MDSearchManagementDAO();
				XMLString=mdsmDAO.searchObject(infoclassname,searchParameter,searchParameterValue,criteria);
				if(XMLString.equals("error while searching object"))
					statusStr="failed";
				else
					statusStr="success";
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				
				MDTransactionWriter.writeLog(datastoreName,"SearchMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
				}
				else
				{
					XMLString="you are not authorised user";
				}
			}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			statusStr="failed in service layer";
		}
			return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
		}

	public Response searchDevice(String infoclassname,String searchParameter,String searchParameterValue,String criteria,int userID,int connectionID,String datastoreName) 
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
				MDSearchManagementDAO mdsmDAO=new MDSearchManagementDAO();
				XMLString=mdsmDAO.searchDevice(infoclassname,searchParameter,searchParameterValue,criteria);
				if(XMLString.equals("error while searching device"))
					statusStr="failed";
				else
					statusStr="success";
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				
				MDTransactionWriter.writeLog(datastoreName,"SearchMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
				}
				else
				{
					XMLString="you are not authorised user";
				}
			}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			statusStr="failed in service layer";
		}
			return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}

	public Response applicationSearch(String searchWord, int userid,
			int connectionid, int rowStartIdx, int rowEndIdx) {
		String outStr=null;
		StringBuffer sb=new StringBuffer();
		MDSearchManagementDAO dao=new MDSearchManagementDAO();
		List<Map<String, String>> list=	dao.applicationSearch(searchWord);
		int size=list.size();
		List<Map<String, String>> subList=new ArrayList<Map<String,String>>();
		if(rowStartIdx < rowEndIdx && rowEndIdx < size){
			subList=list.subList(rowStartIdx, rowEndIdx);
		}else if(rowStartIdx < size){
			subList=list.subList(rowStartIdx, size);
		}
		sb.append("<MD_Search>");
		sb.append("\n");
		for(Map<String, String> map:subList){
			
			    sb.append("<Search>");
				sb.append("\n");
				sb.append("<ID>"+map.get("ID")+"</ID>");
				sb.append("<information>");
			    sb.append("\n");
				sb.append("<RESULT>"+map.get("RESULT")+"</RESULT>");
				sb.append("\n");
				sb.append("<URL>"+map.get("URL")+"</URL>");
				sb.append("\n");
				sb.append("<DESCRIPTION>"+map.get("DESCRIPTION")+"</DESCRIPTION>");
				sb.append("\n");
			    sb.append("</information>");
			    sb.append("\n");
			    sb.append("</Search>");
			    sb.append("\n");
		}
		sb.append("</MD_Search>");
		sb.append("\n");
		outStr=sb.toString();
		return Response.ok().type(MediaType.APPLICATION_XML).entity(outStr).build();
	}

	public Response searchAttendance(AttendencePojo attendencePojo, int userID, int connectionID,String datastoreName) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
				MDSearchManagementDAO mdsmDAO=new MDSearchManagementDAO();
				statusStr=mdsmDAO.searchAttendance(attendencePojo);
				System.out.println(statusStr);
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				
				MDTransactionWriter.writeLog(datastoreName,"SearchMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
				}
				else
				{
					statusStr="you are not authorised user";
				}
			}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			statusStr="failed in service layer";
		}
			return Response.ok().type(MediaType.APPLICATION_XML).entity(statusStr).build();
	}
	public Response searchSection(SectionPojo sectionPojo, int userID, int connectionID,String datastoreName) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
				MDSearchManagementDAO mdsmDAO=new MDSearchManagementDAO();
				statusStr=mdsmDAO.searchSection(sectionPojo);
				System.out.println(statusStr);
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				
				MDTransactionWriter.writeLog(datastoreName,"SearchMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
				}
				else
				{
					statusStr="you are not authorised user";
				}
			}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			statusStr="failed in service layer";
		}
			return Response.ok().type(MediaType.APPLICATION_XML).entity(statusStr).build();
	}

	public Response searchTimeTable(TimeTablePojo timeTablePojo,int userID, int connectionID,String datastoreName) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
				MDSearchManagementDAO mdsmDAO=new MDSearchManagementDAO();
				statusStr=mdsmDAO.searchTimeTable(timeTablePojo);
				System.out.println(statusStr);
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				
				MDTransactionWriter.writeLog(datastoreName,"SearchMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
				}
				else
				{
					statusStr="you are not authorised user";
				}
			}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			statusStr="failed in service layer";
		}
			return Response.ok().type(MediaType.APPLICATION_XML).entity(statusStr).build();
	}
	

	public Response searchPeriods(PeriodPojo periodPojo, int userID, int connectionID,String datastoreName) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
				MDSearchManagementDAO mdsmDAO=new MDSearchManagementDAO();
				statusStr=mdsmDAO.searchPeriods(periodPojo);
				System.out.println(statusStr);
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				
				MDTransactionWriter.writeLog(datastoreName,"SearchMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
				}
				else
				{
					statusStr="you are not authorised user";
				}
			}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			statusStr="failed in service layer";
		}
			return Response.ok().type(MediaType.APPLICATION_XML).entity(statusStr).build();
	}
	

	public Response searchCourse(CoursePojo coursePojo,int userID, int connectionID,String datastoreName) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
				MDSearchManagementDAO mdsmDAO=new MDSearchManagementDAO();
				statusStr=mdsmDAO.searchCourse(coursePojo);
				System.out.println(statusStr);
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				
				MDTransactionWriter.writeLog(datastoreName,"SearchMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
				}
				else
				{
					statusStr="you are not authorised user";
				}
			}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			statusStr="failed in service layer";
		}
			return Response.ok().type(MediaType.APPLICATION_XML).entity(statusStr).build();
	}
	

	public Response searchChapter(ChapterPojo chapterPojo, int userID, int connectionID,String datastoreName) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
				MDSearchManagementDAO mdsmDAO=new MDSearchManagementDAO();
				statusStr=mdsmDAO.searchChapter(chapterPojo);
				System.out.println(statusStr);
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				
				MDTransactionWriter.writeLog(datastoreName,"SearchMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
				}
				else
				{
					statusStr="you are not authorised user";
				}
			}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			statusStr="failed in service layer";
		}
			return Response.ok().type(MediaType.APPLICATION_XML).entity(statusStr).build();
	}
	

	public Response searchTopics(TopicPojo topicPojo, int userID, int connectionID,String datastoreName) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
				MDSearchManagementDAO mdsmDAO=new MDSearchManagementDAO();
				statusStr=mdsmDAO.searchTopics(topicPojo);
				System.out.println(statusStr);
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				
				MDTransactionWriter.writeLog(datastoreName,"SearchMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
				}
				else
				{
					statusStr="you are not authorised user";
				}
			}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			statusStr="failed in service layer";
		}
			return Response.ok().type(MediaType.APPLICATION_XML).entity(statusStr).build();
	}
	

	public Response searchUnits(UnitsPojo unitsPojo, int userID, int connectionID,String datastoreName) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
				MDSearchManagementDAO mdsmDAO=new MDSearchManagementDAO();
				statusStr=mdsmDAO.searchUnits(unitsPojo);
				System.out.println(statusStr);
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				
				MDTransactionWriter.writeLog(datastoreName,"SearchMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
				}
				else
				{
					statusStr="you are not authorised user";
				}
			}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			statusStr="failed in service layer";
		}
			return Response.ok().type(MediaType.APPLICATION_XML).entity(statusStr).build();
	}
	
	public Response searchReferenceBook(ReferenceBookPojo referenceBookPojo, int userID, int connectionID,String datastoreName) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
				MDSearchManagementDAO mdsmDAO=new MDSearchManagementDAO();
				statusStr=mdsmDAO.searchReferenceBook(referenceBookPojo);
				System.out.println(statusStr);
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				
				MDTransactionWriter.writeLog(datastoreName,"SearchMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
				}
				else
				{
					statusStr="you are not authorised user";
				}
			}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			statusStr="failed in service layer";
		}
			return Response.ok().type(MediaType.APPLICATION_XML).entity(statusStr).build();
	}
	

	


	public Response searchLessonPlan(LessonPlanPojo lessonPlanPojo,int userID, int connectionID,String datastoreName) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
				MDSearchManagementDAO mdsmDAO=new MDSearchManagementDAO();
				statusStr=mdsmDAO.searchLessonPlan(lessonPlanPojo);
				System.out.println(statusStr);
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				
				MDTransactionWriter.writeLog(datastoreName,"SearchMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
				}
				else
				{
					statusStr="you are not authorised user";
				}
			}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			statusStr="failed in service layer";
		}
			return Response.ok().type(MediaType.APPLICATION_XML).entity(statusStr).build();
	}

	public Response searchSubject(SubjectPojo subjectPojo, int userID, int connectionID, String datastoreName) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
				MDSearchManagementDAO mdsmDAO=new MDSearchManagementDAO();
				statusStr=mdsmDAO.searchSubject(subjectPojo);
				System.out.println(statusStr);
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				
				MDTransactionWriter.writeLog(datastoreName,"SearchMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
				}
				else
				{
					statusStr="you are not authorised user";
				}
			}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			statusStr="failed in service layer";
		}
			return Response.ok().type(MediaType.APPLICATION_XML).entity(statusStr).build();
	}


	public Response searchStudent(StudentPojo sp, int userid, int connectionid, String datastoreName,int schoolid,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		@SuppressWarnings("unused")
		String XMLString=null;

				String status1=null;
				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date date = new Date();
				String startDate=dateFormat.format(date);
				Long sl=System.currentTimeMillis();
				
				
				try
			{	
					MDValidation mdv = new MDValidation();		
					int ret =mdv.allvalidations(userid, connectionid, datastoreName,schoolid, branchId);
					System.out.println("verifiedvalue::"+ret);
					if(ret==1 )//&& rtVal==1)
					{
						MDSearchManagementDAO ex=new MDSearchManagementDAO();
					    status1=ex.searchStudent(sp,schoolid, branchId);
								
					String endDate=dateFormat.format(new Date());
					Long el=System.currentTimeMillis();
					//status1="user validation successfull";
					MDTransactionWriter.writeLog("sai","CMS","requester",startDate,endDate,sl,el,status1,hsr.getRemoteHost());		
			}
					else
					{
						XMLString="you are not authorised user";
					}
				}
			catch(Exception localException)
			{
				MDTransactionWriter.errorlog.debug(localException);
				MDTransactionWriter.errorlog.info(localException);
				status1="failed in service layer";
				//System.out.println(localException);
			}
		 return Response.ok().type(MediaType.APPLICATION_XML).entity(status1).build();
	}

	public Response searchParent(ParentPojo pp, int userid, int connectionid, String datastoreName,int schoolid,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		@SuppressWarnings("unused")
		String XMLString=null;

				String status1=null;
				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date date = new Date();
				String startDate=dateFormat.format(date);
				Long sl=System.currentTimeMillis();
				
				
				try
			{	
					MDValidation mdv = new MDValidation();		
					int ret =mdv.allvalidations(userid, connectionid, datastoreName,schoolid, branchId);
					System.out.println("verifiedvalue::"+ret);
					if(ret==1 )//&& rtVal==1)
					{
						MDSearchManagementDAO ex=new MDSearchManagementDAO();
					    status1=ex.searchParent(pp,schoolid, branchId);
								
					String endDate=dateFormat.format(new Date());
					Long el=System.currentTimeMillis();
					//status1="user validation successfull";
					MDTransactionWriter.writeLog("sai","CMS","requester",startDate,endDate,sl,el,status1,hsr.getRemoteHost());		
			}
					else
					{
						XMLString="you are not authorised user";
					}
				}
			catch(Exception localException)
			{
				MDTransactionWriter.errorlog.debug(localException);
				MDTransactionWriter.errorlog.info(localException);
				status1="failed in service layer";
				//System.out.println(localException);
			}
		 return Response.ok().type(MediaType.APPLICATION_XML).entity(status1).build();
	}

	public Response searchStaff(StaffPojo sp, int userid, int connectionid, String datastoreName,int schoolid,int branchId) {
		
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		@SuppressWarnings("unused")
		String XMLString=null;

				String status1=null;
				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date date = new Date();
				String startDate=dateFormat.format(date);
				Long sl=System.currentTimeMillis();
				
				
				try
			{	
					MDValidation mdv = new MDValidation();		
					int ret =mdv.allvalidations(userid, connectionid, datastoreName,schoolid, branchId);
					System.out.println("verifiedvalue::"+ret);
					if(ret==1 )//&& rtVal==1)
					{
						MDSearchManagementDAO ex=new MDSearchManagementDAO();
					    status1=ex.searchStaff(sp,schoolid, branchId);
								
					String endDate=dateFormat.format(new Date());
					Long el=System.currentTimeMillis();
					//status1="user validation successfull";
					MDTransactionWriter.writeLog("sai","CMS","requester",startDate,endDate,sl,el,status1,hsr.getRemoteHost());		
			}
					else
					{
						XMLString="you are not authorised user";
					}
				}
			catch(Exception localException)
			{
				MDTransactionWriter.errorlog.debug(localException);
				MDTransactionWriter.errorlog.info(localException);
				status1="failed in service layer";
				//System.out.println(localException);
			}
		 return Response.ok().type(MediaType.APPLICATION_XML).entity(status1).build();
	}

	public Response searchStudentEducation(StudentEducationPojo sep, int userid, int connectionid,
			String datastoreName,int schoolid,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		@SuppressWarnings("unused")
		String XMLString=null;

				String status1=null;
				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date date = new Date();
				String startDate=dateFormat.format(date);
				Long sl=System.currentTimeMillis();
				
				
				try
			{	
					MDValidation mdv = new MDValidation();		
					int ret =mdv.allvalidations(userid, connectionid, datastoreName,schoolid, branchId);
					System.out.println("verifiedvalue::"+ret);
					if(ret==1 )//&& rtVal==1)
					{
						MDSearchManagementDAO ex=new MDSearchManagementDAO();
					    status1=ex.searchStudentEducation(sep,schoolid, branchId);
								
					String endDate=dateFormat.format(new Date());
					Long el=System.currentTimeMillis();
					//status1="user validation successfull";
					MDTransactionWriter.writeLog("sai","CMS","requester",startDate,endDate,sl,el,status1,hsr.getRemoteHost());		
			}
					else
					{
						XMLString="you are not authorised user";
					}
				}
			catch(Exception localException)
			{
				MDTransactionWriter.errorlog.debug(localException);
				MDTransactionWriter.errorlog.info(localException);
				status1="failed in service layer";
				//System.out.println(localException);
			}
		 return Response.ok().type(MediaType.APPLICATION_XML).entity(status1).build();
	}

	public Response searchStaffEducation(StaffEducationPojo sep, int userid, int connectionid, String datastoreName,int schoolid,int branchId) {
		
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		@SuppressWarnings("unused")
		String XMLString=null;

				String status1=null;
				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date date = new Date();
				String startDate=dateFormat.format(date);
				Long sl=System.currentTimeMillis();
				
				
				try
			{	
					MDValidation mdv = new MDValidation();		
					int ret =mdv.allvalidations(userid, connectionid, datastoreName,schoolid, branchId);
					System.out.println("verifiedvalue::"+ret);
					if(ret==1 )//&& rtVal==1)
					{
						MDSearchManagementDAO ex=new MDSearchManagementDAO();
					    status1=ex.searchStaffEducation(sep,schoolid, branchId);
								
					String endDate=dateFormat.format(new Date());
					Long el=System.currentTimeMillis();
					//status1="user validation successfull";
					MDTransactionWriter.writeLog("sai","CMS","requester",startDate,endDate,sl,el,status1,hsr.getRemoteHost());		
			}
					else
					{
						XMLString="you are not authorised user";
					}
				}
			catch(Exception localException)
			{
				MDTransactionWriter.errorlog.debug(localException);
				MDTransactionWriter.errorlog.info(localException);
				status1="failed in service layer";
				//System.out.println(localException);
			}
		 return Response.ok().type(MediaType.APPLICATION_XML).entity(status1).build();
	}

	public Response searchStaffExperience(StaffExperiencePojo sep, int userid, int connectionid, String datastoreName,int schoolid,int branchId) {
		
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		@SuppressWarnings("unused")
		String XMLString=null;

				String status1=null;
				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date date = new Date();
				String startDate=dateFormat.format(date);
				Long sl=System.currentTimeMillis();
				
				
				try
			{	
					MDValidation mdv = new MDValidation();		
					int ret =mdv.allvalidations(userid, connectionid, datastoreName,schoolid, branchId);
					System.out.println("verifiedvalue::"+ret);
					if(ret==1 )//&& rtVal==1)
					{
						MDSearchManagementDAO ex=new MDSearchManagementDAO();
					    status1=ex.searchStaffExperience(sep,schoolid, branchId);
								
					String endDate=dateFormat.format(new Date());
					Long el=System.currentTimeMillis();
					//status1="user validation successfull";
					MDTransactionWriter.writeLog("sai","CMS","requester",startDate,endDate,sl,el,status1,hsr.getRemoteHost());		
			}
					else
					{
						XMLString="you are not authorised user";
					}
				}
			catch(Exception localException)
			{
				MDTransactionWriter.errorlog.debug(localException);
				MDTransactionWriter.errorlog.info(localException);
				status1="failed in service layer";
				//System.out.println(localException);
			}
		 return Response.ok().type(MediaType.APPLICATION_XML).entity(status1).build();
	}

	public Response searchStaffSubjects(StaffSubjectsPojo ssp, int userid, int connectionid, String datastoreName,int schoolid,int branchId) {
	
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		@SuppressWarnings("unused")
		String XMLString=null;

				String status1=null;
				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date date = new Date();
				String startDate=dateFormat.format(date);
				Long sl=System.currentTimeMillis();
				
				
				try
			{	
					MDValidation mdv = new MDValidation();		
					int ret =mdv.allvalidations(userid, connectionid, datastoreName,schoolid, branchId);
					System.out.println("verifiedvalue::"+ret);
					if(ret==1 )//&& rtVal==1)
					{
						MDSearchManagementDAO ex=new MDSearchManagementDAO();
					    status1=ex.searchStaffSubjects(ssp,schoolid, branchId);
								
					String endDate=dateFormat.format(new Date());
					Long el=System.currentTimeMillis();
					//status1="user validation successfull";
					MDTransactionWriter.writeLog("sai","CMS","requester",startDate,endDate,sl,el,status1,hsr.getRemoteHost());		
			}
					else
					{
						XMLString="you are not authorised user";
					}
				}
			catch(Exception localException)
			{
				MDTransactionWriter.errorlog.debug(localException);
				MDTransactionWriter.errorlog.info(localException);
				status1="failed in service layer";
				//System.out.println(localException);
			}
		 return Response.ok().type(MediaType.APPLICATION_XML).entity(status1).build();
	}

	public Response searchStaffAccolades(StaffAccoladePojo sap, int userid, int connectionid, String datastoreName,int schoolid,int branchId) {
		
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		@SuppressWarnings("unused")
		String XMLString=null;

				String status1=null;
				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date date = new Date();
				String startDate=dateFormat.format(date);
				Long sl=System.currentTimeMillis();
				
				
				try
			{	
					MDValidation mdv = new MDValidation();		
					int ret =mdv.allvalidations(userid, connectionid, datastoreName,schoolid, branchId);
					System.out.println("verifiedvalue::"+ret);
					if(ret==1 )//&& rtVal==1)
					{
						MDSearchManagementDAO ex=new MDSearchManagementDAO();
					    status1=ex.searchStaffAccolades(sap,schoolid, branchId);
								
					String endDate=dateFormat.format(new Date());
					Long el=System.currentTimeMillis();
					//status1="user validation successfull";
					MDTransactionWriter.writeLog("sai","CMS","requester",startDate,endDate,sl,el,status1,hsr.getRemoteHost());		
			}
					else
					{
						XMLString="you are not authorised user";
					}
				}
			catch(Exception localException)
			{
				MDTransactionWriter.errorlog.debug(localException);
				MDTransactionWriter.errorlog.info(localException);
				status1="failed in service layer";
				//System.out.println(localException);
			}
		 return Response.ok().type(MediaType.APPLICATION_XML).entity(status1).build();
	}

public Response searchAssessment(AssessmentPojo ast, int userid,
			int connectionid, String datastoreName) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		@SuppressWarnings("unused")
		String XMLString=null;

				String status1=null;
				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date date = new Date();
				String startDate=dateFormat.format(date);
				Long sl=System.currentTimeMillis();
				
				
				try
			{	
					MDGetUserFromID mdgufid=new MDGetUserFromID();
					String requester=mdgufid.getUserName(userid);
					
					System.out.println(connectionid);
					MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
					int ret=mdvcid.verifyConnectionID(userid,connectionid);
					
					MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
					int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
					
					System.out.println("request making user:: "+requester);
					System.out.println("connectionid verification value:: "+ret);
					System.out.println("datastore verification value :: "+rtVal);
					if(ret==1 )//&& rtVal==1)
					{
						MDSearchManagementDAO ex=new MDSearchManagementDAO();
					 status1=ex.searchAssessment(ast);
					 System.out.println(status1);
					String endDate=dateFormat.format(new Date());
					Long el=System.currentTimeMillis();
					//status1="user validation successfull";
					MDTransactionWriter.writeLog("sai","CMS","requester",startDate,endDate,sl,el,status1,hsr.getRemoteHost());		
			}
					else
					{
						XMLString="you are not authorised user";
					}
				}
			catch(Exception localException)
			{
				MDTransactionWriter.errorlog.debug(localException);
				MDTransactionWriter.errorlog.info(localException);
				status1="failed in service layer";
				//System.out.println(localException);
			}
		 return Response.ok().type(MediaType.APPLICATION_XML).entity(status1).build();
	}

	public Response searchBranch(SchoolBranchPojo sbp,int userid, int connectionid, String datastoreName) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		@SuppressWarnings("unused")
		String XMLString=null;

				String status1=null;
				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date date = new Date();
				String startDate=dateFormat.format(date);
				Long sl=System.currentTimeMillis();
				
				
				try
			{	
					MDGetUserFromID mdgufid=new MDGetUserFromID();
					String requester=mdgufid.getUserName(userid);
					
					System.out.println(connectionid);
					MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
					int ret=mdvcid.verifyConnectionID(userid,connectionid);
					
					MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
					int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
					
					System.out.println("request making user:: "+requester);
					System.out.println("connectionid verification value:: "+ret);
					System.out.println("datastore verification value :: "+rtVal);
					if(ret==1 )//&& rtVal==1)
					{
						MDSearchManagementDAO ex=new MDSearchManagementDAO();
					 status1=ex.searchBranch(sbp);
					 System.out.println(status1);
					String endDate=dateFormat.format(new Date());
					Long el=System.currentTimeMillis();
					//status1="user validation successfull";
					MDTransactionWriter.writeLog("sai","CMS","requester",startDate,endDate,sl,el,status1,hsr.getRemoteHost());		
			}
					else
					{
						XMLString="you are not authorised user";
					}
				}
			catch(Exception localException)
			{
				MDTransactionWriter.errorlog.debug(localException);
				MDTransactionWriter.errorlog.info(localException);
				status1="failed in service layer";
				//System.out.println(localException);
			}
		 return Response.ok().type(MediaType.APPLICATION_XML).entity(status1).build();
	}

	public Response searchQuestion(QuestionPojo qp, int userid, int connectionid, String datastoreName) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		@SuppressWarnings("unused")
		String XMLString=null;

				String status1=null;
				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date date = new Date();
				String startDate=dateFormat.format(date);
				Long sl=System.currentTimeMillis();
				
				
				try
			{	
					MDGetUserFromID mdgufid=new MDGetUserFromID();
					String requester=mdgufid.getUserName(userid);
					
					System.out.println(connectionid);
					MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
					int ret=mdvcid.verifyConnectionID(userid,connectionid);
					
					MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
					int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
					
					System.out.println("request making user:: "+requester);
					System.out.println("connectionid verification value:: "+ret);
					System.out.println("datastore verification value :: "+rtVal);
					if(ret==1 )//&& rtVal==1)
					{
						MDSearchManagementDAO ex=new MDSearchManagementDAO();
					 status1=ex.searchQuestion(qp);
					 System.out.println(status1);
					String endDate=dateFormat.format(new Date());
					Long el=System.currentTimeMillis();
					//status1="user validation successfull";
					MDTransactionWriter.writeLog("sai","CMS","requester",startDate,endDate,sl,el,status1,hsr.getRemoteHost());		
			}
					else
					{
						XMLString="you are not authorised user";
					}
				}
			catch(Exception localException)
			{
				MDTransactionWriter.errorlog.debug(localException);
				MDTransactionWriter.errorlog.info(localException);
				status1="failed in service layer";
				//System.out.println(localException);
			}
		 return Response.ok().type(MediaType.APPLICATION_XML).entity(status1).build();
	}

	public Response searchQuestionPaper(QuestionPaperPojo qpp, int userid, int connectionid, String datastoreName) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		@SuppressWarnings("unused")
		String XMLString=null;

				String status1=null;
				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date date = new Date();
				String startDate=dateFormat.format(date);
				Long sl=System.currentTimeMillis();
				
				
				try
			{	
					MDGetUserFromID mdgufid=new MDGetUserFromID();
					String requester=mdgufid.getUserName(userid);
					
					System.out.println(connectionid);
					MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
					int ret=mdvcid.verifyConnectionID(userid,connectionid);
					
					MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
					int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
					
					System.out.println("request making user:: "+requester);
					System.out.println("connectionid verification value:: "+ret);
					System.out.println("datastore verification value :: "+rtVal);
					if(ret==1 )//&& rtVal==1)
					{
						MDSearchManagementDAO ex=new MDSearchManagementDAO();
					 status1=ex.searchQuestionPaper(qpp);
					 System.out.println(status1);
					String endDate=dateFormat.format(new Date());
					Long el=System.currentTimeMillis();
					//status1="user validation successfull";
					MDTransactionWriter.writeLog("sai","CMS","requester",startDate,endDate,sl,el,status1,hsr.getRemoteHost());		
			}
					else
					{
						XMLString="you are not authorised user";
					}
				}
			catch(Exception localException)
			{
				MDTransactionWriter.errorlog.debug(localException);
				MDTransactionWriter.errorlog.info(localException);
				status1="failed in service layer";
				//System.out.println(localException);
			}
		 return Response.ok().type(MediaType.APPLICATION_XML).entity(status1).build();
	}

	public Response searchRoom(RoomPojo rp, int userid, int connectionid, String datastoreName) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		@SuppressWarnings("unused")
		String XMLString=null;

				String status1=null;
				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date date = new Date();
				String startDate=dateFormat.format(date);
				Long sl=System.currentTimeMillis();
				
				
				try
			{	
					MDGetUserFromID mdgufid=new MDGetUserFromID();
					String requester=mdgufid.getUserName(userid);
					
					System.out.println(connectionid);
					MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
					int ret=mdvcid.verifyConnectionID(userid,connectionid);
					
					MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
					int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
					
					System.out.println("request making user:: "+requester);
					System.out.println("connectionid verification value:: "+ret);
					System.out.println("datastore verification value :: "+rtVal);
					if(ret==1 )//&& rtVal==1)
					{
						MDSearchManagementDAO ex=new MDSearchManagementDAO();
					 status1=ex.searchRoom(rp);
					 System.out.println(status1);
					String endDate=dateFormat.format(new Date());
					Long el=System.currentTimeMillis();
					//status1="user validation successfull";
					MDTransactionWriter.writeLog("sai","CMS","requester",startDate,endDate,sl,el,status1,hsr.getRemoteHost());		
			}
					else
					{
						XMLString="you are not authorised user";
					}
				}
			catch(Exception localException)
			{
				MDTransactionWriter.errorlog.debug(localException);
				MDTransactionWriter.errorlog.info(localException);
				status1="failed in service layer";
				//System.out.println(localException);
			}
		 return Response.ok().type(MediaType.APPLICATION_XML).entity(status1).build();
	}

	

	
	

	public Response searchBook(CataloguePojo cp,int userID, int connectionID, String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		@SuppressWarnings("unused")
		String XMLString=null;

				String status1=null;
				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date date = new Date();
				String startDate=dateFormat.format(date);
				Long sl=System.currentTimeMillis();
				
				
				try
			{	
					MDValidation mdv = new MDValidation();  
					int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
					System.out.println("verifiedvalue::"+ret);
					if(ret==1 )//&& rtVal==1)
					{
						MDSearchManagementDAO ex=new MDSearchManagementDAO();
					 status1=ex.searchBook(cp,schoolId,branchId);
					 System.out.println(status1);
					String endDate=dateFormat.format(new Date());
					Long el=System.currentTimeMillis();
					//status1="user validation successfull";
					MDTransactionWriter.writeLog("sai","CMS","requester",startDate,endDate,sl,el,status1,hsr.getRemoteHost());		
			}
					else
					{
						XMLString="you are not authorised user";
					}
				}
			catch(Exception localException)
			{
				MDTransactionWriter.errorlog.debug(localException);
				MDTransactionWriter.errorlog.info(localException);
				status1="failed in service layer";
				//System.out.println(localException);
			}
		 return Response.ok().type(MediaType.APPLICATION_XML).entity(status1).build();
	}

	

	public Response searchLibSubject(LibSubjectPojo cp, int userID, int connectionID, String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		@SuppressWarnings("unused")
		String XMLString=null;

				String status1=null;
				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date date = new Date();
				String startDate=dateFormat.format(date);
				Long sl=System.currentTimeMillis();
				
				
				try
			{	
					MDValidation mdv = new MDValidation();  
					int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
					System.out.println("verifiedvalue::"+ret);
					if(ret==1 )//&& rtVal==1)
					{
						MDSearchManagementDAO ex=new MDSearchManagementDAO();
					 status1=ex.searchLibSubject(cp,schoolId,branchId);
					 System.out.println(status1);
					String endDate=dateFormat.format(new Date());
					Long el=System.currentTimeMillis();
					//status1="user validation successfull";
					MDTransactionWriter.writeLog("datastoreName","CMS","requester",startDate,endDate,sl,el,status1,hsr.getRemoteHost());		
			}
					else
					{
						XMLString="you are not authorised user";
					}
				}
			catch(Exception localException)
			{
				MDTransactionWriter.errorlog.debug(localException);
				MDTransactionWriter.errorlog.info(localException);
				status1="failed in service layer";
				//System.out.println(localException);
			}
		 return Response.ok().type(MediaType.APPLICATION_XML).entity(status1).build();
		
	}

	public Response searchIssues(IssuePojo ip, int userID, int connectionID, String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		@SuppressWarnings("unused")
		String XMLString=null;

				String status1=null;
				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date date = new Date();
				String startDate=dateFormat.format(date);
				Long sl=System.currentTimeMillis();
				
				
				try
			{	
					MDValidation mdv = new MDValidation();  
					int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
					System.out.println("verifiedvalue::"+ret);
					if(ret==1 )//&& rtVal==1)
					{
						MDSearchManagementDAO ex=new MDSearchManagementDAO();
					 status1=ex.searchIssues(ip,schoolId,branchId);
					 System.out.println(status1);
					String endDate=dateFormat.format(new Date());
					Long el=System.currentTimeMillis();
					//status1="user validation successfull";
					MDTransactionWriter.writeLog("datastoreName","CMS","requester",startDate,endDate,sl,el,status1,hsr.getRemoteHost());		
			}
					else
					{
						XMLString="you are not authorised user";
					}
				}
			catch(Exception localException)
			{
				MDTransactionWriter.errorlog.debug(localException);
				MDTransactionWriter.errorlog.info(localException);
				status1="failed in service layer";
				//System.out.println(localException);
			}
		 return Response.ok().type(MediaType.APPLICATION_XML).entity(status1).build();
	}

	public Response searchFeeStructure(FeeStructure cp, int userID, int connectionID, String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		@SuppressWarnings("unused")
		String XMLString=null;

				String status1=null;
				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date date = new Date();
				String startDate=dateFormat.format(date);
				Long sl=System.currentTimeMillis();
				
				
				try
			{	
					MDValidation mdv = new MDValidation();  
					int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
					System.out.println("verifiedvalue::"+ret);
					if(ret==1 )//&& rtVal==1)
					{
						MDSearchManagementDAO ex=new MDSearchManagementDAO();
					 status1=ex.searchFeeStructure(cp,schoolId,branchId);
					 System.out.println(status1);
					String endDate=dateFormat.format(new Date());
					Long el=System.currentTimeMillis();
					//status1="user validation successfull";
					MDTransactionWriter.writeLog("datastoreName","CMS","requester",startDate,endDate,sl,el,status1,hsr.getRemoteHost());		
			}
					else
					{
						XMLString="you are not authorised user";
					}
				}
			catch(Exception localException)
			{
				MDTransactionWriter.errorlog.debug(localException);
				MDTransactionWriter.errorlog.info(localException);
				status1="failed in service layer";
				//System.out.println(localException);
			}
		 return Response.ok().type(MediaType.APPLICATION_XML).entity(status1).build();
		
	}

	public Response searchFeeItems(FeeItemPojo ip, int userID, int connectionID, String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		@SuppressWarnings("unused")
		String XMLString=null;

				String status1=null;
				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date date = new Date();
				String startDate=dateFormat.format(date);
				Long sl=System.currentTimeMillis();
				
				
				try
			{	
					MDValidation mdv = new MDValidation();  
					int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
					System.out.println("verifiedvalue::"+ret);
					if(ret==1 )//&& rtVal==1)
					{
						MDSearchManagementDAO ex=new MDSearchManagementDAO();
					 status1=ex.searchFeeItems(ip,schoolId,branchId);
					 System.out.println(status1);
					String endDate=dateFormat.format(new Date());
					Long el=System.currentTimeMillis();
					//status1="user validation successfull";
					MDTransactionWriter.writeLog("datastoreName","CMS","requester",startDate,endDate,sl,el,status1,hsr.getRemoteHost());		
			}
					else
					{
						XMLString="you are not authorised user";
					}
				}
			catch(Exception localException)
			{
				MDTransactionWriter.errorlog.debug(localException);
				MDTransactionWriter.errorlog.info(localException);
				status1="failed in service layer";
				//System.out.println(localException);
			}
		 return Response.ok().type(MediaType.APPLICATION_XML).entity(status1).build();
	}

	public Response searchPayment(Payment ip, int userID, int connectionID, String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		@SuppressWarnings("unused")
		String XMLString=null;

				String status1=null;
				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date date = new Date();
				String startDate=dateFormat.format(date);
				Long sl=System.currentTimeMillis();
				
				
				try
			{	
					MDValidation mdv = new MDValidation();  
					int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
					System.out.println("verifiedvalue::"+ret);
					if(ret==1 )//&& rtVal==1)
					{
						MDSearchManagementDAO ex=new MDSearchManagementDAO();
					 status1=ex.searchPayment(ip,schoolId,branchId);
					 System.out.println(status1);
					String endDate=dateFormat.format(new Date());
					Long el=System.currentTimeMillis();
					//status1="user validation successfull";
					MDTransactionWriter.writeLog("datastoreName","CMS","requester",startDate,endDate,sl,el,status1,hsr.getRemoteHost());		
			}
					else
					{
						XMLString="you are not authorised user";
					}
				}
			catch(Exception localException)
			{
				MDTransactionWriter.errorlog.debug(localException);
				MDTransactionWriter.errorlog.info(localException);
				status1="failed in service layer";
				//System.out.println(localException);
			}
		 return Response.ok().type(MediaType.APPLICATION_XML).entity(status1).build();
	}

	public Response searchBookReceipt(BookReceiptPojo ip, int userID, int connectionID, String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		@SuppressWarnings("unused")
		String XMLString=null;

				String status1=null;
				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date date = new Date();
				String startDate=dateFormat.format(date);
				Long sl=System.currentTimeMillis();
				
				
				try
			{	
					MDValidation mdv = new MDValidation();  
					int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
					System.out.println("verifiedvalue::"+ret);
					if(ret==1 )//&& rtVal==1)
					{
						MDSearchManagementDAO ex=new MDSearchManagementDAO();
					 status1=ex.searchBookReceipt(ip,schoolId,branchId);
					 System.out.println(status1);
					String endDate=dateFormat.format(new Date());
					Long el=System.currentTimeMillis();
					//status1="user validation successfull";
					MDTransactionWriter.writeLog("datastoreName","CMS","requester",startDate,endDate,sl,el,status1,hsr.getRemoteHost());		
			}
					else
					{
						XMLString="you are not authorised user";
					}
				}
			catch(Exception localException)
			{
				MDTransactionWriter.errorlog.debug(localException);
				MDTransactionWriter.errorlog.info(localException);
				status1="failed in service layer";
				//System.out.println(localException);
			}
		 return Response.ok().type(MediaType.APPLICATION_XML).entity(status1).build();
	}
	public Response getFieldValues(String infoclassName, String fieldnames, String filter, int userid, int connectionid,
			String datastoreName, int PNO, int size) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String XMLString=null;
		String statusStr=null;
		String status1=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userid);
			
			System.out.println(connectionid);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userid,connectionid);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{		
				MDSearchManagementDAO omDAO=new MDSearchManagementDAO();
			XMLString="<status>"+"\n"+omDAO.getFieldValues(infoclassName,fieldnames,filter,PNO,size)+"\n"+"</status>";
			if(XMLString.equals("<status>fail</status>"))
				statusStr="failed in DAO layer";
			else
				statusStr="success";
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			MDTransactionWriter.writeLog(datastoreName,"ObjectMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}
		}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			status1="failed in service layer";
			//System.out.println(localException);
		}
		
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}
}
	
	
	
	
	
	
	
	



	
	

