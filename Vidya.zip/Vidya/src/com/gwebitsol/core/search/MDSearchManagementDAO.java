package com.gwebitsol.core.search;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.assessments.AssessmentPojo;
import com.gwebitsol.core.assessments.QuestionPaperPojo;
import com.gwebitsol.core.assessments.QuestionPojo;
import com.gwebitsol.core.curriculum.AttendencePojo;
import com.gwebitsol.core.curriculum.PeriodPojo;
import com.gwebitsol.core.curriculum.SectionPojo;
import com.gwebitsol.core.curriculum.TimeTablePojo;
import com.gwebitsol.core.fee.FeeItemPojo;
import com.gwebitsol.core.fee.FeeStructure;
import com.gwebitsol.core.fee.Payment;
import com.gwebitsol.core.infrastructure.RoomPojo;
import com.gwebitsol.core.library.BookReceiptPojo;
import com.gwebitsol.core.library.CataloguePojo;
import com.gwebitsol.core.library.IssuePojo;
import com.gwebitsol.core.library.LibSubjectPojo;
import com.gwebitsol.core.padagogy.ChapterPojo;
import com.gwebitsol.core.padagogy.CoursePojo;
import com.gwebitsol.core.padagogy.LessonPlanPojo;
import com.gwebitsol.core.padagogy.ReferenceBookPojo;
import com.gwebitsol.core.padagogy.SubjectPojo;
import com.gwebitsol.core.padagogy.TopicPojo;
import com.gwebitsol.core.padagogy.UnitsPojo;
import com.gwebitsol.core.parent.ParentPojo;
import com.gwebitsol.core.school.SchoolBranchPojo;
import com.gwebitsol.core.staff.StaffAccoladePojo;
import com.gwebitsol.core.staff.StaffEducationPojo;
import com.gwebitsol.core.staff.StaffExperiencePojo;
import com.gwebitsol.core.staff.StaffPojo;
import com.gwebitsol.core.staff.StaffSubjectsPojo;
import com.gwebitsol.core.student.StudentEducationPojo;
import com.gwebitsol.core.student.StudentPojo;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class MDSearchManagementDAO 
{
	@SuppressWarnings({ "deprecation", "rawtypes" })
	public String searchObject(String infoclassName,String searchParameter,String searchParameterValue,String criteria)
	{
		Session sObjSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction sObjTx=null;
		String outStr=null;
		StringBuffer sObjSB=new StringBuffer();
		try
		{

			sObjTx=sObjSession.beginTransaction();
			System.out.println(criteria);
			System.out.println(searchParameterValue);
			if(criteria.equalsIgnoreCase("equals"))
			{
				String sObjSql="select * from "+infoclassName+" where "+searchParameter+"='"+searchParameterValue+"'";
				Query sObjQuery=sObjSession.createSQLQuery(sObjSql).addScalar("indexid",Hibernate.INTEGER).addScalar("componentid",Hibernate.INTEGER).addScalar("item_id",Hibernate.STRING);
				List firstList=sObjQuery.list();
				Iterator firstIT=firstList.iterator();
				sObjSB.append("<MD_Vehicle>");
				sObjSB.append("\n");
				while(firstIT.hasNext())
				{
					System.out.println("inside first while loop");
					Object[] obj=(Object[])firstIT.next();	
					System.out.println(obj[2]);
					String vehicleID=(String)obj[2];
					String sObjSql1="select * from mdobject where objectname='"+vehicleID+"'";
					Query sObjQuery1=sObjSession.createSQLQuery(sObjSql1).addScalar("objectid",Hibernate.INTEGER).addScalar("objectname",Hibernate.STRING)
							.addScalar("parentfolderid",Hibernate.INTEGER).addScalar("infoclassid",Hibernate.INTEGER).addScalar("status",Hibernate.STRING)
							.addScalar("createddate",Hibernate.STRING).addScalar("modifieddate",Hibernate.STRING).addScalar("acl",Hibernate.STRING);
					List secondList=sObjQuery1.list();
					Iterator secondIT=secondList.iterator();

					while(secondIT.hasNext())
					{
						System.out.println("inside while 2nd loop");
						sObjSB.append("<Vehicle>");
						sObjSB.append("\n");
						Object[] obj1=(Object[])secondIT.next();
						sObjSB.append("<indexid>"+obj1[0]+"</indexid>");
						sObjSB.append("\n");
						sObjSB.append("<objectname>"+obj1[1]+"</objectname>");
						sObjSB.append("\n");
						sObjSB.append("<parentfolderid>"+obj1[2]+"</parentfolderid>");
						sObjSB.append("\n");
						sObjSB.append("<infoclassid>"+obj1[3]+"</infoclassid>");
						sObjSB.append("\n");
						sObjSB.append("<status>"+obj1[4]+"</status>");
						sObjSB.append("\n");
						sObjSB.append("<createddate>"+obj1[5]+"</createddate>");
						sObjSB.append("\n");
						sObjSB.append("<modifieddate>"+obj1[6]+"</modifieddate>");
						sObjSB.append("\n");
						sObjSB.append("<acl>"+obj1[7]+"</acl>");
						sObjSB.append("\n");
						sObjSB.append("</Vehicle>");
						sObjSB.append("\n");

					}
				}
				sObjSB.append("</MD_Vehicle>");
				outStr=sObjSB.toString();
			}
			else if(criteria.equalsIgnoreCase("contains"))
			{
				String sObjSql2="select * from "+infoclassName+" where "+searchParameter+" like '%"+searchParameterValue+"%'";
				Query sObjQuery1=sObjSession.createSQLQuery(sObjSql2).addScalar("indexid",Hibernate.INTEGER).addScalar("componentid",Hibernate.INTEGER).addScalar("item_id",Hibernate.STRING);
				List thirdList=sObjQuery1.list();
				Iterator thirdIT=thirdList.iterator();
				sObjSB.append("<MD_Vehicle>");
				sObjSB.append("\n");
				while(thirdIT.hasNext())
				{
					System.out.println("inside first while loop");
					Object[] obj21=(Object[])thirdIT.next();	
					System.out.println(obj21[2]);
					String vehicleID=(String)obj21[2];
				String sObjSql3="select * from mdobject where objectname='"+vehicleID+"'";
				Query sObjQuery2=sObjSession.createSQLQuery(sObjSql3).addScalar("objectid",Hibernate.INTEGER).addScalar("objectname",Hibernate.STRING)
								.addScalar("parentfolderid",Hibernate.INTEGER).addScalar("infoclassid",Hibernate.INTEGER).addScalar("status",Hibernate.STRING)
											.addScalar("createddate",Hibernate.STRING).addScalar("modifieddate",Hibernate.STRING).addScalar("acl",Hibernate.STRING);
				List fourthList=sObjQuery2.list();
				Iterator fourthIT=fourthList.iterator();
				
				while(fourthIT.hasNext())
				{
					System.out.println("inside while 2nd loop");
					sObjSB.append("<Vehicle>");
					sObjSB.append("\n");
					Object[] obj=(Object[])fourthIT.next();
					sObjSB.append("<indexid>"+obj[0]+"</indexid>");
					sObjSB.append("\n");
					sObjSB.append("<objectname>"+obj[1]+"</objectname>");
					sObjSB.append("\n");
					sObjSB.append("<parentfolderid>"+obj[2]+"</parentfolderid>");
					sObjSB.append("\n");
					sObjSB.append("<infoclassid>"+obj[3]+"</infoclassid>");
					sObjSB.append("\n");
					sObjSB.append("<status>"+obj[4]+"</status>");
					sObjSB.append("\n");
					sObjSB.append("<createddate>"+obj[5]+"</createddate>");
					sObjSB.append("\n");
					sObjSB.append("<modifieddate>"+obj[6]+"</modifieddate>");
					sObjSB.append("\n");
					sObjSB.append("<acl>"+obj[7]+"</acl>");
					sObjSB.append("\n");
					sObjSB.append("</Vehicle>");
					sObjSB.append("\n");
					
				}
				}
				sObjSB.append("</MD_Vehicle>");
				outStr=sObjSB.toString();
			}
			sObjTx.commit();
		}
		catch(Exception localException)
		{
			sObjTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			outStr="error while searching object";
		}
		finally
		{
			sObjSession.close();
			sObjSB=null;
		}
		
		return outStr;
	}
	
	@SuppressWarnings({ "deprecation", "rawtypes" })
	public String searchDevice(String infoclassName,String searchParameter,String searchParameterValue,String criteria)
	{
		Session sDevSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction sDevTx=null;
		String outStr=null;
		StringBuffer sDevSB=new StringBuffer();
		try
		{
			sDevTx=sDevSession.beginTransaction();
			if(criteria.equalsIgnoreCase("equals"))
			{
				
				String sDevSql2="select * from "+infoclassName+" where "+searchParameter+" like '%"+searchParameterValue+"%'";
				Query sObjQuery1=sDevSession.createSQLQuery(sDevSql2).addScalar("indexid",Hibernate.INTEGER).addScalar("componentid",Hibernate.INTEGER).addScalar("item_id",Hibernate.STRING);
				List thirdList=sObjQuery1.list();
				Iterator thirdIT=thirdList.iterator();
				sDevSB.append("<MD_Device>");
				sDevSB.append("\n");
				while(thirdIT.hasNext())
				{
					Object[] obj1=(Object[])thirdIT.next();
					String deviceID=(String)obj1[2];
				String sDevSql3="select * from mddevice where devicename='"+deviceID+"'";
				Query sDevQuery2=sDevSession.createSQLQuery(sDevSql3).addScalar("deviceid",Hibernate.INTEGER).addScalar("devicename",Hibernate.STRING)
														.addScalar("parentobjectid",Hibernate.INTEGER).addScalar("infoclassid",Hibernate.INTEGER)
														.addScalar("createddate",Hibernate.STRING).addScalar("modifieddate",Hibernate.STRING)
														.addScalar("acl",Hibernate.STRING).addScalar("createdby",Hibernate.INTEGER).addScalar("modifieddate",Hibernate.INTEGER);
				List fourthList=sDevQuery2.list();
				Iterator fourthIT=fourthList.iterator();
				
				while(fourthIT.hasNext())
				{
					System.out.println("inside while loop");
					sDevSB.append("<Device>");
					sDevSB.append("\n");
					Object[] obj=(Object[])fourthIT.next();
					sDevSB.append("<indexid>"+obj[0]+"</indexid>");
					sDevSB.append("\n");
					sDevSB.append("<devicename>"+obj[1]+"</devicename>");
					sDevSB.append("\n");
					sDevSB.append("<parentobjectid>"+obj[2]+"</parentobjectid>");
					sDevSB.append("\n");
					sDevSB.append("<infoclassid>"+obj[3]+"</infoclassid>");
					sDevSB.append("\n");
					sDevSB.append("<createddate>"+obj[4]+"</createddate>");
					sDevSB.append("\n");
					sDevSB.append("<modifieddate>"+obj[5]+"</modifieddate>");
					sDevSB.append("\n");
					sDevSB.append("<acl>"+obj[6]+"</acl>");
					sDevSB.append("\n");
					sDevSB.append("<createdby>"+obj[7]+"</createdby>");
					sDevSB.append("\n");
					sDevSB.append("<modifiedby>"+obj[8]+"</modifiedby>");
					sDevSB.append("\n");
					sDevSB.append("</Device>");
					sDevSB.append("\n");
				}
				}
				sDevSB.append("</MD_Device>");
				outStr=sDevSB.toString();
		
			}
			else if(criteria.equalsIgnoreCase("contains"))
			{
				
				String sDevSql2="select * from "+infoclassName+" where "+searchParameter+" like '%"+searchParameterValue+"%'";
				Query sObjQuery1=sDevSession.createSQLQuery(sDevSql2).addScalar("indexid",Hibernate.INTEGER).addScalar("componentid",Hibernate.INTEGER).addScalar("item_id",Hibernate.STRING);
				List thirdList=sObjQuery1.list();
				Iterator thirdIT=thirdList.iterator();
				sDevSB.append("<MD_Device>");
				sDevSB.append("\n");
				while(thirdIT.hasNext())
				{
					Object[] obj1=(Object[])thirdIT.next();
					String deviceID=(String)obj1[2];
				String sDevSql3="select * from mddevice where devicename='"+deviceID+"'";
				Query sDevQuery2=sDevSession.createSQLQuery(sDevSql3).addScalar("deviceid",Hibernate.INTEGER).addScalar("devicename",Hibernate.STRING)
														.addScalar("parentobjectid",Hibernate.INTEGER).addScalar("infoclassid",Hibernate.INTEGER)
														.addScalar("createddate",Hibernate.STRING).addScalar("modifieddate",Hibernate.STRING)
														.addScalar("acl",Hibernate.STRING).addScalar("createdby",Hibernate.INTEGER).addScalar("modifieddate",Hibernate.INTEGER);
				List fourthList=sDevQuery2.list();
				Iterator fourthIT=fourthList.iterator();
				
				while(fourthIT.hasNext())
				{
					System.out.println("inside while loop");
					sDevSB.append("<Device>");
					sDevSB.append("\n");
					Object[] obj=(Object[])fourthIT.next();
					sDevSB.append("<indexid>"+obj[0]+"</indexid>");
					sDevSB.append("\n");
					sDevSB.append("<devicename>"+obj[1]+"</devicename>");
					sDevSB.append("\n");
					sDevSB.append("<parentobjectid>"+obj[2]+"</parentobjectid>");
					sDevSB.append("\n");
					sDevSB.append("<infoclassid>"+obj[3]+"</infoclassid>");
					sDevSB.append("\n");
					sDevSB.append("<createddate>"+obj[4]+"</createddate>");
					sDevSB.append("\n");
					sDevSB.append("<modifieddate>"+obj[5]+"</modifieddate>");
					sDevSB.append("\n");
					sDevSB.append("<acl>"+obj[6]+"</acl>");
					sDevSB.append("\n");
					sDevSB.append("<createdby>"+obj[7]+"</createdby>");
					sDevSB.append("\n");
					sDevSB.append("<modifiedby>"+obj[8]+"</modifiedby>");
					sDevSB.append("\n");
					sDevSB.append("</Device>");
					sDevSB.append("\n");
				}
				}
				sDevSB.append("</MD_Device>");
				outStr=sDevSB.toString();
			}
			sDevTx.commit();
		}
		catch(Exception localException)
		{
			sDevTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			outStr="error while searching device";
		}
		finally
		{
			sDevSession.close();
			sDevSB=null;
		}
		
		return outStr;
		
	}	
	
	@SuppressWarnings("rawtypes")
	public List< Map<String, String>> applicationSearch(String searchWord){
		List<Map<String, String>> list=new ArrayList<Map<String,String>>();
		//Map<String,String> map=new HashMap<String,String>();
		Session olSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction olTx = null;
		try {
			olTx = olSession.beginTransaction();
			String userQuery = "select userid,username from mdusers where (username LIKE '%"+ searchWord +"%')"; 
			Query uQuery = olSession.createSQLQuery(userQuery);
			List ulist = uQuery.list();
			Iterator userList=ulist.iterator();
			Map<String,String> userMap=null;
			while(userList.hasNext())
			{
				userMap=new HashMap<String, String>();
				Object o[]=(Object[])userList.next();
				userMap.put("RESULT", (String) o[1]);
				userMap.put("URL", MDSearchConstants.USER_URL);
				userMap.put("DESCRIPTION", "Can you cilck on the above link you will get the full information");
				userMap.put("ID", o[0]+"");
				list.add(userMap);
			}
				//=============================
			String objectQuery = "select OBJECTID,OBJECTNAME from mdobject where (OBJECTNAME LIKE '%"+ searchWord +"%')"; 
			Query oQuery = olSession.createSQLQuery(objectQuery);
			List olist = oQuery.list();
			Iterator objectList=olist.iterator();
			Map<String,String> objectMap=null;
			while(objectList.hasNext())
			{
				objectMap=new HashMap<String, String>();
				Object o[]=(Object[])objectList.next();
				objectMap.put("RESULT", (String) o[1]);
				objectMap.put("URL", MDSearchConstants.OBJECT_URL);
				objectMap.put("DESCRIPTION", "Can you cilck on the above link you will get the full information");
				objectMap.put("ID", o[0]+"");
				list.add(objectMap);
			}
			  //================================
			String deviceQuery = "select DEVICEID,DEVICENAME from mddevice where (DEVICENAME LIKE '%"+ searchWord +"%')"; 
			Query dQuery = olSession.createSQLQuery(deviceQuery);
			List dlist = dQuery.list();
			Iterator deviceList=dlist.iterator();
			Map<String,String> deviceMap=null;
			while(deviceList.hasNext())
			{
				deviceMap=new HashMap<String, String>();
				Object o[]=(Object[])deviceList.next();
				deviceMap.put("RESULT", (String) o[1]);
				deviceMap.put("URL", MDSearchConstants.DEVICE_URL);
				deviceMap.put("DESCRIPTION", "Can you cilck on the above link you will get the full information");
				deviceMap.put("ID", o[0]+"");
				list.add(deviceMap);
			}
			  //=================================
			String routeQuery = "select SNO,ROUTENO,ROUTENAME from mdroutes where (ROUTENO LIKE '%"+ searchWord +"%' OR ROUTENAME LIKE '%"+ searchWord +"%')"; 
			Query rQuery = olSession.createSQLQuery(routeQuery);
			List rlist = rQuery.list();
			Iterator routeList=rlist.iterator();
			Map<String,String> routeMap=null;
			while(routeList.hasNext())
			{
				routeMap=new HashMap<String, String>();
				Object o[]=(Object[])routeList.next();
				routeMap.put("RESULT", "ROUTENO:: "+ o[1]+"ROUTENAME:: "+o[2]);
				routeMap.put("URL", MDSearchConstants.ROUTE_URL);
				routeMap.put("DESCRIPTION", "Can you cilck on the above link you will get the full information");
				routeMap.put("ID", o[0]+"");
				list.add(routeMap);
			}
			//=================================
			String serviceQuery = "select SNO,SID,SNAME from mdservice where (SID LIKE '%"+ searchWord +"%' OR SNAME LIKE '%"+ searchWord +"%')"; 
			Query sQuery = olSession.createSQLQuery(serviceQuery);
			List slist = sQuery.list();
			Iterator serviceList=slist.iterator();
			Map<String,String> serviceMap=null;
			while(serviceList.hasNext())
			{
				serviceMap=new HashMap<String, String>();
				Object o[]=(Object[])serviceList.next();
				serviceMap.put("RESULT", "SID:: "+ o[1]+"SNAME:: "+o[2]);
				serviceMap.put("URL", MDSearchConstants.SERVICE_URL);
				serviceMap.put("DESCRIPTION", "Can you cilck on the above link you will get the full information");
				serviceMap.put("ID", o[0]+"");
				list.add(serviceMap);
			}
			//list.add(map);
				olTx.commit();
				

		} catch (Exception localexception) {
			localexception.printStackTrace();
		} finally {
			olSession.close();
		}

		return list;

	}

	public String searchAttendance(AttendencePojo attendencePojo) {
			  Session sempSession=MDHibernateUtil.getSessionFactory().openSession();
			   Transaction semptx=null;
			   StringBuffer sb=new StringBuffer();
			   String outStr=null;
			   try
			   {
			    semptx=sempSession.beginTransaction();
			
			    String query = "select *from gbl_sm_tbl_attendence where (AttendenceId like '%"+ attendencePojo.getAttendenceId() +"%' or "
			    		+ "StudentId like '%"+ attendencePojo.getStudentId() +"%' or ClassId like '%"+ attendencePojo.getClassId() +"%' or "
			    						+ "SectionId like '%"+ attendencePojo.getSectionId() +"%' or EmployeeId like '%"+ attendencePojo.getEmployeeId() 
			    						+"%' or PeriodId like '%"+ attendencePojo.getPeriodId() +"%' or Date like '%"+ attendencePojo.getDate() 
			    						+"%' or Present like '%"+ attendencePojo.getPresent() +"%')"; 
			    List list=sempSession.createSQLQuery(query).list();
			    Iterator it=list.iterator();
			    sb.append("<Attendances>");
			    while(it.hasNext()){
			     Object[] ex=(Object[])it.next();
			     sb.append("<Attendance>");
			           sb.append("\n");
			           sb.append("<AttendenceId>");
			           sb.append(ex[0]);
			           sb.append("</AttendenceId>");
			           sb.append("\n");
			           sb.append("<StudentId>");
			           sb.append(ex[1]);
			           sb.append("</StudentId>");
			           sb.append("\n");
			           sb.append("<PeriodId>");
			           sb.append(ex[2]);
			           sb.append("</PeriodId>");
			           sb.append("\n");
			           sb.append("<EmployeeId>");
			           sb.append(ex[3]);
			           sb.append("</EmployeeId>");
			           sb.append("\n");
			           sb.append("<classId>");
			           sb.append("\n");
			           sb.append(ex[4]);
			           sb.append("</classId>");
			           sb.append("\n");
			           sb.append("<sectionId>");
			           sb.append(ex[5]);
			           sb.append("</sectionId>");
			           sb.append("\n");
			           sb.append("<Date>");
			           sb.append(ex[6]);
			           sb.append("</Date>");
			           sb.append("\n");
			           sb.append("<Present>");
			           sb.append(ex[7]);
			           sb.append("</Present>");
			           sb.append("\n");
			           sb.append("<CreatedDate>");
			           sb.append(ex[8]);
			           sb.append("</CreatedDate>");
			           sb.append("\n");
			           sb.append("<ModifiedDate>");
			           sb.append(ex[9]);
			           sb.append("</ModifiedDate>");
			           sb.append("\n");
			           sb.append("</Attendance>");
			    }
			    
			    sb.append("</Attendances>");
			    outStr=sb.toString(); 
			     
			     semptx.commit();
			   
			   
			   }catch(Exception localException){
			    System.out.println(localException);
			    
			    localException.printStackTrace();  
			    sb.append("<Response>");
			         sb.append("\n");
			         sb.append("<Result>");
			         sb.append("\n");
			         sb.append("Fail");
			         sb.append("\n");
			         sb.append("</Result>");
			         sb.append("\n");
			         sb.append("<Description>");
			         
			         sb.append("could not inserted attandance info");
			         sb.append("</Description>");
			         sb.append("\n");
			         sb.append("<Exception>");
			         sb.append(localException);
			         sb.append("</Exception>");
			         sb.append("</Response>");
			         outStr= sb.toString();
			        MDTransactionWriter.exceptionlog.info(localException);
			       if (semptx!=null)
			        semptx.rollback();  }
			   finally
			   {   
			    sempSession.close();
			   }
			   return outStr;

	}

	public String searchSection(SectionPojo sectionPojo) {
		Session sempSession=MDHibernateUtil.getSessionFactory().openSession();
		   Transaction semptx=null;
		   StringBuffer sb=new StringBuffer();
		   String outStr=null;
		   try
		   {
		    semptx=sempSession.beginTransaction();
		
		    String query = "select * from gbl_sm_tbl_section where (SectionId like '%"+ sectionPojo.getSectionId() +"%' or "
		    		+ "ClassId like '%"+ sectionPojo.getClassId() +"%' or NoOfStudents like '%"+ sectionPojo.getNoOfStudents() +"%' or "
		    						+ "RoomId like '%"+ sectionPojo.getRoomId() +"%' or CaptainId like '%"+ sectionPojo.getCaptainId() +"%')"; 
		    List list=sempSession.createSQLQuery(query).list();
		    Iterator it=list.iterator();
		    sb.append("<Sections>");
		    while(it.hasNext()){
		     Object[] ex=(Object[])it.next();
		     sb.append("<Section>");
		           sb.append("\n");
		           sb.append("<SectionId>");
		           sb.append(ex[0]);
		           sb.append("</SectionId>");
		           sb.append("\n");
		           sb.append("<classId>");
		           sb.append(ex[1]);
		           sb.append("</classId>");
		           sb.append("\n");
		           sb.append("<RoomId>");
		           sb.append("\n");
		           sb.append(ex[2]);
		           sb.append("</RoomId>");
		           sb.append("\n");
		           sb.append("<CaptionId>");
		           sb.append(ex[3]);
		           sb.append("</CaptionId>");
		           sb.append("\n");
		           sb.append("<Noofstudents>");
		           sb.append(ex[4]);
		           sb.append("</Noofstudents>");
		           sb.append("\n");
		           sb.append("<Sectionname>");
		           sb.append(ex[5]);
		           sb.append("</Sectionname>");
		           sb.append("\n");
		           sb.append("<description>");
		           sb.append(ex[6]);
		           sb.append("</description>");
		           sb.append("\n");
		           sb.append("<remarks>");
		           sb.append(ex[7]);
		           sb.append("</remarks>");
		           sb.append("\n");
		           sb.append("<CreatedDate>");
		           sb.append(ex[8]);
		           sb.append("</CreatedDate>");
		           sb.append("\n");
		           sb.append("<ModifiedDate>");
		           sb.append(ex[9]);
		           sb.append("</ModifiedDate>");
		           sb.append("\n");
		           sb.append("</Section>");
		    }
		    
		    sb.append("</Sections>");
		    outStr=sb.toString(); 
		     
		     semptx.commit();
		   
		   
		   }catch(Exception localException){
		    System.out.println(localException);
		    
		    localException.printStackTrace();  
		    sb.append("<Response>");
		         sb.append("\n");
		         sb.append("<Result>");
		         sb.append("\n");
		         sb.append("Fail");
		         sb.append("\n");
		         sb.append("</Result>");
		         sb.append("\n");
		         sb.append("<Description>");
		         
		         sb.append("could not inserted attandance info");
		         sb.append("</Description>");
		         sb.append("\n");
		         sb.append("<Exception>");
		         sb.append(localException);
		         sb.append("</Exception>");
		         sb.append("</Response>");
		         outStr= sb.toString();
		        MDTransactionWriter.exceptionlog.info(localException);
		       if (semptx!=null)
		        semptx.rollback();  }
		   finally
		   {   
		    sempSession.close();
		   }
		   return outStr;
}

	public String searchTimeTable(TimeTablePojo timeTablePojo) {
		Session sempSession=MDHibernateUtil.getSessionFactory().openSession();
		   Transaction semptx=null;
		   StringBuffer sb=new StringBuffer();
		   String outStr=null;
		   try
		   {
		    semptx=sempSession.beginTransaction();
		
		    String query = "select *from gbl_sm_tbl_timetable where (TimeTableId like '%"+ timeTablePojo.getTimeTableId() +"%' or "
		    		+ "SectionId like '%"+ timeTablePojo.getSectionId() +"%' or Sharable like '%"+ timeTablePojo.getSharable() +"%' or "
		    						+ "TimeTableTitle like '%"+ timeTablePojo.getTimeTableTitle()+"%')"; 
		    List list=sempSession.createSQLQuery(query).list();
		    Iterator it=list.iterator();
		    sb.append("<TimeTables>");
		    while(it.hasNext()){
		     Object[] ex=(Object[])it.next();
		     sb.append("<TimeTable>");
		           sb.append("\n");
		           sb.append("<TimeTableId>");
		           sb.append(ex[0]);
		           sb.append("</TimeTableId>");
		           sb.append("\n");
		           sb.append("<SectionId>");
		           sb.append(ex[1]);
		           sb.append("</SectionId>");
		           sb.append("\n");
		           sb.append("<TimeTableTitle>");		    
		           sb.append(ex[2]);
		           sb.append("</TimeTableTitle>");
		           sb.append("\n");
		           sb.append("<Sharable>");
		           sb.append(ex[3]);
		           sb.append("</Sharable>");
		           sb.append("\n");
		           sb.append("<Description>");
		           sb.append(ex[4]);
		           sb.append("</Description>");
		           sb.append("\n");
		           sb.append("<remarks>");
		           sb.append(ex[5]);
		           sb.append("</remarks>");
		           sb.append("\n");
		           sb.append("<CreatedDate>");
		           sb.append(ex[6]);
		           sb.append("</CreatedDate>");
		           sb.append("\n");
		           sb.append("<ModifiedDate>");
		           sb.append(ex[7]);
		           sb.append("</ModifiedDate>");
		           sb.append("\n");
		           sb.append("</TimeTable>");
		    }
		    
		    sb.append("</TimeTables>");
		    outStr=sb.toString(); 
		     
		     semptx.commit();
		   
		   
		   }catch(Exception localException){
		    System.out.println(localException);
		    
		    localException.printStackTrace();  
		    sb.append("<Response>");
		         sb.append("\n");
		         sb.append("<Result>");
		         sb.append("\n");
		         sb.append("Fail");
		         sb.append("\n");
		         sb.append("</Result>");
		         sb.append("\n");
		         sb.append("<Description>");
		         
		         sb.append("could not inserted timetable info");
		         sb.append("</Description>");
		         sb.append("\n");
		         sb.append("<Exception>");
		         sb.append(localException);
		         sb.append("</Exception>");
		         sb.append("</Response>");
		         outStr= sb.toString();
		        MDTransactionWriter.exceptionlog.info(localException);
		       if (semptx!=null)
		        semptx.rollback();  }
		   finally
		   {   
		    sempSession.close();
		   }
		   return outStr;
	}
	public String searchPeriods(PeriodPojo periodPojo) {
		Session sempSession=MDHibernateUtil.getSessionFactory().openSession();
		   Transaction semptx=null;
		   StringBuffer sb=new StringBuffer();
		   String outStr=null;
		   try
		   {
		    semptx=sempSession.beginTransaction();
		
		    String query = "select *from gbl_sm_tbl_period  where (PeriodId like '%"+ periodPojo.getPeriodId() +"%' or "
		    		+ "TimeTableId like '%"+ periodPojo.getTimeTableId() +"%' or SubjectId like '%"+ periodPojo.getSubjectId() +"%' or "
		    						+ "EmployeeId like '%"+ periodPojo.getEmployeeId() +"%' or Days like '%"+ periodPojo.getDays()
		    						 +"StartTime like '%"+ periodPojo.getStartTime() +"%' or EndTime like '%"+ periodPojo.getEndTime()
		    						 +"SequenceNo like '%"+ periodPojo.getSequenceNo()+"%')"; 
		    List list=sempSession.createSQLQuery(query).list();
		    Iterator it=list.iterator();
		    sb.append("<Periods>");
		    while(it.hasNext()){
		     Object[] ex=(Object[])it.next();
		     sb.append("<Period>");
		           sb.append("\n");
		           sb.append("<PeriodId>");
		           sb.append(ex[0]);
		           sb.append("</PeriodId>");
		           sb.append("\n");
		           sb.append("<TimeTableId>");
		           sb.append(ex[1]);
		           sb.append("</TimeTableId>");
		           sb.append("\n");
		           sb.append("<SubjectId>");
		           sb.append("\n");
		           sb.append(ex[2]);
		           sb.append("</SubjectId>");
		           sb.append("\n");
		           sb.append("<EmployeeId>");
		           sb.append(ex[3]);
		           sb.append("</EmployeeId>");
		           sb.append("\n");
		           sb.append("<SequenceNo>");
		           sb.append(ex[4]);
		           sb.append("</SequenceNo>");
		           sb.append("\n");
		           sb.append("<Days>");
		           sb.append(ex[5]);
		           sb.append("</Days>");
		           sb.append("\n");
		           sb.append("<PeriodTitle>");
		           sb.append(ex[6]);
		           sb.append("</PeriodTitle>");
		           sb.append("\n");
		           sb.append("<StartDate>");
		           sb.append(ex[7]);
		           sb.append("</StartDate>");
		           sb.append("<Enddate>");
		           sb.append(ex[8]);
		           sb.append("</Enddate>");
		           sb.append("\n");
		           sb.append("<description>");
		           sb.append(ex[9]);
		           sb.append("</description>");
		           sb.append("\n");
		           sb.append("</Period>");
		    }
		    sb.append("</Periods>");
		    outStr=sb.toString(); 
		     semptx.commit();
		 		   }catch(Exception localException){
		    System.out.println(localException);
		    localException.printStackTrace();  
		    sb.append("<Response>");
		         sb.append("\n");
		         sb.append("<Result>");
		         sb.append("\n");
		         sb.append("Fail");
		         sb.append("\n");
		         sb.append("</Result>");
		         sb.append("\n");
		         sb.append("<Description>");
		         
		         sb.append("could not inserted period info");
		         sb.append("</Description>");
		         sb.append("\n");
		         sb.append("<Exception>");
		         sb.append(localException);
		         sb.append("</Exception>");
		         sb.append("</Response>");
		         outStr= sb.toString();
		        MDTransactionWriter.exceptionlog.info(localException);
		       if (semptx!=null)
		        semptx.rollback();  }
		   finally
		   {   
		    sempSession.close();
		   }
		   return outStr;
	}
	@SuppressWarnings("rawtypes")
	public String searchCourse(CoursePojo coursePojo) {
		Session sempSession=MDHibernateUtil.getSessionFactory().openSession();
		   Transaction semptx=null;
		   StringBuffer sb=new StringBuffer();
		   String outStr=null;
		   try
		   {
		    semptx=sempSession.beginTransaction();
		
		    String query = "select *from gbl_sm_tbl_course where (CourseId like '%"+ coursePojo.getCourseId() +"%' or "
		    		+ "CourseName like '%"+ coursePojo.getCourseName() +"%' or Duration like '%"+ coursePojo.getDuration() +"%' or "
		    						+ "Status like '%"+ coursePojo.getStatus() +"%')"; 
		    List list=sempSession.createSQLQuery(query).list();
		    Iterator it=list.iterator();
		    sb.append("<Courses>");
		    while(it.hasNext()){
		     Object[] ex=(Object[])it.next();
		     sb.append("<Course>");
		           sb.append("\n");
		           sb.append("<CourseId>");
		           sb.append(ex[0]);
		           sb.append("</CourseId>");
		           sb.append("\n");
		           sb.append("<TopicId>");
		           sb.append(ex[1]);
		           sb.append("</TopicId>");
		           sb.append("\n");
		           sb.append("<CourseName>");
		           sb.append("\n");
		           sb.append(ex[2]);
		           sb.append("</CourseName>");
		           sb.append("\n");
		           sb.append("<Duration>");
		           sb.append(ex[3]);
		           sb.append("</Duration>");
		           sb.append("\n");
		           sb.append("<Status>");
		           sb.append(ex[4]);
		           sb.append("</Status>");
		           sb.append("\n");
		           sb.append("<description>");		       
		           sb.append(ex[5]);
		           sb.append("</description>");
		           sb.append("\n");
		           sb.append("<remarks>");
		           sb.append(ex[6]);
		           sb.append("</remarks>");
		           sb.append("\n");
		           sb.append("<CreatedDate>");
		           sb.append(ex[7]);
		           sb.append("</CreatedDate>");
		           sb.append("\n");
		           sb.append("<ModifiedDate>");
		           sb.append(ex[8]);
		           sb.append("</ModifiedDate>");
		           sb.append("\n");
		           sb.append("</Course>"); 
		    }
		    sb.append("</Courses>");
		    outStr=sb.toString(); 
		     semptx.commit();
		   
		   }catch(Exception localException){
		    System.out.println(localException);
		    
		    localException.printStackTrace();  
		    sb.append("<Response>");
		         sb.append("\n");
		         sb.append("<Result>");
		         sb.append("\n");
		         sb.append("Fail");
		         sb.append("\n");
		         sb.append("</Result>");
		         sb.append("\n");
		         sb.append("<Description>");
		         
		         sb.append("could not inserted course info");
		         sb.append("</Description>");
		         sb.append("\n");
		         sb.append("<Exception>");
		         sb.append(localException);
		         sb.append("</Exception>");
		         sb.append("</Response>");
		         outStr= sb.toString();
		        MDTransactionWriter.exceptionlog.info(localException);
		       if (semptx!=null)
		        semptx.rollback();  }
		   finally
		   {   
		    sempSession.close();
		   }
		   return outStr;
	}
	public String searchChapter(ChapterPojo chapterPojo) {
		Session sempSession=MDHibernateUtil.getSessionFactory().openSession();
		   Transaction semptx=null;
		   StringBuffer sb=new StringBuffer();
		   String outStr=null;
		   try
		   {
		    semptx=sempSession.beginTransaction();
		
		    String query = "select *from gbl_sm_tbl_chapter where (ChapterId like '%"+ chapterPojo.getChapterId() +"%' or "
		    		+ "UnitId like '%"+ chapterPojo.getUnitId() +"%' or ChapterNo like '%"+ chapterPojo.getChapterNo() +"%' or "
		    						+ "ChapterName like '%"+ chapterPojo.getChapterName()  +"%')"; 
		    List list=sempSession.createSQLQuery(query).list();
		    Iterator it=list.iterator();
		    sb.append("<Chapters>");
		    while(it.hasNext()){
		     Object[] ex=(Object[])it.next();
		     sb.append("<Chapter>");
		           sb.append("\n");
		           sb.append("<ChapterId>");
		           sb.append(ex[0]);
		           sb.append("</ChapterId>");
		           sb.append("\n");
		           sb.append("<UnitId>");
		           sb.append(ex[1]);
		           sb.append("</UnitId>");
		           sb.append("\n");
		           sb.append("<ChapterNo>");
		           sb.append("\n");
		           sb.append(ex[2]);
		           sb.append("</ChapterNo>");
		           sb.append("\n");
		           sb.append("<ChapterName>");
		           sb.append(ex[3]);
		           sb.append("</ChapterName>");
		           sb.append("\n");
		           sb.append("<Status>");
		           sb.append(ex[4]);
		           sb.append("</Status>");
		           sb.append("\n");		         
		           sb.append("<description>");
		           sb.append("\n");
		           sb.append(ex[6]);
		           sb.append("</description>");
		           sb.append("\n");
		           sb.append("</Chapter>");
		    }
		    
		    sb.append("</Chapters>");
		    outStr=sb.toString(); 
		     semptx.commit();
		   }catch(Exception localException){
		    System.out.println(localException); 
		    localException.printStackTrace();  
		    sb.append("<Response>");
		         sb.append("\n");
		         sb.append("<Result>");
		         sb.append("\n");
		         sb.append("Fail");
		         sb.append("\n");
		         sb.append("</Result>");
		         sb.append("\n");
		         sb.append("<Description>");
		         sb.append("could not inserted chapter info");
		         sb.append("</Description>");
		         sb.append("\n");
		         sb.append("<Exception>");
		         sb.append(localException);
		         sb.append("</Exception>");
		         sb.append("</Response>");
		         outStr= sb.toString();
		        MDTransactionWriter.exceptionlog.info(localException);
		       if (semptx!=null)
		        semptx.rollback();  }
		   finally
		   {   
		    sempSession.close();
		   }
		   return outStr;
	}

	public String searchTopics(TopicPojo topicPojo) {
		Session sempSession=MDHibernateUtil.getSessionFactory().openSession();
		   Transaction semptx=null;
		   StringBuffer sb=new StringBuffer();
		   String outStr=null;
		   try
		   {
		    semptx=sempSession.beginTransaction();
		
		    String query = "select *from gbl_sm_tbl_topic where (SectionId like '%"+ topicPojo.getTopicId() +"%' or "
		    		+ "ClassId like '%"+ topicPojo.getChapterId() +"%' or NoOfStudents like '%"+ topicPojo.getTopicName() +"%')"; 
		    List list=sempSession.createSQLQuery(query).list();
		    Iterator it=list.iterator();
		    sb.append("<Sections>");
		    while(it.hasNext()){
		     Object[] ex=(Object[])it.next();
		     sb.append("<Section>");
		           sb.append("\n");
		           sb.append("<SectionId>");
		           sb.append(ex[0]);
		           sb.append("</SectionId>");
		           sb.append("\n");
		           sb.append("<classId>");
		           sb.append(ex[1]);
		           sb.append("</classId>");
		           sb.append("\n");
		           sb.append("<RoomId>");
		           sb.append("\n");
		           sb.append(ex[2]);
		           sb.append("</RoomId>");
		           sb.append("\n");
		           sb.append("<CaptionId>");
		           sb.append(ex[3]);
		           sb.append("</CaptionId>");
		           sb.append("\n");
		           sb.append("<Noofstudents>");
		           sb.append(ex[4]);
		           sb.append("</Noofstudents>");
		           sb.append("\n");
		           sb.append("<Sectionname>");
		           sb.append(ex[5]);
		           sb.append("</Sectionname>");
		           sb.append("\n");
		           sb.append("<description>");
		           sb.append("\n");
		           sb.append(ex[6]);
		           sb.append("</description>");
		           sb.append("\n");
		           sb.append("<remarks>");
		           sb.append(ex[7]);
		           sb.append("</remarks>");
		           sb.append("\n");
		           sb.append("</Section>");
		    }
		    
		    sb.append("</Sections>");
		    outStr=sb.toString(); 
		     
		     semptx.commit();
		   
		   
		   }catch(Exception localException){
		    System.out.println(localException);
		    
		    localException.printStackTrace();  
		    sb.append("<Response>");
		         sb.append("\n");
		         sb.append("<Result>");
		         sb.append("\n");
		         sb.append("Fail");
		         sb.append("\n");
		         sb.append("</Result>");
		         sb.append("\n");
		         sb.append("<Description>");
		         
		         sb.append("could not inserted topics info");
		         sb.append("</Description>");
		         sb.append("\n");
		         sb.append("<Exception>");
		         sb.append(localException);
		         sb.append("</Exception>");
		         sb.append("</Response>");
		         outStr= sb.toString();
		        MDTransactionWriter.exceptionlog.info(localException);
		       if (semptx!=null)
		        semptx.rollback();  }
		   finally
		   {   
		    sempSession.close();
		   }
		   return outStr;
	}

	@SuppressWarnings("rawtypes")
	public String searchUnits(UnitsPojo unitsPojo) {
		Session sempSession=MDHibernateUtil.getSessionFactory().openSession();
		   Transaction semptx=null;
		   StringBuffer sb=new StringBuffer();
		   String outStr=null;
		   try
		   {
		    semptx=sempSession.beginTransaction();
		
		    String query = "select * from gbl_sm_tbl_units where (UnitId like '%"+ unitsPojo.getUnitId() +"%' or "
		    		+ "SubjectId like '%"+ unitsPojo.getSubjectId() +"%' or UnitNo like '%"+ unitsPojo.getUnitNo() +"%' or "
		    						+ "UnitName like '%"+ unitsPojo.getUnitName()  +"%')"; 
		    List list=sempSession.createSQLQuery(query).list();
		    Iterator it=list.iterator();
		    sb.append("<Units>");
		    while(it.hasNext()){
		     Object[] ex=(Object[])it.next();
		     sb.append("<unit>");
		           sb.append("\n");
		           sb.append("<UnitId>");
		           sb.append(ex[0]);
		           sb.append("</UnitId>");
		           sb.append("\n");
		           sb.append("<SubjectId>");
		           sb.append(ex[1]);
		           sb.append("</SubjectId>");
		           sb.append("\n");
		           sb.append("<UnitNo>");
		           sb.append(ex[2]);
		           sb.append("</UnitNo>");
		           sb.append("\n");
		           sb.append("<UnitName>");
		           sb.append(ex[3]);
		           sb.append("</UnitName>");
		           sb.append("\n");
		           sb.append("<Status>");
		           sb.append(ex[4]);
		           sb.append("</Status>");
		           sb.append("\n");
		           sb.append("<description>");
		           sb.append(ex[5]);
		           sb.append("</description>");
		           sb.append("\n");
		           sb.append("</unit>");
		    }
		    
		    sb.append("</Units>");
		    outStr=sb.toString(); 
		     
		     semptx.commit();
		   
		   
		   }catch(Exception localException){
		    System.out.println(localException);
		    
		    localException.printStackTrace();  
		    sb.append("<Response>");
		         sb.append("\n");
		         sb.append("<Result>");
		         sb.append("\n");
		         sb.append("Fail");
		         sb.append("\n");
		         sb.append("</Result>");
		         sb.append("\n");
		         sb.append("<Description>");
		         
		         sb.append("could not inserted units info");
		         sb.append("</Description>");
		         sb.append("\n");
		         sb.append("<Exception>");
		         sb.append(localException);
		         sb.append("</Exception>");
		         sb.append("</Response>");
		         outStr= sb.toString();
		        MDTransactionWriter.exceptionlog.info(localException);
		       if (semptx!=null)
		        semptx.rollback();  }
		   finally
		   {   
		    sempSession.close();
		   }
		   return outStr;
	}
	public String searchLessonPlan(LessonPlanPojo lessonPlanPojo) {
		Session sempSession=MDHibernateUtil.getSessionFactory().openSession();
		   Transaction semptx=null;
		   StringBuffer sb=new StringBuffer();
		   String outStr=null;
		   try
		   {
		    semptx=sempSession.beginTransaction();
		
		    String query = "select *from gbl_sm_tbl_lessonplan where (LessonPlanId like '%"+ lessonPlanPojo.getLessonPlanId() +"%' or "
		    		+ "EmployeeId like '%"+ lessonPlanPojo.getEmployeeId() +"%' or LessonPlanName like '%"+ lessonPlanPojo.getLessonPlanName() +"%' or "
		    						+ "StartDate like '%"+ lessonPlanPojo.getStartDate()+"%' or EndDate like '%"+ lessonPlanPojo.getEndDate() +"%')"; 
		    List list=sempSession.createSQLQuery(query).list();
		    Iterator it=list.iterator();
		    sb.append("<LessonPlans>");
		    while(it.hasNext()){
		     Object[] ex=(Object[])it.next();
		     sb.append("<LessonPlan>");
		           sb.append("\n");
		           sb.append("<LessonPlanId>");
		           sb.append(ex[0]);
		           sb.append("</LessonPlanId>");
		           sb.append("\n");
		           sb.append("<EmployeeId>");
		           sb.append(ex[1]);
		           sb.append("</EmployeeId>");
		           sb.append("\n");
		           sb.append("<LessonPlanName>");
		           sb.append(ex[2]);
		           sb.append("</LessonPlanName>");
		           sb.append("\n");
		           sb.append("<LessonPlanStatus>");
		           sb.append(ex[3]);
		           sb.append("</LessonPlanStatus>");
		           sb.append("\n");
		           sb.append("<StartDate>");
		           sb.append(ex[4]);
		           sb.append("</StartDate>");
		           sb.append("\n");
		           sb.append("<Enddate>");
		           sb.append(ex[5]);
		           sb.append("</Enddate>");
		           sb.append("\n");
		           sb.append("<description>");
		           sb.append(ex[6]);
		           sb.append("</description>");
		           sb.append("\n");
		           sb.append("<CreatedDate>");
		           sb.append(ex[7]);
		           sb.append("</CreatedDate>");
		           sb.append("\n");
		           sb.append("<ModifiedDate>");
		           sb.append(ex[8]);
		           sb.append("</ModifiedDate>");
		           sb.append("\n");
		           sb.append("</LessonPlan>");
		    }
		    
		    sb.append("</LessonPlans>");
		    outStr=sb.toString(); 
		     
		     semptx.commit();
		   
		   
		   }catch(Exception localException){
		    System.out.println(localException);
		    
		    localException.printStackTrace();  
		    sb.append("<Response>");
		         sb.append("\n");
		         sb.append("<Result>");
		         sb.append("\n");
		         sb.append("Fail");
		         sb.append("\n");
		         sb.append("</Result>");
		         sb.append("\n");
		         sb.append("<Description>");
		         
		         sb.append("could not inserted lessonplan info");
		         sb.append("</Description>");
		         sb.append("\n");
		         sb.append("<Exception>");
		         sb.append(localException);
		         sb.append("</Exception>");
		         sb.append("</Response>");
		         outStr= sb.toString();
		        MDTransactionWriter.exceptionlog.info(localException);
		       if (semptx!=null)
		        semptx.rollback();  }
		   finally
		   {   
		    sempSession.close();
		   }
		   return outStr;
	}
	public String searchSubject(SubjectPojo subjectPojo) {
		Session sempSession=MDHibernateUtil.getSessionFactory().openSession();
		   Transaction semptx=null;
		   StringBuffer sb=new StringBuffer();
		   String outStr=null;
		   try
		   {
		    semptx=sempSession.beginTransaction();
		
		    String query = "select * from gbl_sm_tbl_subjects where (SubjectId like '%"+ subjectPojo.getSubjectId() +"%' or "
		    		+ "ClassId like '%"+ subjectPojo.getClassId() +"%' or SubjectName like '%"+ subjectPojo.getSubjectTypeId() +"%' or "+ "RoomId like '%"+ subjectPojo.getTextBookId()+"%')"; 
		    						/*+ "RoomId like '%"+ sectionPojo.getRoomId() +"%' or CaptainId like '%"+ sectionPojo.getCaptainId()*/ 
		    List list=sempSession.createSQLQuery(query).list();
		    Iterator it=list.iterator();
		    sb.append("<subjects>");
		    while(it.hasNext()){
		     Object[] ex=(Object[])it.next();
		     sb.append("<subject>");
		           sb.append("\n");
		           sb.append("<SubjectId>");
		           sb.append(ex[0]);
		           sb.append("</SubjectId>");
		           sb.append("\n");
		           sb.append("<subcategoryid>");
		           sb.append(ex[1]);
		           sb.append("</subcategoryid>");
		           sb.append("\n");
		           sb.append("<textbookid>");
		           sb.append(ex[2]);
		           sb.append("</textbookid>");
		           sb.append("\n");
		           sb.append("<classid>");
		           sb.append(ex[3]);
		           sb.append("</classid>");
		           sb.append("\n");
		           sb.append("<subjectname>");
		           sb.append(ex[4]);
		           sb.append("</subjectname>");
		           sb.append("\n");
		           sb.append("<syllabus>");
		           sb.append(ex[5]);
		           sb.append("</syllabus>");
		           sb.append("\n");
		           sb.append("<description>");
		           sb.append(ex[6]);
		           sb.append("</description>");
		           sb.append("\n");
		           sb.append("<remarks>");
		           sb.append(ex[7]);
		           sb.append("</remarks>");
		           sb.append("\n");
		           sb.append("</subject>");
		    }
		    
		    sb.append("</subjects>");
		    outStr=sb.toString(); 
		     
		     semptx.commit();
		   
		   
		   }catch(Exception localException){
		    System.out.println(localException);
		    
		    localException.printStackTrace();  
		    sb.append("<Response>");
		         sb.append("\n");
		         sb.append("<Result>");
		         sb.append("\n");
		         sb.append("Fail");
		         sb.append("\n");
		         sb.append("</Result>");
		         sb.append("\n");
		         sb.append("<Description>");
		         
		         sb.append("could not inserted subject info");
		         sb.append("</Description>");
		         sb.append("\n");
		         sb.append("<Exception>");
		         sb.append(localException);
		         sb.append("</Exception>");
		         sb.append("</Response>");
		         outStr= sb.toString();
		        MDTransactionWriter.exceptionlog.info(localException);
		       if (semptx!=null)
		        semptx.rollback();  }
		   finally
		   {   
		    sempSession.close();
		   }
		   return outStr;
	}
	public String searchReferenceBook(ReferenceBookPojo referenceBookPojo) {
		Session sempSession=MDHibernateUtil.getSessionFactory().openSession();
		   Transaction semptx=null;
		   StringBuffer sb=new StringBuffer();
		   String outStr=null;
		   try
		   {
		    semptx=sempSession.beginTransaction();
		
		    String query = "select * from gbl_sm_tbl_reference_book where (ReferenceBookId like '%"+ referenceBookPojo.getReferenceBookId() +"%' or "
		    		+ "ReferenceBookName like '%"+ referenceBookPojo.getReferenceBookName() +"%' or SubjectId like '%"+ referenceBookPojo.getSubjectId() +"%' or "
		    						+ "Author like '%"+ referenceBookPojo.getAuthor() +"%' or Publisher like '%"+ referenceBookPojo.getPublisher()+"%')"; 
		    List list=sempSession.createSQLQuery(query).list();
		    Iterator it=list.iterator();
		    sb.append("<ReferenceBooks>");
		    while(it.hasNext()){
		     Object[] ex=(Object[])it.next();
		     sb.append("<ReferenceBook>");
		           sb.append("\n");
		           sb.append("<ReferenceBookId>");
		           sb.append(ex[0]);
		           sb.append("</ReferenceBookId>");
		           sb.append("\n");
		           sb.append("<SubjectId>");
		           sb.append(ex[1]);
		           sb.append("</SubjectId>");
		           sb.append("\n");
		           sb.append("<ReferenceBookName>");
		           sb.append(ex[2]);
		           sb.append("</ReferenceBookName>");
		           sb.append("\n");
		           sb.append("<Author>");
		           sb.append(ex[3]);
		           sb.append("</Author>");
		           sb.append("\n");
		           sb.append("<Publisher>");
		           sb.append(ex[4]);
		           sb.append("</Publisher>");
		           sb.append("\n");
		           sb.append("<description>");
		           sb.append(ex[5]);
		           sb.append("</description>");
		           sb.append("\n");
		           sb.append("</ReferenceBook>");
		    }
		    
		    sb.append("</ReferenceBooks>");
		    outStr=sb.toString(); 
		     
		     semptx.commit();
		   
		   
		   }catch(Exception localException){
		    System.out.println(localException);
		    
		    localException.printStackTrace();  
		    sb.append("<Response>");
		         sb.append("\n");
		         sb.append("<Result>");
		         sb.append("\n");
		         sb.append("Fail");
		         sb.append("\n");
		         sb.append("</Result>");
		         sb.append("\n");
		         sb.append("<Description>");
		         
		         sb.append("could not inserted referencebook info");
		         sb.append("</Description>");
		         sb.append("\n");
		         sb.append("<Exception>");
		         sb.append(localException);
		         sb.append("</Exception>");
		         sb.append("</Response>");
		         outStr= sb.toString();
		        MDTransactionWriter.exceptionlog.info(localException);
		       if (semptx!=null)
		        semptx.rollback();  }
		   finally
		   {   
		    sempSession.close();
		   }
		   return outStr;
                 }



	public String searchStudent(StudentPojo sp, int schoolid, int branchId) {

		Session sempSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction semptx = null;
		StringBuffer sb = new StringBuffer();
		String strg = null;

		String firstname = sp.getFirstName();
		String lastname = sp.getLastName();
		String gender = sp.getGender();
		int bloodgrp = sp.getBloodGroupId();
		// int parentid = sp.getParentId();
		String dob = sp.getDob();
		int rollno = sp.getRollNo();
		int studentid = sp.getStudentId();
		String stnum = sp.getStudentNumber();

		try {
			semptx = sempSession.beginTransaction();
			String bqry = "select gbl_sm_tbl_student.*, gbl_sm_tbl_bloodgroup.BloodGroupName "
					+ " from gbl_sm_tbl_student "
					+ " join gbl_sm_tbl_bloodgroup on gbl_sm_tbl_student.BloodGroupId = gbl_sm_tbl_bloodgroup.BloodGroupId "
					+ "where (FirstName like '%" + firstname
					+ "%' or LastName like '%" + lastname + "%' or Gender like '%" + gender
					+ "%' or BloodGroupId like '%" + bloodgrp + "%' or DOB like '%" + dob + "%' or RollNo like '%"
					+ rollno + "%' or StudentNumber like '%" + stnum + "%') and SchoolId='"+schoolid+"'and BranchId='"+branchId+"';";

			List list = sempSession.createSQLQuery(bqry).list();
			Iterator it = list.iterator();
			sb.append("<Students>");

			while (it.hasNext()) {
				Object[] stu = (Object[]) it.next();

				if (stu == null) {
					System.out.println("there is no student object");
				} else {
					sb.append("<student>");
					sb.append("\n");
					sb.append("<studentId>"+stu[0]+"</studentId>");
					sb.append("\n");
					sb.append("<bloodGroupId>" + stu[1]+ "</bloodGroupId>");
					sb.append("\n");
					sb.append("<bloodGroupName>" + stu[20]+ "</bloodGroupName>");
					sb.append("\n");
					sb.append("<userId>" + stu[2]+ "</userId>");
					sb.append("\n");
					sb.append("<photo>" + stu[3] + "</photo>");
					sb.append("\n");
					sb.append("<studentNumber>" + stu[4]+ "</studentNumber>");
					sb.append("\n");
					sb.append("<firstName>" + stu[5] + "</firstName>");
					sb.append("\n");
					sb.append("<middleName>" + stu[6]+ "</middleName>");
					sb.append("\n");
					sb.append("<lastName>" + stu[7] + "</lastName>");
					sb.append("\n");
					sb.append("<gender>" + stu[8] + "</gender>");
					sb.append("\n");
					sb.append("<dOB>" + stu[9] + "</dOB>");
					sb.append("\n");
					sb.append("<rollNo>" + stu[10] + "</rollNo>");
					sb.append("\n");
					sb.append("<emailId>" + stu[11] + "</emailId>");
					sb.append("\n");
					sb.append("<mobileNumber>" + stu[12] + "</mobileNumber>");
					sb.append("\n");
					sb.append("<status>" + stu[13]+ "</status>");
					sb.append("\n");
					sb.append("<remarks>" +  stu[14]+ "</remarks>");
					sb.append("\n");
					sb.append("<createdDate>" +  stu[15]+ "</createdDate>");
					sb.append("\n");
					sb.append("<modifiedDate>" +  stu[16] + "</modifiedDate>");
					sb.append("\n");
					sb.append("<schoolId>" +  stu[17] + "</schoolId>");
					sb.append("\n");	
					sb.append("<branchId>" +  stu[18] + "</branchId>");
					sb.append("\n");	
					sb.append("<isDeleted>" +  stu[19] + "</isDeleted>");
					sb.append("\n");
					sb.append("</student>");
					sb.append("\n");

				}

			}
			sb.append("</Students>");
			semptx.commit();
			strg = sb.toString();

		} catch (Exception localException) {
			System.out.println(localException);

			localException.printStackTrace();
			sb.append("<Response>");
			sb.append("\n");
			sb.append("<Result>");
			sb.append("\n");
			sb.append("Fail");
			sb.append("\n");
			sb.append("</Result>");
			sb.append("\n");
			sb.append("<Description>");
			sb.append("could not inserted Issue info");
			sb.append("</Description>");
			sb.append("\n");
			sb.append("<Exception>");
			sb.append(localException);
			sb.append("</Exception>");
			sb.append("</Response>");
			strg = sb.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (semptx != null)
				semptx.rollback();
		} finally {
			sempSession.close();
		}
		return strg;
	}

	public String searchParent(ParentPojo pp, int schoolid, int branchId) {
		Session sempSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction semptx = null;
		StringBuffer sb = new StringBuffer();
		String string = null;
		String strg = null;

		String fname = pp.getFirstName();
		String lname = pp.getLastName();
		String gen = pp.getGender();

		int parent = pp.getParentId();
		String dob = pp.getDob();
		int jobtype = pp.getJobTypeId();
		String rel = pp.getRelation();
		String qual = pp.getQualification();
		String jobtitle = pp.getJobTitle();
		String sal = pp.getAnnualSalary();

		try {
			semptx = sempSession.beginTransaction();
			String bqry = "select gbl_sm_tbl_parent.*, gbl_sm_tbl_jobtype.JobTypeName"
					+" from gbl_sm_tbl_parent"
					+" join gbl_sm_tbl_jobtype on gbl_sm_tbl_parent.JobTypeId = gbl_sm_tbl_jobtype.JobTypeId"
					+" where (FirstName like '%" + fname + "%' or LastName like '%"
					+ lname + "%' or Gender like '%" + gen + "%' or ParentId like '%" + parent + "%' or  DOB like '% "
					+ dob + "%' or gbl_sm_tbl_parent.JobTypeId like '%" + jobtype + "%' or Relation like '%" + rel
					+ "%' or Qualification like '%" + qual + "%' or JobTitle like '%" + jobtitle
					+ "%' or AnnualSalary like'%" + sal + "%') and gbl_sm_tbl_parent.SchoolId='"+schoolid+"'and gbl_sm_tbl_parent.BranchId='"+branchId+"';";

			List list = sempSession.createSQLQuery(bqry).list();
			Iterator it = list.iterator();
			sb.append("<Parents>");
			while (it.hasNext()) {

				Object[] stu = (Object[]) it.next();

				if (stu == null) {
					System.out.println("there is no parent object");
				} else {
					sb.append("<parent>");
					sb.append("\n");
					sb.append("<parentId>"+stu[0]+"</parentId>");
					sb.append("\n");
					sb.append("<jobTypeId>" + stu[1]+ "</jobTypeId>");
					sb.append("\n");
					sb.append("<jobTypeName>" + stu[22]+ "</jobTypeName>");
					sb.append("\n");
					sb.append("<userId>" + stu[2]+ "</userId>");
					sb.append("\n");
					sb.append("<photo>" + stu[3] + "</photo>");
					sb.append("\n");
					sb.append("<firstName>" + stu[4]+ "</firstName>");
					sb.append("\n");
					sb.append("<middleName>" + stu[5] + "</middleName>");
					sb.append("\n");
					sb.append("<lastName>" +  stu[6]+ "</lastName>");
					sb.append("\n");
					sb.append("<dOB>" + stu[7] + "</dOB>");
					sb.append("\n");
					sb.append("<qualification>" + stu[8] + "</qualification>");
					sb.append("\n");
					sb.append("<jobTitle>" + stu[9] + "</jobTitle>");
					sb.append("\n");
					sb.append("<jobRole>" + stu[10] + "</jobRole>");
					sb.append("\n");
					sb.append("<annualSalary>" + stu[11]+ "</annualSalary>");
					sb.append("\n");
					sb.append("<relation>" +  stu[12]+ "</relation>");
					sb.append("\n");
					sb.append("<gender>" +  stu[13] + "</gender>");
					sb.append("\n");
					sb.append("<emailId>" +  stu[14] + "</emailId>");
					sb.append("\n");
					sb.append("<mobileNumber>" +  stu[15] + "</mobileNumber>");
					sb.append("\n");
					sb.append("<remarks>" +  stu[16] + "</remarks>");
					sb.append("\n");
					sb.append("<createdDate>" +  stu[17] + "</createdDate>");
					sb.append("\n");
					sb.append("<modifiedDate>" +  stu[18] + "</modifiedDate>");
					sb.append("\n");
					sb.append("<schoolId>" +  stu[19] + "</schoolId>");
					sb.append("\n");
					sb.append("<branchId>" +  stu[20] + "</branchId>");
					sb.append("\n");
					sb.append("<isDeleted>" +  stu[21] + "</isDeleted>");
					sb.append("\n");
					sb.append("</parent>");
					sb.append("\n");
				}
			}
			sb.append("</Parents>");
			semptx.commit();
			strg = sb.toString();

		} catch (Exception localException) {
			System.out.println(localException);

			localException.printStackTrace();
			sb.append("<Response>");
			sb.append("\n");
			sb.append("<Result>");
			sb.append("\n");
			sb.append("Fail");
			sb.append("\n");
			sb.append("</Result>");
			sb.append("\n");
			sb.append("<Description>");

			sb.append("could not inserted Issue info");
			sb.append("</Description>");
			sb.append("\n");
			sb.append("<Exception>");
			sb.append(localException);
			sb.append("</Exception>");
			sb.append("</Response>");
			strg = sb.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (semptx != null)
				semptx.rollback();
		} finally {
			sempSession.close();
		}
		return strg;
	}

	public String searchStaff(StaffPojo sp, int schoolid, int branchId) {
		Session sempSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction semptx = null;

		StringBuffer sb = new StringBuffer();
		String string = null;
		String strg = null;

		String fname = sp.getFirstName();
		String lname = sp.getLastName();
		String gen = sp.getGender();

		int bg = sp.getBloodGroupId();
		String dob = sp.getDob();
		String doj = sp.getDoj();
		String stnum = sp.getStaffNumber();
		int empId = sp.getEmployeeId();
		int jobtitle = sp.getJobTitleId();

		try {
			semptx = sempSession.beginTransaction();
			String bqry = "select gbl_sm_tbl_staff.*, gbl_sm_tbl_bloodgroup.BloodGroupName, gbl_sm_tbl_jobtitle.Title"
					+" from gbl_sm_tbl_staff"
					+" join gbl_sm_tbl_bloodgroup on gbl_sm_tbl_staff.BloodGroupId = gbl_sm_tbl_bloodgroup.BloodGroupId"
					+" join gbl_sm_tbl_jobtitle on gbl_sm_tbl_staff.JobTitleId=gbl_sm_tbl_jobtitle.JobTitleId"
					+" (FirstName like '%" + fname + "%' or LastName like '%"
					+ lname + "%' or Gender like '%" + gen + "%' or  DOB like '%" + dob + "%' or DOJ like '%" + doj
					+ "%' or StaffNumber like '%" + stnum + "%' or BloodGroupId like '%" + bg
					+ "%' or JobTitleId like '%" + jobtitle + "%' or EmployeeId like'%" + empId + "%') and SchoolId='"+schoolid+"'and BranchId='"+branchId+"';";

			List list = sempSession.createSQLQuery(bqry).list();
			Iterator it = list.iterator();
			sb.append("<Staff>");
			while (it.hasNext()) {

				Object[] stu = (Object[]) it.next();

				if (stu == null) {
					System.out.println("there is no staff object");
				} else {
					sb.append("<Staff>");
					sb.append("\n");
					sb.append("<employeeId>"+stu[0]+"</employeeId>");
					sb.append("\n");
					sb.append("<bloodGroupId>" + stu[1]+ "</bloodGroupId>");
					sb.append("\n");
					sb.append("<bloodGroupName>" + stu[18]+ "</bloodGroupName>");
					sb.append("\n");
					sb.append("<jobTitleId>" + stu[2]+ "</jobTitleId>");
					sb.append("\n");
					sb.append("<jobTitleName>" + stu[19]+ "</jobTitleName>");
					sb.append("\n");
					sb.append("<userId>" + stu[3] + "</userId>");
					sb.append("\n");
					sb.append("<photo>" + stu[4]+ "</photo>");
					sb.append("\n");
					sb.append("<staffNumber>" + stu[5] + "</staffNumber>");
					sb.append("\n");
					sb.append("<firstName>" +  stu[6]+ "</firstName>");
					sb.append("\n");
					sb.append("<middleName>" + stu[7] + "</middleName>");
					sb.append("\n");
					sb.append("<lastName>" + stu[8] + "</lastName>");
					sb.append("\n");
					sb.append("<gender>" + stu[9] + "</gender>");
					sb.append("\n");
					sb.append("<dOB>" + stu[10] + "</dOB>");
					sb.append("\n");
					sb.append("<dOJ>" + stu[11]+ "</dOJ>");
					sb.append("\n");
					sb.append("<remarks>" +  stu[12]+ "</remarks>");
					sb.append("\n");
					sb.append("<createdDate>" +  stu[13]+ "</createdDate>");
					sb.append("\n");
					sb.append("<modifiedDate>" +  stu[14] + "</modifiedDate>");
					sb.append("\n");
					sb.append("<schoolId>" +  stu[15] + "</schoolId>");
					sb.append("\n");
					sb.append("<branchId>" +  stu[16] + "</branchId>");
					sb.append("\n");
					sb.append("<isDeleted>" +  stu[17] + "</isDeleted>");
					sb.append("\n");
					sb.append("</Staff>");
					sb.append("\n");
				}

			}
			sb.append("</Staff>");
			semptx.commit();
			strg = sb.toString();

		} catch (Exception localException) {
			System.out.println(localException);

			localException.printStackTrace();
			sb.append("<Response>");
			sb.append("\n");
			sb.append("<Result>");
			sb.append("\n");
			sb.append("Fail");
			sb.append("\n");
			sb.append("</Result>");
			sb.append("\n");
			sb.append("<Description>");

			sb.append("could not inserted Issue info");
			sb.append("</Description>");
			sb.append("\n");
			sb.append("<Exception>");
			sb.append(localException);
			sb.append("</Exception>");
			sb.append("</Response>");
			strg = sb.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (semptx != null)
				semptx.rollback();
		} finally {
			sempSession.close();
		}
		return strg;
	}

	public String searchStudentEducation(StudentEducationPojo sep, int schoolid, int branchId) {
		Session sempSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction semptx = null;

		StringBuffer sb = new StringBuffer();
		String strg = null;

		String school = sep.getSchoolName();
		String date1 = sep.getStudiedFrom();
		String date2 = sep.getStudiedTo();
		int clas = sep.getClassId();
		int grade = sep.getGradeId();
		int result = sep.getResultId();
		int sec = sep.getSectionId();
		int student = sep.getStudentId();

		try {
			semptx = sempSession.beginTransaction();
			String bqry = "select gbl_sm_tbl_student_education.*, gbl_sm_tbl_student.StudentNumber, gbl_sm_tbl_student.FirstName,"
					+ " gbl_sm_tbl_student.MiddleName,gbl_sm_tbl_student.LastName,gbl_sm_tbl_class.ClassName,"
					+ " gbl_sm_tbl_section.SectionName, gbl_sm_tbl_result.ResultName,gbl_sm_tbl_grade.GradeName"
					+ " from gbl_sm_tbl_student_education"
					+ " join gbl_sm_tbl_student on  gbl_sm_tbl_student_education.StudentId = gbl_sm_tbl_student.StudentId"
					+ " join gbl_sm_tbl_class on gbl_sm_tbl_student_education.ClassId=gbl_sm_tbl_class.ClassId"
					+ " join gbl_sm_tbl_section on gbl_sm_tbl_student_education.SectionId=gbl_sm_tbl_section.SectionId"
					+ " join gbl_sm_tbl_result on gbl_sm_tbl_student_education.ResultId = gbl_sm_tbl_result.ResultId"
					+ " join gbl_sm_tbl_grade on gbl_sm_tbl_student_education.GradeId= gbl_sm_tbl_grade.GradeId"
					+ " where (StudentId like '%" + student + "%' or ClassId like '%" + clas + "%' or SectionId like '%"
					+ sec + "%' or ResultId like '%" + result + "%' or GradeId like '%" + grade
					+ "%' or SchoolName like '%" + school + "%' or StudiedFrom like '%" + date1
					+ "%' or StudiedTo like '%" + date2 + "%') and SchoolId='" + schoolid + "'and BranchId='" + branchId+ "';";

			List list = sempSession.createSQLQuery(bqry).list();
			Iterator it = list.iterator();
			sb.append("<StudentEducation>");
			while (it.hasNext()) {
				Object[] stu = (Object[]) it.next();

				if (stu == null) {
					System.out.println("there is no student education object");
				} else {
					sb.append("<studenteducation>");
					sb.append("\n");
					sb.append("<studentEdId>"+stu[0]+"</studentEdId>");
					sb.append("\n");
					sb.append("<studentId>" + stu[1]+ "</studentId>");
					sb.append("\n");
					sb.append("<studentNumber>" +  stu[17]+ "</studentNumber>");
					sb.append("\n");
					sb.append("<studentFirstName>" +  stu[18]+ "</studentFirstName>");
					sb.append("\n");
					sb.append("<studentMiddleName>" +  stu[19]+ "</studentMiddleName>");
					sb.append("\n");
					sb.append("<studentLastName>" +  stu[20]+ "</studentLastName>");
					sb.append("\n");
					sb.append("<classId>" + stu[2]+ "</classId>");
					sb.append("\n");
					sb.append("<className>" +  stu[21]+ "</className>");
					sb.append("\n");
					sb.append("<sectionId>" + stu[3] + "</sectionId>");
					sb.append("\n");
					sb.append("<sectionName>" +  stu[22]+ "</sectionName>");
					sb.append("\n");
					sb.append("<resultId>" + stu[4]+ "</resultId>");
					sb.append("\n");
					sb.append("<resultName>" + stu[23]+ "</resultName>");
					sb.append("\n");
					sb.append("<gradeId>" + stu[5] + "</gradeId>");
					sb.append("\n");
					sb.append("<gradeName>" + stu[24]+ "</gradeName>");
					sb.append("\n");
					sb.append("<schoolName>" +  stu[6]+ "</schoolName>");
					sb.append("\n");
					sb.append("<studiedFrom>" + stu[7] + "</studiedFrom>");
					sb.append("\n");
					sb.append("<studiedTo>" + stu[8] + "</studiedTo>");
					sb.append("\n");
					sb.append("<percentScore>" + stu[9] + "</percentScore>");
					sb.append("\n");
					sb.append("<currentFlg>" + stu[10] + "</currentFlg>");
					sb.append("\n");
					sb.append("<remarks>" + stu[11] + "</remarks>");
					sb.append("\n");
					sb.append("<createdDate>" + stu[12]+ "</createdDate>");
					sb.append("\n");
					sb.append("<modifiedDate>" +  stu[13]+ "</modifiedDate>");
					sb.append("\n");
					sb.append("<schoolId>" +  stu[14]+ "</schoolId>");
					sb.append("\n");
					sb.append("<branchId>" +  stu[15]+ "</branchId>");
					sb.append("\n");
					sb.append("<isDeleted>" +  stu[16]+ "</isDeleted>");
					sb.append("\n");
	     			sb.append("</studenteducation>");
					sb.append("\n");
				}

			}
			sb.append("</StudentEducation>");
			semptx.commit();
			strg = sb.toString();

		} catch (Exception localException) {
			System.out.println(localException);

			localException.printStackTrace();
			sb.append("<Response>");
			sb.append("\n");
			sb.append("<Result>");
			sb.append("\n");
			sb.append("Fail");
			sb.append("\n");
			sb.append("</Result>");
			sb.append("\n");
			sb.append("<Description>");

			sb.append("could not inserted Issue info");
			sb.append("</Description>");
			sb.append("\n");
			sb.append("<Exception>");
			sb.append(localException);
			sb.append("</Exception>");
			sb.append("</Response>");
			strg = sb.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (semptx != null)
				semptx.rollback();
		} finally {
			sempSession.close();
		}
		return strg;
	}

	public String searchStaffEducation(StaffEducationPojo sep, int schoolid, int branchId) {
		Session sempSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction semptx = null;

		StringBuffer sb = new StringBuffer();
		String string = null;
		String strg = null;

		String hq = sep.getPassedInClass();
		String uni = sep.getUniversity();
		String year = sep.getYearofPass();
		int acld = sep.getAccoladeId();
		int emp = sep.getEmployeeId();
		int grade = sep.getGradeId();
		String qual = sep.getQualification();
		double per = sep.getPercentScore();
		try {
			semptx = sempSession.beginTransaction();
			String bqry = "select gbl_sm_tbl_staff_education.*, gbl_sm_tbl_staff.FirstName, gbl_sm_tbl_staff.MiddleName,"
					+" gbl_sm_tbl_staff.LastName, gbl_sm_tbl_staff.StaffNumber, gbl_sm_tbl_grade.GradeName,"
					+" gbl_sm_tbl_staff_accolades.AccoladeTitle"
					+" from gbl_sm_tbl_staff_education"
					+" join gbl_sm_tbl_staff on  gbl_sm_tbl_staff_education.EmployeeId = gbl_sm_tbl_staff.EmployeeId"
					+" join gbl_sm_tbl_grade on gbl_sm_tbl_staff_education.GradeId=gbl_sm_tbl_grade.GradeId"
					+" join gbl_sm_tbl_staff_accolades on gbl_sm_tbl_staff_education.AccoladeId=gbl_sm_tbl_staff_accolades.AccoladeId"
					+" where (EmployeeId like '%" + emp
					+"%' or AccoladeId like '%" + acld + "%' or GradeId like '%" + grade
					+"%' or PassedInClass like '%" + hq + "%' or Qualification like '% " + qual
					+"%' or YearofPass like '%" + year + "%' or University like '%" + uni + "%' or PercentScore like '%"
					+ per + "%') and SchoolId='" + schoolid + "'and BranchId='" + branchId+ "';";

			List list = sempSession.createSQLQuery(bqry).list();
			Iterator it = list.iterator();
			sb.append("<StaffEducation>");
			while (it.hasNext()) {

				Object[] stu = (Object[]) it.next();

				if (stu == null) {
					System.out.println("there is no staffEducation object");
				} else {
					sb.append("<staffeducation>");
					sb.append("\n");
					sb.append("<staffEduId>"+stu[0]+"</staffEduId>");
					sb.append("\n");
					sb.append("<employeeId>" + stu[1]+ "</employeeId>");
					sb.append("\n");
					sb.append("<staffFirstName>" + stu[15] + "</staffFirstName>");
					sb.append("\n");
					sb.append("<staffMiddleName>" + stu[16] + "</staffMiddleName>");
					sb.append("\n");
					sb.append("<staffLastName>" + stu[17]+ "</staffLastName>");
					sb.append("\n");
					sb.append("<staffNumber>" + stu[18] + "</staffNumber>");
					sb.append("\n");
					sb.append("<accoladeId>" + stu[2]+ "</accoladeId>");
					sb.append("\n");
					sb.append("<accoladeTitle>" + stu[20]+ "</accoladeTitle>");
					sb.append("\n");
					sb.append("<gradeId>" + stu[3] + "</gradeId>");
					sb.append("\n");
					sb.append("<gradeName>" + stu[19]+ "</gradeName>");
					sb.append("\n");
					sb.append("<passedInClass>" + stu[4]+ "</passedInClass>");
					sb.append("\n");
					sb.append("<qualification>" + stu[5] + "</qualification>");
					sb.append("\n");
					sb.append("<yearofPass>" +  stu[6]+ "</yearofPass>");
					sb.append("\n");
					sb.append("<university>" + stu[7] + "</university>");
					sb.append("\n");
					sb.append("<percentScore>" + stu[8] + "</percentScore>");
					sb.append("\n");
					sb.append("<remarks>" + stu[9] + "</remarks>");
					sb.append("\n");
					sb.append("<createdDate>" + stu[10] + "</createdDate>");
					sb.append("\n");
					sb.append("<modifiedDate>" + stu[11]+ "</modifiedDate>");
					sb.append("\n");
					sb.append("<schoolId>" + stu[12]+ "</schoolId>");
					sb.append("\n");
					sb.append("<branchId>" + stu[13]+ "</branchId>");
					sb.append("\n");
					sb.append("<isdeleted>" + stu[14]+ "</isdeleted>");
					sb.append("\n");
					sb.append("</staffeducation>");
					sb.append("\n");
				}
				sb.append("</StaffEducation>");
				semptx.commit();
				strg = sb.toString();

			}

		} catch (Exception localException) {
			System.out.println(localException);

			localException.printStackTrace();
			sb.append("<Response>");
			sb.append("\n");
			sb.append("<Result>");
			sb.append("\n");
			sb.append("Fail");
			sb.append("\n");
			sb.append("</Result>");
			sb.append("\n");
			sb.append("<Description>");

			sb.append("could not inserted Issue info");
			sb.append("</Description>");
			sb.append("\n");
			sb.append("<Exception>");
			sb.append(localException);
			sb.append("</Exception>");
			sb.append("</Response>");
			strg = sb.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (semptx != null)
				semptx.rollback();
		} finally {
			sempSession.close();
		}
		return strg;
	}

	public String searchStaffExperience(StaffExperiencePojo sep, int schoolid, int branchId) {
		Session sempSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction semptx = null;

		StringBuffer sb = new StringBuffer();
		String string = null;
		String strg = null;

		String jobrole = sep.getJobRole();
		String preinst = sep.getPreviousInstitution();
		String date1 = sep.getWorkedFrom();
		String date2 = sep.getWorkedTo();
		int emp = sep.getEmployeeId();
		int jobtitle = sep.getJobTitleId();

		try {
			semptx = sempSession.beginTransaction();
			String bqry = "select gbl_sm_tbl_staff_experience.*, gbl_sm_tbl_staff.FirstName, gbl_sm_tbl_staff.MiddleName,"
					+" gbl_sm_tbl_staff.LastName,gbl_sm_tbl_staff.StaffNumber,gbl_sm_tbl_jobtitle.Title"
					+" from gbl_sm_tbl_staff_experience"
					+" join gbl_sm_tbl_staff on  gbl_sm_tbl_staff_experience.EmployeeId = gbl_sm_tbl_staff.EmployeeId"
					+" join gbl_sm_tbl_jobtitle on gbl_sm_tbl_staff_experience.JobTitleId=gbl_sm_tbl_jobtitle.JobTitleId"
					+" where (EmployeeId like '%" + emp
					+ "%' or JobTitleId like '%" + jobtitle + "%' or PreviousInstitution like '%" + preinst
					+ "%' or WorkedFrom like '%" + date1 + "%' or WorkedTo like '% " + date2 + "%' or JobRole like '%"
					+ jobrole + "%') and SchoolId='" + schoolid + "'and BranchId='" + branchId+ "';";

			List list = sempSession.createSQLQuery(bqry).list();
			Iterator it = list.iterator();
			sb.append("<StaffExperience>");
			while (it.hasNext()) {

				Object[] stu = (Object[]) it.next();

				if (stu == null) {
					System.out.println("there is no StaffSubjects object");
				} else {
					sb.append("<StaffExperience>");
					sb.append("\n");
					sb.append("<staffExpId>"+stu[0]+"</staffExpId>");
					sb.append("\n");
					sb.append("<employeeId>" + stu[1]+ "</employeeId>");
					sb.append("\n");
					sb.append("<staffFirstName>" + stu[13] + "</staffFirstName>");
					sb.append("\n");
					sb.append("<staffMiddleName>" + stu[14] + "</staffMiddleName>");
					sb.append("\n");
					sb.append("<staffLastName>" + stu[15]+ "</staffLastName>");
					sb.append("\n");
					sb.append("<staffNumber>" + stu[16] + "</staffNumber>");
					sb.append("\n");
					sb.append("<jobTitleId>" + stu[2]+ "</jobTitleId>");
					sb.append("\n");
					sb.append("<jobTitleName>" + stu[17] + "</jobTitleName>");
					sb.append("\n");
					sb.append("<previousInstitution>" + stu[3] + "</previousInstitution>");
					sb.append("\n");
					sb.append("<workedFrom>" + stu[4]+ "</workedFrom>");
					sb.append("\n");
					sb.append("<workedTo>" + stu[5] + "</workedTo>");
					sb.append("\n");
					sb.append("<jobRole>" +  stu[6]+ "</jobRole>");
					sb.append("\n");
					sb.append("<remarks>" + stu[7] + "</remarks>");
					sb.append("\n");
					sb.append("<createdDate>" + stu[8] + "</createdDate>");
					sb.append("\n");
					sb.append("<modifiedDate>" + stu[9] + "</modifiedDate>");
					sb.append("\n");
					sb.append("<schoolId>" + stu[10] + "</schoolId>");
					sb.append("\n");
					sb.append("<branchId>" + stu[11] + "</branchId>");
					sb.append("\n");
					sb.append("<isDeleted>" + stu[12] + "</isDeleted>");
					sb.append("\n");
					sb.append("</StaffExperience>");
					sb.append("\n");
				}
				sb.append("</StaffExperience>");
				semptx.commit();
				strg = sb.toString();
			}

		} catch (Exception localException) {
			System.out.println(localException);

			localException.printStackTrace();
			sb.append("<Response>");
			sb.append("\n");
			sb.append("<Result>");
			sb.append("\n");
			sb.append("Fail");
			sb.append("\n");
			sb.append("</Result>");
			sb.append("\n");
			sb.append("<Description>");

			sb.append("could not inserted Issue info");
			sb.append("</Description>");
			sb.append("\n");
			sb.append("<Exception>");
			sb.append(localException);
			sb.append("</Exception>");
			sb.append("</Response>");
			strg = sb.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (semptx != null)
				semptx.rollback();
		} finally {
			sempSession.close();
		}
		return strg;

	}

	public String searchStaffSubjects(StaffSubjectsPojo ssp, int schoolid, int branchId) {
		Session sempSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction semptx = null;

		StringBuffer sb = new StringBuffer();
		String string = null;
		String strg = null;

		int clas = ssp.getClassIdTaught();
		int duration = ssp.getMonthsTaught();
		int emp = ssp.getEmployeeId();
		int sub = ssp.getSubjectId();

		try {
			semptx = sempSession.beginTransaction();
			String bqry = "select gbl_sm_tbl_staff_subjects.*, gbl_sm_tbl_staff.FirstName, gbl_sm_tbl_staff.MiddleName,"
					+" gbl_sm_tbl_staff.LastName, gbl_sm_tbl_staff.StaffNumber, gbl_sm_tbl_subjects.SubjectName, gbl_sm_tbl_class.ClassName"
					+" from gbl_sm_tbl_staff_subjects"
					+" join gbl_sm_tbl_staff on gbl_sm_tbl_staff_subjects.EmployeeId = gbl_sm_tbl_staff.EmployeeId"
					+" join gbl_sm_tbl_subjects on gbl_sm_tbl_staff_subjects.SubjectId=gbl_sm_tbl_subjects.SubjectId"
					+" join gbl_sm_tbl_class on gbl_sm_tbl_staff_subjects.ClassIdTaught= gbl_sm_tbl_class.ClassId"
					+" where (EmployeeId like '%" + emp
					+ "%' or SubjectId like '%" + sub + "%' or ClassIdTaught like '%" + clas
					+ "%' or MonthsTaught like '% " + duration + "%') and SchoolId='" + schoolid + "'and BranchId='" + branchId+ "';";

			List list = sempSession.createSQLQuery(bqry).list();
			Iterator it = list.iterator();
			sb.append("<StaffSubjects>");
			while (it.hasNext()) {

				Object[] stu = (Object[]) it.next();

				if (stu == null) {
					System.out.println("there is no staffSubjects object");
				} else {
					sb.append("<StaffSubject>");
					sb.append("\n");
					sb.append("<staffSubId>"+stu[0]+"</staffSubId>");
					sb.append("\n");
					sb.append("<employeeId>" + stu[1]+ "</employeeId>");
					sb.append("\n");
					sb.append("<staffFirstName>" + stu[13] + "</staffFirstName>");
					sb.append("\n");
					sb.append("<staffMiddleName>" + stu[14] + "</staffMiddleName>");
					sb.append("\n");
					sb.append("<staffLastName>" + stu[15]+ "</staffLastName>");
					sb.append("\n");
					sb.append("<staffNumber>" + stu[16] + "</staffNumber>");
					sb.append("\n");
					sb.append("<staffExpId>" + stu[2]+ "</staffExpId>");
					sb.append("\n");
					sb.append("<workedFrom>" + stu[17]+ "</workedFrom>");
					sb.append("\n");
					sb.append("<workedTo>" + stu[18]+ "</workedTo>");
					sb.append("\n");
					sb.append("<subjectId>" + stu[3] + "</subjectId>");
					sb.append("\n");
					sb.append("<subjectName>" + stu[19] + "</subjectName>");
					sb.append("\n");
					sb.append("<classIdTaught>" + stu[4]+ "</classIdTaught>");
					sb.append("\n");
					sb.append("<className>" + stu[20] + "</className>");
					sb.append("\n");
					sb.append("<lastUsed>" + stu[5] + "</lastUsed>");
					sb.append("\n");
					sb.append("<monthsTaught>" +  stu[6]+ "</monthsTaught>");
					sb.append("\n");
					sb.append("<description>" + stu[7] + "</description>");
					sb.append("\n");
					sb.append("<createdDate>" + stu[8] + "</createdDate>");
					sb.append("\n");
					sb.append("<modifiedDate>" + stu[9] + "</modifiedDate>");
					sb.append("\n");
					sb.append("<schoolId>" + stu[10] + "</schoolId>");
					sb.append("\n");
					sb.append("<branchId>" + stu[11] + "</branchId>");
					sb.append("\n");
					sb.append("<isDeleted>" + stu[12] + "</isDeleted>");
					sb.append("\n");
					sb.append("</StaffSubject>");
					sb.append("\n");
				}
				sb.append("</StaffSubjects>");
				semptx.commit();
				strg = sb.toString();
			}

		} catch (Exception localException) {
			System.out.println(localException);

			localException.printStackTrace();
			sb.append("<Response>");
			sb.append("\n");
			sb.append("<Result>");
			sb.append("\n");
			sb.append("Fail");
			sb.append("\n");
			sb.append("</Result>");
			sb.append("\n");
			sb.append("<Description>");

			sb.append("could not inserted Issue info");
			sb.append("</Description>");
			sb.append("\n");
			sb.append("<Exception>");
			sb.append(localException);
			sb.append("</Exception>");
			sb.append("</Response>");
			strg = sb.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (semptx != null)
				semptx.rollback();
		} finally {
			sempSession.close();
		}
		return strg;
	}

	public String searchStaffAccolades(StaffAccoladePojo sap, int schoolid, int branchId) {
		Session sempSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction semptx = null;

		StringBuffer sb = new StringBuffer();
		String string = null;
		String strg = null;

		int actypeid = sap.getAccoladeTypeId();
		int emp = sap.getEmployeeId();
		int result = sap.getResultId();
		String awardeddate = sap.getAwardedDate();
		String duration = sap.getDuration();
		String medal = sap.getMedal();
		String prize = sap.getPrize();
		String acctitle = sap.getAccoladeTitle();

		try {
			semptx = sempSession.beginTransaction();
			String bqry = "select gbl_sm_tbl_staff_accolades.*, gbl_sm_tbl_staff.FirstName, gbl_sm_tbl_staff.MiddleName,"
					+" gbl_sm_tbl_staff.LastName,gbl_sm_tbl_staff.StaffNumber,gbl_sm_tbl_assessment_type.TypeName,"
					+" gbl_sm_tbl_result.ResultName"
					+" from gbl_sm_tbl_staff_accolades"
					+" join gbl_sm_tbl_staff on gbl_sm_tbl_staff_accolades.EmployeeId = gbl_sm_tbl_staff.EmployeeId"
					+" join gbl_sm_tbl_assessment_type on gbl_sm_tbl_staff_accolades.AccoladeTypeId=gbl_sm_tbl_assessment_type.AssessmentTypeId"
					+" join gbl_sm_tbl_result on gbl_sm_tbl_staff_accolades.ResultId=gbl_sm_tbl_result.ResultId"
					+" where(EmployeeId like '%" + emp
					+ "%' or AccoladeTypeId like '%" + actypeid + "%' or AwardedDate like '%" + awardeddate
					+ "%' or AccoladeTitle like '%" + acctitle + "%' or Duration like '% " + duration
					+ "%' or Prize like '%" + prize + "%' or ResultId like '%" + result + "%' or Medal like '%" + medal
					+ "%') and SchoolId='" + schoolid + "'and BranchId='" + branchId+ "';";

			List list = sempSession.createSQLQuery(bqry).list();
			Iterator it = list.iterator();
			sb.append("<StaffAccolades>");
			while (it.hasNext()) {

				Object[] stu = (Object[]) it.next();

				if (stu == null) {
					System.out.println("there is no staffAccolades object");
				} else {
					sb.append("<StaffAccolade>");
					sb.append("\n");
					sb.append("<accoladeId>"+stu[0]+"</accoladeId>");
					sb.append("\n");
					sb.append("<employeeId>"+stu[1]+"</employeeId>");
					sb.append("\n");
					sb.append("<staffFirstName>" + stu[16] + "</staffFirstName>");
					sb.append("\n");
					sb.append("<staffMiddleName>" + stu[17] + "</staffMiddleName>");
					sb.append("\n");
					sb.append("<staffLastName>" + stu[18]+ "</staffLastName>");
					sb.append("\n");
					sb.append("<staffNumber>" + stu[19] + "</staffNumber>");
					sb.append("\n");
					sb.append("<accoladeTypeId>" + stu[2]+ "</accoladeTypeId>");
					sb.append("\n");
					sb.append("<accoladeTypeName>" + stu[20] + "</accoladeTypeName>");
					sb.append("\n");
					sb.append("<resultId>" + stu[3]+ "</resultId>");
					sb.append("\n");
					sb.append("<resultName>" + stu[21]+ "</resultName>");
					sb.append("\n");
					sb.append("<accoladeTitle>" + stu[4] + "</accoladeTitle>");
					sb.append("\n");
					sb.append("<awardedDate>" + stu[5]+ "</awardedDate>");
					sb.append("\n");
					sb.append("<duration>" + stu[6] + "</duration>");
					sb.append("\n");
					sb.append("<prize>" +  stu[7]+ "</prize>");
					sb.append("\n");
					sb.append("<medal>" + stu[8] + "</medal>");
					sb.append("\n");
					sb.append("<description>" + stu[9] + "</description>");
					sb.append("\n");
					sb.append("<remarks>" + stu[10] + "</remarks>");
					sb.append("\n");
					sb.append("<createdDate>" + stu[11] + "</createdDate>");
					sb.append("\n");
					sb.append("<modifiedDate>" + stu[12]+ "</modifiedDate>");
					sb.append("\n");
					sb.append("<schoolId>" + stu[13]+ "</schoolId>");
					sb.append("\n");
					sb.append("<branchId>" + stu[14]+ "</branchId>");
					sb.append("\n");
					sb.append("<isDeleted>" + stu[15]+ "</isDeleted>");
					sb.append("\n");
					sb.append("</StaffAccolade>");
					sb.append("\n");
				}
				sb.append("</StaffAccolades>");
				semptx.commit();
				strg = sb.toString();
			}

		} catch (Exception localException) {
			System.out.println(localException);

			localException.printStackTrace();
			sb.append("<Response>");
			sb.append("\n");
			sb.append("<Result>");
			sb.append("\n");
			sb.append("Fail");
			sb.append("\n");
			sb.append("</Result>");
			sb.append("\n");
			sb.append("<Description>");

			sb.append("could not inserted Issue info");
			sb.append("</Description>");
			sb.append("\n");
			sb.append("<Exception>");
			sb.append(localException);
			sb.append("</Exception>");
			sb.append("</Response>");
			strg = sb.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (semptx != null)
				semptx.rollback();
		} finally {
			sempSession.close();
		}
		return strg;
	}

	@SuppressWarnings("rawtypes")
	public String searchAssessment(AssessmentPojo ast) {
		Session sempSession=MDHibernateUtil.getSessionFactory().openSession();
		 Transaction semptx=null;
		
		 StringBuffer sb=new StringBuffer();
		 //String string=null;
		 String strg=null;
			//CataloguePojo cp=null;
		 try
		 {
			 semptx=sempSession.beginTransaction();
			 String bqry="select * from gbl_sm_tbl_assessment where(assessmentId like '%"+ ast.getAssessmentId() +"%' or assessmentTypeId like '%"+ ast.getAssessmentTypeId() +
					 "%' or assessmentName like '%"+ ast.getAssessmentName() +"%' or description like '%"+ ast.getDescription() +
					 "%' or startdate like '%"+ ast.getStartDate() +"%' or enddate like '%"+ ast.getEndDate() +"%' or status like '%"+ ast.getStatus() +"%' or remarks like '%"+ ast.getRemarks() +"%');";
			
			// Query sQuery = sempSession.createSQLQuery(bqry);
			 List list=sempSession.createSQLQuery(bqry).list();
				Iterator it=list.iterator();
				sb.append("<Assessment>");
				while(it.hasNext()){
					Object[] ex=(Object[])it.next();
					
			        sb.append("\n");
			        sb.append("<assessmentId>");
				    sb.append(ex[0]);
				    sb.append("</assessmentId>");
				    sb.append("\n");
				    sb.append("<assessmentTypeId>");
					 sb.append(ex[1]);
					 sb.append("</assessmentTypeId>");
					 sb.append("\n");
					 sb.append("<assessmentName>");
					 sb.append(ex[2]);
					 sb.append("</assessmentName>");
					 sb.append("\n");
			        sb.append("<description>");
				    sb.append(ex[3]);
				    sb.append("</description>");
				    sb.append("\n");
					sb.append("<startdate>");
					sb.append(ex[4]);
					sb.append("</startdate>");
					 sb.append("\n");
					 sb.append("<enddate>");
					 sb.append(ex[5]);
					 sb.append("</enddate>");
					 sb.append("\n");
					 sb.append("<status>");
					 sb.append(ex[6]);
					 sb.append("</status>");
					 sb.append("\n");
					 sb.append("<remarks>");
					 sb.append(ex[7]);
					 sb.append("</remarks>");
					 sb.append("\n");
					 
					 }
				
				sb.append("</Assessment>");
				strg=sb.toString(); 
				 
				 semptx.commit();
		 
		 
		 }catch(Exception localException){
			 System.out.println(localException);
				
				localException.printStackTrace();  
				sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not search assessment info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       strg= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (semptx!=null)
		    	 semptx.rollback();		}
			finally
			{			
				sempSession.close();
			}
			return strg;
	
	}

	@SuppressWarnings("rawtypes")
	public String searchBranch(SchoolBranchPojo sbp) {
		Session sempSession=MDHibernateUtil.getSessionFactory().openSession();
		 Transaction semptx=null;
		 StringBuffer sb=new StringBuffer();
		 String strg=null;
		 try
		 {
			 semptx=sempSession.beginTransaction();
			 String bqry="select * from gbl_sm_tbl_school_branch where(schoolBranchId like '%"+ sbp.getSchoolBranchId() +"%' or branchName like '%"+ sbp.getBranchName() +
					 "%' or schoolId like '%"+ sbp.getSchoolId() +"%' or description like '%"+ sbp.getDescription() +
					 "%' or  priority like '%"+ sbp.getPriority() +"%' or status like '%"+ sbp.getStatus() +"%');";
			
			 List list=sempSession.createSQLQuery(bqry).list();
				Iterator it=list.iterator();
				sb.append("<Branch>");
				while(it.hasNext()){
					Object[] ex=(Object[])it.next();
					
			        sb.append("\n");
			        sb.append("<schoolBranchId>");
				    sb.append(ex[0]);
				    sb.append("</schoolBranchId>");
				    sb.append("\n");
				    sb.append("<branchName>");
					 sb.append(ex[2]);
					 sb.append("</branchName>");
					 sb.append("\n");
					 sb.append("<schoolId>");
					 sb.append(ex[1]);
					 sb.append("</schoolId>");
					 sb.append("\n");
					 sb.append("<description>");
					 sb.append(ex[5]);
					 sb.append("</description>");
					 sb.append("\n");
			        sb.append("<priority>");
				    sb.append(ex[3]);
				    sb.append("</priority>");
				    sb.append("\n");
				    sb.append("<status>");
					sb.append(ex[4]);
					sb.append("</status>");
					sb.append("\n"); 
					 }
				
				sb.append("</Branch>");
				strg=sb.toString(); 
				 
				 semptx.commit();
		 
		 
		 }catch(Exception localException){
			 System.out.println(localException);
				
				localException.printStackTrace();  
				sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not search branch info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       strg= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (semptx!=null)
		    	 semptx.rollback();		}
			finally
			{			
				sempSession.close();
			}
			return strg;
	}

	public String searchQuestion(QuestionPojo qp) {
		Session sempSession=MDHibernateUtil.getSessionFactory().openSession();
		 Transaction semptx=null;
		
		 StringBuffer sb=new StringBuffer();
		 String string=null;
		 String strg=null;
			//CataloguePojo cp=null;
		 try
		 {
			 semptx=sempSession.beginTransaction();
			 String bqry="select * from gbl_sm_tbl_question where(questiontypeId like '%"+ qp.getQuestiontypeId() +"%'  or questionId like '%"+ qp.getQuestionId() +"%' or questionTitle like '%"+ qp.getQuestionTitle() +
					 "%' or  answer like '%"+ qp.getAnswer() +"%' or maxScore like '%"+ qp.getMaxScore() +"%');";
			
			// Query sQuery = sempSession.createSQLQuery(bqry);
			 List list=sempSession.createSQLQuery(bqry).list();
				Iterator it=list.iterator();
				sb.append("<Question>");
				while(it.hasNext()){
					Object[] ex=(Object[])it.next();
					
			        sb.append("\n");
			        sb.append("<questiontypeId>");
				    sb.append(ex[1]);
				    sb.append("</questiontypeId>");
				    sb.append("\n");
					 sb.append("<questionId>");
					 sb.append(ex[0]);
					 sb.append("</questionId>");
					 sb.append("\n");
					 sb.append("<questiontitle>");
					 sb.append(ex[3]);
					 sb.append("</questiontitle>");
					 sb.append("\n"); 
					sb.append("<answer>");
					sb.append(ex[4]);
					sb.append("</answer>");
					sb.append("\n"); 
					sb.append("<maxscore>");
					sb.append(ex[5]);
					sb.append("</maxscore>");
					sb.append("\n"); 
					 }
				
				sb.append("</Question>");
				strg=sb.toString(); 
				 
				 semptx.commit();
		 
		 
		 }catch(Exception localException){
			 System.out.println(localException);
				
				localException.printStackTrace();  
				sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not search question info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       strg= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (semptx!=null)
		    	 semptx.rollback();		}
			finally
			{			
				sempSession.close();
			}
			return strg;
	}

	@SuppressWarnings("rawtypes")
	public String searchQuestionPaper(QuestionPaperPojo qpp) {
		Session sempSession=MDHibernateUtil.getSessionFactory().openSession();
		 Transaction semptx=null;
		
		 StringBuffer sb=new StringBuffer();
		 String string=null;
		 String strg=null;
			//CataloguePojo cp=null;
		 try
		 {
			 semptx=sempSession.beginTransaction();
			 String bqry="select * from gbl_sm_tbl_question_paper where(questionPaperId like '%"+ qpp.getQuestionPaperId() +"%' or paperTitle like '%"+ qpp.getPaperTitle() +"%' or instructions like '%"+ qpp.getInstructions() +"%' or subjectId like '%"+ qpp.getSubjectId() +
					 "%' or description like '%"+ qpp.getDescription() +"%' or  classId like '%"+ qpp.getSubjectId()  +"%');";
			
			// Query sQuery = sempSession.createSQLQuery(bqry);
			 List list=sempSession.createSQLQuery(bqry).list();
				Iterator it=list.iterator();
				sb.append("<QuestionPaper>");
				while(it.hasNext()){
					Object[] ex=(Object[])it.next();
					
			        sb.append("\n");
			        sb.append("<questionpaperId>");
				    sb.append(ex[0]);
				    sb.append("</questionpaperId>");
				    sb.append("\n");
				    sb.append("<subjectid>");
					 sb.append(ex[1]);
					 sb.append("</subjectid>");
					 sb.append("\n");
					sb.append("<instructions>");
					sb.append(ex[2]);
					sb.append("</instructions>");
					sb.append("\n");
					sb.append("<papertitle>");
					sb.append(ex[3]);
					sb.append("</papertitle>");
					sb.append("\n");
					sb.append("<level>");
					sb.append(ex[4]);
					sb.append("</level>");
					sb.append("\n");
					sb.append("<description>");
					sb.append(ex[5]);
					sb.append("</description>");
					sb.append("\n");
					 }
				
				sb.append("</QuestionPaper>");
				strg=sb.toString(); 
				 
				 semptx.commit();
		 
		 
		 }catch(Exception localException){
			 System.out.println(localException);
				
				localException.printStackTrace();  
				sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not search questionpaper info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       strg= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (semptx!=null)
		    	 semptx.rollback();		}
			finally
			{			
				sempSession.close();
			}
			return strg;
	}

	@SuppressWarnings("rawtypes")
	public String searchRoom(RoomPojo rp) {
		Session sempSession=MDHibernateUtil.getSessionFactory().openSession();
		 Transaction semptx=null;
		
		 StringBuffer sb=new StringBuffer();
		 String string=null;
		 String strg=null;
			//CataloguePojo cp=null;
		 try
		 {
			 semptx=sempSession.beginTransaction();
			 String bqry="select * from gbl_sm_tbl_room where(roomNo like '%"+ rp.getRoomNo() +"%' or roomName like '%"+ rp.getRoomName() +"%');";
			
			// Query sQuery = sempSession.createSQLQuery(bqry);
			 List list=sempSession.createSQLQuery(bqry).list();
				Iterator it=list.iterator();
				sb.append("<Room>");
				while(it.hasNext()){
					Object[] ex=(Object[])it.next();
					
			        sb.append("\n");
			        sb.append("<roomNo>");
				    sb.append(ex[3]);
				    sb.append("</roomNo>");
				    sb.append("\n");
				    sb.append("<roomName>");
					 sb.append(ex[8]);
					 sb.append("</roomName>");
					 sb.append("\n");
				
					 }
				
				sb.append("</Room>");
				strg=sb.toString(); 
				 
				 semptx.commit();
		 
		 
		 }catch(Exception localException){
			 System.out.println(localException);
				
				localException.printStackTrace();  
				sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not search room info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       strg= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (semptx!=null)
		    	 semptx.rollback();		}
			finally
			{			
				sempSession.close();
			}
			return strg;
	}


	

	@SuppressWarnings("rawtypes")
	public String searchBook(CataloguePojo cp,int schoolId,int branchId) {
		 Session sempSession=MDHibernateUtil.getSessionFactory().openSession();
		 Transaction semptx=null;
		 StringBuffer sb=new StringBuffer();
		 String strg=null;
		 try
		 {
			 semptx=sempSession.beginTransaction();
			 String bqry="select * from gbl_sm_tbl_catalogue where(BookId like '%"+ cp.getBookId() +"%' or BookTypeId like '%"+ cp.getBookTypeId() +"%' or LibSubjectId like '%"+ cp.getLibSubjectId() +"%' or LibSectionId like '%"+ cp.getLibSectionId() +"%' or BookReceiptId like '%"+ cp.getBookReceiptId() +"%' or  CatalogueName like '%"+ cp.getCatalogueName() +"%' or BookNo like '%"+ cp.getBookNo() +"%' or BookTitle like '%"+ cp.getBookTitle() +"%' or Author like '%"+ cp.getAuthor() +"%' or  Barcode like '%"+ cp.getBarcode() +"%' or ISBN like '%"+ cp.getISBN() +"%' or Publisher like '%"+ cp.getPublisher() +"%' or PublisheDate like '%"+ cp.getPublisheDate() +"%' or Printer like '%"+ cp.getPrinter() +"%' or TypeSetter like '%"+ cp.getTypeSetter() +"%' or RackNo like '%"+ cp.getRackNo() +"%' or RowNo like '%"+ cp.getRowNo() +"%' or OrderNo like '%"+ cp.getOrderNo() +"%' or Quantity like '%"+ cp.getQuantity() +"%' or BookCost like '%"+ cp.getBookCost() +"%' or IsIssue like '%"+ cp.getIsIssue() +"%')and SchoolId='"+schoolId+"'and BranchId='"+branchId+"';;";
			 List list=sempSession.createSQLQuery(bqry).list();
				Iterator it=list.iterator();
				sb.append("<Catalogue>");
				while(it.hasNext()){
					Object[] ex=(Object[])it.next();
					sb.append("<Catalogue>");
			        sb.append("\n");
			        sb.append("<bookId>");
				    sb.append(ex[0]);
				    sb.append("</bookId>");
				    sb.append("\n");
				    sb.append("<bookTypeId>");
					 sb.append(ex[1]);
					 sb.append("</bookTypeId>");
					 sb.append("\n");
					 sb.append("<libSubjectId>");
					 sb.append(ex[2]);
					 sb.append("</libSubjectId>");
					 sb.append("\n");
					 sb.append("<libSectionId>");
					 sb.append(ex[3]);
					 sb.append("</libSectionId>");
					 sb.append("\n");
					 sb.append("<BookReceiptId>");
					 sb.append(ex[4]);
					 sb.append("</BookReceiptId>");
					 sb.append("\n");
			        sb.append("<catalogueName>");
				    sb.append(ex[5]);
				    sb.append("</catalogueName>");
				    sb.append("\n");
				    sb.append("<bookNo>");
					sb.append(ex[6]);
					sb.append("</bookNo>");
					sb.append("\n");
					sb.append("<bookTitle>");
					sb.append(ex[7]);
					sb.append("</bookTitle>");
					 sb.append("\n");
					 sb.append("<image>");
					sb.append(ex[8]);
					sb.append("</image>");
					sb.append("\n");
					 sb.append("<author>");
					 sb.append(ex[9]);
					 sb.append("</author>");
					 sb.append("\n");
					 sb.append("<ISBN>");
					 sb.append(ex[10]);
					 sb.append("</ISBN>");
					 sb.append("\n");
					 sb.append("<barcode>");
					 sb.append(ex[11]);
					 sb.append("</barcode>");
					 sb.append("\n");
					 sb.append("<publisher>");
					 sb.append(ex[12]);
					 sb.append("</publisher>");
					 sb.append("\n");
					 sb.append("<volume>");
					 sb.append(ex[13]);
					 sb.append("</volume>");
					 sb.append("\n");
					 sb.append("<publishDate>");
					 sb.append(ex[14]);
					 sb.append("</publishDate>");
					 sb.append("\n");
					 sb.append("<printer>");
					 sb.append(ex[15]);
					 sb.append("</printer>");
					 sb.append("\n");
					 sb.append("<typeSetter>");
					 sb.append(ex[16]);
					 sb.append("</typeSetter>");
					 sb.append("\n");
					 
					 
					 sb.append("<rackNo>");
					 sb.append(ex[17]);
					 sb.append("</rackNo>");
					 sb.append("\n");
					 
					 sb.append("<rowNo>");
					 sb.append(ex[18]);
					 sb.append("</rowNo>");
					 sb.append("\n");
					 sb.append("<orderNo>");
					 sb.append(ex[19]);
					 sb.append("</orderNo>");
					 sb.append("\n");
					
					
					sb.append("<quantity>");
					 sb.append(ex[20]);
					 sb.append("</quantity>");
					 sb.append("\n");
					 sb.append("<bookCost>");
					 sb.append(ex[21]);
					 sb.append("</bookCost>");
					 sb.append("\n");
					 
					 sb.append("<isIssue>");
					 sb.append(ex[22]);
					 sb.append("</isIssue>");
					 sb.append("\n");
					 sb.append("<description>");
					 sb.append(ex[23]);
					 sb.append("</description>");
					 sb.append("\n");
					 sb.append("</Catalogue>");
				}
				
				sb.append("</Catalogue>");
				strg=sb.toString(); 
				 
				 semptx.commit();
		 
		 
		 }catch(Exception localException){
			 System.out.println(localException);
				
				localException.printStackTrace();  
				sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not inserted Issue info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       strg= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (semptx!=null)
		    	 semptx.rollback();		}
			finally
			{			
				sempSession.close();
			}
			return strg;
	
	}



	@SuppressWarnings("rawtypes")
	public String searchLibSubject(LibSubjectPojo cp,int schoolId,int branchId) {
		Session sempSession=MDHibernateUtil.getSessionFactory().openSession();
		 Transaction semptx=null;
		 StringBuffer sb=new StringBuffer();
		 String outStr=null;
		 try
		 {
			 semptx=sempSession.beginTransaction();
				String query = "select *from gbl_sm_tbl_lib_subject where (LibSubjectId LIKE '%"+cp.getLibSubjectId()+"%' OR LibCategoryId LIKE '%"+cp.getLibCategoryId()+"%' OR SubjectName LIKE '%"+ cp.getSubjectName() +"%')and SchoolId='"+schoolId+"'and BranchId='"+branchId+"';"; 
				List list=sempSession.createSQLQuery(query).list();
				Iterator it=list.iterator();
				sb.append("<libSubject>");
				while(it.hasNext()){
					Object[] ex=(Object[])it.next();
					
			        sb.append("\n");
			        sb.append("<libSubjectId>");
				    sb.append(ex[0]);
				    sb.append("</libSubjectId>");
				    sb.append("\n");
				    sb.append("<libCategoryId>");
					sb.append(ex[1]);
					sb.append("</libCategoryId>");
					sb.append("\n");
			        sb.append("<subjectName>");
				    sb.append(ex[2]);
				    sb.append("</subjectName>");
				    sb.append("\n");
				    sb.append("<description>");
					sb.append(ex[3]);
					sb.append("</description>");
					sb.append("\n");
		
				}
				
				sb.append("</libSubject>");
				outStr=sb.toString(); 
				 
				 semptx.commit();
		 
		 
		 }catch(Exception localException){
			 System.out.println(localException);
				
				localException.printStackTrace();  
				sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not inserted Issue info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       outStr= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (semptx!=null)
		    	 semptx.rollback();		}
			finally
			{			
				sempSession.close();
			}
			return outStr;	
	}

	@SuppressWarnings("rawtypes")
	public String searchIssues(IssuePojo ip,int schoolId,int branchId) {
		Session sempSession=MDHibernateUtil.getSessionFactory().openSession();
		 Transaction semptx=null;
		 StringBuffer sb=new StringBuffer();
		 String outStr=null;
		 try
		 {
			 semptx=sempSession.beginTransaction();
				String query = "select *from gbl_sm_tbl_issues where (IssueId LIKE '%"+ip.getIssueId()+"%' Or BookId LIKE '%"+ ip.getBookId() +"%' Or EmployeeId LIKE '%"+ ip.getEmployeeId() +"%' or StudentId LIKE '%"+ ip.getStudentId() +"%' or IssuedDate LIKE '%"+ ip.getIssuedDate() +"%' or ReturnDate LIKE '%"+ ip.getReturnDate() +"%' or  ReturnedOn LIKE '%"+ ip.getReturnedOn() +"%' or LateFee LIKE '%"+ ip.getLateFee() +"%' or IsFeeCollected LIKE '%"+ ip.getIsFeeCollected() +"%' or IsLost LIKE '%"+ ip.getIsLost() +"%' or IsDamaged LIKE '%"+ ip.getIsDamaged() +"%' or RecoveredCost LIKE '%"+ ip.getRecoveredCost() +"%' or IssuedBy LIKE '%"+ ip.getIssuedBy() +"%')and SchoolId='"+schoolId+"'and BranchId='"+branchId+"';"; 
				List list=sempSession.createSQLQuery(query).list();
				Iterator it=list.iterator();
				sb.append("<Issue>");
				while(it.hasNext()){
					Object[] ex=(Object[])it.next();
					sb.append("<Issue>");
			        sb.append("\n");
			        sb.append("<issueId>");
				    sb.append(ex[0]);
				    sb.append("</issueId>");
				    sb.append("\n");
				    sb.append("<bookId>");
					sb.append(ex[1]);
					sb.append("</bookId>");
					sb.append("\n");
			        sb.append("<employeeId>");
				    sb.append(ex[2]);
				    sb.append("</employeeId>");
				    sb.append("\n");
				    sb.append("<studentId>");
					sb.append(ex[3]);
					sb.append("</studentId>");
					sb.append("\n");
					sb.append("<issuedDate>");
			        sb.append("\n");
				    sb.append(ex[4]);
				    sb.append("</issuedDate>");
				    sb.append("\n");
				    sb.append("<returnDate>");
					sb.append(ex[5]);
					sb.append("</returnDate>");
					sb.append("\n");
			        sb.append("<returnedOn>");
				    sb.append(ex[6]);
				    sb.append("</returnedOn>");
				    sb.append("\n");
				    sb.append("<lateFee>");
					sb.append(ex[7]);
					sb.append("</lateFee>");
					sb.append("\n");
					sb.append("<isFeeCollected>");
				    sb.append(ex[8]);
				    sb.append("</isFeeCollected>");
				    sb.append("\n");
				    sb.append("<isLost>");
					sb.append(ex[9]);
					sb.append("</isLost>");
					sb.append("\n");
			        sb.append("<isDamaged>");
				    sb.append(ex[10]);
				    sb.append("</isDamaged>");
				    sb.append("\n");
				    sb.append("<recoveredCost>");
					sb.append(ex[11]);
					sb.append("</recoveredCost>");
					sb.append("\n");
					sb.append("</Issue>");
				}
				
				sb.append("</Issue>");
				outStr=sb.toString(); 
				 
				 semptx.commit();
		 
		 
		 }catch(Exception localException){
			 System.out.println(localException);
				
				localException.printStackTrace();  
				sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not inserted Issue info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       outStr= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (semptx!=null)
		    	 semptx.rollback();		}
			finally
			{			
				sempSession.close();
			}
			return outStr;
	}

	@SuppressWarnings("rawtypes")
	public String searchFeeStructure(FeeStructure cp,int schoolId,int branchId) {
		Session sempSession=MDHibernateUtil.getSessionFactory().openSession();
		 Transaction semptx=null;
		 StringBuffer sb=new StringBuffer();
		 String outStr=null;
		 try
		 {
			 semptx=sempSession.beginTransaction();
				String query = "select *from gbl_sm_tbl_fee_structure where (FeeStructureId LIKE '%"+cp.getFeeStructureId()+"%' Or ClassId LIKE '%"+ cp.getClassId() +"%' Or SectionId LIKE '%"+ cp.getSectionId() +"%' Or Title LIKE '%"+ cp.getTitle() +"%' Or AcademicYear LIKE '%"+ cp.getAcademicYear() +"%' Or StartDate LIKE '%"+ cp.getStartDate() +"%' or EndDate LIKE '%"+ cp.getEndDate() +"%')and SchoolId='"+schoolId+"'and BranchId='"+branchId+"';"; 
				List list=sempSession.createSQLQuery(query).list();
				Iterator it=list.iterator();
				sb.append("<FeeStructure>");
				while(it.hasNext()){
					Object[] ex=(Object[])it.next();
					sb.append("<FeeStructure>");
			        sb.append("\n");
			        sb.append("<feeStructureId>");
				    sb.append(ex[0]);
				    sb.append("</feeStructureId>");
				    sb.append("\n");
				    sb.append("<classId>");
					sb.append(ex[1]);
					sb.append("</classId>");
					sb.append("\n");
			        sb.append("<sectionId>");
				    sb.append(ex[2]);
				    sb.append("</sectionId>");
				    sb.append("\n");
				    sb.append("<title>");
					sb.append(ex[3]);
					sb.append("</title>");
					sb.append("\n");
					sb.append("<description>");
			        sb.append("\n");
				    sb.append(ex[4]);
				    sb.append("</description>");
				    sb.append("\n");
				    sb.append("<academicYear>");
					sb.append(ex[5]);
					sb.append("</academicYear>");
					sb.append("\n");
			        sb.append("<startDate>");
				    sb.append(ex[6]);
				    sb.append("</startDate>");
				    sb.append("\n");
				    sb.append("<endDate>");
					sb.append(ex[7]);
					sb.append("</endDate>");
					sb.append("\n");
					sb.append("<status>");
			        sb.append("\n");
				    sb.append(ex[8]);
				    sb.append("</status>");
				    sb.append("\n");
					sb.append("</FeeStructure>");
				}
				
				sb.append("</FeeStructure>");
				outStr=sb.toString(); 
				 
				 semptx.commit();
		 
		 
		 }catch(Exception localException){
			 System.out.println(localException);
				
				localException.printStackTrace();  
				sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not inserted Issue info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       outStr= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (semptx!=null)
		    	 semptx.rollback();		}
			finally
			{			
				sempSession.close();
			}
			return outStr;
	}

	@SuppressWarnings("rawtypes")
	public String searchFeeItems(FeeItemPojo ip,int schoolId,int branchId) {
		Session sempSession=MDHibernateUtil.getSessionFactory().openSession();
		 Transaction semptx=null;
		 StringBuffer sb=new StringBuffer();
		 String outStr=null;
		 try
		 {
			 semptx=sempSession.beginTransaction();
				String query = "select *from gbl_sm_tbl_fee_item where (FeeItemId like '%"+ ip.getFeeItemId() +"%' or FeeItemTypeId like '%"+ ip.getFeeItemTypeId() +"%' or StudentId like '%"+ ip.getStudentId() +"%' or EventId like '%"+ ip.getEventId() +"%' or ItemName like '%"+ ip.getItemName() +"%' or  StartDate like '%"+ ip.getStartDate() +"%' or EndDate like '%"+ ip.getEndDate() +"%' or Amount like '%"+ ip.getAmount() +"%' or ValidFrom like '%"+ ip.getValidFrom() +"%' or ValidTo like '%"+ ip.getValidTo() +"%')and SchoolId='"+schoolId+"'and BranchId='"+branchId+"';"; 
				List list=sempSession.createSQLQuery(query).list();
				Iterator it=list.iterator();
				sb.append("<FeeItems>");
				while(it.hasNext()){
					Object[] ex=(Object[])it.next();
					sb.append("<FeeItem>");
			        sb.append("\n");
			        sb.append("<feeItemId>");
				    sb.append(ex[0]);
				    sb.append("</feeItemId>");
				    sb.append("\n");
				    sb.append("<feeItemTypeId>");
					sb.append(ex[1]);
					sb.append("</feeItemTypeId>");
					sb.append("\n");
			        sb.append("<studentId>");
				    sb.append(ex[2]);
				    sb.append("</studentId>");
				    sb.append("\n");
				    sb.append("<eventId>");
					sb.append(ex[3]);
					sb.append("</eventId>");
					sb.append("\n");
					/*sb.append("<classId>");
			        sb.append("\n");
				    sb.append(ex[4]);
				    sb.append("</classId>");
				    sb.append("\n");
				    sb.append("<sectionId>");
					sb.append(ex[5]);
					sb.append("</sectionId>");
					sb.append("\n");*/
			       /* sb.append("<feeStructureId>");
				    sb.append(ex[6]);
				    sb.append("</feeStructureId>");
				    sb.append("\n");*/
				    sb.append("<itemName>");
					sb.append(ex[4]);
					sb.append("</itemName>");
					sb.append("\n");
					sb.append("<startDate>");
				    sb.append(ex[5]);
				    sb.append("</startDate>");
				    sb.append("\n");
				    sb.append("<endDate>");
					sb.append(ex[6]);
					sb.append("</endDate>");
					sb.append("\n");
			        sb.append("<amount>");
				    sb.append(ex[7]);
				    sb.append("</amount>");
				    sb.append("\n");
				    sb.append("<validFrom>");
					sb.append(ex[8]);
					sb.append("</validFrom>");
					sb.append("\n");
					sb.append("<validTo>");
					sb.append(ex[9]);
					sb.append("</validTo>");
					sb.append("\n");
					sb.append("<status>");
					sb.append(ex[10]);
					sb.append("</status>");
					sb.append("\n");
					sb.append("<description>");
					sb.append(ex[11]);
					sb.append("</description>");
					sb.append("\n");
					sb.append("</FeeItem>");
				}
				
				sb.append("</FeeItems>");
				outStr=sb.toString(); 
				 
				 semptx.commit();
		 
		 
		 }catch(Exception localException){
			 System.out.println(localException);
				
				localException.printStackTrace();  
				sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not inserted Issue info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       outStr= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (semptx!=null)
		    	 semptx.rollback();		}
			finally
			{			
				sempSession.close();
			}
			return outStr;
	}
	
	@SuppressWarnings("rawtypes")
	public String searchPayment(Payment ip,int schoolId,int branchId) {
		Session sempSession=MDHibernateUtil.getSessionFactory().openSession();
		 Transaction semptx=null;
		 StringBuffer sb=new StringBuffer();
		 String outStr=null;
		 try
		 {
			 semptx=sempSession.beginTransaction();
			 String query = "select *from gbl_sm_tbl_payment where (PaymentId like '%"+ ip.getPaymentId()+"%' or PaymentModeId like '%"+ ip.getPaymentModeId() +"%' or EmployeeId like '%"+ ip.getEmployeeId() +"%' or StudentId like '%"+ ip.getStudentId() +"%' or  PayReceiptNo like '%"+ ip.getPayReceiptNo() +"%' or PaidBy like '%"+ ip.getPaidBy() +"%' or DatePaid like '%"+ ip.getDatePaid() +"%')and SchoolId='"+schoolId+"'and BranchId='"+branchId+"';"; 
				List list=sempSession.createSQLQuery(query).list();
				Iterator it=list.iterator();
				sb.append("<Payments>");
				while(it.hasNext()){
					Object[] ex=(Object[])it.next();
					sb.append("<Payment>");
			        sb.append("\n");
			        sb.append("<paymentId>");
				    sb.append(ex[0]);
				    sb.append("</paymentId>");
				    sb.append("\n");
				    sb.append("<paymentModeId>");
					sb.append(ex[1]);
					sb.append("</paymentModeId>");
					sb.append("\n");
			        sb.append("<employeeId>");
				    sb.append(ex[2]);
				    sb.append("</employeeId>");
				    sb.append("\n");
				    sb.append("<studentId>");
					sb.append(ex[3]);
					sb.append("</studentId>");
					sb.append("\n");
					sb.append("<payReceiptNo>");
			        sb.append("\n");
				    sb.append(ex[4]);
				    sb.append("</payReceiptNo>");
				    sb.append("\n");
				    sb.append("<paidBy>");
					sb.append(ex[5]);
					sb.append("</paidBy>");
					sb.append("\n");
			        sb.append("<datePaid>");
				    sb.append(ex[6]);
				    sb.append("</datePaid>");
				    sb.append("\n");
				    sb.append("<totalAmount>");
					sb.append(ex[7]);
					sb.append("</totalAmount>");
					sb.append("\n");
					sb.append("<remarks>");
			        sb.append("\n");
				    sb.append(ex[8]);
				    sb.append("</remarks>");
				    sb.append("\n");
					sb.append("</Payment>");
				}
				
				sb.append("</Payments>");
				outStr=sb.toString(); 
				 
				 semptx.commit();
		 
		 
		 }catch(Exception localException){
			 System.out.println(localException);
				
				localException.printStackTrace();  
				sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not inserted Issue info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       outStr= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (semptx!=null)
		    	 semptx.rollback();		}
			finally
			{			
				sempSession.close();
			}
			return outStr;
	}

	@SuppressWarnings("rawtypes")
	public String searchBookReceipt(BookReceiptPojo ip,int schoolId,int branchId) {
		Session sempSession=MDHibernateUtil.getSessionFactory().openSession();
		 Transaction semptx=null;
		 StringBuffer sb=new StringBuffer();
		 String outStr=null;
		 try
		 {
			 semptx=sempSession.beginTransaction();
			 String query = "select *from gbl_sm_tbl_bookreceipt where (BookReceiptId like '%"+ ip.getBookReceiptId()+"%' or BookReceiptTitle like '%"+ ip.getBookReceiptTitle()+"%' or QuantityReceived like '%"+ ip.getQuantityReceived() +"%' or InVoiceNo like '%"+ ip.getInVoiceNo() +"%' or OrderNo like '%"+ ip.getOrderNo() +"%' or  InVoiceAmount like '%"+ ip.getInVoiceAmount()+"%' or BookPrice like '%"+ ip.getBookPrice() +"%' or DateReceived like '%"+ ip.getDateReceived() +"%')and SchoolId='"+schoolId+"'and BranchId='"+branchId+"';"; 
				List list=sempSession.createSQLQuery(query).list();
				Iterator it=list.iterator();
				sb.append("<bookReceipts>");
				while(it.hasNext()){
					Object[] ex=(Object[])it.next();
					sb.append("<bookReceipt>");
			        sb.append("\n");
			        sb.append("<bookReceiptId>");
				    sb.append(ex[0]);
				    sb.append("</bookReceiptId>");
				    sb.append("\n");
				    sb.append("<bookReceiptTitle>");
				    sb.append(ex[1]);
				    sb.append("</bookReceiptTitle>");
				    sb.append("\n");
				    sb.append("<quantityReceived>");
					sb.append(ex[2]);
					sb.append("</quantityReceived>");
					sb.append("\n");
			        sb.append("<inVoiceNo>");
				    sb.append(ex[3]);
				    sb.append("</inVoiceNo>");
				    sb.append("\n");
				    sb.append("<orderNo>");
					sb.append(ex[4]);
					sb.append("</orderNo>");
					sb.append("\n");
					sb.append("<inVoiceAmount>");
				    sb.append(ex[5]);
				    sb.append("</inVoiceAmount>");
				    sb.append("\n");
				    sb.append("<bookPrice>");
					sb.append(ex[6]);
					sb.append("</bookPrice>");
					sb.append("\n");
			        sb.append("<dateReceived>");
				    sb.append(ex[7]);
				    sb.append("</dateReceived>");
				    sb.append("\n");
				    sb.append("<description>");
				    sb.append(ex[8]);
				    sb.append("</description>");
				    sb.append("\n");
					sb.append("</bookReceipt>");
				}
				
				sb.append("</bookReceipts>");
				outStr=sb.toString(); 
				 
				 semptx.commit();
		 
		 
		 }catch(Exception localException){
			 System.out.println(localException);
				
				localException.printStackTrace();  
				sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not inserted Issue info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       outStr= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (semptx!=null)
		    	 semptx.rollback();		}
			finally
			{			
				sempSession.close();
			}
			return outStr;
	}
	@SuppressWarnings("rawtypes")
	public String getFieldValues(String infoclassName, String fieldnames, String filter, int pNO, int size) {
		Session gicSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gobjDetailsTx = null;	
		String ginfXMLString=null;
		StringBuffer infFieldsSB=new StringBuffer();
		
		try
		{
			gobjDetailsTx=gicSession.beginTransaction();
			String qry = "select "+fieldnames+" from "+infoclassName;
			if (filter != null) {
				qry = qry + " where "+filter;
			}
			Query fvQuery=gicSession.createSQLQuery(qry);
			List fvList=fvQuery.list();
			//Iterator fvit=fvList.iterator();
			String [] flds = fieldnames.split(",");
			for(int i=0; i<flds.length;i++)
			{
				infFieldsSB.append("<fieldvalues>");
				infFieldsSB.append("\n");
				infFieldsSB.append("<fieldName>");
				infFieldsSB.append(flds[i]);
				infFieldsSB.append("</fieldName>");
				infFieldsSB.append("\n");
				for(int j=0;j<fvList.size();j++)
				{
					if(flds.length==1)
					{
					Object fvStr=(Object)fvList.get(j);
					infFieldsSB.append("<fieldvalue>");
					infFieldsSB.append(fvStr);
					infFieldsSB.append("</fieldvalue>");
					infFieldsSB.append("\n");
					}else
					{
						Object[] fvStr=(Object[])fvList.get(j);
						infFieldsSB.append("<fieldvalue>");
						infFieldsSB.append(fvStr[i]);
						infFieldsSB.append("</fieldvalue>");
						infFieldsSB.append("\n");
					}
				}
				infFieldsSB.append("</fieldvalues>");
				infFieldsSB.append("\n");
			}
		
		
			ginfXMLString=infFieldsSB.toString();
			gobjDetailsTx.commit();
			infFieldsSB.setLength(0);
		}
		catch(Exception localException)
		{
			gobjDetailsTx.rollback();
			infFieldsSB.setLength(0);
			MDTransactionWriter.exceptionlog.info(localException);
			ginfXMLString="<status>Error while getting the object details</status>";
		}
		finally
		{
			infFieldsSB=null;
			 gicSession.close();			
		}

		return ginfXMLString;
	}
	}
