package com.gwebitsol.core.setting;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="AssessmentType")
public class AssessmentTypePojo {
	private int assessmentTypeId;
	private String typeName;
	private int assessmentModeId;
	private String description;
	private String status;
	private int schoolId;
	private int branchId;
	
	public int getAssessmentTypeId() {
		return assessmentTypeId;
	}
	public void setAssessmentTypeId(int assessmentTypeId) {
		this.assessmentTypeId = assessmentTypeId;
	}
	public String getTypeName() {
		return typeName;
	}
	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}
	public int getAssessmentModeId() {
		return assessmentModeId;
	}
	public void setAssessmentModeId(int assessmentModeId) {
		this.assessmentModeId = assessmentModeId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getSchoolId() {
		return schoolId;
	}
	public void setSchoolId(int schoolId) {
		this.schoolId = schoolId;
	}
	public int getBranchId() {
		return branchId;
	}
	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}
}
