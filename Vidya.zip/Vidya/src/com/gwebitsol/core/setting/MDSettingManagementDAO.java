package com.gwebitsol.core.setting;

import java.util.Iterator;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class MDSettingManagementDAO {

	public String addSettings(MDSetting mdSetting,int schoolid,int branchid) {

		String xmlString=null;
		StringBuffer settgsSB = new StringBuffer();
		try
		{
			settgsSB.append("<MD_Settings>");
			settgsSB.append("\n");
			List<AssessmentModePojo> assessmentmode = mdSetting.getAssessmentmode();
			if(assessmentmode.size()!=0){
			xmlString=saveAssessmentModePojo(assessmentmode,schoolid,branchid);
			settgsSB.append(xmlString);
				}
			else {
				settgsSB.append("<AssessmentMode></AssessmentMode>");
				settgsSB.append("\n");
				System.out.println("Empty List of AssessmentMode");
			}
			List<AssessmentTypePojo> assessmenttype = mdSetting.getAssessmenttype();
			if(assessmenttype.size()!=0){
			xmlString=saveAssessmentTypePojo(assessmenttype,schoolid,branchid);
			settgsSB.append(xmlString);
			    }
			else {
				settgsSB.append("<AssessmentType></AssessmentType>");
				settgsSB.append("\n");
				System.out.println("Empty List of AssessmentType");
				}
			List<RoomType> roomtype = mdSetting.getRoomtype();
			if(roomtype.size()!=0){
			xmlString=saveRoomType(roomtype,schoolid,branchid);
			settgsSB.append(xmlString);
			    }
			else {
				settgsSB.append("<RoomType></RoomType>");
				settgsSB.append("\n");
				System.out.println("Empty List of RoomType");
				}

			// srinu

				List<CastesPojo> castes = mdSetting.getCastes();
						if(castes.size()!=0)
						{

							xmlString=saveCastes(castes,schoolid, branchid);
							settgsSB.append(xmlString);
						        }
							else {
								settgsSB.append("<Castes></Castes>");
								settgsSB.append("\n");
								System.out.println("Empty List of Castes");
							}


						List<ReligionPojo> religions = mdSetting.getReligions();
						if(religions.size()!=0)
						{
							xmlString=saveReligions(religions,schoolid, branchid);
							settgsSB.append(xmlString);
						        }
							else {
								settgsSB.append("<Religions></Religions>");
								settgsSB.append("\n");
								System.out.println("Empty List of Religions");
							}




			List<JobtypePojo> jobtypes = mdSetting.getJobtypes();
			if(jobtypes.size()!=0)
			{

				xmlString=saveJobTypes(jobtypes,schoolid, branchid);
				settgsSB.append(xmlString);
			        }
				else {
					settgsSB.append("<Jobtypes></Jobtypes>");
					settgsSB.append("\n");
					System.out.println("Empty List of Jobtypes");
				}

			List<JobtitlePojo> jobtitles = mdSetting.getJobtitles();
			if(jobtitles.size()!=0)
			{

				xmlString=saveJobTitles(jobtitles,schoolid, branchid);
				settgsSB.append(xmlString);
			        }
				else {
					settgsSB.append("<Jobtitles></Jobtitles>");
					settgsSB.append("\n");
					System.out.println("Empty List of Jobtitles");
				}

			List<AccoladetypePojo> accoladetypes = mdSetting.getAccolades();
			if(accoladetypes.size()!=0)
			{

				xmlString=saveAccoladeTypes(accoladetypes,schoolid, branchid);
				settgsSB.append(xmlString);
			        }
				else {
					settgsSB.append("<Accoladetypes></Accoladetypes>");
					settgsSB.append("\n");
					System.out.println("Empty List of Accoladetypes");
				}
			List<ResultPojo> results = mdSetting.getResults();
			if(results.size()!=0)
			{

				xmlString=saveResults(results,schoolid, branchid);
				settgsSB.append(xmlString);
			        }
				else {
					settgsSB.append("<Results></Results>");
					settgsSB.append("\n");
					System.out.println("Empty List of Results");
				}




			List<LibSectionPOJO> libsection = mdSetting.getSection();
			if (libsection.size()!=0) {
			xmlString=savelibsection(libsection,schoolid, branchid);
			settgsSB.append(xmlString);
		        }
			else {
				settgsSB.append("<Libsection></Libsection>");
				settgsSB.append("\n");
				System.out.println("Empty List of libsections");
			}
			List<LibCategoryPojo> libCategory = mdSetting.getLibcategory();
			if (libCategory.size()!=0) {
			xmlString=savelibCategory(libCategory,schoolid, branchid);
			settgsSB.append(xmlString);
		        }
			else {
				settgsSB.append("<LibCategory></LibCategory>");
				settgsSB.append("\n");
				System.out.println("Empty List of LibCategory");
			}



			List<EventTypePojo> eventtypes = mdSetting.getEventtypes();
			if(eventtypes.size()!=0)
			{

				xmlString=saveEventTypes(eventtypes,schoolid, branchid);
				settgsSB.append(xmlString);
			        }
				else {
					settgsSB.append("<eventtypes></eventtypes>");
					settgsSB.append("\n");
					System.out.println("Empty List of eventtypes");
				}
			List<FeeItemType> feeItemtypes = mdSetting.getFeeitemtypes();
			if(feeItemtypes.size()!=0)
			{

				xmlString=saveFeeItemTypes(feeItemtypes,schoolid, branchid);
				settgsSB.append(xmlString);
			        }
				else {
					settgsSB.append("<feeItemtypes></feeItemtypes>");
					settgsSB.append("\n");
					System.out.println("Empty List of feeItemtypes");
				}


			List<BookTypePOJO> booktypes = mdSetting.getBooktypes();
			if(booktypes.size()!=0)
			{

				xmlString=saveBookTypes(booktypes,schoolid, branchid);
				settgsSB.append(xmlString);
			        }
				else {
					settgsSB.append("<booktypes></booktypes>");
					settgsSB.append("\n");
					System.out.println("Empty List of booktypes");
				}

			List<QuestionType> questiontypes = mdSetting.getQuestiontypes();
			if(questiontypes.size()!=0)
			{

				xmlString=saveQuestionTypes(questiontypes,schoolid,branchid);
				settgsSB.append(xmlString);
			        }
				else {
					settgsSB.append("<questiontypes></questiontypes>");
					settgsSB.append("\n");
					System.out.println("Empty List of questiontypes");
				}


			List<PaymentModePojo> paymentmodes = mdSetting.getPaymentmodes();
			if(paymentmodes.size()!=0)
			{

				xmlString=savePaymentModes(paymentmodes,schoolid, branchid);
				settgsSB.append(xmlString);
			        }
				else {
					settgsSB.append("<paymentmodes></paymentmodes>");
					settgsSB.append("\n");
					System.out.println("Empty List of paymentmodes");
				}

			 List<SubjectType> subjecttypes = mdSetting.getSubjecttype();
			   if(subjecttypes.size()!=0)
			   {

			    xmlString=saveSubjectTypes(subjecttypes,schoolid,branchid);
			    settgsSB.append(xmlString);
			           }
			    else {
			     settgsSB.append("<subjecttypes></subjecttypes>");
			     settgsSB.append("\n");
			     System.out.println("Empty List of subjecttypes");
			    }



			List<MDCategory> categories = mdSetting.getCategories();
			if (categories.size()!=0) {
			xmlString=saveCategories(categories,schoolid,branchid);
			settgsSB.append(xmlString);
		        }
			else {
				settgsSB.append("<Categories></Categories>");
				settgsSB.append("\n");
				System.out.println("Empty List of Categories");
			}

			List<MDSubCategory> subCategories = mdSetting.getSubCategories();
			if (subCategories.size()!=0) {
			xmlString=saveSubCategories(subCategories,schoolid,branchid);
			settgsSB.append(xmlString);
			}
			else {
				settgsSB.append("<SubCategories></SubCategories>");
				settgsSB.append("\n");
				System.out.println("Empty List of Sub Categories");
			}
			List<MDCategoryType> categoryTypes = mdSetting.getCategoryTypes();
			if (categoryTypes.size()!=0) {
			xmlString=saveCategoryTypes(categoryTypes);
			settgsSB.append(xmlString);
			}
			else {
				settgsSB.append("<CategoryTypes></CategoryTypes>");
				settgsSB.append("\n");
				System.out.println("Empty List of CategoryTypes");
			}
			List<MDTagType> tagTypes = mdSetting.getTagTypes();
			if (tagTypes.size()!=0) {
			xmlString=saveTagTypes(tagTypes);
			settgsSB.append(xmlString);
			}
			else {
				settgsSB.append("<TagTypes></TagTypes>");
				settgsSB.append("\n");
				System.out.println("Empty List of TagTypes");
			}
			List<MDTemplateType> templateTypes = mdSetting.getTemplateTypes();
			if (templateTypes.size()!=0) {
			xmlString=saveTemplateTypes(templateTypes);
			settgsSB.append(xmlString);
			}
			else {
				settgsSB.append("<TemplateTypes></TemplateTypes>");
				settgsSB.append("\n");
				System.out.println("Empty List of TemplateTypes");
			}
			List<MDInfomercialType> infomercialTypes = mdSetting.getInfomercialTypes();
			if (infomercialTypes.size()!=0) {
			xmlString=saveInfomercialTypes(infomercialTypes);
			settgsSB.append(xmlString);
			}
			else {
				settgsSB.append("<InfomercialTypes></InfomercialTypes>");
				settgsSB.append("\n");
				System.out.println("Empty List of InfomercialTypes");
			}
			List<MDFileCategory> fileCategories = mdSetting.getFileCategories();
			if (fileCategories.size()!=0) {
			xmlString=saveFileCategories(fileCategories);
			settgsSB.append(xmlString);
			}
			else {
				settgsSB.append("<FileCategories></FileCategories>");
				settgsSB.append("\n");
				System.out.println("Empty List of FileCategories");
			}
			settgsSB.append("</MD_Settings>");
			settgsSB.append("\n");
			xmlString=settgsSB.toString();

		}
		catch(Exception localException)
		{
			MDTransactionWriter.exceptionlog.info(localException);
			xmlString="fail";
		}
		finally
		{

		}
		return xmlString;
	}


	// ===============================saving here==================================


	@SuppressWarnings("rawtypes")
	private String saveSubjectTypes(List<SubjectType> subjecttypes,int schoolid,int branchid) {
		  String xmlString=null;
		  Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		  Transaction stgTx=null;
		  StringBuffer catSB = new StringBuffer();
		  try {
		   stgTx=stgSession.beginTransaction();
		   catSB.append("<SubjectTypes>");
		   catSB.append("\n");
		   Iterator csIT=subjecttypes.iterator();
		   while(csIT.hasNext())
		   {
		    SubjectType mdc=(SubjectType)csIT.next();
		    mdc.setSchoolId(schoolid);
		    mdc.setBranchId(branchid);
		    Integer catId = (Integer) stgSession.save(mdc);
		    catSB.append("<SubjectType>");
		    catSB.append("\n");
		    catSB.append("<subjectTypeId>"+catId+"</subjectTypeId>");
		    catSB.append("\n");
		    catSB.append("</SubjectType>");
		    catSB.append("\n");
		    System.out.println("After Insert Last SubjectType ID:" + catId);
		   }
		   stgTx.commit();
		   catSB.append("</SubjectTypes>");
		   catSB.append("\n");

		   xmlString=catSB.toString();
		  }
		  catch(Exception localException)
		  {
		   stgTx.rollback();
		   localException.printStackTrace();
		   xmlString = "fail";
		   System.out.println("Could not Set SubjectType");
		  }
		  finally
		  {
		   stgSession.close();
		  }
		  return xmlString;
		 }

	@SuppressWarnings("rawtypes")
	private String saveAssessmentModePojo(List<AssessmentModePojo> assessmentmode,int schoolid,int branchid) {
		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer catSB = new StringBuffer();
		try {
			stgTx=stgSession.beginTransaction();
			catSB.append("<AssessmentModes>");
			catSB.append("\n");
			Iterator csIT=assessmentmode.iterator();
			while(csIT.hasNext())
			{
				AssessmentModePojo mdc=(AssessmentModePojo)csIT.next();
				mdc.setSchoolId(schoolid);
				mdc.setBranchId(branchid);
				Integer catId = (Integer) stgSession.save(mdc);
				catSB.append("<AssessmentMode>");
				catSB.append("\n");
				catSB.append("<AssessmentModeid>"+catId+"</AssessmentModeid>");
				catSB.append("\n");
				catSB.append("</AssessmentMode>");
				catSB.append("\n");
				System.out.println("After Insert Last assessmentmode ID:" + catId);
			}
			stgTx.commit();
			catSB.append("</AssessmentModes>");
			catSB.append("\n");

			xmlString=catSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Set assessmentmode");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;

	}

	@SuppressWarnings("rawtypes")
	private String saveAssessmentTypePojo(List<AssessmentTypePojo> assessmenttype,int schoolid,int branchid) {
		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer catSB = new StringBuffer();
		try {
			stgTx=stgSession.beginTransaction();
			catSB.append("<AssessmentTypes>");
			catSB.append("\n");
			Iterator csIT=assessmenttype.iterator();
			while(csIT.hasNext())
			{
				AssessmentTypePojo mdc=(AssessmentTypePojo)csIT.next();
				mdc.setSchoolId(schoolid);
				mdc.setBranchId(branchid);
				Integer catId = (Integer) stgSession.save(mdc);
				catSB.append("<AssessmentType>");
				catSB.append("\n");
				catSB.append("<AssessmentTypeid>"+catId+"</AssessmentTypeid>");
				catSB.append("\n");
				catSB.append("</AssessmentType>");
				catSB.append("\n");
				System.out.println("After Insert Last assessmenttype ID:" + catId);
			}
			stgTx.commit();
			catSB.append("</AssessmentTypes>");
			catSB.append("\n");

			xmlString=catSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Set assessmenttype");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}

	@SuppressWarnings("rawtypes")
	private String saveRoomType(List<RoomType> roomtype,int schoolid,int branchid) {
		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer catSB = new StringBuffer();
		try {
			stgTx=stgSession.beginTransaction();
			catSB.append("<RoomTypes>");
			catSB.append("\n");
			Iterator csIT=roomtype.iterator();
			while(csIT.hasNext())
			{
				RoomType mdc=(RoomType)csIT.next();
				mdc.setSchoolId(schoolid);
				mdc.setBranchId(branchid);
				Integer catId = (Integer) stgSession.save(mdc);
				catSB.append("<RoomType>");
				catSB.append("\n");
				catSB.append("<roomTypeId>"+catId+"</roomTypeId>");
				catSB.append("\n");
				catSB.append("</RoomType>");
				catSB.append("\n");
				System.out.println("After Insert Last roomTypeId:" + catId);
			}
			stgTx.commit();
			catSB.append("</RoomTypes>");
			catSB.append("\n");

			xmlString=catSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Set roomtype");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}

	           // srinu

	@SuppressWarnings("rawtypes")
		public String saveReligions(List <ReligionPojo> religions,int schoolid,int branchid){
			String xmlString=null;
			Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
			Transaction stgTx=null;
			StringBuffer catSB = new StringBuffer();
			try {
				stgTx=stgSession.beginTransaction();
					catSB.append("<Religions>");
					catSB.append("\n");
					Iterator csIT=religions.iterator();
					while(csIT.hasNext())
					{
						ReligionPojo mdc=(ReligionPojo)csIT.next();
						mdc.setSchoolId(schoolid);
						mdc.setBranchId(branchid);
						Integer catId = (Integer) stgSession.save(mdc);
						catSB.append("<Religion>");
						catSB.append("\n");
						catSB.append("<religionId>"+catId+"</religionId>");
						catSB.append("\n");
						catSB.append("</Religion>");
						catSB.append("\n");
						System.out.println("After Insert Last religion ID:" + catId);
					}

				stgTx.commit();
				catSB.append("</Religions>");
				catSB.append("\n");

				xmlString=catSB.toString();
			}
			catch(Exception localException)
			{
				stgTx.rollback();
				localException.printStackTrace();
				xmlString = "fail";
				System.out.println("Could not Set religions");
			}
			finally
			{
				stgSession.close();
			}
		 return xmlString;

		}

		@SuppressWarnings("rawtypes")
		public String saveCastes(List <CastesPojo> castes,int schoolid,int branchid){
			String xmlString=null;
			Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
			Transaction stgTx=null;
			StringBuffer catSB = new StringBuffer();
			try {
				stgTx=stgSession.beginTransaction();
					catSB.append("<Castes>");
					catSB.append("\n");
					Iterator csIT=castes.iterator();
					while(csIT.hasNext())
					{
						CastesPojo mdc=(CastesPojo)csIT.next();
						mdc.setSchoolId(schoolid);
						mdc.setBranchId(branchid);
						Integer catId = (Integer) stgSession.save(mdc);
						catSB.append("<Caste>");
						catSB.append("\n");
						catSB.append("<CasteId>"+catId+"</CasteId>");
						catSB.append("\n");
						catSB.append("</Caste>");
						catSB.append("\n");
						System.out.println("After Insert Last Caste ID:" + catId);
					}

				stgTx.commit();
				catSB.append("</Castes>");
				catSB.append("\n");

				xmlString=catSB.toString();
			}
			catch(Exception localException)
			{
				stgTx.rollback();
				localException.printStackTrace();
				xmlString = "fail";
				System.out.println("Could not Set Castes");
			}
			finally
			{
				stgSession.close();
			}
		 return xmlString;

		}


	@SuppressWarnings("rawtypes")
	public String saveJobTypes(List <JobtypePojo> jobtypes,int schoolid,int branchid){
		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer catSB = new StringBuffer();
		try {
			stgTx=stgSession.beginTransaction();
				catSB.append("<Jobtypes>");
				catSB.append("\n");
				Iterator csIT=jobtypes.iterator();
				while(csIT.hasNext())
				{
					JobtypePojo mdc=(JobtypePojo)csIT.next();
					mdc.setSchoolId(schoolid);
					mdc.setBranchId(branchid);
					Integer catId = (Integer) stgSession.save(mdc);
					catSB.append("<Jobtype>");
					catSB.append("\n");
					catSB.append("<jobTypeId>"+catId+"</jobTypeId>");
					catSB.append("\n");
					catSB.append("</Jobtype>");
					catSB.append("\n");
					System.out.println("After Insert Last jobtype ID:" + catId);
				}

			stgTx.commit();
			catSB.append("</Jobtypes>");
			catSB.append("\n");

			xmlString=catSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Set jobtypes");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;

	}

	@SuppressWarnings("rawtypes")
	public String saveJobTitles(List <JobtitlePojo> jobtitles,int schoolid,int branchid){
		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer catSB = new StringBuffer();
		try {
			stgTx=stgSession.beginTransaction();
				catSB.append("<Jobtitles>");
				catSB.append("\n");
				Iterator csIT=jobtitles.iterator();
				while(csIT.hasNext())
				{
					JobtitlePojo mdc=(JobtitlePojo)csIT.next();
					mdc.setSchoolId(schoolid);
					mdc.setBranchId(branchid);
					Integer catId = (Integer) stgSession.save(mdc);
					catSB.append("<Jobtitle>");
					catSB.append("\n");
					catSB.append("<jobTitleId>"+catId+"</jobTitleId>");
					catSB.append("\n");
					catSB.append("</Jobtitle>");
					catSB.append("\n");
					System.out.println("After Insert Last title ID:" + catId);
				}

			stgTx.commit();
			catSB.append("</Jobtitles>");
			catSB.append("\n");

			xmlString=catSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Set jobtitles");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;

	}
	@SuppressWarnings("rawtypes")
	public String saveAccoladeTypes(List <AccoladetypePojo> accoladetypes,int schoolid,int branchid){
		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer catSB = new StringBuffer();
		try {
			stgTx=stgSession.beginTransaction();
				catSB.append("<Accoladetypes>");
				catSB.append("\n");
				Iterator csIT=accoladetypes.iterator();
				while(csIT.hasNext())
				{
					AccoladetypePojo mdc=(AccoladetypePojo)csIT.next();
					mdc.setSchoolId(schoolid);
					mdc.setBranchId(branchid);
					Integer catId = (Integer) stgSession.save(mdc);
					catSB.append("<Accoladetype>");
					catSB.append("\n");
					catSB.append("<accoladeTypeId>"+catId+"</accoladeTypeId>");
					catSB.append("\n");
					catSB.append("</Accoladetype>");
					catSB.append("\n");
					System.out.println("After Insert Last accolades ID:" + catId);
				}

			stgTx.commit();
			catSB.append("</Accoladetypes>");
			catSB.append("\n");

			xmlString=catSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Set accolades");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;

	}
	@SuppressWarnings("rawtypes")
	public String saveResults(List <ResultPojo> result,int schoolid,int branchid){
		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer catSB = new StringBuffer();
		try {
			stgTx=stgSession.beginTransaction();
				catSB.append("<Results>");
				catSB.append("\n");
				Iterator csIT=result.iterator();
				while(csIT.hasNext())
				{
					ResultPojo mdc=(ResultPojo)csIT.next();
					mdc.setSchoolId(schoolid);
					mdc.setBranchId(branchid);
					Integer catId = (Integer) stgSession.save(mdc);
					catSB.append("<Result>");
					catSB.append("\n");
					catSB.append("<accoladeTypeId>"+catId+"</accoladeTypeId>");
					catSB.append("\n");
					catSB.append("</Result>");
					catSB.append("\n");
					System.out.println("After Insert Last result ID:" + catId);
				}

			stgTx.commit();
			catSB.append("</Results>");
			catSB.append("\n");

			xmlString=catSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Set result");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;

	}

	@SuppressWarnings("rawtypes")

	public String savelibCategory(List<LibCategoryPojo> libcategory,int schoolid,int branchid){

		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer catSB = new StringBuffer();
		try {
			stgTx=stgSession.beginTransaction();
				catSB.append("<libcategories>");
				catSB.append("\n");
				Iterator csIT=libcategory.iterator();
				while(csIT.hasNext())
				{
					LibCategoryPojo mdc=(LibCategoryPojo)csIT.next();
					mdc.setSchoolId(schoolid);
					mdc.setBranchId(branchid);
					Integer catId = (Integer) stgSession.save(mdc);
					catSB.append("<libcategory>");
					catSB.append("\n");
					catSB.append("<libcategoryid>"+catId+"</libcategoryid>");
					catSB.append("\n");
					catSB.append("</libcategory>");
					catSB.append("\n");
					System.out.println("After Insert Last libcategory id:" + catId);
				}

			stgTx.commit();
			catSB.append("</libcategories>");
			catSB.append("\n");

			xmlString=catSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not get libcategories");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}

	@SuppressWarnings("rawtypes")
	public String savelibsection(List <LibSectionPOJO> libsection,int schoolid,int branchid){

		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer catSB = new StringBuffer();
		try {
			stgTx=stgSession.beginTransaction();
				catSB.append("<libsections>");
				catSB.append("\n");
				Iterator csIT=libsection.iterator();
				while(csIT.hasNext())
				{
					LibSectionPOJO mdc=(LibSectionPOJO)csIT.next();
					mdc.setSchoolId(schoolid);
					mdc.setBranchId(branchid);
					Integer catId = (Integer) stgSession.save(mdc);
					catSB.append("<libsection>");
					catSB.append("\n");
					catSB.append("<libsectionid>"+catId+"</libsectionid>");
					catSB.append("\n");
					catSB.append("</libsection>");
					catSB.append("\n");
					System.out.println("After Insert Last lidsection id:" + catId);
				}

			stgTx.commit();
			catSB.append("</libsections>");
			catSB.append("\n");

			xmlString=catSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Set libsections");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}

	@SuppressWarnings("rawtypes")

	public String saveEventTypes(List <EventTypePojo> eventtype,int schoolid,int branchid){
		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer catSB = new StringBuffer();
		try {
			stgTx=stgSession.beginTransaction();
				catSB.append("<EventTypes>");
				catSB.append("\n");
				Iterator csIT=eventtype.iterator();
				while(csIT.hasNext())
				{
					EventTypePojo mdc=(EventTypePojo)csIT.next();
					mdc.setSchoolId(schoolid);
					mdc.setBranchId(branchid);
					Integer catId = (Integer) stgSession.save(mdc);
					catSB.append("<EventType>");
					catSB.append("\n");
					catSB.append("<eventTypeId>"+catId+"</eventTypeId>");
					catSB.append("\n");
					catSB.append("</EventType>");
					catSB.append("\n");
					System.out.println("After Insert Last result ID:" + catId);
				}

			stgTx.commit();
			catSB.append("</EventTypes>");
			catSB.append("\n");

			xmlString=catSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Set result");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;

	}


	@SuppressWarnings("rawtypes")
	public String saveFeeItemTypes(List <FeeItemType> feeitemtype,int schoolid,int branchid){
		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer catSB = new StringBuffer();
		try {
			stgTx=stgSession.beginTransaction();
				catSB.append("<FeeItemTypes>");
				catSB.append("\n");
				Iterator csIT=feeitemtype.iterator();
				while(csIT.hasNext())
				{
					FeeItemType mdc=(FeeItemType)csIT.next();
					mdc.setSchoolId(schoolid);
					mdc.setBranchId(branchid);
					Integer catId = (Integer) stgSession.save(mdc);
					catSB.append("<FeeItemType>");
					catSB.append("\n");
					catSB.append("<feeItemTypeId>"+catId+"</feeItemTypeId>");
					catSB.append("\n");
					catSB.append("</FeeItemType>");
					catSB.append("\n");
					System.out.println("After Insert Last result ID:" + catId);
				}

			stgTx.commit();
			catSB.append("</FeeItemTypes>");
			catSB.append("\n");

			xmlString=catSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Set result");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;

	}



	@SuppressWarnings("rawtypes")
	public String saveBookTypes(List <BookTypePOJO> booktype,int schoolid,int branchid){
		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer catSB = new StringBuffer();
		try {
			stgTx=stgSession.beginTransaction();
				catSB.append("<BookTypes>");
				catSB.append("\n");
				Iterator csIT=booktype.iterator();
				while(csIT.hasNext())
				{
					BookTypePOJO mdc=(BookTypePOJO)csIT.next();
					mdc.setSchoolId(schoolid);
					mdc.setBranchId(branchid);
					Integer catId = (Integer) stgSession.save(mdc);
					catSB.append("<BookType>");
					catSB.append("\n");
					catSB.append("<bookTypeId>"+catId+"</bookTypeId>");
					catSB.append("\n");
					catSB.append("</BookType>");
					catSB.append("\n");
					System.out.println("After Insert Last result ID:" + catId);
				}

			stgTx.commit();
			catSB.append("</BookTypes>");
			catSB.append("\n");

			xmlString=catSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Set result");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;

	}


	@SuppressWarnings("rawtypes")
	public String saveQuestionTypes(List <QuestionType> questiontypes,int schoolid,int branchid){
		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer catSB = new StringBuffer();
		try {
			stgTx=stgSession.beginTransaction();
				catSB.append("<QuestionTypes>");
				catSB.append("\n");
				Iterator csIT=questiontypes.iterator();
				while(csIT.hasNext())
				{
					QuestionType mdc=(QuestionType)csIT.next();
					mdc.setSchoolId(schoolid);
					mdc.setBranchId(branchid);
					Integer catId = (Integer) stgSession.save(mdc);
					catSB.append("<QuestionType>");
					catSB.append("\n");
					catSB.append("<questionTypeId>"+catId+"</questionTypeId>");
					catSB.append("\n");
					catSB.append("</QuestionType>");
					catSB.append("\n");
					System.out.println("After Insert Last result ID:" + catId);
				}

			stgTx.commit();
			catSB.append("</QuestionTypes>");
			catSB.append("\n");

			xmlString=catSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Set result");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;

	}

	@SuppressWarnings("rawtypes")
	public String savePaymentModes(List <PaymentModePojo> paymentmodes,int schoolid,int branchid){
		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer catSB = new StringBuffer();
		try {
			stgTx=stgSession.beginTransaction();
				catSB.append("<PaymentModes>");
				catSB.append("\n");
				Iterator csIT=paymentmodes.iterator();
				while(csIT.hasNext())
				{
					PaymentModePojo mdc=(PaymentModePojo)csIT.next();
				    mdc.setBranchId(branchid);
				    mdc.setSchoolId(schoolid);
					Integer catId = (Integer) stgSession.save(mdc);
					catSB.append("<PaymentMode>");
					catSB.append("\n");
					catSB.append("<paymentModeId>"+catId+"</paymentModeId>");
					catSB.append("\n");
					catSB.append("</PaymentMode>");
					catSB.append("\n");
					System.out.println("After Insert Last result ID:" + catId);
				}

			stgTx.commit();
			catSB.append("</PaymentModes>");
			catSB.append("\n");

			xmlString=catSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Set result");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;

	}

	@SuppressWarnings("rawtypes")

	public String saveCategories(List <MDCategory> mdCategory,int schoolid,int branchid){

		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer catSB = new StringBuffer();
		try {
			stgTx=stgSession.beginTransaction();
				catSB.append("<Categories>");
				catSB.append("\n");
				Iterator csIT=mdCategory.iterator();
				while(csIT.hasNext())
				{
					MDCategory mdc=(MDCategory)csIT.next();
					mdc.setSchoolId(schoolid);
					mdc.setBranchId(branchid);
					Integer catId = (Integer) stgSession.save(mdc);
					catSB.append("<Category>");
					catSB.append("\n");
					catSB.append("<categoryId>"+catId+"</categoryId>");
					catSB.append("\n");
					catSB.append("</Category>");
					catSB.append("\n");
					System.out.println("After Insert Last Category ID:" + catId);
				}

			stgTx.commit();
			catSB.append("</Categories>");
			catSB.append("\n");

			xmlString=catSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Set Categories");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}

	@SuppressWarnings("rawtypes")
	public String saveSubCategories(List <MDSubCategory> mdSubCategory,int schoolid,int branchid){

		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer scatSB = new StringBuffer();

		try {
			stgTx=stgSession.beginTransaction();
				scatSB.append("<SubCategories>");
				scatSB.append("\n");
				Iterator csIT=mdSubCategory.iterator();
				while(csIT.hasNext())
				{
					MDSubCategory mdsc=(MDSubCategory)csIT.next();
					mdsc.setSchoolId(schoolid);
					mdsc.setBranchId(branchid);
					Integer scatId = (Integer) stgSession.save(mdsc);
					scatSB.append("<SubCategory>");
					scatSB.append("\n");
					scatSB.append("<subCategoryId>"+scatId+"</subCategoryId>");
					scatSB.append("\n");
					scatSB.append("</SubCategory>");
					scatSB.append("\n");
					System.out.println("After Insert Last Sub Category ID:" + scatId);
				}

			stgTx.commit();
			scatSB.append("</SubCategories>");
			scatSB.append("\n");
			xmlString=scatSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Set Sub Categories");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}

	@SuppressWarnings("rawtypes")
	public String saveCategoryTypes(List <MDCategoryType> mdCategoryType){

		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer cattSB = new StringBuffer();

		try {
			stgTx=stgSession.beginTransaction();
				cattSB.append("<CategoryTypes>");
				cattSB.append("\n");
				Iterator csIT=mdCategoryType.iterator();
				while(csIT.hasNext())
				{
					MDCategoryType mdct=(MDCategoryType)csIT.next();
					Integer cattId = (Integer) stgSession.save(mdct);
					cattSB.append("<CategoryType>");
					cattSB.append("\n");
					cattSB.append("<categoryTypeId>"+cattId+"</categoryTypeId>");
					cattSB.append("\n");
					cattSB.append("</CategoryType>");
					cattSB.append("\n");
					System.out.println("After Insert Last CategoryType ID:" + cattId);
				}

			stgTx.commit();
			cattSB.append("</CategoryTypes>");
			cattSB.append("\n");
			xmlString=cattSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Set Category Types");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}

	@SuppressWarnings("rawtypes")
	public String saveTagTypes(List <MDTagType> mdTagType){

		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer tagtSB = new StringBuffer();

		try {
			stgTx=stgSession.beginTransaction();
				tagtSB.append("<TagTypes>");
				tagtSB.append("\n");
				Iterator csIT=mdTagType.iterator();
				while(csIT.hasNext())
				{
					MDTagType mdtt=(MDTagType)csIT.next();
					Integer tagtId = (Integer) stgSession.save(mdtt);
					tagtSB.append("<TagType>");
					tagtSB.append("\n");
					tagtSB.append("<tagTypeId>"+tagtId+"</tagTypeId>");
					tagtSB.append("\n");
					tagtSB.append("</TagType>");
					tagtSB.append("\n");
					System.out.println("After Insert Last TagType ID:" + tagtId);
				}

			stgTx.commit();
			tagtSB.append("</TagTypes>");
			tagtSB.append("\n");
			xmlString=tagtSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Set Tag Types");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}

	@SuppressWarnings("rawtypes")
	public String saveTemplateTypes(List <MDTemplateType> mdTemplateType){

		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer templatetSB = new StringBuffer();

		try {
			stgTx=stgSession.beginTransaction();
				templatetSB.append("<TemplateTypes>");
				templatetSB.append("\n");
				Iterator csIT=mdTemplateType.iterator();
				while(csIT.hasNext())
				{
					MDTemplateType mdtt=(MDTemplateType)csIT.next();
					Integer templatetId = (Integer) stgSession.save(mdtt);
					templatetSB.append("<TemplateType>");
					templatetSB.append("\n");
					templatetSB.append("<templateTypeId>"+templatetId+"</templateTypeId>");
					templatetSB.append("\n");
					templatetSB.append("</TemplateType>");
					templatetSB.append("\n");
					System.out.println("After Insert Last TemplateType ID:" + templatetId);
				}

			stgTx.commit();
			templatetSB.append("</TemplateTypes>");
			templatetSB.append("\n");
			xmlString=templatetSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Set Template Types");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}

	@SuppressWarnings("rawtypes")
	public String saveInfomercialTypes(List <MDInfomercialType> mdInfomercialType){

		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer infomercialtSB = new StringBuffer();

		try {
			stgTx=stgSession.beginTransaction();
				infomercialtSB.append("<InfomercialTypes>");
				infomercialtSB.append("\n");
				Iterator csIT=mdInfomercialType.iterator();
				while(csIT.hasNext())
				{
					MDInfomercialType mdtt=(MDInfomercialType)csIT.next();
					Integer infomercialtId = (Integer) stgSession.save(mdtt);
					infomercialtSB.append("<InfomercialType>");
					infomercialtSB.append("\n");
					infomercialtSB.append("<infomercialTypeId>"+infomercialtId+"</infomercialTypeId>");
					infomercialtSB.append("\n");
					infomercialtSB.append("</InfomercialType>");
					infomercialtSB.append("\n");
					System.out.println("After Insert Last InfomercialType ID:" + infomercialtId);
				}

			stgTx.commit();
			infomercialtSB.append("</InfomercialTypes>");
			infomercialtSB.append("\n");
			xmlString=infomercialtSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Set Infomercial Types");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}

	@SuppressWarnings("rawtypes")
	public String saveFileCategories(List <MDFileCategory> mdFileCategory){

		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer fcatSB = new StringBuffer();
		try {
			stgTx=stgSession.beginTransaction();
				fcatSB.append("<FileCategories>");
				fcatSB.append("\n");
				Iterator csIT=mdFileCategory.iterator();
				while(csIT.hasNext())
				{
					MDFileCategory mdfc=(MDFileCategory)csIT.next();
					Integer fcatId = (Integer) stgSession.save(mdfc);
					fcatSB.append("<FileCategory>");
					fcatSB.append("\n");
					fcatSB.append("<fileCategoryId>"+fcatId+"</fileCategoryId>");
					fcatSB.append("\n");
					fcatSB.append("</fileCategory>");
					fcatSB.append("\n");
					System.out.println("After Insert Last FileCategory ID:" + fcatId);
				}

			stgTx.commit();
			fcatSB.append("</FileCategories>");
			fcatSB.append("\n");

			xmlString=fcatSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Set FileCategories");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}

	//====================UPDATE=======================================================

	public String updateSettings(MDSetting mdSetting,int schoolid,int branchid) {

		String xmlString=null;
		StringBuffer settgsSB = new StringBuffer();
		try
		{
			List<AssessmentModePojo> assessmentmode = mdSetting.getAssessmentmode();
			if(assessmentmode.size()!=0)
			{
				xmlString=updateAssessmentMode(assessmentmode,schoolid, branchid);
				settgsSB.append(xmlString);
		    }
				else {
					settgsSB.append("<Assessmentmode></Assessmentmode>");
					settgsSB.append("\n");
					System.out.println("Empty List of Assessmentmode");
				}

			List<AssessmentTypePojo> assessmenttype = mdSetting.getAssessmenttype();
			if(assessmenttype.size()!=0)
			{
				xmlString=updateAssessmentType(assessmenttype,schoolid, branchid);
				settgsSB.append(xmlString);
		    }
				else {
					settgsSB.append("<Assessmenttype></Assessmenttype>");
					settgsSB.append("\n");
					System.out.println("Empty List of Assessmenttype");
				}


			List<RoomType> roomtype = mdSetting.getRoomtype();
			if(roomtype.size()!=0)
			{
				xmlString=updateRoomType(roomtype,schoolid, branchid);
				settgsSB.append(xmlString);
		    }
				else {
					settgsSB.append("<Roomtype></Roomtype>");
					settgsSB.append("\n");
					System.out.println("Empty List of Roomtype");
				}

			// srinu

				List<CastesPojo> castes = mdSetting.getCastes();
						if(castes.size()!=0)
						{
							xmlString=updateCastes(castes,schoolid, branchid);
							settgsSB.append(xmlString);
					    }
							else {
								settgsSB.append("<castes></castes>");
								settgsSB.append("\n");
								System.out.println("Empty List of castes");
							}

						List<ReligionPojo> religions = mdSetting.getReligions();
						if(religions.size()!=0)
						{
							xmlString=updateReligions(religions,schoolid, branchid);
							settgsSB.append(xmlString);
					    }
							else {
								settgsSB.append("<religions></religions>");
								settgsSB.append("\n");
								System.out.println("Empty List of religions");
							}




			List<JobtypePojo> jobtypes = mdSetting.getJobtypes();
			if(jobtypes.size()!=0)
			{
				xmlString=updateJobTypes(jobtypes,schoolid, branchid);
				settgsSB.append(xmlString);
		    }
				else {
					settgsSB.append("<Jobtypes></Jobtypes>");
					settgsSB.append("\n");
					System.out.println("Empty List of Jobtypes");
				}

			List<JobtitlePojo> jobtitles = mdSetting.getJobtitles();
			if(jobtitles.size()!=0)
			{

				xmlString=updateJobTitles(jobtitles,schoolid, branchid);
				settgsSB.append(xmlString);
			        }
				else {
					settgsSB.append("<Jobtitles></Jobtitles>");
					settgsSB.append("\n");
					System.out.println("Empty List of Jobtitles");
				}

			List<AccoladetypePojo> accoladetypes = mdSetting.getAccolades();
			if(accoladetypes.size()!=0)
			{

				xmlString=updateAccoladeTypes(accoladetypes,schoolid, branchid);
				settgsSB.append(xmlString);
			        }
				else {
					settgsSB.append("<Accoladetypes></Accoladetypes>");
					settgsSB.append("\n");
					System.out.println("Empty List of Accoladetypes");
				}
			List<ResultPojo> results = mdSetting.getResults();
			if(results.size()!=0)
			{

				xmlString=updateResults(results,schoolid, branchid);
				settgsSB.append(xmlString);
			        }
				else {
					settgsSB.append("<Results></Results>");
					settgsSB.append("\n");
					System.out.println("Empty List of Results");
				}


			 List<SubjectType> subjecttypes = mdSetting.getSubjecttype();
			   if(subjecttypes.size()!=0)
			   {

			    xmlString=updateSubjectTypes(subjecttypes,schoolid,branchid);
			    settgsSB.append(xmlString);
			           }
			    else {
			     settgsSB.append("<SubjectTypes></SubjectTypes>");
			     settgsSB.append("\n");
			     System.out.println("Empty List of SubjectTypes");
			    }

			//fee....
			List<EventTypePojo> eventtypes = mdSetting.getEventtypes();
			if(eventtypes.size()!=0)
			{

				xmlString=updateEventtypes(eventtypes,schoolid, branchid);
				settgsSB.append(xmlString);
			        }
				else {
					settgsSB.append("<EventTypes></EventTypes>");
					settgsSB.append("\n");
					System.out.println("Empty List of EventTypes");
				}

			List<FeeItemType> feeitemtypes = mdSetting.getFeeitemtypes();
			if(feeitemtypes.size()!=0)
			{

				xmlString=updateFeeItemTypes(feeitemtypes,schoolid, branchid);
				settgsSB.append(xmlString);
			        }
				else {
					settgsSB.append("<FeeiItemTypes></FeeiItemTypes>");
					settgsSB.append("\n");
					System.out.println("Empty List of FeeiItemTypes");
				}

			List<BookTypePOJO> booktypes = mdSetting.getBooktypes();
			if(booktypes.size()!=0)
			{

				xmlString=updateBookTypes(booktypes,schoolid, branchid);
				settgsSB.append(xmlString);
			        }
				else {
					settgsSB.append("<BookTypes></BookTypes>");
					settgsSB.append("\n");
					System.out.println("Empty List of BookTypes");
				}

			List<QuestionType> questiontypes = mdSetting.getQuestiontypes();
			if(questiontypes.size()!=0)
			{

				xmlString=updateQuestionTypes(questiontypes,schoolid, branchid);
				settgsSB.append(xmlString);
			        }
				else {
					settgsSB.append("<QuestionTypes></QuestionTypes>");
					settgsSB.append("\n");
					System.out.println("Empty List of QuestionTypes");
				}

			List<PaymentModePojo> paymentmodes = mdSetting.getPaymentmodes();
			if(paymentmodes.size()!=0)
			{

				xmlString=updatePaymentModes(paymentmodes, schoolid, branchid);
				settgsSB.append(xmlString);
			        }
				else {
					settgsSB.append("<PaymentModes></PaymentModes>");
					settgsSB.append("\n");
					System.out.println("Empty List of PaymentModes");
				}

			List<MDCategory> categories = mdSetting.getCategories();
			if (categories.size()!=0) {
			xmlString=updateCategories(categories,schoolid,branchid);
			settgsSB.append(xmlString);
			settgsSB.append("\n");
			}
			else {
				System.out.println("Empty List of Categories");
			}


			List<LibSectionPOJO> libsection = mdSetting.getSection();
			if (libsection.size()!=0) {
			xmlString=updateLibSection(libsection,schoolid, branchid);
			settgsSB.append(xmlString);
			settgsSB.append("\n");
			}
			else {
				System.out.println("Empty List of libsection");
			}


			List<LibCategoryPojo> libcategory = mdSetting.getLibcategory();
			if (libcategory.size()!=0) {
			xmlString=updateLibCategory(libcategory,schoolid, branchid);
			settgsSB.append(xmlString);
			settgsSB.append("\n");
			}
			else {
			}

			List<MDSubCategory> subCategories = mdSetting.getSubCategories();
			if (subCategories.size()!=0) {
			xmlString=updateSubCategories(subCategories,schoolid,branchid);
			settgsSB.append(xmlString);
			settgsSB.append("\n");
			}
			else {
				System.out.println("Empty List of Sub Categories");
			}
			List<MDCategoryType> categoryTypes = mdSetting.getCategoryTypes();
			if (categoryTypes.size()!=0) {
			xmlString=updateCategoryTypes(categoryTypes);
			settgsSB.append(xmlString);
			settgsSB.append("\n");
			}
			else {
				System.out.println("Empty List of CategoryTypes");
			}
			List<MDTagType> tagTypes = mdSetting.getTagTypes();
			if (tagTypes.size()!=0) {
			xmlString=updateTagTypes(tagTypes);
			settgsSB.append(xmlString);
			settgsSB.append("\n");
			}
			else {
				System.out.println("Empty List of TagTypes");
			}
			List<MDTemplateType> templateTypes = mdSetting.getTemplateTypes();
			if (templateTypes.size()!=0) {
			xmlString=updateTemplateTypes(templateTypes);
			settgsSB.append(xmlString);
			settgsSB.append("\n");
			}
			else {
				System.out.println("Empty List of TemplateTypes");
			}
			List<MDInfomercialType> infomercialTypes = mdSetting.getInfomercialTypes();
			if (infomercialTypes.size()!=0) {
			xmlString=updateInfomercialTypes(infomercialTypes);
			settgsSB.append(xmlString);
			settgsSB.append("\n");
			}
			else {
				System.out.println("Empty List of InfomercialTypes");
			}
			List<MDFileCategory> fileCategories = mdSetting.getFileCategories();
			if (fileCategories.size()!=0) {
			xmlString=updateFileCategories(fileCategories);
			settgsSB.append(xmlString);
			settgsSB.append("\n");
			}
			else {
				System.out.println("Empty List of FileCategories");
			}

		xmlString=settgsSB.toString();
		}
		catch(Exception localException)
		{
			MDTransactionWriter.exceptionlog.info(localException);
			xmlString="fail";
		}
		finally
		{

		}
		return xmlString;
	}


	@SuppressWarnings("rawtypes")
	private String updateSubjectTypes(List<SubjectType> subjecttypes,int schoolId,int branchId) {
		  String xmlString=null;
		  Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		  Transaction stgTx=null;
		  try {
		   stgTx=stgSession.beginTransaction();
		    Iterator csIT=subjecttypes.iterator();
		    while(csIT.hasNext())
		    {
		     SubjectType mdc=(SubjectType)csIT.next();
		     mdc.setSchoolId(schoolId);
		     mdc.setBranchId(branchId);

		     SubjectType mdclpojo = (SubjectType) stgSession.get(SubjectType.class,mdc.getSubjectTypeId());

		         if(branchId==mdclpojo.getBranchId()&&schoolId==mdclpojo.getSchoolId())

		         stgSession.evict(mdclpojo);
		     stgSession.merge(mdc);
		    }

		   stgTx.commit();
		   xmlString = "Updated SubjectType";
		  }
		  catch(Exception localException)
		  {
		   stgTx.rollback();
		   localException.printStackTrace();
		   xmlString = "fail";
		   System.out.println("Could not update SubjectType");
		  }
		  finally
		  {
		   stgSession.close();
		  }
		  return xmlString;
		 }


	@SuppressWarnings("rawtypes")
	private String updateRoomType(List<RoomType> roomtype,int schoolid,int branchid) {
		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		try {
			stgTx=stgSession.beginTransaction();
				Iterator csIT=roomtype.iterator();
				while(csIT.hasNext())
				{
					RoomType mdc=(RoomType)csIT.next();
					mdc.setSchoolId(schoolid);
					mdc.setBranchId(branchid);

					RoomType mdclpojo = (RoomType) stgSession.get(RoomType.class,mdc.getRoomTypeId());

				     if(branchid==mdclpojo.getBranchId()&&schoolid==mdclpojo.getSchoolId())

				     stgSession.evict(mdclpojo);
					stgSession.merge(mdc);
				}

			stgTx.commit();
			xmlString = "Updated Roomtype";
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not update Roomtype");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}

	@SuppressWarnings("rawtypes")
	private String updateAssessmentType(List<AssessmentTypePojo> assessmenttype,int schoolid,int branchid) {
		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		try {
			stgTx=stgSession.beginTransaction();
				Iterator csIT=assessmenttype.iterator();
				while(csIT.hasNext())
				{
					AssessmentTypePojo mdc=(AssessmentTypePojo)csIT.next();
					mdc.setSchoolId(schoolid);
					mdc.setBranchId(branchid);

					AssessmentTypePojo mdclpojo = (AssessmentTypePojo) stgSession.get(AssessmentTypePojo.class,mdc.getAssessmentTypeId());

				     if(branchid==mdclpojo.getBranchId()&&schoolid==mdclpojo.getSchoolId())

				     stgSession.evict(mdclpojo);
					stgSession.merge(mdc);
				}

			stgTx.commit();
			xmlString = "Updated Assessmenttype";
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not update Assessmenttype");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}

	@SuppressWarnings("rawtypes")
	private String updateAssessmentMode(List<AssessmentModePojo> assessmentmode,int schoolid,int branchid) {
		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		try {
			stgTx=stgSession.beginTransaction();
				Iterator csIT=assessmentmode.iterator();
				while(csIT.hasNext())
				{
					AssessmentModePojo mdc=(AssessmentModePojo)csIT.next();
					mdc.setSchoolId(schoolid);
					mdc.setBranchId(branchid);

					AssessmentModePojo mdclpojo = (AssessmentModePojo) stgSession.get(AssessmentModePojo.class,mdc.getAssessmentModeId());

				     if(branchid==mdclpojo.getBranchId()&&schoolid==mdclpojo.getSchoolId())

				     stgSession.evict(mdclpojo);

					stgSession.merge(mdc);
				}

			stgTx.commit();
			xmlString = "Updated Assessmentmode";
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not update Assessmentmode");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}


@SuppressWarnings("rawtypes")
	public String updateCastes(List <CastesPojo> castes,int schoolid,int branchid){

		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		try {
			stgTx=stgSession.beginTransaction();
				Iterator csIT=castes.iterator();
				while(csIT.hasNext())
				{
					CastesPojo mdc=(CastesPojo)csIT.next();

					mdc.setSchoolId(schoolid);
					mdc.setBranchId(branchid);

					CastesPojo mdclpojo = (CastesPojo) stgSession.get(CastesPojo.class,mdc.getCastId());

					if(branchid==mdclpojo.getBranchId()&&schoolid==mdclpojo.getSchoolId())

					stgSession.evict(mdclpojo);
					stgSession.merge(mdc);
				}

			stgTx.commit();
			xmlString = "Updated Castes";
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not update Castes");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}
	@SuppressWarnings("rawtypes")
	public String updateReligions(List <ReligionPojo> religions,int schoolid,int branchid){

		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		try {
			stgTx=stgSession.beginTransaction();
				Iterator csIT=religions.iterator();
				while(csIT.hasNext())
				{
					ReligionPojo mdc=(ReligionPojo)csIT.next();

					mdc.setSchoolId(schoolid);
					mdc.setBranchId(branchid);

					ReligionPojo mdclpojo = (ReligionPojo) stgSession.get(ReligionPojo.class,mdc.getReligionId());

					if(branchid==mdclpojo.getBranchId()&&schoolid==mdclpojo.getSchoolId())

					stgSession.evict(mdclpojo);
					stgSession.merge(mdc);
				}

			stgTx.commit();
			xmlString = "Updated religions";
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not update religions");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}





	@SuppressWarnings("rawtypes")
	public String updateJobTitles(List <JobtitlePojo> jobtitles,int schoolid,int branchid){

		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		try {
			stgTx=stgSession.beginTransaction();
				Iterator csIT=jobtitles.iterator();
				while(csIT.hasNext())
				{
					JobtitlePojo mdc=(JobtitlePojo)csIT.next();

					mdc.setSchoolId(schoolid);
					mdc.setBranchId(branchid);

					JobtitlePojo mdclpojo = (JobtitlePojo) stgSession.get(JobtitlePojo.class,mdc.getJobTitleId());

					if(branchid==mdclpojo.getBranchId()&&schoolid==mdclpojo.getSchoolId())

					stgSession.evict(mdclpojo);
					stgSession.merge(mdc);
				}

			stgTx.commit();
			xmlString = "Updated Jobtitles";
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not update Jobtitle");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}

	@SuppressWarnings("rawtypes")
	public String updateAccoladeTypes(List <AccoladetypePojo> accoladetypes,int schoolid,int branchid){

		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		try {
			stgTx=stgSession.beginTransaction();
				Iterator csIT=accoladetypes.iterator();
				while(csIT.hasNext())
				{
					AccoladetypePojo mdc=(AccoladetypePojo)csIT.next();

					mdc.setSchoolId(schoolid);
					mdc.setBranchId(branchid);

					AccoladetypePojo mdclpojo = (AccoladetypePojo) stgSession.get(AccoladetypePojo.class,mdc.getAccoladeTypeId());

					if(branchid==mdclpojo.getBranchId()&&schoolid==mdclpojo.getSchoolId())

					stgSession.evict(mdclpojo);
					stgSession.merge(mdc);
				}

			stgTx.commit();
			xmlString = "Updated AccoladeTypes";
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not update AccoladeTypes");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}


	@SuppressWarnings("rawtypes")
	public String updateJobTypes(List <JobtypePojo> jobtypes,int schoolid,int branchid){

		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		try {
			stgTx=stgSession.beginTransaction();
				Iterator csIT=jobtypes.iterator();
				while(csIT.hasNext())
				{
					JobtypePojo mdc=(JobtypePojo)csIT.next();

					mdc.setSchoolId(schoolid);
					mdc.setBranchId(branchid);

					JobtypePojo mdclpojo = (JobtypePojo) stgSession.get(JobtypePojo.class,mdc.getJobTypeId());

					if(branchid==mdclpojo.getBranchId()&&schoolid==mdclpojo.getSchoolId())

					stgSession.evict(mdclpojo);

					stgSession.merge(mdc);
				}

			stgTx.commit();
			xmlString = "Updated JobTypes";
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not update JobTypes");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}

	@SuppressWarnings("rawtypes")
	public String updateResults(List <ResultPojo> result,int schoolid,int branchid){

		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		try {
			stgTx=stgSession.beginTransaction();
				Iterator csIT=result.iterator();
				while(csIT.hasNext())
				{
					ResultPojo mdc=(ResultPojo)csIT.next();
					mdc.setSchoolId(schoolid);
					mdc.setBranchId(branchid);
					ResultPojo mdclpojo = (ResultPojo) stgSession.get(ResultPojo.class,mdc.getResultId());
					if(branchid==mdclpojo.getBranchId()&&schoolid==mdclpojo.getSchoolId())

					stgSession.evict(mdclpojo);
					stgSession.merge(mdc);
				}

			stgTx.commit();
			xmlString = "Updated Results";
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not update Results");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}




	@SuppressWarnings("rawtypes")
	public String updateLibSection(List <LibSectionPOJO> libSection,int schoolid,int branchid){

		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		try {
			stgTx=stgSession.beginTransaction();
				Iterator csIT=libSection.iterator();
				while(csIT.hasNext())
				{
					LibSectionPOJO mdc=(LibSectionPOJO)csIT.next();
					mdc.setSchoolId(schoolid);
					mdc.setBranchId(branchid);
					LibSectionPOJO mdclpojo = (LibSectionPOJO) stgSession.get(LibSectionPOJO.class,mdc.getLibSectionId());
					if(branchid==mdclpojo.getBranchId()&&schoolid==mdclpojo.getSchoolId())

					stgSession.evict(mdclpojo);
					stgSession.merge(mdc);
				}

			stgTx.commit();
			xmlString = "Updated libsections";
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not update libsection");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}

	//fee update.....
	@SuppressWarnings("rawtypes")
	public String updateEventtypes(List <EventTypePojo> result,int schoolid,int branchid){

		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		try {
			stgTx=stgSession.beginTransaction();
				Iterator csIT=result.iterator();
				while(csIT.hasNext())
				{
					EventTypePojo mdc=(EventTypePojo)csIT.next();
					mdc.setSchoolId(schoolid);
					mdc.setBranchId(branchid);
					EventTypePojo mdclpojo = (EventTypePojo) stgSession.get(EventTypePojo.class,mdc.getEventTypeId());
					if(branchid==mdclpojo.getBranchId()&&schoolid==mdclpojo.getSchoolId())

					stgSession.evict(mdclpojo);
					stgSession.merge(mdc);
				}

			stgTx.commit();
			xmlString = "Updated EventTypes";
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not update Results");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}

	@SuppressWarnings("rawtypes")
	public String updateLibCategory(List <LibCategoryPojo> libCategory,int schoolid,int branchid){

		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		try {
			stgTx=stgSession.beginTransaction();
				Iterator csIT=libCategory.iterator();
				while(csIT.hasNext())
				{
					LibCategoryPojo mdc=(LibCategoryPojo)csIT.next();
					mdc.setSchoolId(schoolid);
					mdc.setBranchId(branchid);
					LibCategoryPojo mdclpojo = (LibCategoryPojo) stgSession.get(LibCategoryPojo.class,mdc.getLibCategoryId());
					if(branchid==mdclpojo.getBranchId()&&schoolid==mdclpojo.getSchoolId())

					stgSession.evict(mdclpojo);
					stgSession.merge(mdc);
				}

			stgTx.commit();
			xmlString = "Updated LibCategories";
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not update Lib Categories");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}

	@SuppressWarnings("rawtypes")
	public String updateFeeItemTypes(List <FeeItemType> result,int schoolid,int branchid){

		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		try {
			stgTx=stgSession.beginTransaction();
				Iterator csIT=result.iterator();
				while(csIT.hasNext())
				{
					FeeItemType mdc=(FeeItemType)csIT.next();
					mdc.setSchoolId(schoolid);
					mdc.setBranchId(branchid);
					FeeItemType mdclpojo = (FeeItemType) stgSession.get(FeeItemType.class,mdc.getFeeItemTypeId());
					if(branchid==mdclpojo.getBranchId()&&schoolid==mdclpojo.getSchoolId())

					stgSession.evict(mdclpojo);
					stgSession.merge(mdc);
				}

			stgTx.commit();
			xmlString = "Updated FeeItemTypes";
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not update Results");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}


	@SuppressWarnings("rawtypes")
	public String updateBookTypes(List <BookTypePOJO> result,int schoolid,int branchid){

		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		try {
			stgTx=stgSession.beginTransaction();
				Iterator csIT=result.iterator();
				while(csIT.hasNext())
				{
					BookTypePOJO mdc=(BookTypePOJO)csIT.next();
					mdc.setSchoolId(schoolid);
					mdc.setBranchId(branchid);
					BookTypePOJO mdclpojo = (BookTypePOJO) stgSession.get(BookTypePOJO.class,mdc.getBookTypeId());
					if(branchid==mdclpojo.getBranchId()&&schoolid==mdclpojo.getSchoolId())

					stgSession.evict(mdclpojo);
					stgSession.merge(mdc);
				}

			stgTx.commit();
			xmlString = "Updated BookTypes";
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not update Results");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}

	@SuppressWarnings("rawtypes")
	public String updateQuestionTypes(List <QuestionType> result,int schoolid,int branchid){

		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		try {
			stgTx=stgSession.beginTransaction();
				Iterator csIT=result.iterator();
				while(csIT.hasNext())
				{
					QuestionType mdc=(QuestionType)csIT.next();
					mdc.setSchoolId(schoolid);
					mdc.setBranchId(branchid);

					QuestionType mdclpojo = (QuestionType) stgSession.get(QuestionType.class,mdc.getQuestionTypeId());

				     if(branchid==mdclpojo.getBranchId()&&schoolid==mdclpojo.getSchoolId())

				     stgSession.evict(mdclpojo);
					stgSession.merge(mdc);
				}

			stgTx.commit();
			xmlString = "Updated QuestionTypes";
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not update Results");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}

	@SuppressWarnings("rawtypes")
	public String updatePaymentModes(List <PaymentModePojo> result,int schoolid,int branchid){

		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		try {
			stgTx=stgSession.beginTransaction();
				Iterator csIT=result.iterator();
				while(csIT.hasNext())
				{
					PaymentModePojo mdc=(PaymentModePojo)csIT.next();
					mdc.setSchoolId(schoolid);
					mdc.setBranchId(branchid);
					PaymentModePojo mdclpojo = (PaymentModePojo) stgSession.get(PaymentModePojo.class,mdc.getPaymentModeId());
					if(branchid==mdclpojo.getBranchId()&&schoolid==mdclpojo.getSchoolId())

					stgSession.evict(mdclpojo);
					stgSession.merge(mdc);
				}

			stgTx.commit();
			xmlString = "Updated PaymentModes";
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not update Results");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}


	@SuppressWarnings("rawtypes")
	public String updateCategories(List <MDCategory> mdCategory,int schoolid,int branchid){

		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		try {
			stgTx=stgSession.beginTransaction();
				Iterator csIT=mdCategory.iterator();
				while(csIT.hasNext())
				{
					MDCategory mdc=(MDCategory)csIT.next();
					mdc.setSchoolId(schoolid);
					mdc.setBranchId(branchid);

					MDCategory mdclpojo = (MDCategory) stgSession.get(MDCategory.class,mdc.getCategoryId());

					if(branchid==mdclpojo.getBranchId()&&schoolid==mdclpojo.getSchoolId())

					stgSession.evict(mdclpojo);
					stgSession.merge(mdc);
				}

			stgTx.commit();
			xmlString = "Updated Categories";
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not update Categories");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}

	@SuppressWarnings("rawtypes")
	public String updateSubCategories(List <MDSubCategory> mdSubCategory,int schoolid,int branchid){

		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;

		try {
			stgTx=stgSession.beginTransaction();

				Iterator csIT=mdSubCategory.iterator();
				while(csIT.hasNext())
				{
					MDSubCategory mdsc=(MDSubCategory)csIT.next();
					mdsc.setSchoolId(schoolid);
					mdsc.setBranchId(branchid);

					MDSubCategory mdclpojo = (MDSubCategory) stgSession.get(MDSubCategory.class,mdsc.getSubCategoryId());

					if(branchid==mdclpojo.getBranchId()&&schoolid==mdclpojo.getSchoolId())

					stgSession.evict(mdclpojo);
					stgSession.merge(mdsc);
				}

			stgTx.commit();
			xmlString = "Updated Sub Categories";
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Set Sub Categories");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}

	@SuppressWarnings("rawtypes")
	public String updateCategoryTypes(List <MDCategoryType> mdCategoryType){

		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;

		try {
			stgTx=stgSession.beginTransaction();
				Iterator csIT=mdCategoryType.iterator();
				while(csIT.hasNext())
				{
					MDCategoryType mdct=(MDCategoryType)csIT.next();
					stgSession.merge(mdct);
				}

			stgTx.commit();
			xmlString = "Updated Category Types";
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Set Category Types");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}

	@SuppressWarnings("rawtypes")
	public String updateTagTypes(List <MDTagType> mdTagType){

		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;

		try {
			stgTx=stgSession.beginTransaction();
				Iterator csIT=mdTagType.iterator();
				while(csIT.hasNext())
				{
					MDTagType mdtt=(MDTagType)csIT.next();
					stgSession.merge(mdtt);
				}

			stgTx.commit();
			xmlString = "Updated Tag Types";
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Set Tag Types");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}

	@SuppressWarnings("rawtypes")
	public String updateTemplateTypes(List <MDTemplateType> mdTemplateType){

		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;

		try {
			stgTx=stgSession.beginTransaction();
				Iterator csIT=mdTemplateType.iterator();
				while(csIT.hasNext())
				{
					MDTemplateType mdtt=(MDTemplateType)csIT.next();
					stgSession.merge(mdtt);
				}

			stgTx.commit();
			xmlString = "Updated Template Types";
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Set Template Types");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}

	@SuppressWarnings("rawtypes")
	public String updateInfomercialTypes(List <MDInfomercialType> mdInfomercialType){

		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;

		try {
			stgTx=stgSession.beginTransaction();
				Iterator csIT=mdInfomercialType.iterator();
				while(csIT.hasNext())
				{
					MDInfomercialType mdtt=(MDInfomercialType)csIT.next();
					stgSession.merge(mdtt);
				}

			stgTx.commit();
			xmlString = "Updated Infomercial Types";
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Set Infomercial Types");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}

	@SuppressWarnings("rawtypes")
	public String updateFileCategories(List <MDFileCategory> mdFileCategory){

		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		try {
			stgTx=stgSession.beginTransaction();
				Iterator csIT=mdFileCategory.iterator();
				while(csIT.hasNext())
				{
					MDFileCategory mdc=(MDFileCategory)csIT.next();
					stgSession.merge(mdc);
				}

			stgTx.commit();
			xmlString = "Updated FileCategories";
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not update FileCategories");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}

	//=================================GetSettings========================================

	public String getSettings(int PNO, int size, String settings, int schoolid,int branchid) {

		String xmlString=null;
		StringBuffer settgsSB = new StringBuffer();
		try
		{
			boolean category = false;
			boolean subCategory = false;
			boolean categoryType = false;
			boolean tagType = false;
			boolean templateType = false;
			boolean infomercialType = false;
			boolean fileCategory = false;

			boolean jobtype = false;
			boolean jobtitle = false;
			boolean accolade = false;
			boolean result = false;
			boolean religion = false;
			boolean caste = false;

			boolean libsection= false;
			boolean libcategory=false;
			boolean subjecttype = false;

			//fee

			boolean eventtype=false;
			boolean feeitemtype=false;
			boolean booktype=false;

			boolean questiontype=false;
			boolean paymentmode=false;

			boolean assessmenttype = false;
			boolean assessmentmode = false;
			boolean roomtype = false;


			String [] setgArr = settings.split(",");
			if (settings.trim().equalsIgnoreCase("all")) {
				category = true; subCategory = true; categoryType = true; tagType = true; templateType = true;
				infomercialType = true; fileCategory = true;caste=true;religion=true; jobtype=true;jobtitle=true;accolade=true;result=true;assessmenttype=true;assessmentmode=true;roomtype=true;
				eventtype=true;feeitemtype=true;booktype=true;questiontype=true;paymentmode=true;subjecttype=true;
				libsection=true;libcategory=true;
				}
			else {
			for (int i=0; i<setgArr.length; i++){
				if (setgArr[i].trim().equalsIgnoreCase("Category")) category = true;
				if (setgArr[i].trim().equalsIgnoreCase("SubCategory")) subCategory = true;
				if (setgArr[i].trim().equalsIgnoreCase("CategoryType")) categoryType = true;
				if (setgArr[i].trim().equalsIgnoreCase("TagType")) tagType = true;
				if (setgArr[i].trim().equalsIgnoreCase("TemplateType")) templateType = true;
				if (setgArr[i].trim().equalsIgnoreCase("InfomercialType")) infomercialType = true;
				if (setgArr[i].trim().equalsIgnoreCase("fileCategory")) fileCategory = true;

				if (setgArr[i].trim().equalsIgnoreCase("Jobtype")) jobtype = true;
				if (setgArr[i].trim().equalsIgnoreCase("Jobtitle")) jobtitle = true;
				if (setgArr[i].trim().equalsIgnoreCase("Accolade")) accolade = true;
				if (setgArr[i].trim().equalsIgnoreCase("Result")) result = true;
				if (setgArr[i].trim().equalsIgnoreCase("Caste")) caste = true;
				if (setgArr[i].trim().equalsIgnoreCase("Religion")) religion = true;


				if (setgArr[i].trim().equalsIgnoreCase("Libsection")) libsection = true;
				if (setgArr[i].trim().equalsIgnoreCase("Libcategory")) libcategory = true;


				if (setgArr[i].trim().equalsIgnoreCase("eventtype")) eventtype = true;
				if (setgArr[i].trim().equalsIgnoreCase("feeitemtype")) feeitemtype = true;
				if (setgArr[i].trim().equalsIgnoreCase("booktype")) booktype = true;

				if (setgArr[i].trim().equalsIgnoreCase("questiontype")) fileCategory = true;
				if (setgArr[i].trim().equalsIgnoreCase("paymentmode")) paymentmode = true;


				if (setgArr[i].trim().equalsIgnoreCase("assessmenttype")) assessmenttype = true;
				if (setgArr[i].trim().equalsIgnoreCase("assessmentmode")) assessmentmode = true;
				if (setgArr[i].trim().equalsIgnoreCase("roomtype")) roomtype = true;

				if (setgArr[i].trim().equalsIgnoreCase("subjecttype")) subjecttype = true;
				}
			}
			settgsSB.append("<MD_Settings>");
			settgsSB.append("\n");


			if (assessmenttype) {
				xmlString=getAssessmentType(PNO, size, null,schoolid, branchid);
				settgsSB.append(xmlString);
				}

			if (assessmentmode) {
				xmlString=getAssessmentMode(PNO, size, null,schoolid, branchid);
				settgsSB.append(xmlString);
				}

			if (roomtype) {
				xmlString=getRoomType(PNO, size, null,schoolid, branchid);
				settgsSB.append(xmlString);
				}


            if (caste) {
				xmlString=getCastes(PNO, size, null,schoolid, branchid);
				settgsSB.append(xmlString);
				}
			if (religion) {
				xmlString=getReligions(PNO, size, null,schoolid, branchid);
				settgsSB.append(xmlString);
				}


			if (jobtype) {
			xmlString=getJobtypes(PNO, size, null,schoolid, branchid);
			settgsSB.append(xmlString);
			}


			if (jobtitle) {
				xmlString=getJobtitles(PNO, size, null,schoolid, branchid);
				settgsSB.append(xmlString);
				}

			if (accolade) {
				xmlString=getaccolades(PNO, size, null,schoolid, branchid);
				settgsSB.append(xmlString);
				}


			if (result) {
				xmlString=getresults(PNO, size, null,schoolid, branchid);
				settgsSB.append(xmlString);
				}


			if (libsection) {
				xmlString=getLibSection(PNO, size, null,schoolid, branchid);
				settgsSB.append(xmlString);
				}

			if (libcategory) {
				xmlString=getLibCategories(PNO, size, null,schoolid, branchid);
				settgsSB.append(xmlString);
				}

			if (eventtype) {
				xmlString=getEventTypes(PNO, size, null,schoolid, branchid);
				settgsSB.append(xmlString);
				}


			if (feeitemtype) {
				xmlString=getFeeItemTypes(PNO, size, null,schoolid, branchid);
				settgsSB.append(xmlString);
				}

			if (booktype) {
				xmlString=getBookTypes(PNO, size, null,schoolid, branchid);
				settgsSB.append(xmlString);
				}

			if (questiontype) {
				xmlString=getQuestionTypes(PNO, size, null,schoolid, branchid);
				settgsSB.append(xmlString);
				}


			if (paymentmode) {
				xmlString=getPaymentModes(PNO, size, null,schoolid, branchid);
				settgsSB.append(xmlString);
				}

			 if (subjecttype) {
				    xmlString=getSubjectTypes(PNO, size, null,schoolid,branchid);
				    settgsSB.append(xmlString);
				    }

			if (category) {
			xmlString=getCategories(PNO, size, null,schoolid, branchid);
			settgsSB.append(xmlString);
			}

			if (subCategory) {
			xmlString=getSubCategories(PNO, size, null,schoolid, branchid);
			settgsSB.append(xmlString);
			}

			if (categoryType) {
			xmlString=getCategoryTypes(PNO, size, null);
			settgsSB.append(xmlString);
			}

			if (tagType) {
			xmlString=getTagTypes(PNO, size, null);
			settgsSB.append(xmlString);
			}


			if (templateType) {
			xmlString=getTemplateTypes(PNO, size, null);
			settgsSB.append(xmlString);
			}

			if (infomercialType) {
				xmlString=getInfomercialTypes(PNO, size, null);
				settgsSB.append(xmlString);
				}



			if (fileCategory) {
				xmlString=getFileCategories(PNO, size, null);
				settgsSB.append(xmlString);
				}

			settgsSB.append("</MD_Settings>");
			settgsSB.append("\n");
			xmlString=settgsSB.toString();

		}
		catch(Exception localException)
		{
			MDTransactionWriter.exceptionlog.info(localException);
			xmlString="fail";
		}
		finally
		{

		}
		return xmlString;
	}


	@SuppressWarnings("rawtypes")
	private String getSubjectTypes(int PNO, int size, List<SubjectType> subjecttype,int schoolid,int branchid) {
		  String xmlString=null;
		  Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		  Transaction stgTx=null;
		  StringBuffer catSB = new StringBuffer();
		  try {
		   stgTx=stgSession.beginTransaction();
		   int fset = (PNO-1)*size;
		   String gsSql ="select count(*) from gbl_sm_tbl_subject_type where SchoolId='"+schoolid+"' and BranchId='"+branchid+"';";
		   Query gsQuery=stgSession.createSQLQuery(gsSql);
		   Object noRecords= gsQuery.uniqueResult();
		   catSB.append("<subjecttypes>");
		   catSB.append("\n");
		   catSB.append("<noRecords>"+noRecords+"</noRecords>");
		   catSB.append("\n");
		   if(subjecttype==null) {
		   if (PNO > 0 & size > 0){
		   gsSql="select * from gbl_sm_tbl_subject_type where SchoolId='"+schoolid+"' and BranchId='"+branchid+"' limit "+size+" offset "+fset;}
		   else {
		    gsSql="select * from gbl_sm_tbl_subject_type where SchoolId='"+schoolid+"' and BranchId='"+branchid+"'";
		   }
		   } else {
		    StringBuffer ctIdSB = new StringBuffer();
		    Iterator gsIdIT=subjecttype.iterator();
		     while(gsIdIT.hasNext())
		     {
		      SubjectType mdct=(SubjectType)gsIdIT.next();
		      ctIdSB .append("'"+mdct.getSubjectTypeId()+"',");
		     }
		     int k=ctIdSB.lastIndexOf(",");
		     ctIdSB.deleteCharAt(k);
		     String ctIdStr = ctIdSB.toString();
		    gsSql="select * from gbl_sm_tbl_subject_type where SchoolId='"+schoolid+"' and BranchId='"+branchid+"' and SubjectTypeId in ("+ctIdStr+")";
		   }
		   gsQuery=stgSession.createSQLQuery(gsSql);
		   List gcList=gsQuery.list();
		   Iterator gsIT=gcList.iterator();
		    while(gsIT.hasNext())
		    {
		     //MDCategory mdc=(MDCategory)gsIT.next();
		     Object[] mdcArr=(Object[])gsIT.next();
		     catSB.append("<subjecttype>");
		     catSB.append("\n");
		     catSB.append("<subjectTypeId>"+(Integer) mdcArr[0]+"</subjectTypeId>");
		     catSB.append("\n");
		     catSB.append("<subjectName>"+(String) mdcArr[1]+"</subjectName>");
		     catSB.append("\n");
		     catSB.append("<description>"+(String) mdcArr[2]+"</description>");
		     catSB.append("\n");
		     catSB.append("</subjecttype>");
		     catSB.append("\n");
		    }

		   stgTx.commit();
		   catSB.append("</subjecttypes>");
		   catSB.append("\n");

		   xmlString=catSB.toString();
		  }
		  catch(Exception localException)
		  {
		   stgTx.rollback();
		   localException.printStackTrace();
		   xmlString = "fail";
		   System.out.println("Could not Get subjecttype");
		  }
		  finally
		  {
		   stgSession.close();
		  }
		  return xmlString;
		 }

	@SuppressWarnings("rawtypes")
	private String getRoomType(int PNO, int size, List<RoomType> roomtype,int schoolid,int branchid) {
		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer catSB = new StringBuffer();
		try {
			stgTx=stgSession.beginTransaction();
			int fset = (PNO-1)*size;
			String gsSql ="select count(*) from gbl_sm_tbl_room_type where SchoolId='"+schoolid+"' and BranchId='"+branchid+"';";
			Query gsQuery=stgSession.createSQLQuery(gsSql);
			Object noRecords= gsQuery.uniqueResult();
			catSB.append("<roomtypes>");
			catSB.append("\n");
			catSB.append("<noRecords>"+noRecords+"</noRecords>");
			catSB.append("\n");
			if(roomtype==null) {
			if (PNO > 0 & size > 0){
			gsSql="select * from gbl_sm_tbl_room_type where SchoolId='"+schoolid+"' and BranchId='"+branchid+"' limit "+size+" offset "+fset;}
			else {
				gsSql="select * from gbl_sm_tbl_room_type where SchoolId='"+schoolid+"' and BranchId='"+branchid+"'";
			}
			} else {
				StringBuffer ctIdSB = new StringBuffer();
				Iterator gsIdIT=roomtype.iterator();
					while(gsIdIT.hasNext())
					{
						RoomType mdct=(RoomType)gsIdIT.next();
						ctIdSB .append("'"+mdct.getRoomTypeId()+"',");
					}
					int k=ctIdSB.lastIndexOf(",");
					ctIdSB.deleteCharAt(k);
					String ctIdStr = ctIdSB.toString();
				gsSql="select * from gbl_sm_tbl_room_type where SchoolId='"+schoolid+"' and BranchId='"+branchid+"' and RoomTypeId in ("+ctIdStr+")";
			}
			gsQuery=stgSession.createSQLQuery(gsSql);
			List gcList=gsQuery.list();
			Iterator gsIT=gcList.iterator();
				while(gsIT.hasNext())
				{
					//MDCategory mdc=(MDCategory)gsIT.next();
					Object[] mdcArr=(Object[])gsIT.next();
					catSB.append("<roomtype>");
					catSB.append("\n");
					catSB.append("<roomTypeId>"+(Integer) mdcArr[0]+"</roomTypeId>");
					catSB.append("\n");
					catSB.append("<typeName>"+(String) mdcArr[1]+"</typeName>");
					catSB.append("\n");
					catSB.append("<typeFlag>"+(String) mdcArr[2]+"</typeFlag>");
					catSB.append("\n");
					catSB.append("<description>"+(String) mdcArr[3]+"</description>");
					catSB.append("\n");
					catSB.append("</roomtype>");
					catSB.append("\n");
				}

			stgTx.commit();
			catSB.append("</roomtypes>");
			catSB.append("\n");

			xmlString=catSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Get roomtype");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}






	@SuppressWarnings("rawtypes")
	private String getAssessmentMode(int PNO, int size,  List<AssessmentModePojo> assessmentmode,int schoolid,int branchid) {
		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer catSB = new StringBuffer();
		try {
			stgTx=stgSession.beginTransaction();
			int fset = (PNO-1)*size;
			String gsSql ="select count(*) from gbl_sm_tbl_assessment_mode where SchoolId='"+schoolid+"' and BranchId='"+branchid+"';";
			Query gsQuery=stgSession.createSQLQuery(gsSql);
			Object noRecords= gsQuery.uniqueResult();
			catSB.append("<assessmentmodes>");
			catSB.append("\n");
			catSB.append("<noRecords>"+noRecords+"</noRecords>");
			catSB.append("\n");
			if(assessmentmode==null) {
			if (PNO > 0 & size > 0){
			gsSql="select * from gbl_sm_tbl_assessment_mode where SchoolId='"+schoolid+"' and BranchId='"+branchid+"' limit "+size+" offset "+fset;}
			else {
				gsSql="select * from gbl_sm_tbl_assessment_mode where SchoolId='"+schoolid+"' and BranchId='"+branchid+"'";
			}
			} else {
				StringBuffer ctIdSB = new StringBuffer();
				Iterator gsIdIT=assessmentmode.iterator();
					while(gsIdIT.hasNext())
					{
						AssessmentModePojo mdct=(AssessmentModePojo)gsIdIT.next();
						ctIdSB .append("'"+mdct.getAssessmentModeId()+"',");
					}
					int k=ctIdSB.lastIndexOf(",");
					ctIdSB.deleteCharAt(k);
					String ctIdStr = ctIdSB.toString();
				gsSql="select * from gbl_sm_tbl_assessment_mode where SchoolId='"+schoolid+"' and BranchId='"+branchid+"' and AssessmentModeId in ("+ctIdStr+")";
			}
			gsQuery=stgSession.createSQLQuery(gsSql);
			List gcList=gsQuery.list();
			Iterator gsIT=gcList.iterator();
				while(gsIT.hasNext())
				{
					//MDCategory mdc=(MDCategory)gsIT.next();
					Object[] mdcArr=(Object[])gsIT.next();
					catSB.append("<assessmentmode>");
					catSB.append("\n");
					catSB.append("<assessmentModeId>"+(Integer) mdcArr[0]+"</assessmentModeId>");
					catSB.append("\n");
					catSB.append("<modeName>"+(String) mdcArr[1]+"</modeName>");
					catSB.append("\n");
					catSB.append("<description>"+(String) mdcArr[2]+"</description>");
					catSB.append("\n");
					catSB.append("</assessmentmode>");
					catSB.append("\n");
				}

			stgTx.commit();
			catSB.append("</assessmentmodes>");
			catSB.append("\n");

			xmlString=catSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Get assessmentmode");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}


	@SuppressWarnings("rawtypes")
	private String getAssessmentType(int PNO, int size, List<AssessmentTypePojo> assessmenttype,int schoolid,int branchid) {
		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer catSB = new StringBuffer();
		try {
			stgTx=stgSession.beginTransaction();
			int fset = (PNO-1)*size;
			String gsSql ="select count(*) from gbl_sm_tbl_assessment_type where SchoolId='"+schoolid+"' and BranchId='"+branchid+"';";
			Query gsQuery=stgSession.createSQLQuery(gsSql);
			Object noRecords= gsQuery.uniqueResult();
			catSB.append("<assessmenttypes>");
			catSB.append("\n");
			catSB.append("<noRecords>"+noRecords+"</noRecords>");
			catSB.append("\n");
			if(assessmenttype==null) {
			if (PNO > 0 & size > 0){
			gsSql="select * from gbl_sm_tbl_assessment_type where SchoolId='"+schoolid+"' and BranchId='"+branchid+"' limit "+size+" offset "+fset;}
			else {
				gsSql="select * from gbl_sm_tbl_assessment_type where SchoolId='"+schoolid+"' and BranchId='"+branchid+"'";
			}
			} else {
				StringBuffer ctIdSB = new StringBuffer();
				Iterator gsIdIT=assessmenttype.iterator();
					while(gsIdIT.hasNext())
					{
						AssessmentTypePojo mdct=(AssessmentTypePojo)gsIdIT.next();
						ctIdSB .append("'"+mdct.getAssessmentTypeId()+"',");
					}
					int k=ctIdSB.lastIndexOf(",");
					ctIdSB.deleteCharAt(k);
					String ctIdStr = ctIdSB.toString();
				gsSql="select * from gbl_sm_tbl_assessment_type where SchoolId='"+schoolid+"' and BranchId='"+branchid+"' and AssessmentTypeId in ("+ctIdStr+")";
			}
			gsQuery=stgSession.createSQLQuery(gsSql);
			List gcList=gsQuery.list();
			Iterator gsIT=gcList.iterator();
				while(gsIT.hasNext())
				{
					//MDCategory mdc=(MDCategory)gsIT.next();
					Object[] mdcArr=(Object[])gsIT.next();
					catSB.append("<assessmenttype>");
					catSB.append("\n");
					catSB.append("<assessmentTypeId>"+(Integer) mdcArr[0]+"</assessmentTypeId>");
					catSB.append("\n");
					catSB.append("<assessmentModeId>"+(Integer) mdcArr[1]+"</assessmentModeId>");
					catSB.append("\n");
					catSB.append("<typeName>"+(String) mdcArr[2]+"</typeName>");
					catSB.append("\n");
					catSB.append("<status>"+(String) mdcArr[3]+"</status>");
					catSB.append("\n");
					catSB.append("<description>"+(String) mdcArr[4]+"</description>");
					catSB.append("\n");
					catSB.append("</assessmenttype>");
					catSB.append("\n");
				}

			stgTx.commit();
			catSB.append("</assessmenttypes>");
			catSB.append("\n");

			xmlString=catSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Get assessmenttype");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}




@SuppressWarnings("rawtypes")
	private String getCastes(int PNO, int size, List<CastesPojo> castes,int schoolid,int branchid) {
		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer catSB = new StringBuffer();
		try {
			stgTx=stgSession.beginTransaction();
			int fset = (PNO-1)*size;
			String gsSql ="select count(*) from gbl_sm_tbl_caste where BranchId='"+branchid+"' and SchoolId='"+schoolid+"';";
			Query gsQuery=stgSession.createSQLQuery(gsSql);
			Object noRecords= gsQuery.uniqueResult();
			catSB.append("<castes>");
			catSB.append("\n");
			catSB.append("<noRecords>"+noRecords+"</noRecords>");
			catSB.append("\n");
			if(castes==null) {
			if (PNO > 0 & size > 0){
			gsSql="select * from gbl_sm_tbl_caste where BranchId='"+branchid+"' and SchoolId='"+schoolid+"' limit "+size+" offset "+fset;}

			else {
				gsSql="select * from gbl_sm_tbl_caste where BranchId='"+branchid+"' and SchoolId='"+schoolid+"';";
			}
			} else {
				StringBuffer ctIdSB = new StringBuffer();
				Iterator gsIdIT=castes.iterator();
					while(gsIdIT.hasNext())
					{
						CastesPojo mdct=(CastesPojo)gsIdIT.next();
						ctIdSB .append("'"+mdct.getCastId()+"',");
					}
					int k=ctIdSB.lastIndexOf(",");
					ctIdSB.deleteCharAt(k);
					String ctIdStr = ctIdSB.toString();
				gsSql="select * from gbl_sm_tbl_caste where BranchId='"+branchid+"' and SchoolId='"+schoolid+"' and CasteId in ("+ctIdStr+")";
			}
			gsQuery=stgSession.createSQLQuery(gsSql);
			List gcList=gsQuery.list();
			Iterator gsIT=gcList.iterator();
				while(gsIT.hasNext())
				{
					//MDCategory mdc=(MDCategory)gsIT.next();
					Object[] mdcArr=(Object[])gsIT.next();
					catSB.append("<caste>");
					catSB.append("\n");
					catSB.append("<casteId>"+(Integer) mdcArr[0]+"</casteId>");
					catSB.append("\n");
					catSB.append("<casteName>"+(String) mdcArr[1]+"</casteName>");
					catSB.append("\n");
					catSB.append("<description>"+(String) mdcArr[2]+"</description>");
					catSB.append("\n");
					catSB.append("</caste>");
					catSB.append("\n");
				}

			stgTx.commit();
			catSB.append("</castes>");
			catSB.append("\n");

			xmlString=catSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Get castes");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}


	@SuppressWarnings("rawtypes")
	private String getReligions(int PNO, int size, List<ReligionPojo> religions,int schoolid,int branchid) {
		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer catSB = new StringBuffer();
		try {
			stgTx=stgSession.beginTransaction();
			int fset = (PNO-1)*size;
			String gsSql ="select count(*) from gbl_sm_tbl_religion where BranchId='"+branchid+"' and SchoolId='"+schoolid+"';";
			Query gsQuery=stgSession.createSQLQuery(gsSql);
			Object noRecords= gsQuery.uniqueResult();
			catSB.append("<religions>");
			catSB.append("\n");
			catSB.append("<noRecords>"+noRecords+"</noRecords>");
			catSB.append("\n");
			if(religions==null) {
			if (PNO > 0 & size > 0){
			gsSql="select * from gbl_sm_tbl_religion where BranchId='"+branchid+"' and SchoolId='"+schoolid+"' limit "+size+" offset "+fset;}

			else {
				gsSql="select * from gbl_sm_tbl_religion where BranchId='"+branchid+"' and SchoolId='"+schoolid+"';";
			}
			} else {
				StringBuffer ctIdSB = new StringBuffer();
				Iterator gsIdIT=religions.iterator();
					while(gsIdIT.hasNext())
					{
						ReligionPojo mdct=(ReligionPojo)gsIdIT.next();
						ctIdSB .append("'"+mdct.getReligionId()+"',");
					}
					int k=ctIdSB.lastIndexOf(",");
					ctIdSB.deleteCharAt(k);
					String ctIdStr = ctIdSB.toString();
				gsSql="select * from gbl_sm_tbl_religion where BranchId='"+branchid+"' and SchoolId='"+schoolid+"' and ReligionId in ("+ctIdStr+")";
			}
			gsQuery=stgSession.createSQLQuery(gsSql);
			List gcList=gsQuery.list();
			Iterator gsIT=gcList.iterator();
				while(gsIT.hasNext())
				{
					//MDCategory mdc=(MDCategory)gsIT.next();
					Object[] mdcArr=(Object[])gsIT.next();
					catSB.append("<religion>");
					catSB.append("\n");
					catSB.append("<religionId>"+(Integer) mdcArr[0]+"</religionId>");
					catSB.append("\n");
					catSB.append("<religionName>"+(String) mdcArr[1]+"</religionName>");
					catSB.append("\n");
					catSB.append("<description>"+(String) mdcArr[2]+"</description>");
					catSB.append("\n");
					catSB.append("</religion>");
					catSB.append("\n");
				}

			stgTx.commit();
			catSB.append("</religions>");
			catSB.append("\n");

			xmlString=catSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Get religions");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}



	@SuppressWarnings("rawtypes")

	private String getresults(int PNO, int size, List<ResultPojo> results,int schoolid,int branchid) {
		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer catSB = new StringBuffer();
		try {
			stgTx=stgSession.beginTransaction();
			int fset = (PNO-1)*size;
			String gsSql ="select count(*) from gbl_sm_tbl_result where BranchId='"+branchid+"' and SchoolId='"+schoolid+"';";
			Query gsQuery=stgSession.createSQLQuery(gsSql);
			Object noRecords= gsQuery.uniqueResult();
			catSB.append("<results>");
			catSB.append("\n");
			catSB.append("<noRecords>"+noRecords+"</noRecords>");
			catSB.append("\n");
			if(results==null) {
			if (PNO > 0 & size > 0){
			gsSql="select * from gbl_sm_tbl_result where BranchId='"+branchid+"' and SchoolId='"+schoolid+"' limit "+size+" offset "+fset;}

			else {
				gsSql="select * from gbl_sm_tbl_result where BranchId='"+branchid+"' and SchoolId='"+schoolid+"';";
			}
			} else {
				StringBuffer ctIdSB = new StringBuffer();
				Iterator gsIdIT=results.iterator();
					while(gsIdIT.hasNext())
					{
						ResultPojo mdct=(ResultPojo)gsIdIT.next();
						ctIdSB .append("'"+mdct.getResultId()+"',");
					}
					int k=ctIdSB.lastIndexOf(",");
					ctIdSB.deleteCharAt(k);
					String ctIdStr = ctIdSB.toString();
				gsSql="select * from gbl_sm_tbl_result where BranchId='"+branchid+"' and SchoolId='"+schoolid+"' and ResultId in ("+ctIdStr+")";
			}
			gsQuery=stgSession.createSQLQuery(gsSql);
			List gcList=gsQuery.list();
			Iterator gsIT=gcList.iterator();
				while(gsIT.hasNext())
				{
					//MDCategory mdc=(MDCategory)gsIT.next();
					Object[] mdcArr=(Object[])gsIT.next();
					catSB.append("<result>");
					catSB.append("\n");
					catSB.append("<resultId>"+(Integer) mdcArr[0]+"</resultId>");
					catSB.append("\n");
					catSB.append("<resultName>"+(String) mdcArr[1]+"</resultName>");
					catSB.append("\n");
					catSB.append("<description>"+(String) mdcArr[2]+"</description>");
					catSB.append("\n");
					catSB.append("</result>");
					catSB.append("\n");
				}

			stgTx.commit();
			catSB.append("</results>");
			catSB.append("\n");

			xmlString=catSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Get results");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}

	@SuppressWarnings("rawtypes")
	private String getaccolades(int PNO, int size, List<AccoladetypePojo> accolades,int schoolid,int branchid) {
		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer catSB = new StringBuffer();
		try {
			stgTx=stgSession.beginTransaction();
			int fset = (PNO-1)*size;
			String gsSql ="select count(*) from gbl_sm_tbl_accoladetype where BranchId='"+branchid+"' and SchoolId='"+schoolid+"';";
			Query gsQuery=stgSession.createSQLQuery(gsSql);
			Object noRecords= gsQuery.uniqueResult();
			catSB.append("<Accoladetypes>");
			catSB.append("\n");
			catSB.append("<noRecords>"+noRecords+"</noRecords>");
			catSB.append("\n");
			if(accolades==null) {
			if (PNO > 0 & size > 0){
			gsSql="select * from gbl_sm_tbl_accoladetype where BranchId='"+branchid+"' and SchoolId='"+schoolid+"' limit "+size+" offset "+fset;}

			else {
				gsSql="select * from gbl_sm_tbl_accoladetype where BranchId='"+branchid+"' and SchoolId='"+schoolid+"';";
			}
			} else {
				StringBuffer ctIdSB = new StringBuffer();
				Iterator gsIdIT=accolades.iterator();
					while(gsIdIT.hasNext())
					{
						AccoladetypePojo mdct=(AccoladetypePojo)gsIdIT.next();
						ctIdSB .append("'"+mdct.getAccoladeTypeId()+"',");
					}
					int k=ctIdSB.lastIndexOf(",");
					ctIdSB.deleteCharAt(k);
					String ctIdStr = ctIdSB.toString();
				gsSql="select * from gbl_sm_tbl_accoladetype where BranchId='"+branchid+"' and SchoolId='"+schoolid+"' and AccoladeTypeId in ("+ctIdStr+")";
			}
			gsQuery=stgSession.createSQLQuery(gsSql);
			List gcList=gsQuery.list();
			Iterator gsIT=gcList.iterator();
				while(gsIT.hasNext())
				{
					//MDCategory mdc=(MDCategory)gsIT.next();
					Object[] mdcArr=(Object[])gsIT.next();
					catSB.append("<Accoladetype>");
					catSB.append("\n");
					catSB.append("<accoladeTypeId>"+(Integer) mdcArr[0]+"</accoladeTypeId>");
					catSB.append("\n");
					catSB.append("<typeName>"+(String) mdcArr[1]+"</typeName>");
					catSB.append("\n");
					catSB.append("<description>"+(String) mdcArr[2]+"</description>");
					catSB.append("\n");
					catSB.append("</Accoladetype>");
					catSB.append("\n");
				}

			stgTx.commit();
			catSB.append("</Accoladetypes>");
			catSB.append("\n");

			xmlString=catSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Get accolades");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}

	@SuppressWarnings("rawtypes")
	private String getJobtitles(int PNO, int size, List<JobtitlePojo> jobtitles,int schoolid,int branchid) {
		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer catSB = new StringBuffer();
		try {
			stgTx=stgSession.beginTransaction();
			int fset = (PNO-1)*size;
			String gsSql ="select count(*) from gbl_sm_tbl_jobtitle where BranchId='"+branchid+"' and SchoolId='"+schoolid+"';";
			Query gsQuery=stgSession.createSQLQuery(gsSql);
			Object noRecords= gsQuery.uniqueResult();
			catSB.append("<Jobtitles>");
			catSB.append("\n");
			catSB.append("<noRecords>"+noRecords+"</noRecords>");
			catSB.append("\n");
			if(jobtitles==null) {
			if (PNO > 0 & size > 0){
			gsSql="select * from gbl_sm_tbl_jobtitle where BranchId='"+branchid+"' and SchoolId='"+schoolid+"' limit "+size+" offset "+fset;}

			else {
				gsSql="select * from gbl_sm_tbl_jobtitle where BranchId='"+branchid+"' and SchoolId='"+schoolid+"';";
			}
			} else {
				StringBuffer ctIdSB = new StringBuffer();
				Iterator gsIdIT=jobtitles.iterator();
					while(gsIdIT.hasNext())
					{
						JobtitlePojo mdct=(JobtitlePojo)gsIdIT.next();
						ctIdSB .append("'"+mdct.getJobTitleId()+"',");
					}
					int k=ctIdSB.lastIndexOf(",");
					ctIdSB.deleteCharAt(k);
					String ctIdStr = ctIdSB.toString();
				gsSql="select * from gbl_sm_tbl_jobtitle where BranchId='"+branchid+"' and SchoolId='"+schoolid+"' and JobTitleId in ("+ctIdStr+")";
			}
			gsQuery=stgSession.createSQLQuery(gsSql);
			List gcList=gsQuery.list();
			Iterator gsIT=gcList.iterator();
				while(gsIT.hasNext())
				{
					//MDCategory mdc=(MDCategory)gsIT.next();
					Object[] mdcArr=(Object[])gsIT.next();
					catSB.append("<Jobtitle>");
					catSB.append("\n");
					catSB.append("<jobTitleId>"+(Integer) mdcArr[0]+"</jobTitleId>");
					catSB.append("\n");
					catSB.append("<title>"+(String) mdcArr[1]+"</title>");
					catSB.append("\n");
					catSB.append("<description>"+(String) mdcArr[2]+"</description>");
					catSB.append("\n");
					catSB.append("</Jobtitle>");
					catSB.append("\n");
				}

			stgTx.commit();
			catSB.append("</Jobtitles>");
			catSB.append("\n");

			xmlString=catSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Get Jobtitles");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}

	@SuppressWarnings("rawtypes")
	private String getJobtypes(int PNO, int size, List<JobtypePojo> jobtypes,int schoolid,int branchid) {
		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer catSB = new StringBuffer();
		try {
			stgTx=stgSession.beginTransaction();
			int fset = (PNO-1)*size;
			String gsSql ="select count(*) from gbl_sm_tbl_jobtype where BranchId='"+branchid+"' and SchoolId='"+schoolid+"';";
			Query gsQuery=stgSession.createSQLQuery(gsSql);
			Object noRecords= gsQuery.uniqueResult();
			catSB.append("<Jobtypes>");
			catSB.append("\n");
			catSB.append("<noRecords>"+noRecords+"</noRecords>");
			catSB.append("\n");
			if(jobtypes==null) {
			if (PNO > 0 & size > 0){
			gsSql="select * from gbl_sm_tbl_jobtype where BranchId='"+branchid+"' and SchoolId='"+schoolid+" limit "+size+" offset "+fset;}
			else {
				gsSql="select * from gbl_sm_tbl_jobtype where BranchId='"+branchid+"' and SchoolId='"+schoolid+"';";
			}
			} else {
				StringBuffer ctIdSB = new StringBuffer();
				Iterator gsIdIT=jobtypes.iterator();
					while(gsIdIT.hasNext())
					{
						JobtypePojo mdct=(JobtypePojo)gsIdIT.next();
						ctIdSB .append("'"+mdct.getJobTypeId()+"',");
					}
					int k=ctIdSB.lastIndexOf(",");
					ctIdSB.deleteCharAt(k);
					String ctIdStr = ctIdSB.toString();
				gsSql="select * from gbl_sm_tbl_jobtype where BranchId='"+branchid+"' and SchoolId='"+schoolid+"' and JobTypeId in ("+ctIdStr+")";
			}
			gsQuery=stgSession.createSQLQuery(gsSql);
			List gcList=gsQuery.list();
			Iterator gsIT=gcList.iterator();
				while(gsIT.hasNext())
				{
					//MDCategory mdc=(MDCategory)gsIT.next();
					Object[] mdcArr=(Object[])gsIT.next();
					catSB.append("<Jobtype>");
					catSB.append("\n");
					catSB.append("<jobTypeId>"+(Integer) mdcArr[0]+"</jobTypeId>");
					catSB.append("\n");
					catSB.append("<jobTypeName>"+(String) mdcArr[1]+"</jobTypeName>");
					catSB.append("\n");
					catSB.append("<description>"+(String) mdcArr[2]+"</description>");
					catSB.append("\n");
					catSB.append("</Jobtype>");
					catSB.append("\n");
				}

			stgTx.commit();
			catSB.append("</Jobtypes>");
			catSB.append("\n");

			xmlString=catSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Get Jobtypes");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}



	@SuppressWarnings("rawtypes")
	public String getCategoryTypes(int PNO, int size, List <MDCategoryType> mdCategoryTypes){

		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer catSB = new StringBuffer();
		try {
			stgTx=stgSession.beginTransaction();
			int fset = (PNO-1)*size;
			String gsSql ="select count(*) from mdcategorytype";
			Query gsQuery=stgSession.createSQLQuery(gsSql);
			Object noRecords= gsQuery.uniqueResult();
			catSB.append("<CategoryTypes>");
			catSB.append("\n");
			catSB.append("<noRecords>"+noRecords+"</noRecords>");
			catSB.append("\n");
			if(mdCategoryTypes==null){
				if (PNO > 0 & size > 0){
				gsSql="select * from mdcategorytype limit "+size+" offset "+fset;}
				else {
					gsSql="select * from mdcategorytype";
				}
			} else {
				StringBuffer ctIdSB = new StringBuffer();
				Iterator gsIdIT=mdCategoryTypes.iterator();
					while(gsIdIT.hasNext())
					{
						MDCategoryType mdct=(MDCategoryType)gsIdIT.next();
						ctIdSB .append("'"+mdct.getCategoryTypeId()+"',");
					}
					int k=ctIdSB.lastIndexOf(",");
					ctIdSB.deleteCharAt(k);
					String ctIdStr = ctIdSB.toString();
				gsSql="select * from mdcategorytype where categoryTypeId in ("+ctIdStr+")";
			}
			gsQuery=stgSession.createSQLQuery(gsSql);
			List gcList=gsQuery.list();
			Iterator gsIT=gcList.iterator();
				while(gsIT.hasNext())
				{
					Object[] mdctArr=(Object[])gsIT.next();
					catSB.append("<CategoryType>");
					catSB.append("\n");
					catSB.append("<categoryTypeId>"+mdctArr[0]+"</categoryTypeId>");
					catSB.append("\n");
					catSB.append("<categoryTypeName>"+mdctArr[1]+"</categoryTypeName>");
					catSB.append("\n");
					catSB.append("<categoryTypeCode>"+mdctArr[2]+"</categoryTypeCode>");
					catSB.append("\n");
					catSB.append("<categoryTypeStatus>"+mdctArr[3]+"</categoryTypeStatus>");
					catSB.append("\n");
					catSB.append("<description>"+mdctArr[4]+"</description>");
					catSB.append("\n");
					catSB.append("</CategoryType>");
					catSB.append("\n");
				}

			stgTx.commit();
			catSB.append("</CategoryTypes>");
			catSB.append("\n");

			xmlString=catSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Get Category Types");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}


	//fee.....
	@SuppressWarnings("rawtypes")
	private String getEventTypes(int PNO, int size, List<EventTypePojo> results,int schoolid,int branchid) {
		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer catSB = new StringBuffer();
		try {
			stgTx=stgSession.beginTransaction();
			int fset = (PNO-1)*size;
			String gsSql ="select count(*) from gbl_sm_tbl_event_type where BranchId='"+branchid+"' and SchoolId='"+schoolid+"';";
			Query gsQuery=stgSession.createSQLQuery(gsSql);
			Object noRecords= gsQuery.uniqueResult();
			catSB.append("<EventTypes>");
			catSB.append("\n");
			catSB.append("<noRecords>"+noRecords+"</noRecords>");
			catSB.append("\n");
			if(results==null) {
			if (PNO > 0 & size > 0){
			gsSql="select * from gbl_sm_tbl_event_type where BranchId='"+branchid+"' and SchoolId='"+schoolid+"' limit "+size+" offset "+fset;
			}
			else {
				gsSql="select * from gbl_sm_tbl_event_type where BranchId='"+branchid+"' and SchoolId='"+schoolid+"' ";
			}
			} else {
				StringBuffer ctIdSB = new StringBuffer();
				Iterator gsIdIT=results.iterator();
					while(gsIdIT.hasNext())
					{
						EventTypePojo mdct=(EventTypePojo)gsIdIT.next();
						ctIdSB .append("'"+mdct.getEventTypeId()+"',");
					}
					int k=ctIdSB.lastIndexOf(",");
					ctIdSB.deleteCharAt(k);
					String ctIdStr = ctIdSB.toString();
				gsSql="select * from gbl_sm_tbl_event_type where BranchId='"+branchid+"' and SchoolId='"+schoolid+"' and EventTypeId in ("+ctIdStr+")";
			}
			gsQuery=stgSession.createSQLQuery(gsSql);
			List gcList=gsQuery.list();
			Iterator gsIT=gcList.iterator();
				while(gsIT.hasNext())
				{
					//MDCategory mdc=(MDCategory)gsIT.next();
					Object[] mdcArr=(Object[])gsIT.next();
					catSB.append("<EventType>");
					catSB.append("\n");
					catSB.append("<eventTypeId>"+ mdcArr[0]+"</eventTypeId>");
					catSB.append("\n");
					catSB.append("<eventTypeName>"+ mdcArr[1]+"</eventTypeName>");
					catSB.append("\n");
					catSB.append("<description>"+ mdcArr[2]+"</description>");
					catSB.append("\n");
					catSB.append("</EventType>");
					catSB.append("\n");
				}

			stgTx.commit();
			catSB.append("</EventTypes>");
			catSB.append("\n");

			xmlString=catSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Get results");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}
	@SuppressWarnings("rawtypes")
	private String getFeeItemTypes(int PNO, int size, List<FeeItemType> results,int schoolid,int branchid) {
		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer catSB = new StringBuffer();
		try {
			stgTx=stgSession.beginTransaction();
			int fset = (PNO-1)*size;
			String gsSql ="select count(*) from gbl_sm_tbl_feeitemtype where BranchId='"+branchid+"' and SchoolId='"+schoolid+"';";
			Query gsQuery=stgSession.createSQLQuery(gsSql);
			Object noRecords= gsQuery.uniqueResult();
			catSB.append("<feeitemtypes>");
			catSB.append("\n");
			catSB.append("<noRecords>"+noRecords+"</noRecords>");
			catSB.append("\n");
			if(results==null) {
			if (PNO > 0 & size > 0){
			gsSql="select * from gbl_sm_tbl_feeitemtype where BranchId='"+branchid+"' and SchoolId='"+schoolid+"' limit "+size+" offset "+fset;}
			else {
				gsSql="select * from gbl_sm_tbl_feeitemtype where BranchId='"+branchid+"' and SchoolId='"+schoolid+"' ";
			}
			} else {
				StringBuffer ctIdSB = new StringBuffer();
				Iterator gsIdIT=results.iterator();
					while(gsIdIT.hasNext())
					{
						FeeItemType mdct=(FeeItemType)gsIdIT.next();
						ctIdSB .append("'"+mdct.getFeeItemTypeId()+"',");
					}
					int k=ctIdSB.lastIndexOf(",");
					ctIdSB.deleteCharAt(k);
					String ctIdStr = ctIdSB.toString();
				gsSql="select * from gbl_sm_tbl_feeitemtype where BranchId='"+branchid+"' and SchoolId='"+schoolid+"' and FeeItemTypeId in ("+ctIdStr+")";
			}
			gsQuery=stgSession.createSQLQuery(gsSql);
			List gcList=gsQuery.list();
			Iterator gsIT=gcList.iterator();
				while(gsIT.hasNext())
				{
					//MDCategory mdc=(MDCategory)gsIT.next();
					Object[] mdcArr=(Object[])gsIT.next();
					catSB.append("<FeeItemType>");
					catSB.append("\n");
					catSB.append("<feeItemTypeId>"+ mdcArr[0]+"</feeItemTypeId>");
					catSB.append("\n");
					catSB.append("<name>"+ mdcArr[1]+"</name>");
					catSB.append("\n");
					catSB.append("<frequencyName>"+ mdcArr[2]+"</frequencyName>");
					catSB.append("\n");
					catSB.append("<installmentsInYear>"+ mdcArr[3]+"</installmentsInYear>");
					catSB.append("\n");
					catSB.append("<description>"+ mdcArr[4]+"</description>");
					catSB.append("\n");
					catSB.append("</FeeItemType>");
					catSB.append("\n");
				}

			stgTx.commit();
			catSB.append("</feeitemtypes>");
			catSB.append("\n");

			xmlString=catSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Get results");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}


	@SuppressWarnings("rawtypes")
	private String getBookTypes(int PNO, int size, List<BookTypePOJO> results,int schoolid,int branchid) {
		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer catSB = new StringBuffer();
		try {
			stgTx=stgSession.beginTransaction();
			int fset = (PNO-1)*size;
			String gsSql ="select count(*) from gbl_sm_tbl_book_type where BranchId='"+branchid+"' and SchoolId='"+schoolid+"';";
			Query gsQuery=stgSession.createSQLQuery(gsSql);
			Object noRecords= gsQuery.uniqueResult();
			catSB.append("<BookTypes>");
			catSB.append("\n");
			catSB.append("<noRecords>"+noRecords+"</noRecords>");
			catSB.append("\n");
			if(results==null) {
			if (PNO > 0 & size > 0){
			gsSql="select * from gbl_sm_tbl_book_type where BranchId='"+branchid+"' and SchoolId='"+schoolid+"'  limit "+size+" offset "+fset;}
			else {
				gsSql="select * from gbl_sm_tbl_book_type where BranchId='"+branchid+"' and SchoolId='"+schoolid+"' ";
			}
			} else {
				StringBuffer ctIdSB = new StringBuffer();
				Iterator gsIdIT=results.iterator();
					while(gsIdIT.hasNext())
					{
						BookTypePOJO mdct=(BookTypePOJO)gsIdIT.next();
						ctIdSB .append("'"+mdct.getBookTypeId()+"',");
					}
					int k=ctIdSB.lastIndexOf(",");
					ctIdSB.deleteCharAt(k);
					String ctIdStr = ctIdSB.toString();
				gsSql="select * from gbl_sm_tbl_book_type where BranchId='"+branchid+"' and SchoolId='"+schoolid+"' and BookTypeId in ("+ctIdStr+")";
			}
			gsQuery=stgSession.createSQLQuery(gsSql);
			List gcList=gsQuery.list();
			Iterator gsIT=gcList.iterator();
				while(gsIT.hasNext())
				{
					//MDCategory mdc=(MDCategory)gsIT.next();
					Object[] mdcArr=(Object[])gsIT.next();
					catSB.append("<BookType>");
					catSB.append("\n");
					catSB.append("<bookTypeId>"+ mdcArr[0]+"</bookTypeId>");
					catSB.append("\n");
					catSB.append("<bookTypeName>"+ mdcArr[1]+"</bookTypeName>");
					catSB.append("\n");
					catSB.append("<isIssue>"+ mdcArr[2]+"</isIssue>");
					catSB.append("\n");
					catSB.append("<description>"+ mdcArr[3]+"</description>");
					catSB.append("\n");
					catSB.append("</BookType>");
					catSB.append("\n");
				}

			stgTx.commit();
			catSB.append("</BookTypes>");
			catSB.append("\n");

			xmlString=catSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Get results");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}


	@SuppressWarnings("rawtypes")
	private String getQuestionTypes(int PNO, int size, List<QuestionType> results,int schoolid,int branchid) {
		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer catSB = new StringBuffer();
		try {
			stgTx=stgSession.beginTransaction();
			int fset = (PNO-1)*size;
			String gsSql ="select count(*) from gbl_sm_tbl_questiontype where SchoolId='"+schoolid+"' and BranchId='"+branchid+"';";
			Query gsQuery=stgSession.createSQLQuery(gsSql);
			Object noRecords= gsQuery.uniqueResult();
			catSB.append("<QuestionTypes>");
			catSB.append("\n");
			catSB.append("<noRecords>"+noRecords+"</noRecords>");
			catSB.append("\n");
			if(results==null) {
			if (PNO > 0 & size > 0){
			gsSql="select * from gbl_sm_tbl_questiontype where SchoolId='"+schoolid+"' and BranchId='"+branchid+"' limit "+size+" offset "+fset;}
			else {
				gsSql="select * from gbl_sm_tbl_questiontype where SchoolId='"+schoolid+"' and BranchId='"+branchid+"'";
			}
			} else {
				StringBuffer ctIdSB = new StringBuffer();
				Iterator gsIdIT=results.iterator();
					while(gsIdIT.hasNext())
					{
						QuestionType mdct=(QuestionType)gsIdIT.next();
						ctIdSB .append("'"+mdct.getQuestionTypeId()+"',");
					}
					int k=ctIdSB.lastIndexOf(",");
					ctIdSB.deleteCharAt(k);
					String ctIdStr = ctIdSB.toString();
				gsSql="select * from gbl_sm_tbl_questiontype where SchoolId='"+schoolid+"' and BranchId='"+branchid+"' and QuestionTypeId in ("+ctIdStr+")";
			}
			gsQuery=stgSession.createSQLQuery(gsSql);
			List gcList=gsQuery.list();
			Iterator gsIT=gcList.iterator();
				while(gsIT.hasNext())
				{
					//MDCategory mdc=(MDCategory)gsIT.next();
					Object[] mdcArr=(Object[])gsIT.next();
					catSB.append("<QuestionType>");
					catSB.append("\n");
					catSB.append("<questionTypeId>"+ mdcArr[0]+"</questionTypeId>");
					catSB.append("\n");
					catSB.append("<typeName>"+ mdcArr[1]+"</typeName>");
					catSB.append("\n");

					catSB.append("</QuestionType>");
					catSB.append("\n");
				}

			stgTx.commit();
			catSB.append("</QuestionTypes>");
			catSB.append("\n");

			xmlString=catSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Get results");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}



	@SuppressWarnings("rawtypes")
	private String getPaymentModes(int PNO, int size, List<PaymentModePojo> results,int schoolid,int branchid) {
		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer catSB = new StringBuffer();
		try {
			stgTx=stgSession.beginTransaction();
			int fset = (PNO-1)*size;
			String gsSql ="select count(*) from gbl_sm_tbl_paymentmode where BranchId='"+branchid+"' and SchoolId='"+schoolid+"';";
			Query gsQuery=stgSession.createSQLQuery(gsSql);
			Object noRecords= gsQuery.uniqueResult();
			catSB.append("<PaymentModes>");
			catSB.append("\n");
			catSB.append("<noRecords>"+noRecords+"</noRecords>");
			catSB.append("\n");
			if(results==null) {
			if (PNO > 0 & size > 0){
			gsSql="select * from gbl_sm_tbl_paymentmode where BranchId='"+branchid+"' and SchoolId='"+schoolid+"' limit "+size+" offset "+fset;}
			else {
				gsSql="select * from gbl_sm_tbl_paymentmode where BranchId='"+branchid+"' and SchoolId='"+schoolid+"';";
			}
			} else {
				StringBuffer ctIdSB = new StringBuffer();
				Iterator gsIdIT=results.iterator();
					while(gsIdIT.hasNext())
					{
						PaymentModePojo mdct=(PaymentModePojo)gsIdIT.next();
						ctIdSB .append("'"+mdct.getPaymentModeId()+"',");
					}
					int k=ctIdSB.lastIndexOf(",");
					ctIdSB.deleteCharAt(k);
					String ctIdStr = ctIdSB.toString();
				gsSql="select * from gbl_sm_tbl_paymentmode where BranchId='"+branchid+"' and SchoolId='"+schoolid+"' and PaymentModeId in ("+ctIdStr+")";
			}
			gsQuery=stgSession.createSQLQuery(gsSql);
			List gcList=gsQuery.list();
			Iterator gsIT=gcList.iterator();
				while(gsIT.hasNext())
				{
					//MDCategory mdc=(MDCategory)gsIT.next();
					Object[] mdcArr=(Object[])gsIT.next();
					catSB.append("<PaymentMode>");
					catSB.append("\n");
					catSB.append("<paymentModeId>"+ mdcArr[0]+"</paymentModeId>");
					catSB.append("\n");
					catSB.append("<ModeName>"+ mdcArr[1]+"</ModeName>");
					catSB.append("\n");
					catSB.append("<Description>"+ mdcArr[2]+"</Description>");
					catSB.append("\n");
					/*catSB.append("<credit>"+ mdcArr[3]+"</credit>");
					catSB.append("\n");
					catSB.append("<debit>"+ mdcArr[4]+"</debit>");
					catSB.append("\n");
					catSB.append("<transfer>"+ mdcArr[5]+"</transfer>");*/
					catSB.append("\n");

					catSB.append("</PaymentMode>");
					catSB.append("\n");
				}

			stgTx.commit();
			catSB.append("</PaymentModes>");
			catSB.append("\n");

			xmlString=catSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Get results");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}


	@SuppressWarnings("rawtypes")
	public String getCategories(int PNO, int size, List<MDCategory> mdCategories,int schoolid,int branchid){

		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer catSB = new StringBuffer();
		try {
			stgTx=stgSession.beginTransaction();
			int fset = (PNO-1)*size;
			String gsSql ="select count(*) from mdcategory where schoolId='"+schoolid+"' and branchId='"+branchid+"';";
			Query gsQuery=stgSession.createSQLQuery(gsSql);
			Object noRecords= gsQuery.uniqueResult();
			catSB.append("<Categories>");
			catSB.append("\n");
			catSB.append("<noRecords>"+noRecords+"</noRecords>");
			catSB.append("\n");
			if(mdCategories==null) {
			if (PNO > 0 & size > 0){
			gsSql="select * from mdcategory where schoolId='"+schoolid+"' and branchId='"+branchid+"' limit "+size+" offset "+fset;
			}
			else {
				gsSql="select * from mdcategory where schoolId='"+schoolid+"' and branchId='"+branchid+"'";
			}
			} else {
				StringBuffer ctIdSB = new StringBuffer();
				Iterator gsIdIT=mdCategories.iterator();
					while(gsIdIT.hasNext())
					{
						MDCategory mdct=(MDCategory)gsIdIT.next();
						ctIdSB .append("'"+mdct.getCategoryId()+"',");
					}
					int k=ctIdSB.lastIndexOf(",");
					ctIdSB.deleteCharAt(k);
					String ctIdStr = ctIdSB.toString();
				gsSql="select * from mdcategory where schoolId='"+schoolid+"' and branchId='"+branchid+"'and categoryId in ("+ctIdStr+")";
			};
			gsQuery=stgSession.createSQLQuery(gsSql);
			List gcList=gsQuery.list();
			Iterator gsIT=gcList.iterator();
				while(gsIT.hasNext())
				{
					//MDCategory mdc=(MDCategory)gsIT.next();
					Object[] mdcArr=(Object[])gsIT.next();
					catSB.append("<Category>");
					catSB.append("\n");
					catSB.append("<categoryId>"+(Integer) mdcArr[0]+"</categoryId>");
					catSB.append("\n");
					catSB.append("<categoryTypeId>"+(Integer) mdcArr[1]+"</categoryTypeId>");
					catSB.append("\n");
					catSB.append("<categoryName>"+(String) mdcArr[2]+"</categoryName>");
					catSB.append("\n");
					catSB.append("<categoryStatus>"+(String) mdcArr[3]+"</categoryStatus>");
					catSB.append("\n");
					catSB.append("<priority>"+(Integer) mdcArr[4]+"</priority>");
					catSB.append("\n");
					catSB.append("<description>"+(String) mdcArr[5]+"</description>");
					catSB.append("\n");
					catSB.append("</Category>");
					catSB.append("\n");
				}

			stgTx.commit();
			catSB.append("</Categories>");
			catSB.append("\n");

			xmlString=catSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Get Categories");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}

	@SuppressWarnings("rawtypes")
	public String getFileCategories(int PNO, int size, List<MDFileCategory> mdFileCategories){

		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer fcatSB = new StringBuffer();
		try {
			stgTx=stgSession.beginTransaction();
			int fset = (PNO-1)*size;
			String gsSql ="select count(*) from mdfilecategory";
			Query gsQuery=stgSession.createSQLQuery(gsSql);
			Object noRecords= gsQuery.uniqueResult();
			fcatSB.append("<FileCategories>");
			fcatSB.append("\n");
			fcatSB.append("<noRecords>"+noRecords+"</noRecords>");
			fcatSB.append("\n");
			if(mdFileCategories==null) {
			if (PNO > 0 & size > 0){
			gsSql="select * from mdfilecategory limit "+size+" offset "+fset;}
			else {
				gsSql="select * from mdfilecategory";
			}
			} else {
				StringBuffer fctIdSB = new StringBuffer();
				Iterator gsIdIT=mdFileCategories.iterator();
					while(gsIdIT.hasNext())
					{
						MDFileCategory mdct=(MDFileCategory)gsIdIT.next();
						fctIdSB .append("'"+mdct.getFileCategoryId()+"',");
					}
					int k=fctIdSB.lastIndexOf(",");
					fctIdSB.deleteCharAt(k);
					String fctIdStr = fctIdSB.toString();
				gsSql="select * from mdcategory where fileCategoryId in ("+fctIdStr+")";
			}
			gsQuery=stgSession.createSQLQuery(gsSql);
			List gfcList=gsQuery.list();
			Iterator gsIT=gfcList.iterator();
				while(gsIT.hasNext())
				{
					//MDCategory mdc=(MDCategory)gsIT.next();
					Object[] mdfcArr=(Object[])gsIT.next();
					fcatSB.append("<FileCategory>");
					fcatSB.append("\n");
					fcatSB.append("<fileCategoryId>"+(Integer) mdfcArr[0]+"</fileCategoryId>");
					fcatSB.append("\n");
					fcatSB.append("<appNameId>"+(Integer) mdfcArr[1]+"</appNameId>");
					fcatSB.append("\n");
					fcatSB.append("<infomercialTypeId>"+(String) mdfcArr[2]+"</infomercialTypeId>");
					fcatSB.append("\n");
					fcatSB.append("<fileCategoryName>"+(String) mdfcArr[3]+"</fileCategoryName>");
					fcatSB.append("\n");
					fcatSB.append("<fileType>"+(Integer) mdfcArr[4]+"</fileType>");
					fcatSB.append("\n");
					fcatSB.append("<fileNameConvention>"+(String) mdfcArr[2]+"</fileNameConvention>");
					fcatSB.append("\n");
					fcatSB.append("<folderPath>"+(String) mdfcArr[3]+"</folderPath>");
					fcatSB.append("\n");
					fcatSB.append("<status>"+(String) mdfcArr[3]+"</status>");
					fcatSB.append("\n");
					fcatSB.append("<description>"+(String) mdfcArr[5]+"</description>");
					fcatSB.append("\n");
					fcatSB.append("</FileCategory>");
					fcatSB.append("\n");
				}

			stgTx.commit();
			fcatSB.append("</FileCategories>");
			fcatSB.append("\n");

			xmlString=fcatSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Get FileCategories");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}

	@SuppressWarnings("rawtypes")
	public String getSubCategories(int PNO, int size, List <MDSubCategory> mdSubCategories,int schoolid,int branchid){

		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer catSB = new StringBuffer();
		try {
			stgTx=stgSession.beginTransaction();
			int fset = (PNO-1)*size;
			String gsSql ="select count(*) from mdsubcategory where schoolId='"+schoolid+"' and branchId='"+branchid+"'";
			Query gsQuery=stgSession.createSQLQuery(gsSql);
			Object noRecords= gsQuery.uniqueResult();
			catSB.append("<SubCategories>");
			catSB.append("\n");
			catSB.append("<noRecords>"+noRecords+"</noRecords>");
			catSB.append("\n");
			if(mdSubCategories==null){
			if (PNO > 0 & size > 0){
			gsSql="select * from mdsubcategory where schoolId='"+schoolid+"' and branchId='"+branchid+"' limit "+size+" offset "+fset; }
			else {
				gsSql="select * from mdsubcategory where schoolId='"+schoolid+"' and branchId='"+branchid+"'";
			}
			} else {
				StringBuffer sctIdSB = new StringBuffer();
				Iterator gsIdIT=mdSubCategories.iterator();
					while(gsIdIT.hasNext())
					{
						MDSubCategory mdsct=(MDSubCategory)gsIdIT.next();
						sctIdSB .append("'"+mdsct.getSubCategoryId()+"',");
					}
					int k=sctIdSB.lastIndexOf(",");
					sctIdSB.deleteCharAt(k);
					String sctIdStr = sctIdSB.toString();
				gsSql="select * from mdsubcategory where schoolId='"+schoolid+"' and branchId='"+branchid+"' and subCategoryId in ("+sctIdStr+")";
			}
			gsQuery=stgSession.createSQLQuery(gsSql);
			List gcList=gsQuery.list();
			Iterator gsIT=gcList.iterator();
				while(gsIT.hasNext())
				{
					Object[] mdscArr=(Object[])gsIT.next();
					catSB.append("<SubCategory>");
					catSB.append("\n");
					catSB.append("<subCategoryId>"+mdscArr[0]+"</subCategoryId>");
					catSB.append("\n");
					catSB.append("<subCategoryName>"+mdscArr[1]+"</subCategoryName>");
					catSB.append("\n");
					catSB.append("<categoryId>"+mdscArr[2]+"</categoryId>");
					catSB.append("\n");
					catSB.append("<subCategoryStatus>"+mdscArr[3]+"</subCategoryStatus>");
					catSB.append("\n");
					catSB.append("<description>"+mdscArr[4]+"</description>");
					catSB.append("\n");
					catSB.append("</SubCategory>");
					catSB.append("\n");
				}

			stgTx.commit();
			catSB.append("</SubCategories>");
			catSB.append("\n");

			xmlString=catSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Get Sub Categories");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}

	@SuppressWarnings("rawtypes")
	public String getLibSection(int PNO, int size, List <LibSectionPOJO> libSection,int schoolid,int branchid){
		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer catSB = new StringBuffer();
		try {
			stgTx=stgSession.beginTransaction();
			int fset = (PNO-1)*size;
			String gsSql ="select count(*) from gbl_sm_tbl_lib_section where BranchId='"+branchid+"' and SchoolId='"+schoolid+"';";
			Query gsQuery=stgSession.createSQLQuery(gsSql);
			Object noRecords= gsQuery.uniqueResult();
			catSB.append("<libsections>");
			catSB.append("\n");
			catSB.append("<noRecords>"+noRecords+"</noRecords>");
			catSB.append("\n");
			if(libSection==null){
				if (PNO > 0 & size > 0){
				gsSql="select * from gbl_sm_tbl_lib_section where BranchId='"+branchid+"' and SchoolId='"+schoolid+"'  limit "+size+" offset "+fset;}
				else {
					gsSql="select * from gbl_sm_tbl_lib_section where BranchId='"+branchid+"' and SchoolId='"+schoolid+"' ";
				}
			} else {
				StringBuffer ctIdSB = new StringBuffer();
				Iterator gsIdIT=libSection.iterator();
					while(gsIdIT.hasNext())
					{
						LibSectionPOJO mdct=(LibSectionPOJO)gsIdIT.next();
						ctIdSB .append("'"+mdct.getLibSectionId()+"',");
					}
					int k=ctIdSB.lastIndexOf(",");
					ctIdSB.deleteCharAt(k);
					String ctIdStr = ctIdSB.toString();
				gsSql="select * from gbl_sm_tbl_lib_section where BranchId='"+branchid+"' and SchoolId='"+schoolid+"' and LibSectionId in ("+ctIdStr+")";
			}
			gsQuery=stgSession.createSQLQuery(gsSql);
			List gcList=gsQuery.list();
			Iterator gsIT=gcList.iterator();
				while(gsIT.hasNext())
				{
					Object[] mdctArr=(Object[])gsIT.next();
					catSB.append("<libsection>");
					catSB.append("\n");
					catSB.append("<LibSectionId>"+mdctArr[0]+"</LibSectionId>");
					catSB.append("\n");
					catSB.append("<SectionName>"+mdctArr[1]+"</SectionName>");
					catSB.append("\n");
					catSB.append("<Status>"+mdctArr[2]+"</Status>");
					catSB.append("\n");
					catSB.append("<Description>"+mdctArr[3]+"</Description>");
					catSB.append("\n");
					catSB.append("<Remarks>"+mdctArr[4]+"</Remarks>");
					catSB.append("\n");
					catSB.append("</libsection>");
					catSB.append("\n");
				}

			stgTx.commit();
			catSB.append("</libsections>");
			catSB.append("\n");

			xmlString=catSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Get libsection ");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}



	@SuppressWarnings("rawtypes")
	public String getLibCategories(int PNO, int size, List <LibCategoryPojo> libCategory,int schoolid,int branchid){
		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer catSB = new StringBuffer();
		try {
			stgTx=stgSession.beginTransaction();
			int fset = (PNO-1)*size;
			String gsSql ="select count(*) from gbl_sm_tbl_lib_category where BranchId='"+branchid+"' and SchoolId='"+schoolid+"';";
			Query gsQuery=stgSession.createSQLQuery(gsSql);
			Object noRecords= gsQuery.uniqueResult();
			catSB.append("<libCategories>");
			catSB.append("\n");
			catSB.append("<noRecords>"+noRecords+"</noRecords>");
			catSB.append("\n");
			if(libCategory==null){
				if (PNO > 0 & size > 0){
				gsSql="select * from gbl_sm_tbl_lib_category where BranchId='"+branchid+"' and SchoolId='"+schoolid+"'  limit "+size+" offset "+fset;}
				else {
					gsSql="select * from gbl_sm_tbl_lib_category where BranchId='"+branchid+"' and SchoolId='"+schoolid+"' ";
				}
			} else {
				StringBuffer ctIdSB = new StringBuffer();
				Iterator gsIdIT=libCategory.iterator();
					while(gsIdIT.hasNext())
					{
						LibCategoryPojo mdct=(LibCategoryPojo)gsIdIT.next();
						ctIdSB .append("'"+mdct.getLibCategoryId()+"',");
					}
					int k=ctIdSB.lastIndexOf(",");
					ctIdSB.deleteCharAt(k);
					String ctIdStr = ctIdSB.toString();
				gsSql="select * from gbl_sm_tbl_lib_category where BranchId='"+branchid+"' and SchoolId='"+schoolid+"' and LibCategoryId in ("+ctIdStr+")";
			}
			gsQuery=stgSession.createSQLQuery(gsSql);
			List gcList=gsQuery.list();
			Iterator gsIT=gcList.iterator();
				while(gsIT.hasNext())
				{
					Object[] mdctArr=(Object[])gsIT.next();
					catSB.append("<LibCategory>");
					catSB.append("\n");
					catSB.append("<LibCategoryId>"+mdctArr[0]+"</LibCategoryId>");
					catSB.append("\n");
					catSB.append("<CategoryName>"+mdctArr[1]+"</CategoryName>");
					catSB.append("\n");
					catSB.append("<Description>"+mdctArr[2]+"</Description>");
					catSB.append("\n");
					catSB.append("<Remarks>"+mdctArr[3]+"</Remarks>");
					catSB.append("\n");
					catSB.append("</LibCategory>");
					catSB.append("\n");
				}

			stgTx.commit();
			catSB.append("</libCategories>");
			catSB.append("\n");

			xmlString=catSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Get libcategory info ");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}

	@SuppressWarnings("rawtypes")
	public String getTagTypes(int PNO, int size, List<MDTagType> mdTagTypes){

		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer catSB = new StringBuffer();
		try {
			stgTx=stgSession.beginTransaction();
			int fset = (PNO-1)*size;
			String gsSql ="select count(*) from mdtagtype";
			Query gsQuery=stgSession.createSQLQuery(gsSql);
			Object noRecords= gsQuery.uniqueResult();
			catSB.append("<TagTypes>");
			catSB.append("\n");
			catSB.append("<noRecords>"+noRecords+"</noRecords>");
			catSB.append("\n");
			if (mdTagTypes==null){
				if (PNO > 0 & size > 0){
				gsSql="select * from mdtagtype limit "+size+" offset "+fset;}
				else {
					gsSql="select * from mdtagtype";
				}
			} else {
				StringBuffer ttIdSB = new StringBuffer();
				Iterator gsIdIT=mdTagTypes.iterator();
				while(gsIdIT.hasNext())
				{
						MDTagType mdtt=(MDTagType)gsIdIT.next();
						ttIdSB .append("'"+mdtt.getTagTypeId()+"',");
					}
					int k=ttIdSB.lastIndexOf(",");
					ttIdSB.deleteCharAt(k);
					String ttIdStr = ttIdSB.toString();
				gsSql="select * from mdtagtype where tagtypeid in ("+ttIdStr+")";
			}
			gsQuery=stgSession.createSQLQuery(gsSql);
			List gcList=gsQuery.list();
			Iterator gsIT=gcList.iterator();
				while(gsIT.hasNext())
				{
					Object[] mdttArr=(Object[])gsIT.next();
					catSB.append("<TagType>");
					catSB.append("\n");
					catSB.append("<tagTypeId>"+mdttArr[0]+"</tagTypeId>");
					catSB.append("\n");
					catSB.append("<tagTypeName>"+mdttArr[1]+"</tagTypeName>");
					catSB.append("\n");
					catSB.append("<tagTypeCode>"+mdttArr[2]+"</tagTypeCode>");
					catSB.append("\n");
					catSB.append("<priority>"+mdttArr[3]+"</priority>");
					catSB.append("\n");
					catSB.append("<tagTypeStatus>"+mdttArr[4]+"</tagTypeStatus>");
					catSB.append("\n");
					catSB.append("<description>"+mdttArr[5]+"</description>");
					catSB.append("\n");
					catSB.append("</TagType>");
					catSB.append("\n");
				}

			stgTx.commit();
			catSB.append("</TagTypes>");
			catSB.append("\n");

			xmlString=catSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Get Tag Types");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}

	@SuppressWarnings("rawtypes")
	public String getTemplateTypes(int PNO, int size, List<MDTemplateType> mdTemplateTypes){

		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer catSB = new StringBuffer();
		try {
			stgTx=stgSession.beginTransaction();
			int fset = (PNO-1)*size;
			String gsSql ="select count(*) from mdtemplatetype";
			Query gsQuery=stgSession.createSQLQuery(gsSql);
			Object noRecords= gsQuery.uniqueResult();
			catSB.append("<TemplateTypes>");
			catSB.append("\n");
			catSB.append("<noRecords>"+noRecords+"</noRecords>");
			catSB.append("\n");
			if (mdTemplateTypes==null){
				if (PNO > 0 & size > 0){
				gsSql="select * from mdtemplatetype limit "+size+" offset "+fset;}
				else {
					gsSql="select * from mdtemplatetype";
				}
			} else {
				StringBuffer ttIdSB = new StringBuffer();
				Iterator gsIdIT=mdTemplateTypes.iterator();
				while(gsIdIT.hasNext())
				{
						MDTemplateType mdtt=(MDTemplateType)gsIdIT.next();
						ttIdSB .append("'"+mdtt.getTemplateTypeId()+"',");
					}
					int k=ttIdSB.lastIndexOf(",");
					ttIdSB.deleteCharAt(k);
					String ttIdStr = ttIdSB.toString();
				gsSql="select * from mdtemplatetype where templatetypeid in ("+ttIdStr+")";
			}
			gsQuery=stgSession.createSQLQuery(gsSql);
			List gcList=gsQuery.list();
			Iterator gsIT=gcList.iterator();
				while(gsIT.hasNext())
				{
					Object[] mdttArr=(Object[])gsIT.next();
					catSB.append("<TemplateType>");
					catSB.append("\n");
					catSB.append("<templateTypeId>"+mdttArr[0]+"</templateTypeId>");
					catSB.append("\n");
					catSB.append("<templateTypeName>"+mdttArr[1]+"</templateTypeName>");
					catSB.append("\n");
					catSB.append("<templateTypeCode>"+mdttArr[2]+"</templateTypeCode>");
					catSB.append("\n");
					catSB.append("<templateTypeStatus>"+mdttArr[3]+"</templateTypeStatus>");
					catSB.append("\n");
					catSB.append("<description>"+mdttArr[4]+"</description>");
					catSB.append("\n");
					catSB.append("</TemplateType>");
					catSB.append("\n");
				}

			stgTx.commit();
			catSB.append("</TemplateTypes>");
			catSB.append("\n");

			xmlString=catSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Get Template Types");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}

	@SuppressWarnings("rawtypes")
	public String getInfomercialTypes(int PNO, int size, List<MDInfomercialType> mdInfomercialTypes){

		String xmlString=null;
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction stgTx=null;
		StringBuffer catSB = new StringBuffer();
		try {
			stgTx=stgSession.beginTransaction();
			int fset = (PNO-1)*size;
			String gsSql ="select count(*) from mdinfomercialtype";
			Query gsQuery=stgSession.createSQLQuery(gsSql);
			Object noRecords= gsQuery.uniqueResult();
			catSB.append("<InfomercialTypes>");
			catSB.append("\n");
			catSB.append("<noRecords>"+noRecords+"</noRecords>");
			catSB.append("\n");
			if (mdInfomercialTypes==null){
				if (PNO > 0 & size > 0){
				gsSql="select * from mdinfomercialtype limit "+size+" offset "+fset;}
				else {
					gsSql="select * from mdinfomercialtype";
				}
			} else {
				StringBuffer ttIdSB = new StringBuffer();
				Iterator gsIdIT=mdInfomercialTypes.iterator();
				while(gsIdIT.hasNext())
				{
					MDInfomercialType mdtt=(MDInfomercialType)gsIdIT.next();
						ttIdSB .append("'"+mdtt.getInfomercialTypeId()+"',");
					}
					int k=ttIdSB.lastIndexOf(",");
					ttIdSB.deleteCharAt(k);
					String ttIdStr = ttIdSB.toString();
				gsSql="select * from mdinfomercialtype where infomercialtypeid in ("+ttIdStr+")";
			}
			gsQuery=stgSession.createSQLQuery(gsSql);
			List gcList=gsQuery.list();
			Iterator gsIT=gcList.iterator();
				while(gsIT.hasNext())
				{
					Object[] mdttArr=(Object[])gsIT.next();
					catSB.append("<InfomercialType>");
					catSB.append("\n");
					catSB.append("<infomercialTypeId>"+mdttArr[0]+"</infomercialTypeId>");
					catSB.append("\n");
					catSB.append("<infomercialTypeName>"+mdttArr[1]+"</infomercialTypeName>");
					catSB.append("\n");
					catSB.append("<infomercialTypeCode>"+mdttArr[2]+"</infomercialTypeCode>");
					catSB.append("\n");
					catSB.append("<infomercialTypeStatus>"+mdttArr[3]+"</infomercialTypeStatus>");
					catSB.append("\n");
					catSB.append("<description>"+mdttArr[4]+"</description>");
					catSB.append("\n");
					catSB.append("</InfomercialType>");
					catSB.append("\n");
				}

			stgTx.commit();
			catSB.append("</InfomercialTypes>");
			catSB.append("\n");

			xmlString=catSB.toString();
		}
		catch(Exception localException)
		{
			stgTx.rollback();
			localException.printStackTrace();
			xmlString = "fail";
			System.out.println("Could not Get Infomercial Types");
		}
		finally
		{
			stgSession.close();
		}
	 return xmlString;
	}


	public String getSettingsByIds(MDSetting mdSetting,int schoolid,int branchid) {

			String xmlString=null;
			StringBuffer settgsSB = new StringBuffer();
			try
			{
				settgsSB.append("<MD_Settings>");
				settgsSB.append("\n");

				List<AssessmentTypePojo> assessmenttype = mdSetting.getAssessmenttype();
				if (assessmenttype.size()!=0) {
				xmlString=getAssessmentType(0, 0 , assessmenttype,schoolid, branchid);
				settgsSB.append(xmlString);
				settgsSB.append("\n");
				}
				else {
					System.out.println("Empty List of assessmenttype");
				}

				List<AssessmentModePojo> assessmentmode = mdSetting.getAssessmentmode();
				if (assessmentmode.size()!=0) {
				xmlString=getAssessmentMode(0, 0 , assessmentmode,schoolid, branchid);
				settgsSB.append(xmlString);
				settgsSB.append("\n");
				}
				else {
					System.out.println("Empty List of assessmentmode");
				}

				List<RoomType> roomtype = mdSetting.getRoomtype();
				if (roomtype.size()!=0) {
				xmlString=getRoomType(0, 0 , roomtype,schoolid, branchid);
				settgsSB.append(xmlString);
				settgsSB.append("\n");
				}
				else {
					System.out.println("Empty List of roomtype");
				}

               List<CastesPojo> castes = mdSetting.getCastes();
				if (castes.size()!=0) {
				xmlString=getCastes(0, 0 , castes,schoolid, branchid);
				settgsSB.append(xmlString);
				settgsSB.append("\n");
				}
				else {
					System.out.println("Empty List of castes");
				}

				List<ReligionPojo> religions = mdSetting.getReligions();
				if (religions.size()!=0) {
				xmlString=getReligions(0, 0 , religions,schoolid, branchid);
				settgsSB.append(xmlString);
				settgsSB.append("\n");
				}
				else {
					System.out.println("Empty List of religions");
				}


				List<JobtypePojo> jobtypes = mdSetting.getJobtypes();
				if (jobtypes.size()!=0) {
				xmlString=getJobtypes(0, 0 , jobtypes,schoolid, branchid);
				settgsSB.append(xmlString);
				settgsSB.append("\n");
				}
				else {
					System.out.println("Empty List of Jobtypes");
				}

				List<JobtitlePojo> Jobtitles = mdSetting.getJobtitles();
				if (Jobtitles.size()!=0) {
				xmlString=getJobtitles(0, 0 , Jobtitles,schoolid, branchid);
				settgsSB.append(xmlString);
				settgsSB.append("\n");
				}
				else {
					System.out.println("Empty List of Jobtitles");
				}

				List<AccoladetypePojo> Accoladetypes = mdSetting.getAccolades();
				if (Accoladetypes.size()!=0) {
				xmlString=getaccolades(0, 0 , Accoladetypes,schoolid, branchid);
				settgsSB.append(xmlString);
				settgsSB.append("\n");
				}
				else {
					System.out.println("Empty List of accolades");
				}

				List<ResultPojo> Results = mdSetting.getResults();
				if (Results.size()!=0) {
				xmlString=getresults(0, 0 , Results,schoolid, branchid);
				settgsSB.append(xmlString);
				settgsSB.append("\n");
				}
				else {
					System.out.println("Empty List of Results");
				}

				List<LibSectionPOJO> libsection = mdSetting.getSection();
				if (libsection.size()!=0) {
				xmlString=getLibSection(0, 0 ,libsection,schoolid, branchid);
				settgsSB.append(xmlString);
				settgsSB.append("\n");
				}
				else {
					System.out.println("Empty List of libsection");
				}
				List<LibCategoryPojo> libcategories = mdSetting.getLibcategory();
				if (libcategories.size()!=0) {
				xmlString=getLibCategories(0, 0 ,libcategories,schoolid, branchid);
				settgsSB.append(xmlString);
				settgsSB.append("\n");
				}
				else {
					System.out.println("Empty List of libcategories");
				}
				List<SubjectType> subjecttype = mdSetting.getSubjecttype();
			    if (subjecttype.size()!=0) {
			    xmlString=getSubjectTypes(0, 0 , subjecttype,schoolid,branchid);
			    settgsSB.append(xmlString);
			    settgsSB.append("\n");
			    }
			    else {
			     System.out.println("Empty List of subjecttype");
			    }

				//fee...
				List<EventTypePojo> eventtypes = mdSetting.getEventtypes();
				if (eventtypes.size()!=0) {
				xmlString=getEventTypes(0, 0 , eventtypes,schoolid, branchid);
				settgsSB.append(xmlString);
				settgsSB.append("\n");
				}
				else {
					System.out.println("Empty List of eventtypes");
				}


				List<FeeItemType> feeitemtypes = mdSetting.getFeeitemtypes();
				if (feeitemtypes.size()!=0) {
				xmlString=getFeeItemTypes(0, 0 , feeitemtypes,schoolid, branchid);
				settgsSB.append(xmlString);
				settgsSB.append("\n");
				}
				else {
					System.out.println("Empty List of feeitemtypes");
				}

				List<BookTypePOJO> booktypes = mdSetting.getBooktypes();
				if (booktypes.size()!=0) {
				xmlString=getBookTypes(0, 0 , booktypes,schoolid, branchid);
				settgsSB.append(xmlString);
				settgsSB.append("\n");
				}
				else {
					System.out.println("Empty List of booktypes");
				}

				List<QuestionType> questiontypes = mdSetting.getQuestiontypes();
				if (questiontypes.size()!=0) {
				xmlString=getQuestionTypes(0, 0 , questiontypes,schoolid, branchid);
				settgsSB.append(xmlString);
				settgsSB.append("\n");
				}
				else {
					System.out.println("Empty List of questiontypes");
				}

				List<PaymentModePojo> paymentmodes = mdSetting.getPaymentmodes();
				if (paymentmodes.size()!=0) {
				xmlString=getPaymentModes(0, 0 , paymentmodes,schoolid, branchid);
				settgsSB.append(xmlString);
				settgsSB.append("\n");
				}
				else {
					System.out.println("Empty List of paymentmodes");
				}


				List<MDCategory> categories = mdSetting.getCategories();
				if (categories.size()!=0) {
				xmlString=getCategories(0, 0 ,categories,schoolid,branchid);
				settgsSB.append(xmlString);
				settgsSB.append("\n");
				}
				else {
					System.out.println("Empty List of Categories");
				}
				List<MDSubCategory> subCategories = mdSetting.getSubCategories();
				if (subCategories.size()!=0) {
				xmlString=getSubCategories(0,0,subCategories,schoolid,branchid);
				settgsSB.append(xmlString);
				settgsSB.append("\n");
				}
				else {
					System.out.println("Empty List of Sub Categories");
				}
				List<MDCategoryType> categoryTypes = mdSetting.getCategoryTypes();
				if (categoryTypes.size()!=0) {
				xmlString=getCategoryTypes(0,0,categoryTypes);
				settgsSB.append(xmlString);
				settgsSB.append("\n");
				}
				else {
					System.out.println("Empty List of CategoryTypes");
				}
				List<MDTagType> tagTypes = mdSetting.getTagTypes();
				if (tagTypes.size()!=0) {
				xmlString=getTagTypes(0,0,tagTypes);
				settgsSB.append(xmlString);
				settgsSB.append("\n");
				}
				else {
					System.out.println("Empty List of TagTypes");
				}
				List<MDTemplateType> templateTypes = mdSetting.getTemplateTypes();
				if (templateTypes.size()!=0) {
				xmlString=getTemplateTypes(0,0,templateTypes);
				settgsSB.append(xmlString);
				settgsSB.append("\n");
				}
				else {
					System.out.println("Empty List of TemplateTypes");
				}
				List<MDInfomercialType> infomercialTypes = mdSetting.getInfomercialTypes();
				if (infomercialTypes.size()!=0) {
				xmlString=getInfomercialTypes(0,0,infomercialTypes);
				settgsSB.append(xmlString);
				settgsSB.append("\n");
				}
				else {
					System.out.println("Empty List of InfomercialTypes");
				}
				List<MDFileCategory> fileCategories = mdSetting.getFileCategories();
				if (fileCategories.size()!=0) {
				xmlString=getFileCategories(0,0,fileCategories);
				settgsSB.append(xmlString);
				settgsSB.append("\n");
				}
				else {
					System.out.println("Empty List of File Categories");
				}
			settgsSB.append("</MD_Settings>");
			settgsSB.append("\n");
			xmlString=settgsSB.toString();
			}
			catch(Exception localException)
			{
				MDTransactionWriter.exceptionlog.info(localException);
				xmlString="fail";
			}
			finally
			{

			}
			return xmlString;
		}

	public String delSettings(MDSetting mdSetting) {

		return null;
	}


}
