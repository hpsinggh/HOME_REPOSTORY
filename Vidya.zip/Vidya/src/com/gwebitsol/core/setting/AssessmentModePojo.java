package com.gwebitsol.core.setting;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="AssessmentMode")
public class AssessmentModePojo {
	private int assessmentModeId;
	private String modeName;
	private String description;
	private int schoolId;
	private int branchId;
	
	public int getAssessmentModeId() {
		return assessmentModeId;
	}
	public void setAssessmentModeId(int assessmentModeId) {
		this.assessmentModeId = assessmentModeId;
	}
	public String getModeName() {
		return modeName;
	}
	public void setModeName(String modeName) {
		this.modeName = modeName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getSchoolId() {
		return schoolId;
	}
	public void setSchoolId(int schoolId) {
		this.schoolId = schoolId;
	}
	public int getBranchId() {
		return branchId;
	}
	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}
}
