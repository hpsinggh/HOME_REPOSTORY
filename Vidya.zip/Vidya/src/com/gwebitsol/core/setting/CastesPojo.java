package com.gwebitsol.core.setting;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

@SuppressWarnings("serial")
	@XmlRootElement(name="Caste")
	public class CastesPojo implements Serializable{

		int castId;
		String castGroup;
		String castName;
		String descrption;
		int branchId;
		int schoolId;
		
		public int getBranchId() {
			return branchId;
		}
		public void setBranchId(int branchId) {
			this.branchId = branchId;
		}
		public int getSchoolId() {
			return schoolId;
		}
		public void setSchoolId(int schoolId) {
			this.schoolId = schoolId;
		}
		public int getCastId() {
			return castId;
		}
		public void setCastId(int castId) {
			this.castId = castId;
		}
		public String getCastGroup() {
			return castGroup;
		}
		public void setCastGroup(String castGroup) {
			this.castGroup = castGroup;
		}
		public String getCastName() {
			return castName;
		}
		public void setCastName(String castName) {
			this.castName = castName;
		}
		public String getDescrption() {
			return descrption;
		}
		public void setDescrption(String descrption) {
			this.descrption = descrption;
		}

}
