
package com.gwebitsol.core.setting;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

@Path("/settings/")
public interface MDSettingManagementServiceIntf {
	@POST
	@Consumes({ "application/xml", "application/json" })
	@Produces({ "application/xml", "application/json" })
	@Path("/add")
	public Response addSettings(MDSetting mdSetting, @QueryParam("userid") int userid,
			@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
			@QueryParam("schoolid") int schoolid,@QueryParam("branchid") int branchid);

	@POST
	@Consumes({ "application/xml", "application/json" })
	@Produces({ "application/xml", "application/json" })
	@Path("/update")
	public Response updateSettings(MDSetting mdSetting, @QueryParam("userid") int userid,
			@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
			@QueryParam("schoolid") int schoolid,@QueryParam("branchid") int branchid);

	@POST
	@Consumes({ "application/xml", "application/json" })
	@Produces({ "application/xml", "application/json" })
	@Path("/delete")
	public Response delSettings(MDSetting mdSetting, @QueryParam("userid") int userid,
			@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
			@QueryParam("schoolid") int schoolid,@QueryParam("branchid") int branchid);

	@GET
	@Produces({ "application/xml", "application/json" })
	@Path("/getall")
	public Response getSettings(@QueryParam("userid") int userid, @QueryParam("connectionid") int connectionid,
			@QueryParam("datastoreName") String datastoreName, @QueryParam("PNO") int PNO, @QueryParam("size") int size,
			@QueryParam("settings") String settings, @QueryParam("schoolid") int schoolid,@QueryParam("branchid") int branchid);

	@POST
	@Consumes({ "application/xml", "application/json" })
	@Produces({ "application/xml", "application/json" })
	@Path("/getByIds")
	public Response getSettingsByIds(MDSetting mdSetting, @QueryParam("userid") int userid,
			@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
			@QueryParam("schoolid") int schoolid,@QueryParam("branchid") int branchid);

}
