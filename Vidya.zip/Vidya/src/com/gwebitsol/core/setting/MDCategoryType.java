package com.gwebitsol.core.setting;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

@SuppressWarnings("serial")
@XmlRootElement(name="CategoryType")
public class MDCategoryType implements Serializable {
	
	private int categoryTypeId;
	private String categoryTypeName;
	private String categoryTypeStatus;
	private int priority;
	private String description;
	
	public int getCategoryTypeId() {
		return categoryTypeId;
	}
	public void setCategoryTypeId(int categoryTypeId) {
		this.categoryTypeId = categoryTypeId;
	}
	public String getCategoryTypeName() {
		return categoryTypeName;
	}
	public void setCategoryTypeName(String categoryTypeName) {
		this.categoryTypeName = categoryTypeName;
	}
	public String getCategoryTypeStatus() {
		return categoryTypeStatus;
	}
	public void setCategoryTypeStatus(String categoryTypeStatus) {
		this.categoryTypeStatus = categoryTypeStatus;
	}
	public int getPriority() {
		return priority;
	}
	public void setPriority(int priority) {
		this.priority = priority;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
}
