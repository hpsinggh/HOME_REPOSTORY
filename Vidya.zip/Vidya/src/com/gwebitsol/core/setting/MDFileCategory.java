package com.gwebitsol.core.setting;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

@SuppressWarnings("serial")
@XmlRootElement(name="FileCategory")

public class MDFileCategory implements Serializable {
	
	private int fileCategoryId;
	private int appNameId;
	private int infomercialTypeId;
	private String fileCategoryName;
	private String fileType;
	private String fileNameConvention;
	private String folderPath;
	private String status;
	private String description;
	
	public int getFileCategoryId() {
		return fileCategoryId;
	}
	public void setFileCategoryId(int fileCategoryId) {
		this.fileCategoryId = fileCategoryId;
	}
	public int getAppNameId() {
		return appNameId;
	}
	public void setAppNameId(int appNameId) {
		this.appNameId = appNameId;
	}
	public int getInfomercialTypeId() {
		return infomercialTypeId;
	}
	public void setInfomercialTypeId(int infomercialTypeId) {
		this.infomercialTypeId = infomercialTypeId;
	}
	public String getFileCategoryName() {
		return fileCategoryName;
	}
	public void setFileCategoryName(String fileCategoryName) {
		this.fileCategoryName = fileCategoryName;
	}
	public String getFileType() {
		return fileType;
	}
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	public String getFileNameConvention() {
		return fileNameConvention;
	}
	public void setFileNameConvention(String fileNameConvention) {
		this.fileNameConvention = fileNameConvention;
	}
	public String getFolderPath() {
		return folderPath;
	}
	public void setFolderPath(String folderPath) {
		this.folderPath = folderPath;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
}
