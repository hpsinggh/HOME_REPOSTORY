package com.gwebitsol.core.setting;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

@SuppressWarnings("serial")
	@XmlRootElement(name="Religion")
	public class ReligionPojo implements Serializable{

		int religionId;
		String religionName;
		String description;
		int branchId;
		int schoolId;
		
		
		public int getBranchId() {
			return branchId;
		}
		public void setBranchId(int branchId) {
			this.branchId = branchId;
		}
		public int getSchoolId() {
			return schoolId;
		}
		public void setSchoolId(int schoolId) {
			this.schoolId = schoolId;
		}
		public int getReligionId() {
			return religionId;
		}
		public void setReligionId(int religionId) {
			this.religionId = religionId;
		}
		public String getReligionName() {
			return religionName;
		}
		public void setReligionName(String religionName) {
			this.religionName = religionName;
		}
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}

		
		
	}


