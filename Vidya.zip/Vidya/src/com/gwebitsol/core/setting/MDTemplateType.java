package com.gwebitsol.core.setting;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

@SuppressWarnings("serial")
@XmlRootElement(name="templateType")

public class MDTemplateType implements Serializable {
	
	private int templateTypeId;
	private String templateTypeName;
	private String templateTypeCode;
	private String templateTypeStatus;
	private String description;
	
	public int getTemplateTypeId() {
		return templateTypeId;
	}
	public void setTemplateTypeId(int templateTypeId) {
		this.templateTypeId = templateTypeId;
	}
	public String getTemplateTypeName() {
		return templateTypeName;
	}
	public void setTemplateTypeName(String templateTypeName) {
		this.templateTypeName = templateTypeName;
	}
	public String getTemplateTypeCode() {
		return templateTypeCode;
	}
	public void setTemplateTypeCode(String templateTypeCode) {
		this.templateTypeCode = templateTypeCode;
	}
	public String getTemplateTypeStatus() {
		return templateTypeStatus;
	}
	public void setTemplateTypeStatus(String templateTypeStatus) {
		this.templateTypeStatus = templateTypeStatus;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
}
