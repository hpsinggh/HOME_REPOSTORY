package com.gwebitsol.core.setting;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="FeeItemType")
public class FeeItemType {
	private int feeItemTypeId;
	private String name;
	private String description;
	private String frequencyName;
	private int installmentsInYear;
	private int schoolId;
	private int branchId;
	public int getSchoolId() {
		return schoolId;
	}
	public void setSchoolId(int schoolId) {
		this.schoolId = schoolId;
	}
	public int getBranchId() {
		return branchId;
	}
	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}
	public int getFeeItemTypeId() {
		return feeItemTypeId;
	}
	public void setFeeItemTypeId(int feeItemTypeId) {
		this.feeItemTypeId = feeItemTypeId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getFrequencyName() {
		return frequencyName;
	}
	public void setFrequencyName(String frequencyName) {
		this.frequencyName = frequencyName;
	}
	public int getInstallmentsInYear() {
		return installmentsInYear;
	}
	public void setInstallmentsInYear(int installmentsInYear) {
		this.installmentsInYear = installmentsInYear;
	}
	
}
