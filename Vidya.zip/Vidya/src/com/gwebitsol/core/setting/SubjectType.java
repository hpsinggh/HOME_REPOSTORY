package com.gwebitsol.core.setting;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="SubjectType")
	public class SubjectType {
	 private int subjectTypeId;
	 private String subjectName;
	 private String description;
	 private int schoolId;
	 private int branchId;
	 
	 public int getSubjectTypeId() {
	  return subjectTypeId;
	 }
	 public void setSubjectTypeId(int subjectTypeId) {
	  this.subjectTypeId = subjectTypeId;
	 }
	 public String getSubjectName() {
	  return subjectName;
	 }
	 public void setSubjectName(String subjectName) {
	  this.subjectName = subjectName;
	 }
	 public String getDescription() {
	  return description;
	 }
	 public void setDescription(String description) {
	  this.description = description;
	 }
	 public int getSchoolId() {
	  return schoolId;
	 }
	 public void setSchoolId(int schoolId) {
	  this.schoolId = schoolId;
	 }
	 public int getBranchId() {
	  return branchId;
	 }
	 public void setBranchId(int branchId) {
	  this.branchId = branchId;
	 }
	}

