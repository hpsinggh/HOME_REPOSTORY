package com.gwebitsol.core.setting;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

@SuppressWarnings("serial")
@XmlRootElement(name="InfomercialType")

public class MDInfomercialType implements Serializable {
	
	private int infomercialTypeId;
	private String infomercialTypeName;
	private String infomercialTypeCode;
	private String infomercialTypeStatus;
	private int priority;
	private String description;
	
	public int getInfomercialTypeId() {
		return infomercialTypeId;
	}
	public void setInfomercialTypeId(int infomercialTypeId) {
		this.infomercialTypeId = infomercialTypeId;
	}
	public String getInfomercialTypeName() {
		return infomercialTypeName;
	}
	public void setInfomercialTypeName(String infomercialTypeName) {
		this.infomercialTypeName = infomercialTypeName;
	}
	public String getInfomercialTypeCode() {
		return infomercialTypeCode;
	}
	public void setInfomercialTypeCode(String infomercialTypeCode) {
		this.infomercialTypeCode = infomercialTypeCode;
	}
	public String getInfomercialTypeStatus() {
		return infomercialTypeStatus;
	}
	public void setInfomercialTypeStatus(String infomercialTypeStatus) {
		this.infomercialTypeStatus = infomercialTypeStatus;
	}
	public int getPriority() {
		return priority;
	}
	public void setPriority(int priority) {
		this.priority = priority;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}

	
}
