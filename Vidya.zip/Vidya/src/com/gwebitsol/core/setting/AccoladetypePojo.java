package com.gwebitsol.core.setting;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

@SuppressWarnings("serial")
@XmlRootElement(name="Accoladetype")
public class AccoladetypePojo implements Serializable {
	
	int accoladeTypeId;
	String typeName;
	String description;
	int branchId;
	int schoolId;
	
	public int getAccoladeTypeId() {
		
		return accoladeTypeId;
	}
	public void setAccoladeTypeId(int accoladeTypeId) {
		this.accoladeTypeId = accoladeTypeId;
	}
	public String getTypeName() {
		return typeName;
	}
	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getBranchId() {
		return branchId;
	}
	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}
	public int getSchoolId() {
		return schoolId;
	}
	public void setSchoolId(int schoolId) {
		this.schoolId = schoolId;
	}
	

}
