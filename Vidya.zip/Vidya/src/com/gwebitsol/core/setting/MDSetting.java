package com.gwebitsol.core.setting;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;


@SuppressWarnings("serial")
@XmlRootElement(name="MD_Settings")

public class MDSetting implements Serializable {
	
	private MDSettingWrapper wrapper = new MDSettingWrapper();
	
	public MDSettingWrapper getWrapper() {
		return wrapper;
	}
	
	public void setWrapper(MDSettingWrapper wrapper) {
		this.wrapper = wrapper;
	}
	
	@XmlElementWrapper(name="Categories")
    @XmlElement(name="Category")
    public List<MDCategory> getCategories() {
        return wrapper.getCategories();
    }

    public void setCategories(List<MDCategory> categories) {
        wrapper.setCategories(categories);
    }
    
	@XmlElementWrapper(name="SubCategories")
    @XmlElement(name="SubCategory")
    public List<MDSubCategory> getSubCategories() {
        return wrapper.getSubCategories();
    }

    public void setSubCategories(List<MDSubCategory> subCategories) {
        wrapper.setSubCategories(subCategories);
    }
    
	@XmlElementWrapper(name="CategoryTypes")
    @XmlElement(name="CategoryType")
    public List<MDCategoryType> getCategoryTypes() {
        return wrapper.getCategoryTypes();
    }

    public void setCategoryTypes(List<MDCategoryType> categoryTypes) {
        wrapper.setCategoryTypes(categoryTypes);
    }
    
	@XmlElementWrapper(name="TagTypes")
    @XmlElement(name="TagType")
    public List<MDTagType> getTagTypes() {
        return wrapper.getTagTypes();
    }

    public void setTagTypes(List<MDTagType> tagTypes) {
        wrapper.setTagTypes(tagTypes);
    }
    
	@XmlElementWrapper(name="TemplateTypes")
    @XmlElement(name="TemplateType")
    public List<MDTemplateType> getTemplateTypes() {
        return wrapper.getTemplateTypes();
    }

    public void setTemplateTypes(List<MDTemplateType> templateTypes) {
        wrapper.setTemplateTypes(templateTypes);
    }
    
	@XmlElementWrapper(name="InfomercialTypes")
    @XmlElement(name="InfomercialType")
    public List<MDInfomercialType> getInfomercialTypes() {
        return wrapper.getInfomercialTypes();
    }

    public void setInfomercialTypes(List<MDInfomercialType> infomercialTypes) {
        wrapper.setInfomercialTypes(infomercialTypes);
    }
    
	@XmlElementWrapper(name="FileCategories")
    @XmlElement(name="FileCategory")
    public List<MDFileCategory> getFileCategories() {
        return wrapper.getFileCategories();
    }
	
    public void setFileCategories(List<MDFileCategory> fileCategories) {
        wrapper.setFileCategories(fileCategories);
    }
    
    
    @XmlElementWrapper(name="Accoladetypes")
    @XmlElement(name="Accoladetype")
	public List<AccoladetypePojo> getAccolades() {
		return wrapper.getAccolades();
	}
	public void setAccolades(List<AccoladetypePojo> accolades) {
		wrapper.setAccolades(accolades);
	}
	
	@XmlElementWrapper(name="Jobtitles")
    @XmlElement(name="Jobtitle")
	
	public List<JobtitlePojo> getJobtitles() {
		return wrapper.getJobtitles();
	}
	public void setJobtitles(List<JobtitlePojo> jobtitles) {
		 wrapper.setJobtitles(jobtitles);
	}
	
	@XmlElementWrapper(name="Jobtypes")
    @XmlElement(name="Jobtype")
	public List<JobtypePojo> getJobtypes() {
		return wrapper.getJobtypes();
	}
	public void setJobtypes(List<JobtypePojo> jobtypes) {
		wrapper.setJobtypes(jobtypes);
	}
	
	@XmlElementWrapper(name="Results")
    @XmlElement(name="Result")
	public List<ResultPojo> getResults() {
		return wrapper.getResults();
	}
	public void setResults(List<ResultPojo> results) {
	   wrapper.setResults(results);
	}
	@XmlElementWrapper(name="libsections")
	 @XmlElement(name="libsection")
	public List<LibSectionPOJO> getSection() {
		return wrapper.getSection();
	}
	public void setSection(List<LibSectionPOJO> section) {
		wrapper.setSection(section);
	}
	
	@XmlElementWrapper(name="libCategorys")
	 @XmlElement(name="libCategory")
	public List<LibCategoryPojo> getLibcategory() {
		return wrapper.getLibcategory();
	}
	public void setLibcategory(List<LibCategoryPojo> libcategory) {
		wrapper.setLibcategory(libcategory);
	}
	
	
	@XmlElementWrapper(name="EventTypes")
	@XmlElement(name="EventType")
	public List<EventTypePojo> getEventtypes() {
		return wrapper.getEventtypes();
	}
	public void setEventtypes(List<EventTypePojo> eventtypes) {
			wrapper.setEventtypes(eventtypes);
	}
	
	
	
	@XmlElementWrapper(name="FeeItemTypes")
	@XmlElement(name="FeeItemType")
	public List<FeeItemType> getFeeitemtypes() {
		return wrapper.getFeeitemtypes();
	}
	public void setFeeitemtypes(List<FeeItemType> feeitemtypes) {
		wrapper.setFeeitemtypes(feeitemtypes);
	}
	
	@XmlElementWrapper(name="BookTypes")
	@XmlElement(name="BookType")
	public List<BookTypePOJO> getBooktypes() {
		return wrapper.getBooktypes();
	}
	public void setBooktypes(List<BookTypePOJO> booktypes) {
		wrapper.setBooktypes(booktypes);
	}
	
	
	@XmlElementWrapper(name="QuestionTypes")
	@XmlElement(name="QuestionType")
	public List<QuestionType> getQuestiontypes() {
		return wrapper.getQuestiontypes();
	}
	public void setQuestiontypes(List<QuestionType> questiontypes) {
		wrapper.setQuestiontypes(questiontypes);
	}
	
	@XmlElementWrapper(name="PaymentModes")
	@XmlElement(name="PaymentMode")
	public List<PaymentModePojo> getPaymentmodes() {
		return wrapper.getPaymentmodes();
	}
	public void setPaymentmodes(List<PaymentModePojo> paymentmodes) {
		wrapper.setPaymentmodes(paymentmodes);
	}
	

	@XmlElementWrapper(name="AssessmentModes")
    @XmlElement(name="AssessmentMode")
	public List<AssessmentModePojo> getAssessmentmode() {
		return wrapper.getAssessmentmode();
	}
	public void setAssessmentmode(List<AssessmentModePojo> assessmentmode){
		wrapper.setAssessmentmode(assessmentmode);
	}

	@XmlElementWrapper(name="AssessmentTypes")
    @XmlElement(name="AssessmentType")
	public List<AssessmentTypePojo> getAssessmenttype() {
		return wrapper.getAssessmenttype();
	}
	public void setAssessmenttype(List<AssessmentTypePojo> assessmenttype){
		wrapper.setAssessmenttype(assessmenttype);
	}
	
	@XmlElementWrapper(name="RoomTypes")
    @XmlElement(name="RoomType")
	public List<RoomType> getRoomtype() {
		return wrapper.getRoomtype();
	}
	public void setRoomtype(List<RoomType> roomtype){
		wrapper.setRoomtype(roomtype);
		
	}
	
	@XmlElementWrapper(name="SubjectTypes")
    @XmlElement(name="SubjectType")
 public List<SubjectType> getSubjecttype() {
  return wrapper.getSubjecttypes();
 }
 public void setSubjectType(List<SubjectType> subjecttype){
  wrapper.setSubjecttypes(subjecttype);
  
 }
 @XmlElementWrapper(name="Castes")
 @XmlElement(name="Caste")
public List<CastesPojo> getCastes() {
     return wrapper.getCastes();
 }

public void setCastes(List<CastesPojo> castes) {
     wrapper.setCastes(castes);
 }

 @XmlElementWrapper(name="Religions")
 @XmlElement(name="Religion")
 public List<ReligionPojo> getReligions() {
     return wrapper.getReligions();
 }

 public void setReligions(List<ReligionPojo> religions) {
     wrapper.setReligions(religions);
 }
}
