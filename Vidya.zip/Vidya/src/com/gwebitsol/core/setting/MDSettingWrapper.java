package com.gwebitsol.core.setting;

import java.util.ArrayList;
import java.util.List;


public class MDSettingWrapper
{
	private List<MDCategory> categories = new ArrayList <MDCategory>();
	private List<MDSubCategory> subCategories = new ArrayList<MDSubCategory>();
	private List<MDCategoryType> categoryTypes = new ArrayList<MDCategoryType>();
	private List<MDTagType> tagTypes= new ArrayList<MDTagType>();
	private List<MDTemplateType> templateTypes= new ArrayList<MDTemplateType>();
	private List<MDInfomercialType> infomercialTypes= new ArrayList<MDInfomercialType>();
	private List<MDFileCategory> fileCategories = new ArrayList <MDFileCategory>();
	
	private List<AccoladetypePojo> accolades = new ArrayList <AccoladetypePojo>();
	private List<JobtitlePojo> jobtitles = new ArrayList <JobtitlePojo>();
	private List<JobtypePojo> jobtypes = new ArrayList <JobtypePojo>();
	private List<ResultPojo> results = new ArrayList <ResultPojo>();
	
	private List<LibSectionPOJO> section = new ArrayList <LibSectionPOJO>();
	private List<LibCategoryPojo> libcategory = new ArrayList <LibCategoryPojo>();

	private List<AssessmentModePojo> assessmentmode = new ArrayList <AssessmentModePojo>();
	private List<AssessmentTypePojo> assessmenttype = new ArrayList <AssessmentTypePojo>();
	private List<RoomType> roomtype = new ArrayList <RoomType>();
	private List<EventTypePojo> eventtypes =new ArrayList<EventTypePojo>();
	private List<FeeItemType> feeitemtypes=new ArrayList<FeeItemType>();
	private List<BookTypePOJO> booktypes=new ArrayList<BookTypePOJO>();
	
	private List<SubjectType> subjecttypes= new ArrayList<SubjectType>();
	 private List<CastesPojo> castes = new ArrayList<CastesPojo>();
	 private List<ReligionPojo> religions = new ArrayList<ReligionPojo>();
	 public List<CastesPojo> getCastes() {
	  return castes;
	 }
	 public void setCastes(List<CastesPojo> castes) {
	  this.castes = castes;
	 }
	 public List<ReligionPojo> getReligions() {
	  return religions;
	 }
	 public void setReligions(List<ReligionPojo> religions) {
	  this.religions = religions;
	 }
	
	
	 public List<SubjectType> getSubjecttypes() {
		  return subjecttypes;
		 }
		 public void setSubjecttypes(List<SubjectType> subjecttypes) {
		  this.subjecttypes = subjecttypes;
		 }
		 
	public List<LibSectionPOJO> getSection() {
		return section;
	}
	public void setSection(List<LibSectionPOJO> section) {
		this.section = section;
	}
	public List<LibCategoryPojo> getLibcategory() {
		return libcategory;
	}
	public void setLibcategory(List<LibCategoryPojo> libcategory) {
		this.libcategory = libcategory;
	}

	private List<QuestionType> questiontypes=new ArrayList<QuestionType>();
	private List<PaymentModePojo> paymentmodes=new ArrayList<PaymentModePojo>();
	
		
	public List<QuestionType> getQuestiontypes() {
		return questiontypes;
	}
	public void setQuestiontypes(List<QuestionType> questiontypes) {
		this.questiontypes = questiontypes;
	}
	public List<PaymentModePojo> getPaymentmodes() {
		return paymentmodes;
	}
	public void setPaymentmodes(List<PaymentModePojo> paymentmodes) {
		this.paymentmodes = paymentmodes;
	}
	public List<BookTypePOJO> getBooktypes() {
		return booktypes;
	}
	public void setBooktypes(List<BookTypePOJO> booktypes) {
		this.booktypes = booktypes;
	}
	public List<EventTypePojo> getEventtypes() {
		return eventtypes;
	}
	public void setEventtypes(List<EventTypePojo> eventtypes) {
		this.eventtypes = eventtypes;
	}
	public List<FeeItemType> getFeeitemtypes() {
		return feeitemtypes;
	}
	public void setFeeitemtypes(List<FeeItemType> feeitemtypes) {
		this.feeitemtypes = feeitemtypes;
	}
	public List<AccoladetypePojo> getAccolades() {
		return accolades;
	}
	public void setAccolades(List<AccoladetypePojo> accolades) {
		this.accolades = accolades;
	}
	public List<JobtitlePojo> getJobtitles() {
		return jobtitles;
	}
	public void setJobtitles(List<JobtitlePojo> jobtitles) {
		this.jobtitles = jobtitles;
	}
	public List<JobtypePojo> getJobtypes() {
		return jobtypes;
	}
	public void setJobtypes(List<JobtypePojo> jobtypes) {
		this.jobtypes = jobtypes;
	}
	public List<ResultPojo> getResults() {
		return results;
	}
	public void setResults(List<ResultPojo> results) {
		this.results = results;
	}
	public List<MDCategory> getCategories() {
		return categories;
	}
	public void setCategories(List<MDCategory> categories) {
		this.categories = categories;
	}
	public List<MDSubCategory> getSubCategories() {
		return subCategories;
	}
	public void setSubCategories(List<MDSubCategory> subCategories) {
		this.subCategories = subCategories;
	}
	public List<MDCategoryType> getCategoryTypes() {
		return categoryTypes;
	}
	public void setCategoryTypes(List<MDCategoryType> categoryTypes) {
		this.categoryTypes = categoryTypes;
	}
	public List<MDTagType> getTagTypes() {
		return tagTypes;
	}
	public void setTagTypes(List<MDTagType> tagTypes) {
		this.tagTypes = tagTypes;
	}
	public List<MDTemplateType> getTemplateTypes() {
		return templateTypes;
	}
	public void setTemplateTypes(List<MDTemplateType> templateTypes) {
		this.templateTypes = templateTypes;
	}
	public List<MDInfomercialType> getInfomercialTypes() {
		return infomercialTypes;
	}
	public void setInfomercialTypes(List<MDInfomercialType> infomercialTypes) {
		this.infomercialTypes = infomercialTypes;
	}	
	public List<MDFileCategory> getFileCategories() {
		return fileCategories;
	}
	public void setFileCategories(List<MDFileCategory> fileCategories) {
		this.fileCategories = fileCategories;
	}
	public List<AssessmentModePojo> getAssessmentmode() {
		return assessmentmode;
	}
	public void setAssessmentmode(List<AssessmentModePojo> assessmentmode) {
		this.assessmentmode = assessmentmode;
	}
	public List<AssessmentTypePojo> getAssessmenttype() {
		return assessmenttype;
	}
	public void setAssessmenttype(List<AssessmentTypePojo> assessmenttype) {
		this.assessmenttype = assessmenttype;
	}
	public List<RoomType> getRoomtype() {
		return roomtype;
	}
	public void setRoomtype(List<RoomType> roomtype) {
		this.roomtype = roomtype;
	}
}
