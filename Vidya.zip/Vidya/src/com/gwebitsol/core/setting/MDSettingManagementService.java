package com.gwebitsol.core.setting;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.gwebitsol.core.security.MDValidation;
import com.gwebitsol.core.security.MDVerifyConnectionID;
import com.gwebitsol.core.security.MDVerifyDatastoreName;
import com.gwebitsol.core.usermanagement.MDGetUserFromID;
import com.gwebitsol.core.util.MDTransactionWriter;


public class MDSettingManagementService implements MDSettingManagementServiceIntf
{
	@Context private HttpServletRequest hsr;
	public Response addSettings(MDSetting mdSetting, int userid, int connectionid, String datastoreName,int schoolid,int branchid) {
		MDTransactionWriter.accesslog.info("Request from:"+hsr.getRemoteHost()+"at "+new Date());		
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName, schoolid, branchid);
			System.out.println("verifiedvalue::"+ret);
			MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userid);
			if(ret==1 )//&& rtVal==1)
			{
				MDSettingManagementDAO mdstDAO=new MDSettingManagementDAO();
				XMLString=mdstDAO.addSettings(mdSetting, schoolid, branchid);
				if(XMLString.equals("fail"))
					statusStr="failed";
				else
					statusStr="success";
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				MDTransactionWriter.writeLog(datastoreName,"ServiceMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}
		}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			XMLString="failed in service layer";
			localException.printStackTrace();
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}

	public Response updateSettings(MDSetting mdSetting, int userid, int connectionid, String datastoreName,int schoolid,int branchid) {
		MDTransactionWriter.accesslog.info("Request from:"+hsr.getRemoteHost()+"at "+new Date());		
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		
		
		try
		{
			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName,schoolid, branchid);
			System.out.println("verifiedvalue::"+ret);
			
			MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userid);
			
			if(ret==1 )//&& rtVal==1)
			{
						
				MDSettingManagementDAO mdstDAO=new MDSettingManagementDAO();
				XMLString=mdstDAO.updateSettings(mdSetting, schoolid, branchid);
				if(XMLString.equals("fail"))
					statusStr="failed";
				else
					statusStr="success";
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				MDTransactionWriter.writeLog(datastoreName,"ServiceMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}
		}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			XMLString="failed in service layer";
			localException.printStackTrace();
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}
	
	// delete settings
	
	public Response delSettings(MDSetting mdSetting, int userid,int connectionid, String datastoreName,int schoolid,int branchid) {
		MDTransactionWriter.accesslog.info("Request from:"+hsr.getRemoteHost()+"at "+new Date());		
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName,schoolid, branchid);
			System.out.println("verifiedvalue::"+ret);
			
			MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userid);
			
			if(ret==1 )//&& rtVal==1)
			{
						
				MDSettingManagementDAO mdstDAO=new MDSettingManagementDAO();
				XMLString=mdstDAO.delSettings(mdSetting);
				if(XMLString.equals("fail"))
					statusStr="failed";
				else
					statusStr="success";
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				MDTransactionWriter.writeLog(datastoreName,"ServiceMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}
		}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			XMLString="failed in service layer";
			localException.printStackTrace();
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}

	public Response getSettings(int userid, int connectionid,
			String datastoreName, int PNO, int size, String settings,int schoolid,int branchid) {
			MDTransactionWriter.accesslog.info("Request from:"+hsr.getRemoteHost()+"at "+new Date());		
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName,schoolid, branchid);
			System.out.println("verifiedvalue::"+ret);
			
			MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userid);
			
			if(ret==1 )//&& rtVal==1)
			{
						
				MDSettingManagementDAO mdstDAO=new MDSettingManagementDAO();
				XMLString=mdstDAO.getSettings(PNO, size, settings,schoolid, branchid);
				if(XMLString.equals("fail"))
					statusStr="failed";
				else
					statusStr="success";
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				MDTransactionWriter.writeLog(datastoreName,"ServiceMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}
		}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			XMLString="failed in service layer";
			localException.printStackTrace();
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}

	public Response getSettingsByIds(MDSetting mdSetting, int userid, int connectionid,
			String datastoreName,int schoolid,int branchid) {
			MDTransactionWriter.accesslog.info("Request from:"+hsr.getRemoteHost()+"at "+new Date());		
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName,schoolid, branchid);
			System.out.println("verifiedvalue::"+ret);
			
			MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userid);
			
			if(ret==1 )//&& rtVal==1)
			{
						
				MDSettingManagementDAO mdstDAO=new MDSettingManagementDAO();
				XMLString=mdstDAO.getSettingsByIds(mdSetting, schoolid, branchid);
				if(XMLString.equals("fail"))
					statusStr="failed";
				else
					statusStr="success";
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				MDTransactionWriter.writeLog(datastoreName,"ServiceMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}
		}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			XMLString="failed in service layer";
			localException.printStackTrace();
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}
	
	
}
