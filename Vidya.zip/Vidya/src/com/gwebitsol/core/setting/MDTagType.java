package com.gwebitsol.core.setting;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

@SuppressWarnings("serial")
@XmlRootElement(name="TagType")

public class MDTagType implements Serializable {
	
	private int tagTypeId;
	private String tagTypeName;
	private String tagTypeCode;
	private int priority;
	private String tagTypeStatus;
	private String description;
	
	public int getTagTypeId() {
		return tagTypeId;
	}
	public void setTagTypeId(int tagTypeId) {
		this.tagTypeId = tagTypeId;
	}
	public String getTagTypeName() {
		return tagTypeName;
	}
	public void setTagTypeName(String tagTypeName) {
		this.tagTypeName = tagTypeName;
	}
	public String getTagTypeCode() {
		return tagTypeCode;
	}
	public void setTagTypeCode(String tagTypeCode) {
		this.tagTypeCode = tagTypeCode;
	}
	public int getPriority() {
		return priority;
	}
	public void setPriority(int priority) {
		this.priority = priority;
	}
	public String getTagTypeStatus() {
		return tagTypeStatus;
	}
	public void setTagTypeStatus(String tagTypeStatus) {
		this.tagTypeStatus = tagTypeStatus;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}

	
}
