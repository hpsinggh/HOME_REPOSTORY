package com.gwebitsol.core.setting;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="libCategory")

public class LibCategoryPojo {
	private int libCategoryId;
	private String categoryName;
	private String description;
	private String remarks;
	private int schoolId;
	private int branchId;
	public int getSchoolId() {
		return schoolId;
	}
	public void setSchoolId(int schoolId) {
		this.schoolId = schoolId;
	}
	public int getBranchId() {
		return branchId;
	}
	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}
	
	public int getLibCategoryId() {
		return libCategoryId;
	}
	public void setLibCategoryId(int libCategoryId) {
		this.libCategoryId = libCategoryId;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	
	
	
	
	
}
