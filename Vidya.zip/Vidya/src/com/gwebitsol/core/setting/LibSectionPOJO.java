package com.gwebitsol.core.setting;

import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

import org.hibernate.annotations.Entity;

@XmlRootElement(name="libsection")
@Entity
@Table(name="gbl_sm_tbl_lib_section")
public class LibSectionPOJO {
	private int libSectionId;
	private String sectionName;
	private String description;
	private String status;
	private String remarks;
	private int schoolId;
	private int branchId;
	public int getSchoolId() {
		return schoolId;
	}
	public void setSchoolId(int schoolId) {
		this.schoolId = schoolId;
	}
	public int getBranchId() {
		return branchId;
	}
	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}
	public int getLibSectionId() {
		return libSectionId;
	}
	public void setLibSectionId(int libSectionId) {
		this.libSectionId = libSectionId;
	}
	public String getSectionName() {
		return sectionName;
	}
	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	

}
