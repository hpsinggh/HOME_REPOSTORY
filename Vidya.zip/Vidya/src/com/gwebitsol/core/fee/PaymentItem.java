package com.gwebitsol.core.fee;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="PaymentItem")
public class PaymentItem {
	private int paymentItemId;
	/*private List<FeeItemPojo> feeItempojo;*/
	private int feeItemId;
	private int paymentId;
	
	
	/*public List<FeeItemPojo> getFeeItempojo() {
		return feeItempojo;
	}
	public void setFeeItempojo(List<FeeItemPojo> feeItempojo) {
		this.feeItempojo = feeItempojo;
	}*/
	public int getPaymentItemId() {
		return paymentItemId;
	}
	public void setPaymentItemId(int paymentItemId) {
		this.paymentItemId = paymentItemId;
	}
	
	
	public int getPaymentId() {
		return paymentId;
	}
	public void setPaymentId(int paymentId) {
		this.paymentId = paymentId;
	}
	public int getFeeItemId() {
		return feeItemId;
	}
	public void setFeeItemId(int feeItemId) {
		this.feeItemId = feeItemId;
	}
	
	
}
