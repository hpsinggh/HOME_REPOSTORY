package com.gwebitsol.core.fee;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.gwebitsol.core.security.MDValidation;
import com.gwebitsol.core.usermanagement.MDGetUserFromID;
import com.gwebitsol.core.util.MDTransactionWriter;

public class FeeItemService implements FeeItemIntf {
	@Context 
	private HttpServletRequest hsr;
	
	public Response addFeeItem(FeeItemPojo per,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String XMLString=null;
	    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		per.setSchoolId(schoolId);
		per.setBranchId(branchId);
		  try
		  {
		   MDValidation mdv = new MDValidation();  
		   int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
		   System.out.println("verifiedvalue::"+ret);
		   MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userID);
		   if(ret==1 )//&& rtVal==1)
		   {
			   	String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				
				FeeItemDao brdao=new FeeItemDao();
				XMLString=brdao.addFeeItem(per);
				
				System.out.println(XMLString);
				MDTransactionWriter.writeLog(datastoreName,"FeeItemPojo_addFeeItem",requester,startDate,endDate,sl,el,XMLString,hsr.getRemoteHost());
		   }else{
				XMLString="you are not authorised user";
		   }
		}catch(Exception localException){
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
		   XMLString="failed in service layer";
		}	
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}

	public Response updateFeeItem(FeeItemPojo per,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String XMLString=null;
	    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		per.setSchoolId(schoolId);
		per.setBranchId(branchId);
		 try
		  {
		   MDValidation mdv = new MDValidation();  
		   int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
		   System.out.println("verifiedvalue::"+ret);
		   MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userID);
		   if(ret==1 )//&& rtVal==1)
			 {
			   	String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				
				FeeItemDao brdao=new FeeItemDao();
				XMLString=brdao.updateFeeItem(per,schoolId,branchId);
				
				System.out.println(XMLString);
				MDTransactionWriter.writeLog(datastoreName,"FeeItemPojo_updateFeeItem",requester,startDate,endDate,sl,el,XMLString,hsr.getRemoteHost());
			   }else{
				XMLString="you are not authorised user";
			}
		}catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
		   XMLString="failed in service layer";
		}	
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}

	@SuppressWarnings("unused")
	public Response deleteFeeItem(int feeItemId,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		String XMLString=null;
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		 try
		  {
		   MDValidation mdv = new MDValidation();  
		   int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
		   System.out.println("verifiedvalue::"+ret);
		   MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userID);
		   if(ret==1 )//&& rtVal==1)
		   {
			FeeItemDao brdao=new FeeItemDao();
			status=brdao.deleteFeeItem(feeItemId,schoolId,branchId);
		
			String endDate=dateFormat.format(new Date());	
			Long el=System.currentTimeMillis();
		
			MDTransactionWriter.writeLog(datastoreName,"FeeItemPojo_deleteFeeItem",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
		   }else{
			   		XMLString="you are not authorised user";
		   }
		  }catch(Exception localException){
			  MDTransactionWriter.errorlog.debug(localException);
			  MDTransactionWriter.errorlog.info(localException);
			  status="failed in service layer";
		  }
return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	@SuppressWarnings("unused")
	public Response getByIdFeeItem(int feeItemId,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		String XMLString=null;

		String status1=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		
		 try
		  {
		   MDValidation mdv = new MDValidation();  
		   int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
		   System.out.println("verifiedvalue::"+ret);
		   MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userID);
		   if(ret==1 )//&& rtVal==1)
		   {
			FeeItemDao ex=new FeeItemDao();
			 status1=ex.getByIdFeeItem(feeItemId,schoolId,branchId);
			 
			 System.out.println(status1);
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			//status1="user validation successfull";
			MDTransactionWriter.writeLog(datastoreName,"FeeItemPojo_getByIdFeeItem",requester,startDate,endDate,sl,el,status1,hsr.getRemoteHost());		
		   }else
		   	{
		XMLString="you are not authorised user";
		   	}
		  }
		 catch(Exception localException)
		 	{
			 MDTransactionWriter.errorlog.debug(localException);
			 MDTransactionWriter.errorlog.info(localException);
			 status1="failed in service layer";
	}
		 return Response.ok().type(MediaType.APPLICATION_XML).entity(status1).build();
}

	@SuppressWarnings("unused")
	public Response getAllFeeItem(int userID, int connectionID,String datastoreName,int PNO,int size,int schoolId,int branchId,int classId,int sectionId,int studentId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String XMLString=null;
	
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		 try
		  {
		   MDValidation mdv = new MDValidation();  
		   int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
		   System.out.println("verifiedvalue::"+ret);
		   MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userID);
		   if(ret==1 )//&& rtVal==1)
		   {
			  // if ((classId == 0 && sectionId != 0) || (classId != 0 && sectionId == 0) || (classId !=0 && sectionId !=0) || (classId ==0 && sectionId ==0) ){
			FeeItemDao ex=new FeeItemDao();
			status=ex.getAllFeeItem(PNO,size,schoolId,branchId,classId,sectionId,studentId);
			   /*}else {
				XMLString= "<Error> Cannot get subFolders! Only one, FolderId or FolderName is allowed; folderId and folderName are Empty </Error>";
			}*/
			System.out.println(status);
			String endDate=dateFormat.format(new Date());
			  Long el=System.currentTimeMillis();
			 MDTransactionWriter.writeLog(datastoreName,"FeeItemPojo_getAllFeeItem",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
		   }else
		   	{
			XMLString="you are not authorised user";
		   	}
		  }catch(Exception localException)
		   {
			  MDTransactionWriter.errorlog.debug(localException);
			  MDTransactionWriter.errorlog.info(localException);
			  status="failed in service layer";
		   }
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	

	@SuppressWarnings("unused")
	public Response getAllFeeItemByStructureId(int feeStructureId, int userid, int connectionid, String datastoreName,
			int PNO, int size, int schoolId, int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String XMLString=null;
	
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		 try
		  {
		   MDValidation mdv = new MDValidation();  
		   int ret =mdv.allvalidations(userid, connectionid, datastoreName,schoolId,branchId);
		   System.out.println("verifiedvalue::"+ret);
		   MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userid);
		   if(ret==1 )//&& rtVal==1)
		   {
			FeeItemDao ex=new FeeItemDao();
			status=ex.getAllFeeItemByStructureId(feeStructureId,PNO,size,schoolId,branchId);
			
			System.out.println(status);
			String endDate=dateFormat.format(new Date());
			  Long el=System.currentTimeMillis();
			 MDTransactionWriter.writeLog(datastoreName,"FeeItemPojo_getAllFeeItemByStructureId",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
		   }else
		   	{
			XMLString="you are not authorised user";
		   	}
		  }catch(Exception localException)
		   {
			  MDTransactionWriter.errorlog.debug(localException);
			  MDTransactionWriter.errorlog.info(localException);
			  status="failed in service layer";
		   }
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

}
