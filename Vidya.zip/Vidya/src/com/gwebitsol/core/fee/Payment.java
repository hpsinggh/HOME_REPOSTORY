package com.gwebitsol.core.fee;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="payment")
public class Payment {
	private String paymentItemId;
	private int paymentId;
	private int payReceiptNo;
	private int studentId;
	private String feeItemId;
	private String paidBy;
	private String datePaid;
	private int employeeId;
	private String paymentModeId;
	private String totalAmount;
	private String remarks;
	private String 	createdDate;
	DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	 Date date = new Date();
	 String modifiedDate=dateFormat.format(date);
	
		private int schoolId;
		private int branchId;

	public int getSchoolId() {
			return schoolId;
		}
	public void setSchoolId(int schoolId) {
			this.schoolId = schoolId;
		}
	public int getBranchId() {
			return branchId;
		}
	public void setBranchId(int branchId) {
			this.branchId = branchId;
		}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	
	public int getPaymentId() {
		return paymentId;
	}
	public void setPaymentId(int paymentId) {
		this.paymentId = paymentId;
	}
	public int getPayReceiptNo() {
		return payReceiptNo;
	}
	public void setPayReceiptNo(int payReceiptNo) {
		this.payReceiptNo = payReceiptNo;
	}
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public String getPaidBy() {
		return paidBy;
	}
	public void setPaidBy(String paidBy) {
		this.paidBy = paidBy;
	}
	public String getDatePaid() {
		return datePaid;
	}
	public void setDatePaid(String datePaid) {
		this.datePaid = datePaid;
	}
	public String getPaymentModeId() {
		return paymentModeId;
	}
	public void setPaymentModeId(String paymentModeId) {
		this.paymentModeId = paymentModeId;
	}
	public String getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(String totalAmount) {
		this.totalAmount = totalAmount;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getFeeItemId() {
		return feeItemId;
	}
	public void setFeeItemId(String feeItemId) {
		this.feeItemId = feeItemId;
	}
	public String getPaymentItemId() {
		return paymentItemId;
	}
	public void setPaymentItemId(String paymentItemId) {
		this.paymentItemId = paymentItemId;
	}
	
	
	
	
}
