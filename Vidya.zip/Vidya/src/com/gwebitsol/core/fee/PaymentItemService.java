package com.gwebitsol.core.fee;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.gwebitsol.core.security.MDVerifyConnectionID;
import com.gwebitsol.core.security.MDVerifyDatastoreName;
import com.gwebitsol.core.usermanagement.MDGetUserFromID;
import com.gwebitsol.core.util.MDTransactionWriter;

public class PaymentItemService implements PaymentItemIntf {
	@Context 
	private HttpServletRequest hsr;
	public Response addPaymentItem(PaymentItem per, int userID, int connectionID, String datastoreName) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String XMLString=null;
	    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
			String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				
				PaymentItemDao brdao=new PaymentItemDao();
				XMLString=brdao.addPaymentItem(per);
				
				System.out.println(XMLString);
				MDTransactionWriter.writeLog("datastoreName","EmpMS","requester",startDate,endDate,sl,el,XMLString,hsr.getRemoteHost());
		}
			else
			{
				XMLString="you are not authorised user";
			}
		}

		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
		   XMLString="failed in service layer";
		}
	
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}

	public Response updatePaymentItem(PaymentItem per, int userID, int connectionID, String datastoreName) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String XMLString=null;
	    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
			String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				
				PaymentItemDao brdao=new PaymentItemDao();
				XMLString=brdao.updatePaymentItem(per);
				
				System.out.println(XMLString);
				MDTransactionWriter.writeLog("datastoreName","EmpMS","requester",startDate,endDate,sl,el,XMLString,hsr.getRemoteHost());
		}
			else
			{
				XMLString="you are not authorised user";
			}
		}

		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
		   XMLString="failed in service layer";
		}
	
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();

	}

	public Response deletePaymentItem(int paymentItemId, int userID, int connectionID, String datastoreName) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		@SuppressWarnings("unused")
		String XMLString=null;

				String status=null;
				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date date = new Date();
				String startDate=dateFormat.format(date);
				Long sl=System.currentTimeMillis();
				
				try
			{	
					MDGetUserFromID mdgufid=new MDGetUserFromID();
					String requester=mdgufid.getUserName(userID);
					
					System.out.println(connectionID);
					MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
					int ret=mdvcid.verifyConnectionID(userID,connectionID);
					
					MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
					int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
					
					System.out.println("request making user:: "+requester);
					System.out.println("connectionid verification value:: "+ret);
					System.out.println("datastore verification value :: "+rtVal);
					if(ret==1 )//&& rtVal==1)
					{
						PaymentItemDao brdao=new PaymentItemDao();
				status=brdao.deletePaymentItem(paymentItemId);
				
				String endDate=dateFormat.format(new Date());	
				Long el=System.currentTimeMillis();
				
					MDTransactionWriter.writeLog("sai","CMS","requester",startDate,endDate,sl,el,status,hsr.getRemoteHost());		
			}else
			{
				XMLString="you are not authorised user";
			}
		}

			catch(Exception localException)
			{
				MDTransactionWriter.errorlog.debug(localException);
				MDTransactionWriter.errorlog.info(localException);
				status="failed in service layer";
			}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response getByIdPaymentItem(int paymentItemId, int userID, int connectionID, String datastoreName) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		@SuppressWarnings("unused")
		String XMLString=null;

				String status1=null;
				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date date = new Date();
				String startDate=dateFormat.format(date);
				Long sl=System.currentTimeMillis();
				
				
				try
			{	
					MDGetUserFromID mdgufid=new MDGetUserFromID();
					String requester=mdgufid.getUserName(userID);
					
					System.out.println(connectionID);
					MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
					int ret=mdvcid.verifyConnectionID(userID,connectionID);
					
					MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
					int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
					
					System.out.println("request making user:: "+requester);
					System.out.println("connectionid verification value:: "+ret);
					System.out.println("datastore verification value :: "+rtVal);
					if(ret==1 )//&& rtVal==1)
					{
						PaymentItemDao ex=new PaymentItemDao();
					 status1=ex.getByIdPaymentItem(paymentItemId);
					 
					 System.out.println(status1);
					String endDate=dateFormat.format(new Date());
					Long el=System.currentTimeMillis();
					//status1="user validation successfull";
					MDTransactionWriter.writeLog("sai","CMS","requester",startDate,endDate,sl,el,status1,hsr.getRemoteHost());		
			}else
			{
				XMLString="you are not authorised user";
			}
		}

			catch(Exception localException)
			{
				MDTransactionWriter.errorlog.debug(localException);
				MDTransactionWriter.errorlog.info(localException);
				status1="failed in service layer";
				//System.out.println(localException);
			}
		 return Response.ok().type(MediaType.APPLICATION_XML).entity(status1).build();

	}

	public Response getAllPaymentItem(int userID, int connectionID, String datastoreName) {
MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		
		@SuppressWarnings("unused")
		String XMLString=null;

				String status=null;
				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date date = new Date();
				String startDate=dateFormat.format(date);
				Long sl=System.currentTimeMillis();
				try{
					MDGetUserFromID mdgufid=new MDGetUserFromID();
					String requester=mdgufid.getUserName(userID);
					
					System.out.println(connectionID);
					MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
					int ret=mdvcid.verifyConnectionID(userID,connectionID);
					
					MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
					int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
					
					System.out.println("request making user:: "+requester);
					System.out.println("connectionid verification value:: "+ret);
					System.out.println("datastore verification value :: "+rtVal);
					if(ret==1 )//&& rtVal==1)
					{
						PaymentItemDao ex=new PaymentItemDao();
					status=ex.getAllPaymentItem();
					
					System.out.println(status);
					String endDate=dateFormat.format(new Date());
					  Long el=System.currentTimeMillis();
					 MDTransactionWriter.writeLog("sai","CMS","requester",startDate,endDate,sl,el,status,hsr.getRemoteHost());		

				}else
				{
					XMLString="you are not authorised user";
				}
			}

					catch(Exception localException)
				   {
					  MDTransactionWriter.errorlog.debug(localException);
					  MDTransactionWriter.errorlog.info(localException);
					  status="failed in service layer";
				   }
				return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

}
