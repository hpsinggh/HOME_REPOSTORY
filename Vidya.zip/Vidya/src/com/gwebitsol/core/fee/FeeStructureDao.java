package com.gwebitsol.core.fee;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class FeeStructureDao {
	
	public String addFeeStructure(FeeStructure per) {
		Session addempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction addempTx=null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			addempTx=addempSession.beginTransaction();
			 int FeeStructureId ;
			 int FeeItemId;
			
			 FeeStructureId=(Integer)addempSession.save(per);
	        
	        String fat = per.getFeeItemId();  
			   
			   String[] x = fat.split(",");
			   
			    for(int i=0;i<=x.length-1;i++)
			    {
			    FeeItemId  = Integer.parseInt(x[i]);         
			   String  sqlstr = "insert into gbl_sm_tbl_feeitem_structure(FeeStructureId,FeeItemId)values('"+FeeStructureId+"','"+FeeItemId+"');";
			     SQLQuery stpar = addempSession.createSQLQuery(sqlstr);
			     stpar.executeUpdate();
			    } 
	        
			System.out.println(FeeStructureId);
			
			addempTx.commit();
			
			sb.append("<FeeStructure>");
			sb.append("\n");
			sb.append("<feeStructureId>");
			sb.append(FeeStructureId);
			sb.append("</feeStructureId>");
			sb.append("</FeeStructure>");
			String str=sb.toString();
			return str;
   		 	}
		catch(Exception localException){
		   System.out.println(localException);
		   localException.printStackTrace();  
		   sb.append("<Response>");
	       sb.append("\n");
	       sb.append("<Result>");
	       sb.append("\n");
	       sb.append("Fail");
	       sb.append("\n");
	       sb.append("</Result>");
	       sb.append("\n");
	       sb.append("<Description>");
	       sb.append("could not inserted FeeStructure info");
	       sb.append("</Description>");
	       sb.append("\n");
	       sb.append("<Exception>");
	       sb.append(localException);
	       sb.append("</Exception>");
	       sb.append("</Response>");
	       outStr= sb.toString();
	      MDTransactionWriter.exceptionlog.info(localException);
	     if (addempTx!=null)
	      addempTx.rollback();
		}
		finally
		{			
			addempSession.close();
		}
		return outStr;
	}

	public String updateFeeStructure(FeeStructure per,int schoolId,int branchId) {
		Session upempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction upempTx=null;
		StringBuffer sb=new StringBuffer();

		String outStr=null;
		try
		{
				upempTx=upempSession.beginTransaction();
				FeeStructure feestr = (FeeStructure) upempSession.get(FeeStructure.class,per.getFeeStructureId());
		      
				if(branchId==feestr.getBranchId()&&schoolId==feestr.getSchoolId())
			       
			    upempSession.evict(feestr);
			   	upempSession.update(per);
			   	int feeStructureId = per.getFeeStructureId();
			   	int FeeItemId;
				//int feeItemStructureId;
			   	Query empQuery=upempSession.createSQLQuery("delete from gbl_sm_tbl_feeitem_structure  where feeStructureId='"+feeStructureId+"'");
				   empQuery.executeUpdate();
			   	
				   String fat = per.getFeeItemId();  
				   
				   String[] x = fat.split(",");
				   
				    for(int i=0;i<=x.length-1;i++)
				    {
				    FeeItemId  = Integer.parseInt(x[i]);         
				   String  sqlstr = "insert into gbl_sm_tbl_feeitem_structure(FeeStructureId,FeeItemId)values('"+feeStructureId+"','"+FeeItemId+"');";
				     SQLQuery stpar = upempSession.createSQLQuery(sqlstr);
				     stpar.executeUpdate();
				    } 
				/*String fat = per.getFeeItemId();  
				   String f=per.getFeeItemStructureId();
				   String[] x = fat.split(",");
				   String[] y =f.split(",");
				    for(int i=0;i<=x.length-1;i++)
				    {	
				    FeeItemId  = Integer.parseInt(x[i]);
				    feeItemStructureId =Integer.parseInt(y[i]);
				   String  sqlstr = "update  gbl_sm_tbl_feeitem_structure set FeeStructureId='"+feeStructureId+"',FeeItemId='"+FeeItemId+"' where FeeItemStructureId='"+feeItemStructureId+"';";
				     SQLQuery stpar = upempSession.createSQLQuery(sqlstr);
				     stpar.executeUpdate();
				    } */
				upempTx.commit();
				
				sb.append("<FeeStructure>");
				sb.append("\n");
				sb.append("update successfully");
				sb.append("</FeeStructure>");
				String str=sb.toString();
				return str; 
	   		 	}
			catch(Exception localException){
				System.out.println(localException);
				localException.printStackTrace();  
				sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not update FeeStructure info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       outStr= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (upempTx!=null)
		    	 upempTx.rollback();
			}
			finally
			{			
				upempSession.close();
			}
			return outStr;

	}

	public String deleteFeeStructure(int feeStructureId,int schoolId,int branchId) {
		Session delempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction delempTx=null;
		StringBuffer sb=new StringBuffer();

		String outStr=null;
		try
		{
			delempTx=delempSession.beginTransaction();
			FeeStructure mdclpojo = (FeeStructure) delempSession.get(FeeStructure.class,feeStructureId);
			   
			   int branid = mdclpojo.getBranchId();
			   int sclid = mdclpojo.getSchoolId();
			   delempSession.evict(mdclpojo);     
			   if(branchId==branid&&schoolId==sclid)
			   {		   
				   Query empQuery=delempSession.createSQLQuery("update gbl_sm_tbl_fee_structure set isDeleted='y' where feeStructureId='"+feeStructureId+"'");
				   empQuery.executeUpdate();
			
				   delempTx.commit();
				
				   sb.append("<FeeStructure>");
				   sb.append("\n");
				   sb.append("delete successfully");
				   sb.append("</FeeStructure>");
				   String str=sb.toString();
				   return str;
	   		 	}
		}
			catch(Exception localException){
				System.out.println(localException);
				localException.printStackTrace();  
				sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not delete FeeStructure info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       outStr= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (delempTx!=null)
		    	 delempTx.rollback();
			}
			finally
			{			
				delempSession.close();
			}
			return outStr;
	}

	@SuppressWarnings("rawtypes")
	public String getByIdFeeStructure(int feeStructureId,int schoolId,int branchId) {
		Session gtempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gtempTx=null;
		StringBuffer sb=new StringBuffer();
		String strg= null;
			try {
					gtempTx = gtempSession.beginTransaction();
					/*String gs="select feeitemstructureId from gbl_sm_tbl_feeitem_structure where feestructureId="+feeStructureId;
					Query q=gtempSession.createSQLQuery(gs);	
					List l = q.list();
					Iterator i=l.iterator();
					while(i.hasNext()){
						Object[] e=(Object[])i.next();
						int k=e.length;
					for(int j=0; j<k; j++){
						sb.append("<feeItemStructureId>");
					    sb.append(j);
					    sb.append("</feeItemStructureId>");
					}
					}*/
					List list=gtempSession.createSQLQuery("select fst.FeeStructureId,fst.Title,fst.ClassId,cls.ClassName,fst.SectionId,sec.SectionName,fst.Description,fst.AcademicYear,fst.StartDate,fst.EndDate,fst.`Status`,fst.SchoolId,fst.BranchId from gbl_sm_tbl_fee_structure as fst join gbl_sm_tbl_class as cls on fst.ClassId=cls.ClassId join gbl_sm_tbl_section as sec on fst.SectionId=sec.SectionId where fst.FeeStructureId='" + feeStructureId + "' and fst.SchoolId='" + schoolId + "' and fst.BranchId='" + branchId + "' and fst.IsDeleted Is Null;").list();
					Iterator it=list.iterator();
					sb.append("<FeeStructure>");
					/*sb.append("<feeItemStructureId>");
				    sb.append(x);
				    sb.append("</feeItemStructureId>");*/
				    sb.append("\n");
					while(it.hasNext()){
						Object[] ex=(Object[])it.next();						
				        sb.append("\n");
				        sb.append("<feeStructureId>");
					    sb.append(ex[0]);
					    sb.append("</feeStructureId>");
					    sb.append("\n");
					    sb.append("<title>");
						sb.append(ex[1]);
						sb.append("</title>");
						sb.append("\n");					    
					    sb.append("<classId>");
						sb.append(ex[2]);
						sb.append("</classId>");
						sb.append("\n");						
						sb.append("<className>");
						sb.append(ex[3]);
						sb.append("</className>");
						sb.append("\n");						
				        sb.append("<sectionId>");
					    sb.append(ex[4]);
					    sb.append("</sectionId>");
					    sb.append("\n");					    
					    sb.append("<sectionName>");
						sb.append(ex[5]);
						sb.append("</sectionName>");
						sb.append("\n");					    
						sb.append("<description>");
					    sb.append(ex[6]);
					    sb.append("</description>");
					    sb.append("\n");
					    sb.append("<academicYear>");
						sb.append(ex[7]);
						sb.append("</academicYear>");
						sb.append("\n");
				        sb.append("<startDate>");
					    sb.append(ex[8]);
					    sb.append("</startDate>");
					    sb.append("\n");
					    sb.append("<endDate>");
						sb.append(ex[9]);
						sb.append("</endDate>");
						sb.append("\n");
						sb.append("<status>");
					    sb.append(ex[10]);
					    sb.append("</status>");
					    sb.append("\n");
					    sb.append("<schoolId>");
				        sb.append(ex[11]);
				        sb.append("</schoolId>");
				        sb.append("\n");
				        sb.append("<branchId>");
				        sb.append(ex[12]);
				        sb.append("</branchId>");
				        sb.append("\n");						
					}					
						sb.append("</FeeStructure>");
						strg=sb.toString(); 					 
						gtempTx.commit();		
			}catch(Exception localException) {
				System.out.println(localException);			
				localException.printStackTrace();  
				sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not get FeeStructure info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       strg= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (gtempTx!=null)
		    	 gtempTx.rollback();
				} finally {
					gtempSession.close();
				}
		return strg;
	}

	@SuppressWarnings({ "rawtypes" })
	public String getAllFeeStructure(int PNO, int size,int schoolId,int branchId,int classId,int sectionId) {
		Session rdSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb= new StringBuffer();
		String string=null;
		String gsSql=null;
		try
		{
			tx = rdSession.beginTransaction();
			int fset = (PNO-1)*size;
				gsSql ="select count(*) from gbl_sm_tbl_fee_structure where isDeleted is null and schoolId="+schoolId+" and branchId="+branchId+"";
				if(classId!=0){
					   gsSql += " and classId="+classId;
				   if(sectionId!=0){
					   gsSql +=  " and sectionId="+sectionId;
				   }
				   }gsSql +=";";
			Query gsQuery=rdSession.createSQLQuery(gsSql);
			Object noRecords= gsQuery.uniqueResult();
			int intNoRecords=0;
			if(noRecords!=null && Integer.parseInt(noRecords.toString())!=0)
			{
				intNoRecords=Integer.parseInt(noRecords.toString());
			}
			sb.append("<FeeStructures>");
			sb.append("\n");
			sb.append("<noRecords>"+intNoRecords+"</noRecords>");
			sb.append("\n");
			if(intNoRecords!=0)
			{
			if (PNO > 0 & size > 0){
			 gsSql="select fst.FeeStructureId,fst.Title,fst.ClassId,cls.ClassName,fst.SectionId,sec.SectionName, fst.Description,fst.AcademicYear,fst.StartDate,fst.EndDate,fst.`Status`,fst.SchoolId,fst.BranchId from gbl_sm_tbl_fee_structure as fst join gbl_sm_tbl_class as cls on fst.ClassId=cls.ClassId join gbl_sm_tbl_section as sec on fst.SectionId=sec.SectionId where fst.SchoolId='" + schoolId + "' and fst.BranchId='" + branchId + "' and fst.IsDeleted Is Null" ;
			 if(classId!=0){
				   gsSql += " and fst.classId="+classId;
			   if(sectionId!=0){
				   gsSql +=  " and fst.sectionId="+sectionId;
			   }
			   }gsSql +=" limit "+size+" offset "+fset;
			}
			 else {
			  gsSql="select fst.FeeStructureId,fst.Title,fst.ClassId,cls.ClassName,fst.SectionId,sec.SectionName, fst.Description,fst.AcademicYear,fst.StartDate,fst.EndDate,fst.`Status`,fst.SchoolId,fst.BranchId from gbl_sm_tbl_fee_structure as fst join gbl_sm_tbl_class as cls on fst.ClassId=cls.ClassId join gbl_sm_tbl_section as sec on fst.SectionId=sec.SectionId where fst.SchoolId='" + schoolId + "' and fst.BranchId='" + branchId + "' and fst.IsDeleted Is Null";
			  if(classId!=0){
				   gsSql += " and fst.classId="+classId;
			   if(sectionId!=0){
				   gsSql +=  " and fst.sectionId="+sectionId;
			   }
			   }gsSql +=";";
			 }
			    gsQuery=rdSession.createSQLQuery(gsSql);
			    List gcList=gsQuery.list();
			    Iterator gsIT=gcList.iterator();
			 while(gsIT.hasNext())
			 {
			  Object[] mdcArr=(Object[])gsIT.next();
			   sb.append("<FeeStructure>");
			  sb.append("\n");
			  sb.append("<feeStructureId>"+mdcArr[0]+"</feeStructureId>");
			  sb.append("\n");
			  sb.append("<title>" + mdcArr[1]+ "</title>");
			  sb.append("\n");
			  sb.append("<classId>" + mdcArr[2]+ "</classId>");
			  sb.append("\n");
			  sb.append("<className>" + mdcArr[3]+ "</className>");
			  sb.append("\n");
			  sb.append("<sectionId>" + mdcArr[4]+ "</sectionId>");
			  sb.append("\n");
			  sb.append("<sectionName>" + mdcArr[5] + "</sectionName>");
			  sb.append("\n");
			  sb.append("<description>" + mdcArr[6]+ "</description>");
			  sb.append("\n");
			  sb.append("<academicYear>" + mdcArr[7] + "</academicYear>");
			  sb.append("\n");
			  sb.append("<startDate>" + mdcArr[8]+ "</startDate>");
			  sb.append("\n");
			  sb.append("<endDate>" + mdcArr[9] + "</endDate>");
			  sb.append("\n");
			  sb.append("<status>" + mdcArr[10] + "</status>");
			  sb.append("\n");
			  sb.append("<schoolId>" + mdcArr[11]+ "</schoolId>");
			  sb.append("\n");
			  sb.append("<branchId>" + mdcArr[12]+ "</branchId>");
			  sb.append("\n");
			  sb.append("</FeeStructure>");
			  sb.append("\n");
			 }
			}
			 tx.commit();
			sb.append("</FeeStructures>");
			string=sb.toString();  
			  } 
			  catch(Exception localException)
			  {
			   tx.rollback();
			   localException.printStackTrace();
			   string = "fail";
			   System.out.println("Could not Get FeeStructure");
			  }
			  finally
			  {
			   rdSession.close();
			  } 
			  return string;
	}

	@SuppressWarnings("rawtypes")
	public String getFeeStructureByClassId(int ClassId,int schoolId,int branchId) {
		Session sempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction sempTx=null;
		StringBuffer sb=new StringBuffer();
		String strg= null;
			try {
					
					sempTx=sempSession.beginTransaction();
					List list=sempSession.createSQLQuery("select * from gbl_sm_tbl_fee_structure where ClassId like '"+ClassId+"' and isDeleted is null and schoolId="+schoolId+" and branchId="+branchId+";").list();
					Iterator it=list.iterator();
					sb.append("<FeeStructures>");
					sb.append("\n");
					while(it.hasNext()){
						Object[] ex=(Object[])it.next();
						sb.append("<FeeStructure>");
						sb.append("\n");
						sb.append("<feeStructureId>");
					    sb.append(ex[0]);
					    sb.append("</feeStructureId>");
					    sb.append("\n");
					    sb.append("<classId>");
						sb.append(ex[1]);
						sb.append("</classId>");
						sb.append("\n");
						sb.append("<sectionId>");
						sb.append(ex[2]);
						sb.append("</sectionId>");
						sb.append("\n");
						sb.append("<title>");
					    sb.append(ex[3]);
					    sb.append("</title>");
					    sb.append("\n");
					    
						sb.append("<description>");
						sb.append(ex[4]);
						sb.append("</description>");
						sb.append("\n");
						
						sb.append("<academicYear>");
						sb.append(ex[5]);
						sb.append("</academicYear>");
						sb.append("\n");
						
						sb.append("<startDate>");
						sb.append(ex[6]);
						sb.append("</startDate>");
						sb.append("\n");
						
						sb.append("<endDate>");
						sb.append(ex[7]);
						sb.append("</endDate>");
						sb.append("\n");
						
						sb.append("<status>");
						sb.append(ex[8]);
						sb.append("</status>");
						sb.append("\n");
						
						sb.append("<createdDate>");
						sb.append(ex[9]);
						sb.append("</createdDate>");
						sb.append("\n");
						
						sb.append("<modifiedDate>");
						sb.append(ex[10]);
						sb.append("</modifiedDate>");
						sb.append("\n");
						sb.append("</FeeStructure>");
						sb.append("\n");
					}
					 sb.append("</FeeStructures>");
					 strg=sb.toString(); 
					 
					 sempTx.commit();
					
			} 	catch (Exception localException) {
				System.out.println(localException);
				
				localException.printStackTrace();  
				sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not getbyclass FeeStructure info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       strg= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (sempTx!=null)
		    	 sempTx.rollback();
				} finally {
					sempSession.close();
				}
		return strg;
	
	}

	@SuppressWarnings("rawtypes")
	public String getFeeStructureBySectionId(int SectionId,int schoolId,int branchId) {
		Session sempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction sempTx=null;
		StringBuffer sb=new StringBuffer();
		String strg= null;
			try {				
					sempTx=sempSession.beginTransaction();
					List list=sempSession.createSQLQuery("select * from gbl_sm_tbl_fee_structure where SectionId like '"+SectionId+"' and isDeleted is null and schoolId="+schoolId+" and branchId="+branchId+";").list();
					Iterator it=list.iterator();
					sb.append("<FeeStructures>");
					sb.append("\n");
					while(it.hasNext()){
						Object[] ex=(Object[])it.next();
						sb.append("<FeeStructure>");
						sb.append("\n");
						sb.append("<feeStructureId>");
				        sb.append("\n");
					    sb.append(ex[0]);
					    sb.append("</feeStructureId>");
					    sb.append("\n");
					    sb.append("<classId>");
						sb.append(ex[1]);
						sb.append("</classId>");
						sb.append("\n");
						sb.append("<sectionId>");
						sb.append(ex[2]);
						sb.append("</sectionId>");
						sb.append("\n");
						sb.append("<title>");
					    sb.append(ex[3]);
					    sb.append("</title>");
					    sb.append("\n");
					    
						sb.append("<description>");
						sb.append(ex[4]);
						sb.append("</description>");
						sb.append("\n");
						
						sb.append("<academicYear>");
						sb.append(ex[5]);
						sb.append("</academicYear>");
						sb.append("\n");
						
						sb.append("<startDate>");
						sb.append(ex[6]);
						sb.append("</startDate>");
						sb.append("\n");
						
						sb.append("<endDate>");
						sb.append(ex[7]);
						sb.append("</endDate>");
						sb.append("\n");
						
						sb.append("<status>");
						sb.append(ex[8]);
						sb.append("</status>");
						sb.append("\n");
						
						sb.append("<createdDate>");
						sb.append(ex[9]);
						sb.append("</createdDate>");
						sb.append("\n");
						
						sb.append("<modifiedDate>");
						sb.append(ex[10]);
						sb.append("</modifiedDate>");
						sb.append("\n");
						sb.append("</FeeStructure>");
						sb.append("\n");
					}
					 sb.append("</FeeStructures>");
					 strg=sb.toString(); 
					 
					 sempTx.commit();
					
			}catch (Exception localException) {
				System.out.println(localException);				
				localException.printStackTrace();  
				sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not getbyclass FeeStructure info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       strg= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (sempTx!=null)
		    	 sempTx.rollback();
				} finally {
					sempSession.close();
				}
		return strg;
	}

}
