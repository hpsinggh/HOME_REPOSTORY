package com.gwebitsol.core.fee;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;
@Path("/event/")
public interface EventIntf {
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/add/")
    public Response addEvent(EventPojo per,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);
	
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/update/")
	public Response updateEvent(EventPojo per,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);
	
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/delete/")
	public Response deleteEvent(@QueryParam("eventId") int  eventId,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);
	
	@GET
	@Consumes({"application/xml", "application/json"})
	@Produces({"application/xml", "application/json"})
	@Path("/get/")
	public Response getByIdEvent(@QueryParam("eventId") int eventId,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);
	
	@GET
	@Consumes({"application/xml", "application/json"})
	@Produces({"application/xml", "application/json"})
	@Path("/getall/")
	public Response getAllEvent(@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName,@QueryParam("PNO") int PNO,@QueryParam("size") int size,@QueryParam("schoolId") int schoolId,@QueryParam("branchId") int branchId);
}
