package com.gwebitsol.core.fee;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.gwebitsol.core.security.MDValidation;
import com.gwebitsol.core.usermanagement.MDGetUserFromID;
import com.gwebitsol.core.util.MDTransactionWriter;

public class PaymentService implements PaymentIntf {
	@Context 
	private HttpServletRequest hsr;
	public Response addPayment(Payment per, int userID, int connectionID, String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String XMLString=null;
	    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		per.setSchoolId(schoolId);
		per.setBranchId(branchId);
		  try
		  {
		   MDValidation mdv = new MDValidation();  
		   int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
		   System.out.println("verifiedvalue::"+ret);
		   
		   MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userID);
		   
		   if(ret==1 )//&& rtVal==1)
		   {
			String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				
				PaymentDao brdao=new PaymentDao();
				XMLString=brdao.addPayment(per);
				
				System.out.println(XMLString);
				MDTransactionWriter.writeLog(datastoreName,"Payment_addPayment",requester,startDate,endDate,sl,el,XMLString,hsr.getRemoteHost());
		   }
			else
			{
				XMLString="you are not authorised user";
			}
		  }
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
		   XMLString="failed in service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}

	public Response updatePayment(Payment per, int userID, int connectionID, String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String XMLString=null;
	    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		per.setSchoolId(schoolId);
		per.setBranchId(branchId);
		 try
		  {
		   MDValidation mdv = new MDValidation();  
		   int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
		   System.out.println("verifiedvalue::"+ret);
		   
		   MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userID);
		   
		   if(ret==1 )//&& rtVal==1)
		   {
			String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				
				PaymentDao brdao=new PaymentDao();
				XMLString=brdao.updatePayment(per,schoolId,branchId);
				
				System.out.println(XMLString);
				MDTransactionWriter.writeLog(datastoreName,"Payment_updatePayment",requester,startDate,endDate,sl,el,XMLString,hsr.getRemoteHost());
		   }
			else
			{
				XMLString="you are not authorised user";
			}
		}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
		   XMLString="failed in service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}

	public Response deletePayment(int paymentId, int userID, int connectionID, String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		@SuppressWarnings("unused")
		String XMLString=null;

				String status=null;
				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date date = new Date();
				String startDate=dateFormat.format(date);
				Long sl=System.currentTimeMillis();
				
				 try
				  {
				   MDValidation mdv = new MDValidation();  
				   int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
				   System.out.println("verifiedvalue::"+ret);
				   
				   MDGetUserFromID mdgufid = new MDGetUserFromID();
					String requester = mdgufid.getUserName(userID);
				   
				   if(ret==1 )//&& rtVal==1)
				   {
						PaymentDao brdao=new PaymentDao();
						status=brdao.deletePayment(paymentId,schoolId,branchId);
				
						String endDate=dateFormat.format(new Date());	
						Long el=System.currentTimeMillis();
				
						MDTransactionWriter.writeLog(datastoreName,"Payment_deletePayment",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
				   }else
				   	{
					   	XMLString="you are not authorised user";
				   	}
		}catch(Exception localException)
			{
				MDTransactionWriter.errorlog.debug(localException);
				MDTransactionWriter.errorlog.info(localException);
				status="failed in service layer";
			}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response getByIdPayment(int paymentId, int userID, int connectionID, String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		@SuppressWarnings("unused")
		String XMLString=null;

		String status1=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();		
		 try
		 	{
			 	   MDValidation mdv = new MDValidation();  
				   int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
				   System.out.println("verifiedvalue::"+ret);
				   
				   MDGetUserFromID mdgufid = new MDGetUserFromID();
					String requester = mdgufid.getUserName(userID);
				   if(ret==1 )//&& rtVal==1)
				   {
						PaymentDao ex=new PaymentDao();
						status1=ex.getByIdPayment(paymentId,schoolId,branchId);
					 
						System.out.println(status1);
						String endDate=dateFormat.format(new Date());
						Long el=System.currentTimeMillis();
					MDTransactionWriter.writeLog(datastoreName,"Payment_getByIdPayment",requester,startDate,endDate,sl,el,status1,hsr.getRemoteHost());		
			}else
			{
				XMLString="you are not authorised user";
			}
		}catch(Exception localException)
			{
				MDTransactionWriter.errorlog.debug(localException);
				MDTransactionWriter.errorlog.info(localException);
				status1="failed in service layer";
				//System.out.println(localException);
			}
		 return Response.ok().type(MediaType.APPLICATION_XML).entity(status1).build();
	}

	public Response getAllPayment(int userID, int connectionID, String datastoreName,int PNO,int size,int schoolId,int branchId,int classId,int sectionId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		@SuppressWarnings("unused")
		String XMLString=null;

				String status=null;
				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date date = new Date();
				String startDate=dateFormat.format(date);
				Long sl=System.currentTimeMillis();
				 try
				  {
				   MDValidation mdv = new MDValidation();  
				   int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
				   System.out.println("verifiedvalue::"+ret);
				   MDGetUserFromID mdgufid = new MDGetUserFromID();
					String requester = mdgufid.getUserName(userID);
				   if(ret==1 )//&& rtVal==1)
				   {
						PaymentDao ex=new PaymentDao();
					status=ex.getAllPayment(PNO,size,schoolId,branchId,classId,sectionId);
					
					System.out.println(status);
					String endDate=dateFormat.format(new Date());
					  Long el=System.currentTimeMillis();
					 MDTransactionWriter.writeLog(datastoreName,"Payment_getAllPayment",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		

				}else
				{
					XMLString="you are not authorised user";
				}
			}
					catch(Exception localException)
				   {
					  MDTransactionWriter.errorlog.debug(localException);
					  MDTransactionWriter.errorlog.info(localException);
					  status="failed in service layer";
				   }
				return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response getFeeItemPaymentId(int paymentId, int userID, int connectionID, String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		@SuppressWarnings("unused")
		String XMLString=null;

				String status1=null;
				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date date = new Date();
				String startDate=dateFormat.format(date);
				Long sl=System.currentTimeMillis();
				
				 try
				  {
				   MDValidation mdv = new MDValidation();  
				   int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
				   System.out.println("verifiedvalue::"+ret);
				   MDGetUserFromID mdgufid = new MDGetUserFromID();
					String requester = mdgufid.getUserName(userID);
				   if(ret==1 )//&& rtVal==1)
				   {
						PaymentDao ex=new PaymentDao();
					 status1=ex.getFeeItemPaymentId(paymentId,schoolId,branchId);
					 
					 System.out.println(status1);
					String endDate=dateFormat.format(new Date());
					Long el=System.currentTimeMillis();
					//status1="user validation successfull";
					MDTransactionWriter.writeLog(datastoreName,"Payment_getFeeItemPaymentId",requester,startDate,endDate,sl,el,status1,hsr.getRemoteHost());		
			}else
			{
				XMLString="you are not authorised user";
			}
		}

			catch(Exception localException)
			{
				MDTransactionWriter.errorlog.debug(localException);
				MDTransactionWriter.errorlog.info(localException);
				status1="failed in service layer";
				//System.out.println(localException);
			}
		 return Response.ok().type(MediaType.APPLICATION_XML).entity(status1).build();
			}

}
