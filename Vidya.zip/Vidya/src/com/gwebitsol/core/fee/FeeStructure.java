package com.gwebitsol.core.fee;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="FeeStructure")
public class FeeStructure {
	private String feeItemStructureId;
	private int feeStructureId;
	private String title;
	private String description;
	private int classId;
	private int sectionId;
	private String academicYear;
	private String startDate;
	private String endDate;
	private String status;
	private String 	createdDate;
	DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	 Date date = new Date();
	 String modifiedDate=dateFormat.format(date);
	
	
		private int schoolId;
		private int branchId;
		private String feeItemId;
		public String getFeeItemId() {
			return feeItemId;
		}
		public void setFeeItemId(String feeItemId) {
			this.feeItemId = feeItemId;
		}
		public String getCreatedDate() {
			return createdDate;
		}
		public void setCreatedDate(String createdDate) {
			this.createdDate = createdDate;
		}
		public String getModifiedDate() {
			return modifiedDate;
		}
		public void setModifiedDate(String modifiedDate) {
			this.modifiedDate = modifiedDate;
		}
		public int getSchoolId() {
			return schoolId;
		}
		public void setSchoolId(int schoolId) {
			this.schoolId = schoolId;
		}
		public int getBranchId() {
			return branchId;
		}
		public void setBranchId(int branchId) {
			this.branchId = branchId;
		}
	public String getAcademicYear() {
		return academicYear;
	}
	public void setAcademicYear(String academicYear) {
		this.academicYear = academicYear;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public int getFeeStructureId() {
		return feeStructureId;
	}
	public void setFeeStructureId(int feeStructureId) {
		this.feeStructureId = feeStructureId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getClassId() {
		return classId;
	}
	public void setClassId(int classId) {
		this.classId = classId;
	}
	public int getSectionId() {
		return sectionId;
	}
	public void setSectionId(int sectionId) {
		this.sectionId = sectionId;
	}
	public String getFeeItemStructureId() {
		return feeItemStructureId;
	}
	public void setFeeItemStructureId(String feeItemStructureId) {
		this.feeItemStructureId = feeItemStructureId;
	}
	
	
}
