package com.gwebitsol.core.fee;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class PaymentItemDao {
	
	public String addPaymentItem(PaymentItem per) {
		Session addempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction addempTx=null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			addempTx=addempSession.beginTransaction();
	        Integer in=(Integer)addempSession.save(per);
			System.out.println(in);
			
			addempTx.commit();
			
			sb.append("<paymentitem>");
			sb.append("\n");
			sb.append("<paymentItemId>");
			sb.append(in);
			sb.append("</paymentItemId>");
			sb.append("</paymentitem>");
			String str=sb.toString();
			return str;
		   
   		 	}
		
		catch(Exception localException)
		{
			System.out.println(localException);
			
			localException.printStackTrace();  
			sb.append("<Response>");
	       sb.append("\n");
	       sb.append("<Result>");
	       sb.append("\n");
	       sb.append("Fail");
	       sb.append("\n");
	       sb.append("</Result>");
	       sb.append("\n");
	       sb.append("<Description>");
	       
	       sb.append("could not inserted paymentitem info");
	       sb.append("</Description>");
	       sb.append("\n");
	       sb.append("<Exception>");
	       sb.append(localException);
	       sb.append("</Exception>");
	       sb.append("</Response>");
	       outStr= sb.toString();
	      MDTransactionWriter.exceptionlog.info(localException);
	     if (addempTx!=null)
	      addempTx.rollback();
		}
		finally
		{			
			addempSession.close();
		}
		return outStr;

	}

	public String updatePaymentItem(PaymentItem per) {
		Session upempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction upempTx=null;
		StringBuffer sb=new StringBuffer();

		String outStr=null;
		try
		{
			upempTx=upempSession.beginTransaction();
			 upempSession.update(per);
				
				upempTx.commit();
				
				sb.append("<paymentitem>");
				sb.append("\n");
				sb.append("update successfully");
				sb.append("</paymentitem>");
				String str=sb.toString();
				return str;
			   
	   		 	}
			
			catch(Exception localException)
			{
				System.out.println(localException);
				
				localException.printStackTrace();  
				sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not update paymentitem info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       outStr= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (upempTx!=null)
		    	 upempTx.rollback();
			}
			finally
			{			
				upempSession.close();
			}
			return outStr;

	}

	public String deletePaymentItem(int paymentItemId) {
		Session delempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction delempTx=null;
		StringBuffer sb=new StringBuffer();

		String outStr=null;
		try
		{
			delempTx=delempSession.beginTransaction();
			
			PaymentItem brp=new PaymentItem();
			brp.setPaymentItemId(paymentItemId);
			delempSession.delete(brp);
			
			
				delempTx.commit();
				
				sb.append("<paymentitem>");
				sb.append("\n");
				sb.append("delete successfully");
				sb.append("</paymentitem>");
				String str=sb.toString();
				return str;
			   
	   		 	}
			
			catch(Exception localException)
			{
				System.out.println(localException);
				
				localException.printStackTrace();  
				sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not delete paymentitem info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       outStr= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (delempTx!=null)
		    	 delempTx.rollback();
			}
			finally
			{			
				delempSession.close();
			}
			return outStr;
	}

	public String getByIdPaymentItem(int paymentItemId) {
		Session gtempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gtempTx=null;
		StringBuffer sb=new StringBuffer();

		
		System.out.println("hi success");
		String strg= null;
			try {
					gtempTx = gtempSession.beginTransaction();
					PaymentItem ex=(PaymentItem)gtempSession.get(PaymentItem.class,new Integer(paymentItemId));
					if(ex==null){
						System.out.println("there is no PaymentItem object");
					}else{
						 sb.append("<paymentitem>");
					        sb.append("\n");
					        sb.append("<paymentItemId>");
						    sb.append(ex.getPaymentItemId());
						    sb.append("</paymentItemId>");
						    sb.append("\n");
					        sb.append("<feeItemId>");
						    sb.append(ex.getFeeItemId());
						    sb.append("</feeItemId>");
						    sb.append("\n");
						    sb.append("<paymentId>");
							sb.append(ex.getPaymentId());
							sb.append("</paymentId>");
							sb.append("\n");
							sb.append("</paymentitem>");
					   String str= sb.toString();
						return str;
					}
					
			} 	catch (Exception localException) {
				System.out.println(localException);
				
				localException.printStackTrace();  
				sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not get paymentitem info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       strg= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (gtempTx!=null)
		    	 gtempTx.rollback();
				} finally {
					gtempSession.close();
				}
		return strg;
	}

	@SuppressWarnings("unchecked")
	public String getAllPaymentItem() {
		Session rdSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb= new StringBuffer();
		String string=null;
		PaymentItem ex=null;
		
		try
		{
			tx = rdSession.beginTransaction();
			List<PaymentItem> list=rdSession.createCriteria(PaymentItem.class).list();
			 sb.append("<PaymentItem>");
			for(Iterator<PaymentItem> it=list.iterator();it.hasNext();){
				ex=(PaymentItem)it.next();
				
			
			if(ex==null){
				System.out.println("there is no PaymentItem object");
			}else{
				 sb.append("\n");
				 sb.append("<PaymentItem>");
				 sb.append("\n");
				 sb.append("<paymentItemId>");
				    sb.append(ex.getPaymentItemId());
				    sb.append("</paymentItemId>");
				    sb.append("\n");
			        sb.append("<feeItemId>");
				    sb.append(ex.getFeeItemId());
				    sb.append("</feeItemId>");
				    sb.append("\n");
				    sb.append("<paymentId>");
					sb.append(ex.getPaymentId());
					sb.append("</paymentId>");
					sb.append("\n");
					sb.append("</PaymentItem>");
			}
		}
			sb.append("</PaymentItem>");
					    String str= sb.toString();
						 tx.commit();
					return str;
		}
		catch(Exception localException)
		{
			System.out.println(localException);
			
			localException.printStackTrace();  
			sb.append("<Response>");
	       sb.append("\n");
	       sb.append("<Result>");
	       sb.append("\n");
	       sb.append("Fail");
	       sb.append("\n");
	       sb.append("</Result>");
	       sb.append("\n");
	       sb.append("<Description>");
	       
	       sb.append("could not getall paymentitem info");
	       sb.append("</Description>");
	       sb.append("\n");
	       sb.append("<Exception>");
	       sb.append(localException);
	       sb.append("</Exception>");
	       sb.append("</Response>");
	       string = sb.toString();
	      MDTransactionWriter.exceptionlog.info(localException);
	     if (tx!=null)
	    	 tx.rollback();
		}
		finally
		{
			rdSession.close();
		
		}
		return string;
	}

}
