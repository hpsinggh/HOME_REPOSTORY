package com.gwebitsol.core.fee;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class FeeItemDao {

	public String addFeeItem(FeeItemPojo per) {
		Session addempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction addempTx=null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			addempTx=addempSession.beginTransaction();
	        Integer in=(Integer)addempSession.save(per);
			System.out.println(in);
			
			addempTx.commit();
			
			sb.append("<FeeItem>");
			sb.append("\n");
			sb.append("<feeItemId>");
			sb.append(in);
			sb.append("</feeItemId>");
			sb.append("</FeeItem>");
			String str=sb.toString();
			return str; 
   		 	}
		catch(Exception localException)
		{
			System.out.println(localException);
			
			localException.printStackTrace();  
			sb.append("<Response>");
	       sb.append("\n");
	       sb.append("<Result>");
	       sb.append("\n");
	       sb.append("Fail");
	       sb.append("\n");
	       sb.append("</Result>");
	       sb.append("\n");
	       sb.append("<Description>");
	       
	       sb.append("could not inserted FeeItem info");
	       sb.append("</Description>");
	       sb.append("\n");
	       sb.append("<Exception>");
	       sb.append(localException);
	       sb.append("</Exception>");
	       sb.append("</Response>");
	       outStr= sb.toString();
	      MDTransactionWriter.exceptionlog.info(localException);
	     if (addempTx!=null)
	      addempTx.rollback();
		}
		finally
		{			
			addempSession.close();
		}
		return outStr;
	}

	public String updateFeeItem(FeeItemPojo per,int schoolId,int branchId) {
		Session upempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction upempTx=null;
		StringBuffer sb=new StringBuffer();

		String outStr=null;
		try
		{
			upempTx=upempSession.beginTransaction();
			FeeItemPojo feeitem = (FeeItemPojo) upempSession.get(FeeItemPojo.class,per.getFeeItemId());
		      
			   	if(branchId==feeitem.getBranchId()&&schoolId==feeitem.getSchoolId())
			       
			    upempSession.evict(feeitem);
			   	upempSession.update(per);
				
				upempTx.commit();
				
				sb.append("<FeeItem>");
				sb.append("\n");
				sb.append("update successfully");
				sb.append("</FeeItem>");
				String str=sb.toString();
				return str;
	   		 	}
			catch(Exception localException)
			{
				System.out.println(localException);
				
				localException.printStackTrace();  
				sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not update FeeItem info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       outStr= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (upempTx!=null)
		    	 upempTx.rollback();
			}
			finally
			{			
				upempSession.close();
			}
			return outStr;

	}

	public String deleteFeeItem(int feeItemId,int schoolId,int branchId) {
		Session delempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction delempTx=null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			delempTx=delempSession.beginTransaction();
			FeeItemPojo mdclpojo = (FeeItemPojo) delempSession.get(FeeItemPojo.class,feeItemId);
			   
			   int branid = mdclpojo.getBranchId();
			   int sclid = mdclpojo.getSchoolId();
			   delempSession.evict(mdclpojo);
			   if(branchId==branid&&schoolId==sclid)		   
			   {
				   Query empQuery=delempSession.createSQLQuery("update gbl_sm_tbl_fee_item set isDeleted='y' where feeItemId='"+feeItemId+"'");
				   empQuery.executeUpdate();
			
				   delempTx.commit();
				
				   sb.append("<FeeItem>");
				   sb.append("\n");
				   sb.append("delete successfully");
				   sb.append("</FeeItem>");
				   String str=sb.toString();
				   return str;
	   		 	}
		}
			catch(Exception localException)
			{
				System.out.println(localException);
				
				localException.printStackTrace();  
				sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not delete FeeItem info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       outStr= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (delempTx!=null)
		    	 delempTx.rollback();
			}
			finally
			{			
				delempSession.close();
			}
			return outStr;
	}

	@SuppressWarnings("rawtypes")
	public String getByIdFeeItem(int feeItemId,int schoolId,int branchId) {
		Session gtempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gtempTx=null;
		StringBuffer sb=new StringBuffer();
		String strg= null;
			try {
					gtempTx = gtempSession.beginTransaction();
					List list=gtempSession.createSQLQuery("select fi.FeeItemId,fi.ItemName,fi.FeeItemTypeId,fit.Name,fi.StudentId,stud.StudentNumber,stud.FirstName,stud.LastName,fi.EventId,ev.EventName,fi.CategoryId,fst.CATEGORYNAME,fi.StartDate,fi.EndDate,fi.Amount,fi.ValidFrom,fi.ValidTo,fi.`Status`,fi.Description,fi.SchoolId,fi.BranchId from gbl_sm_tbl_fee_item as fi join gbl_sm_tbl_feeitemtype as fit on fi.FeeItemTypeId=fit.FeeItemTypeId join gbl_sm_tbl_event as ev on fi.EventId=ev.EventId join mdcategory as fst on fi.CategoryId=fst.CATEGORYID join gbl_sm_tbl_student as stud on fi.StudentId=stud.StudentId where fi.FeeItemId='" + feeItemId + "' and fi.SchoolId='" + schoolId + "' and fi.BranchId='" + branchId + "' and fi.IsDeleted Is Null;").list();
					Iterator it=list.iterator();
					sb.append("<FeeItem>");
					while(it.hasNext()){
						Object[] ex=(Object[])it.next();
				        sb.append("\n");
				        sb.append("<feeItemId>");
					    sb.append(ex[0]);
					    sb.append("</feeItemId>");
					    sb.append("\n");
					    sb.append("<itemName>");
						sb.append(ex[1]);
						sb.append("</itemName>");
						sb.append("\n");
						
					    sb.append("<feeItemTypeId>");
						sb.append(ex[2]);
						sb.append("</feeItemTypeId>");
						sb.append("\n");
						sb.append("<name>");
						sb.append(ex[3]);
						sb.append("</name>");
						sb.append("\n");
						
				        sb.append("<studentId>");
					    sb.append(ex[4]);
					    sb.append("</studentId>");
					    sb.append("\n");
					    sb.append("<studentNumber>");
					    sb.append(ex[5]);
					    sb.append("</studentNumber>");
					    sb.append("\n");
					    sb.append("<firstName>");
					    sb.append(ex[6]);
					    sb.append("</firstName>");
					    sb.append("\n");
					    sb.append("<lastName>");
					    sb.append(ex[7]);
					    sb.append("</lastName>");
					    sb.append("\n");
					    
					    sb.append("<eventId>");
						sb.append(ex[8]);
						sb.append("</eventId>");
						sb.append("\n");
						sb.append("<eventName>");
						sb.append(ex[9]);
						sb.append("</eventName>");
						sb.append("\n");
						
						
						/*sb.append("<classId>");
					    sb.append(ex[10]);
					    sb.append("</classId>");
					    sb.append("\n");
					    sb.append("<className>");
					    sb.append(ex[11]);
					    sb.append("</className>");
					    sb.append("\n");
					    
					    
					    sb.append("<sectionId>");
						sb.append(ex[12]);
						sb.append("</sectionId>");
						sb.append("\n");
						sb.append("<sectionName>");
						sb.append(ex[10]);
						sb.append("</sectionName>");
						sb.append("\n");*/
						
						
				        sb.append("<categoryId>");
					    sb.append(ex[10]);
					    sb.append("</categoryId>");
					    sb.append("\n");
					    sb.append("<categoryName>");
					    sb.append(ex[11]);
					    sb.append("</categoryName>");
					    sb.append("\n");
					    
						sb.append("<startDate>");
					    sb.append(ex[12]);
					    sb.append("</startDate>");
					    sb.append("\n");
					    sb.append("<endDate>");
						sb.append(ex[13]);
						sb.append("</endDate>");
						sb.append("\n");
				        sb.append("<amount>");
					    sb.append(ex[14]);
					    sb.append("</amount>");
					    sb.append("\n");
					    sb.append("<validFrom>");
						sb.append(ex[15]);
						sb.append("</validFrom>");
						sb.append("\n");
						sb.append("<validTo>");
						sb.append(ex[16]);
						sb.append("</validTo>");
						sb.append("\n");
						sb.append("<status>");
						sb.append(ex[17]);
						sb.append("</status>");
						sb.append("\n");
						sb.append("<description>");
						sb.append(ex[18]);
						sb.append("</description>");
						sb.append("\n");
						sb.append("<schoolId>");
				        sb.append(ex[19]);
				        sb.append("</schoolId>");
				        sb.append("\n");
				        sb.append("<branchId>");
				        sb.append(ex[20]);
				        sb.append("</branchId>");
				        sb.append("\n");
					}
					sb.append("</FeeItem>");
					strg=sb.toString(); 
					 
					 gtempTx.commit();					
			} 	catch (Exception localException) {
				System.out.println(localException);
				localException.printStackTrace();  
				sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not get FeeItem info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       strg= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (gtempTx!=null)
		    	 gtempTx.rollback();
				} finally {
					gtempSession.close();
				}
		return strg;
	}

	@SuppressWarnings({ "rawtypes" })
	public String getAllFeeItem(int PNO,int size,int schoolId,int branchId,int classId,int sectionId,int studentId) {
		Session rdSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb= new StringBuffer();
		String string=null;
		String gsSql=null;
		try
		{
			tx = rdSession.beginTransaction();
			int fset = (PNO-1)*size;
			gsSql ="select count(*) from gbl_sm_tbl_fee_item where isDeleted is null and schoolId="+schoolId+" and branchId="+branchId+"";
			/*if(classId!=0){
				gsSql += " and classId="+classId;
			if(sectionId!=0){
				gsSql +=  " and sectionId="+sectionId;
				}
			if(studentId!=0){
				gsSql += " and studentId="+studentId;
				}
				}gsSql +=";";*/
			Query gsQuery=rdSession.createSQLQuery(gsSql);
			Object noRecords= gsQuery.uniqueResult();
			int intNoRecords=0;
			if(noRecords!=null && Integer.parseInt(noRecords.toString())!=0)
			{
				intNoRecords=Integer.parseInt(noRecords.toString());
			}
			sb.append("<FeeItems>");
			sb.append("\n");
			sb.append("<noRecords>"+intNoRecords+"</noRecords>");
			sb.append("\n");
			if(intNoRecords!=0)
			{
			 if (PNO > 0 & size > 0){
			 gsSql="select fi.FeeItemId,fi.ItemName,fi.FeeItemTypeId,fit.Name,fi.StudentId,stud.StudentNumber,stud.FirstName,stud.LastName,fi.EventId,ev.EventName,fi.CategoryId,fst.CATEGORYNAME,fi.StartDate,fi.EndDate,fi.Amount,fi.ValidFrom,fi.ValidTo,fi.`Status`,fi.Description,fi.SchoolId,fi.BranchId from gbl_sm_tbl_fee_item as fi join gbl_sm_tbl_feeitemtype as fit on fi.FeeItemTypeId=fit.FeeItemTypeId join gbl_sm_tbl_event as ev on fi.EventId=ev.EventId join mdcategory as fst on fi.CategoryId=fst.CATEGORYID join gbl_sm_tbl_student as stud on fi.StudentId=stud.StudentId where fi.SchoolId='" + schoolId + "' and fi.BranchId='" + branchId + "' and fi.IsDeleted Is Null";
			 if(classId!=0){
				   gsSql += " and fi.classId="+classId;
			   if(sectionId!=0){
				   gsSql +=  " and fi.sectionId="+sectionId;
			   }
				 if(studentId!=0){
					gsSql += " and fi.studentId="+studentId;
			   }
			   }gsSql +=" limit "+size+" offset "+fset;
			 }
			 else {
			  gsSql="select fi.FeeItemId,fi.ItemName,fi.FeeItemTypeId,fit.Name,fi.StudentId,stud.StudentNumber,stud.FirstName,stud.LastName,fi.EventId,ev.EventName,fi.CategoryId,fst.CATEGORYNAME,fi.StartDate,fi.EndDate,fi.Amount,fi.ValidFrom,fi.ValidTo,fi.`Status`,fi.Description,fi.SchoolId,fi.BranchId from gbl_sm_tbl_fee_item as fi join gbl_sm_tbl_feeitemtype as fit on fi.FeeItemTypeId=fit.FeeItemTypeId join gbl_sm_tbl_event as ev on fi.EventId=ev.EventId join mdcategory as fst on fi.CategoryId=fst.CATEGORYID join gbl_sm_tbl_student as stud on fi.StudentId=stud.StudentId where fi.SchoolId='" + schoolId + "' and fi.BranchId='" + branchId + "' and fi.IsDeleted Is Null ";
			  if(classId!=0){
				   gsSql += " and fi.classId="+classId;
			   if(sectionId!=0){
				   gsSql +=  " and fi.sectionId="+sectionId;
			   }
				 if(studentId!=0){
					gsSql += " and fi.studentId="+studentId;
			   }
			   }gsSql +=";";
			 }
			  
			    gsQuery=rdSession.createSQLQuery(gsSql);
			    List gcList=gsQuery.list();
			    Iterator gsIT=gcList.iterator();
			 while(gsIT.hasNext())
			 {
			  Object[] mdcArr=(Object[])gsIT.next();
			   sb.append("<FeeItem>");
			  sb.append("\n");
			  sb.append("<feeItemId>"+mdcArr[0]+"</feeItemId>");
			  sb.append("\n");
			  sb.append("<itemName>" + mdcArr[1]+ "</itemName>");
			  sb.append("\n");
			  sb.append("<feeItemTypeId>" + mdcArr[2]+ "</feeItemTypeId>");
			  sb.append("\n");
			  sb.append("<name>" + mdcArr[3]+ "</name>");
			  sb.append("\n");
			  sb.append("<studentId>" + mdcArr[4]+ "</studentId>");
			  sb.append("\n");
			  sb.append("<studentNumber>" + mdcArr[5] + "</studentNumber>");
			  sb.append("\n");
			  sb.append("<firstName>" + mdcArr[6]+ "</firstName>");
			  sb.append("\n");
			  sb.append("<lastName>" + mdcArr[7] + "</lastName>");
			  sb.append("\n");
			  sb.append("<eventId>" + mdcArr[8]+ "</eventId>");
			  sb.append("\n");
			  sb.append("<eventName>" + mdcArr[9] + "</eventName>");
			  sb.append("\n");
			 /* sb.append("<classId>" + mdcArr[10] + "</classId>");
			  sb.append("\n");
			  sb.append("<className>" + mdcArr[11] + "</className>");
			  sb.append("\n");
			  sb.append("<sectionId>" + mdcArr[12] + "</sectionId>");
			  sb.append("\n");
			  sb.append("<sectionName>" + mdcArr[13]+ "</sectionName>");
			  sb.append("\n");*/
			  sb.append("<categoryId>" +  mdcArr[10]+ "</categoryId>");
			  sb.append("\n");
			  sb.append("<categoryName>" +  mdcArr[11]+ "</categoryName>");
			  sb.append("\n");
			  sb.append("<startDate>" + mdcArr[12]+ "</startDate>");
			  sb.append("\n");
			  sb.append("<endDate>" + mdcArr[13] + "</endDate>");
			  sb.append("\n");
			  sb.append("<amount>" +  mdcArr[14] + "</amount>");
			  sb.append("\n");
			  sb.append("<validFrom>" + mdcArr[15]+ "</validFrom>");
			  sb.append("\n");
			  sb.append("<validTo>" + mdcArr[16]+ "</validTo>");
			  sb.append("\n");
			  sb.append("<status>" + mdcArr[17] + "</status>");
			  sb.append("\n");
			  sb.append("<description>" + mdcArr[18]+ "</description>");
			  sb.append("\n");
			  sb.append("<schoolId>" + mdcArr[19]+ "</schoolId>");
			  sb.append("\n");
			  sb.append("<branchId>" + mdcArr[20]+ "</branchId>");
			  sb.append("\n");
			  sb.append("</FeeItem>");
			  sb.append("\n");
			 }
			}
			tx.commit();
			sb.append("</FeeItems>");
			string=sb.toString();
			   
			  } 
			  catch(Exception localException)
			  {
			   tx.rollback();
			   localException.printStackTrace();
			   string = "fail";
			   System.out.println("Could not Get FeeItem");
			  }
			  finally
			  {
			   rdSession.close();
			  } 
			  return string;
	}

	@SuppressWarnings("rawtypes")
	public String getAllFeeItemByStructureId(int feeStructureId,int PNO, int size, int schoolId, int branchId) {
		Session rdSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb= new StringBuffer();
		String string=null;
		
		try
		{
			tx = rdSession.beginTransaction();
			int fset = (PNO-1)*size;
			String gsSql ="select count(*) from gbl_sm_tbl_fee_item where isDeleted is null and schoolId="+schoolId+" and branchId="+branchId+" and feeitemid in(select feeitemid from gbl_sm_tbl_feeitem_structure where feestructureid="+feeStructureId+")";
			Query gsQuery=rdSession.createSQLQuery(gsSql);
			Object noRecords= gsQuery.uniqueResult();
			sb.append("<FeeItems>");
			sb.append("\n");
			sb.append("<noRecords>"+noRecords+"</noRecords>");
			sb.append("\n");
			if (PNO > 0 & size > 0){
			 gsSql="select fi.FeeItemId,fi.ItemName,fi.FeeItemTypeId,fit.Name,fi.StudentId,stud.StudentNumber,stud.FirstName,stud.LastName,fi.EventId,ev.EventName,fi.CategoryId,fst.CATEGORYNAME, fi.StartDate,fi.EndDate,fi.Amount,fi.ValidFrom,fi.ValidTo,fi.`Status`,fi.Description,fi.SchoolId,fi.BranchId from gbl_sm_tbl_fee_item as fi join gbl_sm_tbl_feeitemtype as fit on fi.FeeItemTypeId=fit.FeeItemTypeId join gbl_sm_tbl_event as ev on fi.EventId=ev.EventId join mdcategory as fst on fi.CategoryId=fst.CATEGORYID join gbl_sm_tbl_student as stud on fi.StudentId=stud.StudentId where feeitemid in(select feeitemid from gbl_sm_tbl_feeitem_structure where feestructureid='" + feeStructureId + "') and fi.SchoolId='" + schoolId + "' and fi.BranchId='" + branchId + "' and fi.IsDeleted Is Null limit "+size+" offset "+fset;
			 }
			 else {
			  gsSql="select fi.FeeItemId,fi.ItemName,fi.FeeItemTypeId,fit.Name,fi.StudentId,stud.StudentNumber,stud.FirstName,stud.LastName,fi.EventId,ev.EventName,fi.CategoryId,fst.CATEGORYNAME, fi.StartDate,fi.EndDate,fi.Amount,fi.ValidFrom,fi.ValidTo,fi.`Status`,fi.Description,fi.SchoolId,fi.BranchId from gbl_sm_tbl_fee_item as fi join gbl_sm_tbl_feeitemtype as fit on fi.FeeItemTypeId=fit.FeeItemTypeId join gbl_sm_tbl_event as ev on fi.EventId=ev.EventId join mdcategory as fst on fi.CategoryId=fst.CATEGORYID join gbl_sm_tbl_student as stud on fi.StudentId=stud.StudentId where  feeitemid in(select feeitemid from gbl_sm_tbl_feeitem_structure where feestructureid='" + feeStructureId + "') and fi.SchoolId='" + schoolId + "' and fi.BranchId='" + branchId + "' and fi.IsDeleted Is Null;";
			 }
			    gsQuery=rdSession.createSQLQuery(gsSql);
			    List gcList=gsQuery.list();
			    Iterator gsIT=gcList.iterator();
			 while(gsIT.hasNext())
			 {
			  Object[] mdcArr=(Object[])gsIT.next();
			   sb.append("<FeeItem>");
			  sb.append("\n");
			  sb.append("<feeStructureId>"+feeStructureId+"</feeStructureId>");
			  sb.append("\n");
			  sb.append("<feeItemId>"+mdcArr[0]+"</feeItemId>");
			  sb.append("\n");
			  sb.append("<itemName>" + mdcArr[1]+ "</itemName>");
			  sb.append("\n");
			  sb.append("<feeItemTypeId>" + mdcArr[2]+ "</feeItemTypeId>");
			  sb.append("\n");
			  sb.append("<name>" + mdcArr[3]+ "</name>");
			  sb.append("\n");
			  sb.append("<studentId>" + mdcArr[4]+ "</studentId>");
			  sb.append("\n");
			  sb.append("<studentNumber>" + mdcArr[5] + "</studentNumber>");
			  sb.append("\n");
			  sb.append("<firstName>" + mdcArr[6]+ "</firstName>");
			  sb.append("\n");
			  sb.append("<lastName>" + mdcArr[7] + "</lastName>");
			  sb.append("\n");
			  sb.append("<eventId>" + mdcArr[8]+ "</eventId>");
			  sb.append("\n");
			  sb.append("<eventName>" + mdcArr[9] + "</eventName>");
			  sb.append("\n");
			 /* sb.append("<classId>" + mdcArr[10] + "</classId>");
			  sb.append("\n");
			  sb.append("<className>" + mdcArr[11] + "</className>");
			  sb.append("\n");
			  sb.append("<sectionId>" + mdcArr[12] + "</sectionId>");
			  sb.append("\n");
			  sb.append("<sectionName>" + mdcArr[13]+ "</sectionName>");
			  sb.append("\n");*/
			  sb.append("<categoryId>" +  mdcArr[10]+ "</categoryId>");
			  sb.append("\n");
			  sb.append("<categoryName>" +  mdcArr[11]+ "</categoryName>");
			  sb.append("\n");
			  sb.append("<startDate>" + mdcArr[12]+ "</startDate>");
			  sb.append("\n");
			  sb.append("<endDate>" + mdcArr[13] + "</endDate>");
			  sb.append("\n");
			  sb.append("<amount>" +  mdcArr[14] + "</amount>");
			  sb.append("\n");
			  sb.append("<validFrom>" + mdcArr[15]+ "</validFrom>");
			  sb.append("\n");
			  sb.append("<validTo>" + mdcArr[16]+ "</validTo>");
			  sb.append("\n");
			  sb.append("<status>" + mdcArr[17] + "</status>");
			  sb.append("\n");
			  sb.append("<description>" + mdcArr[18]+ "</description>");
			  sb.append("\n");
			  sb.append("<schoolId>" + mdcArr[19]+ "</schoolId>");
			  sb.append("\n");
			  sb.append("<branchId>" + mdcArr[20]+ "</branchId>");
			  sb.append("\n");
			  sb.append("</FeeItem>");
			  sb.append("\n");
			 }
			
			tx.commit();
			sb.append("</FeeItems>");
			string=sb.toString();
			   
			  } 
			  catch(Exception localException)
			  {
			   tx.rollback();
			   localException.printStackTrace();
			   string = "fail";
			   System.out.println("Could not Get FeeItem");
			  }
			  finally
			  {
			   rdSession.close();
			  } 
			  return string;
	}

}
