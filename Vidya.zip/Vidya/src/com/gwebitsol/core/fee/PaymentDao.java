package com.gwebitsol.core.fee;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class PaymentDao {

	public String addPayment(Payment per) {
		Session addempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction addempTx=null;
		  String sqlstr = null;
		  StringBuffer sb=new StringBuffer();
		  String outStr=null;
		try
		{
			addempTx=addempSession.beginTransaction();
			   
			   int PaymentId;
			   int FeeItemId;
			   
			   PaymentId=(Integer)addempSession.save(per);
			  
			   String fat = per.getFeeItemId();  
			   
			   String[] x = fat.split(",");
			   
			    for(int i=0;i<=x.length-1;i++)
			    {
			    FeeItemId  = Integer.parseInt(x[i]);         
			     sqlstr = "insert into gbl_sm_tbl_paymentitem(PaymentId,FeeItemId)values('"+PaymentId+"','"+FeeItemId+"');";
			     SQLQuery stpar = addempSession.createSQLQuery(sqlstr);
			     stpar.executeUpdate();
			    } 
			  
			   addempTx.commit();
			  
			   sb.append("<payment>");
			   sb.append("\n");
			   sb.append("<paymentId>");
			   sb.append(PaymentId);
			   sb.append("</paymentId>");
			   sb.append("</payment>");
			   outStr=sb.toString();
			   
			       }
		catch(Exception localException)
		{
			System.out.println(localException);
			
			localException.printStackTrace();  
			sb.append("<Response>");
	       sb.append("\n");
	       sb.append("<Result>");
	       sb.append("\n");
	       sb.append("Fail");
	       sb.append("\n");
	       sb.append("</Result>");
	       sb.append("\n");
	       sb.append("<Description>");
	       
	       sb.append("could not inserted payment info");
	       sb.append("</Description>");
	       sb.append("\n");
	       sb.append("<Exception>");
	       sb.append(localException);
	       sb.append("</Exception>");
	       sb.append("</Response>");
	       outStr= sb.toString();
	      MDTransactionWriter.exceptionlog.info(localException);
	     if (addempTx!=null)
	      addempTx.rollback();
		}
		finally
		{			
			addempSession.close();
		}
		return outStr;
	}

	public String updatePayment(Payment per,int schoolId,int branchId) {
		Session upempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction upempTx=null;
		StringBuffer sb=new StringBuffer();

		String outStr=null;
		try
		{
				upempTx=upempSession.beginTransaction();
				Payment pay = (Payment) upempSession.get(Payment.class,per.getPaymentId());
		      
			   	if(branchId==pay.getBranchId()&&schoolId==pay.getSchoolId())
			       
			    upempSession.evict(pay);
			   	upempSession.update(per);
			   	int paymentId = per.getPaymentId();
				int FeeItemId;
				Query empQuery=upempSession.createSQLQuery("delete from gbl_sm_tbl_paymentitem  where paymentId='"+paymentId+"'");
				   empQuery.executeUpdate();
				   String fat = per.getFeeItemId(); 
				   String[] x = fat.split(",");
				   
				    for(int i=0;i<=x.length-1;i++)
				    {
				    FeeItemId  = Integer.parseInt(x[i]);         
				  String sqlstr = "insert into gbl_sm_tbl_paymentitem(PaymentId,FeeItemId)values('"+paymentId+"','"+FeeItemId+"');";
				     SQLQuery stpar = upempSession.createSQLQuery(sqlstr);
				     stpar.executeUpdate();
				    } 
				/*int PaymentItemId;
				
				   String f=per.getPaymentItemId();
				   String[] x = fat.split(",");
				   String[] y =f.split(",");
				    for(int i=0;i<=x.length-1;i++)
				    {	
				    FeeItemId  = Integer.parseInt(x[i]);
				    PaymentItemId =Integer.parseInt(y[i]);
				   String  sqlstr = "update  gbl_sm_tbl_paymentitem set PaymentId='"+paymentId+"',FeeItemId='"+FeeItemId+"' where PaymentItemId='"+PaymentItemId+"';";
				     SQLQuery stpar = upempSession.createSQLQuery(sqlstr);
				     stpar.executeUpdate();
				    } */
				upempTx.commit();
				
				sb.append("<payment>");
				sb.append("\n");
				sb.append("update successfully");
				sb.append("</payment>");
				String str=sb.toString();
				return str; 
	   		 	}
			catch(Exception localException)
			{
				System.out.println(localException);
				
				localException.printStackTrace();  
				sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not update payment info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       outStr= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (upempTx!=null)
		    	 upempTx.rollback();
			}
			finally
			{			
				upempSession.close();
			}
			return outStr;

	}

	public String deletePayment(int paymentId,int schoolId,int branchId) {
		Session delempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction delempTx=null;
		StringBuffer sb=new StringBuffer();

		String outStr=null;
		try
		{
			delempTx=delempSession.beginTransaction();
			Payment mdclpojo = (Payment) delempSession.get(Payment.class,paymentId);
			   
			   int branid = mdclpojo.getBranchId();
			   int sclid = mdclpojo.getSchoolId();
			   delempSession.evict(mdclpojo);           
			   if(branchId==branid&&schoolId==sclid)
			   { 	  
				   Query empQuery=delempSession.createSQLQuery("update gbl_sm_tbl_payment set isDeleted='y' where paymentId='"+paymentId+"'");
				   empQuery.executeUpdate();
				   delempTx.commit();
				   sb.append("<payment>");
				   sb.append("\n");
				   sb.append("delete successfully");
				   sb.append("</payment>");
				   String str=sb.toString();
				   return str;			   
	   		}
		}catch(Exception localException){
				System.out.println(localException);				
				localException.printStackTrace();  
				sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not delete payment info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       outStr= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (delempTx!=null)
		    	 delempTx.rollback();
			}
			finally
			{			
				delempSession.close();
			}
			return outStr;
	}

	@SuppressWarnings("rawtypes")
	public String getByIdPayment(int paymentId,int schoolId,int branchId) {
		Session gtempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gtempTx=null;
		StringBuffer sb=new StringBuffer();
		String strg= null;
			try {
					gtempTx = gtempSession.beginTransaction();
					List list=gtempSession.createSQLQuery("select p.PaymentId,p.PaymentModeId,pm.ModeName,p.EmployeeId,s.StaffNumber,s.FirstName,s.LastName,stuedu.ClassId,cls.ClassName,stuedu.SectionId,sec.SectionName,p.StudentId,p.PayReceiptNo,p.PaidBy,p.DatePaid,p.TotalAmount,p.Remarks,p.SchoolId,p.BranchId from gbl_sm_tbl_payment as p join gbl_sm_tbl_paymentmode as pm on p.PaymentModeId=pm.PaymentModeId join gbl_sm_tbl_staff as s on p.EmployeeId=s.EmployeeId join gbl_sm_tbl_student_education as stuedu on stuedu.StudentId=p.StudentId left outer join  gbl_sm_tbl_class as cls on stuedu.ClassId=cls.ClassId left outer join gbl_sm_tbl_section as sec on sec.SectionId=stuedu.SectionId  where p.PaymentId='" + paymentId + "' and p.SchoolId='" + schoolId + "' and p.BranchId='" + branchId + "' and p.IsDeleted Is Null;").list();
					Iterator it=list.iterator();
					sb.append("<Payment>");
					while(it.hasNext()){
						Object[] ex=(Object[])it.next();
				        sb.append("\n");
				        sb.append("<paymentId>");
					    sb.append(ex[0]);
					    sb.append("</paymentId>");
					    sb.append("\n");
					    sb.append("<paymentModeId>");
						sb.append(ex[1]);
						sb.append("</paymentModeId>");
						sb.append("\n");
						sb.append("<paymentModeName>");
						sb.append(ex[2]);
						sb.append("</paymentModeName>");
						sb.append("\n");
				        sb.append("<employeeId>");
					    sb.append(ex[3]);
					    sb.append("</employeeId>");
					    sb.append("\n");
					    sb.append("<staffNumber>");
					    sb.append(ex[4]);
					    sb.append("</staffNumber>");
					    sb.append("\n");
					    sb.append("<firstName>");
					    sb.append(ex[5]);
					    sb.append("</firstName>");
					    sb.append("\n");
					    sb.append("<lastName>");
					    sb.append(ex[6]);
					    sb.append("</lastName>");
					    sb.append("\n");
					    sb.append("<classId>");
					    sb.append(ex[7]);
					    sb.append("</classId>");
					    sb.append("\n");
					    sb.append("<className>");
					    sb.append(ex[8]);
					    sb.append("</className>");
					    sb.append("\n");
					    
					    
					    sb.append("<sectionId>");
						sb.append(ex[9]);
						sb.append("</sectionId>");
						sb.append("\n");
						sb.append("<sectionName>");
						sb.append(ex[10]);
						sb.append("</sectionName>");
						sb.append("\n");
					    int studentId=(Integer)ex[11];
					    sb.append("<studentId>" +studentId+ "</studentId>");
				         sb.append("\n");
				         if(studentId!=0)
				         {
				       String  gsSql="select stu.StudentId,stu.StudentNumber,stu.FirstName,stu.MiddleName,stu.LastName from gbl_sm_tbl_student as stu where (stu.isDeleted<>'y' or  stu.isDeleted is null) and stu.StudentId='"+studentId+"'";
				      Query   gsQuery = gtempSession.createSQLQuery(gsSql);
				     List parList1 = gsQuery.list();
				     Iterator paIT = parList1.iterator();
				      //sb.append("<studentDetails>");
				      //sb.append("\n");
				     while (paIT.hasNext()) {
				      Object[] paArr = (Object[]) paIT.next();
				      //sb.append("<student>");
				      //sb.append("\n");
				      //sb.append("<studentId>" + paArr[0] + "</studentId>");
				      //sb.append("\n");
				      sb.append("<studentnumber>"+paArr[1]+"</studentnumber>");
				      sb.append("\n");
				      sb.append("<studentfirstName>" + paArr[2] + "</studentfirstName>");
				      sb.append("\n");
				      sb.append("<studentmiddleName>" + paArr[3] + "</studentmiddleName>");
				      sb.append("\n");
				      sb.append("<studentlastName>" + paArr[4] + "</studentlastName>");
				      sb.append("\n");      
				     }
				         }else{
				          sb.append("<studentnumber></studentnumber>");
				      sb.append("\n");
				      sb.append("<studentfirstName></studentfirstName>");
				      sb.append("\n");
				      sb.append("<studentmiddleName></studentmiddleName>");
				      sb.append("\n");
				      sb.append("<studentlastName></studentlastName>");
				      sb.append("\n");
				         }
					    
						
						sb.append("<payReceiptNo>");
					    sb.append(ex[12]);
					    sb.append("</payReceiptNo>");
					    sb.append("\n");
					    sb.append("<paidBy>");
						sb.append(ex[13]);
						sb.append("</paidBy>");
						sb.append("\n");
				        sb.append("<datePaid>");
					    sb.append(ex[14]);
					    sb.append("</datePaid>");
					    sb.append("\n");
					    sb.append("<totalAmount>");
						sb.append(ex[15]);
						sb.append("</totalAmount>");
						sb.append("\n");
						sb.append("<remarks>");
				        sb.append("\n");
					    sb.append(ex[16]);
					    sb.append("</remarks>");
					    sb.append("\n");
					    sb.append("<schoolId>");
				        sb.append(ex[17]);
				        sb.append("</schoolId>");
				        sb.append("\n");
				        sb.append("<branchId>");
				        sb.append(ex[18]);
				        sb.append("</branchId>");
				        sb.append("\n");
					}
					
					sb.append("</Payment>");
					strg=sb.toString(); 
					 
					 gtempTx.commit();					
			} 	catch (Exception localException) {
				System.out.println(localException);
				
				localException.printStackTrace();  
				sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not get payment info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       strg= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (gtempTx!=null)
		    	 gtempTx.rollback();
				} finally {
					gtempSession.close();
				}
		return strg;
	}

	@SuppressWarnings({ "rawtypes" })
	public String getAllPayment(int PNO,int size,int schoolId,int branchId,int classId,int sectionId) {
		Session rdSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb= new StringBuffer();
		String string=null;
		try
		{
				tx = rdSession.beginTransaction();
			    int fset = (PNO-1)*size;
			    String filterWhere="";
			    String gsSql ="select count(*) from gbl_sm_tbl_payment as p join gbl_sm_tbl_student_education as stuedu on stuedu.StudentId=p.StudentId left outer join  gbl_sm_tbl_class as cls on stuedu.ClassId=cls.ClassId left outer join gbl_sm_tbl_section as sec on sec.SectionId=stuedu.SectionId where p.isDeleted is null and p.schoolId="+schoolId+" and p.branchId="+branchId+""+filterWhere+"";
			    if(classId!=0){
			    	
			    	 filterWhere+=" and stuedu.ClassId in("+classId+")";
			    
				   if(sectionId!=0){
					   filterWhere+=" and stuedu.sectionId in("+sectionId+")";
				   }
			    }
				   gsSql +=";";
			    Query gsQuery=rdSession.createSQLQuery(gsSql);
			    Object noRecords= gsQuery.uniqueResult();
			    int intNoRecords=0;
				if(noRecords!=null && Integer.parseInt(noRecords.toString())!=0)
				{
					intNoRecords=Integer.parseInt(noRecords.toString());
				}
				sb.append("<Payments>");
				sb.append("\n");
				sb.append("<noRecords>"+intNoRecords+"</noRecords>");
				sb.append("\n");
				if(intNoRecords!=0)
				{
			       if (PNO > 0 & size > 0){
			     gsSql="select p.PaymentId,p.PaymentModeId,pm.ModeName,p.EmployeeId,s.StaffNumber,s.FirstName,s.LastName,stuedu.ClassId,cls.ClassName,stuedu.SectionId,sec.SectionName,p.StudentId,p.PayReceiptNo,p.PaidBy,p.DatePaid,p.TotalAmount,p.Remarks,p.SchoolId,p.BranchId from gbl_sm_tbl_payment as p join gbl_sm_tbl_paymentmode as pm on p.PaymentModeId=pm.PaymentModeId join gbl_sm_tbl_staff as s on p.EmployeeId=s.EmployeeId join gbl_sm_tbl_student_education as stuedu on stuedu.StudentId=p.StudentId left outer join  gbl_sm_tbl_class as cls on stuedu.ClassId=cls.ClassId left outer join gbl_sm_tbl_section as sec on sec.SectionId=stuedu.SectionId where p.SchoolId='" + schoolId + "' and p.BranchId='" + branchId + "' and p.IsDeleted Is Null";
			     if(classId!=0){
			    	 gsSql += " and stuedu.classId="+classId;
			     
				   if(sectionId!=0){
					   gsSql += " and stuedu.sectionId="+sectionId;
				   }
				   }gsSql +=" limit "+size+" offset "+fset;
				
			       }
			     else {
			      gsSql="select p.PaymentId,p.PaymentModeId,pm.ModeName,p.EmployeeId,s.StaffNumber,s.FirstName,s.LastName,stuedu.ClassId,cls.ClassName,stuedu.SectionId,sec.SectionName, p.StudentId,p.PayReceiptNo,p.PaidBy,p.DatePaid,p.TotalAmount,p.Remarks,p.SchoolId,p.BranchId from gbl_sm_tbl_payment as p join gbl_sm_tbl_paymentmode as pm on p.PaymentModeId=pm.PaymentModeId join gbl_sm_tbl_staff as s on p.EmployeeId=s.EmployeeId join gbl_sm_tbl_student_education as stuedu on stuedu.StudentId=p.StudentId left outer join  gbl_sm_tbl_class as cls on stuedu.ClassId=cls.ClassId left outer join gbl_sm_tbl_section as sec on sec.SectionId=stuedu.SectionId where p.SchoolId='" + schoolId + "' and p.BranchId='" + branchId + "' and p.IsDeleted Is Null";
			      if(classId!=0){
			    	  gsSql += " and stuedu.classId="+classId;
			      
				   if(sectionId!=0){
					   gsSql += " and stuedu.classId="+classId;
				   }
				   }gsSql +=";";
			     }
				
			        gsQuery=rdSession.createSQLQuery(gsSql);
			        List gcList=gsQuery.list();
			        Iterator gsIT=gcList.iterator();
			     while(gsIT.hasNext())
			     {
			      Object[] mdcArr=(Object[])gsIT.next();
			       sb.append("<Payment>");
			      sb.append("\n");
			      sb.append("<paymentId>"+mdcArr[0]+"</paymentId>");
			      sb.append("\n");
			      sb.append("<paymentModeId>" + mdcArr[1]+ "</paymentModeId>");
			      sb.append("\n");
			      sb.append("<paymentModeName>" + mdcArr[2]+ "</paymentModeName>");
			      sb.append("\n");
			      sb.append("<employeeId>" + mdcArr[3]+ "</employeeId>");
			      sb.append("\n");
			      sb.append("<staffNumber>" + mdcArr[4]+ "</staffNumber>");
			      sb.append("\n");
			      sb.append("<firstName>" + mdcArr[5]+ "</firstName>");
			      sb.append("\n");
			      sb.append("<lastName>" + mdcArr[6] + "</lastName>");
			      sb.append("\n");
			      
			      sb.append("<classId>"+mdcArr[7]+"</classId>");
			      sb.append("\n");
			      sb.append("<className>" + mdcArr[8]+ "</className>");
			      sb.append("\n");
			      sb.append("<sectionId>" + mdcArr[9]+ "</sectionId>");
			      sb.append("\n");
			      sb.append("<sectionName>" + mdcArr[10]+ "</sectionName>");
			      sb.append("\n");
			      
			      int studentId=(Integer)mdcArr[11];
			         sb.append("<studentId>" +studentId+ "</studentId>");
			         sb.append("\n");
			         if(studentId!=0)
			         {
			         gsSql="select stu.StudentId,stu.StudentNumber,stu.FirstName,stu.MiddleName,stu.LastName from gbl_sm_tbl_student as stu where (stu.isDeleted<>'y' or  stu.isDeleted is null) and stu.StudentId='"+studentId+"'";
			         gsQuery = rdSession.createSQLQuery(gsSql);
			     List parList1 = gsQuery.list();
			     Iterator paIT = parList1.iterator();
			      //sb.append("<studentDetails>");
			      //sb.append("\n");
			     while (paIT.hasNext()) {
			      Object[] paArr = (Object[]) paIT.next();
			      //sb.append("<student>");
			      //sb.append("\n");
			      //sb.append("<studentId>" + paArr[0] + "</studentId>");
			      //sb.append("\n");
			      sb.append("<studentnumber>"+paArr[1]+"</studentnumber>");
			      sb.append("\n");
			      sb.append("<studentfirstName>" + paArr[2] + "</studentfirstName>");
			      sb.append("\n");
			      sb.append("<studentmiddleName>" + paArr[3] + "</studentmiddleName>");
			      sb.append("\n");
			      sb.append("<studentlastName>" + paArr[4] + "</studentlastName>");
			      sb.append("\n");      
			     }
			         }
			        else{
			          sb.append("<studentnumber></studentnumber>");
			      sb.append("\n");
			      sb.append("<studentfirstName></studentfirstName>");
			      sb.append("\n");
			      sb.append("<studentmiddleName></studentmiddleName>");
			      sb.append("\n");
			      sb.append("<studentlastName></studentlastName>");
			      sb.append("\n");
			         }
			      sb.append("\n");
			      sb.append("<payReceiptNo>" + mdcArr[12]+ "</payReceiptNo>");
			      sb.append("\n");
			      sb.append("<paidBy>" + mdcArr[13] + "</paidBy>");
			      sb.append("\n");
			      sb.append("<datePaid>" + mdcArr[14] + "</datePaid>");
			      sb.append("\n");
			      sb.append("<totalAmount>" + mdcArr[15] + "</totalAmount>");
			      sb.append("\n");
			      sb.append("<remarks>" + mdcArr[16] + "</remarks>");
			      sb.append("\n");
			      sb.append("<schoolId>" + mdcArr[17]+ "</schoolId>");
			      sb.append("\n");
			      sb.append("<branchId>" + mdcArr[18]+ "</branchId>");
			      sb.append("\n");
			      sb.append("</Payment>");
			      sb.append("\n");
			     }
		}
			    tx.commit();
			    sb.append("</Payments>");
			    string=sb.toString();
			   
			   
			  } 
			  catch(Exception localException)
			  {
			   tx.rollback();
			   localException.printStackTrace();
			   string = "fail";
			   System.out.println("Could not Get Payment");
			  }
			  finally
			  {
			   rdSession.close();
			  } 
			  return string;
	}

	@SuppressWarnings("rawtypes")
	public String getFeeItemPaymentId(int paymentId,int schoolId,int branchId) {
		Session sempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction sempTx=null;
		StringBuffer sb=new StringBuffer();
		String strg= null;
			try {
					
					sempTx=sempSession.beginTransaction();
					List list=sempSession.createSQLQuery("select fi.FeeItemId,fi.ItemName,fi.FeeItemTypeId,fit.Name,fi.StudentId,stud.StudentNumber,stud.FirstName,stud.LastName,fi.EventId,ev.EventName,fi.CategoryId,fst.CATEGORYNAME,fi.StartDate,fi.EndDate,fi.Amount,fi.ValidFrom,fi.ValidTo,fi.`Status`,fi.Description,fi.SchoolId,fi.BranchId from gbl_sm_tbl_fee_item as fi join gbl_sm_tbl_feeitemtype as fit on fi.FeeItemTypeId=fit.FeeItemTypeId join gbl_sm_tbl_event as ev on fi.EventId=ev.EventId  join mdcategory as fst on fi.CategoryId=fst.CATEGORYID join gbl_sm_tbl_student as stud on fi.StudentId=stud.StudentId where fi.FeeItemId in(select feeitemid from gbl_sm_tbl_paymentitem where paymentid='" + paymentId + "') and fi.SchoolId='" + schoolId + "' and fi.BranchId='" + branchId + "' and fi.IsDeleted Is Null").list();
					Iterator it=list.iterator();
					sb.append("<Payments>");
					sb.append("\n");
					while(it.hasNext()){
						Object[] ex=(Object[])it.next();
						sb.append("<Payment>");
						sb.append("\n");
						sb.append("<paymentId>");
					    sb.append(paymentId);
					    sb.append("</paymentId>");
					    sb.append("\n");
				        sb.append("<feeItemId>");
					    sb.append(ex[0]);
					    sb.append("</feeItemId>");
					    sb.append("\n");
					    sb.append("<itemName>");
						sb.append(ex[1]);
						sb.append("</itemName>");
						sb.append("\n");
						sb.append("<feeItemTypeId>");
						sb.append(ex[2]);
						sb.append("</feeItemTypeId>");
						sb.append("\n");
						sb.append("<name>");
						sb.append(ex[3]);
						sb.append("</name>");
						sb.append("\n");
						sb.append("<studentId>");
					    sb.append(ex[4]);
					    sb.append("</studentId>");
					    sb.append("\n");
					    sb.append("<studentNumber>");
					    sb.append(ex[5]);
					    sb.append("</studentNumber>");
					    sb.append("\n");
					    sb.append("<firstName>");
					    sb.append(ex[6]);
					    sb.append("</firstName>");
					    sb.append("\n");
					    sb.append("<lastName>");
					    sb.append(ex[7]);
					    sb.append("</lastName>");
					    sb.append("\n");
					    
					    sb.append("<eventId>");
						sb.append(ex[8]);
						sb.append("</eventId>");
						sb.append("\n");
						sb.append("<eventName>");
						sb.append(ex[9]);
						sb.append("</eventName>");
						sb.append("\n");
						
						
						/*sb.append("<classId>");
					    sb.append(ex[10]);
					    sb.append("</classId>");
					    sb.append("\n");
					    sb.append("<className>");
					    sb.append(ex[11]);
					    sb.append("</className>");
					    sb.append("\n");
					    
					    
					    sb.append("<sectionId>");
						sb.append(ex[12]);
						sb.append("</sectionId>");
						sb.append("\n");
						sb.append("<sectionName>");
						sb.append(ex[13]);
						sb.append("</sectionName>");
						sb.append("\n");*/
						
						
				        sb.append("<categoryId>");
					    sb.append(ex[10]);
					    sb.append("</categoryId>");
					    sb.append("\n");
					    sb.append("<categoryName>");
					    sb.append(ex[11]);
					    sb.append("</categoryName>");
					    sb.append("\n");
					    
					    
						sb.append("<startDate>");
					    sb.append(ex[12]);
					    sb.append("</startDate>");
					    sb.append("\n");
					    sb.append("<endDate>");
						sb.append(ex[13]);
						sb.append("</endDate>");
						sb.append("\n");
				        sb.append("<amount>");
					    sb.append(ex[14]);
					    sb.append("</amount>");
					    sb.append("\n");
					    sb.append("<validFrom>");
						sb.append(ex[15]);
						sb.append("</validFrom>");
						sb.append("\n");
						sb.append("<validTo>");
						sb.append(ex[16]);
						sb.append("</validTo>");
						sb.append("\n");
						sb.append("<status>");
						sb.append(ex[17]);
						sb.append("</status>");
						sb.append("\n");
						sb.append("<description>");
						sb.append(ex[18]);
						sb.append("</description>");
						sb.append("\n");
						sb.append("<schoolId>");
				        sb.append(ex[19]);
				        sb.append("</schoolId>");
				        sb.append("\n");
				        sb.append("<branchId>");
				        sb.append(ex[20]);
				        sb.append("</branchId>");
				        sb.append("\n");
				        sb.append("</Payment>");
						
					}
					 sb.append("</Payments>");
					 strg=sb.toString();
					 
					 sempTx.commit();
					
			} 	catch (Exception localException) {
				System.out.println(localException);
				
				localException.printStackTrace();  
				sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not inserted FeeStructure info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       strg= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (sempTx!=null)
		    	 sempTx.rollback();
				} finally {
					sempSession.close();
				}
		return strg;
		
	}
}
