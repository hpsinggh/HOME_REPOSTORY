package com.gwebitsol.core.fee;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class EventDao {
	public String addEvent(EventPojo per) {
		Session addempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction addempTx=null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			addempTx=addempSession.beginTransaction();
	        Integer in=(Integer)addempSession.save(per);
			System.out.println(in);
			
			addempTx.commit();
			
			sb.append("<Event>");
			sb.append("\n");
			sb.append("<eventId>");
			sb.append(in);
			sb.append("</eventId>");
			sb.append("</Event>");
			String str=sb.toString();
			return str;
		   
   		 	}
		
		catch(Exception localException)
		{
			System.out.println(localException);
			
			localException.printStackTrace();  
			sb.append("<Response>");
	       sb.append("\n");
	       sb.append("<Result>");
	       sb.append("\n");
	       sb.append("Fail");
	       sb.append("\n");
	       sb.append("</Result>");
	       sb.append("\n");
	       sb.append("<Description>");
	       
	       sb.append("could not inserted Event info");
	       sb.append("</Description>");
	       sb.append("\n");
	       sb.append("<Exception>");
	       sb.append(localException);
	       sb.append("</Exception>");
	       sb.append("</Response>");
	       outStr= sb.toString();
	      MDTransactionWriter.exceptionlog.info(localException);
	     if (addempTx!=null)
	      addempTx.rollback();
		}
		finally
		{			
			addempSession.close();
		}
		return outStr;
	}

	public String updateEvent(EventPojo per,int schoolId,int branchId) {
		Session upempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction upempTx=null;
		StringBuffer sb=new StringBuffer();

		String outStr=null;
		try
		{
			upempTx=upempSession.beginTransaction();
			EventPojo event = (EventPojo) upempSession.get(EventPojo.class,per.getEventId());
		      
			   if(branchId==event.getBranchId()&&schoolId==event.getSchoolId())
			       
			    upempSession.evict(event);
			 upempSession.update(per);
				
				upempTx.commit();
				
				sb.append("<Event>");
				sb.append("\n");
				sb.append("update successfully");
				sb.append("</Event>");
				String str=sb.toString();
				return str;
			   
	   		 	}
			
			catch(Exception localException)
			{
				System.out.println(localException);
				
				localException.printStackTrace();  
				sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not update Event info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       outStr= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (upempTx!=null)
		    	 upempTx.rollback();
			}
			finally
			{			
				upempSession.close();
			}
			return outStr;
	}

	public String deleteEvent(int eventId,int schoolId,int branchId) {
		Session delempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction delempTx=null;
		StringBuffer sb=new StringBuffer();

		String outStr=null;
		try
		{
			delempTx=delempSession.beginTransaction();
			EventPojo mdclpojo = (EventPojo) delempSession.get(EventPojo.class,eventId);
			   
			   int branid = mdclpojo.getBranchId();
			   int sclid = mdclpojo.getSchoolId();
			   delempSession.evict(mdclpojo);     
			   if(branchId==branid&&schoolId==sclid)
			   {
				   
				   Query empQuery=delempSession.createSQLQuery("update gbl_sm_tbl_event set isDeleted='y' where eventId='"+eventId+"'");
				   empQuery.executeUpdate();
			
				   delempTx.commit();
				
				   sb.append("<Event>");
				   sb.append("\n");
				   sb.append("delete successfully");
				   sb.append("</Event>");
				   String str=sb.toString();
				   return str;
			   }
	   		}
			catch(Exception localException)
			{
				System.out.println(localException);
				
				localException.printStackTrace();  
				sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not delete Event info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       outStr= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (delempTx!=null)
		    	 delempTx.rollback();
			}
			finally
			{			
				delempSession.close();
			}
			return outStr;
	}

	@SuppressWarnings("rawtypes")
	public String getByIdEvent(int eventId,int schoolId,int branchId) {
		Session gtempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gtempTx=null;
		StringBuffer sb=new StringBuffer();

		
		System.out.println("hi success");
		String strg= null;
			try {
					gtempTx = gtempSession.beginTransaction();
					List list=gtempSession.createSQLQuery("select e.EventId,e.EventTypeId,et.EventTypeName,e.EventName,e.EventDate,e.Description,e.SchoolId,e.BranchId from gbl_sm_tbl_event as e join gbl_sm_tbl_event_type as et on  e.EventTypeId=et.EventTypeId where eventId='" + eventId + "' and e.SchoolId='" + schoolId + "' and e.BranchId='" + branchId + "' and  IsDeleted Is Null;").list();
					Iterator it=list.iterator();
					sb.append("<Event>");
					while(it.hasNext()){
						Object[] ex=(Object[])it.next();
				        sb.append("\n");
				        sb.append("<eventId>");
					    sb.append(ex[0]);
					    sb.append("</eventId>");
					    sb.append("\n");
					    sb.append("<eventTypeId>");
						sb.append(ex[1]);
						sb.append("</eventTypeId>");
						sb.append("\n");
				        sb.append("<EventTypeName>");
					    sb.append(ex[2]);
					    sb.append("</EventTypeName>");
					    sb.append("\n");
					    sb.append("<eventName>");
					    sb.append(ex[3]);
					    sb.append("</eventName>");
					    sb.append("\n");
					    sb.append("<eventDate>");
					    sb.append(ex[4]);
					    sb.append("</eventDate>");
					    sb.append("\n");
					    sb.append("<description>");
					    sb.append(ex[5]);
					    sb.append("</description>");
					    sb.append("\n");
					    
					    sb.append("<schoolId>");
				        sb.append(ex[6]);
				        sb.append("</schoolId>");
				        sb.append("\n");
				        sb.append("<branchId>");
				        sb.append(ex[7]);
				        sb.append("</branchId>");
				        sb.append("\n");
					}
					
					sb.append("</Event>");
					strg=sb.toString(); 
					 
					 gtempTx.commit();		
			} 	catch (Exception localException) {
				System.out.println(localException);
				
				localException.printStackTrace();  
				sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not get Event info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       strg= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (gtempTx!=null)
		    	 gtempTx.rollback();
				} finally {
					gtempSession.close();
				}
		return strg;
	}

	@SuppressWarnings("rawtypes")
	public String getAllEvent(int PNO,int size,int schoolId,int branchId) {
		Session rdSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb= new StringBuffer();
		String string=null;
		
		try
		{
			tx = rdSession.beginTransaction();
			int fset = (PNO-1)*size;
			String gsSql ="select count(*) from gbl_sm_tbl_event where isDeleted is null and schoolId="+schoolId+" and branchId="+branchId+"";
			Query gsQuery=rdSession.createSQLQuery(gsSql);
			Object noRecords= gsQuery.uniqueResult();
			sb.append("<Events>");
			sb.append("\n");
			sb.append("<noRecords>"+noRecords+"</noRecords>");
			sb.append("\n");
			
			 if (PNO > 0 & size > 0){
			 gsSql="select e.EventId,e.EventTypeId,et.EventTypeName,e.EventName,e.EventDate,e.Description,e.SchoolId,e.BranchId from gbl_sm_tbl_event as e join gbl_sm_tbl_event_type as et on  e.EventTypeId=et.EventTypeId where e.SchoolId='" + schoolId + "' and e.BranchId='" + branchId + "' and e.IsDeleted Is Null limit "+size+" offset "+fset;}
			 else {
			  gsSql="select e.EventId,e.EventTypeId,et.EventTypeName,e.EventName,e.EventDate,e.Description,e.SchoolId,e.BranchId from gbl_sm_tbl_event as e join gbl_sm_tbl_event_type as et on  e.EventTypeId=et.EventTypeId where e.SchoolId='" + schoolId + "' and e.BranchId='" + branchId + "' and e.IsDeleted Is Null";
			 } 
   
			gsQuery=rdSession.createSQLQuery(gsSql);
			List gcList=gsQuery.list();
			Iterator gsIT=gcList.iterator();
			 while(gsIT.hasNext())
			 {
			  Object[] mdcArr=(Object[])gsIT.next();
			  sb.append("<Event>");
			  sb.append("\n");
			  sb.append("<eventId>"+mdcArr[0]+"</eventId>");
			  sb.append("\n");
			  sb.append("<eventTypeId>" + mdcArr[1]+ "</eventTypeId>");
			  sb.append("\n");
			  sb.append("<eventTypeName>" + mdcArr[2]+ "</eventTypeName>");
			  sb.append("\n");
			  sb.append("<eventName>" + mdcArr[3]+ "</eventName>");
			  sb.append("\n");
			  sb.append("<eventDate>" + mdcArr[4]+ "</eventDate>");
			  sb.append("\n");
			  sb.append("<description>" + mdcArr[5]+ "</description>");
			  sb.append("\n");
			  sb.append("<schoolId>" + mdcArr[6]+ "</schoolId>");
			  sb.append("\n");
			  sb.append("<branchId>" + mdcArr[7]+ "</branchId>");
			  sb.append("\n");
			  sb.append("</Event>");
			  sb.append("\n");
			 }
			
			tx.commit();
			sb.append("</Events>");
			sb.append("\n");

			string=sb.toString();
			   
			  } 
			  catch(Exception localException)
			  {
			   tx.rollback();
			   localException.printStackTrace();
			   string = "fail";
			   System.out.println("Could not Get Events");
			  }
			  finally
			  {
			   rdSession.close();
			  } 
			  return string;
	}

}
