package com.gwebitsol.core.objectcontroller.object;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

import com.gwebitsol.core.objectcontroller.object.MDObject;

@Path("/objectmanagement/")
public interface MDObjectManagementServiceIntf 
{
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/addobject/")
	public Response addObject(MDObject mdobject,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/delobject/")
	public Response deleteObject(@QueryParam("objectName") String objectName,@QueryParam("infoclassName") String infoclassName,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	/*@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/addobj/")
	public Response addObjectFromRemote(MDObject mdobject,@QueryParam("deviceid") String deviceid);*/
	
	@GET
	@Produces ({"application/xml","application/json"})
	@Path("/getallobjects")
	public Response getAllObjects(@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@GET
	@Produces ({"application/xml","application/json"})
	@Path("/getobjectdetails")
	public Response getObjectDetails(@QueryParam ("objectID") int objectID,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/moveObject")
	public Response moveObjectToAnotherFolder(@QueryParam("objectName") String objectName,@QueryParam("destinationFolder") String destinationFolder,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@POST
	@Produces ({"application/xml","application/json"})
	@Path("/smtObj")
	public Response sendMsg(@QueryParam("objectid") int objectid,@QueryParam("messageid") int messageid);
	
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/actdeactivate")
	public Response activateDeactivate(@QueryParam("objectID") String objectID,@QueryParam("operation") String operation,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/addremoveservice")
	public Response addRemoveService(@QueryParam("objectID") int objectID,@QueryParam("serviceId") String serviceID,@QueryParam("operation") String operation,@QueryParam("messageid") int messageid,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/regOwn/")
	public Response registerOwner(MDOwner mdown,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/regDr/")
	public Response registerDriver(MDDriver mddr,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@GET
	@Produces ({"application/xml","application/json"})
	@Path("/getOwnDet")
	public Response getOwnerDetails(@QueryParam ("ownerid") int ownerid,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@GET
	@Produces ({"application/xml","application/json"})
	@Path("/getDrDet")
	public Response getDriverDetails(@QueryParam ("driverid") int driverid,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);

	@GET
	@Produces ({"application/xml","application/json"})
	@Path("/getallowner")
	public Response getAllOwners(@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@GET
	@Produces ({"application/xml","application/json"})
	@Path("/getalldriver")
	public Response getAllDrivers(@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/updateOwn/")
	public Response updateOwner(MDOwner mdown,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);

	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/updateDr/")
	public Response updateDriver(MDDriver mddr,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);

	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/editobject")
	public Response editObjectDetails(MDObject mdobject,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	
	/*@GET
	@Produces ({"application/xml","application/json"})
	@Path("/getallobjectsdetails")
	public Response getAllObjectsDetails(@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	*/
	
}
