package com.gwebitsol.core.objectcontroller.object;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="MD_Object")
public class MDObject 
{
	private int objectID;
	private String objectName;
	private int parentOrgID;
	private String infoclassName;
	private int ownerID;
	private int driverID;
	private int stngCapacity;
	private String infoclassString;
	
	
	public int getObjectID() {
		return objectID;
	}
	public void setObjectID(int objectID) {
		this.objectID = objectID;
	}
	public String getObjectName() {
		return objectName;
	}
	public void setObjectName(String objectName) {
		this.objectName = objectName;
	}
	public int getParentOrgID() {
		return parentOrgID;
	}
	public void setParentOrgID(int parentOrgID) {
		this.parentOrgID = parentOrgID;
	}
	public String getInfoclassName() {
		return infoclassName;
	}
	public void setInfoclassName(String infoclassName) {
		this.infoclassName = infoclassName;
	}
	public int getOwnerID() {
		return ownerID;
	}
	public void setOwnerID(int ownerID) {
		this.ownerID = ownerID;
	}
	public int getDriverID() {
		return driverID;
	}
	public void setDriverID(int driverID) {
		this.driverID = driverID;
	}
	public int getStngCapacity() {
		return stngCapacity;
	}
	public void setStngCapacity(int stngCapacity) {
		this.stngCapacity = stngCapacity;
	}
	public String getInfoclassString() {
		return infoclassString;
	}
	public void setInfoclassString(String infoclassString) {
		this.infoclassString = infoclassString;
	}
	
	
	private String transportType;
	private String model;
	private String colour;
	private String registrationNo;
	private String engineChasisNo;
	private String manufacturer;
	private String yearOfMake;
	private String registeredDate;
	private String registeredCircle;
	private int seatCapacity;
	private int csCapacity;
	
	private String driverFirstName;
	private String driverFullName;
	private String licenceType;
	private String licenceNo;
	private String licensedArea;
	private String issuingAuth;
	private String issuedDate;
	private String expiryDate;
	private String driverMobileNo;
	private String driverEmailID;
	private String driverStreet;
	private String driverArea;
	private String driverCity;
	private String driverState;
	private String driverCountry;
	private String driverPincode;
	
	
	private String ownerFirstName;
	private String ownerFullName;
	private String ownerMobileNo;
	private String ownerEmailID;
	private String ownerStreet;
	private String ownerArea;
	private String ownerCity;
	private String ownerState;
	private String ownerCountry;
	private String ownerPincode;
	
	public String getTransportType() {
		return transportType;
	}
	public void setTransportType(String transportType) {
		this.transportType = transportType;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getColour() {
		return colour;
	}
	public void setColour(String colour) {
		this.colour = colour;
	}
	public String getRegistrationNo() {
		return registrationNo;
	}
	public void setRegistrationNo(String registrationNo) {
		this.registrationNo = registrationNo;
	}
	public String getEngineChasisNo() {
		return engineChasisNo;
	}
	public void setEngineChasisNo(String engineChasisNo) {
		this.engineChasisNo = engineChasisNo;
	}
	public String getManufacturer() {
		return manufacturer;
	}
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
	public String getYearOfMake() {
		return yearOfMake;
	}
	public void setYearOfMake(String yearOfMake) {
		this.yearOfMake = yearOfMake;
	}
	public String getRegisteredDate() {
		return registeredDate;
	}
	public void setRegisteredDate(String registeredDate) {
		this.registeredDate = registeredDate;
	}
	public String getRegisteredCircle() {
		return registeredCircle;
	}
	public void setRegisteredCircle(String registeredCircle) {
		this.registeredCircle = registeredCircle;
	}
	public int getSeatCapacity() {
		return seatCapacity;
	}
	public void setSeatCapacity(int seatCapacity) {
		this.seatCapacity = seatCapacity;
	}
	public int getCsCapacity() {
		return csCapacity;
	}
	public void setCsCapacity(int csCapacity) {
		this.csCapacity = csCapacity;
	}
	
	
	public String getDriverFirstName() {
		return driverFirstName;
	}
	public void setDriverFirstName(String driverFirstName) {
		this.driverFirstName = driverFirstName;
	}
	public String getDriverFullName() {
		return driverFullName;
	}
	public void setDriverFullName(String driverFullName) {
		this.driverFullName = driverFullName;
	}
	public String getLicenceType() {
		return licenceType;
	}
	public void setLicenceType(String licenceType) {
		this.licenceType = licenceType;
	}
	public String getLicenceNo() {
		return licenceNo;
	}
	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}
	public String getLicensedArea() {
		return licensedArea;
	}
	public void setLicensedArea(String licensedArea) {
		this.licensedArea = licensedArea;
	}
	public String getIssuingAuth() {
		return issuingAuth;
	}
	public void setIssuingAuth(String issuingAuth) {
		this.issuingAuth = issuingAuth;
	}
	public String getIssuedDate() {
		return issuedDate;
	}
	public void setIssuedDate(String issuedDate) {
		this.issuedDate = issuedDate;
	}
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	public String getDriverMobileNo() {
		return driverMobileNo;
	}
	public void setDriverMobileNo(String driverMobileNo) {
		this.driverMobileNo = driverMobileNo;
	}
	public String getDriverEmailID() {
		return driverEmailID;
	}
	public void setDriverEmailID(String driverEmailID) {
		this.driverEmailID = driverEmailID;
	}
	public String getDriverStreet() {
		return driverStreet;
	}
	public void setDriverStreet(String driverStreet) {
		this.driverStreet = driverStreet;
	}
	public String getDriverArea() {
		return driverArea;
	}
	public void setDriverArea(String driverArea) {
		this.driverArea = driverArea;
	}
	public String getDriverCity() {
		return driverCity;
	}
	public void setDriverCity(String driverCity) {
		this.driverCity = driverCity;
	}
	public String getDriverState() {
		return driverState;
	}
	public void setDriverState(String driverState) {
		this.driverState = driverState;
	}
	public String getDriverCountry() {
		return driverCountry;
	}
	public void setDriverCountry(String driverCountry) {
		this.driverCountry = driverCountry;
	}
	public String getDriverPincode() {
		return driverPincode;
	}
	public void setDriverPincode(String driverPincode) {
		this.driverPincode = driverPincode;
	}
	public String getOwnerFirstName() {
		return ownerFirstName;
	}
	public void setOwnerFirstName(String ownerFirstName) {
		this.ownerFirstName = ownerFirstName;
	}
	public String getOwnerFullName() {
		return ownerFullName;
	}
	public void setOwnerFullName(String ownerFullName) {
		this.ownerFullName = ownerFullName;
	}
	public String getOwnerMobileNo() {
		return ownerMobileNo;
	}
	public void setOwnerMobileNo(String ownerMobileNo) {
		this.ownerMobileNo = ownerMobileNo;
	}
	public String getOwnerEmailID() {
		return ownerEmailID;
	}
	public void setOwnerEmailID(String ownerEmailID) {
		this.ownerEmailID = ownerEmailID;
	}
	public String getOwnerStreet() {
		return ownerStreet;
	}
	public void setOwnerStreet(String ownerStreet) {
		this.ownerStreet = ownerStreet;
	}
	public String getOwnerArea() {
		return ownerArea;
	}
	public void setOwnerArea(String ownerArea) {
		this.ownerArea = ownerArea;
	}
	public String getOwnerCity() {
		return ownerCity;
	}
	public void setOwnerCity(String ownerCity) {
		this.ownerCity = ownerCity;
	}
	public String getOwnerState() {
		return ownerState;
	}
	public void setOwnerState(String ownerState) {
		this.ownerState = ownerState;
	}
	public String getOwnerCountry() {
		return ownerCountry;
	}
	public void setOwnerCountry(String ownerCountry) {
		this.ownerCountry = ownerCountry;
	}
	public String getOwnerPincode() {
		return ownerPincode;
	}
	public void setOwnerPincode(String ownerPincode) {
		this.ownerPincode = ownerPincode;
	}
}
