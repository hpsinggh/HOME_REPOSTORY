package com.gwebitsol.core.objectcontroller.object;

import java.net.URI;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.DefaultHttpClient;
import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.gwebitsol.core.infoclass.MDPrepareInsertQueryForObject;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class MDObjectManagementDAO 
{
	DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	Date date = new Date();
	String d=dateFormat.format(date);

	@SuppressWarnings("rawtypes")
	public String addObject(MDObject mdobj,int uid)
	{
		Session aoSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction addObjectTx = null;
		String XMLStatusString=null;
		String objectName=mdobj.getObjectName();
		String infoclassName=mdobj.getInfoclassName();
		int parentOrgID=mdobj.getParentOrgID();
		int ownerID=mdobj.getOwnerID();
		int driverID=mdobj.getDriverID();
		int stngCapacity=mdobj.getStngCapacity();
		String infoclassString=mdobj.getInfoclassString();
		String acl=null;

		try
		{
			addObjectTx=aoSession.beginTransaction();

			int infoclassID =(Integer)aoSession.createSQLQuery("select infoclassid from mdobjectinfoclassdefcontainer where infoclassname='"+infoclassName+"'").uniqueResult();
			
			List list=aoSession.createSQLQuery("select * from mdobject where objectname='"+objectName+"'").list();
			if(list!=null && list.size()>0)
			{
				XMLStatusString="Object with this name aldready exists...";
			}

			else
			{
				if(uid==1)
				{
					acl="U#1:111";
				}
				else
				{
					acl="U#1:111;U#"+uid+":111";
				}
			String fldSql="INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) " +
					"VALUES('"+objectName+"',"+parentOrgID+","+infoclassID+",'active','O','"+d+"','0000-00-00 00:00:00','"+acl+"',"+uid+",0,'L')";
			Query query0=aoSession.createSQLQuery(fldSql);
			query0.executeUpdate();
			
			Query query=aoSession.createSQLQuery("update mdfolder set folderlevel='P' where folderid='"+parentOrgID+"'");
			query.executeUpdate();


			String objSql="insert into mdobject(objectname,parentfolderid,infoclassid,deviceid,ownerid,driverid,stngcapacity,status,createddate,modifieddate,acl) " +
					"values('"+objectName+"',"+parentOrgID+","+infoclassID+",0,"+ownerID+","+driverID+","+stngCapacity+",1,'"+d+"','0000-00-00 00:00:00','"+acl+"')";
			Query query1=aoSession.createSQLQuery(objSql);
			query1.executeUpdate();
			
			int objectID=(Integer)aoSession.createSQLQuery("select objectid from mdobject where objectname='"+objectName+"'").uniqueResult();

			MDPrepareInsertQueryForObject piQuery=new MDPrepareInsertQueryForObject();
			String firstHalf=piQuery.prepareQuery(infoclassName, infoclassID);
			String totalQuery=firstHalf+objectID+","+infoclassString+")";
			Query query2=aoSession.createSQLQuery(totalQuery);
			query2.executeUpdate();

			XMLStatusString="successfully added the object";
			}
			addObjectTx.commit();
		}

		catch(Exception localexception)
		{
			addObjectTx.rollback();
			XMLStatusString="Error while adding the object";
			MDTransactionWriter.exceptionlog.info(localexception);
			
		}
		finally
		{
			aoSession.close();
		}
		return XMLStatusString;
	}
	
	public String updateObject(MDObject mdobj,int uid)
	{
		Session upObjSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction upObjTx=null;
		String XMLString=null;
		int objectID=mdobj.getObjectID();
		String objectName=mdobj.getObjectName();
		String infoclassName=mdobj.getInfoclassName();
		int parentOrgID=mdobj.getParentOrgID();
		int ownerID=mdobj.getOwnerID();
		int driverID=mdobj.getDriverID();
		int stngCapacity=mdobj.getStngCapacity();
		String infoclassString=mdobj.getInfoclassString();
		try
		{
				upObjTx=upObjSession.beginTransaction();
				
				int infoclassID =(Integer)upObjSession.createSQLQuery("select infoclassid from mdobjectinfoclassdefcontainer where infoclassname='"+infoclassName+"'").uniqueResult();
				String objName=(String)upObjSession.createSQLQuery("select objectname from mdobject where objectid="+objectID).uniqueResult();
				int folderID=(Integer)upObjSession.createSQLQuery("select folderid from mdfolder where foldername='"+objName+"'").uniqueResult();
				
				Query query=upObjSession.createSQLQuery("update mdobject set objectname='"+objectName+"' , ownerid="+ownerID+", driverid="+driverID+",stngcapacity="+stngCapacity+",modifieddate='"+d+"' where objectid="+objectID);
				query.executeUpdate();
				
				Query query1=upObjSession.createSQLQuery("delete from "+infoclassName+" where componentid="+objectID);
				query1.executeUpdate();

				MDPrepareInsertQueryForObject piQuery=new MDPrepareInsertQueryForObject();
				String firstHalf=piQuery.prepareQuery(infoclassName, infoclassID);
				String totalQuery=firstHalf+objectID+","+infoclassString+")";
				Query query2=upObjSession.createSQLQuery(totalQuery);
				query2.executeUpdate();
				
				Query query3=upObjSession.createSQLQuery("update mdfolder set foldername='"+objectName+"' ,parentfolderid="+parentOrgID+", modifieddate='"+d+"',modifiedby="+uid+" where folderid="+folderID);
				query3.executeUpdate();
				
				Query query4=upObjSession.createSQLQuery("update mdobject set parentfolderid="+parentOrgID+",modifieddate='"+d+"' where objectid="+objectID);
				query4.executeUpdate();
				
			
				upObjTx.commit();
				XMLString="sucessfully updated the object";
			
		}
		catch(Exception localException)
		{
			upObjTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			XMLString="fail";
		}
		finally
		{
			upObjSession.close();
		}
		return XMLString;
	}
	
	@SuppressWarnings("rawtypes")
	public String deleteObject(String objectName,String infoclassName)
	{
		Session doSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction doTx=null;
		String rtnString=null;
		try
		{
			doTx=doSession.beginTransaction();
			
			int objectID=(Integer)doSession.createSQLQuery("select objectid from mdobject where objectname='"+objectName+"'").uniqueResult();
			int folderID=(Integer)doSession.createSQLQuery("select folderid from mdfolder where foldername='"+objectName+"'").uniqueResult();

			Query doQuery0=doSession.createSQLQuery("select * from mdfolder where parentfolderid="+folderID);
			List doList=doQuery0.list();
			if(doList.isEmpty())
			{}
			else
			{
				Iterator doIT=doList.iterator();
				while(doIT.hasNext())
				{
					Object[] doObj=(Object[])doIT.next();
					int cfID=(Integer)doObj[0];
					String cfName=(String)doObj[1];
				
					Query doQuery1=doSession.createSQLQuery("update mdfolder set parentfolderid=0 where folderid="+cfID);
					doQuery1.executeUpdate();
					
					Query doQuery2=doSession.createSQLQuery("update mddevice set status=1,assign='no' where devicename='"+cfName+"'");
					doQuery2.executeUpdate();
				}
			}
			
			Query doQuery=doSession.createSQLQuery("delete from "+infoclassName+" where componentid="+objectID);
			doQuery.executeUpdate();
			
			Query doQuery1=doSession.createSQLQuery("delete from mdobject where objectid="+objectID);
			doQuery1.executeUpdate();
			
			Query doQuery2=doSession.createSQLQuery("delete from mdfolder where foldername='"+objectName+"'");
			doQuery2.executeUpdate();
			
			doTx.commit();
			rtnString="success";
		}
		catch(Exception localException)
		{
			doTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			rtnString="fail";
		}
		finally
		{
			doSession.close();
		}
		
		return rtnString;
	}
	
		
	@SuppressWarnings({ "rawtypes", "deprecation" })
	public String getAllObjects(int uid)
	{

		SessionFactory factory=MDHibernateUtil.getSessionFactory();
		Session session=factory.openSession();
		Transaction getObjectsTx = null;
		String respXMLString=null;
		StringBuffer objectsSB=new StringBuffer();

		try
		{
			getObjectsTx=session.beginTransaction();
			String objSql="select * from mdobject where acl like '%U#"+uid+":%' order by objectname ASC";
			Query objQuery=session.createSQLQuery(objSql).addScalar("objectid",Hibernate.INTEGER).addScalar("objectname",Hibernate.STRING);
			List objList=objQuery.list();
			if(objList!=null && objList.size()>0)
			{
			Iterator it=objList.iterator();
			objectsSB.append("<MD_Objects>");
			objectsSB.append("\n");
			while(it.hasNext())
			{
				Object[] obj=(Object[])it.next();
				objectsSB.append("<Object>");
				objectsSB.append("\n");
				objectsSB.append("<objectID>"+obj[0]+"</objectID>");
				objectsSB.append("\n");
				objectsSB.append("<objectName>"+obj[1]+"</objectName>");
				objectsSB.append("\n");
				objectsSB.append("</Object>");
				objectsSB.append("\n");
			}
			objectsSB.append("</MD_Objects>");
			
			}
			else
			{objectsSB.append("<MD_Objects>");
			objectsSB.append("\n");
			objectsSB.append("<Object>");
			objectsSB.append("\n");
			objectsSB.append("<objectName>No Vehicles</objectName>");
			objectsSB.append("\n");
			objectsSB.append("</Object>");
			objectsSB.append("\n");
			objectsSB.append("</MD_Objects>");
				
			}
			respXMLString=objectsSB.toString();
			getObjectsTx.commit();
			objectsSB.setLength(0);

		}
		catch(Exception localException)
		{
			getObjectsTx.rollback();
			objectsSB.setLength(0);
			MDTransactionWriter.exceptionlog.info(localException);
			respXMLString="fail";
		}
		finally
		{
			objectsSB=null;
			session.close();
		}
		return respXMLString;
	}
		
	@SuppressWarnings({ "deprecation", "rawtypes" })
	public String getObjectDetails(int objectID)
	{
		Session gicSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gobjDetailsTx = null;	
		String ginfXMLString=null;
		StringBuffer infFieldsSB=new StringBuffer();
		String deviceName=null;
		String infoclassName=null;
		try
		{
			gobjDetailsTx=gicSession.beginTransaction();
			int objectid=0;
			int infoclassid=0;
			int pfid=0;
			String infSql="select * from MDOBJECT where objectid="+objectID;
			Query objQuery=gicSession.createSQLQuery(infSql).addScalar("objectid",Hibernate.INTEGER).addScalar("objectname",Hibernate.STRING).addScalar("parentfolderid",Hibernate.INTEGER)
					.addScalar("infoclassid",Hibernate.INTEGER).addScalar("deviceid",Hibernate.INTEGER)
					.addScalar("ownerid",Hibernate.INTEGER).addScalar("driverid",Hibernate.INTEGER).addScalar("stngcapacity",Hibernate.INTEGER).addScalar("status",Hibernate.INTEGER);
			List objList=objQuery.list();
			Iterator objIT=objList.iterator();
			infFieldsSB.append("<MD_Object>");
			infFieldsSB.append("\n");
			

			while(objIT.hasNext())
			{
				System.out.println("entered into 1 while loop");
				Object[] objids=(Object[])objIT.next();
				objectid=(Integer)objids[0];
				String objectName=(String)objids[1];
				pfid=(Integer)objids[2];
				infoclassid=(Integer)objids[3];
				int deviceid=(Integer)objids[4];
				int ownerid=(Integer)objids[5];
				int driverid=(Integer)objids[6];
				int stngCapacity=(Integer)objids[7];
				String parentOrgName=(String)gicSession.createSQLQuery("select foldername from mdfolder where folderid="+pfid).uniqueResult();
				String ownerName=(String)gicSession.createSQLQuery("select fullname from mdowner where ownerid="+ownerid).uniqueResult();
				String driverName=(String)gicSession.createSQLQuery("select fullname from mddriver where driverid="+driverid).uniqueResult();
				if(deviceid!=0)
				{
					deviceName=(String)gicSession.createSQLQuery("select devicename from mddevice where deviceid="+deviceid).uniqueResult();
				}
				infoclassName=(String)gicSession.createSQLQuery("select infoclassname from mdobjectinfoclassdefcontainer where infoclassid="+infoclassid).uniqueResult();
				
				infFieldsSB.append("<objectdetails>");
				infFieldsSB.append("\n");
				infFieldsSB.append("<objectID>"+objectid+"</objectID>");
				infFieldsSB.append("\n");
				infFieldsSB.append("<objectName>"+objectName+"</objectName>");
				infFieldsSB.append("\n");
				infFieldsSB.append("<parentOrgID>"+pfid+"</parentOrgID>");
				infFieldsSB.append("\n");
				infFieldsSB.append("<parentOrgName>"+parentOrgName+"</parentOrgName>");
				infFieldsSB.append("\n");
				infFieldsSB.append("<deviceID>"+deviceid+"</deviceID>");
				infFieldsSB.append("\n");
				infFieldsSB.append("<deviceName>"+deviceName+"</deviceName>");
				infFieldsSB.append("\n");
				infFieldsSB.append("<ownerID>"+ownerid+"</ownerID>");
				infFieldsSB.append("\n");
				infFieldsSB.append("<ownerName>"+ownerName+"</ownerName>");
				infFieldsSB.append("\n");
				infFieldsSB.append("<driverID>"+driverid+"</driverID>");
				infFieldsSB.append("\n");
				infFieldsSB.append("<driverName>"+driverName+"</driverName>");
				infFieldsSB.append("\n");
				infFieldsSB.append("<stngCapacity>"+stngCapacity+"</stngCapacity>");
				infFieldsSB.append("\n");
				infFieldsSB.append("<infoclassName>"+infoclassName+"</infoclassName>");
				infFieldsSB.append("\n");
				int k=(Integer)objids[8];
				if(k==1)
				infFieldsSB.append("<status>deactive</status>");
				else if(k==2)
					infFieldsSB.append("<status>active</status>");
				else if(k==3)
					infFieldsSB.append("<status>ServiceAdded</status>");
				else if(k==4)
					infFieldsSB.append("<status>ServiceRemoved</status>");
				infFieldsSB.append("\n");
				infFieldsSB.append("</objectdetails>");
				infFieldsSB.append("\n");
			}
	
			String infSql3="select  * from mdobjinfoclassfields where infoclassid="+infoclassid+" group by parentfieldgroup order by fieldid";
			Query ginfQuery1=gicSession.createSQLQuery(infSql3).addScalar("FIELDID",Hibernate.INTEGER).addScalar("PARENTFIELDGROUP",Hibernate.STRING);
			List ginfList1=ginfQuery1.list();
			infFieldsSB.append("<objectdetails>");
			infFieldsSB.append("\n");
			Iterator ginfIT=ginfList1.iterator();
			while(ginfIT.hasNext())
			{
				Object[] infObj1=(Object[])ginfIT.next();
				infFieldsSB.append("<SectionName name='"+infObj1[1]+"'>");
				infFieldsSB.append("\n");
				String pfg=(String)infObj1[1];
				System.out.println(pfg);
				String infSql1="select * from mdobjinfoclassfields  where infoclassid="+infoclassid+" and parentfieldgroup='"+pfg+"'";
				Query ginfQuery=gicSession.createSQLQuery(infSql1).addScalar("fieldid",Hibernate.INTEGER).addScalar("infoclassid",Hibernate.INTEGER).addScalar("fieldname",Hibernate.STRING);
				List ginfList=ginfQuery.list();
				Iterator it=ginfList.iterator();
				while(it.hasNext())
				{
					Object[] infObj=(Object[])it.next();
					infFieldsSB.append("<field>");
					infFieldsSB.append("\n");
					infFieldsSB.append("<fieldname>");
					infFieldsSB.append(infObj[2]);
					infFieldsSB.append("</fieldname>");
					infFieldsSB.append("\n");
					infFieldsSB.append("</field>");
				}
				infFieldsSB.append("\n");
				infFieldsSB.append("</SectionName>");	
			}	
			infFieldsSB.append("\n");

			Query fvQuery=gicSession.createSQLQuery("select * from view_"+infoclassName+" where componentid="+objectid);
			List fvList=fvQuery.list();
			Iterator fvit=fvList.iterator();
			infFieldsSB.append("<fieldvalues>");infFieldsSB.append("\n");
			
			while(fvit.hasNext())
			{
				System.out.println("entered into 3rd while loop");
				Object[] fvStr=(Object[])fvit.next();
				int k=fvStr.length;
				for(int i=2;i<k;i++)
				{
					infFieldsSB.append("<fieldvalue>");
					infFieldsSB.append(fvStr[i]);
					infFieldsSB.append("</fieldvalue>");
					infFieldsSB.append("\n");
				}
			}
			infFieldsSB.append("</fieldvalues>");
			infFieldsSB.append("\n");
			infFieldsSB.append("</objectdetails>");
			infFieldsSB.append("\n");
			infFieldsSB.append("</MD_Object>");

			ginfXMLString=infFieldsSB.toString();
			gobjDetailsTx.commit();
			infFieldsSB.setLength(0);
		}
		catch(Exception localException)
		{
			gobjDetailsTx.rollback();
			infFieldsSB.setLength(0);
			MDTransactionWriter.exceptionlog.info(localException);
			ginfXMLString="<status>Error while getting the object details</status>";
		}
		finally
		{
			infFieldsSB=null;
			 gicSession.close();			
		}

		return ginfXMLString;
	}
	
	public String moveObject(String objectName,String destinationFolder,int userID)
	{
		Session moSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction moTx = null;	
		String moXMLString=null;
		try
		{
			moTx=moSession.beginTransaction();
			int pfid =(Integer)moSession.createSQLQuery("select folderid from mdfolder where foldername='"+destinationFolder+"'").uniqueResult();
			
			Query query = moSession.createSQLQuery("update mdfolder set parentfolderid="+pfid+",modifieddate='"+d+"',modifiedby="+userID+" where foldername='"+objectName+"'");
			query.executeUpdate();
			
			moTx.commit();
			moXMLString="object moved";
		}
		catch(Exception localException)
		{
			moTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			moXMLString="fail";
		}
		finally
		{
			moSession.close();
		}
		return moXMLString;

	}
	
	public String activeDeactive(String objectID,String operation)
	{
		Session adoSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction adoTx = null;	
		String adoXMLString=null;
		try
		{
			adoTx=adoSession.beginTransaction();
			if(operation.equalsIgnoreCase("activate"))
			{
				Query adoQuery=adoSession.createSQLQuery("update mdobject set status='2',modifieddate='"+d+"' where objectid="+objectID);
				adoQuery.executeUpdate();
				adoXMLString="object activated";
			}
			else if(operation.equalsIgnoreCase("deactivate"))
			{
				Query adoQuery1=adoSession.createSQLQuery("update mdobject set status='1',modifieddate='"+d+"' where objectid="+objectID);
				adoQuery1.executeUpdate();
				adoXMLString="object deactivated";
			}
			
			adoTx.commit();
			
		}
		catch(Exception localException)
		{
			adoTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			adoXMLString="fail";
		}
		finally
		{
			adoSession.close();
		}
		return adoXMLString;

	}
	
	public String addRemoveService(int objectID,String serviceId,String operation,int messageID)
	{
		Session arSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction arTx=null;
		String arXMLString=null;
		try
		{
			arTx=arSession.beginTransaction();
			if(operation.equalsIgnoreCase("AddService"))
			{
				MDObjectManagementDAO mdobj=new MDObjectManagementDAO();
				String result=mdobj.sendMsgToObject(objectID, messageID);
				if(result.equalsIgnoreCase("success"))
				{
				Query adoQuery=arSession.createSQLQuery("update mdobject set status='3',modifieddate='"+d+"' where objectid="+objectID);
				adoQuery.executeUpdate();
							
				Query adoQuery1=arSession.createSQLQuery("update mdservice set objectid="+objectID+" where serviceId='"+serviceId+"'");
				adoQuery1.executeUpdate();
							
				arXMLString="Service added to object";
				}
				else
				{
					arXMLString="Service addition failed..Try again";
					System.out.println(arXMLString);
				}
			}
			else if(operation.equalsIgnoreCase("RemoveService"))
			{
				Query adoQuery2=arSession.createSQLQuery("update mdobject set status='4',modifieddate='"+d+"' where objectid="+objectID);
				adoQuery2.executeUpdate();
				
				Query adoQuery3=arSession.createSQLQuery("update mdservice set objectid=0 where serviceId='"+serviceId+"'");
				adoQuery3.executeUpdate();
				
				arXMLString="Service removed from object";
			}
			arTx.commit();	
		}
		catch(Exception localException)
		{
			arTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			arXMLString="fail";
		}
		finally
		{
			arSession.close();
		}
		return arXMLString;
	}
	
	public String sendMsgToObject(int objectID,int messageID)
	{
		Session smtSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction smtTx=null;
		String rtnString=null;
		try
		{
			smtTx=smtSession.beginTransaction();
			int deviceID=(Integer)smtSession.createSQLQuery("select deviceid from mdobject where objectid="+objectID).uniqueResult();
			if(deviceID==0)
			{
				rtnString="No Device is associated with this Object.";
				//Siva Tata
				System.out.println(rtnString);
			}
			else
			{
			String message=(String)smtSession.createSQLQuery("select message from mdmessagedetails where messageid="+messageID).uniqueResult();
			String mobileNo=(String)smtSession.createSQLQuery("select mobileno from mddevice where deviceid="+deviceID).uniqueResult();
			
			HttpClient httpclient=new DefaultHttpClient();
			URIBuilder builder=new URIBuilder();
			String hardcodestr = "Siva Tata - HardCoded by programmer, get this fixed";
			System.out.println(hardcodestr);
			builder.setScheme("http").setHost("127.0.0.1:8080/msg/services").setPath("/sendsms/send").setParameter("to_No",mobileNo)
												.setParameter("message",message).setParameter("from_No","8520850749");
		
			URI uri=builder.build();
			HttpPost httppost=new HttpPost(uri);
			HttpResponse response=httpclient.execute(httppost);
			
			System.out.println("httppost request------"+httppost.getURI());
			System.out.println("response is " +response);
			
			rtnString="success";
			}
			
			smtTx.commit();
		}
		catch(Exception localException)
		{
			smtTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			rtnString="fail";
		}
		finally
		{
			smtSession.close();
		}
		return rtnString;
	}
	
	public String registerOwner(MDOwner mdown)
	{
		Session regOwnSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction regOwnTx=null;
		String rtnString=null;
		try
		{
			regOwnTx=regOwnSession.beginTransaction();
			MDOwnerPOJO mdownpojo=new MDOwnerPOJO();
			mdownpojo.setFirstName(mdown.getFirstName());
			mdownpojo.setFullName(mdown.getFullName());
			mdownpojo.setMobileNo(mdown.getMobileNo());
			mdownpojo.setEmailID(mdown.getEmailID());
			mdownpojo.setStreet(mdown.getStreet());
			mdownpojo.setArea(mdown.getArea());
			mdownpojo.setCity(mdown.getCity());
			mdownpojo.setState(mdown.getState());
			mdownpojo.setCountry(mdown.getCountry());
			mdownpojo.setPincode(mdown.getPincode());
			regOwnSession.saveOrUpdate(mdownpojo);	
			regOwnTx.commit();
			
			int ownerID=(Integer)regOwnSession.createSQLQuery("select ownerid from mdowner where mobileno='"+mdown.getMobileNo()+"'").uniqueResult();
			
			rtnString="<MD_Owner>\n<OwnerName>"+mdown.getFullName()+"</OwnerName>\n<OwnerID>"+ownerID+"</OwnerID>\n</MD_Owner>";
		}
		catch(Exception localException)
		{
			rtnString="fail";
			MDTransactionWriter.exceptionlog.info(localException);
			regOwnTx.rollback();
		}
		finally
		{
			regOwnSession.close();
		}
		return rtnString;
	}
	
	public String registerDriver(MDDriver mddr)
	{
		Session regDrSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction regDrTx=null;
		String rtnString=null;
		try
		{
			regDrTx=regDrSession.beginTransaction();
			MDDriverPOJO mddrpojo=new MDDriverPOJO();
			mddrpojo.setFirstName(mddr.getFirstName());
			mddrpojo.setFullName(mddr.getFullName());
			mddrpojo.setLicenceType(mddr.getLicenceType());
			mddrpojo.setLicenceNo(mddr.getLicenceNo());
			mddrpojo.setLicensedArea(mddr.getLicensedArea());
			mddrpojo.setIssuingAuth(mddr.getIssuingAuth());
			mddrpojo.setIssuedDate(mddr.getIssuedDate());
			mddrpojo.setExpiryDate(mddr.getEmailID());
			mddrpojo.setMobileNo(mddr.getMobileNo());
			mddrpojo.setEmailID(mddr.getEmailID());
			mddrpojo.setStreet(mddr.getStreet());
			mddrpojo.setArea(mddr.getArea());
			mddrpojo.setCity(mddr.getCity());
			mddrpojo.setState(mddr.getState());
			mddrpojo.setCountry(mddr.getCountry());
			mddrpojo.setPincode(mddr.getPincode());
			
			regDrSession.save(mddrpojo);
			regDrTx.commit();
			
			int driverID=(Integer)regDrSession.createSQLQuery("select driverid from mddriver where mobileno='"+mddr.getMobileNo()+"'").uniqueResult();
			
			rtnString="<MD_Driver>\n<DriverName>"+mddr.getFullName()+"</DriverName>\n<DriverID>"+driverID+"</DriverID>\n</MD_Driver>";
		}
		catch(Exception localException)
		{
			regDrTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			rtnString="fail";
		}
		finally
		{
			regDrSession.close();
		}
		return rtnString;
	}
	
	@SuppressWarnings("rawtypes")
	public String getOwnerDetails(int ownerID)
	{
		Session gtOwnSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gtOwnTx=null;
		String rtnString=null;
		StringBuffer gtoSB=new StringBuffer();
		try
		{
			gtOwnTx=gtOwnSession.beginTransaction();
			
			Query gtoQuery=gtOwnSession.createSQLQuery("select * from mdowner where ownerid="+ownerID);
			List gtoList=gtoQuery.list();
			Iterator gtoIT=gtoList.iterator();
			gtoSB.append("<MD_Owner>");
			gtoSB.append("\n");
			while(gtoIT.hasNext())
			{
				Object[] gtoObj=(Object[])gtoIT.next();
				gtoSB.append("<OwnerID>"+gtoObj[0]+"</OwnerID>");
				gtoSB.append("\n");
				gtoSB.append("<FirstName>"+gtoObj[1]+"</FirstName>");
				gtoSB.append("\n");
				gtoSB.append("<FullName>"+gtoObj[2]+"</FullName>");
				gtoSB.append("\n");
				gtoSB.append("<MobileNo>"+gtoObj[3]+"</MobileNo>");
				gtoSB.append("\n");
				gtoSB.append("<EmailID>"+gtoObj[4]+"</EmailID>");
				gtoSB.append("\n");
				gtoSB.append("<Street>"+gtoObj[5]+"</Street>");
				gtoSB.append("\n");
				gtoSB.append("<Area>"+gtoObj[6]+"</Area>");
				gtoSB.append("\n");
				gtoSB.append("<City>"+gtoObj[7]+"</City>");
				gtoSB.append("\n");
				gtoSB.append("<State>"+gtoObj[8]+"</State>");
				gtoSB.append("\n");
				gtoSB.append("<Country>"+gtoObj[9]+"</Country>");
				gtoSB.append("\n");
				gtoSB.append("<Pincode>"+gtoObj[10]+"</Pincode>");
				gtoSB.append("\n");	
			}
			gtoSB.append("</MD_Owner>");
			gtOwnTx.commit();
			rtnString=gtoSB.toString();
		}
		catch(Exception localException)
		{
			rtnString="fail";
			MDTransactionWriter.exceptionlog.info(localException);
			gtOwnTx.rollback();
		}
		finally
		{
			gtOwnSession.close();
		}
		return rtnString;
	}
	
	@SuppressWarnings("rawtypes")
	public String getDriverDetails(int driverID)
	{
		Session gtDrSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gtDrTx=null;
		String rtnString=null;
		StringBuffer gtdSB=new StringBuffer();
		try
		{
			gtDrTx=gtDrSession.beginTransaction();
			
			Query gtdQuery=gtDrSession.createSQLQuery("select * from mddriver where driverid="+driverID);
			List gtdList=gtdQuery.list();
			Iterator gtdIT=gtdList.iterator();
			gtdSB.append("<MD_Driver>");
			gtdSB.append("\n");
			while(gtdIT.hasNext())
			{
				Object[] gtoObj=(Object[])gtdIT.next();
				gtdSB.append("<DriverID>"+gtoObj[0]+"</DriverID>");
				gtdSB.append("\n");
				gtdSB.append("<FirstName>"+gtoObj[1]+"</FirstName>");
				gtdSB.append("\n");
				gtdSB.append("<FullName>"+gtoObj[2]+"</FullName>");
				gtdSB.append("\n");
				gtdSB.append("<LicenceType>"+gtoObj[3]+"</LicenceType>");
				gtdSB.append("\n");
				gtdSB.append("<LicenceNo>"+gtoObj[4]+"</LicenceNo>");
				gtdSB.append("\n");
				gtdSB.append("<LicensedArea>"+gtoObj[5]+"</LicensedArea>");
				gtdSB.append("\n");
				gtdSB.append("<IssuingAuth>"+gtoObj[6]+"</IssuingAuth>");
				gtdSB.append("\n");
				gtdSB.append("<IssuedDate>"+gtoObj[7]+"</IssuedDate>");
				gtdSB.append("\n");
				gtdSB.append("<ExpiryDate>"+gtoObj[8]+"</ExpiryDate>");
				gtdSB.append("\n");
				gtdSB.append("<MobileNo>"+gtoObj[9]+"</MobileNo>");
				gtdSB.append("\n");
				gtdSB.append("<EmailID>"+gtoObj[10]+"</EmailID>");
				gtdSB.append("\n");
				gtdSB.append("<Street>"+gtoObj[11]+"</Street>");
				gtdSB.append("\n");
				gtdSB.append("<Area>"+gtoObj[12]+"</Area>");
				gtdSB.append("\n");
				gtdSB.append("<City>"+gtoObj[13]+"</City>");
				gtdSB.append("\n");
				gtdSB.append("<State>"+gtoObj[14]+"</State>");
				gtdSB.append("\n");
				gtdSB.append("<Country>"+gtoObj[15]+"</Country>");
				gtdSB.append("\n");
				gtdSB.append("<Pincode>"+gtoObj[16]+"</Pincode>");
				gtdSB.append("\n");	
			}	
			gtdSB.append("</MD_Driver>");
			gtDrTx.commit();
			rtnString=gtdSB.toString();
		}
		catch(Exception localException)
		{
			rtnString="fail";
			MDTransactionWriter.exceptionlog.info(localException);
			gtDrTx.rollback();
		}
		finally
		{
			gtDrSession.close();
		}
		return rtnString;
	}
	
	public String updateOwner(MDOwner mdown)
	{
		Session upOwnSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction upOwnTx=null;
		String rtnString=null;
		try
		{
			upOwnTx=upOwnSession.beginTransaction();
			MDOwnerPOJO mdOwn=(MDOwnerPOJO)upOwnSession.load(MDOwnerPOJO.class,mdown.getOwnerID());
			mdOwn.setFirstName(mdown.getFirstName());
			mdOwn.setFullName(mdown.getFullName());
			mdOwn.setMobileNo(mdown.getMobileNo());
			mdOwn.setEmailID(mdown.getEmailID());
			mdOwn.setStreet(mdown.getStreet());
			mdOwn.setArea(mdown.getArea());
			mdOwn.setCity(mdown.getCity());
			mdOwn.setState(mdown.getState());
			mdOwn.setCountry(mdown.getCountry());
			mdOwn.setPincode(mdown.getPincode());
			upOwnSession.update(mdOwn);
			upOwnTx.commit();
			rtnString="Owner Details Updated";
		}
		catch(Exception localException)
		{
			rtnString="fail";
			MDTransactionWriter.exceptionlog.info(localException);
			upOwnTx.rollback();
		}
		finally
		{
			upOwnSession.close();
		}
		return rtnString;
	}
	
	public String updateDriver(MDDriver mddr)
	{
		Session upDrSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction upDrTx=null;
		String rtnString=null;
		try
		{
			upDrTx=upDrSession.beginTransaction();
			MDDriverPOJO mdDr=(MDDriverPOJO)upDrSession.load(MDDriverPOJO.class,mddr.getDriverID());
			mdDr.setFirstName(mddr.getFirstName());
			mdDr.setFullName(mddr.getFullName());
			mdDr.setLicenceType(mddr.getLicenceType());
			mdDr.setLicenceNo(mddr.getLicenceNo());
			mdDr.setLicensedArea(mddr.getLicensedArea());
			mdDr.setIssuingAuth(mddr.getIssuingAuth());
			mdDr.setIssuedDate(mddr.getIssuedDate());
			mdDr.setExpiryDate(mddr.getExpiryDate());
			mdDr.setMobileNo(mddr.getMobileNo());
			mdDr.setEmailID(mddr.getEmailID());
			mdDr.setStreet(mddr.getStreet());
			mdDr.setArea(mddr.getArea());
			mdDr.setCity(mddr.getCity());
			mdDr.setState(mddr.getState());
			mdDr.setCountry(mddr.getCountry());
			mdDr.setPincode(mddr.getPincode());
			upDrSession.update(mdDr);			
			upDrTx.commit();
			rtnString="Driver Details Updated";
		}
		catch(Exception localException)
		{
			rtnString="fail";
			MDTransactionWriter.exceptionlog.info(localException);
			upDrTx.rollback();
		}
		finally
		{
			upDrSession.close();
		}
		return rtnString;
	}

	@SuppressWarnings({ "deprecation", "rawtypes" })
	public String getAllOwners()
	{
		Session gtaoSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gtaoTx = null;
		String rtnString=null;
		StringBuffer gtaoSB=new StringBuffer();

		try
		{
			gtaoTx=gtaoSession.beginTransaction();
			String gtaoSql="select * from mdowner";
			Query gtaoQuery=gtaoSession.createSQLQuery(gtaoSql).addScalar("ownerid",Hibernate.INTEGER).addScalar("fullname",Hibernate.STRING);
			List gtaoList=gtaoQuery.list();
			Iterator it=gtaoList.iterator();
			gtaoSB.append("<MD_Owner>");
			gtaoSB.append("\n");
			while(it.hasNext())
			{
				Object[] obj=(Object[])it.next();
				gtaoSB.append("<Owner>");
				gtaoSB.append("\n");
				gtaoSB.append("<OwnerID>"+obj[0]+"</OwnerID>");
				gtaoSB.append("\n");
				gtaoSB.append("<FullName>"+obj[1]+"</FullName>");
				gtaoSB.append("\n");
				gtaoSB.append("</Owner>");
				gtaoSB.append("\n");
			}
			gtaoSB.append("</MD_Owner>");
			rtnString=gtaoSB.toString();
			gtaoTx.commit();
			gtaoSB.setLength(0);

		}
		catch(Exception localException)
		{
			gtaoTx.rollback();
			gtaoSB.setLength(0);
			MDTransactionWriter.exceptionlog.info(localException);
			rtnString="fail";
		}
		finally
		{
			gtaoSB=null;
			gtaoSession.close();
		}
		return rtnString;
		
	}
	
	@SuppressWarnings({ "deprecation", "rawtypes" })
	public String getAllDrivers()
	{
		Session gtadSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gtadTx = null;
		String rtnString=null;
		StringBuffer gtadSB=new StringBuffer();

		try
		{
			gtadTx=gtadSession.beginTransaction();
			String gtadSql="select * from mddriver";
			Query gtadQuery=gtadSession.createSQLQuery(gtadSql).addScalar("driverid",Hibernate.INTEGER).addScalar("fullname",Hibernate.STRING);
			List gtadList=gtadQuery.list();
			Iterator it=gtadList.iterator();
			gtadSB.append("<MD_Driver>");
			gtadSB.append("\n");
			while(it.hasNext())
			{
				Object[] obj=(Object[])it.next();
				gtadSB.append("<Driver>");
				gtadSB.append("\n");
				gtadSB.append("<DriverID>"+obj[0]+"</DriverID>");
				gtadSB.append("\n");
				gtadSB.append("<FullName>"+obj[1]+"</FullName>");
				gtadSB.append("\n");
				gtadSB.append("</Driver>");
				gtadSB.append("\n");
			}
			gtadSB.append("</MD_Driver>");
			rtnString=gtadSB.toString();
			gtadTx.commit();
			gtadSB.setLength(0);

		}
		catch(Exception localException)
		{
			gtadTx.rollback();
			gtadSB.setLength(0);
			MDTransactionWriter.exceptionlog.info(localException);
			rtnString="fail";
		}
		finally
		{
			gtadSB=null;
			gtadSession.close();
		}
		return rtnString;
	}
	

	/*@SuppressWarnings("rawtypes")
	public String addObjectFromRemote(MDObject mdobj,String deviceID)
	{
		Session aoSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction addObjectTx = null;
		String XMLStatusString=null;

		try
		{
			addObjectTx=aoSession.beginTransaction();		
		
			String objectName=mdobj.getObjectName();
			String parentOrgName=mdobj.getParentOrgName();
			
			int parentFolderID=(Integer)aoSession.createSQLQuery("select folderid from mdfolder where foldername='"+parentOrgName+"'").uniqueResult();
			
			List list=aoSession.createSQLQuery("select * from mdobject where objectname='"+objectName+"'").list();
			if(list!=null && list.size()>0)
			{
				XMLStatusString="Object with this name aldready exists...";
			}

			else
			{
			String fldSql="INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) " +
			"VALUES('"+objectName+"',"+parentFolderID+",0,'active','O','"+d+"','0000-00-00 00:00:00','U#1:111;U#"+deviceID+":111',"+deviceID+",0,'L')";
			Query query0=aoSession.createSQLQuery(fldSql);
			query0.executeUpdate();
			
			//registering owner
	
			String regOwn="insert into mdowner (firstname, fullname, mobileno, emailid, street, area, city, state, country, pincode) " +
					"values ('"+mdobj.getOwnerFirstName()+"','"+mdobj.getOwnerFullName()+"','"+mdobj.getOwnerMobileNo()+"','"+mdobj.getOwnerEmailID()+"','"
					+mdobj.getOwnerStreet()+"','"+mdobj.getOwnerArea()+"','"+mdobj.getOwnerCity()+"','"+mdobj.getOwnerState()+"','"+mdobj.getOwnerCountry()+"','"+mdobj.getOwnerPincode()+"')";
			Query regOwnQuery=aoSession.createSQLQuery(regOwn);
			regOwnQuery.executeUpdate();
			
			//registering driver
			
			String regDr="insert into mddriver (firstname, fullname, licencetype, licenceno, licensedarea, issuingauth, issueddate, expirydate, mobileno, emailid, street, area, city, state, country, pincode) " +
					"values ('"+mdobj.getDriverFirstName()+"','"+mdobj.getDriverFullName()+"','"+mdobj.getLicenceType()+"','"+mdobj.getLicenceNo()+"','"+mdobj.getLicensedArea()+"','"
					+mdobj.getIssuingAuth()+"','"+mdobj.getIssuedDate()+"','"+mdobj.getExpiryDate()+"','"+mdobj.getDriverMobileNo()+"','"+mdobj.getDriverEmailID()+"','"
					+mdobj.getDriverStreet()+"','"+mdobj.getDriverArea()+"','"+mdobj.getDriverCity()+"','"+mdobj.getDriverState()+"','"+mdobj.getDriverCountry()+"','"+mdobj.getDriverPincode()+"')";
			
			Query regDrQuery=aoSession.createSQLQuery(regDr);
			regDrQuery.executeUpdate();
			
			int driverID=(Integer)aoSession.createSQLQuery("select driverid from mddriver where mobileno='"+mdobj.getDriverMobileNo()+"'").uniqueResult();
			
			int ownerID=(Integer)aoSession.createSQLQuery("select ownerid from mdowner where mobileno='"+mdobj.getOwnerMobileNo()+"'").uniqueResult();

			
			String addobj="insert into mdobject (objectname, transporttype, model, colour, registrationno, chasisno, manufacturer, registereddate, registeredcircle, seatcapacity, cscapacity, ownerid, currentdriverid, parentfolderid, infoclassid, status, createddate, modifieddate, acl) " +
					"values ('"+objectName+"','"+mdobj.getTransportType()+"','"+mdobj.getModel()+"','"+mdobj.getColour()+"','"+mdobj.getRegistrationNo()+"'," +
							"'"+mdobj.getEngineChasisNo()+"', '"+mdobj.getManufacturer()+"','"+mdobj.getRegisteredDate()+"','"+mdobj.getRegisteredCircle()+"'," +
									""+mdobj.getSeatCapacity()+","+mdobj.getCsCapacity()+","+ownerID+","+driverID+","+parentFolderID+",0" +
											",0,'"+d+"','0000-00-00 00:00:00','U#"+deviceID+":111')";
			
			Query query1=aoSession.createSQLQuery(addobj);
			query1.executeUpdate();
			
			XMLStatusString="successfully added the object";
			
			}
			addObjectTx.commit();
		}

		catch(Exception localexception)
		{
			addObjectTx.rollback();
			XMLStatusString="Error while adding the object";
			MDTransactionWriter.exceptionlog.info(localexception);
			
		}
		finally
		{
			aoSession.close();
		}
		return XMLStatusString;
		
	}*/
}
