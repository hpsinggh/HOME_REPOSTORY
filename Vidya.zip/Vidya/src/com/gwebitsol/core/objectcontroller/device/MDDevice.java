package com.gwebitsol.core.objectcontroller.device;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="MD_Device")
public class MDDevice 
{
	private int deviceID;
	private String deviceName;
	private String simNo;
	private String mobileNo;
	private int ownerID;
	private String infoclassName;
	private int parentObjID;
	private String infoclassString;
	
	
	public int getDeviceID() {
		return deviceID;
	}
	public void setDeviceID(int deviceID) {
		this.deviceID = deviceID;
	}
	public String getDeviceName() {
		return deviceName;
	}
	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}
	
	public String getSimNo() {
		return simNo;
	}
	public void setSimNo(String simNo) {
		this.simNo = simNo;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public int getOwnerID() {
		return ownerID;
	}
	public void setOwnerID(int ownerID) {
		this.ownerID = ownerID;
	}
	public String getInfoclassName() {
		return infoclassName;
	}
	public void setInfoclassName(String infoclassName) {
		this.infoclassName = infoclassName;
	}
	public int getParentObjID() {
		return parentObjID;
	}
	public void setParentObjID(int parentObjID) {
		this.parentObjID = parentObjID;
	}
	public String getInfoclassString() {
		return infoclassString;
	}
	public void setInfoclassString(String infoclassString) {
		this.infoclassString = infoclassString;
	}
	
	
}
