package com.gwebitsol.core.objectcontroller.device;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

import com.gwebitsol.core.objectcontroller.device.MDDevice;

@Path("/devicemanagement/")
public interface MDDeviceManagementServiceIntf 
{
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/adddevice/")
	public Response addDevice(MDDevice mddevice,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);

	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/deldevice/")
	public Response deleteDevice(@QueryParam("deviceName") String deviceName,@QueryParam("infoclassName") String infoclassName,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@GET
	@Produces ("application/xml")
	@Path("/getalldevices")
	public Response getAllDevices(@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@GET
	@Produces("application/xml")
	@Path("/getdevicedetails")
	public Response getDeviceDetails(@QueryParam("deviceID") int deviceID,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/assginDevToObj")
	public Response associateDeviceToObject(@QueryParam("deviceName") String deviceName,@QueryParam("objectName") String objectName,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/deassociateDevFromobj")
	public Response deAssociateDeviceFromObject(@QueryParam("deviceName") String deviceName,@QueryParam("objectName") String objectName,@QueryParam("connectionid")int connectionID,@QueryParam("userid") int userID,@QueryParam("datastoreName") String datastoreName);
	
	@GET
	@Produces ("application/xml")
	@Path("/getavailabledevices")
	public Response getAvailableDevices(@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/editdevice")
	public Response editDeviceDetails(MDDevice mddevice,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@GET
	@Produces ("application/xml")
	@Path("/getassociateddevices")
	public Response getAssociatedDevices(@QueryParam("objectName") String objectName,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@GET
	@Produces ("application/xml")
	@Path("/getdestobj")
	public Response getDestinationObjects(@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
}
