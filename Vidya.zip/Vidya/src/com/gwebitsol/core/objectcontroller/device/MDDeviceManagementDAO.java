package com.gwebitsol.core.objectcontroller.device;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.gwebitsol.core.infoclass.MDPrepareInsertQueryForObject;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class MDDeviceManagementDAO
{
	DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	Date date = new Date();
	String d=dateFormat.format(date);
	@SuppressWarnings("rawtypes")
	public String addDevice(MDDevice mddev,int uid)
	{
		SessionFactory factory=MDHibernateUtil.getSessionFactory();
		Session session=factory.openSession();
		Transaction addDeviceTx = null;	
		String XMLStatusString=null;
		int status;
		int deviceID;
		String assign;
		String deviceName=mddev.getDeviceName();
		String infoclassName=mddev.getInfoclassName();
		int parentObjID=mddev.getParentObjID();
		String simNo=mddev.getSimNo();
		String mobileNo=mddev.getMobileNo();
		int ownerID=mddev.getOwnerID();
		String infoclassString=mddev.getInfoclassString();
		String acl=null;
		
		
		try
		{
			addDeviceTx=session.beginTransaction();
			if(uid==1)
			{
				acl="U#1:111";
			}
			else
			{
				acl="U#1:111;U#"+uid+":111";
			}
			int infoclassID =(Integer)session.createSQLQuery("select infoclassid from mdobjectinfoclassdefcontainer where infoclassname='"+infoclassName+"'").uniqueResult();
			
			List list=session.createSQLQuery("select * from mddevice where devicename='"+deviceName+"'").list();
			if(list!=null && list.size()>0)
			{
				XMLStatusString="Device with this name already exists...";
			}

			else
			{
				
				if(parentObjID==0)
				{
					status=1;
					assign="no";
					String dvcSql="insert into mddevice(devicename,simno,mobileno,infoclassid,ownerid,createddate,modifieddate,acl,createdby,modifiedby,status,assign) " +
							"values('"+deviceName+"','"+simNo+"','"+mobileNo+"',"+infoclassID+","+ownerID+",'"+d+"','0000-00-00 00:00:00','"+acl+"',"+uid+",0,"+status+",'"+assign+"')";
					Query query1=session.createSQLQuery(dvcSql);
					query1.executeUpdate();
					
					deviceID=(Integer)session.createSQLQuery("select deviceid from mddevice where devicename='"+deviceName+"'").uniqueResult();
					
				}
				else
				{
					status=2;
					assign="yes";
					
					String dvcSql="insert into mddevice(devicename,simno,mobileno,infoclassid,ownerid,createddate,modifieddate,acl,createdby,modifiedby,status,assign) " +
							"values('"+deviceName+"','"+simNo+"','"+mobileNo+"',"+infoclassID+","+ownerID+",'"+d+"','0000-00-00 00:00:00','"+acl+"',"+uid+",0,"+status+",'"+assign+"')";
					Query query1=session.createSQLQuery(dvcSql);
					query1.executeUpdate();
					deviceID=(Integer)session.createSQLQuery("select deviceid from mddevice where devicename='"+deviceName+"'").uniqueResult();
					
					Query query=session.createSQLQuery("update mdfolder set folderlevel='P' where folderid="+parentObjID);
					query.executeUpdate();
					
					String objectName=(String)session.createSQLQuery("select foldername from mdfolder where folderid="+parentObjID).uniqueResult();
					
					Query query2=session.createSQLQuery("update mdobject set deviceid="+deviceID+" where objectname='"+objectName+"'");
					query2.executeUpdate();
				}
				
				String fldSql="INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) " +
						"VALUES('"+deviceName+"',"+parentObjID+","+infoclassID+",'active','D','"+d+"','0000-00-00 00:00:00','"+acl+"',"+uid+",0,'L')";
				Query query0=session.createSQLQuery(fldSql);
				query0.executeUpdate();
		
				MDPrepareInsertQueryForObject pdiQuery=new MDPrepareInsertQueryForObject();
				String firstHalf=pdiQuery.prepareQuery(infoclassName, infoclassID);
				String totalQuery=firstHalf+deviceID+","+infoclassString+")";
				Query query2=session.createSQLQuery(totalQuery);
				query2.executeUpdate();
				
				XMLStatusString="successfully added the device";

			}
			addDeviceTx.commit();
		}

		catch(Exception localexception)
		{
			XMLStatusString="Error while adding the device";
			MDTransactionWriter.exceptionlog.info(localexception);
			addDeviceTx.rollback();
		}
		finally
		{
			session.close();
		}
		return XMLStatusString;
	}
	
	public String updateDevice(MDDevice mddev,int uid)
	{
		Session upDevSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction upDevTx=null;
		String XMLString=null;
		int deviceID=mddev.getDeviceID();
		String deviceName=mddev.getDeviceName();
		String infoclassName=mddev.getInfoclassName();
		String simNo=mddev.getSimNo();
		String mobileNo=mddev.getMobileNo();
		int ownerID=mddev.getOwnerID();
		String infoclassString=mddev.getInfoclassString();
		try
		{
				upDevTx=upDevSession.beginTransaction();
				int infoclassID=(Integer)upDevSession.createSQLQuery("select infoclassid from mdobjectinfoclassdefcontainer where infoclassname='"+infoclassName+"'").uniqueResult();
				String devName=(String)upDevSession.createSQLQuery("select devicename from mddevice where deviceid="+deviceID).uniqueResult();
				int folderID=(Integer)upDevSession.createSQLQuery("select folderid from mdfolder where foldername='"+devName+"'").uniqueResult();
				
				Query query=upDevSession.createSQLQuery("update mddevice set devicename='"+deviceName+"', simno='"+simNo+"', mobileNo='"+mobileNo+"',ownerid="+ownerID+", modifieddate='"+d+"',modifiedby="+uid+" where deviceid="+deviceID);
				query.executeUpdate();
				
				Query query1=upDevSession.createSQLQuery("delete from "+infoclassName+" where componentid="+deviceID);
				query1.executeUpdate();

				MDPrepareInsertQueryForObject piQuery=new MDPrepareInsertQueryForObject();
				String firstHalf=piQuery.prepareQuery(infoclassName, infoclassID);
				String totalQuery=firstHalf+deviceID+","+infoclassString+")";
				Query query2=upDevSession.createSQLQuery(totalQuery);
				query2.executeUpdate();
				
				Query query3=upDevSession.createSQLQuery("update mdfolder set foldername='"+deviceName+"' ,modifieddate='"+d+"' , modifiedby="+uid+" where folderID="+folderID);
				query3.executeUpdate();
				
				Query query4=upDevSession.createSQLQuery("update mddevice set modifieddate='"+d+"' , modifiedby="+uid+" where deviceid="+deviceID);
				query4.executeUpdate();
			
				upDevTx.commit();
				XMLString="successfully updated the device";
			
		}
		catch(Exception localException)
		{
			upDevTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			XMLString="fail";
		}
		finally
		{
			upDevSession.close();
		}
		return XMLString;
	}
	
	@SuppressWarnings("rawtypes")
	public String deleteDevice(String deviceName,String infoclassName)
	{
		Session ddSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction ddTx=null;
		String rtnString=null;
		
		try
		{
			ddTx=ddSession.beginTransaction();
			
			int deviceID=(Integer)ddSession.createSQLQuery("select deviceid from mddevice where devicename='"+deviceName+"'").uniqueResult();
			String ddSql="select * from mdobject where deviceid="+deviceID;
			Query ddQuery0=ddSession.createSQLQuery(ddSql);
			List ddList=ddQuery0.list();
			if(ddList.isEmpty())
			{}
			else
			{
				Iterator ddIT=ddList.iterator();
				while(ddIT.hasNext())
				{
					Object[] ddObj=(Object[])ddIT.next();
					int objID=(Integer)ddObj[0];
				
					Query ddQuery1=ddSession.createSQLQuery("update mdobject set deviceid=0 where objectid="+objID);
					ddQuery1.executeUpdate();
				}
			}
			Query ddQuery=ddSession.createSQLQuery("delete from "+infoclassName+" where componentid="+deviceID);
			ddQuery.executeUpdate();
			
			Query ddQuery1=ddSession.createSQLQuery("delete from mddevice where deviceid="+deviceID);
			ddQuery1.executeUpdate();
			
			Query ddQuery2=ddSession.createSQLQuery("delete from mdfolder where foldername='"+deviceName+"'");
			ddQuery2.executeUpdate();
			
			ddTx.commit();
			rtnString="success";
		}
		catch(Exception localException)
		{
			ddTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			rtnString="fail";
		}
		finally
		{
			ddSession.close();
		}
		
		return rtnString;
	}
	
	@SuppressWarnings({ "deprecation", "rawtypes" })
	public String getAllDevices(int uid)
	{
		
		SessionFactory factory=MDHibernateUtil.getSessionFactory();
		Session session=factory.openSession();
		Transaction getDevicesTx = null;
		
		String respXMLString=null;
		StringBuffer devicesSB=new StringBuffer();
		
		try
		{
			getDevicesTx=session.beginTransaction();
			String devSql="select * from mddevice where acl like '%U#"+uid+":%' order by devicename ASC";
			Query devQuery=session.createSQLQuery(devSql).addScalar("deviceid",Hibernate.INTEGER).addScalar("devicename",Hibernate.STRING);
			List devList=devQuery.list();
			if(devList!=null && devList.size()>0)
			{
			Iterator it=devList.iterator();
			devicesSB.append("<MD_Devices>");
			devicesSB.append("\n");
			while(it.hasNext())
			{
				Object[] dev=(Object[])it.next();
				devicesSB.append("<deviceID>"+dev[0]+"</deviceID>");
				devicesSB.append("\n");
				devicesSB.append("<deviceName>"+dev[1]+"</deviceName>");
				devicesSB.append("\n");
			}
			devicesSB.append("</MD_Devices>");
			
			}
			else
			{
				devicesSB.append("<MD_Devices>");
				devicesSB.append("\n");
				devicesSB.append("<deviceName>No Devices</deviceName>");
				devicesSB.append("\n");
				devicesSB.append("</MD_Devices>");
				
			}
			getDevicesTx.commit();
			respXMLString=devicesSB.toString();
			devicesSB.setLength(0);
			
		}
		catch(Exception localException)
		{
			devicesSB.setLength(0);
			getDevicesTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			respXMLString="Error while retrieving the devices";
		}
		finally
		{
			devicesSB=null;
			session.close();
		}
		return respXMLString;
	}

	@SuppressWarnings({ "rawtypes", "deprecation" })
	public String getDeviceDetails(int deviceID)
	{
		Session gdtSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gdevDetailsTx = null;	
		String gdtXMLString=null;
		StringBuffer infFieldsSB=new StringBuffer();
		String infoclassName=null;
		try
		{
			gdevDetailsTx=gdtSession.beginTransaction();
			int deviceid=0;
			int infoclassid=0;

			String infSql="select * from MDDEVICE where deviceid="+deviceID;
			Query devQuery=gdtSession.createSQLQuery(infSql).addScalar("deviceid",Hibernate.INTEGER).addScalar("devicename",Hibernate.STRING)
					.addScalar("simno",Hibernate.STRING).addScalar("mobileno",Hibernate.STRING).addScalar("infoclassid",Hibernate.INTEGER).addScalar("ownerid",Hibernate.INTEGER)
					.addScalar("status",Hibernate.INTEGER);
			List devList=devQuery.list();
			Iterator devIT=devList.iterator();
			infFieldsSB.append("<MD_Device>");
			infFieldsSB.append("\n");
			while(devIT.hasNext())
			{
				System.out.println("enterd into 1 loop");
				Object[] objids=(Object[])devIT.next();
				deviceid=(Integer)objids[0];
				String deviceName=(String)objids[1];
				String simNo=(String)objids[2];
				String mobileNo=(String)objids[3];
				infoclassid=(Integer)objids[4];
				int ownerID=(Integer)objids[5];
				String ownerName=(String)gdtSession.createSQLQuery("select fullname from mdowner where ownerid="+ownerID).uniqueResult();
				infoclassName=(String)gdtSession.createSQLQuery("select infoclassname from mdobjectinfoclassdefcontainer where infoclassid="+infoclassid).uniqueResult();
				
				infFieldsSB.append("<devicedetails>");
				infFieldsSB.append("\n");
				infFieldsSB.append("<deviceID>"+deviceid+"</deviceID>");
				infFieldsSB.append("\n");
				infFieldsSB.append("<deviceName>"+deviceName+"</deviceName>");
				infFieldsSB.append("\n");
				infFieldsSB.append("<simNo>"+simNo+"</simNo>");
				infFieldsSB.append("\n");
				infFieldsSB.append("<mobileNo>"+mobileNo+"</mobileNo>");
				infFieldsSB.append("\n");
				infFieldsSB.append("<ownerID>"+ownerID+"</ownerID>");
				infFieldsSB.append("\n");
				infFieldsSB.append("<ownerName>"+ownerName+"</ownerName>");
				infFieldsSB.append("\n");
				infFieldsSB.append("<infoclassName>"+infoclassName+"</infoclassName>");
				infFieldsSB.append("\n");
				int k=(Integer)objids[6];
				if(k==1)
				infFieldsSB.append("<status>deactive</status>");
				else if(k==2)
					infFieldsSB.append("<status>active</status>");
				infFieldsSB.append("\n");
				infFieldsSB.append("</devicedetails>");
				infFieldsSB.append("\n");
			}	
			
			
			String infSql3="select  * from mdobjinfoclassfields where infoclassid="+infoclassid+" group by parentfieldgroup order by fieldid";
			Query ginfQuery1=gdtSession.createSQLQuery(infSql3).addScalar("FIELDID",Hibernate.INTEGER).addScalar("PARENTFIELDGROUP",Hibernate.STRING);
			List ginfList1=ginfQuery1.list();
			infFieldsSB.append("<devicedetails>");
			infFieldsSB.append("\n");
			Iterator ginfIT=ginfList1.iterator();
			while(ginfIT.hasNext())
			{
				Object[] infObj1=(Object[])ginfIT.next();
				infFieldsSB.append("<SectionName name='"+infObj1[1]+"'>");
				infFieldsSB.append("\n");
				String pfg=(String)infObj1[1];
				System.out.println(pfg);
				String infSql1="select * from mdobjinfoclassfields  where infoclassid="+infoclassid+" and parentfieldgroup='"+pfg+"'";
				Query ginfQuery=gdtSession.createSQLQuery(infSql1).addScalar("fieldid",Hibernate.INTEGER).addScalar("infoclassid",Hibernate.INTEGER).addScalar("fieldname",Hibernate.STRING);
				List ginfList=ginfQuery.list();
				Iterator it=ginfList.iterator();
				while(it.hasNext())
				{
					Object[] infObj=(Object[])it.next();
					infFieldsSB.append("<field>");
					infFieldsSB.append("\n");
					infFieldsSB.append("<fieldname>");
					infFieldsSB.append(infObj[2]);
					infFieldsSB.append("</fieldname>");
					infFieldsSB.append("\n");
					infFieldsSB.append("</field>");
				}
				infFieldsSB.append("\n");
				infFieldsSB.append("</SectionName>");	
			}	
			infFieldsSB.append("\n");

			String objSql="select * from view_"+infoclassName+" where componentid="+deviceid;
			Query dfvQuery=gdtSession.createSQLQuery(objSql);
			List dfvList=dfvQuery.list();
			Iterator dfvit=dfvList.iterator();
			infFieldsSB.append("<fieldvalues>");infFieldsSB.append("\n");
			while(dfvit.hasNext())
			{
				System.out.println("entered into while loop of final one");
				Object[] dfvStr=(Object[])dfvit.next();
				int k=dfvStr.length;
				for(int i=2;i<k;i++)
				{
					System.out.println("enterd into for loop");
					infFieldsSB.append("<fieldvalue>");
					infFieldsSB.append(dfvStr[i]);
					infFieldsSB.append("</fieldvalue>");
					infFieldsSB.append("\n");
				}
			}
			infFieldsSB.append("</fieldvalues>");
			infFieldsSB.append("\n");
			infFieldsSB.append("</devicedetails>");
			infFieldsSB.append("\n");
			infFieldsSB.append("</MD_Device>");
		

			gdtXMLString=infFieldsSB.toString();
			gdevDetailsTx.commit();
			infFieldsSB.setLength(0);
		}
		
		catch(Exception localexception)
		{
			gdevDetailsTx.rollback();
			infFieldsSB.setLength(0);
			MDTransactionWriter.exceptionlog.info(localexception);
			gdtXMLString="<status>Error occured while retreving device details</status>";
		}
		finally
		{
			gdtSession.close();
			infFieldsSB=null;
		}

		return gdtXMLString;
	}
	
	public String associateDeviceToObject(String deviceName,String objectName,int userID)
	{
		Session adSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction adTx = null;	
		String outStr=null;
		try
		{

			adTx=adSession.beginTransaction();
		
			int devID=(Integer)adSession.createSQLQuery("select deviceid from mddevice where devicename='"+deviceName+"'").uniqueResult();
			
			int deviceID=(Integer)adSession.createSQLQuery("select deviceid from mdobject where objectname='"+objectName+"'").uniqueResult();
			if(deviceID!=0)
			{
				outStr="<status>This Object is already associated with a device.First Deassociate that device..</status>";
			}

			else
			{
		
			Query adQuery=adSession.createSQLQuery("update mddevice set status=2,assign='yes',modifieddate='"+d+"' , modifiedby="+userID+" where devicename='"+deviceName+"'");
			adQuery.executeUpdate();
			
			Query adQuery1=adSession.createSQLQuery("update mdobject set deviceid="+devID+",modifieddate='"+d+"' where objectname='"+objectName+"'");
			adQuery1.executeUpdate();
			
			int parentFolderID=(Integer)adSession.createSQLQuery("select folderid from mdfolder where foldername='"+objectName+"'").uniqueResult();
			
			Query adQuery2=adSession.createSQLQuery("update mdfolder set parentfolderid="+parentFolderID+",modifieddate='"+d+"' , modifiedby="+userID+" ,folderlevel='L' where foldername='"+deviceName+"'");
			adQuery2.executeUpdate();
			
			Query adQuery3=adSession.createSQLQuery("update mdfolder set folderlevel='P',modifieddate='"+d+"' where foldername='"+objectName+"'");
			adQuery3.executeUpdate();
			
		
			adTx.commit();
			outStr="<status>Device associated to Object</status>";
			}
			
		}
		catch(Exception localException)
		{
			adTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			outStr="<status>Error occured while associating device to object</status>";
		}
		finally
		{
			adSession.close();
		}
		return outStr;
	}
	
	public String deAssociateDeviceFromObject(String deviceName,String objectName,int userID)
	{
		Session daSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction daTx = null;	
		String outStr=null;
		try
		{
			daTx=daSession.beginTransaction();
			
			Query daQuery=daSession.createSQLQuery("update mddevice set status=1,assign='no',modifieddate='"+d+"', modifiedby="+userID+" where devicename='"+deviceName+"'");
			daQuery.executeUpdate();
			
			Query daQuery1=daSession.createSQLQuery("update mdfolder set parentfolderid=0,modifieddate='"+d+"' , modifiedby="+userID+" where foldername='"+deviceName+"'");
			daQuery1.executeUpdate();
			
			Query daQuery2=daSession.createSQLQuery("update mdobject set deviceid=0,modifieddate='"+d+"' where objectname='"+objectName+"'");
			daQuery2.executeUpdate();
			
			Query daQuery3=daSession.createSQLQuery("update mdfolder set folderlevel='L' where foldername='"+objectName+"'");
			daQuery3.executeUpdate();
			
			daTx.commit();
			outStr="<status>Device deassociated from Object</status>";
			
		}
		catch(Exception localException)
		{
			daTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			outStr="<status>Error occured while deassociating device from object</status>";
		}
		finally
		{
			daSession.close();
		}
		return outStr;
		
	}
	
	@SuppressWarnings({ "deprecation", "rawtypes" })
	public String getDeassociatedDevices()
	{
		Session gddSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gddTx = null;
		String respXMLString=null;
		StringBuffer gddSB=new StringBuffer();
		try
		{
			gddTx=gddSession.beginTransaction();
			String gddSql="select * from mdfolder where parentfolderid=0 and foldertype='D'";
			Query gddQuery=gddSession.createSQLQuery(gddSql).addScalar("foldername",Hibernate.STRING);
			List gddList=gddQuery.list();
			if(gddList!=null && gddList.size()>0)
			{
			Iterator gddIT=gddList.iterator();
			gddSB.append("<MD_Devices>");
			gddSB.append("\n");
			while(gddIT.hasNext())
			{
				String deviceName=(String)gddIT.next();
				gddSB.append("<deviceName>"+deviceName+"</deviceName>");
				gddSB.append("\n");
			}
			gddSB.append("</MD_Devices>");
			}
			else
			{
				gddSB.append("<MD_Devices>");
				gddSB.append("\n");
				gddSB.append("<deviceName>No devices available for association..</deviceName>");
				gddSB.append("\n");
				gddSB.append("</MD_Devices>");
				
			}
			respXMLString=gddSB.toString();
			gddSB.setLength(0);
			gddTx.commit();
			
			
		}
		catch(Exception localException)
		{
			gddTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			gddSB.setLength(0);
			respXMLString="fail";
		}
		finally
		{
			gddSession.close();
			gddSB=null;
		}
		return respXMLString;
	}

	public String getAssociatedDevices(String objectName)
	{
		Session aDevSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction aDevTx=null;
		String outString=null;
		StringBuffer aDevSB=new StringBuffer();
		try
		{
			aDevTx=aDevSession.beginTransaction();
			
			int devID=(Integer)aDevSession.createSQLQuery("select deviceid from mdobject where objectname='"+objectName+"'").uniqueResult();	
			aDevSB.append("<MD_Devices>");
			aDevSB.append("\n");
			if(devID==0)
			{
				aDevSB.append("<deviceName>No Device is associated with this Object.</deviceName>");
			}
			else
			{
				String deviceName=(String)aDevSession.createSQLQuery("select devicename from mddevice where deviceid="+devID).uniqueResult();
				aDevSB.append("<deviceName>"+deviceName+"</deviceName>");
			}
			aDevSB.append("\n");
			aDevSB.append("</MD_Devices>");
			aDevTx.commit();
			outString=aDevSB.toString();
			
		}
		catch(Exception localException)
		{
			aDevTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			outString="fail";
		}
		finally
		{
			aDevSession.close();
		}
		
		return outString;
		
	}
	
	@SuppressWarnings({ "deprecation", "rawtypes" })
	public String getDestinationObject(int uid)
	{
		SessionFactory factory=MDHibernateUtil.getSessionFactory();
		Session session=factory.openSession();
		Transaction getObjectsTx = null;
		String respXMLString=null;
		StringBuffer objectsSB=new StringBuffer();

		try
		{
			getObjectsTx=session.beginTransaction();
			String objSql="select * from mdfolder where foldertype='O' and acl like '%U#"+uid+":%' and folderlevel!='P' order by foldername ASC";
			Query objQuery=session.createSQLQuery(objSql).addScalar("folderid",Hibernate.INTEGER).addScalar("foldername",Hibernate.STRING);
			List objList=objQuery.list();
			if(objList!=null && objList.size()>0)
			{
			Iterator it=objList.iterator();
			objectsSB.append("<MD_Objects>");
			objectsSB.append("\n");
			while(it.hasNext())
			{
				Object[] obj=(Object[])it.next();
				objectsSB.append("<Object>");
				objectsSB.append("\n");
				objectsSB.append("<objectID>"+obj[0]+"</objectID>");
				objectsSB.append("\n");
				objectsSB.append("<objectName>"+obj[1]+"</objectName>");
				objectsSB.append("\n");
				objectsSB.append("</Object>");
				objectsSB.append("\n");
			}
			objectsSB.append("</MD_Objects>");
			
			}
			else
			{
			objectsSB.append("<MD_Objects>");
			objectsSB.append("\n");
			objectsSB.append("<Object>");
			objectsSB.append("\n");
			objectsSB.append("<objectName>No Vehicles</objectName>");
			objectsSB.append("\n");
			objectsSB.append("</Object>");
			objectsSB.append("\n");
			objectsSB.append("</MD_Objects>");		
			}
			respXMLString=objectsSB.toString();
			getObjectsTx.commit();
			objectsSB.setLength(0);

		}
		catch(Exception localException)
		{
			getObjectsTx.rollback();
			objectsSB.setLength(0);
			MDTransactionWriter.exceptionlog.info(localException);
			respXMLString="fail";
		}
		finally
		{
			objectsSB=null;
			session.close();
		}
		return respXMLString;
	}
}
