package com.gwebitsol.core.objectcontroller.device;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.gwebitsol.core.objectcontroller.device.MDDevice;
import com.gwebitsol.core.objectcontroller.device.MDDeviceManagementDAO;
import com.gwebitsol.core.objectcontroller.device.MDDeviceManagementServiceIntf;
import com.gwebitsol.core.security.MDVerifyConnectionID;
import com.gwebitsol.core.security.MDVerifyDatastoreName;
import com.gwebitsol.core.usermanagement.MDGetUserFromID;
import com.gwebitsol.core.util.MDTransactionWriter;

public class MDDeviceManagementService implements MDDeviceManagementServiceIntf
{
	@Context private HttpServletRequest hsr;
	public Response addDevice(MDDevice mddevice,int userID,int connectionID,String datastoreName)
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
			MDDeviceManagementDAO dmDAO=new MDDeviceManagementDAO();
			XMLString=dmDAO.addDevice(mddevice,userID);
			if(XMLString.equals("Error while adding the device"))
				statusStr="failed";
			else
				statusStr="success";
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			MDTransactionWriter.writeLog(datastoreName,"DeviceMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}
		}
		catch(WebApplicationException localWebApplicationException)
		{
			MDTransactionWriter.exceptionlog.info(localWebApplicationException);
			XMLString="<status>Failed in Service Layer</status>";
		}

		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}
	
	public Response deleteDevice(String deviceName, String infoclassName,int userID, int connectionID, String datastoreName) 
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
			MDDeviceManagementDAO dmDAO=new MDDeviceManagementDAO();
			XMLString="<status>"+dmDAO.deleteDevice(deviceName, infoclassName)+"</status>";
			if(XMLString.equals("<status>Error while adding the device</status>"))
				statusStr="failed";
			else
				statusStr="success";
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			MDTransactionWriter.writeLog(datastoreName,"DeviceMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}
		}
		catch(WebApplicationException localWebApplicationException)
		{
			MDTransactionWriter.exceptionlog.info(localWebApplicationException);
			XMLString="<status>Failed in Service Layer</status>";
		}

		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}
	
	public Response getAllDevices(int userID,int connectionID,String datastoreName)
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{

			MDDeviceManagementDAO dmDAO=new MDDeviceManagementDAO();
			XMLString="<status>"+"\n"+dmDAO.getAllDevices(userID)+"\n"+"</status>";
			if(XMLString.equals("<status>Error while retrieving the devices</status>"))
				statusStr="failed";
			else
				statusStr="success";
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			MDTransactionWriter.writeLog(datastoreName,"DeviceMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}
		}
		catch(WebApplicationException localWebApplicationException)
		{
			MDTransactionWriter.exceptionlog.info(localWebApplicationException);
			XMLString="<status>failed in DAO layer</status>";
		}

		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}


	public Response getDeviceDetails(int deviceID,int userID,int connectionID,String datastoreName)
	{

		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{

			MDDeviceManagementDAO omDAO= new MDDeviceManagementDAO();
			XMLString=omDAO.getDeviceDetails(deviceID);
			if(XMLString.equals("<status>Error occured while retreving device details</status>"))
				statusStr="failed";
			else
				statusStr="success";
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			MDTransactionWriter.writeLog(datastoreName,"DeviceMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}

		}catch(WebApplicationException localWebApplicationException)
		{
			MDTransactionWriter.exceptionlog.info(localWebApplicationException);
			XMLString="<status>failed in DAO layer</status>";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}
	public Response associateDeviceToObject(String deviceName, String objectName,int userID,int connectionID,String datastoreName) 
	
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
	try
	{
		MDGetUserFromID mdgufid=new MDGetUserFromID();
		String requester=mdgufid.getUserName(userID);
		
		System.out.println(connectionID);
		MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
		int ret=mdvcid.verifyConnectionID(userID,connectionID);
		
		MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
		int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
		
		System.out.println("request making user:: "+requester);
		System.out.println("connectionid verification value:: "+ret);
		System.out.println("datastore verification value :: "+rtVal);
		if(ret==1 )//&& rtVal==1)
		{
		MDDeviceManagementDAO mdmDAO= new MDDeviceManagementDAO();
		XMLString=mdmDAO.associateDeviceToObject(deviceName, objectName,userID);
		if(XMLString.equals("<status>Error occured while associating device to object</status>"))
			statusStr="failed";
		else
			statusStr="success";
		String endDate=dateFormat.format(new Date());
		Long el=System.currentTimeMillis();
		MDTransactionWriter.writeLog(datastoreName,"DeviceMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
		}
		else
		{
			XMLString="you are not authorised user";
		}

	}catch(WebApplicationException localWebApplicationException)
	{
		MDTransactionWriter.exceptionlog.info(localWebApplicationException);
		XMLString="<status>failed in DAO layer</status>";
	}
	return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}

	
	public Response deAssociateDeviceFromObject(String deviceName,String objectName,int connectionID,int userID,String datastoreName)
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
			MDDeviceManagementDAO mdmDAO= new MDDeviceManagementDAO();
			XMLString=mdmDAO.deAssociateDeviceFromObject(deviceName,objectName,userID);
			if(XMLString.equals("<status>Error occured while deassociating device from object</status>"))
				statusStr="failed";
			else
				statusStr="success";
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			MDTransactionWriter.writeLog(datastoreName,"DeviceMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}

		}catch(WebApplicationException localWebApplicationException)
		{
			MDTransactionWriter.exceptionlog.info(localWebApplicationException);
			XMLString="<status>failed in DAO layer</status>";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}
	public Response getAvailableDevices(int userID, int connectionID,String datastoreName) 
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
			MDDeviceManagementDAO dmDAO=new MDDeviceManagementDAO();
			XMLString="<status>"+"\n"+dmDAO.getDeassociatedDevices()+"\n"+"</status>";
			if(XMLString.equals("<status>fail</status>"))
				statusStr="failed";
			else
				statusStr="success";
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			MDTransactionWriter.writeLog(datastoreName,"DeviceMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}
		}
		catch(WebApplicationException localWebApplicationException)
		{
			MDTransactionWriter.exceptionlog.info(localWebApplicationException);
			XMLString="<status>failed in DAO layer</status>";
		}

		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}

	public Response editDeviceDetails(MDDevice mddevice,int userID, int connectionID, String datastoreName) 
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
			MDDeviceManagementDAO dmDAO=new MDDeviceManagementDAO();
			XMLString=dmDAO.updateDevice(mddevice,userID);
			if(XMLString.equals("fail"))
				statusStr="failed";
			else
				statusStr="success";
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			MDTransactionWriter.writeLog(datastoreName,"DeviceMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}
		}
		catch(WebApplicationException localWebApplicationException)
		{
			MDTransactionWriter.exceptionlog.info(localWebApplicationException);
			XMLString="<status>Failed in Service Layer</status>";
		}

		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}
	
	public Response getAssociatedDevices(String objectName, int userID,int connectionID, String datastoreName) 
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
	try
	{
		MDGetUserFromID mdgufid=new MDGetUserFromID();
		String requester=mdgufid.getUserName(userID);
		
		System.out.println(connectionID);
		MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
		int ret=mdvcid.verifyConnectionID(userID,connectionID);
		
		MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
		int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
		
		System.out.println("request making user:: "+requester);
		System.out.println("connectionid verification value:: "+ret);
		System.out.println("datastore verification value :: "+rtVal);
		if(ret==1 )//&& rtVal==1)
		{
		MDDeviceManagementDAO mdmDAO= new MDDeviceManagementDAO();
		XMLString=mdmDAO.getAssociatedDevices(objectName);
		if(XMLString.equals("<status>Error occured while associating device to object</status>"))
			statusStr="failed";
		else
			statusStr="success";
		String endDate=dateFormat.format(new Date());
		Long el=System.currentTimeMillis();
		MDTransactionWriter.writeLog(datastoreName,"DeviceMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
		}
		else
		{
			XMLString="you are not authorised user";
		}

	}catch(WebApplicationException localWebApplicationException)
	{
		MDTransactionWriter.exceptionlog.info(localWebApplicationException);
		XMLString="<status>failed in DAO layer</status>";
	}
	return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}

	public Response getDestinationObjects(int userID, int connectionID,String datastoreName) 
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
	try
	{
		MDGetUserFromID mdgufid=new MDGetUserFromID();
		String requester=mdgufid.getUserName(userID);
		
		System.out.println(connectionID);
		MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
		int ret=mdvcid.verifyConnectionID(userID,connectionID);
		
		MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
		int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
		
		System.out.println("request making user:: "+requester);
		System.out.println("connectionid verification value:: "+ret);
		System.out.println("datastore verification value :: "+rtVal);
		if(ret==1 )//&& rtVal==1)
		{
		MDDeviceManagementDAO mdmDAO= new MDDeviceManagementDAO();
		XMLString=mdmDAO.getDestinationObject(userID);
		if(XMLString.equals("<status>Error occured while associating device to object</status>"))
			statusStr="failed";
		else
			statusStr="success";
		String endDate=dateFormat.format(new Date());
		Long el=System.currentTimeMillis();
		MDTransactionWriter.writeLog(datastoreName,"DeviceMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
		}
		else
		{
			XMLString="you are not authorised user";
		}

	}catch(WebApplicationException localWebApplicationException)
	{
		MDTransactionWriter.exceptionlog.info(localWebApplicationException);
		XMLString="<status>failed in DAO layer</status>";
	}
	return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}

	
	
}
