package com.gwebitsol.core.notifications.push;

public class MDPushNotificationToTDB 
{
	public String sendNotification(String gcm_reg_id,String message)
	{
		
		return "";
	}
}
