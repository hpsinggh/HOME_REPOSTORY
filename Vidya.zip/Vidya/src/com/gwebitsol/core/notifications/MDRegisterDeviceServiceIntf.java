package com.gwebitsol.core.notifications;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

@Path("/registerService/")
public interface MDRegisterDeviceServiceIntf 
{
	@POST
	@Produces({"application/xml", "application/json"})
	@Consumes({"application/xml", "application/json"})
	@Path("/registerDevice")
	public Response registerDevice(@QueryParam("regNO") String regNO);

}
