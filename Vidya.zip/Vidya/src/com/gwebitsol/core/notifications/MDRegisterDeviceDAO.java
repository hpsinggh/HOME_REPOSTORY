package com.gwebitsol.core.notifications;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class MDRegisterDeviceDAO 
{
	Session rdSession=MDHibernateUtil.getSessionFactory().openSession();
	Transaction rdTx=null;
	public String registerDevice(String regNO)
	{
		String rtnString=null;
		try
		{
			rdTx=rdSession.beginTransaction();
			String rdSql="insert into mddeviceid(registrationno) values('"+regNO+"')";
			Query rdQuery=rdSession.createSQLQuery(rdSql);
			rdQuery.executeUpdate();	
			rdTx.commit();
			rtnString="device registered";
		}
		catch(Exception localException)
		{
			rdTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			rtnString="fail";
		}
		finally
		{
			rdSession.close();
		}
		return rtnString;
	}

}
