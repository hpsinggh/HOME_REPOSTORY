package com.gwebitsol.core.notifications;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.gwebitsol.core.security.MDVerifyConnectionID;
import com.gwebitsol.core.util.MDTransactionWriter;

public class MDRegisterDeviceService implements MDRegisterDeviceServiceIntf
{

	@Context private HttpServletRequest hsr;
	public Response registerDevice(String regNO) 
	{
		MDTransactionWriter.accesslog.info("Request from:"+hsr.getRemoteHost());		
		String XMLString=null;
		String statusString=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
					MDRegisterDeviceDAO mdrd=new MDRegisterDeviceDAO();
					XMLString=mdrd.registerDevice(regNO);
					statusString="device registered";
					String endDate=dateFormat.format(new Date());
					Long el=System.currentTimeMillis();
					MDTransactionWriter.writeLog("idea","MMS","rajesh",startDate,endDate,sl,el,statusString,hsr.getRemoteHost());
		
			
		}
		catch(Exception localException)
		{
			MDTransactionWriter.exceptionlog.info(localException);
			XMLString="failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
		
	}

	

}
