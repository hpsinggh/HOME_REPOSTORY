package com.gwebitsol.core.notifications.mails;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.StringTokenizer;



import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class SendCCMails 
{
	public String sendCCMails(String senderName,String recieverName,String subject,String content,byte[] attachment,String cC,String attachmentName)
	{
		Session smSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction smTx = null;
		String outStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String d=dateFormat.format(date);
		
		try
		{
		StringTokenizer st=new StringTokenizer(cC,";");
		while(st.hasMoreTokens())
		{	
		smTx=smSession.beginTransaction();
		MDMailsPOJO mdmpojo=new MDMailsPOJO();
		
		int fromUserID1=(Integer) smSession.createSQLQuery("select userid from mdusers where username='"+senderName+"'").uniqueResult();
		
		String recieverName1=st.nextToken();

		int toUserID1=(Integer) smSession.createSQLQuery("select userid from mdusers where username='"+recieverName1+"'").uniqueResult();
		
		if(attachment.length==0)
		{
			mdmpojo.setSubject(subject);
			mdmpojo.setContent(content);
			mdmpojo.setcC(cC);
			mdmpojo.setToUserID(toUserID1);
			mdmpojo.setToUserName(recieverName1);
			mdmpojo.setFromUserID(fromUserID1);
			mdmpojo.setFromUserName(senderName);
			mdmpojo.setSentDateTime(d);
			mdmpojo.setDeleteStatus("notdeleted");
			mdmpojo.setDeletedBy("0");
			mdmpojo.setDeletedDateTime("0000-00-00 00:00:00");
		}
		else
		{
			mdmpojo.setSubject(subject);
			mdmpojo.setContent(content);
			mdmpojo.setAttachment(attachment);
			mdmpojo.setAttachmentName(attachmentName);
			mdmpojo.setcC(cC);
			mdmpojo.setToUserID(toUserID1);
			mdmpojo.setToUserName(recieverName1);
			mdmpojo.setFromUserID(fromUserID1);
			mdmpojo.setFromUserName(senderName);
			mdmpojo.setSentDateTime(d);
			mdmpojo.setDeleteStatus("notdeleted");
			mdmpojo.setDeletedBy("0");
			mdmpojo.setDeletedDateTime("0000-00-00 00:00:00");
			
		}
		smSession.save(mdmpojo);
		smTx.commit();
		}
		outStr="success";
		}
		catch(Exception localException)
		{
			smTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			outStr="fail";
	
		}
		finally
		{
			smSession.close();
		}
	
	
		return outStr;
	}

}
