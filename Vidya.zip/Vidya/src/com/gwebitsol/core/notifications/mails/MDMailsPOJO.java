package com.gwebitsol.core.notifications.mails;

public class MDMailsPOJO 
{
	private int mailID;
	private String subject;
	private String content;
	private byte[] attachment;
	private String attachmentName;
	private String cC;
	private int toUserID;
	private String toUserName;
	private int fromUserID;
	private String fromUserName;
	private String sentDateTime;
	private String deleteStatus;
	private String deletedBy;
	private String deletedDateTime;
	public int getMailID() {
		return mailID;
	}
	public void setMailID(int mailID) {
		this.mailID = mailID;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public byte[] getAttachment() {
		return attachment;
	}
	public void setAttachment(byte[] attachment) {
		this.attachment = attachment;
	}
	public String getAttachmentName() {
		return attachmentName;
	}
	public void setAttachmentName(String attachmentName) {
		this.attachmentName = attachmentName;
	}
	public String getcC() {
		return cC;
	}
	public void setcC(String cC) {
		this.cC = cC;
	}
	public int getToUserID() {
		return toUserID;
	}
	public void setToUserID(int toUserID) {
		this.toUserID = toUserID;
	}
	public String getToUserName() {
		return toUserName;
	}
	public void setToUserName(String toUserName) {
		this.toUserName = toUserName;
	}
	public int getFromUserID() {
		return fromUserID;
	}
	public void setFromUserID(int fromUserID) {
		this.fromUserID = fromUserID;
	}
	public String getFromUserName() {
		return fromUserName;
	}
	public void setFromUserName(String fromUserName) {
		this.fromUserName = fromUserName;
	}
	public String getSentDateTime() {
		return sentDateTime;
	}
	public void setSentDateTime(String sentDateTime) {
		this.sentDateTime = sentDateTime;
	}
	public String getDeleteStatus() {
		return deleteStatus;
	}
	public void setDeleteStatus(String deleteStatus) {
		this.deleteStatus = deleteStatus;
	}
	public String getDeletedBy() {
		return deletedBy;
	}
	public void setDeletedBy(String deletedBy) {
		this.deletedBy = deletedBy;
	}
	public String getDeletedDateTime() {
		return deletedDateTime;
	}
	public void setDeletedDateTime(String deletedDateTime) {
		this.deletedDateTime = deletedDateTime;
	}
	
	
}
