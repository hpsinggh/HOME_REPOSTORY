package com.gwebitsol.core.notifications.mails;

import java.awt.Image;
import java.io.InputStream;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.imageio.ImageIO;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;
import com.gwebitsol.core.util.MailSender;
import com.mysql.jdbc.Blob;

public class MDMailManagementDAO 
{
	@SuppressWarnings("rawtypes")
	public String getInboxItems(String userName,int indexID)
	{
		Session giSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction giTx = null;
		String rtnString=null;
		StringBuffer giSB=new StringBuffer();
		try
		{
			giTx=giSession.beginTransaction();
			
			int userID=(Integer) giSession.createSQLQuery("select userid from mdusers where username='"+userName+"'").uniqueResult();
			
			Query giQuery=giSession.createSQLQuery("select * from mdmails where touserid="+userID+ " and deletedby not like '%"+userID+"%' order by sentdatetime desc limit "+indexID+",8");
			List l=giQuery.list();
			Iterator it=l.iterator();
			
			giSB.append("<MD_Mails>");
			giSB.append("\n");
			while(it.hasNext())
			{
				Object[] o=(Object[])it.next();
				giSB.append("<mailID>");
				giSB.append(o[0]);
				giSB.append("</mailID>");
				giSB.append("\n");
				giSB.append("<subject>");
				giSB.append(o[1]);
				giSB.append("</subject>");
				giSB.append("\n");
				giSB.append("<content>");
				giSB.append(o[2]);
				giSB.append("</content>");
				giSB.append("\n");
				giSB.append("<from>");
				giSB.append(o[9]);
				giSB.append("</from>");
				giSB.append("\n");
				giSB.append("<sentdate>");
				giSB.append(o[10]);
				giSB.append("</sentdate>");
				giSB.append("\n");
				giSB.append("<attachmentName>");
				giSB.append(o[4]);
				giSB.append("</attachmentName>");
				giSB.append("\n");
			}
			giSB.append("</MD_Mails>");
			rtnString=giSB.toString();
			giSB.setLength(0);
			giTx.commit();
			
		}
		catch(Exception localException)
		{
			giSB.setLength(0);
			MDTransactionWriter.exceptionlog.info(localException);
			giTx.rollback();
			rtnString="fail";
		}
		finally
		{
			giSession.close();
			giSB=null;
		}
		return rtnString;
	}
	
	@SuppressWarnings("rawtypes")
	public String getSentItems(String userName,int indexID)
	{
			Session gsSession=MDHibernateUtil.getSessionFactory().openSession();
			Transaction gsTx = null;
			String rtnString=null;
			StringBuffer gsSB=new StringBuffer();
			
			try
			{
				gsTx=gsSession.beginTransaction();
				
				int userID=(Integer) gsSession.createSQLQuery("select userid from mdusers where username='"+userName+"'").uniqueResult();
				
				Query gsQuery=gsSession.createSQLQuery("select * from mdmails where fromuserid="+userID+" and deletedby not like '%"+userID+"%' order by sentdatetime desc limit "+indexID+",8");
				List l=gsQuery.list();

				Iterator it=l.iterator();
				
				gsSB.append("<MD_Mails>");
				gsSB.append("\n");
				while(it.hasNext())
				{
					Object[] o=(Object[])it.next();
					gsSB.append("<mailID>");
					gsSB.append(o[0]);
					gsSB.append("</mailID>");
					gsSB.append("\n");
					gsSB.append("<subject>");
					gsSB.append(o[1]);
					gsSB.append("</subject>");
					gsSB.append("\n");
					gsSB.append("<content>");
					gsSB.append(o[2]);
					gsSB.append("</content>");
					gsSB.append("\n");
					gsSB.append("<To>");
					gsSB.append(o[7]);
					gsSB.append("</To>");
					gsSB.append("\n");
					gsSB.append("<sentdate>");
					gsSB.append(o[10]);
					gsSB.append("</sentdate>");
					gsSB.append("\n");
					gsSB.append("<attachmentName>");
					gsSB.append(o[4]);
					gsSB.append("</attachmentName>");
					gsSB.append("\n");
			
				}
				gsSB.append("</MD_Mails>");
				rtnString=gsSB.toString();
				gsSB.setLength(0);
				gsTx.commit();
				
			}
			catch(Exception localException)
			{
				gsSB.setLength(0);
				MDTransactionWriter.exceptionlog.info(localException);
				gsTx.rollback();
				rtnString="fail";
			}
			finally
			{
				gsSession.close();
				gsSB=null;
			}
			return rtnString;
	}
	
	@SuppressWarnings("static-access")
	public String newMail(String senderName,String recieverName,String subject,String content,byte[] attachment,String cC,String attachmentName)
	{
		Session nmSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction nmTx = null;
		String rtnString=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String d=dateFormat.format(date);
		MDMailsPOJO mdmpojo=new MDMailsPOJO();
		try
		{
			nmTx=nmSession.beginTransaction();
			
			int fromUserID=(Integer) nmSession.createSQLQuery("select userid from mdusers where username='"+senderName+"'").uniqueResult();

			int toUserID=(Integer) nmSession.createSQLQuery("select userid from mdusers where username='"+recieverName+"'").uniqueResult();
			
			if(attachment.length==0)
			{
				mdmpojo.setSubject(subject);
				mdmpojo.setContent(content);
				mdmpojo.setcC(cC);
				mdmpojo.setToUserID(toUserID);
				mdmpojo.setToUserName(recieverName);
				mdmpojo.setFromUserID(fromUserID);
				mdmpojo.setFromUserName(senderName);
				mdmpojo.setSentDateTime(d);
				mdmpojo.setDeleteStatus("notdeleted");
				mdmpojo.setDeletedBy("0");
				mdmpojo.setDeletedDateTime("0000-00-00 00:00:00");
			}
			else
			{
				mdmpojo.setSubject(subject);
				mdmpojo.setContent(content);
				mdmpojo.setAttachment(attachment);
				mdmpojo.setAttachmentName(attachmentName);
				mdmpojo.setcC(cC);
				mdmpojo.setToUserID(toUserID);
				mdmpojo.setToUserName(recieverName);
				mdmpojo.setFromUserID(fromUserID);
				mdmpojo.setFromUserName(senderName);
				mdmpojo.setSentDateTime(d);
				mdmpojo.setDeleteStatus("notdeleted");
				mdmpojo.setDeletedBy("0");
				mdmpojo.setDeletedDateTime("0000-00-00 00:00:00");
				
			}
			
			
			nmSession.save(mdmpojo);
			MailSender ms = new MailSender();
			ms.sendMail(senderName,subject,content,recieverName);
			nmTx.commit();
			
			SendCCMails smobj=new SendCCMails();
			String result=smobj.sendCCMails(senderName, recieverName, subject, content, attachment, cC, attachmentName);
			if(result.equalsIgnoreCase("success"))
			{
			rtnString="new mail composed";
			}
		
		}
		catch(Exception localException)
		{
			MDTransactionWriter.exceptionlog.info(localException);
			nmTx.rollback();
			rtnString="fail";
		}
		finally
		{
			nmSession.close();
		}
		return rtnString;
	}
	

	public String deleteMail(int mailID,int userID,String type)
	{
		Session dmSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction dmTx = null;
		String rtnString=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String d=dateFormat.format(date);
		try
		{
			dmTx=dmSession.beginTransaction();
			if(type.equalsIgnoreCase("trash"))
			{
				
				String detBy=(String)dmSession.createSQLQuery("select deletedby from mdmails where mailid="+mailID).uniqueResult();
				String deletedBy=detBy+";"+userID;

				Query query=dmSession.createSQLQuery("update mdmails set deletestatus='trashdeleted',deletedby='"+deletedBy+"',deleteddatetime='"+d+"' where mailID="+mailID);
				query.executeUpdate();
				
			}
			else
			{
				String detBy=(String)dmSession.createSQLQuery("select deletedby from mdmails where mailid="+mailID).uniqueResult();
				String deletedBy=detBy+";"+userID;
				
				Query query=dmSession.createSQLQuery("update mdmails set deletestatus='deleted',deletedby='"+deletedBy+"',deleteddatetime='"+d+"' where mailID="+mailID);
				query.executeUpdate();
			}
			dmTx.commit();
			rtnString="<serviceStatus>message deleted</serviceStatus>";
		}
		catch(Exception localException)
		{
			MDTransactionWriter.exceptionlog.info(localException);
			dmTx.rollback();
			rtnString="fail";
		}
		finally
		{
			dmSession.close();
		}
		return rtnString;
		
	}

	
	@SuppressWarnings("rawtypes")
	public String getTrashItems(String userName,int indexID)
	{
		Session gtSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gtTx = null;
		String rtnString=null;
		StringBuffer gtSB=new StringBuffer();
		
		try
		{
			gtTx=gtSession.beginTransaction();
			
			int userID=(Integer) gtSession.createSQLQuery("select userid from mdusers where username='"+userName+"'").uniqueResult();
			
			Query query=gtSession.createSQLQuery("select * from mdmails where deletestatus!='trashdeleted' and deletedby like '%"+userID+"%' order by deleteddatetime desc limit "+indexID+",8");
			List gtList=query.list();
			Iterator gtIT=gtList.iterator();
			gtSB.append("<MD_Mails>");
			gtSB.append("\n");
			while(gtIT.hasNext())
			{
				Object[] gtobj=(Object[])gtIT.next();
				gtSB.append("<mailID>"+gtobj[0]+"</mailID>");
				gtSB.append("\n");
				gtSB.append("<subject>"+gtobj[1]+"</subject>");
				gtSB.append("\n");
				gtSB.append("<content>"+gtobj[2]+"</content>");
				gtSB.append("\n");
				gtSB.append("<attachmentName>"+gtobj[4]+"</attachmentName>");
				gtSB.append("\n");
				gtSB.append("<toUserName>"+gtobj[7]+"</toUserName>");
				gtSB.append("\n");
				gtSB.append("<fromUserName>"+gtobj[9]+"</fromUserName>");
				gtSB.append("\n");
				gtSB.append("<sentDateTime>"+gtobj[10]+"</sentDateTime>");
				gtSB.append("\n");
				
			}
			gtSB.append("</MD_Mails>");	
			rtnString=gtSB.toString();
			gtSB.setLength(0);
			gtTx.commit();
			
		}
		catch(Exception localException)
		{
			gtSB.setLength(0);
			MDTransactionWriter.exceptionlog.info(localException);
			gtTx.rollback();
			rtnString="fail";
		}
		finally
		{
			gtSession.close();
			gtSB=null;
		}
		return rtnString;
	}
	
	public String getMailContent(int mailID)
	{
		Session gmSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gmTx = null;
		String rtnString=null;
		try
		{
			gmTx=gmSession.beginTransaction();

			String content=(String) gmSession.createSQLQuery("select content from mdmails where mailid="+mailID).uniqueResult();

			gmTx.commit();
			
			rtnString="<mailContent>"+content+"</mailContent>";
		}
		catch(Exception localException)
		{
			MDTransactionWriter.exceptionlog.info(localException);
			gmTx.rollback();
			rtnString="fail";
		}
		finally
		{
			gmSession.close();
		}
		return rtnString;
	}
	
	 @SuppressWarnings("deprecation")
	public Image getAttachment(int mailID)
		{
			Session gaSession=MDHibernateUtil.getSessionFactory().openSession();
			Transaction gaTx = null;	
			PreparedStatement ps = null;
			ResultSet rs = null;
			Image img=null;
			try
			{
				gaTx=gaSession.beginTransaction();
				String sql="select attachment from mdmails where mailid="+mailID;
				java.sql.Connection connection =gaSession.connection();
				ps = (PreparedStatement) connection.prepareStatement(sql);
				rs = (ResultSet) ps.executeQuery();
				if (rs.next()) 
				{
					Blob bl=(Blob)rs.getBlob("attachment");
					InputStream in=bl.getBinaryStream();
					img = ImageIO.read(in);
				}
				gaTx.commit();
			}
			catch(Exception localException)
			{
				MDTransactionWriter.exceptionlog.info(localException);
			}
			finally
			{
				gaSession.close();
			}
			return img;

		}

}
