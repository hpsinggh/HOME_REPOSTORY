package com.gwebitsol.core.notifications.messages;
/*package com.gwebitsol.core.notifications.messages;

import java.awt.Image;
import java.io.InputStream;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

import javax.imageio.ImageIO;

import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;
import com.mysql.jdbc.Blob;

public class MDMessageManagementDAO 
{

	@SuppressWarnings("rawtypes")
	public String getInbox(String userName,int indexID)
	{
		Session giSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction giTx = null;
		String rtnString=null;
		StringBuffer giSB=new StringBuffer();
		try
		{
			giTx=giSession.beginTransaction();
			String giSql="select userid from mdusers where username='"+userName+"'";
			int userID=(Integer) giSession.createSQLQuery(giSql).uniqueResult();
			
			String giSql1="select * from mdmessages where touserid="+userID+ " order by sentdatetime desc limit "+indexID+",8";
			System.out.println(giSql1);
			Query giQuery=giSession.createSQLQuery(giSql1);
			List l=giQuery.list();

			Iterator it=l.iterator();
			
			giSB.append("<MD_Messages>");
			giSB.append("\n");
			while(it.hasNext())
			{
				Object[] o=(Object[])it.next();
				giSB.append("<SNO>");
				giSB.append(o[0]);
				giSB.append("</SNO>");
				giSB.append("\n");
				giSB.append("<messageid>");
				giSB.append(o[1]);
				giSB.append("</messageid>");
				giSB.append("\n");
				giSB.append("<subject>");
				giSB.append(o[2]);
				giSB.append("</subject>");
				giSB.append("\n");
				giSB.append("<from>");
				giSB.append(o[6]);
				giSB.append("</from>");
				giSB.append("\n");
				giSB.append("<status>");
				giSB.append(o[7]);
				giSB.append("</status>");
				giSB.append("\n");
				giSB.append("<sentdate>");
				giSB.append(o[8]);
				giSB.append("</sentdate>");
				giSB.append("\n");
				giSB.append("<attachmentName>");
				giSB.append(o[9]);
				giSB.append("</attachmentName>");
				giSB.append("\n");
			}
			giSB.append("</MD_Messages>");
			rtnString=giSB.toString();
			giSB.setLength(0);
			giTx.commit();
			
		}
		catch(Exception localException)
		{
			giSB.setLength(0);
			MDTransactionWriter.exceptionlog.info(localException);
			giTx.rollback();
			rtnString="fail";
		}
		finally
		{
			giSession.close();
			giSB=null;
		}
		return rtnString;
	}
	
	@SuppressWarnings("rawtypes")
	public String getSentItems(String userName,int indexID)
	{
			Session gsSession=MDHibernateUtil.getSessionFactory().openSession();
			Transaction gsTx = null;
			String rtnString=null;
			StringBuffer gsSB=new StringBuffer();
			
			try
			{
				gsTx=gsSession.beginTransaction();
				String mSql="select userid from mdusers where username='"+userName+"'";
				int userID=(Integer) gsSession.createSQLQuery(mSql).uniqueResult();
				
				String gsSql1="select * from mdmessages where fromuserid="+userID+" order by sentdatetime desc limit "+indexID+",8";
				Query gsQuery=gsSession.createSQLQuery(gsSql1);
				List l=gsQuery.list();

				Iterator it=l.iterator();
				
				gsSB.append("<MD_Messages>");
				gsSB.append("\n");
				while(it.hasNext())
				{
					Object[] o=(Object[])it.next();
					gsSB.append("<SNO>");
					gsSB.append(o[0]);
					gsSB.append("</SNO>");
					gsSB.append("\n");
					gsSB.append("<messageid>");
					gsSB.append(o[1]);
					gsSB.append("</messageid>");
					gsSB.append("\n");
					gsSB.append("<subject>");
					gsSB.append(o[2]);
					gsSB.append("</subject>");
					gsSB.append("\n");
					gsSB.append("<To>");
					gsSB.append(o[4]);
					gsSB.append("</To>");
					gsSB.append("\n");
					gsSB.append("<sentdate>");
					gsSB.append(o[8]);
					gsSB.append("</sentdate>");
					gsSB.append("\n");
					gsSB.append("<attachmentName>");
					gsSB.append(o[9]);
					gsSB.append("</attachmentName>");
					gsSB.append("\n");
			
				}
				gsSB.append("</MD_Messages>");
				rtnString=gsSB.toString();
				gsSB.setLength(0);
				gsTx.commit();
				
			}
			catch(Exception localException)
			{
				gsSB.setLength(0);
				MDTransactionWriter.exceptionlog.info(localException);
				gsTx.rollback();
				rtnString="fail";
			}
			finally
			{
				gsSession.close();
				gsSB=null;
			}
			return rtnString;
	}
	
	@SuppressWarnings({ "deprecation", "rawtypes" })
	public String getTrash(String userName,int indexID)
	{
		Session gtSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gtTx = null;
		String rtnString=null;
		StringBuffer gtSB=new StringBuffer();
		
		try
		{
			gtTx=gtSession.beginTransaction();
			String gtSql="select * from mdmessagetrash where tousername='"+userName+"' or fromusername='"+userName+"' order by deletedatetime desc limit "+indexID+",8";
			Query gtQuery=gtSession.createSQLQuery(gtSql).addScalar("indexid",Hibernate.INTEGER).addScalar("sno",Hibernate.INTEGER).addScalar("messageid",Hibernate.INTEGER)
					.addScalar("subject",Hibernate.STRING).addScalar("touserid",Hibernate.INTEGER).addScalar("tousername",Hibernate.STRING).addScalar("fromuserid",Hibernate.INTEGER)
					.addScalar("fromusername",Hibernate.STRING).addScalar("sentdatetime",Hibernate.STRING).addScalar("attachmentname",Hibernate.STRING).addScalar("content",Hibernate.STRING).addScalar("deletedatetime",Hibernate.STRING);
			List gtList=gtQuery.list();
			Iterator gtIT=gtList.iterator();
			gtSB.append("<MD_Messages>");
			gtSB.append("\n");
			while(gtIT.hasNext())
			{
				Object[] gtObj=(Object[])gtIT.next();
				gtSB.append("<Trash_Item>");
				gtSB.append("\n");
				gtSB.append("<sno>"+gtObj[1]+"</sno>");
				gtSB.append("\n");
				gtSB.append("<messageid>"+gtObj[2]+"</messageid>");
				gtSB.append("\n");
				gtSB.append("<subject>"+gtObj[3]+"</subject>");
				gtSB.append("\n");
				gtSB.append("<touserid>"+gtObj[4]+"</touserid>");
				gtSB.append("\n");
				gtSB.append("<tousername>"+gtObj[5]+"</tousername>");
				gtSB.append("\n");
				gtSB.append("<fromuserid>"+gtObj[6]+"</fromuserid>");
				gtSB.append("\n");
				gtSB.append("<fromusername>"+gtObj[7]+"</fromusername>");
				gtSB.append("\n");
				gtSB.append("<sentdatetime>"+gtObj[8]+"</sentdatetime>");
				gtSB.append("\n");
				gtSB.append("<attachmentname>"+gtObj[9]+"</attachmentname>");
				gtSB.append("\n");
				gtSB.append("<content>"+gtObj[10]+"</content>");
				gtSB.append("\n");
				gtSB.append("<deletedatetime>"+gtObj[11]+"</deletedatetime>");
				gtSB.append("\n");
				gtSB.append("</Trash_Item>");
				gtSB.append("\n");
			}
			gtSB.append("</MD_Messages>");
			rtnString=gtSB.toString();
			gtSB.setLength(0);
			gtTx.commit();
			
		}
		catch(Exception localException)
		{
			gtSB.setLength(0);
			MDTransactionWriter.exceptionlog.info(localException);
			gtTx.rollback();
			rtnString="fail";
		}
		finally
		{
			gtSession.close();
			gtSB=null;
		}
		return rtnString;
	}
	
	public String newMail(String senderName,String recieverName,String subject,String content,byte[] attachment,String cC,String attachmentName)
	{
		Session nmSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction nmTx = null;
		String rtnString=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String d=dateFormat.format(date);
		MDMessageContentPOJO adObj=new MDMessageContentPOJO();
		try
		{
			nmTx=nmSession.beginTransaction();
			if(attachment.length==0)
			{
				adObj.setSubject(subject);
				adObj.setContent(content);
				adObj.setcC(cC);
				nmSession.save(adObj);
			}
			else
			{
			adObj.setSubject(subject);
			adObj.setContent(content);
			adObj.setAttachment(attachment);
			adObj.setcC(cC);
			nmSession.save(adObj);
			}
			int messageID=adObj.getMessageID();
			String nmSql="select userid from mdusers where username='"+senderName+"'";
			int fromUserID=(Integer) nmSession.createSQLQuery(nmSql).uniqueResult();
			
			String nmSql1="select userid from mdusers where username='"+recieverName+"'";
			int toUserID=(Integer) nmSession.createSQLQuery(nmSql1).uniqueResult();
			
			String nmSql2="insert into MDMessages(messageid,subject,touserid,tousername,fromuserid,fromusername,status,sentdatetime,attachmentName) values" +
					"("+messageID+",'"+subject+"',"+toUserID+",'"+recieverName+"',"+fromUserID+",'"+senderName+"','unread','"+d+"','"+attachmentName+"')";
			Query nmQuery=nmSession.createSQLQuery(nmSql2);
			nmQuery.executeUpdate();
			StringTokenizer st=new StringTokenizer(cC,";");
			while(st.hasMoreTokens())
			{
				String nmSql3="select userid from mdusers where username='"+senderName+"'";
				int fromUserID1=(Integer) nmSession.createSQLQuery(nmSql3).uniqueResult();
				String recieverName1=st.nextToken();
				
				String nmSql4="select userid from mdusers where username='"+recieverName1+"'";
				int toUserID1=(Integer) nmSession.createSQLQuery(nmSql4).uniqueResult();
				
				String nmSql5="insert into MDMessages(messageid,subject,touserid,tousername,fromuserid,fromusername,status,sentdatetime,attachmentName) values" +
						"("+messageID+",'"+subject+"',"+toUserID1+",'"+recieverName1+"',"+fromUserID1+",'"+senderName+"','unread','"+d+"','"+attachmentName+"')";
				Query nmQuery1=nmSession.createSQLQuery(nmSql5);
				nmQuery1.executeUpdate();	
			}
			
			nmTx.commit();
			rtnString="new mail composed";
		
		}
		catch(Exception localException)
		{
			MDTransactionWriter.exceptionlog.info(localException);
			nmTx.rollback();
			rtnString="fail";
		}
		finally
		{
			nmSession.close();
		}
		return rtnString;
	}
	
	@SuppressWarnings({ "deprecation", "rawtypes" })
	public String deleteMessage(int sno)
	{
		Session dmSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction dmTx = null;
		String rtnString=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String d=dateFormat.format(date);
		
		try
		{
			dmTx=dmSession.beginTransaction();
			String dmSql="select * from mdmessages where sno="+sno;
			Query dmQuery=dmSession.createSQLQuery(dmSql).addScalar("sno",Hibernate.INTEGER).addScalar("messageid",Hibernate.INTEGER).addScalar("subject",Hibernate.STRING).addScalar("touserid",Hibernate.INTEGER)
					.addScalar("tousername",Hibernate.STRING).addScalar("fromuserid",Hibernate.INTEGER).addScalar("fromusername",Hibernate.STRING).addScalar("status",Hibernate.STRING).addScalar("sentdatetime",Hibernate.STRING).addScalar("attachmentname",Hibernate.STRING);
			List dmList=dmQuery.list();
			Iterator dmIT=dmList.iterator();
			while(dmIT.hasNext())
			{
				Object[] dmObj=(Object[])dmIT.next();
				int messageid=(Integer)dmObj[1];
				String dmSql3="select content from mdmessagecontent where messageid="+messageid;
				String content=(String)dmSession.createSQLQuery(dmSql3).uniqueResult();
				String dmSql1="insert into mdmessagetrash(sno,messageid,subject,touserid,tousername,fromuserid,fromusername,sentdatetime,attachmentname,content,deletedatetime) " +
						"values("+dmObj[0]+","+dmObj[1]+",'"+dmObj[2]+"',"+dmObj[3]+",'"+dmObj[4]+"',"+dmObj[5]+",'"+dmObj[6]+"','"+dmObj[8]+"','"+dmObj[9]+"','"+content+"','"+d+"')";
				Query dmQuery1=dmSession.createSQLQuery(dmSql1);
				dmQuery1.executeUpdate();
				
			}
			
			String dmSql2="delete from mdmessages where sno="+sno;
			Query dmQuery2=dmSession.createSQLQuery(dmSql2);
			dmQuery2.executeUpdate();	
			dmTx.commit();
			rtnString="<serviceStatus>message deleted</serviceStatus>";
		}
		catch(Exception localException)
		{
			MDTransactionWriter.exceptionlog.info(localException);
			dmTx.rollback();
			rtnString="fail";
		}
		finally
		{
			dmSession.close();
		}
		return rtnString;
		
	}

	public String getMessageContent(int messageID)
	{
		Session gmSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gmTx = null;
		String rtnString=null;
		try
		{
			gmTx=gmSession.beginTransaction();
			String gmSql="select content from mdmessagecontent where messageid="+messageID;
			String content=(String) gmSession.createSQLQuery(gmSql).uniqueResult();
			String gmSql1="update mdmessages set status='read' where messageid="+messageID;
			Query gmQuery=gmSession.createSQLQuery(gmSql1);
			gmQuery.executeUpdate();
			System.out.println(content);
			gmTx.commit();
			rtnString="<messagecontent>"+content+"</messagecontent>";
		}
		catch(Exception localException)
		{
			MDTransactionWriter.exceptionlog.info(localException);
			gmTx.rollback();
			rtnString="fail";
		}
		finally
		{
			gmSession.close();
		}
		return rtnString;
	}
	
	 @SuppressWarnings("deprecation")
	public Image getAttachment(int messageID)
		{
			Session gaSession=MDHibernateUtil.getSessionFactory().openSession();
			Transaction gaTx = null;	
			PreparedStatement ps = null;
			ResultSet rs = null;
			Image img=null;
			try
			{
				gaTx=gaSession.beginTransaction();
				String sql="select attachment from mdmessagecontent where messageid="+messageID;
				java.sql.Connection connection =gaSession.connection();
				ps = (PreparedStatement) connection.prepareStatement(sql);
				rs = (ResultSet) ps.executeQuery();
				if (rs.next()) 
				{
					Blob bl=(Blob)rs.getBlob("attachment");
					InputStream in=bl.getBinaryStream();
					img = ImageIO.read(in);
				}
				gaTx.commit();
			}
			catch(Exception localException)
			{
				MDTransactionWriter.exceptionlog.info(localException);
			}
			finally
			{
				gaSession.close();
			}
			return img;

		}
}
*/