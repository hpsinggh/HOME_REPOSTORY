package com.gwebitsol.core.notifications.messages;
/*package com.gwebitsol.core.notifications.messages;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

@Path("/messageService/")
public interface MDMessageManagementServiceIntf 
{
	@GET
	@Produces({"application/xml", "application/json"})
	@Path("/getInbox")
	public Response getInboxMessages(@QueryParam("userName") String userName,@QueryParam("indexID") int indexID,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@GET
	@Produces({"application/xml", "application/json"})
	@Path("/getSentItems")
	public Response getSentItemsMessages(@QueryParam("userName") String userName,@QueryParam("indexID") int indexID,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@GET
	@Produces({"application/xml", "application/json"})
	@Path("/getTrash")
	public Response getTrashItems(@QueryParam("userName") String userName,@QueryParam("indexID") int indexID,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	*/
	//@POST
	//@Produces({"application/xml", "application/json"})
	//@Consumes({"*/*"})
	//@Path("/newMail")
	//public Response newMailMessage(MDMessageContent mdMsg,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	/*@POST
	@Produces({"application/xml", "application/json"})
	@Consumes({"application/xml", "application/json"})
	@Path("/deleteMessage")
	public Response deleteMessage(@QueryParam("sNO") int sNO,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@POST
	@Produces({"application/xml", "application/json"})
	@Path("/getMessageContent")
	public Response getMailMessageContent(@QueryParam("messageID") int messageID,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@Path("/getattachment")
	@Produces("image/*")
	@GET
	public Response getattachment(@QueryParam("messageID") int messageID,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	
	}
	*/
	
	


