package com.gwebitsol.core.notifications.messages;
/*package com.gwebitsol.core.notifications.messages;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.gwebitsol.core.security.MDVerifyConnectionID;
import com.gwebitsol.core.security.MDVerifyDatastoreName;
import com.gwebitsol.core.usermanagement.MDGetUserFromID;
import com.gwebitsol.core.util.MDTransactionWriter;

public class MDMessageManagementService implements MDMessageManagementServiceIntf
{
	@Context private HttpServletRequest hsr;
	public Response getInboxMessages(String userName,int indexID,int userID,int connectionID,String datastoreName) 
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());		
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{

					MDMessageManagementDAO mdMsgDAO=new MDMessageManagementDAO();				
					XMLString=mdMsgDAO.getInbox(userName,indexID);
					if(XMLString.equals("fail"))
						statusStr="failed";
					else
						statusStr="success";
					String endDate=dateFormat.format(new Date());
					Long el=System.currentTimeMillis();
					MDTransactionWriter.writeLog(datastoreName,"MsgMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}
		}
		catch(Exception localException)
		{
			MDTransactionWriter.exceptionlog.info(localException);
			XMLString="failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
		
	}


	public Response getSentItemsMessages(String userName,int indexID,int userID,int connectionID,String datastoreName) 
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());		
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
				MDMessageManagementDAO mdMsgDAO=new MDMessageManagementDAO();
				XMLString=mdMsgDAO.getSentItems(userName,indexID);
				if(XMLString.equals("fail"))
					statusStr="failed";
				else
					statusStr="success";
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				MDTransactionWriter.writeLog(datastoreName,"MsgMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}
	}
		catch(Exception localException)
		{
			MDTransactionWriter.exceptionlog.info(localException);
			XMLString="failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
		
	}


	public Response getTrashItems(String userName,int indexID,int userID,int connectionID,String datastoreName) 
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());		
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
			MDMessageManagementDAO mdMsgDAO=new MDMessageManagementDAO();				
			XMLString=mdMsgDAO.getTrash(userName,indexID);
			if(XMLString.equals("fail"))
				statusStr="failed";
			else
				statusStr="success";
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			MDTransactionWriter.writeLog(datastoreName,"MsgMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}
		}
		catch(Exception localException)
		{
			MDTransactionWriter.exceptionlog.info(localException);
			XMLString="failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
		
	}

	
	public Response newMailMessage(MDMessageContent mdMsg,int userID,int connectionID,String datastoreName) 
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String senderName=null;
		String recieverName=null;
		String subject=null;
		String content=null;
		byte[] attachment=null;
		String cC=null;
		String attachmentName=null;		
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
					MDMessageManagementDAO mdMsgDAO=new MDMessageManagementDAO();
					senderName=mdMsg.getSenderName();
					recieverName=mdMsg.getRecieverName();
					subject=mdMsg.getSubject();
					content=mdMsg.getContent();
					attachment=mdMsg.getAttachment();
					attachmentName=mdMsg.getAttachmentName();
					cC=mdMsg.getcC();
					XMLString=mdMsgDAO.newMail(senderName,recieverName,subject,content,attachment,cC,attachmentName);
					if(XMLString.equals("fail"))
						statusStr="failed";
					else
						statusStr="success";
					String endDate=dateFormat.format(new Date());
					Long el=System.currentTimeMillis();
					MDTransactionWriter.writeLog(datastoreName,"MsgMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}
		}
		
		catch(Exception localException)
		{
			MDTransactionWriter.exceptionlog.info(localException);
			XMLString="failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}

	public Response deleteMessage(int sNO,int userID,int connectionID,String datastoreName) 
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
			
					MDMessageManagementDAO mdMsgDAO=new MDMessageManagementDAO();				
					XMLString=mdMsgDAO.deleteMessage(sNO);
					if(XMLString.equals("fail"))
						statusStr="failed";
					else
						statusStr="success";
					String endDate=dateFormat.format(new Date());
					Long el=System.currentTimeMillis();
					MDTransactionWriter.writeLog(datastoreName,"MsgMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}
		}
		catch(Exception localException)
		{
			MDTransactionWriter.exceptionlog.info(localException);
			XMLString="failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}

	public Response getMailMessageContent(int messageID,int userID,int connectionID,String datastoreName) 
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
					MDMessageManagementDAO mdMsgDAO=new MDMessageManagementDAO();				
					XMLString=mdMsgDAO.getMessageContent(messageID);
					if(XMLString.equals("fail"))
						statusStr="failed";
					else
						statusStr="success";
					String endDate=dateFormat.format(new Date());
					Long el=System.currentTimeMillis();
					MDTransactionWriter.writeLog(datastoreName,"MsgMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}
		}
		catch(Exception localException)
		{
			
			MDTransactionWriter.exceptionlog.info(localException);
			XMLString="failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
		
	}


	public Response getattachment(int messageID,int userID,int connectionID,String datastoreName) 
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		InputStream bigInputStream=null;
		String statusStr=null;
		
		final ByteArrayOutputStream out = new ByteArrayOutputStream();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
			MDMessageManagementDAO mdMsgDAO=new MDMessageManagementDAO();	
			Image image=mdMsgDAO.getAttachment(messageID);
			if(image.equals(null))
				statusStr="fail";
			else
				statusStr="success";
			ImageIO.write((BufferedImage) image, "jpg", out);
			final byte[] imgData = out.toByteArray();
			bigInputStream = new ByteArrayInputStream(imgData);
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			MDTransactionWriter.writeLog(datastoreName,"MsgMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			
			return Response.ok(bigInputStream).build();
		}
		catch (final IOException e)
		{
			return Response.noContent().build();
		}	
	}
	

}
*/