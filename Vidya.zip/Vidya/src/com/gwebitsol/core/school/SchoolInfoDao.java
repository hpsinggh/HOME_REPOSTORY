package com.gwebitsol.core.school;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class SchoolInfoDao {
	

	public String addSchoolInfo(SchoolInfoPojo sip) {
		Session addempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction addempTx=null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			addempTx=addempSession.beginTransaction();
			Integer in=(Integer)addempSession.save(sip);
			System.out.println(in);
		
			addempTx.commit();
			
			sb.append("<SchoolInfo>");
			sb.append("\n");
			sb.append("<Schoolid>");
			sb.append(in);
			sb.append("</Schoolid>");
			sb.append("</SchoolInfo>");
			outStr=sb.toString();
			
		   
   		 	}
		
		catch(Exception localException)
		{
			System.out.println(localException);
			
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    
			    sb.append("could not inserted schoolinfo info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			     outStr= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (addempTx!=null)
				  addempTx.rollback();
		}
		finally
		{			
			addempSession.close();
		}
		return outStr;
	}

	public String updateSchoolInfo(SchoolInfoPojo sip) {
		Session upempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction upempTx=null;
		StringBuffer sb=new StringBuffer();
		
		String outStr=null;
		try
		{
			upempTx=upempSession.beginTransaction();
	        upempSession.update(sip);
			
			
			upempTx.commit();
			
		
			sb.append("<SchoolInfo>");
			sb.append("\n");
			sb.append("update sucessfully");
			sb.append("</SchoolInfo>");
			String str=sb.toString();
			return str;
		   
   		 	}
		
		catch(Exception localException)
		{
			System.out.println(localException);
			
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    
			    sb.append("could not update schoolinfo info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			     outStr= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (upempTx!=null)
				  upempTx.rollback();
		}
		finally
		{			
			upempSession.close();
		}
		return outStr;
	}

	public String deleteSchoolInfoPojo(int schoolId) {
		Session delempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction delempTx=null;
		StringBuffer sb=new StringBuffer();
		
		String outStr=null;
		try
		{
			delempTx=delempSession.beginTransaction();
			Query empQuery=delempSession.createSQLQuery("update gbl_sm_tbl_school_info set IsDeleted ='Y' where SchoolId='"+schoolId+"'");
			empQuery.executeUpdate();
			/*SchoolInfoPojo f= new SchoolInfoPojo();
			f.setSchoolId(schoolId);
	        delempSession.delete(f);*/
			
			
			delempTx.commit();
			
		
			sb.append("<School>");
			sb.append("\n");
			sb.append("deleted sucessfully");
			sb.append("</School>");
			String str=sb.toString();
			return str;
		   
   		 	}
		
		catch(Exception localException)
		{
			System.out.println(localException);
			
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    
			    sb.append("could not delete schoolinfo info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			     outStr= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (delempTx!=null)
				  delempTx.rollback();
		}
		finally
		{			
			delempSession.close();
		}
		return outStr;
	}

	public String getByIdSchoolInfoId(int schoolId) {
		Session gtempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gtTx=null;
			StringBuffer sb= new StringBuffer();
			System.out.println("hi dao impl success");
			String strg= null;
				try {
					gtTx = gtempSession.beginTransaction();
				List list=gtempSession.createSQLQuery("Select si.SchoolId,si.SchoolName,si.EstablishedOn,si.MobileNo,si.Email,si.Web,si.ContactPerson,si.Location,si.Photo,si.LandLine,si.Fax,si.Description,si.Remarks,si.CreatedDate,si.ModifiedDate from gbl_sm_tbl_school_info as si where si.IsDeleted <> 'Y' or si.IsDeleted IS NULL and SchoolId ='" + schoolId + "';").list();
			     Iterator it=list.iterator();
			    		    sb.append("<School>");
					        sb.append("\n");
					        while(it.hasNext())
					        {
					        	Object[] ex=(Object[])it.next();
						    	sb.append("<SchoolInfo>");
								sb.append("\n");
						        sb.append("<schoolId>");
							    sb.append(ex[0]);
							    sb.append("</schoolId>");
							    sb.append("\n");
							    sb.append("<schoolName>");
							    sb.append(ex[1]);
							    sb.append("</schoolName>");
							    sb.append("\n");
							    sb.append("<establishedOn>");
								sb.append(ex[2]);
								sb.append("</establishedOn>");
								 sb.append("\n");
								sb.append("<mobileNo>");
								sb.append(ex[3]);
								sb.append("</mobileNo>");
								 sb.append("\n");
								sb.append("<email>");
								sb.append(ex[4]);
								sb.append("</email>");
								sb.append("\n");
								sb.append("<web>");
								sb.append(ex[5]);
								sb.append("</web>");
								sb.append("\n");
								sb.append("<contactPerson>");
								sb.append(ex[6]);
								sb.append("</contactPerson>");
								sb.append("<location>");
							    sb.append(ex[7]);
							    sb.append("</location>");
							    sb.append("\n");
							    sb.append("<photo>");
							    sb.append(ex[8]);
							    sb.append("</photo>");
							    sb.append("\n");
							    sb.append("<landLine>");
								sb.append(ex[9]);
								sb.append("</landLine>");
								 sb.append("\n");
								sb.append("<fax>");
								sb.append(ex[10]);
								sb.append("</fax>");
								 sb.append("\n");
								sb.append("<description>");
								sb.append(ex[11]);
								sb.append("</description>");
								sb.append("\n");
								sb.append("<remarks>");
								sb.append(ex[12]);
								sb.append("</remarks>");
								sb.append("\n");
								sb.append("<createddate>");
								sb.append(ex[13]);
								sb.append("</createddate>");
								sb.append("\n");
								sb.append("<modifieddate>");
								sb.append(ex[14]);
								sb.append("</modifieddate>");
								sb.append("\n");
								sb.append("</SchoolInfo>");
					        }
							sb.append("</School>");
						    strg= sb.toString();
						
				
						
				} 	catch (Exception localException) {
					System.out.println(localException);
					
					   sb.append("<Response>");
					    sb.append("\n");
					    sb.append("<Result>");
					    sb.append("\n");
					    sb.append("Fail");
					    sb.append("\n");
					    sb.append("</Result>");
					    sb.append("\n");
					    sb.append("<Description>");
					    
					    sb.append("could not getbyid schoolinfo info");
					    sb.append("</Description>");
					    sb.append("\n");
					    sb.append("<Exception>");
					    sb.append(localException);
					    sb.append("</Exception>");
					    sb.append("</Response>");
					    sb.append("</schoolId>");
					    sb.append("</SchoolInfo>");
					    strg= sb.toString();
					   MDTransactionWriter.exceptionlog.info(localException);
					  if (gtTx!=null)
						  gtTx.rollback();
					} finally {
						gtempSession.close();
					}
			return strg;
	}

	public String getAllSchoolInfo(int PNO, int size) {
		Session rdSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb= new StringBuffer();
		String string=null;
	   // SchoolInfoPojo ex=null;
		
		try
		{
			tx = rdSession.beginTransaction();
			
			 if(("all") != null)
			   {
			    int fset = (PNO-1)*size;
			    String gsSql ="select count(*) from gbl_sm_tbl_school_info";
			    Query gsQuery=rdSession.createSQLQuery(gsSql);
			    Object noRecords= gsQuery.uniqueResult();
			    sb.append("<SchoolInfos>");
			    sb.append("\n");
			    sb.append("<noRecords>"+noRecords+"</noRecords>");
			    sb.append("\n");
			    
			     if (PNO > 0 & size > 0){
			     gsSql="Select si.SchoolId,si.SchoolName,si.EstablishedOn,si.MobileNo,si.Email,si.Web,si.ContactPerson,si.Location,si.Photo,si.LandLine,si.Fax,si.Description,si.Remarks,si.CreatedDate,si.ModifiedDate from gbl_sm_tbl_school_info as si where si.IsDeleted <> 'Y' or si.IsDeleted IS NULL limit "+size+" offset "+fset;}
			     else {
			      gsSql="Select si.SchoolId,si.SchoolName,si.EstablishedOn,si.MobileNo,si.Email,si.Web,si.ContactPerson,si.Location,si.Photo,si.LandLine,si.Fax,si.Description,si.Remarks,si.CreatedDate,si.ModifiedDate from gbl_sm_tbl_school_info as si where si.IsDeleted <> 'Y' or si.IsDeleted IS NULL";
			     } 
			   
			    gsQuery=rdSession.createSQLQuery(gsSql);
			    List gcList=gsQuery.list();
			    Iterator gsIT=gcList.iterator();
			    while(gsIT.hasNext())
			     {
			    	Object[] ex=(Object[])gsIT.next();
			    	sb.append("<SchoolInfo>");
					sb.append("\n");
			        sb.append("<schoolId>");
				    sb.append(ex[0]);
				    sb.append("</schoolId>");
				    sb.append("\n");
				    sb.append("<schoolName>");
				    sb.append(ex[1]);
				    sb.append("</schoolName>");
				    sb.append("\n");
				    sb.append("<establishedOn>");
					sb.append(ex[2]);
					sb.append("</establishedOn>");
					 sb.append("\n");
					sb.append("<mobileNo>");
					sb.append(ex[3]);
					sb.append("</mobileNo>");
					 sb.append("\n");
					sb.append("<email>");
					sb.append(ex[4]);
					sb.append("</email>");
					sb.append("\n");
					sb.append("<web>");
					sb.append(ex[5]);
					sb.append("</web>");
					sb.append("\n");
					sb.append("<contactPerson>");
					sb.append(ex[6]);
					sb.append("</contactPerson>");
					sb.append("<location>");
				    sb.append(ex[7]);
				    sb.append("</location>");
				    sb.append("\n");
				    sb.append("<photo>");
				    sb.append(ex[8]);
				    sb.append("</photo>");
				    sb.append("\n");
				    sb.append("<landLine>");
					sb.append(ex[9]);
					sb.append("</landLine>");
					 sb.append("\n");
					sb.append("<fax>");
					sb.append(ex[10]);
					sb.append("</fax>");
					 sb.append("\n");
					sb.append("<description>");
					sb.append(ex[11]);
					sb.append("</description>");
					sb.append("\n");
					sb.append("<remarks>");
					sb.append(ex[12]);
					sb.append("</remarks>");
					sb.append("\n");
					sb.append("<createddate>");
					sb.append(ex[13]);
					sb.append("</createddate>");
					sb.append("\n");
					sb.append("<modifieddate>");
					sb.append(ex[14]);
					sb.append("</modifieddate>");
					sb.append("\n");
					sb.append("</SchoolInfo>");
			}
		}
			sb.append("</SchoolInfos>");
					    String str= sb.toString();
						 tx.commit();
					return str;
			
		
		}
		catch(Exception localException)
		{
			System.out.println(localException);
			
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    
			    sb.append("could not getall schoolinfo info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    string= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (tx!=null)
				  tx.rollback();
		}
		finally
		{
			rdSession.close();
		
		}
		return string;
	}
	}






