package com.gwebitsol.core.school;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.stereotype.Service;

import com.gwebitsol.core.grading.ScaleDao;
import com.gwebitsol.core.security.MDVerifyConnectionID;
import com.gwebitsol.core.security.MDVerifyDatastoreName;
import com.gwebitsol.core.usermanagement.MDGetUserFromID;
import com.gwebitsol.core.util.MDTransactionWriter;

@Service
public class SchoolInfoService implements SchoolInfoIntf {
	@Context 
	private HttpServletRequest hsr;
	public Response addSchoolInfo(SchoolInfoPojo sip, int userID, int connectionID,String datastoreName) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String XMLString=null;
	    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				SchoolInfoDao sipDAO=new SchoolInfoDao();
				XMLString=sipDAO.addSchoolInfo(sip);
				System.out.println(XMLString);
				MDTransactionWriter.writeLog(datastoreName,"addSchoolInfo",requester,startDate,endDate,sl,el,XMLString,hsr.getRemoteHost());
		}
			else
			{
				XMLString="you are not authorised user";
			}
			
		}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
		   XMLString="failed in service layer";
		}
	
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}

	public Response updateSchoolInfo(SchoolInfoPojo sip, int userID, int connectionID,String datastoreName) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String XMLString=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			SchoolInfoDao flDAO=new SchoolInfoDao();
			XMLString=flDAO.updateSchoolInfo(sip);
			System.out.println(XMLString);
			MDTransactionWriter.writeLog(datastoreName,"updateSchoolInfo",requester,startDate,endDate,sl,el,XMLString,hsr.getRemoteHost());
	}
			else
			{
				XMLString="you are not authorised user";
			}
			
		}
	catch(Exception localException)
	{
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
	   XMLString="failed in service layer";
	}

	return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}

	public Response deleteSchoolInfo(int schoolId, int userID, int connectionID,String datastoreName) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		String XMLString=null;
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		
		try
	{	
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
		SchoolInfoDao ex=new SchoolInfoDao();
		status=ex.deleteSchoolInfoPojo(schoolId);
		
		String endDate=dateFormat.format(new Date());	
		Long el=System.currentTimeMillis();
		//status="user validation successfull";
			MDTransactionWriter.writeLog(datastoreName,"deleteSchoolInfo",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
	}
			else
			{
				XMLString="you are not authorised user";
			}
			
		}
	catch(Exception localException)
	{
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
		status="failed in service layer";
	}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response getBySchoolInfoId(int schoolId, int userID, int connectionID,String datastoreName) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		String XMLString=null;
		String status1=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		
		
		try
	{	
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
			SchoolInfoDao ex=new SchoolInfoDao();
			 status1=ex.getByIdSchoolInfoId(schoolId);
			 System.out.println(status1);
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			//status1="user validation successfull";
			MDTransactionWriter.writeLog(datastoreName,"getBySchoolInfoId",requester,startDate,endDate,sl,el,status1,hsr.getRemoteHost());		
	}
			else
			{
				XMLString="you are not authorised user";
			}
			
		}
	catch(Exception localException)
	{
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
		status1="failed in service layer";
		//System.out.println(localException);
	}
 return Response.ok().type(MediaType.APPLICATION_XML).entity(status1).build();
	}

	public Response getAllSchoolInfo( int userID, int connectionID,String datastoreName,int PNO, int size) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		
		String XMLString=null;
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try{
			
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
			SchoolInfoDao ex=new SchoolInfoDao();
			status=ex.getAllSchoolInfo(PNO,size);
			System.out.println(status);
			String endDate=dateFormat.format(new Date());
			  Long el=System.currentTimeMillis();
			 MDTransactionWriter.writeLog(datastoreName,"getAllSchoolInfo",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		

		}else
		{
			XMLString="you are not authorised user";
		}
		
	}
			catch(Exception localException)
		   {
			  MDTransactionWriter.errorlog.debug(localException);
			  MDTransactionWriter.errorlog.info(localException);
			  status="failed in service layer";
		   }
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}
}
	

