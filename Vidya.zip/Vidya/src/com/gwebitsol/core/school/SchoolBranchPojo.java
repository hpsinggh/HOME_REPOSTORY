package com.gwebitsol.core.school;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="SchoolBranch")
public class SchoolBranchPojo {
	private int schoolBranchId;
	private String branchName;
	private int schoolId;
	private String description;
	private int priority;
	private String status;
	private byte[] image;
	private String establishedOn;
	private String landLine;
	private String mobileNo;
	private String fax;
	private String email;
	private String web;
	private String remarks;
	private String contactPerson;
	private String location;
	
	public int getPriority() {
		return priority;
	}
	public void setPriority(int priority) {
		this.priority = priority;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getSchoolBranchId() {
		return schoolBranchId;
	}
	public void setSchoolBranchId(int schoolBranchId) {
		this.schoolBranchId = schoolBranchId;
	}
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public int getSchoolId() {
		return schoolId;
	}
	public void setSchoolId(int schoolId) {
		this.schoolId = schoolId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public byte[] getImage() {
		return image;
	}
	public void setImage(byte[] image) {
		this.image = image;
	}
	public String getEstablishedOn() {
		return establishedOn;
	}
	public void setEstablishedOn(String establishedOn) {
		this.establishedOn = establishedOn;
	}
	public String getLandLine() {
		return landLine;
	}
	public void setLandLine(String landLine) {
		this.landLine = landLine;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getFax() {
		return fax;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getWeb() {
		return web;
	}
	public void setWeb(String web) {
		this.web = web;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getContactPerson() {
		return contactPerson;
	}
	public void setContactPerson(String contactPerson) {
		this.contactPerson = contactPerson;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
}
