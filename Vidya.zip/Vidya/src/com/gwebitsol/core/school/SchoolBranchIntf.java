package com.gwebitsol.core.school;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

@Path("/schoolbranch/")
public interface SchoolBranchIntf {
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/add/")
    public Response addSchoolBranch(SchoolBranchPojo sbp,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/update/")
	public Response updateSchoolBranch(SchoolBranchPojo sbp,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/delete/")
	public Response deleteSchoolBranch(@QueryParam("schoolBranchId") int schoolBranchId,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@GET
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/get/")
	public Response getBySchoolBranchId(@QueryParam("schoolBranchId") int schoolBranchId,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@GET
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/getall/")
	public Response getAllSchoolBranch(@QueryParam("status") String status,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName
			,@QueryParam("PNO") int PNO,@QueryParam("size") int size);
}
