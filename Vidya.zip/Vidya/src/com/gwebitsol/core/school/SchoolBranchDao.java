package com.gwebitsol.core.school;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class SchoolBranchDao {
	
	public String addSchoolBranch(SchoolBranchPojo sbp) {
		Session addempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction addempTx=null;
		
		StringBuffer sb=new StringBuffer();
		String strg=null;
		try
		{
			addempTx=addempSession.beginTransaction();
			Integer in=(Integer)addempSession.save(sbp);
			System.out.println(in);
		
			addempTx.commit();
			
			
			sb.append("<SchoolBranch>");
			sb.append("\n");
			sb.append("<Branchid>");
			sb.append(in);
			sb.append("</Branchid>");
			sb.append("</SchoolBranch>");
			strg=sb.toString();
		   
   		 	}
		
		catch(Exception localException)
		{
			System.out.println(localException);
			
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    
			    sb.append("could not inserted schoolbranch info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			     strg= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (addempTx!=null)
				  addempTx.rollback();
		}
		finally
		{			
			addempSession.close();
		}
		return strg;
	}

	public String updateSchoolBranch(SchoolBranchPojo sbp) {
		Session upempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction upempTx=null;
		StringBuffer sb=new StringBuffer();
		
		String outStr=null;
		try
		{
			upempTx=upempSession.beginTransaction();
	        upempSession.update(sbp);
			
			
			upempTx.commit();
			
		
			sb.append("<SchoolBranch>");
			sb.append("\n");
			sb.append("update sucessfully");
			sb.append("</SchoolBranch>");
			String str=sb.toString();
			return str;
		   
   		 	}
		
		catch(Exception localException)
		{
			System.out.println(localException);
			
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    
			    sb.append("could not update schoolbranch info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    outStr= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (upempTx!=null)
				  upempTx.rollback();
		}
		finally
		{			
			upempSession.close();
		}
		return outStr;
	}

	public String deleteSchoolBranchPojo(int schoolBranchId) {
		Session delempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction delempTx=null;
		StringBuffer sb=new StringBuffer();
		
		String outStr=null;
		try
		{
			delempTx=delempSession.beginTransaction();
			Query empQuery=delempSession.createSQLQuery("update gbl_sm_tbl_school_branch set IsDeleted ='Y' where SchoolBranchId='"+schoolBranchId+"'");
			empQuery.executeUpdate();
			/*SchoolBranchPojo f= new SchoolBranchPojo();
			f.setSchoolBranchId(schoolBranchId);
	        delempSession.delete(f);
			*/
			
			delempTx.commit();
			
			
			sb.append("<SchoolBranch>");
			sb.append("\n");
			sb.append("deleted sucessfully");
			sb.append("</SchoolBranch>");
			String str=sb.toString();
			return str;
		   
   		 	}
		
		catch(Exception localException)
		{
			System.out.println(localException);
			
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    
			    sb.append("could not delete schoolbranch info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    outStr= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (delempTx!=null)
				  delempTx.rollback();
		}
		finally
		{			
			delempSession.close();
		}
		return outStr;
	}

	public String getByIdSchoolBranchId(int schoolBranchId) {
		Session gtempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gtTx=null;
			StringBuffer sb= new StringBuffer();
			System.out.println("hi dao impl success");
			String strg= null;
				try {
					gtTx = gtempSession.beginTransaction();
					List list=gtempSession.createSQLQuery("SELECT sb.SchoolBranchId,sb.SchoolId,sf.SchoolName,sb.BranchName,sb.Image,sb.Priority,sb.`Status`,sb.Description,sb.EstablishedOn,sb.MobileNo,sb.Email,sb.Web,sb.ContactPerson,sb.Remarks,sb.Location,sb.LandLine,sb.Fax FROM gbl_sm_tbl_school_branch as sb JOIN gbl_sm_tbl_school_info as sf ON sb.SchoolId = sf.SchoolId where sb.IsDeleted <> 'Y' or sb.IsDeleted IS NULL and SchoolBranchId ='" + schoolBranchId + "';").list();
				     Iterator it=list.iterator();
				    		    sb.append("<SchoolBranch>");
						        sb.append("\n");
						        while(it.hasNext())
						        {
								Object[] ex=(Object[])it.next();
						        sb.append("<schoolBranchId>");
							    sb.append(ex[0]);
							    sb.append("</schoolBranchId>");
							    sb.append("\n");
							    sb.append("<schoolId>");
							    sb.append(ex[1]);
							    sb.append("</schoolId>");
							    sb.append("\n");
							    sb.append("<schoolName>");
								sb.append(ex[2]);
								sb.append("</schoolName>");
								sb.append("\n");
								sb.append("<branchName>");
								sb.append(ex[3]);
								sb.append("</branchName>");
								sb.append("\n");
								sb.append("<image>");
								sb.append(ex[4]);
								sb.append("</image>");
								sb.append("\n");
								sb.append("<priority>");
								sb.append(ex[5]);
								sb.append("</priority>");
								sb.append("\n");
								sb.append("<status>");
								sb.append(ex[6]);
								sb.append("</status>");
								sb.append("\n");
								sb.append("<description>");
								sb.append(ex[7]);
								sb.append("</description>");
								sb.append("\n");
								sb.append("<establishedOn>");
							    sb.append(ex[8]);
							    sb.append("</establishedOn>");
							    sb.append("\n");
							    sb.append("<mobileNo>");
							    sb.append(ex[9]);
							    sb.append("</mobileNo>");
							    sb.append("\n");
							    sb.append("<email>");
								sb.append(ex[10]);
								sb.append("</email>");
								sb.append("\n");
								sb.append("<web>");
								sb.append(ex[11]);
								sb.append("</web>");
								sb.append("\n");
								sb.append("<contactPerson>");
								sb.append(ex[12]);
								sb.append("</contactPerson>");
								sb.append("\n");
								sb.append("<remarks>");
								sb.append(ex[13]);
								sb.append("</remarks>");
								sb.append("\n");
								sb.append("<location>");
								sb.append(ex[14]);
								sb.append("</location>");
								sb.append("\n");
								sb.append("<landLine>");
								sb.append(ex[15]);
								sb.append("</landLine>");
								sb.append("\n");
								sb.append("<fax>");
								sb.append(ex[16]);
								sb.append("</fax>");
								sb.append("\n");
								sb.append("</SchoolBranch>");
							    strg= sb.toString();
						        }
							
								
						
						
				} 	catch (Exception localException) {
					System.out.println(localException);
					
					   sb.append("<Response>");
					    sb.append("\n");
					    sb.append("<Result>");
					    sb.append("\n");
					    sb.append("Fail");
					    sb.append("\n");
					    sb.append("</Result>");
					    sb.append("\n");
					    sb.append("<Description>");
					    sb.append("could not getbyid schoolbranch info");
					    sb.append("</Description>");
					    sb.append("\n");
					    sb.append("<Exception>");
					    sb.append(localException);
					    sb.append("</Exception>");
					    sb.append("</Response>");
					    sb.append("</schoolBranchId>");
					    sb.append("</SchoolBranch>");
					    strg= sb.toString();
					   MDTransactionWriter.exceptionlog.info(localException);
					  if (gtTx!=null)
						  gtTx.rollback();
					} finally {
						gtempSession.close();
					}
			return strg;
	}


	@SuppressWarnings("rawtypes")
	public String getAllSchoolBranch(String status, int PNO, int size) {
		String xmlString =null;
		  //String gsSql=null;
		  Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		  Transaction stgTx=null;
		  StringBuffer sb = new StringBuffer();
		  try
		  {
			  stgTx = stgSession.beginTransaction();
				
			
				    int fset = (PNO-1)*size;
				    String gsSql ="select count(*) from gbl_sm_tbl_school_branch";
				    Query gsQuery=stgSession.createSQLQuery(gsSql);
				    Object noRecords= gsQuery.uniqueResult();
				    sb.append("<SchoolBranches>");
				    sb.append("\n");
				    sb.append("<noRecords>"+noRecords+"</noRecords>");
				    sb.append("\n");
				    
				     if (PNO > 0 & size > 0){
				     gsSql="SELECT sb.SchoolBranchId,sb.SchoolId,si.SchoolName,sb.BranchName,sb.Image,sb.Priority,sb.`Status`,sb.Description,sb.EstablishedOn,sb.MobileNo,sb.Email,sb.Web,sb.ContactPerson,sb.Remarks,sb.Location,sb.LandLine,sb.Fax  FROM gbl_sm_tbl_school_branch as sb JOIN gbl_sm_tbl_school_info as si on sb.SchoolId=si.SchoolId where sb.IsDeleted <> 'Y' or sb.IsDeleted IS NULL and Status ='" + status + "' limit "+size+" offset "+fset;
				     }
		  
				     else {
				      gsSql="SELECT sb.SchoolBranchId,sb.SchoolId,si.SchoolName,sb.BranchName,sb.Image,sb.Priority,sb.`Status`,sb.Description,sb.EstablishedOn,sb.MobileNo,sb.Email,sb.Web,sb.ContactPerson,sb.Remarks,sb.Location,sb.LandLine,sb.Fax  FROM gbl_sm_tbl_school_branch as sb JOIN gbl_sm_tbl_school_info as si on sb.SchoolId=si.SchoolId where sb.IsDeleted <> 'Y' or sb.IsDeleted IS NULL and Status ='" + status + "'";
				     } 
				   
				  
				     gsQuery=stgSession.createSQLQuery(gsSql);
					    List gcList=gsQuery.list();
					    Iterator gsIT=gcList.iterator();
				    while(gsIT.hasNext())
				     {
				    	Object[] ex=(Object[])gsIT.next();
				    	sb.append("<SchoolBranch>");
						sb.append("\n");
						 sb.append("<schoolBranchId>");
						    sb.append(ex[0]);
						    sb.append("</schoolBranchId>");
						    sb.append("\n");
						    sb.append("<schoolId>");
						    sb.append(ex[1]);
						    sb.append("</schoolId>");
						    sb.append("\n");
						    sb.append("<schoolName>");
							sb.append(ex[2]);
							sb.append("</schoolName>");
							 sb.append("\n");
							sb.append("<branchName>");
							sb.append(ex[3]);
							sb.append("</branchName>");
							 sb.append("\n");
								sb.append("<image>");
								sb.append(ex[4]);
								sb.append("</image>");
								sb.append("\n");
								sb.append("<priority>");
								sb.append(ex[5]);
								sb.append("</priority>");
								sb.append("\n");
								sb.append("<status>");
								sb.append(ex[6]);
								sb.append("</status>");
								sb.append("\n");
								sb.append("<description>");
								sb.append(ex[7]);
								sb.append("</description>");
								sb.append("\n");
								sb.append("<establishedOn>");
							    sb.append(ex[8]);
							    sb.append("</establishedOn>");
							    sb.append("\n");
							    sb.append("<mobileNo>");
							    sb.append(ex[9]);
							    sb.append("</mobileNo>");
							    sb.append("\n");
							    sb.append("<email>");
								sb.append(ex[10]);
								sb.append("</email>");
								sb.append("\n");
								sb.append("<web>");
								sb.append(ex[11]);
								sb.append("</web>");
								sb.append("\n");
								sb.append("<contactPerson>");
								sb.append(ex[12]);
								sb.append("</contactPerson>");
								sb.append("\n");
								sb.append("<remarks>");
								sb.append(ex[13]);
								sb.append("</remarks>");
								sb.append("\n");
								sb.append("<location>");
								sb.append(ex[14]);
								sb.append("</location>");
								sb.append("\n");
								sb.append("<landLine>");
								sb.append(ex[15]);
								sb.append("</landLine>");
								sb.append("\n");
								sb.append("<fax>");
								sb.append(ex[16]);
								sb.append("</fax>");
								sb.append("\n");
						sb.append("</SchoolBranch>");
			}		
				sb.append("</SchoolBranches>");
				xmlString= sb.toString();
			
				stgTx.commit();
			
		
		   }
		catch(Exception localException)
		{
			System.out.println(localException);
			
			   sb.append("<SchoolBranch>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    
			    sb.append("could not getall schoolbranch info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</SchoolBranch>");
			    xmlString= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (stgTx!=null)
				  stgTx.rollback();
		}
		finally
		{
			stgSession.close();
		
		}
		return xmlString;
	
	}
}
