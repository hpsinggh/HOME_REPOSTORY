package com.gwebitsol.core.grading;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="Scale")
public class ScalePojo {
	private int scaleId;
	private String scaleName;
	private String description;
	private int scaleStart;
	private int scaleEnd;
	private int schoolId;
	private int branchId;
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getScaleId() {
		return scaleId;
	}
	public void setScaleId(int scaleId) {
		this.scaleId = scaleId;
	}
	public String getScaleName() {
		return scaleName;
	}
	public void setScaleName(String scaleName) {
		this.scaleName = scaleName;
	}
	
	public int getScaleStart() {
		return scaleStart;
	}
	public void setScaleStart(int scaleStart) {
		this.scaleStart = scaleStart;
	}
	public int getScaleEnd() {
		return scaleEnd;
	}
	public void setScaleEnd(int scaleEnd) {
		this.scaleEnd = scaleEnd;
	}
	public int getSchoolId() {
		return schoolId;
	}
	public void setSchoolId(int schoolId) {
		this.schoolId = schoolId;
	}
	public int getBranchId() {
		return branchId;
	}
	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}
}
