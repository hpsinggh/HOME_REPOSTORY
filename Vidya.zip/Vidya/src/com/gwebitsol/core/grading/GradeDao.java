package com.gwebitsol.core.grading;

import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.infrastructure.FieldPojo;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class GradeDao {
	
	public String addGrade(GradePojo gp) {
		Session addempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction addempTx=null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			addempTx=addempSession.beginTransaction();
			Integer in=(Integer)addempSession.save(gp);
			System.out.println(in);
			
			addempTx.commit();
			
			
			sb.append("<Grade>");
			sb.append("\n");
			sb.append("<Gradeid>");
			sb.append(in);
			sb.append("</Gradeid>");
			sb.append("</Grade>");
			outStr=sb.toString();
		   
   		 	}
		
		catch(Exception localException)
		{
			System.out.println(localException);
			
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    
			    sb.append("could not inserted grade info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    outStr= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (addempTx!=null)
				  addempTx.rollback();
		}
		finally
		{			
			addempSession.close();
		}
		return outStr;
	}

	public String updateGrade(GradePojo gp,int schoolId,int branchId) {
		Session upempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction upempTx=null;
		StringBuffer sb=new StringBuffer();
		
		String outStr=null;
		try
		{
			upempTx=upempSession.beginTransaction();
			GradePojo grade = (GradePojo) upempSession.get(GradePojo.class,gp.getGradeId());
			upempSession.evict(grade);
			if(branchId==grade.getBranchId()&&schoolId==grade.getSchoolId())
			upempSession.update(gp);
			upempTx.commit();
			sb.append("<Grade>");
			sb.append("\n");
			sb.append("update sucessfully");
			sb.append("</Grade>");
			String str=sb.toString();
			return str;
		   
   		 	}
		
		catch(Exception localException)
		{
			System.out.println(localException);
			
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    
			    sb.append("could not update grade info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    outStr= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (upempTx!=null)
				  upempTx.rollback();
		}
		finally
		{			
			upempSession.close();
		}
		return outStr;
	}

	public String deleteGradePojo(int gradeId,int schoolId,int branchId) {
		Session delempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction delempTx=null;
		StringBuffer sb=new StringBuffer();
		
		String outStr=null;
		try
		{
			delempTx=delempSession.beginTransaction();
			GradePojo grade = (GradePojo) delempSession.get(GradePojo.class,gradeId);
			   int branid = grade.getBranchId();
			   int sclid = grade.getSchoolId();
			   delempSession.evict(grade);             
			   if(branchId==branid&&schoolId==sclid)
			   {
			Query empQuery=delempSession.createSQLQuery("update gbl_sm_tbl_grade set IsDeleted ='Y' where gradeId='"+gradeId+"'");
			empQuery.executeUpdate();
			delempTx.commit();
			sb.append("<Grade>");
			sb.append("\n");
			sb.append("deleted sucessfully");
			sb.append("</Grade>");
			String str=sb.toString();
			return str;
		   
   		 	}else
			   {
				outStr = "grade is not deleted";
			    sb.append("<Grade>");
			    sb.append("\n");
			    sb.append(outStr);
			    sb.append("</Grade>");
			    String str = sb.toString();
			    return str;
			   }
				}
		
		catch(Exception localException)
		{
			System.out.println(localException);
			
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    
			    sb.append("could not delete grade info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    outStr= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (delempTx!=null)
				  delempTx.rollback();
		}
		finally
		{			
			delempSession.close();
		}
		return outStr;
	}

	public String getByIdGradeId(int gradeId,int schoolId,int branchId) {
		Session gtempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gtTx=null;
			StringBuffer sb= new StringBuffer();
			System.out.println("hi dao impl success");
			String strg= null;
				try {
					gtTx = gtempSession.beginTransaction();
					List list=gtempSession.createSQLQuery("SELECT g.GradeId,g.ScaleId,s.ScaleName,g.GradeName,g.GradeStart,g.GradeEnd,g.GradeDescription,g.SchoolId,g.BranchId FROM gbl_sm_tbl_grade as g JOIN gbl_sm_tbl_scale as s ON g.ScaleId = s.ScaleId where g.IsDeleted <> 'Y' or g.IsDeleted IS NULL and GradeId ='" + gradeId + "' and g.SchoolId ='" + schoolId + "'and g.BranchId ='" + branchId + "';").list();
				     Iterator it=list.iterator();
						        while(it.hasNext())
						        {
								Object[] ex=(Object[])it.next();
								 sb.append("<Grade>");
							     sb.append("\n");
						        sb.append("<gradeId>");
							    sb.append(ex[0]);
							    sb.append("</gradeId>");
							    sb.append("\n");
							    sb.append("<scaleId>");
							    sb.append(ex[1]);
							    sb.append("</scaleId>");
							    sb.append("\n");
							    sb.append("<scaleName>");
								sb.append(ex[2]);
								sb.append("</scaleName>");
								 sb.append("\n");
								sb.append("<gradeName>");
								sb.append(ex[3]);
								sb.append("</gradeName>");
								 sb.append("\n");
								sb.append("<gradeStart>");
								sb.append(ex[4]);
								sb.append("</gradeStart>");
								sb.append("\n");
								sb.append("<gradeEnd>");
								sb.append(ex[5]);
								sb.append("</gradeEnd>");
								sb.append("\n");
								sb.append("<gradeDescription>");
								sb.append(ex[6]);
								sb.append("</gradeDescription>");
								sb.append("\n");
								sb.append("<schoolId>");
								sb.append(ex[7]);
								sb.append("</schoolId>");
								sb.append("\n");
								sb.append("<branchId>");
								sb.append(ex[8]);
								sb.append("</branchId>");
								sb.append("\n");
								sb.append("</Grade>");
						        }
							    strg= sb.toString();
						
						
				} 	catch (Exception localException) {
					System.out.println(localException);
					
					   sb.append("<Response>");
					    sb.append("\n");
					    sb.append("<Result>");
					    sb.append("\n");
					    sb.append("Fail");
					    sb.append("\n");
					    sb.append("</Result>");
					    sb.append("\n");
					    sb.append("<Description>");
					    
					    sb.append("could not getbyid grade info");
					    sb.append("</Description>");
					    sb.append("\n");
					    sb.append("<Exception>");
					    sb.append(localException);
					    sb.append("</Exception>");
					    sb.append("</Response>");
					    sb.append("</gradeId>");
					    sb.append("</Grade>");
					    strg= sb.toString();
					   MDTransactionWriter.exceptionlog.info(localException);
					  if (gtTx!=null)
						  gtTx.rollback();
					} finally {
						gtempSession.close();
					}
			return strg;
	}


	@SuppressWarnings("unused")

	public String getAllGrade(int PNO, int size,int schoolId,int branchId) {

		Session rdSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb= new StringBuffer();
		String string=null;
	   // GradePojo ex=null;
		
		try
		{
			tx = rdSession.beginTransaction();
			
			 if(("all") != null)
			   {
			    int fset = (PNO-1)*size;
			    String gsSql ="select count(*) from gbl_sm_tbl_grade as g where g.IsDeleted <> 'Y' or g.IsDeleted IS NULL and g.SchoolId ='" + schoolId + "'and g.BranchId ='" + branchId + "'";
			    Query gsQuery=rdSession.createSQLQuery(gsSql);
			    Object noRecords= gsQuery.uniqueResult();
			    sb.append("<Grades>");
			    sb.append("\n");
			    sb.append("<noRecords>"+noRecords+"</noRecords>");
			    sb.append("\n");
			    
			     if (PNO > 0 & size > 0){
			     gsSql="SELECT g.GradeId,g.ScaleId,s.ScaleName,g.GradeName,g.GradeStart,g.GradeEnd,g.GradeDescription,g.SchoolId,g.BranchId FROM gbl_sm_tbl_grade as g JOIN gbl_sm_tbl_scale as s ON g.ScaleId = s.ScaleId where g.IsDeleted <> 'Y' or g.IsDeleted IS NULL and g.SchoolId ='" + schoolId + "'and g.BranchId ='" + branchId + "' limit "+size+" offset "+fset;}
			     else {
			      gsSql="SELECT g.GradeId,g.ScaleId,s.ScaleName,g.GradeName,g.GradeStart,g.GradeEnd,g.GradeDescription,g.SchoolId,g.BranchId FROM gbl_sm_tbl_grade as g JOIN gbl_sm_tbl_scale as s ON g.ScaleId = s.ScaleId where g.IsDeleted <> 'Y' or g.IsDeleted IS NULL and g.SchoolId ='" + schoolId + "'and g.BranchId ='" + branchId + "'";
			     } 
			   
			    gsQuery=rdSession.createSQLQuery(gsSql);
			    List gcList=gsQuery.list();
			    Iterator gsIT=gcList.iterator();
			    while(gsIT.hasNext())
			     {
			    	Object[] ex=(Object[])gsIT.next();
			    	sb.append("<Grade>");
					sb.append("\n");
					 sb.append("<gradeId>");
					    sb.append(ex[0]);
					    sb.append("</gradeId>");
					    sb.append("\n");
					    sb.append("<scaleId>");
					    sb.append(ex[1]);
					    sb.append("</scaleId>");
					    sb.append("\n");
					    sb.append("<scaleName>");
						sb.append(ex[2]);
						sb.append("</scaleName>");
						 sb.append("\n");
						sb.append("<gradeName>");
						sb.append(ex[3]);
						sb.append("</gradeName>");
						 sb.append("\n");
						sb.append("<gradeStart>");
						sb.append(ex[4]);
						sb.append("</gradeStart>");
						sb.append("\n");
						sb.append("<gradeEnd>");
						sb.append(ex[5]);
						sb.append("</gradeEnd>");
						sb.append("\n");
						sb.append("<gradeDescription>");
						sb.append(ex[6]);
						sb.append("</gradeDescription>");
						sb.append("\n");
						sb.append("<schoolId>");
						sb.append(ex[7]);
						sb.append("</schoolId>");
						sb.append("\n");
						sb.append("<branchId>");
						sb.append(ex[8]);
						sb.append("</branchId>");
						sb.append("\n");
					sb.append("</Grade>");
			}
		}
			sb.append("</Grades>");
					    String str= sb.toString();
						 tx.commit();
					return str;
			
		
		}
		catch(Exception localException)
		{
			System.out.println(localException);
			
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    
			    sb.append("could not getall grade info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    string= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (tx!=null)
				  tx.rollback();
		}
		finally
		{
			rdSession.close();
		
		}
		return string;
	}
	}

