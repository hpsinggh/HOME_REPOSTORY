package com.gwebitsol.core.grading;

import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.infrastructure.FieldPojo;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class ScaleDao {
	
	public String addScale(ScalePojo sp)
	{
		Session addempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction addempTx=null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			addempTx=addempSession.beginTransaction();
			Integer in=(Integer)addempSession.save(sp);
			System.out.println(in);
			
			addempTx.commit();
			
			
			sb.append("<Scale>");
			sb.append("\n");
			sb.append("<Scaleid>");
			sb.append(in);
			sb.append("</Scaleid>");
			sb.append("</Scale>");
			outStr=sb.toString();
		   
   		 	}
		
		catch(Exception localException)
		{
			System.out.println(localException);
			
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    
			    sb.append("could not inserted scale info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    outStr= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (addempTx!=null)
				  addempTx.rollback();
		}
		finally
		{			
			addempSession.close();
		}
		return outStr;
		}
	public String updateScale(ScalePojo sp,int schoolId,int branchId) {
		Session upempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction upempTx=null;
		StringBuffer sb=new StringBuffer();
		
		String outStr=null;
		try
		{
			upempTx=upempSession.beginTransaction();
			ScalePojo scale = (ScalePojo) upempSession.get(ScalePojo.class,sp.getScaleId());
			upempSession.evict(scale);
			if(branchId==scale.getBranchId()&&schoolId==scale.getSchoolId())
			upempSession.update(sp);
			upempTx.commit();
			sb.append("<Scale>");
			sb.append("\n");
			sb.append("update sucessfully");
			sb.append("</Scale>");
			String str=sb.toString();
			return str;
		   
   		 	}
		
		catch(Exception localException)
		{
			System.out.println(localException);
			
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    
			    sb.append("could not update scale info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    outStr= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (upempTx!=null)
				  upempTx.rollback();
		}
		finally
		{			
			upempSession.close();
		}
		return outStr;
	}
	public String deleteScalePojo(int scaleId,int schoolId,int branchId) {
		Session delempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction delempTx=null;
		StringBuffer sb=new StringBuffer();
		
		String outStr=null;
		try
		{
			delempTx=delempSession.beginTransaction();
			ScalePojo scale = (ScalePojo) delempSession.get(ScalePojo.class,scaleId);
			   int branid = scale.getBranchId();
			   int sclid = scale.getSchoolId();
			   delempSession.evict(scale);             
			   if(branchId==branid&&schoolId==sclid)
			   {
			Query empQuery=delempSession.createSQLQuery("update gbl_sm_tbl_scale set IsDeleted ='Y' where scaleId='"+scaleId+"'");
			empQuery.executeUpdate();
			delempTx.commit();
			sb.append("<Scale>");
			sb.append("\n");
			sb.append("deleted sucessfully");
			sb.append("</Scale>");
			String str=sb.toString();
			return str;
		   
   		 	} else
			   {
				outStr = "scale is not deleted";
			    sb.append("<Scale>");
			    sb.append("\n");
			    sb.append(outStr);
			    sb.append("</Scale>");
			    String str = sb.toString();
			    return str;
			   }
				}
		
		catch(Exception localException)
		{
			System.out.println(localException);
			
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    
			    sb.append("could not delete scale info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    outStr= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (delempTx!=null)
				  delempTx.rollback();
		}
		finally
		{			
			delempSession.close();
		}
		return outStr;
	}
	public String getByIdScaleId(int scaleId,int schoolId,int branchId) {
		Session gtempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gtTx=null;
			StringBuffer sb= new StringBuffer();
			System.out.println("hi dao impl success");
			String strg= null;
				try {
					gtTx = gtempSession.beginTransaction();
					List list=gtempSession.createSQLQuery("Select s.ScaleId,s.ScaleName,s.ScaleStart,s.ScaleEnd,s.Description,s.SchoolId,s.BranchId from gbl_sm_tbl_scale as s where s.IsDeleted <> 'Y' or s.IsDeleted IS NULL and ScaleId='" + scaleId + "' and s.SchoolId ='" + schoolId + "'and s.BranchId ='" + branchId + "' ;").list();
				     Iterator it=list.iterator();
				    		    sb.append("<Scale>");
						        sb.append("\n");
						        while(it.hasNext())
						        {
								Object[] ex=(Object[])it.next();
						        sb.append("<scaleId>");
							    sb.append(ex[0]);
							    sb.append("</scaleId>");
							    sb.append("\n");
							    sb.append("<scaleEnd>");
							    sb.append(ex[3]);
							    sb.append("</scaleEnd>");
							    sb.append("\n");
							    sb.append("<description>");
								sb.append(ex[4]);
								sb.append("</description>");
								 sb.append("\n");
								sb.append("<scaleName>");
								sb.append(ex[1]);
								sb.append("</scaleName>");
								sb.append("\n");
								sb.append("<scaleStart>");
								sb.append(ex[2]);
								sb.append("</scaleStart>");
								sb.append("\n");
								sb.append("<schoolId>");
								sb.append(ex[5]);
								sb.append("</schoolId>");
								sb.append("\n");
								sb.append("<branchId>");
								sb.append(ex[6]);
								sb.append("</branchId>");
								sb.append("\n");
						        }
								sb.append("</Scale>");
							    strg= sb.toString();
						
						
				} 	catch (Exception localException) {
					System.out.println(localException);
					
					   sb.append("<Response>");
					    sb.append("\n");
					    sb.append("<Result>");
					    sb.append("\n");
					    sb.append("Fail");
					    sb.append("\n");
					    sb.append("</Result>");
					    sb.append("\n");
					    sb.append("<Description>");
					    
					    sb.append("could not getbyid scale info");
					    sb.append("</Description>");
					    sb.append("\n");
					    sb.append("<Exception>");
					    sb.append(localException);
					    sb.append("</Exception>");
					    sb.append("</Response>");
					    sb.append("</scaleId>");
					    sb.append("</Scale>");
					    strg= sb.toString();
					   MDTransactionWriter.exceptionlog.info(localException);
					  if (gtTx!=null)
						  gtTx.rollback();
					} finally {
						gtempSession.close();
					}
			return strg;
	}

	@SuppressWarnings("unused")

	public String getAllScale(int PNO, int size,int schoolId,int branchId) {

		Session rdSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb= new StringBuffer();
		String string=null;
	    ScalePojo ex=null;
		
		try
		{
			tx = rdSession.beginTransaction();
			
			 if(("all") != null)
			   {
			    int fset = (PNO-1)*size;
			    String gsSql ="select count(*) from gbl_sm_tbl_scale as s where s.IsDeleted <> 'Y' or s.IsDeleted IS NULL and s.SchoolId ='" + schoolId + "'and s.BranchId ='" + branchId + "'";
			    Query gsQuery=rdSession.createSQLQuery(gsSql);
			    Object noRecords= gsQuery.uniqueResult();
			    sb.append("<Scales>");
			    sb.append("\n");
			    sb.append("<noRecords>"+noRecords+"</noRecords>");
			    sb.append("\n");
			    
			     if (PNO > 0 & size > 0){
			     gsSql="Select s.ScaleId,s.ScaleName,s.ScaleStart,s.ScaleEnd,s.Description,s.SchoolId,s.BranchId from gbl_sm_tbl_scale as s where s.IsDeleted <> 'Y' or s.IsDeleted IS NULL and s.SchoolId ='" + schoolId + "'and s.BranchId ='" + branchId + "' limit "+size+" offset "+fset;}
			     else {
			      gsSql="Select s.ScaleId,s.ScaleName,s.ScaleStart,s.ScaleEnd,s.Description,s.SchoolId,s.BranchId from gbl_sm_tbl_scale as s where s.IsDeleted <> 'Y' or s.IsDeleted IS NULL and s.SchoolId ='" + schoolId + "'and s.BranchId ='" + branchId + "'";
			     } 
			   
			    gsQuery=rdSession.createSQLQuery(gsSql);
			    List gcList=gsQuery.list();
			    Iterator gsIT=gcList.iterator();
			    while(gsIT.hasNext())
			     {
			      Object[] mdcArr=(Object[])gsIT.next();
			      sb.append("<Scale>");
			      sb.append("\n");
			      sb.append("<scaleId>"+mdcArr[0]+"</scaleId>");
			      sb.append("\n");
			      sb.append("<scaleName>" + mdcArr[1]+ "</scaleName>");
			      sb.append("\n");
			      sb.append("<scaleStart>" + mdcArr[2]+ "</scaleStart>");
			      sb.append("\n");
			      sb.append("<scaleEnd>" + mdcArr[3] + "</scaleEnd>");
			      sb.append("\n");
			      sb.append("<description>" + mdcArr[4] + "</description>");
			      sb.append("\n");
			      sb.append("<schoolId>" + mdcArr[5] + "</schoolId>");
			      sb.append("\n");
			      sb.append("<branchId>" + mdcArr[6] + "</branchId>");
			      sb.append("</Scale>");
			      sb.append("\n");
			}
		}
			sb.append("</Scales>");
					    String str= sb.toString();
						 tx.commit();
					return str;
			
		
		}
		catch(Exception localException)
		{
			System.out.println(localException);
			
			   sb.append("<Response>");
			    sb.append("\n");
			    sb.append("<Result>");
			    sb.append("\n");
			    sb.append("Fail");
			    sb.append("\n");
			    sb.append("</Result>");
			    sb.append("\n");
			    sb.append("<Description>");
			    
			    sb.append("could not getall scale info");
			    sb.append("</Description>");
			    sb.append("\n");
			    sb.append("<Exception>");
			    sb.append(localException);
			    sb.append("</Exception>");
			    sb.append("</Response>");
			    string= sb.toString();
			   MDTransactionWriter.exceptionlog.info(localException);
			  if (tx!=null)
				  tx.rollback();
		}
		finally
		{
			rdSession.close();
		
		}
		return string;
	}
	}

