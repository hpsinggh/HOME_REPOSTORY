package com.gwebitsol.core.grading;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="Grade")
public class GradePojo {
	private int gradeId;
	private int scaleId;
	private String gradeName;
	private String gradeDescription;
	private String gradeStart;
	private String gradeEnd;
	private int schoolId;
	private int branchId;
	
	public int getGradeId() {
		return gradeId;
	}
	public void setGradeId(int gradeId) {
		this.gradeId = gradeId;
	}
	public int getScaleId() {
		return scaleId;
	}
	public void setScaleId(int scaleId) {
		this.scaleId = scaleId;
	}
	public String getGradeName() {
		return gradeName;
	}
	public void setGradeName(String gradeName) {
		this.gradeName = gradeName;
	}
	public String getGradeDescription() {
		return gradeDescription;
	}
	public void setGradeDescription(String gradeDescription) {
		this.gradeDescription = gradeDescription;
	}
	public String getGradeStart() {
		return gradeStart;
	}
	public void setGradeStart(String gradeStart) {
		this.gradeStart = gradeStart;
	}
	public String getGradeEnd() {
		return gradeEnd;
	}
	public void setGradeEnd(String gradeEnd) {
		this.gradeEnd = gradeEnd;
	}
	public int getSchoolId() {
		return schoolId;
	}
	public void setSchoolId(int schoolId) {
		this.schoolId = schoolId;
	}
	public int getBranchId() {
		return branchId;
	}
	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}
}
