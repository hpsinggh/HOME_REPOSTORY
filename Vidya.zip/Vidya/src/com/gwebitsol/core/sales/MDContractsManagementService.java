package com.gwebitsol.core.sales;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.gwebitsol.core.dms.MDDocumentManagementDAO;
import com.gwebitsol.core.dms.MDDocumentPOJO;
import com.gwebitsol.core.util.MDTransactionWriter;

public class MDContractsManagementService implements
		MDContractsManagementServiceIntf {

	@Context private HttpServletRequest hsr;
	public Response contractsCreate(MDContracts pojo) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		MDContractsDAO dao=new MDContractsDAO();
		MDDocumentManagementDAO managementDao=new MDDocumentManagementDAO();
		String response=null;
		StringBuffer uploaddocument=null;
		MDConsumerDetails entity=null;
		try
		{
			if(pojo!=null){
				for(MDContractFile file:pojo.getFiles()){
					MDDocumentPOJO mdDocumentPOJO=	managementDao.addDocument("CONTRACT", file.getFiledata());
					if(uploaddocument == null){
						uploaddocument=new StringBuffer();
						uploaddocument.append(mdDocumentPOJO.getDocumentID());
				}else{
					uploaddocument.append(","+mdDocumentPOJO.getDocumentID());
			}
					
			}
				pojo.setUploaddocument(uploaddocument.toString());
				dao.saveMDContracts(pojo);
				  response="Document created successfully";
					}
		}
	catch(Exception localException)
	{
		dao.deleteMDConsumerDetails(entity);
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
		 response="Consumer created Failed";
		return Response.status(Status.INTERNAL_SERVER_ERROR).entity(response).build();
	}
	
	return Response.ok().type(MediaType.APPLICATION_XML).entity(response).build();
	}

	
	public Response contractsRetrieve(MDContracts pojo) {
		// TODO Auto-generated method stub
		return null;
	}

}
