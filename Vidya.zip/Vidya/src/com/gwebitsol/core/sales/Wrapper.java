package com.gwebitsol.core.sales;

import java.util.ArrayList;
import java.util.List;

public class Wrapper {
	private List<MDContractFile> files=new ArrayList<MDContractFile>();

	public List<MDContractFile> getFiles() {
		return files;
	}

	public void setFiles(List<MDContractFile> files) {
		this.files = files;
	}
	
}
