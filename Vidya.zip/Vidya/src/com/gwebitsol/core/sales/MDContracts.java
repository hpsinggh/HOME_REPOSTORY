package com.gwebitsol.core.sales;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="MD_CONTRACTS")
public class MDContracts {
	private Integer id;
	private String contractname;
	private String contracttype;
	private String issla;
	private String customername;
	private String customertype;
	private String contractsignedon;
	private String contractsignedby;
	private String expirydate;
	private String uploaddocument;
	private Wrapper wrapper = new Wrapper();
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getContractname() {
		return contractname;
	}
	public void setContractname(String contractname) {
		this.contractname = contractname;
	}
	public String getContracttype() {
		return contracttype;
	}
	public void setContracttype(String contracttype) {
		this.contracttype = contracttype;
	}
	public String getIssla() {
		return issla;
	}
	public void setIssla(String issla) {
		this.issla = issla;
	}
	public String getCustomername() {
		return customername;
	}
	public void setCustomername(String customername) {
		this.customername = customername;
	}
	public String getCustomertype() {
		return customertype;
	}
	public void setCustomertype(String customertype) {
		this.customertype = customertype;
	}
	public String getContractsignedon() {
		return contractsignedon;
	}
	public void setContractsignedon(String contractsignedon) {
		this.contractsignedon = contractsignedon;
	}
	public String getContractsignedby() {
		return contractsignedby;
	}
	public void setContractsignedby(String contractsignedby) {
		this.contractsignedby = contractsignedby;
	}
	public String getExpirydate() {
		return expirydate;
	}
	public void setExpirydate(String expirydate) {
		this.expirydate = expirydate;
	}
	public String getUploaddocument() {
		return uploaddocument;
	}
	public void setUploaddocument(String uploaddocument) {
		this.uploaddocument = uploaddocument;
	}
	public Wrapper getWrapper() {
		return wrapper;
	}

	public void setWrapper(Wrapper wrapper) {
		this.wrapper = wrapper;
	}
	@XmlElementWrapper(name="files")
	@XmlElement(name="file")
	public List<MDContractFile> getFiles() {
		return wrapper.getFiles();
	}

	public void setFiles(List<MDContractFile> files) {
		wrapper.setFiles(files);
	}

	
}
