package com.gwebitsol.core.sales;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

@Path("/contractsManagement/")
public interface MDContractsManagementServiceIntf
{
	@POST
	@Path("/contractsCreate")
	@Produces("application/xml")
	public Response contractsCreate(MDContracts pojo);
	
	@POST
	@Path("/contractsRetrieve")
	@Produces("application/xml")
	public Response contractsRetrieve(MDContracts pojo);
	
	/*@GET
	@Path("/checkConsumerName")
	@Produces("application/xml")
	public Response checkConsumerName(@QueryParam("ticsUserName") String ticsUserName);
	
	@GET
	@Path("/checkConsumerEmail")
	@Produces("application/xml")
	public Response checkConsumerEmail(@QueryParam("email") String email);
	@POST
	@Path("/consumerUpdate")
	@Produces("application/xml")
	public Response consumerUpdate(MDConsumerDetails pojo);
	
	@GET
	@Path("/getAllConsumers")
	@Produces("application/xml")
	public Response getAllConsumers(@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	@GET
	@Path("/getAllCustomers")
	@Produces("application/xml")
	public Response getAllCustomers(@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	@GET
	@Path("/getDetails")
	@Produces("application/xml")
	public Response getDetails(@QueryParam("id") String id);*/
}
