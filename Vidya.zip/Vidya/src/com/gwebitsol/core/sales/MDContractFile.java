package com.gwebitsol.core.sales;

public class MDContractFile {

	private  Integer fileId;
	private  byte[] filedata;
	public Integer getFileId() {
		return fileId;
	}
	public void setFileId(Integer fileId) {
		this.fileId = fileId;
	}
	public byte[] getFiledata() {
		return filedata;
	}
	public void setFiledata(byte[] filedata) {
		this.filedata = filedata;
	}
	
	

}
