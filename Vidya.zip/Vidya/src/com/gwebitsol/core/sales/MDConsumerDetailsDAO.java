package com.gwebitsol.core.sales;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class MDConsumerDetailsDAO 
{
		public MDConsumerDetails saveMDConsumerDetails(MDConsumerDetails entity){
			Session gimgSession = MDHibernateUtil.getSessionFactory().openSession();
			Transaction gimgTx = null;
			try 
			{
				
				gimgTx = gimgSession.beginTransaction();
				entity=	(MDConsumerDetails) gimgSession.merge(entity);
				gimgTx.commit();
			
			} 
			catch (Exception localException) 
			{
				MDTransactionWriter.exceptionlog.info(localException);
				throw new RuntimeException("Exception:"+localException.getMessage());
			} 
			finally 
			{
				gimgSession.close();
			}
			return entity;
		}
		
		public void deleteMDConsumerDetails(MDConsumerDetails entity){
			Session gimgSession = MDHibernateUtil.getSessionFactory().openSession();
			Transaction gimgTx = null;
			try 
			{
				gimgTx = gimgSession.beginTransaction();
			    gimgSession.delete(entity);
				gimgTx.commit();
			} 
			catch (Exception localException) 
			{
				MDTransactionWriter.exceptionlog.info(localException);
				throw new RuntimeException("Exaception:"+localException.getMessage());
			} 
			finally 
			{
				gimgSession.close();
			}
		}
		
		public MDConsumerDetails findByID(Integer id){
			Session gimgSession = MDHibernateUtil.getSessionFactory().openSession();
			Transaction gimgTx = null;
			MDConsumerDetails entity=null;
			try 
			{
				
				gimgTx = gimgSession.beginTransaction();
				entity = (MDConsumerDetails) gimgSession.get(MDConsumerDetails.class,id);
				gimgTx.commit();
			
			} 
			catch (Exception localException) 
			{
				MDTransactionWriter.exceptionlog.info(localException);
				throw new RuntimeException("Exception:"+localException.getMessage());
			} 
			finally 
			{
				gimgSession.close();
			}
			return entity;
		}
		
		public MDConsumerDetails checkCredentials(String userName,String password){
			Session gimgSession = MDHibernateUtil.getSessionFactory().openSession();
			Transaction gimgTx = null;
			MDConsumerDetails entity=null;
			try 
			{
				
				gimgTx = gimgSession.beginTransaction();
				String QUERY="SELECT model FROM MDConsumerDetails model WHERE model.ticsUserName = :ticsUserName AND model.ticsPassword = :ticsPassword";
				Query query= gimgSession.createQuery(QUERY);
				query.setParameter("ticsUserName", userName);
				query.setParameter("ticsPassword", password);
				entity=	(MDConsumerDetails) query.uniqueResult();
				gimgTx.commit();
			
			} 
			catch (Exception localException) 
			{
				MDTransactionWriter.exceptionlog.info(localException);
				throw new RuntimeException("Exception:"+localException.getMessage());
			} 
			finally 
			{
				gimgSession.close();
			}
			return entity;
		}
		
		
		@SuppressWarnings("unchecked")
		public List<MDConsumerDetails> findByProperty(String propertyName, Object entity,
				int... rowStartIdxAndCount) {
			Session gimgSession = MDHibernateUtil.getSessionFactory().openSession();
			Transaction gimgTx = null;
			List<MDConsumerDetails> list=null;
		
			try {
				gimgTx = gimgSession.beginTransaction();
				final String queryString = "select model from MDConsumerDetails model where model."
						+ propertyName
						+ "=:propertyValue";
				Query query= gimgSession.createQuery(queryString);
				query.setParameter("propertyValue", entity);
				if (rowStartIdxAndCount != null && rowStartIdxAndCount.length > 0) {
					int rowStartIdx = Math.max(0, rowStartIdxAndCount[0]);
					if (rowStartIdx > 0) {
						query.setFirstResult(rowStartIdx);
					}

					if (rowStartIdxAndCount.length > 1) {
						int rowCount = Math.max(0, rowStartIdxAndCount[1]);
						if (rowCount > 0) {
							query.setMaxResults(rowCount);
						}
					}
				}
				list= query.list();
				gimgTx.commit();
			} catch (RuntimeException re) {
				MDTransactionWriter.exceptionlog.info(re);
				throw new RuntimeException("Exaception:"+re.getMessage());
			}
			finally 
			{
				gimgSession.close();
			}
			return list;
		}
		
		public String forgotPassword(String userName, String emailID)
	    {
	    	Session cpSession=MDHibernateUtil.getSessionFactory().openSession();
	    	Transaction cpTx=null;
	    	String rtnString=null;
	    	try
	    	{
	    		cpTx=cpSession.beginTransaction();
	    		String query="select ticsPassword from mdconsumerdetails where ticsUserName='"+ userName +"' and email='"+ emailID+"'";
	    		rtnString= (String) cpSession.createSQLQuery(query).uniqueResult();
	    		cpTx.commit();
	    	}
	    	catch(Exception localException)
	    	{
	    		cpTx.rollback();
	    		MDTransactionWriter.exceptionlog.info(localException);
	    		rtnString="fail";
	    	}
	    	finally
	    	{
	    		cpSession.close();
	    	}
	    	return rtnString;
	    }
			

}
