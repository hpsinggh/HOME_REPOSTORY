package com.gwebitsol.core.sales;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement(name="RESPONSE")
public class MDConsumerDetailsWrapper {
	public List<MDConsumerDetails> list;

}
