package com.gwebitsol.core.sales;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.json.simple.JSONObject;

import com.google.gson.Gson;
import com.gwebitsol.core.security.MDVerifyConnectionID;
import com.gwebitsol.core.security.MDVerifyDatastoreName;
import com.gwebitsol.core.usermanagement.MDGetUserFromID;
import com.gwebitsol.core.util.MDTransactionWriter;
import com.gwebitsol.core.util.MailSender;
import com.vtiger.vtwsclib.WSClient;



public class MDConsumerManagementService implements MDConsumerManagementServiceIntf {

	private String userName;
	private String accessKey;
	private String url;
	
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserName() {
		return userName;
	}
	public void setAccessKey(String accessKey) {
		this.accessKey = accessKey;
	}
	public String getAccessKey() {
		return accessKey;
	}
	public String getUrl() {
		return url;
	}
	
	public void setUrl(String url) {
		this.url = url;
	}
	@Context private HttpServletRequest hsr;
	
	
	public Response crmConsumerCreate(MDConsumerDetails pojo,int userid, int connectionid, String datastoreName) 
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		MDConsumerDetailsDAO dao=new MDConsumerDetailsDAO();
		String response=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		
		try
		{
		   
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userid);
			
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userid,connectionid);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			if(ret==1 && rtVal==1)
			{
				String id=(String) pojo.getId();
				if (id != null && id != "") {
				dao.saveMDConsumerDetails(pojo);
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				MDTransactionWriter.writeLog(datastoreName,"CRMConsumerCreate",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());	
			    response="<Response>Consumer created successfully</Response>";
				}
				else {
					response="<Response>Failed - CRM Consumer ID is null or empty!</Response>";
				}
			}
			
			else
			{
				response="<Response>you are not an authorised user</Response>";
			}
		   
		}
		
		catch(Exception localException)
		{
			dao.deleteMDConsumerDetails(pojo);
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			response="<Response>Consumer creation Failed.</Response>";
			return Response.status(Status.INTERNAL_SERVER_ERROR).entity(response).build();
		}
	
	return Response.ok().type(MediaType.APPLICATION_XML).entity(response).build();
	}
	
	
	public Response crmConsumerUpdate(MDConsumerDetails pojo, int userid, int connectionid, String datastoreName) 
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String response=null;
		MDConsumerDetailsDAO dao=new MDConsumerDetailsDAO();
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		
		try
		{
			
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userid);
			
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userid,connectionid);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			if(ret==1 && rtVal==1)
			{					
				List<MDConsumerDetails> list=dao.findByProperty("id", pojo.getId());
				if(list!=null && list.size()>0){
					MDConsumerDetails entity=list.get(0);
					System.out.println("Request ID: "+ pojo.getId()+ "Retrieved ID :" + entity.getId());
					if(pojo.getId().equals(entity.getId())){
						if (pojo.getFirstname()!=null) entity.setFirstname(pojo.getFirstname());
						if (pojo.getTicsUserName()!=null) entity.setTicsUserName(pojo.getTicsUserName());
						if (pojo.getEmail()!=null) entity.setEmail(pojo.getEmail());
						if (pojo.gettype()!=null) entity.settype(pojo.gettype());
						if (pojo.getSubtype()!=null) entity.setSubtype(pojo.getSubtype());
						if (pojo.getPhone()!=null) entity.setPhone(pojo.getPhone());
						if (pojo.getStatus()!=null) entity.setStatus(pojo.getStatus());
						dao.saveMDConsumerDetails(entity);
						response="<Response>Consumer updated successfully.</Response>";	
						String endDate=dateFormat.format(new Date());
						Long el=System.currentTimeMillis();
						MDTransactionWriter.writeLog(datastoreName,"InfoMS",requester,startDate,endDate,sl,el,response,hsr.getRemoteHost());	
					}
					else {
					response="<Response>Consumer ID mismatch</Response>";
					}
				}
				else {
					response="<Response>Consumer does not exist for the ID</Response>";
				}
			}
			else 
			{
			response="<Response>you are not an authorised user</Response>";
			}
		}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			response="<Response>Consumer update Failed.</Response>";
			return Response.status(Status.INTERNAL_SERVER_ERROR).build();
		}
	
	return Response.ok().type(MediaType.APPLICATION_XML).entity(response).build();
	}
	
	
	public Response consumerCreate(MDConsumerDetails pojo) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		JSONObject createResult=null;
		MDConsumerDetailsDAO dao=new MDConsumerDetailsDAO();
		String response=null;
		MDConsumerDetails entity=null;
		try
		{
			
			entity=dao.saveMDConsumerDetails(pojo);
						
				WSClient client = new WSClient(getUrl());
				boolean result = client.doLogin(getUserName(), getAccessKey());
				if(result == false) {
					dao.deleteMDConsumerDetails(entity);
					MDTransactionWriter.accesslog.info(client.lastError()+" at "+new Date());
				}else {
					Map valuesmap = new HashMap();
					valuesmap.put("firstname", pojo.getFirstname());
					valuesmap.put("lastname", pojo.getLastname());
					valuesmap.put("company", pojo.getCompany());
					valuesmap.put("email", pojo.getEmail());
					valuesmap.put("phone", pojo.getPhone());
					 createResult = client.doCreate("Leads", valuesmap);
					if(client.hasError(createResult)) {
						MDTransactionWriter.accesslog.info(client.lastError()+" at "+new Date());
						return Response.ok().type(MediaType.APPLICATION_JSON).entity(client.lastError()).build();
					} 
					else{
					String id=	(String) createResult.get("id");
					entity.setId(id);
				   pojo =	dao.saveMDConsumerDetails(entity);
				   response="<Response>Consumer created successfully.</Response>/n <id>"+id+"</id>";
					}
		}
		}
	catch(Exception localException)
	{
		dao.deleteMDConsumerDetails(entity);
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
		 response="<Response>Consumer created Failed.</Response>";
		return Response.status(Status.INTERNAL_SERVER_ERROR).entity(response).build();
	}
	
	return Response.ok().type(MediaType.APPLICATION_XML).entity(response).build();
	}
	
	
	
	public Response consumerRetrieve(MDConsumerDetails pojo) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		JSONObject createResult=null;
		MDConsumerDetails details=null;
		try
		{
			MDConsumerDetailsDAO dao=new MDConsumerDetailsDAO();
		MDConsumerDetails entity=dao.checkCredentials(pojo.getTicsUserName(), pojo.getTicsPassword());
		if(entity!=null && entity.getId()!=null){
			if(entity.getStatus().equals("N")){
				WSClient client = new WSClient(getUrl());
				boolean result = client.doLogin(getUserName(), getAccessKey());
				if(result == false) {
					MDTransactionWriter.accesslog.info(client.lastError()+" at "+new Date());
				}else {
					createResult = client.doRetrieve(entity.getId());
					if(client.hasError(createResult)) {
					System.out.println("Retrieve failed!" +
					client.lastError());
					} else {
						Gson gson=new Gson();
						 details=	gson.fromJson(createResult.toJSONString(), MDConsumerDetails.class);
					}
					}
		}else{
			
		}
		}else{
			return Response.status(Status.UNAUTHORIZED).build();
		}
		}
	catch(Exception localException)
	{
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
		return Response.status(Status.INTERNAL_SERVER_ERROR).build();
	}
	
	return Response.ok().type(MediaType.APPLICATION_XML).entity(details).build();
	}
	
	
	
	public Response checkConsumerName(String ticsUserName) {
		String status="NOT_EXIST";
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		try
		{
			MDConsumerDetailsDAO dao=new MDConsumerDetailsDAO();
		List<MDConsumerDetails> entity=dao.findByProperty("ticsUserName", ticsUserName);
		if(entity!=null && entity.size()>0){
			status="EXIST";
		}
		}
	catch(Exception localException)
	{
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
		return Response.status(Status.INTERNAL_SERVER_ERROR).build();
	}
	
	return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}
	
	
	public Response consumerUpdate(MDConsumerDetails pojo) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		JSONObject createResult=null;
		MDConsumerDetails details=null;
		MDConsumerDetailsDAO dao=new MDConsumerDetailsDAO();
		try
		{
			
				WSClient client = new WSClient(getUrl());
				boolean result = client.doLogin(getUserName(), getAccessKey());
				if(result == false) {
					MDTransactionWriter.accesslog.info(client.lastError()+" at "+new Date());
				}else {
					Map valuesmap = new HashMap();
					valuesmap.put("firstname", pojo.getFirstname());
					valuesmap.put("lastname", pojo.getLastname());
					valuesmap.put("company", pojo.getCompany());
					valuesmap.put("email", pojo.getEmail());
					valuesmap.put("phone", pojo.getPhone());
					valuesmap.put("state", pojo.getState());
					valuesmap.put("leadsource", pojo.getLeadsource());
					valuesmap.put("designation", pojo.getDesignation());
					valuesmap.put("city", pojo.getCity());
					valuesmap.put("lane", pojo.getLane());
					valuesmap.put("description", pojo.getDescription());
					valuesmap.put("noofemployees", pojo.getNoofemployees());
					valuesmap.put("industry", pojo.getIndustry());
					valuesmap.put("fax", pojo.getFax());
					valuesmap.put("website", pojo.getWebsite());
					valuesmap.put("annualrevenue", pojo.getAnnualrevenue());
					valuesmap.put("code", pojo.getCode());
					valuesmap.put("country", pojo.getCountry());
					valuesmap.put("salutationtype", pojo.getSalutationtype());
					valuesmap.put("leadstatus", pojo.getLeadstatus());
					valuesmap.put("secondaryemail", pojo.getSecondaryemail());
					valuesmap.put("pobox", pojo.getPobox());
					valuesmap.put("rating", pojo.getRating());
					valuesmap.put("mobile", pojo.getMobile());
					valuesmap.put("id", pojo.getId());
				
					createResult = (JSONObject) client.doUpdate(valuesmap);
					if(client.hasError(createResult)) {
					System.out.println("Update failed!" + client.lastError());
					MDTransactionWriter.errorlog.debug("Update failed!" + client.lastError());
					} else {
						List<MDConsumerDetails> list=dao.findByProperty("ticsUserName", pojo.getTicsUserName());
						if(list!=null && list.size()>0){
							MDConsumerDetails entity=list.get(0);
							entity.setStatus("Y");
						dao.saveMDConsumerDetails(entity);
						}
						Gson gson=new Gson();
						 details=	gson.fromJson(createResult.toJSONString(), MDConsumerDetails.class);
					}
					}
			
		}
	catch(Exception localException)
	{
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
		return Response.status(Status.INTERNAL_SERVER_ERROR).build();
	}
	
	return Response.ok().type(MediaType.APPLICATION_XML).entity(details).build();
	}
	
	
	
	public Response checkConsumerEmail(String email) {
		String status="NOT_EXIST";
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		try
		{
			MDConsumerDetailsDAO dao=new MDConsumerDetailsDAO();
		List<MDConsumerDetails> entity=dao.findByProperty("email", email);
		if(entity!=null && entity.size()>0){
			status="EXIST";
		}
		}
	catch(Exception localException)
	{
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
		return Response.status(Status.INTERNAL_SERVER_ERROR).build();
	}
	
	return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}
	
	
	
	public Response getAllConsumers(int userid, int connectionid,
			String datastoreName) {
		MDConsumerDetailsWrapper wrapper=new MDConsumerDetailsWrapper();
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String statusStr=null;
		String XMLString=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userid);
			
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userid,connectionid);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			if(ret==1 && rtVal==1)
			{
					MDConsumerDetailsDAO dao=new MDConsumerDetailsDAO();
					List<MDConsumerDetails> list=dao.findByProperty("subtype", "Passenger");
					 wrapper.list=list;
					//XMLString=	mdImDAO.saveTemplate(mdTemplates);
					String endDate=dateFormat.format(new Date());
					Long el=System.currentTimeMillis();
					MDTransactionWriter.writeLog(datastoreName,"InfoMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());	
			}
			else
			{
				XMLString="you are not authorised user";
			}
		}
	catch(Exception localException)
	{
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
		statusStr="failed in service layer";
		return Response.status(Status.INTERNAL_SERVER_ERROR).build();
	}
	
	return Response.ok().type(MediaType.APPLICATION_XML).entity(wrapper).build();
	}
	
	
	
	public Response getAllCustomers(int userid, int connectionid,
			String datastoreName) {
		MDConsumerDetailsWrapper wrapper=new MDConsumerDetailsWrapper();
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String statusStr=null;
		String XMLString=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userid);
			
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userid,connectionid);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			if(ret==1 && rtVal==1)
			{
					MDConsumerDetailsDAO dao=new MDConsumerDetailsDAO();
					List<MDConsumerDetails> list=dao.findByProperty("company", "Consumer");
					 wrapper.list=list;
					//XMLString=	mdImDAO.saveTemplate(mdTemplates);
					String endDate=dateFormat.format(new Date());
					Long el=System.currentTimeMillis();
					MDTransactionWriter.writeLog(datastoreName,"InfoMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());	
			}
			else
			{
				XMLString="you are not authorised user";
			}
		}
	catch(Exception localException)
	{
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
		statusStr="failed in service layer";
	}
	
	return Response.ok().type(MediaType.APPLICATION_XML).entity(wrapper).build();
	}
	
	
	
	public Response getDetails(String id) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		JSONObject createResult=null;
		MDConsumerDetails details=null;
		try
		{
			MDConsumerDetailsDAO dao=new MDConsumerDetailsDAO();
		List<MDConsumerDetails> entity=dao.findByProperty("id", id);
		if(entity!=null && entity.size()>0){
				WSClient client = new WSClient(getUrl());
				boolean result = client.doLogin(getUserName(), getAccessKey());
				if(result == false) {
					MDTransactionWriter.accesslog.info(client.lastError()+" at "+new Date());
				}else {
					createResult = client.doRetrieve(id);
					if(client.hasError(createResult)) {
					System.out.println("Retrieve failed!" +
					client.lastError());
					} else {
						Gson gson=new Gson();
						 details=	gson.fromJson(createResult.toJSONString(), MDConsumerDetails.class);
					}
					}
		}else{
			return Response.status(Status.UNAUTHORIZED).build();
		}
		}
	catch(Exception localException)
	{
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
		return Response.status(Status.INTERNAL_SERVER_ERROR).build();
	}
	
	return Response.ok().type(MediaType.APPLICATION_XML).entity(details).build();
	}
	
	
	
	public Response forgotPassword(String userName, String emailID) {

		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String XMLString="FAILE";
		@SuppressWarnings("unused")
		String statusStr=null;
		try{
			MDConsumerDetailsDAO umDAO=new MDConsumerDetailsDAO();
	    String password=	umDAO.forgotPassword(userName, emailID);
	    if(password != null && !password.equalsIgnoreCase("fail")){
	  Boolean status=  MailSender.sendMail(emailID,"Test Mail","Your Password is :: "+ password);
	  if(status){
	    XMLString="Your Password  is send to the following E_mail_ID :"+emailID+" please check once.";
	  }
	    }else{
	    	 XMLString="Your UserName OR Email-ID is wrong please provide valid Information";
	    }
		}catch (Exception localException) {
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			statusStr="failed in service layer";
			String response="<Response>Internal Server Error.</Response>";
			return Response.status(Status.EXPECTATION_FAILED).entity(response).build();
		}
		String response="<Response>"+XMLString+"</Response>";
		return Response.ok().type(MediaType.APPLICATION_XML).entity(response).build();
	
	}
	
	
	
	public Response consumerLogin(MDConsumerDetails pojo) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		MDConsumerDetails details=null;
		try
		{
			MDConsumerDetailsDAO dao=new MDConsumerDetailsDAO();
		MDConsumerDetails entity=dao.checkCredentials(pojo.getTicsUserName(), pojo.getTicsPassword());
		if(entity!=null && entity.getId()!=null){
			details=entity;
		}else{
			return Response.status(Status.UNAUTHORIZED).build();
		}
		}
	catch(Exception localException)
	{
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
		return Response.status(Status.INTERNAL_SERVER_ERROR).build();
	}
	
	return Response.ok().type(MediaType.APPLICATION_XML).entity(details).build();
	}
	
	
	
	public Response passwordUpdate(MDConsumerDetails pojo) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		try
		{
			MDConsumerDetailsDAO dao=new MDConsumerDetailsDAO();
		MDConsumerDetails entity=dao.checkCredentials(pojo.getTicsUserName(), pojo.getTicsPassword());
		if(entity!=null && entity.getId()!=null){
			entity.setTicsPassword(pojo.getNewTicsPassword());
			dao.saveMDConsumerDetails(entity);
		}else{
			return Response.status(Status.UNAUTHORIZED).build();
		}
		}
	catch(Exception localException)
	{
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
		return Response.status(Status.INTERNAL_SERVER_ERROR).build();
	}
		String response="<Response>Password updated success fully</Response>";
	return Response.ok().type(MediaType.APPLICATION_XML).entity(response).build();
	}
	
	
	
	public Response phpConsumerCreate(MDConsumerDetails pojo) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		JSONObject createResult=null;
		MDConsumerDetailsDAO dao=new MDConsumerDetailsDAO();
		String response=null;
		MDConsumerDetails entity=null;
		try
		{
			pojo.setStatus("Y");
			entity=dao.saveMDConsumerDetails(pojo);
				WSClient client = new WSClient(getUrl());
				boolean result = client.doLogin(getUserName(), getAccessKey());
				if(result == false) {
					dao.deleteMDConsumerDetails(entity);
					MDTransactionWriter.accesslog.info(client.lastError()+" at "+new Date());
				}else {
					Map valuesmap = new HashMap();
					valuesmap.put("firstname", pojo.getFirstname());
					valuesmap.put("lastname", pojo.getLastname());
					valuesmap.put("company", pojo.getCompany());
					valuesmap.put("email", pojo.getEmail());
					valuesmap.put("phone", pojo.getPhone());
					valuesmap.put("state", pojo.getState());
					valuesmap.put("leadsource", pojo.getLeadsource());
					valuesmap.put("designation", pojo.getDesignation());
					valuesmap.put("city", pojo.getCity());
					valuesmap.put("lane", pojo.getLane());
					valuesmap.put("description", pojo.getDescription());
					valuesmap.put("noofemployees", pojo.getNoofemployees());
					valuesmap.put("industry", pojo.getIndustry());
					valuesmap.put("fax", pojo.getFax());
					valuesmap.put("website", pojo.getWebsite());
					valuesmap.put("annualrevenue", pojo.getAnnualrevenue());
					valuesmap.put("code", pojo.getCode());
					valuesmap.put("country", pojo.getCountry());
					valuesmap.put("salutationtype", pojo.getSalutationtype());
					valuesmap.put("leadstatus", pojo.getLeadstatus());
					valuesmap.put("secondaryemail", pojo.getSecondaryemail());
					valuesmap.put("pobox", pojo.getPobox());
					valuesmap.put("rating", pojo.getRating());
					valuesmap.put("mobile", pojo.getMobile());
					 createResult = client.doCreate("Leads", valuesmap);
					if(client.hasError(createResult)) {
						MDTransactionWriter.accesslog.info(client.lastError()+" at "+new Date());
						return Response.ok().type(MediaType.APPLICATION_JSON).entity(client.lastError()).build();
					} 
					else{
					String id=	(String) createResult.get("id");
					entity.setId(id);
				   pojo =	dao.saveMDConsumerDetails(entity);
				   response="<Response>Consumer created successfully.</Response>";
					}
		}
		}
	catch(Exception localException)
	{
		dao.deleteMDConsumerDetails(entity);
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
		 response="<Response>Consumer created Failed.</Response>";
		return Response.status(Status.INTERNAL_SERVER_ERROR).entity(response).build();
	}
	
	return Response.ok().type(MediaType.APPLICATION_XML).entity(response).build();
	}
	
	
}
