package com.gwebitsol.core.sales;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

@SuppressWarnings("serial")
@XmlRootElement(name = "MD_CONSUMER_DETAILS")
public class MDConsumerDetails implements Serializable {
	private Integer indexId;
	private String firstname;
	private String lastname;
	private String company;
	private String ticsUserName;
	private String ticsPassword;
	private String email;
	private String id;
	private String type;
	private String subtype;
	private String phone;
	private String newTicsPassword;
	private String status="N";

	private String lead_no;
	private String state;
	private String leadsource;
	private String designation;
	private String city;
	private String lane;
	private String description;
	private String noofemployees;
	private String industry;
	private String fax;
	private String website;
	private String annualrevenue;
	private String code;
	private String country;
	private String salutationtype;
	private String leadstatus;
	private String secondaryemail;
	private String createdtime;
	private String pobox;
	private String modifiedtime;
	private String rating;
	private String mobile;
	public Integer getIndexId() {
		return indexId;
	}
	public void setIndexId(Integer indexId) {
		this.indexId = indexId;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getTicsUserName() {
		return ticsUserName;
	}
	public void setTicsUserName(String ticsUserName) {
		this.ticsUserName = ticsUserName;
	}
	public String getTicsPassword() {
		return ticsPassword;
	}
	public void setTicsPassword(String ticsPassword) {
		this.ticsPassword = ticsPassword;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String gettype() {
		return type;
	}
	public void settype(String type) {
		this.type = type;
	}
	public String getSubtype() {
		return subtype;
	}
	public void setSubtype(String subtype) {
		this.subtype = subtype;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getNewTicsPassword() {
		return newTicsPassword;
	}
	public void setNewTicsPassword(String newTicsPassword) {
		this.newTicsPassword = newTicsPassword;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getLead_no() {
		return lead_no;
	}
	public void setLead_no(String lead_no) {
		this.lead_no = lead_no;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getLeadsource() {
		return leadsource;
	}
	public void setLeadsource(String leadsource) {
		this.leadsource = leadsource;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getLane() {
		return lane;
	}
	public void setLane(String lane) {
		this.lane = lane;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getNoofemployees() {
		return noofemployees;
	}
	public void setNoofemployees(String noofemployees) {
		this.noofemployees = noofemployees;
	}
	public String getIndustry() {
		return industry;
	}
	public void setIndustry(String industry) {
		this.industry = industry;
	}
	public String getFax() {
		return fax;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}
	public String getWebsite() {
		return website;
	}
	public void setWebsite(String website) {
		this.website = website;
	}
	public String getAnnualrevenue() {
		return annualrevenue;
	}
	public void setAnnualrevenue(String annualrevenue) {
		this.annualrevenue = annualrevenue;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getSalutationtype() {
		return salutationtype;
	}
	public void setSalutationtype(String salutationtype) {
		this.salutationtype = salutationtype;
	}
	public String getLeadstatus() {
		return leadstatus;
	}
	public void setLeadstatus(String leadstatus) {
		this.leadstatus = leadstatus;
	}
	public String getSecondaryemail() {
		return secondaryemail;
	}
	public void setSecondaryemail(String secondaryemail) {
		this.secondaryemail = secondaryemail;
	}
	public String getCreatedtime() {
		return createdtime;
	}
	public void setCreatedtime(String createdtime) {
		this.createdtime = createdtime;
	}
	public String getPobox() {
		return pobox;
	}
	public void setPobox(String pobox) {
		this.pobox = pobox;
	}
	public String getModifiedtime() {
		return modifiedtime;
	}
	public void setModifiedtime(String modifiedtime) {
		this.modifiedtime = modifiedtime;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	
}
