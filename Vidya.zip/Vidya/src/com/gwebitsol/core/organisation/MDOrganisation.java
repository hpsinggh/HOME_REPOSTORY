package com.gwebitsol.core.organisation;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="MD_Org")
public class MDOrganisation 
{
	private int parentFolderID;
	private String orgName;
	private String infoclassName;
	private String infoclassString;
	
	public int getParentFolderID() {
		return parentFolderID;
	}
	public void setParentFolderID(int parentFolderID) {
		this.parentFolderID = parentFolderID;
	}
	public String getOrgName() {
		return orgName;
	}
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}
	public String getInfoclassName() {
		return infoclassName;
	}
	public void setInfoclassName(String infoclassName) {
		this.infoclassName = infoclassName;
	}
	public String getInfoclassString() {
		return infoclassString;
	}
	public void setInfoclassString(String infoclassString) {
		this.infoclassString = infoclassString;
	}
	
	

}
