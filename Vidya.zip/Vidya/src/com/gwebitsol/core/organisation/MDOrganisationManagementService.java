package com.gwebitsol.core.organisation;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.gwebitsol.core.security.MDVerifyConnectionID;
import com.gwebitsol.core.security.MDVerifyDatastoreName;
import com.gwebitsol.core.usermanagement.MDGetUserFromID;
import com.gwebitsol.core.util.MDTransactionWriter;

public class MDOrganisationManagementService implements MDOrganisationManagementServiceIntf
{
	@Context private HttpServletRequest hsr;
	public Response addOrg(MDOrganisation mdorg, int userID,int connectionID, String datastoreName) 
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{

			int parentFolderID=mdorg.getParentFolderID();
			String orgName=mdorg.getOrgName();
			String icName=mdorg.getInfoclassName();
			String icBigString=mdorg.getInfoclassString();
			
			MDOrganisationManagementDAO mdorgDAO=new MDOrganisationManagementDAO();
			XMLString=mdorgDAO.addOrganisation(parentFolderID,orgName,icName,icBigString,userID);
			if(XMLString.equals("fail"))
				statusStr="failed";
			else
				statusStr="success";
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			MDTransactionWriter.writeLog(datastoreName,"OrgMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}
		}
		catch(WebApplicationException e)
		{
			
			XMLString="<status>failed in DAO layed</sttus>";
		}
		
		
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}
	

	public Response updateOrg(MDOrganisation mdorg, int userID,int connectionID, String datastoreName) 
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
				String orgName=mdorg.getOrgName();
			String icName=mdorg.getInfoclassName();
			String icBigString=mdorg.getInfoclassString();
			
			MDOrganisationManagementDAO mdorgDAO=new MDOrganisationManagementDAO();
			XMLString=mdorgDAO.updateOrganisationDetails(orgName,icName,icBigString,userID);
			if(XMLString.equals("fail"))
				statusStr="failed";
			else
				statusStr="success";
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			MDTransactionWriter.writeLog(datastoreName,"OrgMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}
		}
		catch(WebApplicationException e)
		{
			
			XMLString="<status>failed in DAO layed</sttus>";
		}
		
		
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}

	public Response getOrgDetails(String orgName, int userID, int connectionID,String datastoreName) 
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());	
		String XMLString=null;
		String statusStr=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{

			MDOrganisationManagementDAO mdorgDAO=new MDOrganisationManagementDAO();
			XMLString=mdorgDAO.getOrganisationDetails(orgName);
			if(XMLString.equals("fail"))
				statusStr="failed";
			else
				statusStr="success";
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			MDTransactionWriter.writeLog(datastoreName,"OrgMS",requester,startDate,endDate,sl,el,statusStr,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}
		}
		catch(WebApplicationException e)
		{
			
			XMLString="<status>failed in DAO layed</sttus>";
		}
		
		
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}




}
