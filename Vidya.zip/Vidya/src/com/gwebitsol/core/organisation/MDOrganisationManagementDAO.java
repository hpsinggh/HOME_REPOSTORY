package com.gwebitsol.core.organisation;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.infoclass.MDPrepareInsertQueryForObject;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class MDOrganisationManagementDAO 
{
	DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	Date date = new Date();
	String d=dateFormat.format(date);
	public String addOrganisation(int parentFolderID,String orgName,String infoclassName,String infoclassString,int uid)
	{
		Session addOrgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction addOrgTx=null;
		String XMLStatusString=null;
		String acl=null;
		try
		{
			if(uid==1)
			{
				acl="U#1:111";
			}
			else
			{
				acl="U#1:111;U#"+uid+":111";
			}
			addOrgTx=addOrgSession.beginTransaction();
			
			int infoclassID =(Integer)addOrgSession.createSQLQuery("select infoclassid from mdobjectinfoclassdefcontainer where infoclassname='"+infoclassName+"'").uniqueResult();

			String fldSql="INSERT INTO MDFOLDER(FOLDERNAME,PARENTFOLDERID,INFOCLASSID,STATUS,FOLDERTYPE,CREATEDDATE,MODIFIEDDATE,ACL,CREATEDBY,MODIFIEDBY,FOLDERLEVEL) VALUES('"+orgName+"',"+parentFolderID+","+infoclassID+",'active','F','"+d+"','0000-00-00 00:00:00','"+acl+"',"+uid+",0,'L')";
			Query query0=addOrgSession.createSQLQuery(fldSql);
			query0.executeUpdate();

			int folderid=(Integer)addOrgSession.createSQLQuery("select folderid from mdfolder where foldername='"+orgName+"'").uniqueResult();

			MDPrepareInsertQueryForObject piQuery=new MDPrepareInsertQueryForObject();
			String firstHalf=piQuery.prepareQuery(infoclassName, infoclassID);
			String totalQuery=firstHalf+folderid+","+infoclassString+")";
			Query query2=addOrgSession.createSQLQuery(totalQuery);
			query2.executeUpdate();

			XMLStatusString="sucessfully added the organisation";
			
			addOrgTx.commit();
		}
		catch(Exception localException)
		{
			addOrgTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			XMLStatusString="fail";
		}
		finally
		{
			addOrgSession.close();
		}
		
		return XMLStatusString;
	}
	
	public String updateOrganisationDetails(String orgName,String infoclassName,String infoclassString,int uid)
	{
		Session upObjSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction upObjTx=null;
		String XMLString=null;
		try
		{
				upObjTx=upObjSession.beginTransaction();
				
				int infoclassID =(Integer)upObjSession.createSQLQuery("select infoclassid from mdobjectinfoclassdefcontainer where infoclassname='"+infoclassName+"'").uniqueResult();
				int folderID=(Integer)upObjSession.createSQLQuery("select folderid from mdfolder where foldername='"+orgName+"'").uniqueResult();
				
				Query query=upObjSession.createSQLQuery("delete from "+infoclassName+" where componentid="+folderID);
				query.executeUpdate();

				MDPrepareInsertQueryForObject piQuery=new MDPrepareInsertQueryForObject();
				String firstHalf=piQuery.prepareQuery(infoclassName, infoclassID);
				String totalQuery=firstHalf+folderID+","+infoclassString+")";
				Query query2=upObjSession.createSQLQuery(totalQuery);
				query2.executeUpdate();
				
				Query query1=upObjSession.createSQLQuery("update mdfolder set modifieddate='"+d+"',modifiedby="+uid+" where foldername='"+orgName+"'");
				query1.executeUpdate();
			
				upObjTx.commit();
				XMLString="sucessfully updated the organisation details";
			
		}
		catch(Exception localException)
		{
			upObjTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			XMLString="fail";
		}
		finally
		{
			upObjSession.close();
		}
		return XMLString;
	}
	
	@SuppressWarnings({ "rawtypes", "deprecation" })
	public String getOrganisationDetails(String orgName)
	{
		Session gtorgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gtorgTx=null;
		String outStr=null;
		int folderid=0;
		int infoclassid=0;
		StringBuffer infFieldsSB=new StringBuffer();
		try
		{
			gtorgTx=gtorgSession.beginTransaction();
			String gtorgSql="select * from mdfolder where foldername='"+orgName+"'";
			Query gtorgQuery=gtorgSession.createSQLQuery(gtorgSql).addScalar("folderid",Hibernate.INTEGER).addScalar("foldername",Hibernate.STRING)
					.addScalar("parentfolderid",Hibernate.INTEGER).addScalar("infoclassid",Hibernate.INTEGER);
			List gtorgList=gtorgQuery.list();
			Iterator gtorgIT=gtorgList.iterator();
			while(gtorgIT.hasNext())
			{
				Object[] gtorgObj=(Object[])gtorgIT.next();
				folderid=(Integer)gtorgObj[0];
				infoclassid=(Integer)gtorgObj[3];			
			}
			infFieldsSB.append("<MD_Org>");infFieldsSB.append("\n");
			infFieldsSB.append("<orgdetails>");infFieldsSB.append("\n");

			String infoclassName=(String)gtorgSession.createSQLQuery("select infoclassname from mdobjectinfoclassdefcontainer where infoclassid="+infoclassid).uniqueResult();
			
			String infSql3="select  * from mdobjinfoclassfields where infoclassid="+infoclassid+" group by parentfieldgroup order by fieldid";
			Query ginfQuery1=gtorgSession.createSQLQuery(infSql3).addScalar("FIELDID",Hibernate.INTEGER).addScalar("PARENTFIELDGROUP",Hibernate.STRING);
			List ginfList1=ginfQuery1.list();
			Iterator ginfIT=ginfList1.iterator();
			while(ginfIT.hasNext())
			{
				Object[] infObj1=(Object[])ginfIT.next();
				infFieldsSB.append("<SectionName name='"+infObj1[1]+"'>");
				infFieldsSB.append("\n");
				String pfg=(String)infObj1[1];
				System.out.println(pfg);
				String infSql1="select * from mdobjinfoclassfields  where infoclassid="+infoclassid+" and parentfieldgroup='"+pfg+"'";
				Query ginfQuery=gtorgSession.createSQLQuery(infSql1).addScalar("fieldid",Hibernate.INTEGER).addScalar("infoclassid",Hibernate.INTEGER).addScalar("fieldname",Hibernate.STRING);
				List ginfList=ginfQuery.list();
				Iterator it=ginfList.iterator();
				while(it.hasNext())
				{
					Object[] infObj=(Object[])it.next();
					infFieldsSB.append("<field>");
					infFieldsSB.append("\n");
					infFieldsSB.append("<fieldname>");
					infFieldsSB.append(infObj[2]);
					infFieldsSB.append("</fieldname>");
					infFieldsSB.append("\n");
					infFieldsSB.append("</field>");
				}
				infFieldsSB.append("\n");
				infFieldsSB.append("</SectionName>");	
			}	
			infFieldsSB.append("\n");

			String objSql="select * from view_"+infoclassName+" where componentid="+folderid;
			Query fvQuery=gtorgSession.createSQLQuery(objSql);
			List fvList=fvQuery.list();
			Iterator fvit=fvList.iterator();
			infFieldsSB.append("<fieldvalues>");infFieldsSB.append("\n");
			
			while(fvit.hasNext())
			{
				Object[] fvStr=(Object[])fvit.next();
				int k=fvStr.length;
				for(int i=2;i<k;i++)
				{
					infFieldsSB.append("<fieldvalue>");
					infFieldsSB.append(fvStr[i]);
					infFieldsSB.append("</fieldvalue>");
					infFieldsSB.append("\n");
				}
			}
			infFieldsSB.append("</fieldvalues>");
			infFieldsSB.append("\n");
			infFieldsSB.append("</orgdetails>");
			infFieldsSB.append("\n");
			infFieldsSB.append("</MD_Org>");

			outStr=infFieldsSB.toString();
			infFieldsSB.setLength(0);		
			gtorgTx.commit();
		}
		catch(Exception localException)
		{
			gtorgTx.rollback();
			infFieldsSB.setLength(0);
			MDTransactionWriter.exceptionlog.info(localException);
			outStr="fail";
		}
		finally
		{
			gtorgSession.close();
			infFieldsSB=null;
		}
		
		return outStr;
		
	}

}
