package com.gwebitsol.core.schooltimetable;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="period")
public class Periods {
	private int timeTableId;
	private String periodTitle;
	private String description;
	private String startTime;
	private String endTime;
	private int schoolId;
	private int branchId;
	private String lunchBreak;
	
	public int getTimeTableId() {
		return timeTableId;
	}
	public void setTimeTableId(int timeTableId) {
		this.timeTableId = timeTableId;
	}
	public String getPeriodTitle() {
		return periodTitle;
	}
	public void setPeriodTitle(String periodTitle) {
		this.periodTitle = periodTitle;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public int getSchoolId() {
		return schoolId;
	}
	public void setSchoolId(int schoolId) {
		this.schoolId = schoolId;
	}
	public int getBranchId() {
		return branchId;
	}
	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}
	public String getLunchBreak() {
		return lunchBreak;
	}
	public void setLunchBreak(String lunchBreak) {
		this.lunchBreak = lunchBreak;
	}

}
