package com.gwebitsol.core.schooltimetable;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="Section")
public class Section {
	private int sectionId;
	 private int timeTableId;

	public int getTimeTableId() {
		return timeTableId;
	}

	public void setTimeTableId(int timeTableId) {
		this.timeTableId = timeTableId;
	}

	public int getSectionId() {
		return sectionId;
	}

	public void setSectionId(int sectionId) {
		this.sectionId = sectionId;
	}

}

