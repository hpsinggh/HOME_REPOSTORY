package com.gwebitsol.core.schooltimetable;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import com.gwebitsol.core.security.MDVerifyConnectionID;
import com.gwebitsol.core.security.MDVerifyDatastoreName;
import com.gwebitsol.core.usermanagement.MDGetUserFromID;
import com.gwebitsol.core.util.MDTransactionWriter;

public class SchoolTimeTableService implements SchoolTimeTableServiceInf{
	@Context
	private HttpServletRequest hsr;

	@SuppressWarnings("rawtypes")
	public Response getSchoolTimetables(Chart chart, int userid, int connectionid, String datastoreName) {
	
			MDTransactionWriter.accesslog.info("Request from:" + hsr.getRemoteHost() + "at " + new Date());
			String XMLString = null;
			String statusStr = null;
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date date = new Date();
			String startDate = dateFormat.format(date);
			Long sl = System.currentTimeMillis();
			try {
				MDGetUserFromID mdgufid = new MDGetUserFromID();
				String requester = mdgufid.getUserName(userid);
				System.out.println(connectionid);
				MDVerifyConnectionID mdvcid = new MDVerifyConnectionID();
				int ret = mdvcid.verifyConnectionID(userid, connectionid);

				MDVerifyDatastoreName mdvdsn = new MDVerifyDatastoreName();
				int rtVal = mdvdsn.verifyDatastoreName(datastoreName);
			
					System.out.println("request making user:: " + requester);
					System.out.println("connectionid verification value:: " + ret);
					System.out.println("datastore verification value :: " + rtVal);
					if (ret == 1) {
						// classes and sections

					 /*  List classes = tts.getAllclasses().getClasses();// 2 objects

					      for (int i = 0; i < classes.size(); i++) {

					            Classes Objs = (Classes) classes.get(i); // getting classId

					        	int classId = Objs.getClassId();
					
						     List sections = tts.getAllclasses().getClasses().get(i).getSections();
						     													
				         	   for (int j = 0; j < sections.size(); j++) { // getting sectionIds from List
																
							   Section section =  (Section) sections.get(j);
							     
							   int sectionId = section.getSectionId();*/
							  						   
							  // SchoolTimeTableDao sfs =new SchoolTimeTableDao();
							  // List<GblSubject> sub= sfs.getsubjects(classId,sectionId);							  
							   SchoolTTDao stt=new SchoolTTDao();
							  stt.getSchoolTimetables( chart.getAllclasses());
							  String xmlString = stt.toString();
								System.out.println(xmlString);
							
					String endDate = dateFormat.format(new Date());
					Long el = System.currentTimeMillis();
					MDTransactionWriter.writeLog(datastoreName,"ServiceMS",requester,startDate,endDate, sl, el,statusStr,hsr.getRemoteHost());				
				         	   }				      
					else {
					XMLString = "you are not authorised user";
					}
					      
					
		} catch (Exception localException) {
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			XMLString = "failed in service layer";
			localException.printStackTrace();
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}

	@SuppressWarnings("rawtypes")
	public Response addDayPeriods(Chart chart, int userID,int connectionID, String datastoreName) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String XMLString=null;
		String statusString=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
				  List classes = chart.getAllclasses().getClasses();// 2 objects

			      for (int i = 0; i < classes.size(); i++) {

			            Classes Objs = (Classes) classes.get(i); // getting classId

			        	int classId = Objs.getClassId();
				     List sections = chart.getAllclasses().getClasses().get(i).getSections(); // getting list of sectionIds
																			
		         	   for (int j = 0; j < sections.size(); j++) { // getting sectionIds from List
														
					   Section section =  (Section) sections.get(j);
					     
					   int sectionId = section.getSectionId();
					   int timetableId=section.getTimeTableId();
		         	  
					   //List weekday=chart.getSectionWeekdays().getSectionDays();
					  // List periodTimings=chart.getPeriodTimings().getPeriods();
					   /*for(int k=0;k<weekday.size();k++){
						   SectionDays day=  (SectionDays) weekday.get(k);
					   }*/
					//for (int i2 = 0; i2 < t.size(); i2++) {
					
					
					/* ArrayList<TimeTablePojo> tt=new ArrayList<TimeTablePojo>();
					   Iterator i1=chart.getTimetable().iterator();*/
					   
					   
				SchoolTTDao sclDAO=new SchoolTTDao();
				XMLString=sclDAO.addDayPeriods(classId,sectionId,timetableId,chart.getSectionWeekdays(),chart.getPeriodTimings());
				System.out.println(XMLString);
				if(XMLString.equals("fail"))
					statusString="<status>failed</status>";
				else
					statusString="<status>success</status>";
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();			
				MDTransactionWriter.writeLog(datastoreName,"EmpMS",requester,startDate,endDate,sl,el,statusString,hsr.getRemoteHost());
		         	  }
			      }  	        
			}
			else{
				XMLString="you are not authorised user";
			}		
		}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			statusString="failed in service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
		}

	@Override
	public Response updateChart(Chart chart, int userID, int connectionID, String datastoreName) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String XMLString=null;
		String statusString=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
				  List classes = chart.getAllclasses().getClasses();// 2 objects

			      for (int i = 0; i < classes.size(); i++) {

			            Classes Objs = (Classes) classes.get(i); // getting classId

			        	int classId = Objs.getClassId();
				     List sections = chart.getAllclasses().getClasses().get(i).getSections(); // getting list of sectionIds
																			
		         	   for (int j = 0; j < sections.size(); j++) { // getting sectionIds from List
														
					   Section section =  (Section) sections.get(j);
					     
					   int sectionId = section.getSectionId();
					   int timetableId=section.getTimeTableId(); 
					   
					   SchoolTTDao sclDAO=new SchoolTTDao();
					   XMLString=sclDAO.addDayPeriods(classId,sectionId,timetableId,chart.getSectionWeekdays(),chart.getPeriodTimings());
					   System.out.println(XMLString);
					   if(XMLString.equals("fail"))
						   statusString="<status>failed</status>";
					   		else
					   			statusString="<status>success</status>";
					   String endDate=dateFormat.format(new Date());
					   Long el=System.currentTimeMillis();			
					   MDTransactionWriter.writeLog(datastoreName,"EmpMS",requester,startDate,endDate,sl,el,statusString,hsr.getRemoteHost());
		         	  }
			      }  	        
			}
			else{
				XMLString="you are not authorised user";
			}		
	}catch(Exception localException)
		{
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
		statusString="failed in service layer";
	}
	return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}


	@Override
	public Response getSchoolTimetable(Timetables tts, int userID, int connectionID, String datastoreName) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String XMLString=null;
		String statusString=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
				  List classes = tts.getAllclasses().getClasses();// 2 objects

			      for (int i = 0; i < classes.size(); i++) {

			            Classes Objs = (Classes) classes.get(i); // getting classId

			        	int classId = Objs.getClassId();
				     List sections = tts.getAllclasses().getClasses().get(i).getSections(); // getting list of sectionIds
																			
		         	   for (int j = 0; j < sections.size(); j++) { // getting sectionIds from List
														
					   Section section =  (Section) sections.get(j);
					     
					   int sectionId = section.getSectionId();
					   int timetableId=section.getTimeTableId();
		         	  
					   //List weekday=chart.getSectionWeekdays().getSectionDays();
					  // List periodTimings=chart.getPeriodTimings().getPeriods();
					   /*for(int k=0;k<weekday.size();k++){
						   SectionDays day=  (SectionDays) weekday.get(k);
					   }*/
					//for (int i2 = 0; i2 < t.size(); i2++) {
					
					
					/* ArrayList<TimeTablePojo> tt=new ArrayList<TimeTablePojo>();
					   Iterator i1=chart.getTimetable().iterator();*/
					   
					   
				SchoolTTDao sclDAO=new SchoolTTDao();
				XMLString=sclDAO.getSchoolTimetable( classId, sectionId);
				System.out.println(XMLString);
				if(XMLString.equals("fail"))
					statusString="<status>failed</status>";
				else
					statusString="<status>success</status>";
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();			
				MDTransactionWriter.writeLog(datastoreName,"EmpMS",requester,startDate,endDate,sl,el,statusString,hsr.getRemoteHost());			      	        
			}
			      }
			}
			else{
				XMLString="you are not authorised user";
			}		
		}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			statusString="failed in service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
		}
	
	
	
	@SuppressWarnings("rawtypes")
	public Response addSchoolTimetables(Chart chart, int userID,int connectionID, String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String XMLString=null;
		String statusString=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{   
				SchoolTTDao sclDAO=new SchoolTTDao();
				XMLString=sclDAO.addSchoolTimetables(chart.getAllclasses(),chart.getSectionWeekdays(),chart.getPeriodTimings(),schoolId,branchId);
				System.out.println(XMLString);
				if(XMLString.equals("fail"))
					statusString="<status>failed</status>";
				else
				statusString="<status>success</status>";
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();			
				MDTransactionWriter.writeLog(datastoreName,"EmpMS",requester,startDate,endDate,sl,el,statusString,hsr.getRemoteHost());
		         	  }
			else{
				XMLString="you are not authorised user";
			}	
	
	}
		catch(Exception localException)
			{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			statusString="failed in service layer";
			}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
		}

}
	





			
