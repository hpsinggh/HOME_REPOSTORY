package com.gwebitsol.core.schooltimetable;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "timetable")
public class Timetables {
	
	AllClasses allclasses = new AllClasses();
	public AllClasses getAllclasses() {
		return allclasses;
	}

	public void setAllclasses(AllClasses allclasses) {
		this.allclasses = allclasses;
	}
	@XmlElementWrapper(name="Classes")
    @XmlElement(name="Class")
	public List<Classes> getClasses() {
		return allclasses.getClasses();
	}

	public void setClasses(List<Classes> classes) {
		allclasses.setClasses(classes);
	}
	
}
