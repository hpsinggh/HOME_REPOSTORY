package com.gwebitsol.core.schooltimetable;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

@Path("/school")
public interface SchoolTimeTableServiceInf {
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/timetabledata")
	public Response getSchoolTimetables(Chart chart, @QueryParam("userid") int userid, @QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName);
	
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/periods")
	public Response addDayPeriods(Chart chart, @QueryParam("userid") int userid, @QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName);
		
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/preparetimetable")
	public Response updateChart(Chart chart, @QueryParam("userid") int userid, @QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName);
	
	@GET
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/gettimetable")
	public Response getSchoolTimetable(Timetables tts, @QueryParam("userid") int userid, @QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName);
	
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/addchart")
	public Response addSchoolTimetables(Chart chart, @QueryParam("userid") int userid, @QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,@QueryParam("schoolId")int schoolId,@QueryParam("branchId")int branchId);
	
}

