package com.gwebitsol.core.schooltimetable;

import java.time.DayOfWeek;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.TreeMap;

import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;
import com.gwebitsol.timetable.GblPeriod;
import com.gwebitsol.timetable.GblSection;
import com.gwebitsol.timetable.GblSubject;
import com.gwebitsol.timetable.GblTeacher;
import com.gwebitsol.timetable.GblTimeTable;
import com.gwebitsol.timetable.TimeTableTester.TimeTableTest;

public class SchoolTTDao {
	Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
	Transaction tx = null;
	StringBuffer sb = new StringBuffer();
	String xmlString=null;
	String sectionId;
	String ttids;
	String periods;
	DayOfWeek weekday;
	String subs="";
	String emps;
	GblTimeTable gblTimeTable = new GblTimeTable();
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public String getSchoolTimetables(AllClasses allClasses) {		
		StringBuffer sb1 = new StringBuffer();
		List <GblSection> sections1 = new ArrayList <GblSection>();	
		try{
			
			tx = rdSession.beginTransaction();
		List classList=allClasses.getClasses();
		
		Iterator classItr=classList.iterator();
		while(classItr.hasNext())
		{
			Classes classSelected=(Classes)classItr.next();
			int classId=classSelected.getClassId();
			List sectionsList=classSelected.getSections();
			Iterator secItr=sectionsList.iterator();
		
			while(secItr.hasNext())
			{
				Section sec=(Section)secItr.next();
				 sectionId=String.valueOf(sec.getSectionId());
				 //ttids=sec.getTimeTableId();
					
		//List<GblTimeTable> gtt=new ArrayList<GblTimeTable>();
		List <GblSubject> subjects = new ArrayList<GblSubject>();
		List <GblSection> sections = new ArrayList <GblSection>();
		List <GblTeacher> teachers = new ArrayList <GblTeacher>();
		
	
		Query query = rdSession.createSQLQuery("select classId,SectionName from gbl_sm_tbl_section "
				+ " where ClassId='"+classId+"' and SectionId in('"+sectionId+"')");
			List gcList=query.list();
		    Iterator gsIT=gcList.iterator();
		     while(gsIT.hasNext())	     
		     {
		      Object[] mdcArr=(Object[])gsIT.next();
		      GblSection gblsection=new GblSection();
		      gblsection.setSchClass((Integer) mdcArr[0]);
		      gblsection.setSection((String) mdcArr[1]);
		     
		    	  Query query1 = rdSession.createSQLQuery("select sub.Priority,sub.SubWeekPeriods,sub.SubjectId from gbl_sm_tbl_subjects as sub  "
		    	  		+ "left outer join gbl_sm_tbl_subject_type as subtype on sub.SubjectTypeId=subtype.SubjectTypeId where classId='"+classId+"' and sectionId in('"+sectionId+"')");
		    	  List gcList1=query1.list();
		    	  Iterator gsIT1=gcList1.iterator();
		    	  while(gsIT1.hasNext())
		    	  	{
		    		  Object[] mdcArr1=(Object[])gsIT1.next();
		    		  GblSubject sub=new GblSubject();
		    		  sub.setPriority((Integer)mdcArr1[0]);
		    		  sub.setWeekPeriods((Integer) mdcArr1[1]);
		    		  sub.setCode(((Integer) mdcArr1[2]).toString());			      		   
		    		  subjects.add(sub);
		    	  	}
		gblsection.setSubjects(subjects);
	      //gblsection.toString();	     
		TreeMap<DayOfWeek, Integer> DailyPeriods = new TreeMap<DayOfWeek, Integer>();
		//gblsection.setChart();
	
		Query query6 = rdSession.createSQLQuery("select  count(sequenceNo) as periods, days from gbl_sm_tbl_period where timetableId in "
				+ "(select timetableId from gbl_sm_tbl_timetable where classId='"+classId+"' and sectionId in ("+sectionId+") group by sectionId ) group by timetableid, days").addScalar("periods", Hibernate.INTEGER).addScalar("days", Hibernate.STRING);
		  List<Integer> gcList6=query6.list();
    	  Iterator gsIT6=gcList6.iterator();
    	  while(gsIT6.hasNext())
    	  	{
    		  Object[] mdcArr6=(Object[])gsIT6.next();
    		  String day=(String)mdcArr6[1];
    		 // gblsection.setDayPeriod(DayOfWeek.MONDAY,(Integer)mdcArr6[2]);
		// DailyPeriods.put(DayOfWeek.SUNDAY,0);
		// DailyPeriods.put(mdcArr6[0], mdcArr6[1]);
    		/*  Integer gCount = ((BigInteger) mdcArr6[0]).intValue();
		 DailyPeriods.put(DayOfWeek.FRIDAY, gCount);
		 Integer grandChildCount1 = ((BigInteger) mdcArr6[3]).intValue();
		 DailyPeriods.put(DayOfWeek.MONDAY, grandChildCount1);
		 Integer grandChildCount2 = ((BigInteger) mdcArr6[5]).intValue();
		 DailyPeriods.put(DayOfWeek.SATURDAY, grandChildCount2);
		 Integer grandChildCount3 = ((BigInteger) mdcArr6[7]).intValue(); 
		 DailyPeriods.put(DayOfWeek.THURSDAY, grandChildCount3);
		 Integer grandChildCount4 = ((BigInteger) mdcArr6[9]).intValue();
		 DailyPeriods.put(DayOfWeek.TUESDAY, grandChildCount4);
		 Integer grandChildCount5 = ((BigInteger) mdcArr6[11]).intValue();
		 DailyPeriods.put(DayOfWeek.WEDNESDAY ,grandChildCount5);*/
    	 if(day!=null && day.equalsIgnoreCase("MONDAY")){ 	
		 DailyPeriods.put(DayOfWeek.MONDAY, (Integer)mdcArr6[0]);
    	 }else if(day!=null && day.equalsIgnoreCase("TUESDAY")){ 
    		 DailyPeriods.put(DayOfWeek.TUESDAY, (Integer)mdcArr6[0]);
    	 }else if(day!=null && day.equalsIgnoreCase("WEDNESDAY")){ 
    		 DailyPeriods.put(DayOfWeek.WEDNESDAY, (Integer)mdcArr6[0]);
    	 }else if(day!=null && day.equalsIgnoreCase("THURSDAY")){ 
    		 DailyPeriods.put(DayOfWeek.THURSDAY, (Integer)mdcArr6[0]);
    	 }else if(day!=null && day.equalsIgnoreCase("FRIDAY")){ 
    		 DailyPeriods.put(DayOfWeek.FRIDAY, (Integer)mdcArr6[0]);
    	 }else if(day!=null && day.equalsIgnoreCase("SATURDAY")){ 
    		 DailyPeriods.put(DayOfWeek.SATURDAY, (Integer)mdcArr6[0]);
    	 }else{
    		 DailyPeriods.put(DayOfWeek.SUNDAY, (Integer)mdcArr6[0]);
    	 }		 
    	  	}
		 System.out.println(DailyPeriods);
		   //setDayPeriod(DailyPeriods); 
		// gblsection.setDayPeriod(DailyPeriods);
		 gblsection.setDayPeriod(DailyPeriods);
		 sections.add(gblsection);			 
		System.out.println(sections);	
		
     }
		//teacher	=getteachers(classId, sectionId);
	Query query3 = rdSession.createSQLQuery("select staffSubjects.ClassIdTaught,staff.EmployeeId,sub.SubjectId,spAllocation.MaximumWeekPeriods,spAllocation.MaximumDayPeriods from gbl_sm_tbl_class as cls  join gbl_sm_tbl_staff_subjects as staffSubjects on staffSubjects.ClassIdTaught=cls.ClassId join gbl_sm_tbl_staff as staff on staffSubjects.EmployeeId=staff.EmployeeId  left outer join gbl_sm_tbl_staffperiodallocation as spAllocation on spAllocation.EmployeeId=staff.EmployeeId join gbl_sm_tbl_subjects as sub on sub.SubjectId=staffSubjects.SubjectId left outer join gbl_sm_tbl_subject_type as subtype on subtype.SubjectTypeId=sub.SubjectTypeId where cls.ClassId='"+ classId+"' and sub.SectionId in('"+ sectionId+"')");
	List gcList3=query3.list();
		    Iterator gsIT3=gcList3.iterator();
		     while(gsIT3.hasNext())
		     {
		      Object[] mdcArr3=(Object[])gsIT3.next();		      
		      GblTeacher teacher=new GblTeacher();
		      teacher.setClassTaught((Integer) mdcArr3[0]);
		      teacher.setEmployeeCode(((Integer) mdcArr3[1]).toString());
		      teacher.setSubjectCode(((Integer) mdcArr3[2]).toString());
		      teacher.setMaxWeekPeriods((Integer)mdcArr3[3]);
		      teacher.setMaxDayPeriods((Integer)mdcArr3[4]);
		       teachers.add(teacher);
		      System.out.println(teachers);
		     }		
		gblTimeTable.setTtGblsection(sections);
		gblTimeTable.setTtGblTeacher(teachers);
		System.out.println(gblTimeTable);		
		gblTimeTable.createTimeTable();
		/*ttTest.printTimeTable(gblTimeTable);
		List<GblSection> gSections = ttTest.g
	*/
		sections1 = gblTimeTable.getTimeTable();
		Iterator sections1itr=sections1.iterator();
		int count=0;
		while(sections1itr.hasNext()){
			GblSection gblSection=(GblSection)sections1itr.next();
			List periodResult=gblSection.getChart();
			Iterator periodResultItr=periodResult.iterator();
			
			while(periodResultItr.hasNext()){
				
				GblPeriod gblPeriod=(GblPeriod)periodResultItr.next();
				int  perde=gblPeriod.getPeriod();
				periods=String.valueOf(perde);
				 subs=gblPeriod.getSubjectCode();
				 emps=gblPeriod.getTeacher();
				  weekday=gblPeriod.getWeekday();
				
				System.out.println(perde);
				System.out.println(subs);
				System.out.println(emps);
				System.out.println(weekday);
				
				/*if(!firstRecord)
					sb2.append(", ");
					sb2.append("("+classid+","+sectionid+","+period+",'"+weekday+"')");
					*/
				if(count!=0){
					sb.append(",");
				}
				sb.append(periods +":"+ subs +":" +emps +":"+weekday);
				count++;
			}

			//sb1.append(subs +","+ emps +"," +periods +","+weekday);
			//ttids=sb.toString();
		}
			
				}
		
			
			
		Query icQuery=rdSession.createSQLQuery("CALL `updateTimeTableProcedure`('"+sb+"', '"+classId+"','"+sectionId+"')");
		icQuery.executeUpdate();
		tx.commit();
		/*TimeTableTest ttTest = new TimeTableTest();
		ttTest.printTimeTable(sections);
		System.out.println(sections);
		sections1.toString();*/
				
				System.out.println(subs);
		// return sections1;
			}	
		
}catch (Exception localException) {
	MDTransactionWriter.exceptionlog.info(localException);
	if (tx != null)
		tx.rollback();
} finally {
	rdSession.close();
}
	return ttids;
	}
	
	@SuppressWarnings("rawtypes")
	public String addDayPeriods(int classId,int sectionId,int timetableId,SectionWeekdays sectionWeekdays,PeriodTimings periodTimings) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		String strg= null;
		StringBuffer sb= new StringBuffer();		
		StringBuffer sb2= new StringBuffer();
		StringBuffer sbPeriod= new StringBuffer();
		List<SectionDays> sd=sectionWeekdays.getSectionDays();
		List<Periods> periodsList=periodTimings.getPeriods();
		 
		 try {				 
				tx = rdSession.beginTransaction();	
				Iterator i4=sd.iterator();
				boolean firstRecord=true;
				boolean firstPeriodRecord=true;
				while(i4.hasNext()){
					SectionDays sds=(SectionDays) i4.next();
					sds.setClassId(classId);
					sds.setSectionId(sectionId);
					sds.getClassId();
					int classid=sds.getClassId();
					int sectionid=sds.getSectionId();
					int period=sds.getPeriods();
					String weekday=sds.getWeekday();
					if(!firstRecord)
					sb2.append(", ");
					sb2.append("("+classid+","+sectionid+","+period+",'"+weekday+"')");
					
					if(period!=0){
						for(int periodCount=1; periodCount<=period;periodCount++){
							Periods	 periods=periodsList.get(periodCount-1);
							periods.setTimeTableId(timetableId);
							int ttid=periods.getTimeTableId();
							if(!firstPeriodRecord)							
							sbPeriod.append(", ");
							sbPeriod.append("("+ttid+","+periodCount+",'"+weekday+"','"+periods.getPeriodTitle()+"','"+periods.getStartTime()+"','"+periods.getEndTime()+"','"+periods.getDescription()+"')");
							firstPeriodRecord=false;
						}
											
					}
					firstRecord=false;
				}
				String addICSql="insert into gbl_sm_tbl_sectionperiods(ClassId,SectionId,Periods,WeekDay) " +
						"values"+sb2.toString();
				Query icQuery=rdSession.createSQLQuery(addICSql);
				icQuery.executeUpdate();
				String addSql="insert into gbl_sm_tbl_period(TimeTableId,SequenceNo,Days,PeriodTitle,StartTime,EndTime,Description) "
						+ "values"+sbPeriod.toString();
				Query query=rdSession.createSQLQuery(addSql);
				query.executeUpdate();
				tx.commit();
				sb.append("<status>periods created</status>");				
				strg= sb.toString();
				/*TimeTablePojo ttps=new TimeTablePojo();
				int sid=ttps.getSectionId();
				int clsid=ttps.getClassId();
				String  tt=ttps.getTimeTableTitle();
				String sharable=ttps.getSharable();
				String des=ttps.getDescription();
				String remarks=ttps.getRemarks();
				
				String ttsql="insert into gbl_sm_tbl_timetable(SectionId,ClassId,TimeTableTitle,Sharable,Description,Remarks)"
						+ "values("+sid+","+clsid+",'"+tt+"','"+sharable+"','"+des+"','"+remarks+"')";
				Query query1=rdSession.createSQLQuery(ttsql);
				query1.executeUpdate();*/
//				Iterator it1=sectionWeekdays.iterator();
//				{			
				//GblTimeTable gtt=new GblTimeTable();
				//gtt.createTimeTable();
				//List<GblSection> sec=gtt.getTimeTable();
										
						}
					 catch (Exception localException) {
							System.out.println(localException);
	 						localException.printStackTrace();
						   sb.append("<Response>");
						   sb.append("\n");
						   sb.append("<Result>");
						   sb.append("\n");
						   sb.append("Fail");
						   sb.append("\n");
						   sb.append("</Result>");
						   sb.append("\n");
						   sb.append("<Description>");
						   sb.append("could not inserted class info");
						   sb.append("</Description>");
						   sb.append("\n");
						   sb.append("<Exception>");
						   sb.append(localException);
						   sb.append("</Exception>");
						   sb.append("</Response>");
						    strg=sb.toString();
						   MDTransactionWriter.exceptionlog.info(localException);
						  if (tx!=null)
						   tx.rollback();
						  } finally {						  
						   rdSession.close(); 
						  }
						  return strg;
						 }

	public String getSchoolTimetable(int classId,int sectionId) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		String strg= null;
		StringBuffer sb= new StringBuffer();	
		 try {				 
				tx = rdSession.beginTransaction();	
				//Iterator i4=sd.iterator();
				boolean firstRecord=true;
				tx = rdSession.beginTransaction();
				Query query=rdSession.createSQLQuery("select cls.classId,cls.className,sec.sectionId,sec.sectionName,tt.timeTableId,tt.timetabletitle,period.subjectId,"
						+ "sub.SubjectName,period.employeeId,staff.StaffNumber,staff.FirstName,staff.MiddleName,staff.LastName,"
						+ "period.sequenceNo,period.days,period.periodTitle,period.starttime,period.endtime"
						+ "from gbl_sm_tbl_period as period,gbl_sm_tbl_staff as staff,gbl_sm_tbl_subjects as sub,"
						+ "gbl_sm_tbl_timetable as tt,gbl_sm_tbl_section as sec,gbl_sm_tbl_class as cls where cls.ClassId=sec.ClassId and "
						+ "tt.SectionId=sec.SectionId and tt.TimeTableId=period.TimeTableId and sub.SubjectId=period.SubjectId "
						+ "and staff.EmployeeId=period.EmployeeId and  cls.ClassId='"+classId+"' and sec.SectionId='"+sectionId+"'");
					List gcList=query.list();
				    Iterator gsIT=gcList.iterator();
				     while(gsIT.hasNext())
				     {
				      Object[] mdcArr=(Object[])gsIT.next();
				  
				      sb.append("<TimeTable>");
				      sb.append("\n");
				      sb.append("<classId>"+mdcArr[0]+"</classId>");
				      sb.append("\n");
				      sb.append("<className>" + mdcArr[1]+ "</className>");
				      sb.append("\n");
				      sb.append("<sectionId>" + mdcArr[2]+ "</sectionId>");
				      sb.append("\n");
				      sb.append("<sectionName>" + mdcArr[3]+ "</sectionName>");
				      sb.append("\n");
				      sb.append("<timeTableId>" + mdcArr[4]+ "</timeTableId>");
				      sb.append("\n");
				      sb.append("<timetabletitle>" + mdcArr[5]+ "</timetabletitle>");
				      sb.append("\n");
				      sb.append("<subjectId>" + mdcArr[6] + "</subjectId>");
				      sb.append("\n");
				      sb.append("<subjectName>" + mdcArr[7]+ "</subjectName>");
				      sb.append("\n");
				      sb.append("<employeeId>" + mdcArr[8] + "</employeeId>");
				      sb.append("\n");
				      sb.append("<staffNumber>" +  mdcArr[9]+ "</staffNumber>");
				      sb.append("\n");
				      sb.append("<firstName>" + mdcArr[10] + "</firstName>");
				      sb.append("\n");
				      sb.append("<middleName>" + mdcArr[11] + "</middleName>");
				      sb.append("\n");
				      sb.append("<lastName>" + mdcArr[12] + "</lastName>");
				      sb.append("\n");
				      sb.append("<sequenceNo>" + mdcArr[13] + "</sequenceNo>");
				      sb.append("\n");
				      sb.append("<days>" + mdcArr[14] + "</days>");
				      sb.append("\n");
				      sb.append("<periodTitle>" + mdcArr[15] + "</periodTitle>");
				      sb.append("\n");
				      sb.append("<startTime>" + mdcArr[16] + "</startTime>");
				      sb.append("\n");
				      sb.append("<endTime>" + mdcArr[17] + "</endTime>");
				      sb.append("\n");
				      sb.append("</TimeTable>");	
				     }
				     String str= sb.toString();
						return str;
	} catch (Exception localException) {
		System.out.println(localException);
			localException.printStackTrace();
	   sb.append("<Response>");
	   sb.append("\n");
	   sb.append("<Result>");
	   sb.append("\n");
	   sb.append("Fail");
	   sb.append("\n");
	   sb.append("</Result>");
	   sb.append("\n");
	   sb.append("<Description>");
	   sb.append("could not inserted class info");
	   sb.append("</Description>");
	   sb.append("\n");
	   sb.append("<Exception>");
	   sb.append(localException);
	   sb.append("</Exception>");
	   sb.append("</Response>");
	    strg=sb.toString();
	   MDTransactionWriter.exceptionlog.info(localException);
	  if (tx!=null)
	   tx.rollback();
	  } finally {						  
	   rdSession.close(); 
	  }
	  return strg;
	 }

	@SuppressWarnings("rawtypes")
	public String addSchoolTimetables(AllClasses allclasses, SectionWeekdays sectionWeekdays,
			PeriodTimings periodTimings,int schoolId,int branchId) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		String strg= null;
		StringBuffer sb= new StringBuffer();		
		StringBuffer sb2= new StringBuffer();
		StringBuffer sbPeriod= new StringBuffer();
		List<SectionDays> secdayList=sectionWeekdays.getSectionDays();
		List<Periods> periodsList=periodTimings.getPeriods();
		List<Classes> classList	=allclasses.getClasses();
		
		String secids = "";
		String ttids= "";
		String stime= "";
		String etime= "";
		String des= "";
		String pedtitle= "";
		String periods= "";
		String wkdy= "";
		int brnid=0;
		int sclid = 0;
		String lbreak= "";
		// List sections = chart.getAllclasses().getClasses().get(i).getSections();
		 try {		
			 
				tx = rdSession.beginTransaction();	
				/*Iterator i4=sd.iterator();
				boolean firstRecord=true;
				boolean firstPeriodRecord=true;
				//List<SectionWeekdays> secList = Arrays.asList(sd.split(","));
				List<SectionWeekdays> myList = new ArrayList<SectionWeekdays>();
				myList.spliterator();
				// Add items to List
				String s=myList.toString();
				System.out.println(s);
				String csv = s.substring(1, s.length() - 1).replace(", ", ",");
				System.out.println(csv);
				
				while(i4.hasNext()){
					SectionDays sds=(SectionDays) i4.next();					
					sds.getClassId();
					int classid=sds.getClassId();
					int sectionid=sds.getSectionId();
					int period=sds.getPeriods();
					String weekday=sds.getWeekday();
				}*/
				Iterator pedItr=periodsList.iterator();
				while(pedItr.hasNext())
				{
					Periods ped=(Periods)pedItr.next();
					if("".equalsIgnoreCase(stime)){
						stime+=ped.getStartTime();
						etime+=ped.getEndTime();
						des+=ped.getDescription();
						pedtitle+=ped.getPeriodTitle();
						lbreak+=ped.getLunchBreak();
						ped.setSchoolId(schoolId);
						ped.setBranchId(branchId);
						 sclid=ped.getSchoolId();
						  brnid=ped.getBranchId();
						  
						}else{
					stime+=","+ped.getStartTime();
					etime+=","+ped.getEndTime();
					des+=","+ped.getDescription();
					pedtitle+=","+ped.getPeriodTitle();
					lbreak+=","+ped.getLunchBreak();
					ped.setSchoolId(schoolId);
					ped.setBranchId(branchId);
					 sclid=ped.getSchoolId();
					  brnid=ped.getBranchId();
						}
					/* stime=ped.getStartTime().toString().replaceAll(", ", ",");
					// stime.split(",");
					 etime=ped.getEndTime().toString().replaceAll(", ", ",");
					 des=ped.getDescription().toString().replaceAll(", ", ",");
					 pedtitle=ped.getPeriodTitle().toString().replaceAll(", ", ",");*/
					//Integer.toString(sec.getTimeTableId().replaceAll(",", ",");
				}
				Iterator wkdyItr=secdayList.iterator();
				while(wkdyItr.hasNext())
				{
					SectionDays sdays=(SectionDays)wkdyItr.next();
				
					if("".equalsIgnoreCase(periods)){
				
						periods+=sdays.getPeriods();
						wkdy+=sdays.getWeekday();
					}else{
					
					periods+=","+sdays.getPeriods();
					wkdy+=","+sdays.getWeekday();
					}
					 //periods=Integer.toString(sdays.getPeriods()).replaceAll(", ", ",");
					// wkdy=sdays.getWeekday().toString().replaceAll(", ", ",");
				//String sectionString=sectionsList.toString().replaceAll(", ", ",");
				
			}
				
				Iterator classItr=classList.iterator();
				while(classItr.hasNext())
				{
					secids="";
					ttids="";
					Classes classSelected=(Classes)classItr.next();
					int clsid=classSelected.getClassId();
					List sectionsList=classSelected.getSections();
					Iterator secItr=sectionsList.iterator();
				
					while(secItr.hasNext())
					{
						Section sec=(Section)secItr.next();
						if("".equalsIgnoreCase(secids)){
						 secids+=sec.getSectionId();
						 ttids+=sec.getTimeTableId();
						}else{
							secids+=","+sec.getSectionId();
							 ttids+=","+sec.getTimeTableId();
						}
							
							
					
				//	Iterator pedItr=periodsList.iterator();
					
			}
					
			Query icQuery=rdSession.createSQLQuery("CALL `timetable`('"+clsid+"', '"+secids+"', '"+periods+"', '"+wkdy+"',"
					+ " '"+stime+"', '"+etime+"', '"+pedtitle+"', '"+des+"', '"+ttids+"', '"+sclid+"', '"+brnid+"', '"+lbreak+"')");
			icQuery.executeUpdate();
				
				}
				tx.commit();
				sb.append("<status>periods created</status>");				
				strg= sb.toString();
				
										
						}
					 catch (Exception localException) {
							System.out.println(localException);
	 						localException.printStackTrace();
						   sb.append("<Response>");
						   sb.append("\n");
						   sb.append("<Result>");
						   sb.append("\n");
						   sb.append("Fail");
						   sb.append("\n");
						   sb.append("</Result>");
						   sb.append("\n");
						   sb.append("<Description>");
						   sb.append("could not inserted SchoolTimetables info");
						   sb.append("</Description>");
						   sb.append("\n");
						   sb.append("<Exception>");
						   sb.append(localException);
						   sb.append("</Exception>");
						   sb.append("</Response>");
						    strg=sb.toString();
						   MDTransactionWriter.exceptionlog.info(localException);
						  if (tx!=null)
						   tx.rollback();
						  } finally {						  
						   rdSession.close(); 
						  }
						  return strg;
						 }
	}




