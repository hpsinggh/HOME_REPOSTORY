package com.gwebitsol.core.schooltimetable;

import java.time.DayOfWeek;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;
import com.gwebitsol.timetable.GblPeriod;
import com.gwebitsol.timetable.GblSection;
import com.gwebitsol.timetable.GblSubject;
import com.gwebitsol.timetable.GblTeacher;
import com.gwebitsol.timetable.GblTimeTable;

public class SchoolTimeTableDao {
	Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
	Transaction tx = null;
	StringBuffer sb = new StringBuffer();
	String xmlString=null;


	public List<GblTimeTable> getSchoolTimetables(int classId, int sectionId) {		
	
		List <GblSection> gsection=null;
		List <GblTeacher> teacher=null;		
		List<GblTimeTable> gtt=new ArrayList<GblTimeTable>();
	try{
		tx = rdSession.beginTransaction();
		GblTimeTable gblTimeTable = new GblTimeTable();
		//getsubjects(classId, sectionId);
		
		gsection=getsections(classId, sectionId);
		teacher	=getteachers(classId, sectionId);
				
		gblTimeTable.setTtGblsection(gsection);
		gblTimeTable.setTtGblTeacher(teacher);		
		//gblTimeTable.setTimeTable();
		//gblTimeTable.allocateTeachers();
		
		//List <GblPeriod> Timetable = gblTimeTable.getTimeTable();
		
		//TreeMap <Integer,String> subjPriorty = new TreeMap <Integer,String> ();
		//subjPriorty.
		gtt.add(gblTimeTable);
		
}catch (Exception localException) {
	MDTransactionWriter.exceptionlog.info(localException);
	if (tx != null)
		tx.rollback();
} finally {
	rdSession.close();
}
	return gtt;
}
		
	// list of subjects calling
	
	@SuppressWarnings("rawtypes")
	public List<GblSubject> getsubjects(int classId, int sectionId) {
		
		tx = rdSession.beginTransaction();		
		List <GblSubject> subjects = new ArrayList<GblSubject>();
		try{
			Query query1 = rdSession.createSQLQuery("select SubjectName,Priority,SubWeekPeriods from "
		 		+ "gbl_sm_tbl_subjects where classId='"+classId+"' or sectionId='"+sectionId+"'");
			List gcList1=query1.list();
			    Iterator gsIT=gcList1.iterator();
			     while(gsIT.hasNext())
			     {
			      Object[] mdcArr=(Object[])gsIT.next();
			      GblSubject sub=new GblSubject();
			      sub.setCode((String) mdcArr[0]);
			      sub.setPriority((Integer) mdcArr[1]);
			      sub.setWeekPeriods((Integer) mdcArr[2]);
			      subjects.add(sub);
			      
			      /*sub.equals(mdcArr);
			      subjects.add(sub);
			      GblSection gSection =new GblSection();      
			gSection.setSubjects(gcList1);*/
			     }
		}catch (Exception localException) {
			MDTransactionWriter.exceptionlog.info(localException);
			if (tx != null)
				tx.rollback();
		} finally {
			rdSession.close();
		}
		return  subjects;
	}
		// list of periods calling
	
@SuppressWarnings("rawtypes")
public List<GblPeriod> getperiods(int classId, int sectionId) {
		
		tx = rdSession.beginTransaction();
		
		List <GblPeriod> periods = new ArrayList <GblPeriod>();
		try{
			Query query = rdSession.createSQLQuery("select per.PeriodId,per.Days,sub.SubjectName,staff.StaffNumber"
					+ " from gbl_sm_tbl_period as per join gbl_sm_tbl_subjects as sub "
					+ "on sub.SubjectId=per.SubjectId join gbl_sm_tbl_staff as staff on "
					+ "staff.EmployeeId=per.EmployeeId join gbl_sm_tbl_timetable as tt on tt.TimeTableId=per.TimeTableId"
					+ " where tt.ClassId='"+classId+"' or tt.SectionId='"+sectionId+"'");
				List gcList=query.list();
			    Iterator gsIT=gcList.iterator();
			     while(gsIT.hasNext())
			     {
			      Object[] mdcArr=(Object[])gsIT.next();
			      GblPeriod period=new GblPeriod();
			      period.setPeriod((Integer) mdcArr[0]);
			      period.setWeekday( (DayOfWeek) mdcArr[1]);
			      period.setSubjectCode((String) mdcArr[2]);
			      period.setTeacher((String) mdcArr[3]);
			      periods.add(period);
			  		      
			      /*sub.equals(mdcArr);
			      subjects.add(sub);
			      GblSection gSection =new GblSection();      
			gSection.setSubjects(gcList1);*/
			     }
		}catch (Exception localException) {
			MDTransactionWriter.exceptionlog.info(localException);
			if (tx != null)
				tx.rollback();
		} finally {
			rdSession.close();
		}
		return  periods;
	}
// get the list of sections

@SuppressWarnings("rawtypes")
public List<GblSection> getsections(int classId, int sectionId) {
	
	tx = rdSession.beginTransaction();
	List <GblSubject> subjects=null;
	//List <GblPeriod> Chart=null;
	List <GblSection> sections = new ArrayList <GblSection>();
	try{
		Query query = rdSession.createSQLQuery("select ClassId,SectionName from gbl_sm_tbl_section "
				+ " where ClassId='"+classId+"' or SectionId='"+sectionId+"'");
			List gcList=query.list();
		    Iterator gsIT=gcList.iterator();
		     while(gsIT.hasNext())
		     {
		      Object[] mdcArr=(Object[])gsIT.next();
		GblSection gblsection=new GblSection();
		gblsection.setSchClass((Integer) mdcArr[0]);
		gblsection.setSection((String) mdcArr[1]);
		//gblsection.setSubjects(subjects);
		//GblSubject sub1=new GblSubject();
		subjects=getsubjects(classId, sectionId);
		 gblsection.setSubjects(subjects);
		gblsection.getChart();
		HashMap<DayOfWeek, Integer> DailyPeriods = new HashMap<DayOfWeek, Integer>();
		 DailyPeriods.put(DayOfWeek.SUNDAY,1);
		 DailyPeriods.put(DayOfWeek.MONDAY, 2);
		 DailyPeriods.put(DayOfWeek.TUESDAY, 3);
		 DailyPeriods.put(DayOfWeek.WEDNESDAY, 4);
		 DailyPeriods.put(DayOfWeek.THURSDAY, 5);
		 DailyPeriods.put(DayOfWeek.FRIDAY, 6);
		 DailyPeriods.put(DayOfWeek.SATURDAY, 7);
		 System.out.println(DailyPeriods);
		 //gblsection.setDayPeriod(DailyPeriods);  
		 sections.add(gblsection);	
		 
		System.out.println(sections);
      /*sub.equals(mdcArr);
		      subjects.add(sub);
		      GblSection gSection =new GblSection();      
		gSection.setSubjects(gcList1);*/
		//return sections;
		     }
	}catch (Exception localException) {
		MDTransactionWriter.exceptionlog.info(localException);
		if (tx != null)
			tx.rollback();
	} finally {
		rdSession.close();
	}
	return  sections;
}
			//teachers in list data
@SuppressWarnings("rawtypes")
public List<GblTeacher> getteachers(int classId, int sectionId) {
	
	tx = rdSession.beginTransaction();
	
	List <GblTeacher> teachers = new ArrayList <GblTeacher>();
	try{
		Query query = rdSession.createSQLQuery("select sub.ClassIdTaught,staff.StaffNumber,subs.SubjectName from gbl_sm_tbl_staff_subjects as sub "
		 		+ "join gbl_sm_tbl_staff as staff on staff.EmployeeId=sub.EmployeeId join gbl_sm_tbl_subjects as subs on subs.SubjectId=sub.SubjectId where classId='"+ classId+"' and sectionId='"+ sectionId+"'");
 
			List gcList=query.list();
		    Iterator gsIT=gcList.iterator();
		     while(gsIT.hasNext())
		     {
		      Object[] mdcArr=(Object[])gsIT.next();		      
		      GblTeacher teacher=new GblTeacher();
		      teacher.setClassTaught((Integer) mdcArr[0]);
		      teacher.setEmployeeCode((String) mdcArr[1]);
		      teacher.setSubjectCode((String) mdcArr[2]);
		      teachers.add(teacher);
		      System.out.println(teachers);
		//gblsection.setSubjects(subjects);
		
      /*sub.equals(mdcArr);
		      subjects.add(sub);
		      GblSection gSection =new GblSection();      
		gSection.setSubjects(gcList1);*/
		     }
	}catch (Exception localException) {
		MDTransactionWriter.exceptionlog.info(localException);
		if (tx != null)
			tx.rollback();
	} finally {
		rdSession.close();
	}
	return  teachers;
}
}

/*
public class SchoolTTDao {
	Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
	Transaction tx = null;
	StringBuffer sb = new StringBuffer();
	String xmlString=null;
	GblTimeTable gblTimeTable = new GblTimeTable();
	@SuppressWarnings("rawtypes")
	public  List<GblSection> getSchoolTimetables(int classId, int sectionId) {		
	
		//List <GblSection> gsection=null;
		//List <GblTeacher> teacher1=null;		
		//List<GblTimeTable> gtt=new ArrayList<GblTimeTable>();
		List <GblSubject> subjects = new ArrayList<GblSubject>();
		List <GblSection> sections = new ArrayList <GblSection>();
		List <GblTeacher> teachers = new ArrayList <GblTeacher>();
		List <GblSection> sections1 = new ArrayList <GblSection>();		
	try{
		
		tx = rdSession.beginTransaction();
		Query query = rdSession.createSQLQuery("select ClassName,SectionName from gbl_sm_tbl_section "
				+ " where ClassId='"+classId+"' and SectionId='"+sectionId+"'");
			List gcList=query.list();
		    Iterator gsIT=gcList.iterator();
		     while(gsIT.hasNext())	     
		     {
		      Object[] mdcArr=(Object[])gsIT.next();
		      GblSection gblsection=new GblSection();
		      gblsection.setSchClass((Integer) mdcArr[0]);
		      gblsection.setSection((String) mdcArr[1]);
		      try{
		    	  Query query1 = rdSession.createSQLQuery("select Priority,SubWeekPeriods,SubjectName from "
		    	  + "gbl_sm_tbl_subjects where classId='"+classId+"' and sectionId='"+sectionId+"'");
		    	  List gcList1=query1.list();
		    	  Iterator gsIT1=gcList1.iterator();
		    	  while(gsIT1.hasNext())
		    	  	{
		    		  Object[] mdcArr1=(Object[])gsIT1.next();
		    		  GblSubject sub=new GblSubject();
		    		  sub.setPriority((Integer)mdcArr1[0]);
		    		  sub.setWeekPeriods((Integer) mdcArr1[1]);
		    		  sub.setCode((String) mdcArr1[2]);			      		   
		    		  subjects.add(sub);
		    	  	}
		      	}catch(Exception e){
		      		e.printStackTrace();		
		}
		gblsection.setSubjects(subjects);
	      //gblsection.toString();	     
		
		//gblsection.setChart();
		TreeMap<DayOfWeek, Integer> DailyPeriods = new TreeMap<DayOfWeek, Integer>();
		// DailyPeriods.put(DayOfWeek.SUNDAY,0);
		 DailyPeriods.put(DayOfWeek.MONDAY, 7);
		 DailyPeriods.put(DayOfWeek.TUESDAY, 7);
		 DailyPeriods.put(DayOfWeek.WEDNESDAY, 7);
		 DailyPeriods.put(DayOfWeek.THURSDAY, 7);
		 DailyPeriods.put(DayOfWeek.FRIDAY, 7);
		 DailyPeriods.put(DayOfWeek.SATURDAY,4);
		 System.out.println(DailyPeriods);
		   //setDayPeriod(DailyPeriods); 
		// gblsection.setDayPeriod(DailyPeriods);
		 gblsection.setDayPeriod(DailyPeriods);
		 sections.add(gblsection);			 
		System.out.println(sections);
     }
		
		//teacher	=getteachers(classId, sectionId);
		
	Query query3 = rdSession.createSQLQuery("select  staffSubjects.ClassIdTaught,staff.StaffNumber,subj.SubjectName,spAllocation.MaximumWeekPeriods,"
			+ "spAllocation.MaximumDayPeriods from gbl_sm_tbl_section section,gbl_sm_tbl_staff as staff,gbl_sm_tbl_staff_subjects staffSubjects, "
			+ "gbl_sm_tbl_staffperiodallocation spAllocation,gbl_sm_tbl_subjects subj  where staffSubjects.ClassIdTaught=section.ClassId and "
			+ "staffSubjects.EmployeeId=staff.EmployeeId and spAllocation.EmployeeId=staff.EmployeeId and subj.ClassId=section.ClassId and "
			+ "subj.SubjectId=staffSubjects.SubjectId  and section.ClassId='"+ classId+"' and section.SectionId='"+ sectionId+"'");
			List gcList3=query3.list();
		    Iterator gsIT3=gcList3.iterator();
		     while(gsIT3.hasNext())
		     {
		      Object[] mdcArr3=(Object[])gsIT3.next();		      
		      GblTeacher teacher=new GblTeacher();
		      teacher.setClassTaught((Integer) mdcArr3[0]);
		      teacher.setEmployeeCode((String) mdcArr3[1]);
		      teacher.setSubjectCode((String) mdcArr3[2]);
		      teacher.setMaxWeekPeriods((Integer)mdcArr3[3]);
		      teacher.setMaxDayPeriods((Integer)mdcArr3[4]);
		       teachers.add(teacher);
		      System.out.println(teachers);
		     }
		
		gblTimeTable.setTtGblsection(sections);
		gblTimeTable.setTtGblTeacher(teachers);
		System.out.println(gblTimeTable);		
		gblTimeTable.createTimeTable();
		
		/*ttTest.printTimeTable(gblTimeTable);
		List<GblSection> gSections = ttTest.g
	
		sections1 = gblTimeTable.getTimeTable();
		TimeTableTest ttTest = new TimeTableTest();
		//ttTest.printTimeTable(sections1);
		System.out.println(sections);
		sections1.toString();
		
		//gblTimeTable.allocateTeachers();	
		//List <GblPeriod> Timetable = gblTimeTable.getTimeTable();	
		//subjPriorty
		//gtt.add(gblTimeTable);
		 return sections1;
		
}catch (Exception localException) {
	MDTransactionWriter.exceptionlog.info(localException);
	if (tx != null)
		tx.rollback();
} finally {
	rdSession.close();
}
	return sections1;
	}
	
	public String addDayPeriods(int classId,int sectionId,int timetableId,SectionWeekdays sectionWeekdays,PeriodTimings periodTimings) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		String strg= null;
		StringBuffer sb= new StringBuffer();		
		StringBuffer sb2= new StringBuffer();
		StringBuffer sbPeriod= new StringBuffer();
		List<SectionDays> sd=sectionWeekdays.getSectionDays();
		List<Periods> periodsList=periodTimings.getPeriods();
		 
		 try {				 
				tx = rdSession.beginTransaction();	
				Iterator i4=sd.iterator();
				boolean firstRecord=true;
				boolean firstPeriodRecord=true;
				while(i4.hasNext()){
					SectionDays sds=(SectionDays) i4.next();
					sds.setClassId(classId);
					sds.setSectionId(sectionId);
					sds.getClassId();
					int classid=sds.getClassId();
					int sectionid=sds.getSectionId();
					int period=sds.getPeriods();
					String weekday=sds.getWeekday();
					if(!firstRecord)
					sb2.append(", ");
					sb2.append("("+classid+","+sectionid+","+period+",'"+weekday+"')");
					
					if(period!=0){
						for(int periodCount=1; periodCount<=period;periodCount++){
							Periods	 periods=periodsList.get(periodCount-1);
							periods.setTimeTableId(timetableId);
							int ttid=periods.getTimeTableId();
							if(!firstPeriodRecord)							
							sbPeriod.append(", ");
							sbPeriod.append("("+ttid+","+periodCount+",'"+weekday+"','"+periods.getPeriodTitle()+"','"+periods.getStartTime()+"','"+periods.getEndTime()+"','"+periods.getDescription()+"')");
							firstPeriodRecord=false;
						}
											
					}
					firstRecord=false;
				}
				String addICSql="insert into gbl_sm_tbl_sectionperiods(ClassId,SectionId,Periods,WeekDay) " +
						"values"+sb2.toString();
				Query icQuery=rdSession.createSQLQuery(addICSql);
				icQuery.executeUpdate();
				String addSql="insert into gbl_sm_tbl_period(TimeTableId,SequenceNo,Days,PeriodTitle,StartTime,EndTime,Description) "
						+ "values"+sbPeriod.toString();
				Query query=rdSession.createSQLQuery(addSql);
				query.executeUpdate();
				tx.commit();
				sb.append("<status>periods created</status>");				
				strg= sb.toString();
				TimeTablePojo ttps=new TimeTablePojo();
				int sid=ttps.getSectionId();
				int clsid=ttps.getClassId();
				String  tt=ttps.getTimeTableTitle();
				String sharable=ttps.getSharable();
				String des=ttps.getDescription();
				String remarks=ttps.getRemarks();
				
				String ttsql="insert into gbl_sm_tbl_timetable(SectionId,ClassId,TimeTableTitle,Sharable,Description,Remarks)"
						+ "values("+sid+","+clsid+",'"+tt+"','"+sharable+"','"+des+"','"+remarks+"')";
				Query query1=rdSession.createSQLQuery(ttsql);
				query1.executeUpdate();
//				Iterator it1=sectionWeekdays.iterator();
//				{			
				//GblTimeTable gtt=new GblTimeTable();
				//gtt.createTimeTable();
				//List<GblSection> sec=gtt.getTimeTable();
										
						}
					 catch (Exception localException) {
							System.out.println(localException);
	 						localException.printStackTrace();
						   sb.append("<Response>");
						   sb.append("\n");
						   sb.append("<Result>");
						   sb.append("\n");
						   sb.append("Fail");
						   sb.append("\n");
						   sb.append("</Result>");
						   sb.append("\n");
						   sb.append("<Description>");
						   sb.append("could not inserted class info");
						   sb.append("</Description>");
						   sb.append("\n");
						   sb.append("<Exception>");
						   sb.append(localException);
						   sb.append("</Exception>");
						   sb.append("</Response>");
						    strg=sb.toString();
						   MDTransactionWriter.exceptionlog.info(localException);
						  if (tx!=null)
						   tx.rollback();
						  } finally {						  
						   rdSession.close(); 
						  }
						  return strg;
						 }

	public String getSchoolTimetable(int classId,int sectionId) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		String strg= null;
		StringBuffer sb= new StringBuffer();	
		 try {				 
				tx = rdSession.beginTransaction();	
				//Iterator i4=sd.iterator();
				boolean firstRecord=true;
				tx = rdSession.beginTransaction();
				Query query=rdSession.createSQLQuery("select cls.classId,cls.className,sec.sectionId,sec.sectionName,tt.timeTableId,tt.timetabletitle,period.subjectId,"
						+ "sub.SubjectName,period.employeeId,staff.StaffNumber,staff.FirstName,staff.MiddleName,staff.LastName,"
						+ "period.sequenceNo,period.days,period.periodTitle,period.starttime,period.endtime"
						+ "from gbl_sm_tbl_period as period,gbl_sm_tbl_staff as staff,gbl_sm_tbl_subjects as sub,"
						+ "gbl_sm_tbl_timetable as tt,gbl_sm_tbl_section as sec,gbl_sm_tbl_class as cls where cls.ClassId=sec.ClassId and "
						+ "tt.SectionId=sec.SectionId and tt.TimeTableId=period.TimeTableId and sub.SubjectId=period.SubjectId "
						+ "and staff.EmployeeId=period.EmployeeId and  cls.ClassId='"+classId+"' and sec.SectionId='"+sectionId+"'");
					List gcList=query.list();
				    Iterator gsIT=gcList.iterator();
				     while(gsIT.hasNext())
				     {
				      Object[] mdcArr=(Object[])gsIT.next();
				  
				      sb.append("<TimeTable>");
				      sb.append("\n");
				      sb.append("<classId>"+mdcArr[0]+"</classId>");
				      sb.append("\n");
				      sb.append("<className>" + mdcArr[1]+ "</className>");
				      sb.append("\n");
				      sb.append("<sectionId>" + mdcArr[2]+ "</sectionId>");
				      sb.append("\n");
				      sb.append("<sectionName>" + mdcArr[3]+ "</sectionName>");
				      sb.append("\n");
				      sb.append("<timeTableId>" + mdcArr[4]+ "</timeTableId>");
				      sb.append("\n");
				      sb.append("<timetabletitle>" + mdcArr[5]+ "</timetabletitle>");
				      sb.append("\n");
				      sb.append("<subjectId>" + mdcArr[6] + "</subjectId>");
				      sb.append("\n");
				      sb.append("<subjectName>" + mdcArr[7]+ "</subjectName>");
				      sb.append("\n");
				      sb.append("<employeeId>" + mdcArr[8] + "</employeeId>");
				      sb.append("\n");
				      sb.append("<staffNumber>" +  mdcArr[9]+ "</staffNumber>");
				      sb.append("\n");
				      sb.append("<firstName>" + mdcArr[10] + "</firstName>");
				      sb.append("\n");
				      sb.append("<middleName>" + mdcArr[11] + "</middleName>");
				      sb.append("\n");
				      sb.append("<lastName>" + mdcArr[12] + "</lastName>");
				      sb.append("\n");
				      sb.append("<sequenceNo>" + mdcArr[13] + "</sequenceNo>");
				      sb.append("\n");
				      sb.append("<days>" + mdcArr[14] + "</days>");
				      sb.append("\n");
				      sb.append("<periodTitle>" + mdcArr[15] + "</periodTitle>");
				      sb.append("\n");
				      sb.append("<startTime>" + mdcArr[16] + "</startTime>");
				      sb.append("\n");
				      sb.append("<endTime>" + mdcArr[17] + "</endTime>");
				      sb.append("\n");
				      sb.append("</TimeTable>");	
				     }
				     String str= sb.toString();
						return str;
	} catch (Exception localException) {
		System.out.println(localException);
			localException.printStackTrace();
	   sb.append("<Response>");
	   sb.append("\n");
	   sb.append("<Result>");
	   sb.append("\n");
	   sb.append("Fail");
	   sb.append("\n");
	   sb.append("</Result>");
	   sb.append("\n");
	   sb.append("<Description>");
	   sb.append("could not inserted class info");
	   sb.append("</Description>");
	   sb.append("\n");
	   sb.append("<Exception>");
	   sb.append(localException);
	   sb.append("</Exception>");
	   sb.append("</Response>");
	    strg=sb.toString();
	   MDTransactionWriter.exceptionlog.info(localException);
	  if (tx!=null)
	   tx.rollback();
	  } finally {						  
	   rdSession.close(); 
	  }
	  return strg;
	 }

	@SuppressWarnings("rawtypes")
	public String addSchoolTimetables(AllClasses allclasses, SectionWeekdays sectionWeekdays,
			PeriodTimings periodTimings) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		String strg= null;
		StringBuffer sb= new StringBuffer();		
		StringBuffer sb2= new StringBuffer();
		StringBuffer sbPeriod= new StringBuffer();
		List<SectionDays> secdayList=sectionWeekdays.getSectionDays();
		List<Periods> periodsList=periodTimings.getPeriods();
		List<Classes> classList	=allclasses.getClasses();
		String secids = "";
		String ttids= "";
		String stime= "";
		String etime= "";
		String des= "";
		String pedtitle= "";
		String periods= "";
		String wkdy= "";
		// List sections = chart.getAllclasses().getClasses().get(i).getSections();
		// try {		
			 
				//tx = rdSession.beginTransaction();	
				Iterator i4=sd.iterator();
				boolean firstRecord=true;
				boolean firstPeriodRecord=true;
				//List<SectionWeekdays> secList = Arrays.asList(sd.split(","));
				List<SectionWeekdays> myList = new ArrayList<SectionWeekdays>();
				myList.spliterator();
				// Add items to List
				String s=myList.toString();
				System.out.println(s);
				String csv = s.substring(1, s.length() - 1).replace(", ", ",");
				System.out.println(csv);
				
				while(i4.hasNext()){
					SectionDays sds=(SectionDays) i4.next();					
					sds.getClassId();
					int classid=sds.getClassId();
					int sectionid=sds.getSectionId();
					int period=sds.getPeriods();
					String weekday=sds.getWeekday();
				}
				Iterator pedItr=periodsList.iterator();
				while(pedItr.hasNext())
				{
					Periods ped=(Periods)pedItr.next();
					if("".equalsIgnoreCase(stime)){
						stime+=ped.getStartTime();
						etime+=ped.getEndTime();
						des+=ped.getDescription();
						pedtitle+=ped.getPeriodTitle();
						}else{
					stime+=","+ped.getStartTime();
					etime+=","+ped.getEndTime();
					des+=","+ped.getDescription();
					pedtitle+=","+ped.getPeriodTitle();
						}
					/* stime=ped.getStartTime().toString().replaceAll(", ", ",");
					// stime.split(",");
					 etime=ped.getEndTime().toString().replaceAll(", ", ",");
					 des=ped.getDescription().toString().replaceAll(", ", ",");
					 pedtitle=ped.getPeriodTitle().toString().replaceAll(", ", ",");
					//Integer.toString(sec.getTimeTableId().replaceAll(",", ",");
				}
				Iterator wkdyItr=secdayList.iterator();
				while(wkdyItr.hasNext())
				{
					SectionDays sdays=(SectionDays)wkdyItr.next();
				
					if("".equalsIgnoreCase(periods)){
				
						periods+=sdays.getPeriods();
						wkdy+=sdays.getWeekday();
					}else{
					
					periods+=","+sdays.getPeriods();
					wkdy+=","+sdays.getWeekday();
					}
					 //periods=Integer.toString(sdays.getPeriods()).replaceAll(", ", ",");
					// wkdy=sdays.getWeekday().toString().replaceAll(", ", ",");
				//String sectionString=sectionsList.toString().replaceAll(", ", ",");
				
			}
				
				Iterator classItr=classList.iterator();
				while(classItr.hasNext())
				{
					secids="";
					ttids="";
					Classes classSelected=(Classes)classItr.next();
					int clsid=classSelected.getClassId();
					List sectionsList=classSelected.getSections();
					Iterator secItr=sectionsList.iterator();
				
					while(secItr.hasNext())
					{
						Section sec=(Section)secItr.next();
						if("".equalsIgnoreCase(secids)){
						 secids+=sec.getSectionId();
						 ttids+=sec.getTimeTableId();
						}else{
							secids+=","+sec.getSectionId();
							 ttids+=","+sec.getTimeTableId();
						}
							
							
					
				//	Iterator pedItr=periodsList.iterator();
					
			}
					
			Query icQuery=rdSession.createSQLQuery("CALL `timetable`('"+clsid+"', '"+secids+"', '"+periods+"', '"+wkdy+"',"
					+ " '"+stime+"', '"+etime+"', '"+pedtitle+"', '"+des+"', '"+ttids+"')");
			icQuery.executeUpdate();
				
				}
				tx.commit();
				sb.append("<status>periods created</status>");				
				strg= sb.toString();
				
										
						}
					 catch (Exception localException) {
							System.out.println(localException);
	 						localException.printStackTrace();
						   sb.append("<Response>");
						   sb.append("\n");
						   sb.append("<Result>");
						   sb.append("\n");
						   sb.append("Fail");
						   sb.append("\n");
						   sb.append("</Result>");
						   sb.append("\n");
						   sb.append("<Description>");
						   sb.append("could not inserted SchoolTimetables info");
						   sb.append("</Description>");
						   sb.append("\n");
						   sb.append("<Exception>");
						   sb.append(localException);
						   sb.append("</Exception>");
						   sb.append("</Response>");
						    strg=sb.toString();
						   MDTransactionWriter.exceptionlog.info(localException);
						  if (tx!=null)
						   tx.rollback();
						  } finally {						  
						   rdSession.close(); 
						  }
						  return strg;
						 }
	}


*/



