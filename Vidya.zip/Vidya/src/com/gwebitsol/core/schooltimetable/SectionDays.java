package com.gwebitsol.core.schooltimetable;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="day")
public class SectionDays {
	int sectionPeriodsId;
	int classId;
	int sectionId;
	int periods;
	String weekday;

	public int getSectionPeriodsId() {
		return sectionPeriodsId;
	}
	public void setSectionPeriodsId(int sectionPeriodsId) {
		this.sectionPeriodsId = sectionPeriodsId;
	}
	public int getClassId() {
		return classId;
	}
	public void setClassId(int classId) {
		this.classId = classId;
	}
	public int getSectionId() {
		return sectionId;
	}
	public void setSectionId(int sectionId) {
		this.sectionId = sectionId;
	}
	public int getPeriods() {
		return periods;
	}
	public void setPeriods(int periods) {
		this.periods = periods;
	}
	public String getWeekday() {
		return weekday;
	}
	public void setWeekday(String weekday) {
		this.weekday = weekday;
	}

}

	


