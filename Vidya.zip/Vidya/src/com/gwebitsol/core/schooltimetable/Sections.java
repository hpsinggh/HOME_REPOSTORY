package com.gwebitsol.core.schooltimetable;

import java.util.List;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="Sections")
public class Sections {

	List<Section> sections ;

	public List<Section> getSections() {
		return sections;
	}

	public void setSections(List<Section> sections) {
		this.sections = sections;
	}

}