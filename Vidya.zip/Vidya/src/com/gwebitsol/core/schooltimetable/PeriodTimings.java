package com.gwebitsol.core.schooltimetable;

import java.util.List;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="periodtimings")
public class PeriodTimings {
	private List<Periods> periods;

	public List<Periods> getPeriods() {
		return periods;
	}

	public void setPeriods(List<Periods> periods) {
		this.periods = periods;
	}


	
}
