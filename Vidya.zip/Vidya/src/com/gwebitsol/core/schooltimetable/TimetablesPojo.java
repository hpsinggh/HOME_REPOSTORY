package com.gwebitsol.core.schooltimetable;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement(name="Timetables")
public class TimetablesPojo {
	List<TimeTablePojo> timetable;

	public List<TimeTablePojo> getTimetable() {
		return timetable;
	}

	public void setTimetable(List<TimeTablePojo> timetable) {
		this.timetable = timetable;
	}
	
}
