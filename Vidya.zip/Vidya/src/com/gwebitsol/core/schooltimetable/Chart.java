package com.gwebitsol.core.schooltimetable;

import java.util.List;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="Chart")
public class Chart {
	AllClasses allclasses = new AllClasses();
	public AllClasses getAllclasses() {
		return allclasses;
	}

	public void setAllclasses(AllClasses allclasses) {
		this.allclasses = allclasses;
	}
	@XmlElementWrapper(name="Classes")
    @XmlElement(name="Class")
	public List<Classes> getClasses() {
		return allclasses.getClasses();
	}

	public void setClasses(List<Classes> classes) {
		allclasses.setClasses(classes);
	}
	
	//period timings
	
	PeriodTimings  periodTimings=new PeriodTimings();
	
	public PeriodTimings getPeriodTimings() {
		return periodTimings;
	}

	public void setPeriodTimings(PeriodTimings periodTimings) {
		this.periodTimings = periodTimings;
	}
	@XmlElementWrapper(name="periodtimings")
    @XmlElement(name="period")
	public List<Periods> getPeriods() {
		return periodTimings.getPeriods();
	}

	public void setPeriods(List<Periods> periods) {
		periodTimings.setPeriods(periods);
	}
	
	//weekdays
	SectionWeekdays  sectionWeekdays= new SectionWeekdays();
	
	public SectionWeekdays getSectionWeekdays() {
		return sectionWeekdays;
	}

	public void setSectionWeekdays(SectionWeekdays sectionWeekdays) {
		this.sectionWeekdays = sectionWeekdays;
	}
	@XmlElementWrapper(name="weekdays")
    @XmlElement(name="day")
	public List<SectionDays> getSectionDays() {
		return sectionWeekdays.getSectionDays();
	}

	public void setSectionDays(List<SectionDays> sectionDays) {
		sectionWeekdays.setSectionDays(sectionDays);
	}

} 
