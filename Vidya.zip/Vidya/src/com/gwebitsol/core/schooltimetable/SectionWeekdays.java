package com.gwebitsol.core.schooltimetable;

import java.util.List;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="weekdays")
public class SectionWeekdays {

		List<SectionDays> sectionDays;

		public List<SectionDays> getSectionDays() {
			return sectionDays;
		}

		public void setSectionDays(List<SectionDays> sectionDays) {
			this.sectionDays = sectionDays;
		}


	
}
