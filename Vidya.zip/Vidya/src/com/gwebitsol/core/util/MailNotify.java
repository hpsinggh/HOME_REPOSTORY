package com.gwebitsol.core.util;

import java.io.File;
import java.util.StringTokenizer;

public class MailNotify extends Thread
{

    public MailNotify()
    {
        html = false;
    }

    public void run()
    {
       
        SmtpMail smtpmail = new SmtpMail();
        if(smtpmail.open(host, port) == 1)
        {
            smtpmail.setDomain(domain);
            smtpmail.setFrom(from);
            smtpmail.setTo(to);
            if(user != null && password != null)
            {
                smtpmail.setUser(user);
                smtpmail.setPassword(password);
            }
            if(cc != null)
                smtpmail.setCc(cc);
            if(bcc != null)
                smtpmail.setBcc(bcc);
            if(subject != null)
                smtpmail.addHeader("Subject", subject);
            if(html)
                smtpmail.addHeader("Content-Type", "text/html");
            if(content != null)
                smtpmail.addData(content);
            if(attach != null)
            {
                for(StringTokenizer stringtokenizer = new StringTokenizer(attach, ","); stringtokenizer.hasMoreTokens();)
                {
                    String s = stringtokenizer.nextToken().trim();
                    File file = new File(s);
                    if(file.isFile() && file.canRead())
                        smtpmail.addAttachment(s);
                }

            }
            smtpmail.transmit();
            smtpmail.close();
        }
    }

    public void setAttach(String s)
    {
        attach = s;
    }

    public void setBcc(String s)
    {
        bcc = s;
    }

    public void setCc(String s)
    {
        cc = s;
    }

    public void setContent(String s)
    {
        content = s;
    }

    public void setDomain(String s)
    {
        domain = s;
    }

    public void setFrom(String s)
    {
        from = s;
    }

    public void setHost(String s)
    {
        host = s;
    }

    public void setHtml()
    {
        html = true;
    }

    public void setPassword(String s)
    {
        password = s;
    }

    public void setPort(int i)
    {
        port = i;
    }

    public void setSubject(String s)
    {
        subject = s;
    }

    public void setTo(String s)
    {
        to = s;
    }

    public void setUser(String s)
    {
        user = s;
    }

    private int port;
    private String host;
    private String domain;
    private String from;
    private String user;
    private String password;
    private String to;
    private String cc;
    private String bcc;
    private boolean html;
    private String subject;
    private String content;
    private String attach;
}