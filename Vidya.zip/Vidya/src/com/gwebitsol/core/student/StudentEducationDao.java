//Vidya Version 0.8
package com.gwebitsol.core.student;

import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.gwebitsol.core.address.AddressPojo;
import com.gwebitsol.core.parent.ParentPojo;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

@Repository
@Component
public class StudentEducationDao {

	StringBuffer StudentID = new StringBuffer();

	public String addStudentEducation(StudentEducationPojo pp) {

		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String studentedureg = null;
		try {
			rdTx = rdSession.beginTransaction();

			Integer studenteduid = (Integer) rdSession.save(pp);

			rdTx.commit();
			StudentID.append("<StudentEducation>");
			StudentID.append("\n");
			StudentID.append("<id>");
			StudentID.append("\n");
			StudentID.append(studenteduid);
			StudentID.append("</id>");
			StudentID.append("\n");
			StudentID.append("</StudentEducation>");
			studentedureg = StudentID.toString();
		} catch (Exception localException) {
			localException.printStackTrace();
			System.out.println(localException);

			StudentID.append("<Response>");
			StudentID.append("\n");
			StudentID.append("<Result>");
			StudentID.append("\n");
			StudentID.append("Fail");
			StudentID.append("\n");
			StudentID.append("</Result>");
			StudentID.append("\n");
			StudentID.append("<Description>");
			StudentID.append("could not inserted studenteducation info");
			StudentID.append("</Description>");
			StudentID.append("\n");
			StudentID.append("<Exception>");
			StudentID.append(localException);
			StudentID.append("</Exception>");
			StudentID.append("</Response>");

			studentedureg = StudentID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		} finally {
			rdSession.close();
		}
		return studentedureg;
	}

	public String updateStudentEducation(StudentEducationPojo pp,int schoolid,int branchid) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String studentedureg = null;

		try {
			rdTx = rdSession.beginTransaction();
			
			/*	String vcSql="select StudentEdId from gbl_sm_tbl_student_education where StudentEdId="+pp.getStudentEdId();
			int Stedid =(Integer)rdSession.createSQLQuery(vcSql).uniqueResult();
			*/
			StudentEducationPojo mdclpojo = (StudentEducationPojo) rdSession.get(StudentEducationPojo.class,pp.getStudentEdId());
			
			if(branchid==mdclpojo.getBranchId()&&schoolid==mdclpojo.getSchoolId())
				
			rdSession.evict(mdclpojo);
				
			rdSession.update(pp);		
			rdTx.commit();
			studentedureg = "studentEducation is succssfully updated";
			StudentID.append("<StudentEducationPojo>");
			StudentID.append("\n");
			StudentID.append(studentedureg);
			StudentID.append("</StudentEducationPojo>");
			String str = StudentID.toString();
			return str;
		} catch (Exception localException) {
			localException.printStackTrace();
			System.out.println(localException);

			StudentID.append("<Response>");
			StudentID.append("\n");
			StudentID.append("<Result>");
			StudentID.append("\n");
			StudentID.append("Fail");
			StudentID.append("\n");
			StudentID.append("</Result>");
			StudentID.append("\n");
			StudentID.append("<Description>");
			StudentID.append("could not updated studenteducation info");
			StudentID.append("</Description>");
			StudentID.append("\n");
			StudentID.append("<Exception>");
			StudentID.append(localException);
			StudentID.append("</Exception>");
			StudentID.append("</Response>");

			studentedureg = StudentID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();

		} finally {
			rdSession.close();
		}
		return studentedureg;
	}

	public String deleteStudentEducation(int studentEdId,int schoolid,int branchid) {

		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String studentedureg = null;

		try {
			rdTx = rdSession.beginTransaction();
			
			StudentEducationPojo mdclpojo = (StudentEducationPojo) rdSession.get(StudentEducationPojo.class,studentEdId);
			
			rdSession.evict(mdclpojo);
			
			if(branchid==mdclpojo.getBranchId()&&schoolid==mdclpojo.getSchoolId())
			{
			Query empQuery=rdSession.createSQLQuery("update gbl_sm_tbl_student_education set isDeleted='y' where StudentEdId='"+studentEdId+"'");
			empQuery.executeUpdate();
			rdTx.commit();
			studentedureg = "studenteducation is succssfully deleted";
			StudentID.append("<StudentEducation>");
			StudentID.append("\n");
			StudentID.append(studentedureg);
			StudentID.append("</StudentEducation>");
			String str = StudentID.toString();
			return str;
			}
			else
			{
				studentedureg = "studenteducation is not deleted";
				StudentID.append("<StudentEducation>");
				StudentID.append("\n");
				StudentID.append(studentedureg);
				StudentID.append("</StudentEducation>");
			    String str = StudentID.toString();
			    return str;
			}
		} catch (Exception localException) {
			localException.printStackTrace();
			System.out.println(localException);

			StudentID.append("<Response>");
			StudentID.append("\n");
			StudentID.append("<Result>");
			StudentID.append("\n");
			StudentID.append("Fail");
			StudentID.append("\n");
			StudentID.append("</Result>");
			StudentID.append("\n");
			StudentID.append("<Description>");
			StudentID.append("could not deleted studenteducation info");
			StudentID.append("</Description>");
			StudentID.append("\n");
			StudentID.append("<Exception>");
			StudentID.append(localException);
			StudentID.append("</Exception>");
			StudentID.append("</Response>");

			studentedureg = StudentID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		} finally {
			rdSession.close();
		}
		return studentedureg;
	}

	public String getStudentEducationByStudentId(int studentId, int schoolid,int branchid) {

		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String studentedureg = null;
		String gsSql = null;
		try {
			
			rdTx = rdSession.beginTransaction();

			gsSql="select gbl_sm_tbl_student_education.*, gbl_sm_tbl_student.StudentNumber, gbl_sm_tbl_student.FirstName,"
		                        +" gbl_sm_tbl_student.MiddleName,gbl_sm_tbl_student.LastName,gbl_sm_tbl_class.ClassName,"
								+" gbl_sm_tbl_section.SectionName, gbl_sm_tbl_result.ResultName,gbl_sm_tbl_grade.GradeName"
		                        +" from gbl_sm_tbl_student_education"
								+" join gbl_sm_tbl_student on  gbl_sm_tbl_student_education.StudentId = gbl_sm_tbl_student.StudentId"
		                        +" join gbl_sm_tbl_class on gbl_sm_tbl_student_education.ClassId=gbl_sm_tbl_class.ClassId"
								+" join gbl_sm_tbl_section on gbl_sm_tbl_student_education.SectionId=gbl_sm_tbl_section.SectionId"
		                        +" join gbl_sm_tbl_result on gbl_sm_tbl_student_education.ResultId = gbl_sm_tbl_result.ResultId"
								+" join gbl_sm_tbl_grade on gbl_sm_tbl_student_education.GradeId= gbl_sm_tbl_grade.GradeId "
								+" where gbl_sm_tbl_student_education.IsDeleted is null and gbl_sm_tbl_student_education.StudentId ='"+studentId+"' and gbl_sm_tbl_student_education.SchoolId='"+schoolid+"' and gbl_sm_tbl_student_education.BranchId='"+branchid+"';";
								
		
			Query gsQuery=rdSession.createSQLQuery(gsSql);
			List gcList=gsQuery.list();
			Iterator gsIT=gcList.iterator();
				while(gsIT.hasNext())
				{
					Object[] mdcArr=(Object[])gsIT.next();
					StudentID.append("<studenteducation>");
					StudentID.append("\n");
					StudentID.append("<studentEdId>"+mdcArr[0]+"</studentEdId>");
					StudentID.append("\n");
					StudentID.append("<studentId>" + mdcArr[1]+ "</studentId>");
					StudentID.append("\n");
					StudentID.append("<studentNumber>" +  mdcArr[17]+ "</studentNumber>");
					StudentID.append("\n");
					StudentID.append("<studentFirstName>" +  mdcArr[18]+ "</studentFirstName>");
					StudentID.append("\n");
					StudentID.append("<studentMiddleName>" +  mdcArr[19]+ "</studentMiddleName>");
					StudentID.append("\n");
					StudentID.append("<studentLastName>" +  mdcArr[20]+ "</studentLastName>");
					StudentID.append("\n");
					StudentID.append("<classId>" + mdcArr[2]+ "</classId>");
					StudentID.append("\n");
					StudentID.append("<className>" +  mdcArr[21]+ "</className>");
					StudentID.append("\n");
					StudentID.append("<sectionId>" + mdcArr[3] + "</sectionId>");
					StudentID.append("\n");
					StudentID.append("<sectionName>" +  mdcArr[22]+ "</sectionName>");
					StudentID.append("\n");
					StudentID.append("<resultId>" + mdcArr[4]+ "</resultId>");
					StudentID.append("\n");
					StudentID.append("<resultName>" + mdcArr[23]+ "</resultName>");
					StudentID.append("\n");
					StudentID.append("<gradeId>" + mdcArr[5] + "</gradeId>");
					StudentID.append("\n");
					StudentID.append("<gradeName>" + mdcArr[24]+ "</gradeName>");
					StudentID.append("\n");
					StudentID.append("<schoolName>" +  mdcArr[6]+ "</schoolName>");
					StudentID.append("\n");
					StudentID.append("<studiedFrom>" + mdcArr[7] + "</studiedFrom>");
					StudentID.append("\n");
					StudentID.append("<studiedTo>" + mdcArr[8] + "</studiedTo>");
					StudentID.append("\n");
					StudentID.append("<percentScore>" + mdcArr[9] + "</percentScore>");
					StudentID.append("\n");
					StudentID.append("<currentFlg>" + mdcArr[10] + "</currentFlg>");
					StudentID.append("\n");
					StudentID.append("<remarks>" + mdcArr[11] + "</remarks>");
					StudentID.append("\n");
					StudentID.append("<createdDate>" + mdcArr[12]+ "</createdDate>");
					StudentID.append("\n");
					StudentID.append("<modifiedDate>" +  mdcArr[13]+ "</modifiedDate>");
					StudentID.append("\n");
					StudentID.append("<schoolId>" +  mdcArr[14]+ "</schoolId>");
					StudentID.append("\n");
					StudentID.append("<branchId>" +  mdcArr[15]+ "</branchId>");
					StudentID.append("\n");
					StudentID.append("<isDeleted>" +  mdcArr[16]+ "</isDeleted>");
					StudentID.append("\n");
	     			StudentID.append("</studenteducation>");
					StudentID.append("\n");
			}
			rdTx.commit();
			studentedureg=StudentID.toString();
		} catch (HibernateException localException) {
			localException.printStackTrace();
			System.out.println(localException);

			StudentID.append("<Response>");
			StudentID.append("\n");
			StudentID.append("<Result>");
			StudentID.append("\n");
			StudentID.append("Fail");
			StudentID.append("\n");
			StudentID.append("</Result>");
			StudentID.append("\n");
			StudentID.append("<Description>");
			StudentID.append("could not get studenteducation info");
			StudentID.append("</Description>");
			StudentID.append("\n");
			StudentID.append("<Exception>");
			StudentID.append(localException);
			StudentID.append("</Exception>");
			StudentID.append("</Response>");

			studentedureg = StudentID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		} finally {
			rdSession.close();
		}
		return studentedureg;
	}

	
public String getStudentEducationByStuEduId(int studentEdId, int studentId, int schoolid, int branchid) {
	Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
	Transaction rdTx = null;
	String studentedureg = null;
	String gsSql = null;
	try {
		
		rdTx = rdSession.beginTransaction();

		gsSql="select gbl_sm_tbl_student_education.*, gbl_sm_tbl_student.StudentNumber, gbl_sm_tbl_student.FirstName,"
	                        +" gbl_sm_tbl_student.MiddleName,gbl_sm_tbl_student.LastName,gbl_sm_tbl_class.ClassName,"
							+" gbl_sm_tbl_section.SectionName, gbl_sm_tbl_result.ResultName,gbl_sm_tbl_grade.GradeName"
	                        +" from gbl_sm_tbl_student_education"
							+" join gbl_sm_tbl_student on  gbl_sm_tbl_student_education.StudentId = gbl_sm_tbl_student.StudentId"
	                        +" join gbl_sm_tbl_class on gbl_sm_tbl_student_education.ClassId=gbl_sm_tbl_class.ClassId"
							+" join gbl_sm_tbl_section on gbl_sm_tbl_student_education.SectionId=gbl_sm_tbl_section.SectionId"
	                        +" join gbl_sm_tbl_result on gbl_sm_tbl_student_education.ResultId = gbl_sm_tbl_result.ResultId"
							+" join gbl_sm_tbl_grade on gbl_sm_tbl_student_education.GradeId= gbl_sm_tbl_grade.GradeId "
							+" where gbl_sm_tbl_student_education.IsDeleted is null and gbl_sm_tbl_student_education.StudentId ='"+studentId+"' and gbl_sm_tbl_student_education.StudentEdId='"+studentEdId+"' and gbl_sm_tbl_student_education.SchoolId='"+schoolid+"' and gbl_sm_tbl_student_education.BranchId='"+branchid+"';";
							
		Query gsQuery=rdSession.createSQLQuery(gsSql);
		List gcList=gsQuery.list();
		Iterator gsIT=gcList.iterator();
			while(gsIT.hasNext())
			{
				Object[] mdcArr=(Object[])gsIT.next();
				StudentID.append("<studenteducation>");
				StudentID.append("\n");
				StudentID.append("<studentEdId>"+mdcArr[0]+"</studentEdId>");
				StudentID.append("\n");
				StudentID.append("<studentId>" + mdcArr[1]+ "</studentId>");
				StudentID.append("\n");
				StudentID.append("<studentNumber>" +  mdcArr[17]+ "</studentNumber>");
				StudentID.append("\n");
				StudentID.append("<studentFirstName>" +  mdcArr[18]+ "</studentFirstName>");
				StudentID.append("\n");
				StudentID.append("<studentMiddleName>" +  mdcArr[19]+ "</studentMiddleName>");
				StudentID.append("\n");
				StudentID.append("<studentLastName>" +  mdcArr[20]+ "</studentLastName>");
				StudentID.append("\n");
				StudentID.append("<classId>" + mdcArr[2]+ "</classId>");
				StudentID.append("\n");
				StudentID.append("<className>" +  mdcArr[21]+ "</className>");
				StudentID.append("\n");
				StudentID.append("<sectionId>" + mdcArr[3] + "</sectionId>");
				StudentID.append("\n");
				StudentID.append("<sectionName>" +  mdcArr[22]+ "</sectionName>");
				StudentID.append("\n");
				StudentID.append("<resultId>" + mdcArr[4]+ "</resultId>");
				StudentID.append("\n");
				StudentID.append("<resultName>" + mdcArr[23]+ "</resultName>");
				StudentID.append("\n");
				StudentID.append("<gradeId>" + mdcArr[5] + "</gradeId>");
				StudentID.append("\n");
				StudentID.append("<gradeName>" + mdcArr[24]+ "</gradeName>");
				StudentID.append("\n");
				StudentID.append("<schoolName>" +  mdcArr[6]+ "</schoolName>");
				StudentID.append("\n");
				StudentID.append("<studiedFrom>" + mdcArr[7] + "</studiedFrom>");
				StudentID.append("\n");
				StudentID.append("<studiedTo>" + mdcArr[8] + "</studiedTo>");
				StudentID.append("\n");
				StudentID.append("<percentScore>" + mdcArr[9] + "</percentScore>");
				StudentID.append("\n");
				StudentID.append("<currentFlg>" + mdcArr[10] + "</currentFlg>");
				StudentID.append("\n");
				StudentID.append("<remarks>" + mdcArr[11] + "</remarks>");
				StudentID.append("\n");
				StudentID.append("<createdDate>" + mdcArr[12]+ "</createdDate>");
				StudentID.append("\n");
				StudentID.append("<modifiedDate>" +  mdcArr[13]+ "</modifiedDate>");
				StudentID.append("\n");
				StudentID.append("<schoolId>" +  mdcArr[14]+ "</schoolId>");
				StudentID.append("\n");
				StudentID.append("<branchId>" +  mdcArr[15]+ "</branchId>");
				StudentID.append("\n");
				StudentID.append("<isDeleted>" +  mdcArr[16]+ "</isDeleted>");
				StudentID.append("\n");
     			StudentID.append("</studenteducation>");
				StudentID.append("\n");
		}
		rdTx.commit();
		studentedureg=StudentID.toString();
	} catch (HibernateException localException) {
		localException.printStackTrace();
		System.out.println(localException);

		StudentID.append("<Response>");
		StudentID.append("\n");
		StudentID.append("<Result>");
		StudentID.append("\n");
		StudentID.append("Fail");
		StudentID.append("\n");
		StudentID.append("</Result>");
		StudentID.append("\n");
		StudentID.append("<Description>");
		StudentID.append("could not get studenteducation info");
		StudentID.append("</Description>");
		StudentID.append("\n");
		StudentID.append("<Exception>");
		StudentID.append(localException);
		StudentID.append("</Exception>");
		StudentID.append("</Response>");

		studentedureg = StudentID.toString();
		MDTransactionWriter.exceptionlog.info(localException);
		if (rdTx != null)
			rdTx.rollback();
	} finally {
		rdSession.close();
	}
	return studentedureg;
	}

	public String getAllStudentPerSection(int sectionid,int classid, int schoolid,int branchid) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String studentreg = null;
		StudentPojo par = null;
		StudentPojo pp = null;
		String query=null;
		
		try {
			
			rdTx = rdSession.beginTransaction();

			if(classid==0)
			{
			query = "select gbl_sm_tbl_student.StudentId , gbl_sm_tbl_student.FirstName , gbl_sm_tbl_student.MiddleName, gbl_sm_tbl_student.LastName, gbl_sm_tbl_student.StudentNumber "
					+ "from gbl_sm_tbl_student where gbl_sm_tbl_student_education.IsDeleted is null and StudentId in "
					+ "(select StudentId from gbl_sm_tbl_student_education where SectionId='" + sectionid
					+ "' and gbl_sm_tbl_student_education.SchoolId='" + schoolid
					+ "' and gbl_sm_tbl_student_education.BranchId='" + branchid + "');";	

			}
			else
			{
				query = "select gbl_sm_tbl_student.StudentId , gbl_sm_tbl_student.FirstName , gbl_sm_tbl_student.MiddleName, gbl_sm_tbl_student.LastName, gbl_sm_tbl_student.StudentNumber "
						+ "from gbl_sm_tbl_student where gbl_sm_tbl_student_education.IsDeleted is null and StudentId in "
						+ "(select StudentId from gbl_sm_tbl_student_education where SectionId='" + sectionid
						+ "' and ClassId='"+classid+"' and gbl_sm_tbl_student_education.SchoolId='" + schoolid
						+ "' and gbl_sm_tbl_student_education.BranchId='" + branchid + "');";	

			}
			List<StudentPojo> list = rdSession.createSQLQuery(query).list();

			Iterator gtempIT = list.iterator();

			System.out.println(list);
			StudentID.append("<Student>");
		
			while (gtempIT.hasNext()) {
				Object[] stu = (Object[]) gtempIT.next();

				if (stu == null) {
					System.out.println("there is no student object");
				} else {
					StudentID.append("<studentID>" + stu[0] + "</studentID>");
					StudentID.append("\n");
					StudentID.append("<firstName>" + stu[1] + "</firstName>");
					StudentID.append("\n");
					StudentID.append("<middleName>" + stu[2] + "</middleName>");
					StudentID.append("\n");
					StudentID.append("<lastName>" + stu[3] + "</lastName>");
					StudentID.append("\n");
					StudentID.append("<studentNumber>" + stu[4] + "</studentNumber>");
					StudentID.append("\n");
					
				}
			}
			StudentID.append("</Student>");
			rdTx.commit();
			String str = StudentID.toString();

			return str;
		} catch (HibernateException localException) {
			localException.printStackTrace();
			System.out.println(localException);

			StudentID.append("<Response>");
			StudentID.append("\n");
			StudentID.append("<Result>");
			StudentID.append("\n");
			StudentID.append("Fail");
			StudentID.append("\n");
			StudentID.append("</Result>");
			StudentID.append("\n");
			StudentID.append("<Description>");
			StudentID.append("could not get all student info");
			StudentID.append("</Description>");
			StudentID.append("\n");
			StudentID.append("<Exception>");
			StudentID.append(localException);
			StudentID.append("</Exception>");
			StudentID.append("</Response>");

			studentreg = StudentID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		} finally {
			rdSession.close();
		}
		return studentreg;
	}

	@SuppressWarnings("unused")
	public String getAllStuEdu(int PNO, int size, int schoolid,int branchid) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String xmlString=null;
	//	Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
	//	Transaction stgTx=null;
	
		try
		{
			rdTx=rdSession.beginTransaction();
			
				int fset = (PNO-1)*size;
				String gsSql ="select count(*) from gbl_sm_tbl_student_education where gbl_sm_tbl_student_education.IsDeleted is null and gbl_sm_tbl_student_education.SchoolId='"
						+ schoolid + "' and gbl_sm_tbl_student_education.BranchId='" + branchid + "';";
				Query gsQuery=rdSession.createSQLQuery(gsSql);
				Object noRecords= gsQuery.uniqueResult();
				
				int intNoRecords=0;
				   if(noRecords!=null && Integer.parseInt(noRecords.toString())!=0)
				   {
				    intNoRecords=Integer.parseInt(noRecords.toString());
				   }
				   
				StudentID.append("<studenteducations>");
				StudentID.append("\n");
				StudentID.append("<noRecords>"+noRecords+"</noRecords>");
				StudentID.append("\n");
				 if(intNoRecords!=0)
				   {
					if (PNO > 0 & size > 0){
					gsSql="select gbl_sm_tbl_student_education.*, gbl_sm_tbl_student.StudentNumber, gbl_sm_tbl_student.FirstName,"
                        +" gbl_sm_tbl_student.MiddleName,gbl_sm_tbl_student.LastName,gbl_sm_tbl_class.ClassName,"
						+" gbl_sm_tbl_section.SectionName, gbl_sm_tbl_result.ResultName,gbl_sm_tbl_grade.GradeName"
                        +" from gbl_sm_tbl_student_education"
						+" join gbl_sm_tbl_student on  gbl_sm_tbl_student_education.StudentId = gbl_sm_tbl_student.StudentId"
                        +" join gbl_sm_tbl_class on gbl_sm_tbl_student_education.ClassId=gbl_sm_tbl_class.ClassId"
						+" join gbl_sm_tbl_section on gbl_sm_tbl_student_education.SectionId=gbl_sm_tbl_section.SectionId"
                        +" join gbl_sm_tbl_result on gbl_sm_tbl_student_education.ResultId = gbl_sm_tbl_result.ResultId"
						+" join gbl_sm_tbl_grade on gbl_sm_tbl_student_education.GradeId= gbl_sm_tbl_grade.GradeId limit "
						+" where gbl_sm_tbl_student_education.IsDeleted is null and gbl_sm_tbl_student_education.SchoolId='"+schoolid+"' and gbl_sm_tbl_student_education.BranchId='"+branchid+"' limit "+size+" offset "+fset+" ;";
					
					}
					else {
						gsSql="select gbl_sm_tbl_student_education.*, gbl_sm_tbl_student.StudentNumber, gbl_sm_tbl_student.FirstName,"
		                        +" gbl_sm_tbl_student.MiddleName,gbl_sm_tbl_student.LastName,gbl_sm_tbl_class.ClassName,"
								+" gbl_sm_tbl_section.SectionName, gbl_sm_tbl_result.ResultName,gbl_sm_tbl_grade.GradeName"
		                        +" from gbl_sm_tbl_student_education"
								+" join gbl_sm_tbl_student on  gbl_sm_tbl_student_education.StudentId = gbl_sm_tbl_student.StudentId"
		                        +" join gbl_sm_tbl_class on gbl_sm_tbl_student_education.ClassId=gbl_sm_tbl_class.ClassId"
								+" join gbl_sm_tbl_section on gbl_sm_tbl_student_education.SectionId=gbl_sm_tbl_section.SectionId"
		                        +" join gbl_sm_tbl_result on gbl_sm_tbl_student_education.ResultId = gbl_sm_tbl_result.ResultId"
								+" join gbl_sm_tbl_grade on gbl_sm_tbl_student_education.GradeId= gbl_sm_tbl_grade.GradeId "
								+" where gbl_sm_tbl_student_education.IsDeleted is null and gbl_sm_tbl_student_education.SchoolId='"+schoolid+"' and gbl_sm_tbl_student_education.BranchId='"+branchid+"';";
						
					}	
			
				gsQuery=rdSession.createSQLQuery(gsSql);
				List gcList=gsQuery.list();
				Iterator gsIT=gcList.iterator();
					while(gsIT.hasNext())
					{
						Object[] mdcArr=(Object[])gsIT.next();
						StudentID.append("<studenteducation>");
						StudentID.append("\n");
						StudentID.append("<studentEdId>"+mdcArr[0]+"</studentEdId>");
						StudentID.append("\n");
						StudentID.append("<studentId>" + mdcArr[1]+ "</studentId>");
						StudentID.append("\n");
						StudentID.append("<studentNumber>" +  mdcArr[17]+ "</studentNumber>");
						StudentID.append("\n");
						StudentID.append("<studentFirstName>" +  mdcArr[18]+ "</studentFirstName>");
						StudentID.append("\n");
						StudentID.append("<studentMiddleName>" +  mdcArr[19]+ "</studentMiddleName>");
						StudentID.append("\n");
						StudentID.append("<studentLastName>" +  mdcArr[20]+ "</studentLastName>");
						StudentID.append("\n");
						StudentID.append("<classId>" + mdcArr[2]+ "</classId>");
						StudentID.append("\n");
						StudentID.append("<className>" +  mdcArr[21]+ "</className>");
						StudentID.append("\n");
						StudentID.append("<sectionId>" + mdcArr[3] + "</sectionId>");
						StudentID.append("\n");
						StudentID.append("<sectionName>" +  mdcArr[22]+ "</sectionName>");
						StudentID.append("\n");
						StudentID.append("<resultId>" + mdcArr[4]+ "</resultId>");
						StudentID.append("\n");
						StudentID.append("<resultName>" + mdcArr[23]+ "</resultName>");
						StudentID.append("\n");
						StudentID.append("<gradeId>" + mdcArr[5] + "</gradeId>");
						StudentID.append("\n");
						StudentID.append("<gradeName>" + mdcArr[24]+ "</gradeName>");
						StudentID.append("\n");
						StudentID.append("<schoolName>" +  mdcArr[6]+ "</schoolName>");
						StudentID.append("\n");
						StudentID.append("<studiedFrom>" + mdcArr[7] + "</studiedFrom>");
						StudentID.append("\n");
						StudentID.append("<studiedTo>" + mdcArr[8] + "</studiedTo>");
						StudentID.append("\n");
						StudentID.append("<percentScore>" + mdcArr[9] + "</percentScore>");
						StudentID.append("\n");
						StudentID.append("<currentFlg>" + mdcArr[10] + "</currentFlg>");
						StudentID.append("\n");
						StudentID.append("<remarks>" + mdcArr[11] + "</remarks>");
						StudentID.append("\n");
						StudentID.append("<createdDate>" + mdcArr[12]+ "</createdDate>");
						StudentID.append("\n");
						StudentID.append("<modifiedDate>" +  mdcArr[13]+ "</modifiedDate>");
						StudentID.append("\n");
						StudentID.append("<schoolId>" +  mdcArr[14]+ "</schoolId>");
						StudentID.append("\n");
						StudentID.append("<branchId>" +  mdcArr[15]+ "</branchId>");
						StudentID.append("\n");
						StudentID.append("<isDeleted>" +  mdcArr[16]+ "</isDeleted>");
						StudentID.append("\n");
		     			StudentID.append("</studenteducation>");
						StudentID.append("\n");
					}
				   }
				rdTx.commit();
				StudentID.append("</studenteducations>");
				StudentID.append("\n");

				xmlString=StudentID.toString();
			}
			
		catch(Exception localException)
		{
			localException.printStackTrace();
			System.out.println(localException);

			StudentID.append("<Response>");
			StudentID.append("\n");
			StudentID.append("<Result>");
			StudentID.append("\n");
			StudentID.append("Fail");
			StudentID.append("\n");
			StudentID.append("</Result>");
			StudentID.append("\n");
			StudentID.append("<Description>");
			StudentID.append("could not get studenteducation info");
			StudentID.append("</Description>");
			StudentID.append("\n");
			StudentID.append("<Exception>");
			StudentID.append(localException);
			StudentID.append("</Exception>");
			StudentID.append("</Response>");

			xmlString = StudentID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		}
		finally
		{
			rdSession.close();
		}	
		return xmlString;
	}

	
}