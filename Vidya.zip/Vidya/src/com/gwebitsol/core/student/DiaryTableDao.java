package com.gwebitsol.core.student;

import java.util.Iterator;
import java.util.List;
import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class DiaryTableDao {
		
		public String addDiaryTable(DiaryTablePojo diaryTablePojo) {
			Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
			Transaction tx = null;
			String strg= null;
			String academicYear = null;
			 StringBuffer sb= new StringBuffer();
			 try {
					tx = rdSession.beginTransaction();
					String acayear=diaryTablePojo.getAcademicYear();
				
					String classIds="";
					String sectionIds="";
					
					String studentIds=diaryTablePojo.getStudentId();
					
					if(studentIds==null || "".equalsIgnoreCase(studentIds))
					{
						if(diaryTablePojo.getSectionIds()!=null && !"".equalsIgnoreCase(diaryTablePojo.getSectionIds())){
							sectionIds+=diaryTablePojo.getSectionIds();
						}else{
						if(diaryTablePojo.getClassIds() != null && !"".equalsIgnoreCase(diaryTablePojo.getClassIds())){
							classIds+=diaryTablePojo.getClassIds();
						}else{
							classIds=(String)rdSession.createSQLQuery("SELECT GROUP_CONCAT(DISTINCT classid ORDER BY classid) as classIds FROM gbl_sm_tbl_class where (IsDeleted<>'y' or IsDeleted is null) and BranchId = '"+diaryTablePojo.getBranchId()+"' and SchoolId = '"+diaryTablePojo.getSchoolId()+"'").addScalar("classIds", Hibernate.STRING).uniqueResult();
							
						}
						sectionIds=(String)rdSession.createSQLQuery("SELECT GROUP_CONCAT(DISTINCT sectionid ORDER BY sectionid) as sectionIds FROM gbl_sm_tbl_section where (IsDeleted<>'y' or IsDeleted is null) and classid in ("+classIds+") and BranchId = '"+diaryTablePojo.getBranchId()+"' and SchoolId = '"+diaryTablePojo.getSchoolId()+"'").addScalar("sectionIds", Hibernate.STRING).uniqueResult();
						}
					
					studentIds=(String)rdSession.createSQLQuery("SELECT GROUP_CONCAT(DISTINCT studentid ORDER BY studentid) as studentIds FROM gbl_sm_tbl_student_education where (IsDeleted<>'y' or IsDeleted is null) and currentflg='active' and sectionid in("+sectionIds+") and BranchId = '"+diaryTablePojo.getBranchId()+"' and SchoolId = '"+diaryTablePojo.getSchoolId()+"'").addScalar("studentIds", Hibernate.STRING).uniqueResult();
					
					}
					if(studentIds!=null && !"".equalsIgnoreCase(studentIds))
					{
						String title=diaryTablePojo.getTitle();
					String acadamicyear=diaryTablePojo.getAcademicYear();
					String status=diaryTablePojo.getStatus();
					int sclid=diaryTablePojo.getSchoolId();
					int brnid=diaryTablePojo.getBranchId();
					/*List studentId=(List) rdSession.createSQLQuery("SELECT StudentId,AcademicYear,status FROM gbl_sm_tbl_diarytable where (isDeleted<>'y' or isDeleted is null) and status='active'").uniqueResult();
					if(studentIds.equals(studentId)&&acadamicyear.equals(studentId)&&status.equals(studentId)){						
					}*/
					
					//List list1 = studentId.spl
					Query icQuery=rdSession.createSQLQuery("CALL `diarytable`('"+studentIds+"', '"+title+"', '"+acadamicyear+"', '"+status+"',"
							+ " '"+sclid+"', '"+brnid+"')");
					icQuery.executeUpdate();
					}
					tx.commit();
					
					 //String insertQuery=
					    /*Iterator gsIT=gcList.iterator();
					
					
						  Query empQuery=rdSession.createSQLQuery("update gbl_sm_tbl_diarytable set status='inactive' where academicYear='"+academicYear+"'");
						   empQuery.executeUpdate();
						   //Query empQuery=rdSession.createSQLQuery("update gbl_sm_tbl_diarytable set status='inactive' where academicYear='"+academicYear+"'");
						   empQuery.executeUpdate();
						   tx.commit();*/
					
					sb.append("<diaryTable>");
					sb.append("\n");
					sb.append("students diaryTable is created");
					sb.append("\n");
					sb.append("</diaryTable>");
					strg= sb.toString();
			 		}		
			 			catch (Exception localException){
			 						System.out.println(localException);
			 						localException.printStackTrace();
								   sb.append("<Response>");
								   sb.append("\n");
								   sb.append("<Result>");
								   sb.append("\n");
								   sb.append("Fail");
								   sb.append("\n");
								   sb.append("</Result>");
								   sb.append("\n");
								   sb.append("<Description>");
								   sb.append("could not inserted diaryTable info");
								   sb.append("</Description>");
								   sb.append("\n");
								   sb.append("<Exception>");
								   sb.append(localException);
								   sb.append("</Exception>");
								   sb.append("</Response>");
								    strg=sb.toString();
								   MDTransactionWriter.exceptionlog.info(localException);
								  if (tx!=null)
								   tx.rollback();
								  } finally {
								   rdSession.close(); 
								  }
								  return strg;
								 }
			
		public String deleteDiaryTable(int diarytableId,int schoolId,int branchId) {
			Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
			Transaction tx = null;
			StringBuffer sb=new StringBuffer();
			String strg= null;
			
			try {
					tx = rdSession.beginTransaction();
					DiaryTablePojo diarytable = (DiaryTablePojo) rdSession.get(DiaryTablePojo.class,diarytableId);					   
					   rdSession.evict(diarytable);
					   if(schoolId==diarytable.getSchoolId()&&branchId==diarytable.getBranchId())
					   {
					   Query empQuery=rdSession.createSQLQuery("update gbl_sm_tbl_diarytable set isDeleted='y' where diaryId='"+diarytableId+"'");
					   empQuery.executeUpdate();
					   tx.commit();
					/*DiaryTablePojo diarytable=new DiaryTablePojo();				
					diarytable.setDiaryId(diarytableId);
					rdSession.delete(diarytable);	*/
					sb.append("<DiaryTable>");
				    sb.append("\n");
				    sb.append("<id>");
					sb.append("\n");
					sb.append("DiaryTable item deleted");
					sb.append("</id>");
					sb.append("\n");
					sb.append("</DiaryTable>");
					strg= sb.toString();	
					}else{
						   strg = " diarytable is not deleted";
						   sb.append("<diarytable>");
						   sb.append("\n");
						   sb.append(strg);
						   sb.append("</diarytable>");
						    String str = sb.toString();
						    return str;
						   }
					}
			
					catch(Exception localException)
					{
						System.out.println(localException);
						localException.printStackTrace();
					   sb.append("<Response>");
					   sb.append("\n");
					   sb.append("<Result>");
					   sb.append("\n");
					   sb.append("Fail");
					   sb.append("\n");
					   sb.append("</Result>");
					   sb.append("\n");
					   sb.append("<Description>");
					   sb.append("could not deleted DiaryTable item");
					   sb.append("</Description>");
					   sb.append("\n");
					   sb.append("<Exception>");
					   sb.append(localException);
					   sb.append("</Exception>");
					   sb.append("</Response>");
					   strg=sb.toString();
					   MDTransactionWriter.exceptionlog.info(localException);
					  if (tx!=null)
					   tx.rollback();
					  } finally {
					   rdSession.close(); 
					  }
					  return strg;
					 }

	public String updateDiaryTable(DiaryTablePojo diaryTablePojo,int schoolId,int branchId) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb= new StringBuffer();
		String strg= null;
		try {
				tx = rdSession.beginTransaction();
				DiaryTablePojo diarytable = (DiaryTablePojo) rdSession.get(DiaryTablePojo.class,diaryTablePojo.getDiaryId());
				rdSession.evict(diarytable);
				   if(schoolId==diarytable.getSchoolId()&&branchId==diarytable.getBranchId())
				   rdSession.update(diaryTablePojo);				     
				   tx.commit();
				sb.append("<diaryTable>");
				sb.append("\n");
			    sb.append("<diaryTableid>");
				sb.append("diaryTable succssfully updated");
				sb.append("</diaryTableid>");
				sb.append("\n");
				sb.append("</diaryTable>");
				strg= sb.toString();		
				}catch (Exception localException) {
					System.out.println(localException);
					localException.printStackTrace();
				   sb.append("<Response>");
				   sb.append("\n");
				   sb.append("<Result>");
				   sb.append("\n");
				   sb.append("Fail");
				   sb.append("\n");
				   sb.append("</Result>");
				   sb.append("\n");
				   sb.append("<Description>");
				   sb.append("could not update diaryTable item");
				   sb.append("</Description>");
				   sb.append("\n");
				   sb.append("<Exception>");
				   sb.append(localException);
				   sb.append("</Exception>");
				   sb.append("</Response>");
				   strg=sb.toString();
				   MDTransactionWriter.exceptionlog.info(localException);
				  if (tx!=null)
				   tx.rollback();
				  } finally {
				   rdSession.close(); 
				  }
				  return strg;
				 }

	@SuppressWarnings("rawtypes")
	public String getAllDiaryTable(int PNO, int size,int schoolId,int branchId,String classId,String sectionId,String studentId,String diaryAcademicYear) {
			  String xmlString=null;
			  Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
			  Transaction stgTx=null;
			  StringBuffer sb = new StringBuffer();
			  try
			  {
			   stgTx=stgSession.beginTransaction();
			    int fset = (PNO-1)*size;
			    String filterWhere="";
			    if(classId!=null ){									  								    	
			    	filterWhere+=" and stuedu.ClassId in("+classId+")";
			    
			    	if(sectionId!=null){
					filterWhere +=  " and stuedu.SectionId in("+sectionId+")";
			    	}
			    }
						if(studentId!=null){
						filterWhere +=  " and dt.studentId in("+studentId+")";
						}
			    
			    if(diaryAcademicYear!=null && !"".equalsIgnoreCase(diaryAcademicYear)){
			    	filterWhere+=" and dt.AcademicYear in ('"+diaryAcademicYear+"')";	
			    }
			    
			    String gsSql ="SELECT count(*) FROM gbl_sm_tbl_diarytable as dt left outer join gbl_sm_tbl_student_education as stuedu on stuedu.StudentId=dt.StudentId left outer join  gbl_sm_tbl_class as cls on stuedu.ClassId=cls.ClassId left outer join  gbl_sm_tbl_section as sec on sec.SectionId=stuedu.SectionId join gbl_sm_tbl_student as stu on stu.StudentId=dt.StudentId where (dt.isDeleted<>'y' or dt.isDeleted is null) and dt.schoolId='"+schoolId+"' and dt.branchId='"+branchId+"'"+filterWhere+"";
			    Query gsQuery=stgSession.createSQLQuery(gsSql);
			    Object noRecords= gsQuery.uniqueResult();
			    int intNoRecords=0;
				if(noRecords!=null && Integer.parseInt(noRecords.toString())!=0)
				{
					intNoRecords=Integer.parseInt(noRecords.toString());
				} if(intNoRecords!=0)
				{
			    sb.append("<diarytables>");
			    sb.append("\n");
			    sb.append("<noRecords>"+noRecords+"</noRecords>");
			    sb.append("\n");
			     if (PNO > 0 & size > 0){
			     gsSql="SELECT dt.DiaryId,stuedu.ClassId,cls.ClassName,stuedu.SectionId,sec.SectionName,dt.StudentId,stu.StudentNumber,stu.FirstName,stu.MiddleName,stu.LastName,dt.Title,dt.AcademicYear,dt.`Status`,dt.SchoolId,dt.BranchId FROM "
			     		+ "gbl_sm_tbl_diarytable as dt left outer join gbl_sm_tbl_student_education as stuedu on stuedu.StudentId=dt.StudentId left outer join  gbl_sm_tbl_class as cls on stuedu.ClassId=cls.ClassId left outer join  gbl_sm_tbl_section as sec on sec.SectionId=stuedu.SectionId join gbl_sm_tbl_student as stu on stu.StudentId=dt.StudentId where (dt.isDeleted<>'y' or dt.isDeleted is null) and "
			     		+ " dt.schoolId='"+schoolId+"' and dt.branchId='"+branchId+"' "+filterWhere+" limit "+size+" offset "+fset;
			     }
			     else {
			      gsSql="SELECT dt.DiaryId,stuedu.ClassId,cls.ClassName,stuedu.SectionId,sec.SectionName,dt.StudentId,stu.StudentNumber,stu.FirstName,stu.MiddleName,stu.LastName,dt.Title,dt.AcademicYear,dt.`Status`,dt.SchoolId,dt.BranchId FROM "
			     		+ "gbl_sm_tbl_diarytable as dt left outer join gbl_sm_tbl_student_education as stuedu on stuedu.StudentId=dt.StudentId left outer join  gbl_sm_tbl_class as cls on stuedu.ClassId=cls.ClassId left outer join  gbl_sm_tbl_section as sec on sec.SectionId=stuedu.SectionId join gbl_sm_tbl_student as stu on stu.StudentId=dt.StudentId where (dt.isDeleted<>'y' or dt.isDeleted is null) and "
			     		+ " dt.schoolId='"+schoolId+"' and dt.branchId='"+branchId +"'"+filterWhere+"";
			     } 
			    
			    gsQuery=stgSession.createSQLQuery(gsSql);
			    List gcList=gsQuery.list();
			    Iterator gsIT=gcList.iterator();
			     while(gsIT.hasNext())
			     {
			      Object[] mdcArr=(Object[])gsIT.next();
			      sb.append("<diarytable>");
			      sb.append("\n");
			      sb.append("<diaryId>"+mdcArr[0]+"</diaryId>");
			      sb.append("\n");			      
			      sb.append("<classId>" + mdcArr[1]+ "</classId>");
			      sb.append("\n");
			      sb.append("<className>" + mdcArr[2] + "</className>");
			      sb.append("\n");
			      sb.append("<sectionId>" + mdcArr[3]+ "</sectionId>");
			      sb.append("\n");
			      sb.append("<sectionName>" + mdcArr[4] + "</sectionName>");
			      sb.append("\n");  
			      sb.append("<studentId>" + mdcArr[5]+ "</studentId>");
			      sb.append("\n");
			      sb.append("<studentNumber>" + mdcArr[6]+ "</studentNumber>");
			      sb.append("\n");
			      sb.append("<firstName>" + mdcArr[7] + "</firstName>");
			      sb.append("\n");
			      sb.append("<middleName>" + mdcArr[8]+ "</middleName>");
			      sb.append("\n");
			      sb.append("<lastName>" + mdcArr[9] + "</lastName>");
			      sb.append("\n");
			      sb.append("<title>" +  mdcArr[10]+ "</title>");
			      sb.append("\n");
			      sb.append("<academicYear>" + mdcArr[11] + "</academicYear>");
			      sb.append("\n");
			      sb.append("<status>" + mdcArr[12] + "</status>");
			      sb.append("\n");
			      sb.append("<schoolId>" + mdcArr[13] + "</schoolId>");
			      sb.append("\n");
			      sb.append("<branchId>" + mdcArr[14] + "</branchId>");
			      sb.append("\n");
			      sb.append("</diarytable>");
			     }
				}
			    stgTx.commit();
			    sb.append("</diarytables>");
			    sb.append("\n");
			    xmlString=sb.toString();
			   } 
		catch(Exception localException)
		{
			System.out.println(localException);
			localException.printStackTrace();
		   sb.append("<Response>");
		   sb.append("\n");
		   sb.append("<Result>");
		   sb.append("\n");
		   sb.append("Fail");
		   sb.append("\n");
		   sb.append("</Result>");
		   sb.append("\n");
		   sb.append("<Description>");
		   sb.append("could not getall diarytable items");
		   sb.append("</Description>");
		   sb.append("\n");
		   sb.append("<Exception>");
		   sb.append(localException);
		   sb.append("</Exception>");
		   sb.append("</Response>");
		   xmlString=sb.toString();
		   MDTransactionWriter.exceptionlog.info(localException);
		  if (stgTx!=null)
			  stgTx.rollback();
		  } finally {
		   stgSession.close(); 
		  }
		  return xmlString;
		 }

	@SuppressWarnings("rawtypes")
	public String getByIdDiaryTable(int diarytableId,int schoolId,int branchId) {
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		  Transaction tx=null;
		StringBuffer sb= new StringBuffer();
		String strg= null;
		try{
			tx = stgSession.beginTransaction();
			Query query=stgSession.createSQLQuery("SELECT dt.DiaryId,stuedu.ClassId,cls.ClassName,stuedu.SectionId,sec.SectionName,dt.StudentId,stu.StudentNumber,stu.FirstName,stu.MiddleName,stu.LastName,dt.Title,dt.AcademicYear,dt.`Status`,dt.SchoolId,dt.BranchId FROM "
			     		+ "gbl_sm_tbl_diarytable as dt left outer join gbl_sm_tbl_student_education as stuedu on stuedu.StudentId=dt.StudentId left outer join  gbl_sm_tbl_class as cls on stuedu.ClassId=cls.ClassId left outer join  gbl_sm_tbl_section as sec on sec.SectionId=stuedu.SectionId join gbl_sm_tbl_student as stu on stu.StudentId=dt.StudentId where (dt.isDeleted<>'y' or dt.isDeleted is null) and "
			     		+ "  dt.DiaryId='"+diarytableId+"' and dt.schoolId='"+schoolId+"' and dt.branchId='"+branchId+"' ");
		    List gcList=query.list();
		    Iterator gsIT=gcList.iterator();
		     while(gsIT.hasNext())
		     {
		      Object[] mdcArr=(Object[])gsIT.next();
		  
		      sb.append("<diarytable>");
		      sb.append("\n");
		      sb.append("<diaryId>"+mdcArr[0]+"</diaryId>");
		      sb.append("\n");			      
		      sb.append("<classId>" + mdcArr[1]+ "</classId>");
		      sb.append("\n");
		      sb.append("<className>" + mdcArr[2] + "</className>");
		      sb.append("\n");
		      sb.append("<sectionId>" + mdcArr[3]+ "</sectionId>");
		      sb.append("\n");
		      sb.append("<sectionName>" + mdcArr[4] + "</sectionName>");
		      sb.append("\n");  
		      sb.append("<studentId>" + mdcArr[5]+ "</studentId>");
		      sb.append("\n");
		      sb.append("<studentNumber>" + mdcArr[6]+ "</studentNumber>");
		      sb.append("\n");
		      sb.append("<firstName>" + mdcArr[7] + "</firstName>");
		      sb.append("\n");
		      sb.append("<middleName>" + mdcArr[8]+ "</middleName>");
		      sb.append("\n");
		      sb.append("<lastName>" + mdcArr[9] + "</lastName>");
		      sb.append("\n");
		      sb.append("<title>" +  mdcArr[10]+ "</title>");
		      sb.append("\n");
		      sb.append("<academicYear>" + mdcArr[11] + "</academicYear>");
		      sb.append("\n");
		      sb.append("<status>" + mdcArr[12] + "</status>");
		      sb.append("\n");
		      sb.append("<schoolId>" + mdcArr[13] + "</schoolId>");
		      sb.append("\n");
		      sb.append("<branchId>" + mdcArr[14] + "</branchId>");
		      sb.append("\n");
		      sb.append("</diarytable>");
				String str= sb.toString();
				return str;
		     }
		} 	catch (Exception localException) {
			System.out.println(localException);
			localException.printStackTrace();
		   sb.append("<Response>");
		   sb.append("\n");
		   sb.append("<Result>");
		   sb.append("\n");
		   sb.append("Fail");
		   sb.append("\n");
		   sb.append("</Result>");
		   sb.append("\n");
		   sb.append("<Description>");
		   sb.append("could not getby diarytable item");
		   sb.append("</Description>");
		   sb.append("\n");
		   sb.append("<Exception>");
		   sb.append(localException);
		   sb.append("</Exception>");
		   sb.append("</Response>");
		   sb.append("</diarytableId>");
		   sb.append("</diarytable>");
		   
		   strg=sb.toString();
		   MDTransactionWriter.exceptionlog.info(localException);
		  if (tx!=null)
		   tx.rollback();
		  } finally {
		   stgSession.close(); 
		 }
		  return strg;
	 }			

}
