package com.gwebitsol.core.student;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import com.gwebitsol.core.security.MDValidation;
import com.gwebitsol.core.usermanagement.MDGetUserFromID;
import com.gwebitsol.core.util.MDTransactionWriter;

public class DiaryTableServiceImpl implements DiaryTableServiceIntf {
	@Context 
	private HttpServletRequest hsr;
	public Response addDiaryTable(DiaryTablePojo diaryTablePojo,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		diaryTablePojo.setBranchId(branchId);
		diaryTablePojo.setSchoolId(schoolId);
			try
				{	
				MDValidation mdv = new MDValidation();  
				int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
				System.out.println("verifiedvalue::"+ret);
				
				MDGetUserFromID mdgufid = new MDGetUserFromID();
				   String requester = mdgufid.getUserName(userID);
				if(ret==1 )//&& rtVal==1)
				{
					DiaryTableDao dao= new DiaryTableDao();
					status=dao.addDiaryTable(diaryTablePojo);
					System.out.println("output is "+status);
				
					String endDate=dateFormat.format(new Date());
					Long el=System.currentTimeMillis();
					MDTransactionWriter.writeLog(datastoreName,"DiaryTableServiceImpl_addDiaryTable",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
				}else
				{
					status="you are not authorised user";
				}
				}
					catch(Exception localException)
					{
						MDTransactionWriter.errorlog.debug(localException);
						MDTransactionWriter.errorlog.info(localException);
						status="failed in service layer";
						System.out.println(localException);
					}
					
	
			return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}
	

	public Response deleteDiaryTable(int diarytableId,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();	
		try
			{	
			MDValidation mdv = new MDValidation();  
			int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			System.out.println("verifiedvalue::"+ret);
			
			MDGetUserFromID mdgufid = new MDGetUserFromID();
			   String requester = mdgufid.getUserName(userID);
			if(ret==1 ){//&& rtVal==1){
				DiaryTableDao dao= new DiaryTableDao();
			status=dao.deleteDiaryTable(diarytableId,schoolId,branchId);
			
			String endDate=dateFormat.format(new Date());	
			Long el=System.currentTimeMillis();
			//status="user validation successfull";
			MDTransactionWriter.writeLog(datastoreName,"DiaryTableServiceImpl_deleteDiaryTable",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
			}else
			{
				status="you are not authorised user";
			}
		}
		
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			status="failed in service layer";
		}
	return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}
	

	public Response updateDiaryTable(DiaryTablePojo diaryTablePojo,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		diaryTablePojo.setBranchId(branchId);
		diaryTablePojo.setSchoolId(schoolId);
		try
		{	
			MDValidation mdv = new MDValidation();  
			int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			System.out.println("verifiedvalue::"+ret);
			
			MDGetUserFromID mdgufid = new MDGetUserFromID();
			   String requester = mdgufid.getUserName(userID);
		if(ret==1 ){
			DiaryTableDao dao= new DiaryTableDao();
			status=dao.updateDiaryTable(diaryTablePojo, schoolId,branchId);
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			//status="user validation successfull";
			MDTransactionWriter.writeLog(datastoreName,"DiaryTableServiceImpl_updateDiaryTable",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
			}else
			{
				status="you are not authorised user";
			}
		}
		  	catch(Exception localException)
			{
			  MDTransactionWriter.errorlog.debug(localException);
			  MDTransactionWriter.errorlog.info(localException);
			  status="failed in service layer";
		   }
    return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response getAllDiaryTable(int userID, int connectionID,String datastoreName,int PNO,int size,int schoolId,int branchId,String classId,String sectionId,String studentId,String diaryAcademicYear) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try{
			MDValidation mdv = new MDValidation();  
			int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			System.out.println("verifiedvalue::"+ret);
			
			MDGetUserFromID mdgufid = new MDGetUserFromID();
			   String requester = mdgufid.getUserName(userID);
			if(ret==1 ){
				DiaryTableDao dao= new DiaryTableDao();
				status=dao.getAllDiaryTable(PNO,size,schoolId,branchId, classId,sectionId, studentId, diaryAcademicYear);
				System.out.println(status);
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				MDTransactionWriter.writeLog(datastoreName,"DiaryTableServiceImpl_getAllDiaryTable",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
				}else
				{
				status="you are not authorised user";
			}
		}catch(Exception localException)
		   {
			  MDTransactionWriter.errorlog.debug(localException);
			  MDTransactionWriter.errorlog.info(localException);
			  status="failed in service layer";
		   }
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response getByIdDiaryTable(int diarytableId,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try
	{
			MDValidation mdv = new MDValidation();  
			int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			System.out.println("verifiedvalue::"+ret);
			MDGetUserFromID mdgufid = new MDGetUserFromID();
			   String requester = mdgufid.getUserName(userID);
			if(ret==1 ){
				DiaryTableDao dao= new DiaryTableDao();
				status=dao.getByIdDiaryTable(diarytableId,schoolId,branchId);
				System.out.println(status);
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				MDTransactionWriter.writeLog(datastoreName,"DiaryTableServiceImpl_getByIdDiaryTable",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
			}else
			{
			status="you are not authorised user";
			}
		}
	catch(Exception localException)
	{
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
		status="failed in service layer";
	  }
 return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}
}

