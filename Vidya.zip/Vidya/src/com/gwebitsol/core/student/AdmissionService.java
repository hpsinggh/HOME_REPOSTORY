package com.gwebitsol.core.student;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.gwebitsol.core.security.MDValidation;
import com.gwebitsol.core.security.MDVerifyConnectionID;
import com.gwebitsol.core.security.MDVerifyDatastoreName;
import com.gwebitsol.core.usermanagement.MDGetUserFromID;
import com.gwebitsol.core.util.MDTransactionWriter;

public class AdmissionService implements AdmissionIntf {
	@Context
	private HttpServletRequest hsr;

	public Response addAdmission(AdmissionPojo tp, int userid, int connectionid, String datastoreName,int schoolid,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: " + hsr.getRemoteHost() + " at " + new Date());
		String XMLString = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();
		
		tp.setSchoolId(schoolid);
		tp.setBranchId(branchId);
		
		try {

			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName, schoolid, branchId);
			System.out.println("verifiedvalue::"+ret);

			if (ret == 1) // && rtVal==1)
			{
				String endDate = dateFormat.format(new Date());
				Long el = System.currentTimeMillis();

				AdmissionDao idao = new AdmissionDao();
				XMLString = idao.addAdmission(tp);

				System.out.println(XMLString);
				MDTransactionWriter.writeLog("SCHOOL", "MMS", "srinu", startDate, endDate, sl, el, XMLString,
						hsr.getRemoteHost());
			} else {
				XMLString = "you are not authorised user";
			}
		} catch (Exception localException) {
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			XMLString = "failed in service layer";
		}

		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();

	}

	public Response updateAdmission(AdmissionPojo tp, int userid, int connectionid, String datastoreName, int schoolid,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: " + hsr.getRemoteHost() + " at " + new Date());
		String XMLString = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();
		
		tp.setSchoolId(schoolid);
		tp.setBranchId(branchId);
		
		try {

			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName,schoolid, branchId);
			System.out.println("verifiedvalue::"+ret);

			if (ret == 1) // && rtVal==1)
			{
				String endDate = dateFormat.format(new Date());
				Long el = System.currentTimeMillis();
				AdmissionDao idao = new AdmissionDao();
				XMLString = idao.updateAdmission(tp,schoolid, branchId);
				System.out.println(XMLString);
				MDTransactionWriter.writeLog("SCHOOL", "MMS", "srinu", startDate, endDate, sl, el, XMLString,
						hsr.getRemoteHost());
			} else {
				XMLString = "you are not authorised user";
			}
		} catch (Exception localException) {
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			XMLString = "failed in service layer";
		}

		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}

	/*
	 * public Response deleteAdmission(int admissionID,int userID, int
	 * connectionID,String datastoreName) { MDTransactionWriter.accesslog.info(
	 * "Request from: "+hsr.getRemoteHost()); String XMLString=null;
	 * 
	 * String status=null; DateFormat dateFormat = new SimpleDateFormat(
	 * "yyyy-MM-dd HH:mm:ss"); Date date = new Date(); String
	 * startDate=dateFormat.format(date); Long sl=System.currentTimeMillis();
	 * 
	 * try { MDGetUserFromID mdgufid=new MDGetUserFromID(); String
	 * requester=mdgufid.getUserName(userID);
	 * 
	 * System.out.println(connectionID); MDVerifyConnectionID mdvcid=new
	 * MDVerifyConnectionID(); int
	 * ret=mdvcid.verifyConnectionID(userID,connectionID);
	 * 
	 * MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName(); int
	 * rtVal=mdvdsn.verifyDatastoreName(datastoreName);
	 * 
	 * System.out.println("request making user:: "+requester);
	 * System.out.println("connectionid verification value:: "+ret);
	 * System.out.println("datastore verification value :: "+rtVal); if(ret==1
	 * )//&& rtVal==1) { AdmissionDao idao=new AdmissionDao();
	 * status=idao.deleteAdmission(admissionID);
	 * 
	 * String endDate=dateFormat.format(new Date()); Long
	 * el=System.currentTimeMillis();
	 * 
	 * MDTransactionWriter.writeLog("sai","CMS","requester",startDate,endDate,sl
	 * ,el,status,hsr.getRemoteHost()); }else { XMLString=
	 * "you are not authorised user"; } } catch(Exception localException) {
	 * MDTransactionWriter.errorlog.debug(localException);
	 * MDTransactionWriter.errorlog.info(localException); status=
	 * "failed in service layer"; } return
	 * Response.ok().type(MediaType.APPLICATION_XML).entity(status).build(); }
	 */

	public Response getByIdAdmission(int admissionID, int userid, int connectionid, String datastoreName, int schoolid,int branchId, int classId, int studentId,int sectionId) {
		MDTransactionWriter.accesslog.info("Request from: " + hsr.getRemoteHost());
		String XMLString = null;

		String status1 = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();

		try {

			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName, schoolid, branchId);
			System.out.println("verifiedvalue::"+ret);

			if (ret == 1) // && rtVal==1)
			{
				AdmissionDao ex = new AdmissionDao();
				status1 = ex.getByIdAdmission(admissionID,schoolid, branchId,classId,studentId,sectionId);
				System.out.println(status1);
				String endDate = dateFormat.format(new Date());
				Long el = System.currentTimeMillis();
				// status1="user validation successfull";
				MDTransactionWriter.writeLog("SCHOOL", "MMS", "srinu", startDate, endDate, sl, el, status1,
						hsr.getRemoteHost());
			} else {
				XMLString = "you are not authorised user";
			}
		} catch (Exception localException) {
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			status1 = "failed in service layer";
			// System.out.println(localException);
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status1).build();
	}

	public Response getAllAdmission(String status, int userID, int connectionID, String datastoreName) {

		MDTransactionWriter.accesslog.info("Request from: " + hsr.getRemoteHost() + " at " + new Date());

		String XMLString = null;

		String stat = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();
		try {
			System.out.println("service" + status);
			MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userID);

			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid = new MDVerifyConnectionID();
			int ret = mdvcid.verifyConnectionID(userID, connectionID);

			MDVerifyDatastoreName mdvdsn = new MDVerifyDatastoreName();
			int rtVal = mdvdsn.verifyDatastoreName(datastoreName);

			System.out.println("request making user:: " + requester);
			System.out.println("connectionid verification value:: " + ret);
			System.out.println("datastore verification value :: " + rtVal);
			if (ret == 1) // && rtVal==1)
			{
				AdmissionDao ex = new AdmissionDao();
				stat = ex.getAllAdmission(status);
				System.out.println("final status" + stat);
				String endDate = dateFormat.format(new Date());
				Long el = System.currentTimeMillis();
				MDTransactionWriter.writeLog("SCHOOL", "MMS", "srinu", startDate, endDate, sl, el, stat,
						hsr.getRemoteHost());

			} else {
				XMLString = "you are not authorised user";
			}
		} catch (Exception localException) {
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			stat = "failed in service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(stat).build();

	}

	public Response getAllAdmsn(String status, int userid, int connectionid, String datastoreName, int PNO, int size, int schoolid,int branchId, int classId, int studentId,int sectionId) {
		
		MDTransactionWriter.accesslog.info("Request from: " + hsr.getRemoteHost() + " at " + new Date());

		String XMLString = null;

		String stat = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();
		try {
			
			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName, schoolid, branchId);
			System.out.println("verifiedvalue::"+ret);

			if (ret == 1) // && rtVal==1)
			{
				AdmissionDao ex = new AdmissionDao();
				stat = ex.getAllAdmsn(PNO,size,status, schoolid, branchId,classId,studentId,sectionId);
						
				System.out.println("final status" + stat);
				String endDate = dateFormat.format(new Date());
				Long el = System.currentTimeMillis();
				MDTransactionWriter.writeLog("SCHOOL", "MMS", "srinu", startDate, endDate, sl, el, stat,
						hsr.getRemoteHost());

			} else {
				XMLString = "you are not authorised user";
			}
		} catch (Exception localException) {
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			stat = "failed in service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(stat).build();
	}

	
	

}
