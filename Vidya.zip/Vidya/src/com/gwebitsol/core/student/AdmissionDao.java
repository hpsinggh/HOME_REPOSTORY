package com.gwebitsol.core.student;

import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.parent.ParentPojo;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class AdmissionDao {

	StringBuffer sb = new StringBuffer();

	public String addAdmission(AdmissionPojo tp) {
		Session empSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction addempTx = null;
		String outStr = null;
		try {
			addempTx = empSession.beginTransaction();
			Integer in = (Integer) empSession.save(tp);

			addempTx.commit();

			sb.append("<Admission>");
			sb.append("\n");
			sb.append("<id>");
			sb.append("\n");
			sb.append(in);
			sb.append("</id>");
			sb.append("\n");
			sb.append("</Admission>");
			outStr = sb.toString();
		} catch (Exception localException) {
			localException.printStackTrace();
			System.out.println(localException);

			sb.append("<Response>");
			sb.append("\n");
			sb.append("<Result>");
			sb.append("\n");
			sb.append("Fail");
			sb.append("\n");
			sb.append("</Result>");
			sb.append("\n");
			sb.append("<Description>");
			sb.append("could not inserted admission info");
			sb.append("</Description>");
			sb.append("\n");
			sb.append("<Exception>");
			sb.append(localException);
			sb.append("</Exception>");
			sb.append("</Response>");

			outStr = sb.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (addempTx != null)
				addempTx.rollback();
		} finally {
			empSession.close();
		}
		return outStr;
	}

	public String updateAdmission(AdmissionPojo tp, int schoolid, int branchid) {
		// Session upempSession =
		// MDHibernateUtil.getSessionFactory().openSession();
		Session empSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction addempTx = null;
		// Transaction upempTx = null;
		StringBuffer sb = new StringBuffer();
		String outStr = null;
		try {
			addempTx = empSession.beginTransaction();

			AdmissionPojo mdclpojo = (AdmissionPojo) empSession.get(AdmissionPojo.class, tp.getAdmissionID());

			if (branchid == mdclpojo.getBranchId() && schoolid == mdclpojo.getSchoolId())

				empSession.evict(mdclpojo);
			empSession.update(tp);
			try {
				addempTx.commit();
			} catch (HibernateException e) {
				System.out.println(e);
			}
			sb.append("<Admission>");
			sb.append("\n");
			sb.append("update successfully");
			sb.append("</Admission>");
			String str = sb.toString();
			return str;

		}

		catch (Exception localException) {
			localException.printStackTrace();
			System.out.println(localException);

			sb.append("<Response>");
			sb.append("\n");
			sb.append("<Result>");
			sb.append("\n");
			sb.append("Fail");
			sb.append("\n");
			sb.append("</Result>");
			sb.append("\n");
			sb.append("<Description>");
			sb.append("could not updated admission info");
			sb.append("</Description>");
			sb.append("\n");
			sb.append("<Exception>");
			sb.append(localException);
			sb.append("</Exception>");
			sb.append("</Response>");

			outStr = sb.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (addempTx != null)
				addempTx.rollback();
		} finally {
			empSession.close();
		}
		return outStr;
	}

	/*
	 * public String deleteAdmission(int admissionID) { Session
	 * delempSession=MDHibernateUtil.getSessionFactory().openSession();
	 * Transaction delempTx=null; StringBuffer sb=new StringBuffer();
	 * 
	 * String outStr=null; try { delempTx=delempSession.beginTransaction();
	 * 
	 * AdmissionPojo brp=new AdmissionPojo(); brp.setAdmissionID(admissionID);
	 * delempSession.delete(brp); try{ delempTx.commit(); }
	 * catch(HibernateException e){ System.out.println(e); }
	 * sb.append("<Admission>"); sb.append("\n"); sb.append(
	 * "delete successfully"); sb.append("</Admission>"); String
	 * str=sb.toString(); return str;
	 * 
	 * }
	 * 
	 * catch(Exception localException) { delempTx.rollback();
	 * localException.printStackTrace(); outStr="fail"; } finally {
	 * delempSession.close(); } return outStr; }
	 */

	public String getByIdAdmission(int admissionID, int schoolid, int branchid, int classId, int studentId,
			int sectionId) {
		Session empSession = MDHibernateUtil.getSessionFactory().openSession();

		Transaction gtempTx = null;
		StringBuffer sb = new StringBuffer();

		System.out.println("hi success");
		String strg = null;
		String gsSql = null;
		try {
			gtempTx = empSession.beginTransaction();

			gsSql = "select ad.*, st.StudentNumber, st.FirstName,st.MiddleName,"
					+ " st.LastName,cl.ClassName,se.SectionName,fs.Title,ca.CasteGroup,ca.CasteName,re.ReligionName,si.SchoolName,br.BranchName"
					+ " from gbl_sm_tbl_admission as ad join gbl_sm_tbl_student as st on ad.StudentId = st.StudentId "
					+ " join gbl_sm_tbl_class as cl on ad.ClassId=cl.ClassId join gbl_sm_tbl_section as se on ad.SectionId=se.SectionId"
					+ " join gbl_sm_tbl_fee_structure as fs on ad.FeeStructureId = fs.FeeStructureId"
					+ " join gbl_sm_tbl_school_branch as br on ad.SchoolBranchId = br.SchoolBranchId"
					+ " join gbl_sm_tbl_school_info as si on ad.SchoolId = si.SchoolId"
					+ " join gbl_sm_tbl_caste as ca on ad.CasteId = ca.CasteId"
					+ " join gbl_sm_tbl_religion as re on ad.ReligionId = re.ReligionId"
					+ " join gbl_sm_tbl_student_education as ste on ad.StudentEdId= ste.StudentEdId"	
					+ " where ad.IsDeleted is null and ad.AdmissionId ='" + admissionID
					+ "' and ad.SchoolId='" + schoolid + "' and ad.SchoolBranchId='"
					+ branchid + "'";

			if (classId != 0) {
				gsSql += " and ad.classId=" + classId;
				if (sectionId != 0) {
					gsSql += " and ad.sectionId=" + sectionId;
				}
			}
			gsSql += ";";
			Query gsQuery = empSession.createSQLQuery(gsSql);
			List gcList = gsQuery.list();
			Iterator gsIT = gcList.iterator();
			while (gsIT.hasNext()) {
				Object[] mdcArr = (Object[]) gsIT.next();
				sb.append("<Admission>");
				sb.append("\n");
				sb.append("<admissionId>" + mdcArr[0] + "</admissionId>");
				sb.append("\n");
				sb.append("<studentId>" + mdcArr[1] + "</studentId>");
				sb.append("\n");
				sb.append("<studentNumber>" + mdcArr[19] + "</studentNumber>");
				sb.append("\n");
				sb.append("<studentFirstName>" + mdcArr[20] + "</studentFirstName>");
				sb.append("\n");
				sb.append("<studentMiddleName>" + mdcArr[21] + "</studentMiddleName>");
				sb.append("\n");
				sb.append("<studentLastName>" + mdcArr[22] + "</studentLastName>");
				sb.append("\n");
				sb.append("<studentEdId>" + mdcArr[2] + "</studentEdId>");
				sb.append("\n");
				sb.append("<classId>" + mdcArr[3] + "</classId>");
				sb.append("\n");
				sb.append("<className>" + mdcArr[23] + "</className>");
				sb.append("\n");
				sb.append("<sectionId>" + mdcArr[4] + "</sectionId>");
				sb.append("\n");
				sb.append("<sectionName>" + mdcArr[24] + "</sectionName>");
				sb.append("\n");
				sb.append("<feeStructureId>" + mdcArr[5] + "</feeStructureId>");
				sb.append("\n");
				sb.append("<Title>" + mdcArr[25] + "</Title>");
				sb.append("\n");
				sb.append("<casteId>" + mdcArr[6] + "</casteId>");
				sb.append("\n");
				sb.append("<casteGroup>" + mdcArr[26] + "</casteGroup>");
				sb.append("\n");
				sb.append("<casteName>" + mdcArr[27] + "</casteName>");
				sb.append("\n");
				sb.append("<religionId>" + mdcArr[7] + "</religionId>");
				sb.append("\n");
				sb.append("<religionName>" + mdcArr[28] + "</religionName>");
				sb.append("\n");
				sb.append("<admissionNo>" + mdcArr[8] + "</admissionNo>");
				sb.append("\n");
				sb.append("<dateOfAdmission>" + mdcArr[9] + "</dateOfAdmission>");
				sb.append("\n");
				sb.append("<nationality>" + mdcArr[10] + "</nationality>");
				sb.append("\n");
				sb.append("<status>" + mdcArr[11] + "</status>");
				sb.append("\n");
				sb.append("<description>" + mdcArr[12] + "</description>");
				sb.append("\n");
				sb.append("<remarks>" + mdcArr[13] + "</remarks>");
				sb.append("\n");
				sb.append("<createdDate>" + mdcArr[14] + "</createdDate>");
				sb.append("\n");
				sb.append("<modifiedDate>" + mdcArr[15] + "</modifiedDate>");
				sb.append("\n");
				sb.append("<schoolId>" + mdcArr[16] + "</schoolId>");
				sb.append("\n");
				sb.append("<SchoolName>" + mdcArr[29] + "</SchoolName>");
				sb.append("\n");
				sb.append("<schoolBranchId>" + mdcArr[17] + "</schoolBranchId>");
				sb.append("\n");
				sb.append("<schoolBranchName>" + mdcArr[30] + "</schoolBranchName>");
				sb.append("\n");
				sb.append("<isDeleted>" + mdcArr[18] + "</isDeleted>");
				sb.append("\n");
				sb.append("</Admission>");
				sb.append("\n");
			}
			gtempTx.commit();
			strg = sb.toString();

		} catch (Exception localException) {
			localException.printStackTrace();
			System.out.println(localException);

			sb.append("<Response>");
			sb.append("\n");
			sb.append("<Result>");
			sb.append("\n");
			sb.append("Fail");
			sb.append("\n");
			sb.append("</Result>");
			sb.append("\n");
			sb.append("<Description>");
			sb.append("could not get admission info");
			sb.append("</Description>");
			sb.append("\n");
			sb.append("<Exception>");
			sb.append(localException);
			sb.append("</Exception>");
			sb.append("</Response>");

			strg = sb.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (gtempTx != null)
				gtempTx.rollback();
		} finally {
			empSession.close();
		}
		return strg;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public String getAllAdmission(String status) {
		/*
		 * if (status.equalsIgnoreCase("active")) System.out.println(
		 * "Yes, I am active"); if (status.equalsIgnoreCase("INactive"))
		 * System.out.println("Yes, I am INactive"); if
		 * (status.equalsIgnoreCase("")) System.out.println("I don't know!!!");
		 * 
		 * return status;
		 * 
		 * }
		 */

		// System.out.println(status);
		Session empSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction addempTx = null;
		String admnreg = null;
		AdmissionPojo par = null;
		String sqlstr = null;
		try {
			addempTx = empSession.beginTransaction();

			if (status.equalsIgnoreCase("inactive")) {

				sqlstr = "select * from gbl_sm_tbl_admission where gbl_sm_tbl_admission.StudentId in (select StudentId from gbl_sm_tbl_transfer);";

			}

			else if (status.equalsIgnoreCase("active")) {
				sqlstr = "select * from gbl_sm_tbl_admission where gbl_sm_tbl_admission.StudentId not in (select StudentId from gbl_sm_tbl_transfer);";

			}

			else {
				sqlstr = "select * from gbl_sm_tbl_admission";

			}
			List<AdmissionPojo> list = empSession.createSQLQuery(sqlstr).list();

			System.out.println(list);

			Iterator admis = list.iterator();

			sb.append("<Admission>");

			while (admis.hasNext()) {
				Object[] admsn = (Object[]) admis.next();

				if (admsn == null) {
					System.out.println("there is no student object");
				} else {
					sb.append("\n");
					sb.append("<admissionID>");
					sb.append("\n");
					sb.append(admsn[0]);
					sb.append("</admissionID>");
					sb.append("\n");
					sb.append("<studentId>");
					sb.append(admsn[1]);
					sb.append("</studentId>");
					sb.append("\n");
					sb.append("<admissionNo>");
					sb.append(admsn[2]);
					sb.append("</admissionNo>");
					sb.append("\n");
					sb.append("<schoolBranchId>");
					sb.append(admsn[3]);
					sb.append("</schoolBranchId>");
					sb.append("\n");
					sb.append("<studentEdId>");
					sb.append(admsn[4]);
					sb.append("</studentEdId>");
					sb.append("\n");
					sb.append("<classId>");
					sb.append(admsn[5]);
					sb.append("</classId>");
					sb.append("\n");
					sb.append("<sectionId>");
					sb.append(admsn[6]);
					sb.append("</sectionId>");
					sb.append("\n");
					sb.append("<feeStructureId>");
					sb.append(admsn[7]);
					sb.append("</feeStructureId>");
					sb.append("\n");
					sb.append("<casteId>");
					sb.append(admsn[8]);
					sb.append("</casteId>");
					sb.append("\n");
					sb.append("<religionId>");
					sb.append(admsn[9]);
					sb.append("</religionId>");
					sb.append("\n");
					sb.append("<nationality>");
					sb.append(admsn[10]);
					sb.append("</nationality>");
					sb.append("\n");
					sb.append("<dateOfAdmission>");
					sb.append(admsn[11]);
					sb.append("</dateOfAdmission>");
					sb.append("\n");
					sb.append("<description>");
					sb.append(admsn[12]);
					sb.append("</description>");
					sb.append("\n");
					sb.append("<remarks>");
					sb.append(admsn[13]);
					sb.append("</remarks>");
					sb.append("\n");
					sb.append("<createdDate>");
					sb.append(admsn[14]);
					sb.append("</createdDate>");
					sb.append("\n");
					sb.append("<modifiedDate>");
					sb.append(admsn[15]);
					sb.append("</modifiedDate>");
					sb.append("\n");
					sb.append("<status>");
					sb.append(admsn[16]);
					sb.append("</status>");
					sb.append("\n");
				}
			}
			sb.append("</Admission>");
			addempTx.commit();
			String str = sb.toString();
			return str;
		} catch (HibernateException localException) {
			localException.printStackTrace();
			System.out.println(localException);

			sb.append("<Response>");
			sb.append("\n");
			sb.append("<Result>");
			sb.append("\n");
			sb.append("Fail");
			sb.append("\n");
			sb.append("</Result>");
			sb.append("\n");
			sb.append("<Description>");
			sb.append("could not get all admission info");
			sb.append("</Description>");
			sb.append("\n");
			sb.append("<Exception>");
			sb.append(localException);
			sb.append("</Exception>");
			sb.append("</Response>");

			admnreg = sb.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (addempTx != null)
				addempTx.rollback();
		} finally {
			empSession.close();
		}

		return admnreg;

	}

	public String getAllAdmsn(int PNO, int size, String status, int schoolid, int branchid, int classId, int studentId,
			int sectionId) {

		String xmlString = null;
		Session empSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction addempTx = null;
		String gsSql = null;
		// Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		// Transaction stgTx=null;
		StringBuffer sb = new StringBuffer();
		try {
			addempTx = empSession.beginTransaction();

			int fset = (PNO - 1) * size;
			if(status.equalsIgnoreCase("inactive"))
			{
			 gsSql = "select count(*) from gbl_sm_tbl_admission as ad where ad.StudentId in (select gbl_sm_tbl_transfer.StudentId from gbl_sm_tbl_transfer) and ad.IsDeleted is null and ad.Status='"+status+"' and ad.SchoolId='" + schoolid
					+ "' and ad.SchoolBranchId='" + branchid + "'";
			}
			if(status.equalsIgnoreCase("active"))
			{
			 gsSql = "select count(*) from gbl_sm_tbl_admission as ad where ad.StudentId not in (select gbl_sm_tbl_transfer.StudentId from gbl_sm_tbl_transfer) and ad.IsDeleted is null and ad.Status='"+status+"' and ad.SchoolId='" + schoolid
						+ "' and ad.SchoolBranchId='" + branchid + "'";
			}
			if(classId>0)
			{
				gsSql+=" and ad.ClassId='"+classId+"'";
			}
			if(sectionId>0)
			{
				gsSql+=" and ad.SectionId='"+sectionId+"'";
			}
			Query gsQuery = empSession.createSQLQuery(gsSql);
			Object noRecords = gsQuery.uniqueResult();

			int intNoRecords = 0;
			if (noRecords != null && Integer.parseInt(noRecords.toString()) != 0) {
				intNoRecords = Integer.parseInt(noRecords.toString());
			}
			sb.append("<Admissions>");
			sb.append("\n");
			sb.append("<noRecords>" + noRecords + "</noRecords>");
			sb.append("\n");
			
			String selectquery = "select ad.*, st.StudentNumber, st.FirstName,st.MiddleName,"
					+ " st.LastName,cl.ClassName,se.SectionName,fs.Title,ca.CasteGroup,ca.CasteName,re.ReligionName,si.SchoolName,br.BranchName"
					+ " from gbl_sm_tbl_admission as ad join gbl_sm_tbl_student as st on ad.StudentId = st.StudentId "
					+ " join gbl_sm_tbl_class as cl on ad.ClassId=cl.ClassId join gbl_sm_tbl_section as se on ad.SectionId=se.SectionId"
					+ " join gbl_sm_tbl_fee_structure as fs on ad.FeeStructureId = fs.FeeStructureId"
					+ " join gbl_sm_tbl_school_branch as br on ad.SchoolBranchId = br.SchoolBranchId"
					+ " join gbl_sm_tbl_school_info as si on ad.SchoolId = si.SchoolId"
					+ " join gbl_sm_tbl_caste as ca on ad.CasteId = ca.CasteId"
					+ " join gbl_sm_tbl_religion as re on ad.ReligionId = re.ReligionId"
					+ " join gbl_sm_tbl_student_education as ste on ad.StudentEdId= ste.StudentEdId where ad.StudentId ";
	
					String scbrquery =  " and ad.Status='"+status+"' and ad.IsDeleted is null and ad.SchoolId='" + schoolid+ "' and ad.SchoolBranchId='"+ branchid+"'";
					String limitquery = " limit " + size + " offset " + fset + ";";


			    if (intNoRecords != 0) {
				if (PNO > 0 & size > 0) {
					if (status.equalsIgnoreCase("inactive")) {
						gsSql = selectquery+"in (select StudentId from gbl_sm_tbl_transfer)"+scbrquery+limitquery;

					} else if (status.equalsIgnoreCase("active")) {
						gsSql = selectquery+" not in (select StudentId from gbl_sm_tbl_transfer)"+scbrquery+limitquery;


					}

				} else {

					if (status.equalsIgnoreCase("inactive")) {
						gsSql = selectquery+"in (select StudentId from gbl_sm_tbl_transfer)"+scbrquery;

					} else if (status.equalsIgnoreCase("active")) {
						gsSql = selectquery+" not in (select StudentId from gbl_sm_tbl_transfer)"+scbrquery;

					}
				}


			
				if (classId != 0) {
					gsSql += " and ad.classId=" + classId;
					if (sectionId != 0) {
						gsSql += " and ad.sectionId=" + sectionId;
					}
				}
				gsSql += ";";

				gsQuery = empSession.createSQLQuery(gsSql);
				List gcList = gsQuery.list();
				Iterator gsIT = gcList.iterator();
				while (gsIT.hasNext()) {
					Object[] mdcArr = (Object[]) gsIT.next();
					sb.append("<Admission>");
					sb.append("\n");
					sb.append("<admissionId>" + mdcArr[0] + "</admissionId>");
					sb.append("\n");
					sb.append("<studentId>" + mdcArr[1] + "</studentId>");
					sb.append("\n");
					sb.append("<studentNumber>" + mdcArr[19] + "</studentNumber>");
					sb.append("\n");
					sb.append("<studentFirstName>" + mdcArr[20] + "</studentFirstName>");
					sb.append("\n");
					sb.append("<studentMiddleName>" + mdcArr[21] + "</studentMiddleName>");
					sb.append("\n");
					sb.append("<studentLastName>" + mdcArr[22] + "</studentLastName>");
					sb.append("\n");
					sb.append("<studentEdId>" + mdcArr[2] + "</studentEdId>");
					sb.append("\n");
					sb.append("<classId>" + mdcArr[3] + "</classId>");
					sb.append("\n");
					sb.append("<className>" + mdcArr[23] + "</className>");
					sb.append("\n");
					sb.append("<sectionId>" + mdcArr[4] + "</sectionId>");
					sb.append("\n");
					sb.append("<sectionName>" + mdcArr[24] + "</sectionName>");
					sb.append("\n");
					sb.append("<feeStructureId>" + mdcArr[5] + "</feeStructureId>");
					sb.append("\n");
					sb.append("<Title>" + mdcArr[25] + "</Title>");
					sb.append("\n");
					sb.append("<casteId>" + mdcArr[6] + "</casteId>");
					sb.append("\n");
					sb.append("<casteGroup>" + mdcArr[26] + "</casteGroup>");
					sb.append("\n");
					sb.append("<casteName>" + mdcArr[27] + "</casteName>");
					sb.append("\n");
					sb.append("<religionId>" + mdcArr[7] + "</religionId>");
					sb.append("\n");
					sb.append("<religionName>" + mdcArr[28] + "</religionName>");
					sb.append("\n");
					sb.append("<admissionNo>" + mdcArr[8] + "</admissionNo>");
					sb.append("\n");
					sb.append("<dateOfAdmission>" + mdcArr[9] + "</dateOfAdmission>");
					sb.append("\n");
					sb.append("<nationality>" + mdcArr[10] + "</nationality>");
					sb.append("\n");
					sb.append("<status>" + mdcArr[11] + "</status>");
					sb.append("\n");
					sb.append("<description>" + mdcArr[12] + "</description>");
					sb.append("\n");
					sb.append("<remarks>" + mdcArr[13] + "</remarks>");
					sb.append("\n");
					sb.append("<createdDate>" + mdcArr[14] + "</createdDate>");
					sb.append("\n");
					sb.append("<modifiedDate>" + mdcArr[15] + "</modifiedDate>");
					sb.append("\n");
					sb.append("<schoolId>" + mdcArr[16] + "</schoolId>");
					sb.append("\n");
					sb.append("<previousSchoolName>" + mdcArr[29] + "</previousSchoolName>");
					sb.append("\n");
					sb.append("<schoolBranchId>" + mdcArr[17] + "</schoolBranchId>");
					sb.append("\n");
					sb.append("<SchoolName>" + mdcArr[30] + "</SchoolName>");
					sb.append("\n");
					sb.append("<isDeleted>" + mdcArr[18] + "</isDeleted>");
					sb.append("\n");
					sb.append("</Admission>");
					sb.append("\n");
				}
			}
			addempTx.commit();
			sb.append("</Admissions>");
			sb.append("\n");

			xmlString = sb.toString();

		} catch (Exception localException) {
			localException.printStackTrace();
			System.out.println(localException);

			sb.append("<Response>");
			sb.append("\n");
			sb.append("<Result>");
			sb.append("\n");
			sb.append("Fail");
			sb.append("\n");
			sb.append("</Result>");
			sb.append("\n");
			sb.append("<Description>");
			sb.append("could not get admission info");
			sb.append("</Description>");
			sb.append("\n");
			sb.append("<Exception>");
			sb.append(localException);
			sb.append("</Exception>");
			sb.append("</Response>");

			xmlString = sb.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (addempTx != null)
				addempTx.rollback();
		} finally {
			empSession.close();
		}
		return xmlString;
	}

}