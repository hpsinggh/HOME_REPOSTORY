//Vidya Version 0.8

package com.gwebitsol.core.student;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.math.BigInteger;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Iterator;
import java.util.List;

import javax.imageio.ImageIO;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.util.SerializationUtils;

import com.gwebitsol.core.parent.ParentPojo;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;
import com.mysql.jdbc.Blob;

public class StudentDao {

	StringBuffer StudentID = new StringBuffer();
	Integer stuid = null;

	public String addStudent(StudentPojo pp) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String sqlstr = null;
		String studentreg = null;
		Integer studentid1 = null;
		try {

			rdTx = rdSession.beginTransaction();
			studentid1 = (Integer) rdSession.save(pp);
			List<ParentPojo> parnetsary = pp.getPfr().getParents();

			// ParentPojo[] parnetsary = studentparents.getParent();

			for (int i = 0; i <= parnetsary.size() - 1; i++) {

				ParentPojo par = parnetsary.get(i);
				int parid = par.getParentId();
				String relation = par.getRelation();

				sqlstr = "insert into gbl_sm_tbl_student_parent(StudentId,ParentId,Relation) values ('" + studentid1
						+ "','" + parid + "','" + relation + "');";
				SQLQuery stpar = rdSession.createSQLQuery(sqlstr);

				stpar.executeUpdate();

			}
			rdTx.commit();
			StudentID.append("<Student>");
			StudentID.append("\n");
			StudentID.append("<id>");
			StudentID.append("\n");
			StudentID.append(studentid1);
			StudentID.append("\n");
			StudentID.append("</id>");
			StudentID.append("\n");
			StudentID.append("</Student>");
			studentreg = StudentID.toString();
		} catch (Exception localException) {
			localException.printStackTrace();
			System.out.println(localException);

			StudentID.append("<Response>");
			StudentID.append("\n");
			StudentID.append("<Result>");
			StudentID.append("\n");
			StudentID.append("Fail");
			StudentID.append("\n");
			StudentID.append("</Result>");
			StudentID.append("\n");
			StudentID.append("<Description>");
			StudentID.append("could not inserted student info");
			StudentID.append("</Description>");
			StudentID.append("\n");
			StudentID.append("<Exception>");
			StudentID.append(localException);
			StudentID.append("</Exception>");
			StudentID.append("</Response>");

			studentreg = StudentID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		} finally {
			rdSession.close();
		}
		return studentreg;
	}

	public String updateStudent(StudentPojo pp, int schoolid, int branchid) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String studentreg = null;
		String sqlstr = null;
		System.out.println(pp.getFirstName());
		try {

			rdTx = rdSession.beginTransaction();

			StudentPojo mdclpojo = (StudentPojo) rdSession.get(StudentPojo.class, pp.getStudentId());

			if (branchid == mdclpojo.getBranchId() && schoolid == mdclpojo.getSchoolId())

				rdSession.evict(mdclpojo);
			rdSession.update(pp);

			int studentid = pp.getStudentId();
			List<ParentPojo> parnetsary = pp.getPfr().getParents();
			for (int i = 0; i <= parnetsary.size() - 1; i++) {
				ParentPojo par = parnetsary.get(i);
				int stuparid = par.getStudentparentId();
				int parid = par.getParentId();
				String relation = par.getRelation();

				if (stuparid == 0) {
					sqlstr = "insert into gbl_sm_tbl_student_parent(StudentId,ParentId,Relation) values ('" + studentid
							+ "','" + parid + "','" + relation + "');";
					SQLQuery stpar = rdSession.createSQLQuery(sqlstr);

					stpar.executeUpdate();
				} else {
					sqlstr = "update gbl_sm_tbl_student_parent set StudentId='" + studentid + "', ParentId='" + parid
							+ "', Relation='" + relation + "' where StudentParentId='" + stuparid + "';";
					Query gsQuery = rdSession.createSQLQuery(sqlstr);
					gsQuery.executeUpdate();
				}
			}

			/*
			 * sqlstr=
			 * "select StudentParentId,ParentId from gbl_sm_tbl_student_parent where StudentId='"
			 * +studentid+"'"; Query gsQuery = rdSession.createSQLQuery(sqlstr);
			 * List gcList=gsQuery.list(); Iterator gsIT=gcList.iterator();
			 * while (gsIT.hasNext()) { Object[] paArr = (Object[]) gsIT.next();
			 * Integer stuparid = (Integer) paArr[0]; //52, 52 Integer parentid
			 * = (Integer) paArr[1]; //5, 6
			 */

			rdTx.commit();
			studentreg = "student is succssfully updated";
			StudentID.append("<Student>");
			StudentID.append("\n");
			StudentID.append(studentreg);
			StudentID.append("</Student>");
			String str = StudentID.toString();
			return str;

		} catch (Exception localException) {
			localException.printStackTrace();
			System.out.println(localException);

			StudentID.append("<Response>");
			StudentID.append("\n");
			StudentID.append("<Result>");
			StudentID.append("\n");
			StudentID.append("Fail");
			StudentID.append("\n");
			StudentID.append("</Result>");
			StudentID.append("\n");
			StudentID.append("<Description>");
			StudentID.append("could not updated student info");
			StudentID.append("</Description>");
			StudentID.append("\n");
			StudentID.append("<Exception>");
			StudentID.append(localException);
			StudentID.append("</Exception>");
			StudentID.append("</Response>");

			studentreg = StudentID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();

		} finally {
			rdSession.close();
		}
		return studentreg;
	}

	public String deleteStudent(int studentId, int schoolid, int branchid, int studentParentId) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String studentreg = null;
		Integer Parid = null;
		try {
			rdTx = rdSession.beginTransaction();

			if (studentParentId > 0) {
				Query empQuery1 = rdSession
						.createSQLQuery("update gbl_sm_tbl_student_parent set isDeleted='y' where StudentParentId='"
								+ studentParentId + "'");
				empQuery1.executeUpdate();

			} else {
				StudentPojo mdclpojo = (StudentPojo) rdSession.get(StudentPojo.class, studentId);

				rdSession.evict(mdclpojo);
				if (branchid == mdclpojo.getBranchId() && schoolid == mdclpojo.getSchoolId()) {
					Query empQuery = rdSession.createSQLQuery(
							"update gbl_sm_tbl_student set isDeleted='y' where StudentId='" + studentId + "'");
					empQuery.executeUpdate();

					Query empQuery1 = rdSession.createSQLQuery(
							"update gbl_sm_tbl_student_parent set isDeleted='y' where StudentId='" + studentId + "'");
					empQuery1.executeUpdate();

					studentreg = "select ParentId from gbl_sm_tbl_student_parent where StudentId='" + studentId
							+ "' and IsDeleted='y'";
					Query gsQuery = rdSession.createSQLQuery(studentreg);
					List gcList = gsQuery.list();
					Iterator gsIT = gcList.iterator();
					while (gsIT.hasNext()) {
						Parid = (Integer) gsIT.next();
						// Parid = (Integer) mdcArr[0];

						studentreg = "select gbl_sm_tbl_student_parent.StudentId,gbl_sm_tbl_student.Status"
								+ " from gbl_sm_tbl_student_parent join gbl_sm_tbl_student on gbl_sm_tbl_student_parent.StudentId=gbl_sm_tbl_student.StudentId"
								+ " where gbl_sm_tbl_student_parent.ParentId='" + Parid
								+ "' and gbl_sm_tbl_student.Status='active'";

						gsQuery = rdSession.createSQLQuery(studentreg);
						List parList1 = gsQuery.list();

						if (parList1.size() == 0) {
							studentreg = "update gbl_sm_tbl_parent set  IsDeleted='y' where ParentId='" + Parid + "'";
							empQuery = rdSession.createSQLQuery(studentreg);
							empQuery.executeUpdate();

						}
					}
					/*
					 * String Sql =
					 * "select ParentId from gbl_sm_tbl_student_parent where StudentId='"
					 * + studentId + "' and IsDeleted='y'"; Query
					 * gsQuery=rdSession.createSQLQuery(Sql); String
					 * gcList=gsQuery.list().toString();
					 * 
					 * 
					 * String sql =
					 * "select StudentId from gbl_sm_tbl_student_parent ";
					 * BigInteger numprv = (BigInteger)
					 * rdSession.createSQLQuery(Sql).uniqueResult();
					 * if(numprv.intValue()>1) { studentreg=
					 * "This parent has a other kids"; }
					 * 
					 * else { Query empQuery2 = rdSession.createSQLQuery(
					 * "update gbl_sm_tbl_parent set isDeleted='y' where StudentId='"
					 * + studentId + "'"); empQuery2.executeUpdate();
					 * 
					 * }
					 */

				}
			}
			rdTx.commit();
			studentreg = "student is succssfully deleted";
			StudentID.append("<Student>");
			StudentID.append("\n");
			StudentID.append(studentreg);
			StudentID.append("</Student>");
			String str = StudentID.toString();
			return str;
			/*
			 * } else { studentreg = "student is not deleted";
			 * StudentID.append("<Student>"); StudentID.append("\n");
			 * StudentID.append(studentreg); StudentID.append("</Student>");
			 * String str = StudentID.toString(); return str; }
			 */

		} catch (Exception localException) {
			localException.printStackTrace();
			System.out.println(localException);

			StudentID.append("<Response>");
			StudentID.append("\n");
			StudentID.append("<Result>");
			StudentID.append("\n");
			StudentID.append("Fail");
			StudentID.append("\n");
			StudentID.append("</Result>");
			StudentID.append("\n");
			StudentID.append("<Description>");
			StudentID.append("could not deleted student info");
			StudentID.append("</Description>");
			StudentID.append("\n");
			StudentID.append("<Exception>");
			StudentID.append(localException);
			StudentID.append("</Exception>");
			StudentID.append("</Response>");

			studentreg = StudentID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		} finally {
			rdSession.close();
		}
		return studentreg;
	}

	public String getStudent(int studentId, int schoolid, int branchid) {

		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String studentreg = null;
		String gsSql = null;
		try {
			rdTx = rdSession.beginTransaction();

			gsSql = "select gbl_sm_tbl_student.*, gbl_sm_tbl_bloodgroup.BloodGroupName from gbl_sm_tbl_student"
					+ " join gbl_sm_tbl_bloodgroup on gbl_sm_tbl_student.BloodGroupId = gbl_sm_tbl_bloodgroup.BloodGroupId"
					+ " left join gbl_sm_tbl_student_education on gbl_sm_tbl_student.StudentId = gbl_sm_tbl_student_education.StudentId "
					+ " where gbl_sm_tbl_student.IsDeleted is null and gbl_sm_tbl_student.StudentId ='" + studentId
					+ "' and gbl_sm_tbl_student_education.SchoolId='"+ schoolid + "' and gbl_sm_tbl_student_education.BranchId='"+branchid  // added for schoolid and branchid are mismatched from both the tables.
					+ "' and gbl_sm_tbl_student_education.currentFlg='active' and gbl_sm_tbl_student.SchoolId='"
					+ schoolid + "' and gbl_sm_tbl_student.BranchId='" + branchid + "';";

			Query gsQuery = rdSession.createSQLQuery(gsSql);
			List gcList = gsQuery.list();
			Iterator gsIT = gcList.iterator();
			while (gsIT.hasNext()) {
				Object[] mdcArr = (Object[]) gsIT.next();
				StudentID.append("<student>");
				StudentID.append("\n");
				StudentID.append("<studentId>" + mdcArr[0] + "</studentId>");
				StudentID.append("\n");

				gsSql = "select gbl_sm_tbl_student_parent.StudentParentId, gbl_sm_tbl_student_parent.ParentId , gbl_sm_tbl_parent.FirstName,gbl_sm_tbl_parent.MiddleName,gbl_sm_tbl_parent.LastName, gbl_sm_tbl_student_parent.Relation"
						+ " from gbl_sm_tbl_student_parent "
						+ "join gbl_sm_tbl_parent on gbl_sm_tbl_student_parent.ParentId=gbl_sm_tbl_parent.ParentId where gbl_sm_tbl_student_parent.IsDeleted is null and StudentId='"
						+ mdcArr[0] + "';";

				gsQuery = rdSession.createSQLQuery(gsSql);
				List parList1 = gsQuery.list();
				Iterator paIT = parList1.iterator();
				StudentID.append("<Parentrelation>");
				StudentID.append("\n");
				while (paIT.hasNext()) {
					Object[] paArr = (Object[]) paIT.next();
					StudentID.append("<Parent>");
					StudentID.append("\n");
					StudentID.append("<studnetParentId>" + paArr[0] + "</studnetParentId>");
					StudentID.append("\n");
					StudentID.append("<parentId>" + paArr[1] + "</parentId>");
					StudentID.append("\n");
					StudentID.append("<parentfirstName>" + paArr[2] + "</parentfirstName>");
					StudentID.append("\n");
					StudentID.append("<parentmiddleName>" + paArr[3] + "</parentmiddleName>");
					StudentID.append("\n");
					StudentID.append("<parentlastName>" + paArr[4] + "</parentlastName>");
					StudentID.append("\n");
					StudentID.append("<relation>" + paArr[5] + "</relation>");
					StudentID.append("\n");
					StudentID.append("</Parent>");
					StudentID.append("\n");
				}
				StudentID.append("</Parentrelation>");
				StudentID.append("\n");
				StudentID.append("<bloodGroupId>" + mdcArr[1] + "</bloodGroupId>");
				StudentID.append("\n");
				StudentID.append("<bloodGroupName>" + mdcArr[20] + "</bloodGroupName>");
				StudentID.append("\n");
				StudentID.append("<userId>" + mdcArr[2] + "</userId>");
				StudentID.append("\n");
				StudentID.append("<photo>" + mdcArr[3] + "</photo>");
				StudentID.append("\n");
				StudentID.append("<studentNumber>" + mdcArr[4] + "</studentNumber>");
				StudentID.append("\n");
				StudentID.append("<firstName>" + mdcArr[5] + "</firstName>");
				StudentID.append("\n");
				StudentID.append("<middleName>" + mdcArr[6] + "</middleName>");
				StudentID.append("\n");
				StudentID.append("<lastName>" + mdcArr[7] + "</lastName>");
				StudentID.append("\n");
				StudentID.append("<gender>" + mdcArr[8] + "</gender>");
				StudentID.append("\n");
				StudentID.append("<dOB>" + mdcArr[9] + "</dOB>");
				StudentID.append("\n");
				StudentID.append("<rollNo>" + mdcArr[10] + "</rollNo>");
				StudentID.append("\n");
				StudentID.append("<emailId>" + mdcArr[11] + "</emailId>");
				StudentID.append("\n");
				StudentID.append("<mobileNumber>" + mdcArr[12] + "</mobileNumber>");
				StudentID.append("\n");
				StudentID.append("<status>" + mdcArr[13] + "</status>");
				StudentID.append("\n");
				StudentID.append("<remarks>" + mdcArr[14] + "</remarks>");
				StudentID.append("\n");
				StudentID.append("<createdDate>" + mdcArr[15] + "</createdDate>");
				StudentID.append("\n");
				StudentID.append("<modifiedDate>" + mdcArr[16] + "</modifiedDate>");
				StudentID.append("\n");
				StudentID.append("<schoolId>" + mdcArr[17] + "</schoolId>");
				StudentID.append("\n");
				StudentID.append("<branchId>" + mdcArr[18] + "</branchId>");
				StudentID.append("\n");
				StudentID.append("<isDeleted>" + mdcArr[19] + "</isDeleted>");
				StudentID.append("\n");
				StudentID.append("</student>");
				StudentID.append("\n");
			}
			rdTx.commit();
			studentreg = StudentID.toString();
		} catch (HibernateException localException) {
			localException.printStackTrace();
			System.out.println(localException);

			StudentID.append("<Response>");
			StudentID.append("\n");
			StudentID.append("<Result>");
			StudentID.append("\n");
			StudentID.append("Fail");
			StudentID.append("\n");
			StudentID.append("</Result>");
			StudentID.append("\n");
			StudentID.append("<Description>");
			StudentID.append("could not get student info");
			StudentID.append("</Description>");
			StudentID.append("\n");
			StudentID.append("<Exception>");
			StudentID.append(localException);
			StudentID.append("</Exception>");
			StudentID.append("</Response>");

			studentreg = StudentID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		} finally {
			rdSession.close();
		}
		return studentreg;
	}

	public String getAllStudentsInfo(int PNO, int size, String classId, String sectionId, int schoolid, int branchid) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;

		// Transaction gimgTx = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		Image img = null;
		String xmlString = null;
		InputStream bigInputStream = null;
		final ByteArrayOutputStream out = new ByteArrayOutputStream();

		try {
			rdTx = rdSession.beginTransaction();

			int fset = (PNO - 1) * size;
			String filterWhere = "";
			String subQryEducation = "";
			if (classId != null) {
				filterWhere = " and gbl_sm_tbl_student.StudentId in (";

				subQryEducation = " select distinct StudentId from gbl_sm_tbl_student_education where gbl_sm_tbl_student_education.ClassId in (" + classId + ")";
				if (sectionId != null) {
					subQryEducation += " and gbl_sm_tbl_student_education.SectionId in (" + sectionId + ")";
				}
				filterWhere += subQryEducation + " ) ";
			}
			String gsSql = "select count(*) from gbl_sm_tbl_student "
					+ "join gbl_sm_tbl_student_education on gbl_sm_tbl_student.StudentId= gbl_sm_tbl_student_education.StudentId "
					+ "where (gbl_sm_tbl_student.IsDeleted is null or gbl_sm_tbl_student.IsDeleted<>'y') "
					+ " and gbl_sm_tbl_student_education.SchoolId='"+ schoolid + "' and gbl_sm_tbl_student_education.BranchId='"+branchid  // added for schoolid and branchid are mismatched from both the tables.
					+ "' and gbl_sm_tbl_student.SchoolId='" + schoolid + "' and gbl_sm_tbl_student_education.currentFlg='active' and gbl_sm_tbl_student.BranchId='"
					+ branchid + "'" + filterWhere + ";";
			Query gsQuery = rdSession.createSQLQuery(gsSql);
			Object noRecords = gsQuery.uniqueResult();
			int intNoRecords = 0;
			if (noRecords != null && Integer.parseInt(noRecords.toString()) != 0) {
				intNoRecords = Integer.parseInt(noRecords.toString());
			}
			StudentID.append("<students>");
			StudentID.append("\n");
			StudentID.append("<noRecords>" + noRecords + "</noRecords>");
			StudentID.append("\n");
			if (intNoRecords != 0) {
				if (PNO > 0 && size > 0) {
					gsSql = "select gbl_sm_tbl_student.*, gbl_sm_tbl_bloodgroup.BloodGroupName,gbl_sm_tbl_student_education.ClassId,gbl_sm_tbl_class.ClassName,gbl_sm_tbl_student_education.SectionId,gbl_sm_tbl_section.SectionName "
							+ " from gbl_sm_tbl_student "
							+ " join gbl_sm_tbl_bloodgroup on gbl_sm_tbl_student.BloodGroupId = gbl_sm_tbl_bloodgroup.BloodGroupId "
							+ " left join gbl_sm_tbl_student_education on gbl_sm_tbl_student.StudentId = gbl_sm_tbl_student_education.StudentId "
							+ " left join gbl_sm_tbl_class on gbl_sm_tbl_student_education.ClassId = gbl_sm_tbl_class.ClassId "
							+ " left join gbl_sm_tbl_section on gbl_sm_tbl_student_education.SectionId = gbl_sm_tbl_section.SectionId "
							+ " where (gbl_sm_tbl_student.IsDeleted is null or  gbl_sm_tbl_student.IsDeleted<>'y')"
							+ " and gbl_sm_tbl_student_education.SchoolId='"+ schoolid + "' and gbl_sm_tbl_student_education.BranchId='"+branchid+"'"
							+ " and gbl_sm_tbl_student.SchoolId='"+ schoolid+ "' and gbl_sm_tbl_student_education.currentFlg='active' and gbl_sm_tbl_student.BranchId='"
							+ branchid + "'" + filterWhere + " order by gbl_sm_tbl_student_education.ClassId,gbl_sm_tbl_student_education.SectionId limit " + size + " offset " + fset + ";";

				} else {
					gsSql = "select gbl_sm_tbl_student.*, gbl_sm_tbl_bloodgroup.BloodGroupName,gbl_sm_tbl_student_education.ClassId,gbl_sm_tbl_class.ClassName,gbl_sm_tbl_student_education.SectionId,gbl_sm_tbl_section.SectionName "
							+ " from gbl_sm_tbl_student "
							+ " join gbl_sm_tbl_bloodgroup on gbl_sm_tbl_student.BloodGroupId = gbl_sm_tbl_bloodgroup.BloodGroupId "
							+ " left join gbl_sm_tbl_student_education on gbl_sm_tbl_student.StudentId = gbl_sm_tbl_student_education.StudentId "
							+ " left join gbl_sm_tbl_class on gbl_sm_tbl_student_education.ClassId = gbl_sm_tbl_class.ClassId "
							+ " left join gbl_sm_tbl_section on gbl_sm_tbl_student_education.SectionId = gbl_sm_tbl_section.SectionId "
							+ "  where (gbl_sm_tbl_student.IsDeleted is null or  gbl_sm_tbl_student.IsDeleted<>'y') "
							+ " and gbl_sm_tbl_student_education.SchoolId='"+ schoolid + "' and gbl_sm_tbl_student_education.BranchId='"+branchid+"'"
							+ " and gbl_sm_tbl_student.SchoolId='"+ schoolid+ "' and gbl_sm_tbl_student_education.currentFlg='active' and gbl_sm_tbl_student.BranchId='"
							+ branchid + "'" + filterWhere + " order by gbl_sm_tbl_student_education.ClassId,gbl_sm_tbl_student_education.SectionId;";

				}
				gsQuery = rdSession.createSQLQuery(gsSql);
				List gcList = gsQuery.list();
				Iterator gsIT = gcList.iterator();
				while (gsIT.hasNext()) {
					Object[] mdcArr = (Object[]) gsIT.next();
					StudentID.append("<student>");
					StudentID.append("\n");
					StudentID.append("<studentId>" + mdcArr[0] + "</studentId>");
					StudentID.append("\n");

					gsSql = "select gbl_sm_tbl_student_parent.StudentParentId ,gbl_sm_tbl_student_parent.ParentId , gbl_sm_tbl_parent.FirstName,gbl_sm_tbl_parent.MiddleName,gbl_sm_tbl_parent.LastName, gbl_sm_tbl_student_parent.Relation"
							+ " from gbl_sm_tbl_student_parent "
							+ "join gbl_sm_tbl_parent on gbl_sm_tbl_student_parent.ParentId=gbl_sm_tbl_parent.ParentId where gbl_sm_tbl_student_parent.IsDeleted<>'y' and StudentId='"
							+ mdcArr[0] + "';";

					gsQuery = rdSession.createSQLQuery(gsSql);
					List parList1 = gsQuery.list();
					Iterator paIT = parList1.iterator();
					StudentID.append("<Parentrelation>");
					StudentID.append("\n");
					while (paIT.hasNext()) {
						Object[] paArr = (Object[]) paIT.next();
						StudentID.append("<Parent>");
						StudentID.append("\n");
						StudentID.append("<studnetParentId>" + paArr[0] + "</studnetParentId>");
						StudentID.append("\n");
						StudentID.append("<parentId>" + paArr[1] + "</parentId>");
						StudentID.append("\n");
						StudentID.append("<parentfirstName>" + paArr[2] + "</parentfirstName>");
						StudentID.append("\n");
						StudentID.append("<parentmiddleName>" + paArr[3] + "</parentmiddleName>");
						StudentID.append("\n");
						StudentID.append("<parentlastName>" + paArr[4] + "</parentlastName>");
						StudentID.append("\n");
						StudentID.append("<relation>" + paArr[5] + "</relation>");
						StudentID.append("\n");
						StudentID.append("</Parent>");
						StudentID.append("\n");
					}
					StudentID.append("</Parentrelation>");
					StudentID.append("\n");
					StudentID.append("<bloodGroupId>" + mdcArr[1] + "</bloodGroupId>");
					StudentID.append("\n");
					StudentID.append("<bloodGroupName>" + mdcArr[20] + "</bloodGroupName>");
					StudentID.append("\n");
					StudentID.append("<classId>" + mdcArr[21] + "</classId>");
					StudentID.append("\n");
					StudentID.append("<className>" + mdcArr[22] + "</className>");
					StudentID.append("\n");
					StudentID.append("<sectionId>" + mdcArr[23] + "</sectionId>");
					StudentID.append("\n");
					StudentID.append("<sectionName>" + mdcArr[24] + "</sectionName>");
					StudentID.append("\n");
					StudentID.append("<userId>" + mdcArr[2] + "</userId>");
					StudentID.append("\n");
					StudentID.append("<photo>" + mdcArr[3] + "</photo>");
					StudentID.append("\n");
					StudentID.append("<studentNumber>" + mdcArr[4] + "</studentNumber>");
					StudentID.append("\n");
					StudentID.append("<firstName>" + mdcArr[5] + "</firstName>");
					StudentID.append("\n");
					StudentID.append("<middleName>" + mdcArr[6] + "</middleName>");
					StudentID.append("\n");
					StudentID.append("<lastName>" + mdcArr[7] + "</lastName>");
					StudentID.append("\n");
					StudentID.append("<gender>" + mdcArr[8] + "</gender>");
					StudentID.append("\n");
					StudentID.append("<dOB>" + mdcArr[9] + "</dOB>");
					StudentID.append("\n");
					StudentID.append("<rollNo>" + mdcArr[10] + "</rollNo>");
					StudentID.append("\n");
					StudentID.append("<emailId>" + mdcArr[11] + "</emailId>");
					StudentID.append("\n");
					StudentID.append("<mobileNumber>" + mdcArr[12] + "</mobileNumber>");
					StudentID.append("\n");
					StudentID.append("<status>" + mdcArr[13] + "</status>");
					StudentID.append("\n");
					StudentID.append("<remarks>" + mdcArr[14] + "</remarks>");
					StudentID.append("\n");
					StudentID.append("<createdDate>" + mdcArr[15] + "</createdDate>");
					StudentID.append("\n");
					StudentID.append("<modifiedDate>" + mdcArr[16] + "</modifiedDate>");
					StudentID.append("\n");
					StudentID.append("<schoolId>" + mdcArr[17] + "</schoolId>");
					StudentID.append("\n");
					StudentID.append("<branchId>" + mdcArr[18] + "</branchId>");
					StudentID.append("\n");
					StudentID.append("<isDeleted>" + mdcArr[19] + "</isDeleted>");
					StudentID.append("\n");
					StudentID.append("</student>");
					StudentID.append("\n");
				}
			}
			rdTx.commit();
			StudentID.append("</students>");
			xmlString = StudentID.toString();
		} catch (Exception localException) {
			localException.printStackTrace();
			System.out.println(localException);

			StudentID.append("<Response>");
			StudentID.append("\n");
			StudentID.append("<Result>");
			StudentID.append("\n");
			StudentID.append("Fail");
			StudentID.append("\n");
			StudentID.append("</Result>");
			StudentID.append("\n");
			StudentID.append("<Description>");
			StudentID.append("could not get student info");
			StudentID.append("</Description>");
			StudentID.append("\n");
			StudentID.append("<Exception>");
			StudentID.append(localException);
			StudentID.append("</Exception>");
			StudentID.append("</Response>");

			xmlString = StudentID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		} finally {
			rdSession.close();
		}
		return xmlString;
	}

	public String addStudentForOtherBranch(StudentPojo pp) {

		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction rdTx = null;
		String parentreg = null;
		String bqry = null;
		try {
			rdTx = rdSession.beginTransaction();

			String fname = pp.getFirstName();
			String mname = pp.getMiddleName();
			String lname = pp.getLastName();
			String gen = pp.getGender();
			String dob = pp.getDob();
			String mailid = pp.getEmailId();
			String contactnum = pp.getMobileNumber();
			String stunum = pp.getStudentNumber();

			rdTx = rdSession.beginTransaction();

			String selectsearch = "select * from gbl_sm_tbl_student where IsDeleted is null ";

			if (fname != null && mname != null && lname != null) {
				selectsearch += "and FirstName ='" + fname + "' and MiddleName ='" + mname + "' and LastName='" + lname
						+ "'";
			}
			if (mailid != null) {
				selectsearch += " and EmailId ='" + mailid + "'";
			}

			if (contactnum != null) {
				selectsearch += " and MobileNumber='" + contactnum + "'";
			}
			if (dob != null) {
				selectsearch += " and DOB ='" + dob + "'";
			}
			if (gen != null) {
				selectsearch += " and Gender='" + gen + "'";
			}
			if (stunum != null) {
				selectsearch += " and StudentNumber='" + stunum + "'";
			}
			List list = rdSession.createSQLQuery(selectsearch).list();

			if (list.size() > 0) {
				Iterator gsIT = list.iterator();
				StudentID.append("<Students>");
				StudentID.append("\n");
				while (gsIT.hasNext()) {
					Object[] stu = (Object[]) gsIT.next();
					StudentID.append("<student>");
					StudentID.append("\n");
					StudentID.append("<studentId>" + stu[0] + "</studentId>");
					StudentID.append("\n");
					StudentID.append("<bloodGroupId>" + stu[1] + "</bloodGroupId>");
					StudentID.append("\n");
					StudentID.append("<userId>" + stu[2] + "</userId>");
					StudentID.append("\n");
					StudentID.append("<photo>" + stu[3] + "</photo>");
					StudentID.append("\n");
					StudentID.append("<studentNumber>" + stu[4] + "</studentNumber>");
					StudentID.append("\n");
					StudentID.append("<firstName>" + stu[5] + "</firstName>");
					StudentID.append("\n");
					StudentID.append("<middleName>" + stu[6] + "</middleName>");
					StudentID.append("\n");
					StudentID.append("<lastName>" + stu[7] + "</lastName>");
					StudentID.append("\n");
					StudentID.append("<gender>" + stu[8] + "</gender>");
					StudentID.append("\n");
					StudentID.append("<dOB>" + stu[9] + "</dOB>");
					StudentID.append("\n");
					StudentID.append("<rollNo>" + stu[10] + "</rollNo>");
					StudentID.append("\n");
					StudentID.append("<emailId>" + stu[11] + "</emailId>");
					StudentID.append("\n");
					StudentID.append("<mobileNumber>" + stu[12] + "</mobileNumber>");
					StudentID.append("\n");
					StudentID.append("<status>" + stu[13] + "</status>");
					StudentID.append("\n");
					StudentID.append("<remarks>" + stu[14] + "</remarks>");
					StudentID.append("\n");
					StudentID.append("<createdDate>" + stu[15] + "</createdDate>");
					StudentID.append("\n");
					StudentID.append("<modifiedDate>" + stu[16] + "</modifiedDate>");
					StudentID.append("\n");
					StudentID.append("<schoolId>" + stu[17] + "</schoolId>");
					StudentID.append("\n");
					StudentID.append("<branchId>" + stu[18] + "</branchId>");
					StudentID.append("\n");
					StudentID.append("<isDeleted>" + stu[19] + "</isDeleted>");
					StudentID.append("\n");
					StudentID.append("</student>");
					StudentID.append("\n");
				}

				rdTx.commit();
				StudentID.append("</Students>");
				StudentID.append("\n");
				parentreg = StudentID.toString();
			} else {
				Integer stuid = (Integer) rdSession.save(pp);
				System.out.println(stuid);
				rdTx.commit();
				StudentID.append("<Parent>");
				StudentID.append("\n");
				StudentID.append("<id>");
				StudentID.append("\n");
				StudentID.append(stuid);
				StudentID.append("</id>");
				StudentID.append("\n");
				StudentID.append("</Parent>");
				parentreg = StudentID.toString();
			}
		} catch (Exception localException) {

			localException.printStackTrace();
			System.out.println(localException);

			StudentID.append("<Response>");
			StudentID.append("\n");
			StudentID.append("<Result>");
			StudentID.append("\n");
			StudentID.append("Fail");
			StudentID.append("\n");
			StudentID.append("</Result>");
			StudentID.append("\n");
			StudentID.append("<Description>");
			StudentID.append("could not inserted student info");
			StudentID.append("</Description>");
			StudentID.append("\n");
			StudentID.append("<Exception>");
			StudentID.append(localException);
			StudentID.append("</Exception>");
			StudentID.append("</Response>");

			parentreg = StudentID.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (rdTx != null)
				rdTx.rollback();
		} finally {
			rdSession.close();
		}
		return parentreg;

	}

}
