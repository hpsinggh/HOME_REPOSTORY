//Vidya Version 0.8
package com.gwebitsol.core.student;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

@Path("/studenteducation/")

public interface StudentEducationServiceIntf {

	@POST
	@Path("/addstudenteducation/")
	@Consumes({ "application/xml", "application/json" })
	@Produces({ "application/xml", "application/json" })
	public Response addStudentEducation(StudentEducationPojo pp, @QueryParam("userid") int userid,
			@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
			@QueryParam("schoolid") int schoolid,@QueryParam("branchid") int branchid);

	@POST
	@Path("/updatestudenteducation/")
	@Consumes({ "application/xml", "application/json" })
	@Produces({ "application/xml", "application/json" })
	public Response updateStudentEducation(StudentEducationPojo pp, @QueryParam("userid") int userid,
			@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
			@QueryParam("schoolid") int schoolid,@QueryParam("branchid") int branchid);

	@POST
	@Path("/deletestudenteducation/")
	@Consumes({ "application/xml", "application/json" })
	@Produces({ "application/xml", "application/json" })
	public Response deleteStudentEducation(@QueryParam("studentEdId") int studentEdId, @QueryParam("userid") int userid,
			@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
			@QueryParam("schoolid") int schoolid,@QueryParam("branchid") int branchid);

	@GET
	@Path("/getstudenteducations/")
	@Consumes({ "application/xml", "application/json" })
	@Produces({ "application/xml", "application/json" })
	public Response getStudentEducationByStudentId(@QueryParam("studentid") int studentid, @QueryParam("userid") int userid,
			@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
			@QueryParam("schoolid") int schoolid,@QueryParam("branchid") int branchid);

	@GET
	@Path("/getstudentsingleeducation/")
	@Consumes({ "application/xml", "application/json" })
	@Produces({ "application/xml", "application/json" })
	public Response getStudentEducationByStudentEduId(@QueryParam("studentEdId") int studentEdId, @QueryParam("studentId") int studentId,@QueryParam("userid") int userid,
			@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
			@QueryParam("schoolid") int schoolid,@QueryParam("branchid") int branchid);
	
	
	@GET
	@Path("/getallstudentspersection/")
	@Consumes({ "application/xml", "application/json" })
	@Produces({ "application/xml", "application/json" })
	public Response getAllStudentsPerSection(@QueryParam("sectionid") int sectionid, @QueryParam("classid") int classid,@QueryParam("userid") int userid,
			@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
			@QueryParam("schoolid") int schoolid,@QueryParam("branchid") int branchid);

	@GET
	@Path("/getallstueducations/")
	@Consumes({ "application/xml", "application/json" })
	@Produces({ "application/xml", "application/json" })
	public Response getAllStuEdu(@QueryParam("userid") int userid, @QueryParam("connectionid") int connectionid,
			@QueryParam("datastoreName") String datastoreName, @QueryParam("PNO") int PNO, @QueryParam("size") int size,
			@QueryParam("schoolid") int schoolid,@QueryParam("branchid") int branchid);
	
}
