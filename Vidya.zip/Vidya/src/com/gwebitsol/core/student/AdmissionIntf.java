package com.gwebitsol.core.student;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

@Path("/admission/")
public interface AdmissionIntf {
	@POST
	@Consumes({ "application/xml", "application/json" })
	@Produces({ "application/xml", "application/json" })
	@Path("/addadmission/")
	public Response addAdmission(AdmissionPojo tp, @QueryParam("userid") int userid,
			@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
			@QueryParam("schoolid") int schoolid, @QueryParam("branchid") int branchid);

	@POST
	@Consumes({ "application/xml", "application/json" })
	@Produces({ "application/xml", "application/json" })
	@Path("/updateadmission/")
	public Response updateAdmission(AdmissionPojo tp, @QueryParam("userid") int userid,
			@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
			@QueryParam("schoolid") int schoolid, @QueryParam("branchid") int branchid);

	/*
	 * @DELETE
	 * 
	 * @Consumes({"application/xml","application/json"})
	 * 
	 * @Produces({"application/xml","application/json"})
	 * 
	 * @Path("/deleteadmission/") public Response
	 * deleteAdmission(@QueryParam("admissionID") int
	 * admissionID,@QueryParam("userid") int userid,@QueryParam("connectionid")
	 * int connectionid,@QueryParam("datastoreName") String datastoreName);
	 */

	@GET
	@Consumes({ "application/xml", "application/json" })
	@Produces({ "application/xml", "application/json" })
	@Path("/getadmission/")
	public Response getByIdAdmission(@QueryParam("admissionID") int admissionID, @QueryParam("userid") int userid,
			@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
			@QueryParam("schoolid") int schoolid, @QueryParam("branchid") int branchid,
			@QueryParam("classId") int classId, @QueryParam("studentId") int studentId,
			@QueryParam("sectionId") int sectionId);

	@GET
	// @Consumes({"application/xml", "application/json"})
	@Produces({ "application/xml", "application/json" })
	@Path("/getalladmission/")
	public Response getAllAdmission(@QueryParam("status") String status, @QueryParam("userid") int userid,
			@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName);

	@GET
	// @Consumes({"application/xml", "application/json"})
	@Produces({ "application/xml", "application/json" })
	@Path("/getalladmsn/")
	public Response getAllAdmsn(@QueryParam("status") String status, @QueryParam("userid") int userid,
			@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
			@QueryParam("PNO") int PNO, @QueryParam("size") int size, @QueryParam("schoolid") int schoolid,
			@QueryParam("branchid") int branchid, @QueryParam("classId") int classId,
			@QueryParam("studentId") int studentId, @QueryParam("sectionId") int sectionId);
}
