package com.gwebitsol.core.student;

import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.address.AddressPojo;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class TransferDao {

	StringBuffer sb = new StringBuffer();

	public String addTransfer(TransferPojo tp) {
		Session empSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction addempTx = null;
		String outStr = null;
		
		int studentid = tp.getStudentId();
		int schoolid = tp.getSchoolId();
		int branchid  = tp.getBranchId();
		 Integer Parid = null;
		
		try {
			addempTx = empSession.beginTransaction();
			Integer in = (Integer) empSession.save(tp);

			outStr = "update gbl_sm_tbl_student set Status ='inactive', IsDeleted='y' where StudentId='"+studentid
					+ "' and SchoolId='"+schoolid+"' and BranchId ='"+branchid+"';";
			Query empQuery = empSession.createSQLQuery(outStr);
			empQuery.executeUpdate();
			
			outStr = "select ParentId from gbl_sm_tbl_student_parent where StudentId='"+studentid+"'";
			Query gsQuery = empSession.createSQLQuery(outStr);
			List gcList = gsQuery.list();
			Iterator gsIT = gcList.iterator();
			while (gsIT.hasNext()) {
				 Parid = (Integer) gsIT.next();
				//Parid  =  (Integer) mdcArr[0];	
				  
			     outStr  = "select gbl_sm_tbl_student_parent.StudentId,gbl_sm_tbl_student.Status"
                           +" from gbl_sm_tbl_student_parent join gbl_sm_tbl_student on gbl_sm_tbl_student_parent.StudentId=gbl_sm_tbl_student.StudentId"
                           +" where gbl_sm_tbl_student_parent.ParentId='"+Parid+"' and gbl_sm_tbl_student.Status='active'";
			
			   gsQuery=empSession.createSQLQuery(outStr);
		       List parList1=gsQuery.list();
		       
		       if(parList1.size()==0)
		       {
		    	outStr = "update gbl_sm_tbl_parent set  IsDeleted='y' where ParentId='"+Parid+"'";
           		empQuery=empSession.createSQLQuery(outStr);
           		empQuery.executeUpdate();    
		       }
		       
		       }
		                 
			addempTx.commit();
			sb.append("<Transfer>");
			sb.append("\n");
			sb.append("<id>");
			sb.append("\n");
			sb.append(in);
			sb.append("</id>");
			sb.append("\n");
			sb.append("</Transfer>");
			outStr = sb.toString();
		} catch (Exception localException) {
			localException.printStackTrace();
			System.out.println(localException);

			sb.append("<Response>");
			sb.append("\n");
			sb.append("<Result>");
			sb.append("\n");
			sb.append("Fail");
			sb.append("\n");
			sb.append("</Result>");
			sb.append("\n");
			sb.append("<Description>");
			sb.append("could not inserted transfer info");
			sb.append("</Description>");
			sb.append("\n");
			sb.append("<Exception>");
			sb.append(localException);
			sb.append("</Exception>");
			sb.append("</Response>");

			outStr = sb.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (addempTx != null)
				addempTx.rollback();
		} finally {
			empSession.close();
		}
		return outStr;

	}

	public String updateTransfer(TransferPojo tp, int schoolid, int branchid) {
		// Session upempSession =
		// MDHibernateUtil.getSessionFactory().openSession();
		Session empSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction addempTx = null;
		// Transaction upempTx = null;
		StringBuffer sb = new StringBuffer();

		String outStr = null;
		try {
			addempTx = empSession.beginTransaction();
			TransferPojo mdclpojo = (TransferPojo) empSession.get(TransferPojo.class, tp.getTransferId());
			if (branchid == mdclpojo.getBranchId() && schoolid == mdclpojo.getSchoolId())
				empSession.evict(mdclpojo);

			empSession.update(tp);
			try {
				addempTx.commit();
			} catch (HibernateException localException) {
				localException.printStackTrace();
				System.out.println(localException);
			}
			sb.append("<Transfer>");
			sb.append("\n");
			sb.append("update successfully");
			sb.append("</Transfer>");
			String str = sb.toString();
			return str;

		}

		catch (Exception localException) {
			localException.printStackTrace();
			System.out.println(localException);

			sb.append("<Response>");
			sb.append("\n");
			sb.append("<Result>");
			sb.append("\n");
			sb.append("Fail");
			sb.append("\n");
			sb.append("</Result>");
			sb.append("\n");
			sb.append("<Description>");
			sb.append("could not updated transfer info");
			sb.append("</Description>");
			sb.append("\n");
			sb.append("<Exception>");
			sb.append(localException);
			sb.append("</Exception>");
			sb.append("</Response>");

			outStr = sb.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (addempTx != null)
				addempTx.rollback();
		} finally {
			empSession.close();
		}
		return outStr;
	}

	/*
	 * public String deleteTransfer(int transferId) { Session
	 * delempSession=MDHibernateUtil.getSessionFactory().openSession();
	 * Transaction delempTx=null; StringBuffer sb=new StringBuffer();
	 * 
	 * String outStr=null; try { delempTx=delempSession.beginTransaction();
	 * 
	 * TransferPojo ip=new TransferPojo(); ip.setTransferId(transferId);
	 * delempSession.delete(ip); try{ delempTx.commit(); }
	 * catch(HibernateException e){ System.out.println(e); }
	 * sb.append("<Transfer>"); sb.append("\n"); sb.append("delete successfully"
	 * ); sb.append("</Transfer>"); String str=sb.toString(); return str;
	 * 
	 * }
	 * 
	 * catch(Exception localException) { delempTx.rollback();
	 * localException.printStackTrace(); outStr="fail"; } finally {
	 * delempSession.close(); } return outStr; }
	 */

	public String getByIdTransfer(int transferId, int schoolid, int branchid,int studentId) {

		Session empSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction addempTx = null;
		StringBuffer sb = new StringBuffer();

		String strg = null;
		try {
			
			addempTx = empSession.beginTransaction();
			String gsSql = null;

			gsSql = "select gbl_sm_tbl_transfer.*, gbl_sm_tbl_student.StudentNumber, gbl_sm_tbl_student.FirstName,"
					+ " gbl_sm_tbl_student.MiddleName,gbl_sm_tbl_student.LastName" + " from gbl_sm_tbl_transfer"
					+ " join gbl_sm_tbl_student on gbl_sm_tbl_transfer.StudentId = gbl_sm_tbl_student.StudentId "
					+ " where gbl_sm_tbl_transfer.IsDeleted is null and TransferId ='" + transferId
					+ "' and gbl_sm_tbl_transfer.SchoolId='" + schoolid + "' and gbl_sm_tbl_transfer.BranchId='"
					+ branchid + "'";

			if(studentId>0)
			{
				gsSql+=" and gbl_sm_tbl_transfer.StudentId='"+studentId+"';";
			}
			
			Query gsQuery = empSession.createSQLQuery(gsSql);
			List gcList = gsQuery.list();
			Iterator gsIT = gcList.iterator();
			while (gsIT.hasNext()) {
				Object[] mdcArr = (Object[]) gsIT.next();
				sb.append("<tranfer>");
				sb.append("\n");
				sb.append("<transferId>" + mdcArr[0] + "</transferId>");
				sb.append("\n");
				sb.append("<studentId>" + mdcArr[1] + "</studentId>");
				sb.append("\n");
				sb.append("<studentNumber>" + mdcArr[9] + "</studentNumber>");
				sb.append("\n");
				sb.append("<studentFirstName>" + mdcArr[10] + "</studentFirstName>");
				sb.append("\n");
				sb.append("<studentMiddleName>" + mdcArr[11] + "</studentMiddleName>");
				sb.append("\n");
				sb.append("<studentLastName>" + mdcArr[12] + "</studentLastName>");
				sb.append("\n");
				sb.append("<tranferReason>" + mdcArr[2] + "</tranferReason>");
				sb.append("\n");
				sb.append("<transferTo>" + mdcArr[3] + "</transferTo>");
				sb.append("\n");
				sb.append("<transferDate>" + mdcArr[4] + "</transferDate>");
				sb.append("\n");
				sb.append("<createdDate>" + mdcArr[5] + "</createdDate>");
				sb.append("\n");
				sb.append("<schoolId>" + mdcArr[6] + "</schoolId>");
				sb.append("\n");
				sb.append("<branchId>" + mdcArr[7] + "</branchId>");
				sb.append("\n");
				sb.append("<isDeleted>" + mdcArr[8] + "</isDeleted>");
				sb.append("\n");
				sb.append("</tranfer>");
				sb.append("\n");
			}
			addempTx.commit();
			strg = sb.toString();

		} catch (Exception localException) {
			localException.printStackTrace();
			System.out.println(localException);

			sb.append("<Response>");
			sb.append("\n");
			sb.append("<Result>");
			sb.append("\n");
			sb.append("Fail");
			sb.append("\n");
			sb.append("</Result>");
			sb.append("\n");
			sb.append("<Description>");
			sb.append("could not get transfer info");
			sb.append("</Description>");
			sb.append("\n");
			sb.append("<Exception>");
			sb.append(localException);
			sb.append("</Exception>");
			sb.append("</Response>");

			strg = sb.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (addempTx != null)
				addempTx.rollback();
		} finally {
			empSession.close();
		}
		return strg;
	}

	public String getAllTransferStudents(int PNO, int size, int schoolid, int branchid) {
		Session empSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction addempTx = null;
		String xmlString = null;
		StringBuffer sb = new StringBuffer();
		try {
			addempTx = empSession.beginTransaction();

			int fset = (PNO - 1) * size;
			String gsSql = "select count(*) from gbl_sm_tbl_transfer where gbl_sm_tbl_transfer.IsDeleted is null and gbl_sm_tbl_transfer.SchoolId='"
					+ schoolid + "' and gbl_sm_tbl_transfer.BranchId='" + branchid + "';";
			Query gsQuery = empSession.createSQLQuery(gsSql);
			Object noRecords = gsQuery.uniqueResult();
			sb.append("<transfers>");
			sb.append("\n");
			sb.append("<noRecords>" + noRecords + "</noRecords>");
			sb.append("\n");

			if (PNO > 0 & size > 0) {
				gsSql = "select gbl_sm_tbl_transfer.*, gbl_sm_tbl_student.StudentNumber, gbl_sm_tbl_student.FirstName,"
						+ " gbl_sm_tbl_student.MiddleName,gbl_sm_tbl_student.LastName" + " from gbl_sm_tbl_transfer"
						+ " join gbl_sm_tbl_student on gbl_sm_tbl_transfer.StudentId = gbl_sm_tbl_student.StudentId"
						+ " where gbl_sm_tbl_transfer.IsDeleted is null and gbl_sm_tbl_transfer.SchoolId='" + schoolid
						+ "' and gbl_sm_tbl_transfer.BranchId='" + branchid + "' limit " + size + " offset " + fset
						+ " ;";

			} else {
				gsSql = "select gbl_sm_tbl_transfer.*, gbl_sm_tbl_student.StudentNumber, gbl_sm_tbl_student.FirstName,"
						+ " gbl_sm_tbl_student.MiddleName,gbl_sm_tbl_student.LastName" + " from gbl_sm_tbl_transfer"
						+ " join gbl_sm_tbl_student on gbl_sm_tbl_transfer.StudentId = gbl_sm_tbl_student.StudentId"
						+ " where gbl_sm_tbl_transfer.IsDeleted is null and gbl_sm_tbl_transfer.SchoolId='" + schoolid
						+ "' and gbl_sm_tbl_transfer.BranchId='" + branchid + "';";
			}

			gsQuery = empSession.createSQLQuery(gsSql);
			List gcList = gsQuery.list();
			Iterator gsIT = gcList.iterator();
			while (gsIT.hasNext()) {
				Object[] mdcArr = (Object[]) gsIT.next();
				sb.append("<tranfer>");
				sb.append("\n");
				sb.append("<transferId>" + mdcArr[0] + "</transferId>");
				sb.append("\n");
				sb.append("<studentId>" + mdcArr[1] + "</studentId>");
				sb.append("\n");
				sb.append("<studentNumber>" + mdcArr[9] + "</studentNumber>");
				sb.append("\n");
				sb.append("<studentFirstName>" + mdcArr[10] + "</studentFirstName>");
				sb.append("\n");
				sb.append("<studentMiddleName>" + mdcArr[11] + "</studentMiddleName>");
				sb.append("\n");
				sb.append("<studentLastName>" + mdcArr[12] + "</studentLastName>");
				sb.append("\n");
				sb.append("<tranferReason>" + mdcArr[2] + "</tranferReason>");
				sb.append("\n");
				sb.append("<transferTo>" + mdcArr[3] + "</transferTo>");
				sb.append("\n");
				sb.append("<transferDate>" + mdcArr[4] + "</transferDate>");
				sb.append("\n");
				sb.append("<createdDate>" + mdcArr[5] + "</createdDate>");
				sb.append("\n");
				sb.append("<schoolId>" + mdcArr[6] + "</schoolId>");
				sb.append("\n");
				sb.append("<branchId>" + mdcArr[7] + "</branchId>");
				sb.append("\n");
				sb.append("<isDeleted>" + mdcArr[8] + "</isDeleted>");
				sb.append("\n");
				sb.append("</tranfer>");
				sb.append("\n");
			}

			addempTx.commit();
			sb.append("</transfers>");
			sb.append("\n");

			xmlString = sb.toString();
		} catch (Exception localException) {
			localException.printStackTrace();
			System.out.println(localException);

			sb.append("<Response>");
			sb.append("\n");
			sb.append("<Result>");
			sb.append("\n");
			sb.append("Fail");
			sb.append("\n");
			sb.append("</Result>");
			sb.append("\n");
			sb.append("<Description>");
			sb.append("could not get transfer info");
			sb.append("</Description>");
			sb.append("\n");
			sb.append("<Exception>");
			sb.append(localException);
			sb.append("</Exception>");
			sb.append("</Response>");

			xmlString = sb.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (addempTx != null)
				addempTx.rollback();
		} finally {
			empSession.close();
		}
		return xmlString;
	}

}
