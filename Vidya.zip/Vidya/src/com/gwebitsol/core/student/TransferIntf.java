package com.gwebitsol.core.student;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

@Path("/transfer/")
public interface TransferIntf {
	@POST
	@Consumes({ "application/xml", "application/json" })
	@Produces({ "application/xml", "application/json" })
	@Path("/addtransfer/")
	public Response addTransfer(TransferPojo tp, @QueryParam("userid") int userid,
			@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
			@QueryParam("schoolid") int schoolid,@QueryParam("branchid") int branchid);

	@POST
	@Consumes({ "application/xml", "application/json" })
	@Produces({ "application/xml", "application/json" })
	@Path("/updatetransfer/")
	public Response updateTransfer(TransferPojo tp, @QueryParam("userid") int userid,
			@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
			@QueryParam("schoolid") int schoolid,@QueryParam("branchid") int branchid);

	/*
	 * @DELETE
	 * 
	 * @Consumes({"application/xml","application/json"})
	 * 
	 * @Produces({"application/xml","application/json"})
	 * 
	 * @Path("/deletetransfer/") public Response
	 * deleteTransfer(@QueryParam("transferId") int
	 * transferId,@QueryParam("userid") int userid,@QueryParam("connectionid")
	 * int connectionid,@QueryParam("datastoreName") String datastoreName);
	 */

	@GET
	@Consumes({ "application/xml", "application/json" })
	@Produces({ "application/xml", "application/json" })
	@Path("/gettransfer/")
	public Response getByIdTransfer(@QueryParam("transferId") int transferId, @QueryParam("userid") int userid,
			@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
			@QueryParam("schoolid") int schoolid,@QueryParam("branchid") int branchid,@QueryParam("studentId") int studentId);

	@GET
	@Consumes({ "application/xml", "application/json" })
	@Produces({ "application/xml", "application/json" })
	@Path("/getalltransfers/")
	public Response getAllTransferStudents(@QueryParam("userid") int userid,
			@QueryParam("connectionid") int connectionid, @QueryParam("datastoreName") String datastoreName,
			@QueryParam("PNO") int PNO, @QueryParam("size") int size, 
			@QueryParam("schoolid") int schoolid,@QueryParam("branchid") int branchid);

}
