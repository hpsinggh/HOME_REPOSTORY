package com.gwebitsol.core.student;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class DiaryEntryTableDao {
	
		@SuppressWarnings("deprecation")
		public String addDiaryEntryTable(DiaryEntryTablePojo diaryEntryTablePojo) {
			Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
			Transaction tx = null;
			String strg= null;
			 StringBuffer sb= new StringBuffer();
			 try {
					tx = rdSession.beginTransaction();
					
					String classIds="";
					String sectionIds="";
					String diaryIds="";
					
					String studentIds=diaryEntryTablePojo.getStudentIds();
					
					if(studentIds==null || "".equalsIgnoreCase(studentIds))
					{
						if(diaryEntryTablePojo.getSectionIds()!=null && !"".equalsIgnoreCase(diaryEntryTablePojo.getSectionIds())){
							sectionIds+=diaryEntryTablePojo.getSectionIds();
						}else{
						if(diaryEntryTablePojo.getClassIds() != null && !"".equalsIgnoreCase(diaryEntryTablePojo.getClassIds())){
							classIds+=diaryEntryTablePojo.getClassIds();
						}else{
							classIds=(String)rdSession.createSQLQuery("SELECT GROUP_CONCAT(DISTINCT classid ORDER BY classid) as classIds FROM gbl_sm_tbl_class where (IsDeleted<>'y' or IsDeleted is null) and BranchId = '"+diaryEntryTablePojo.getBranchId()+"' and SchoolId = '"+diaryEntryTablePojo.getSchoolId()+"'").addScalar("classIds", Hibernate.STRING).uniqueResult();
							
						}
						sectionIds=(String)rdSession.createSQLQuery("SELECT GROUP_CONCAT(DISTINCT sectionid ORDER BY sectionid) as sectionIds FROM gbl_sm_tbl_section where (IsDeleted<>'y' or IsDeleted is null) and classid in ("+classIds+") and BranchId = '"+diaryEntryTablePojo.getBranchId()+"' and SchoolId = '"+diaryEntryTablePojo.getSchoolId()+"'").addScalar("sectionIds", Hibernate.STRING).uniqueResult();
						}
					
					studentIds=(String)rdSession.createSQLQuery("SELECT GROUP_CONCAT(DISTINCT studentid ORDER BY studentid) as studentIds FROM gbl_sm_tbl_student_education where (IsDeleted<>'y' or IsDeleted is null) and currentflg='active' and sectionid in("+sectionIds+") and BranchId = '"+diaryEntryTablePojo.getBranchId()+"' and SchoolId = '"+diaryEntryTablePojo.getSchoolId()+"'").addScalar("studentIds", Hibernate.STRING).uniqueResult();
					
					}
					diaryIds=(String)rdSession.createSQLQuery("SELECT GROUP_CONCAT(DISTINCT diaryid ORDER BY diaryid) as diaryIds FROM gbl_sm_tbl_diarytable where (IsDeleted<>'y' or IsDeleted is null) and status='active' and studentid in("+studentIds+") and BranchId = '"+diaryEntryTablePojo.getBranchId()+"' and SchoolId = '"+diaryEntryTablePojo.getSchoolId()+"'").addScalar("diaryIds", Hibernate.STRING).uniqueResult();
					
					/* Random r = new Random();
			         long fi=(r.nextLong() % 1000000000000L);
			         int i=(r.nextInt()%10000);
			         String strLong12 = Long.toString(fi);*/
			         Random rand = new Random();
			         int strLong1 = rand.nextInt(9000000) + 1000000;
			        
			         
					
										
					if(diaryIds!=null && !"".equalsIgnoreCase(diaryIds))
					{
					int empid=diaryEntryTablePojo.getEmployeeId();					
					String subid=null;
					String unitid=null;
					String chapid=null;
					String topicid=null;
					
					String title=diaryEntryTablePojo.getTitle();
					String  date= diaryEntryTablePojo.getDate();
					String subdate=diaryEntryTablePojo.getSubmitDate();
					String status=diaryEntryTablePojo.getStatus();
					String des=diaryEntryTablePojo.getDescription();
					int sclid=diaryEntryTablePojo.getSchoolId();
					int brnid=diaryEntryTablePojo.getBranchId();
					String remarks=diaryEntryTablePojo.getRemarks();
					String mdate=diaryEntryTablePojo.getModifiedDate();
					if(diaryEntryTablePojo.getSubjectId()!=0){
						subid=String.valueOf(diaryEntryTablePojo.getSubjectId());
					}
					if(diaryEntryTablePojo.getUnitId()!=0){
						unitid=String.valueOf(diaryEntryTablePojo.getUnitId());
					}
					if(diaryEntryTablePojo.getChapterId()!=0){
						chapid=String.valueOf(diaryEntryTablePojo.getChapterId());
					}
					if(diaryEntryTablePojo.getTopicId()!=0){
						topicid=String.valueOf(diaryEntryTablePojo.getTopicId());
					}
					Query icQuery=rdSession.createSQLQuery("CALL `diaryentry`('"+empid+"', '"+diaryIds+"', "+subid+", "+unitid+", "+chapid+", "+topicid+",'"+title+"', '"+date+"', '"+subdate+"', '"+status+"','"+des+"', '"+sclid+"', '"+brnid+"', '"+remarks+"', '"+strLong1+"','"+mdate+"')");
					icQuery.executeUpdate();
					}
					tx.commit();
					//Integer i=(Integer) rdSession.save(diaryEntryTablePojo);	 
					//System.out.println(i);
					//tx.commit();
					sb.append("<diaryEntryTable>");
					sb.append("\n");
					sb.append("Diary Entries are inserted successfuly with Transaction Id "+strLong1);
					//sb.append(i);
					sb.append("\n");
					sb.append("</diaryEntryTable>");
					strg= sb.toString();
			 		}		
			 			catch (Exception localException){
			 						System.out.println(localException);
			 						localException.printStackTrace();
								   sb.append("<Response>");
								   sb.append("\n");
								   sb.append("<Result>");
								   sb.append("\n");
								   sb.append("Fail");
								   sb.append("\n");
								   sb.append("</Result>");
								   sb.append("\n");
								   sb.append("<Description>");
								   sb.append("could not inserted diaryEntryTable info");
								   sb.append("</Description>");
								   sb.append("\n");
								   sb.append("<Exception>");
								   sb.append(localException);
								   sb.append("</Exception>");
								   sb.append("</Response>");
								    strg=sb.toString();
								   MDTransactionWriter.exceptionlog.info(localException);
								  if (tx!=null)
								   tx.rollback();
								  } finally {
								   rdSession.close(); 
								  }
								  return strg;
								 }

		public String deleteDiaryEntryTable(int diaryentrytableId,int schoolId,int branchId) {
			Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
			Transaction tx = null;
			StringBuffer sb=new StringBuffer();
			String strg= null;
			try {
					tx = rdSession.beginTransaction();
					/*DiaryEntryTablePojo diaryEntrytable=new DiaryEntryTablePojo();				
					diaryEntrytable.setDiaryEntryId(diaryentrytableId);
					rdSession.delete(diaryEntrytable);	
					tx.commit();*/
					DiaryEntryTablePojo diaryentrytable = (DiaryEntryTablePojo) rdSession.get(DiaryEntryTablePojo.class,diaryentrytableId);
					   
					   rdSession.evict(diaryentrytable);
					   
					   if(branchId==diaryentrytable.getBranchId()&&schoolId==diaryentrytable.getSchoolId())
					   {
					   Query empQuery=rdSession.createSQLQuery("update gbl_sm_tbl_diaryentry set isDeleted='y' where diaryEntryId='"+diaryentrytableId+"'");
					   empQuery.executeUpdate();
					   tx.commit();
					sb.append("<DiaryEntryTable>");
				    sb.append("\n");
				    sb.append("<id>");
					sb.append("\n");
					sb.append("diaryentrytable item deleted");
					sb.append("</id>");
					sb.append("\n");
					sb.append("</DiaryEntryTable>");
					strg= sb.toString();	
					}else{
						strg ="diaryentrytable is not deleted";
					    sb.append("<diaryEntryTable>");
					    sb.append("\n");
					    sb.append(strg);
					    sb.append("</diaryEntryTable>");
					    String str = sb.toString();
					    return str;
					}
			}
					catch(Exception localException)
					{
						System.out.println(localException);
						localException.printStackTrace();
					   sb.append("<Response>");
					   sb.append("\n");
					   sb.append("<Result>");
					   sb.append("\n");
					   sb.append("Fail");
					   sb.append("\n");
					   sb.append("</Result>");
					   sb.append("\n");
					   sb.append("<Description>");
					   sb.append("could not deleted DiaryEntryTable item");
					   sb.append("</Description>");
					   sb.append("\n");
					   sb.append("<Exception>");
					   sb.append(localException);
					   sb.append("</Exception>");
					   sb.append("</Response>");
					   strg=sb.toString();
					   MDTransactionWriter.exceptionlog.info(localException);
					  if (tx!=null)
					   tx.rollback();
					  } finally {
					   rdSession.close(); 
					  }
					  return strg;
					 }

	public String updateDiaryEntryTable(DiaryEntryTablePojo diaryEntryTablePojo,int schoolId,int branchId) {
		Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb= new StringBuffer();
		String strg= null;
		try {
				tx = rdSession.beginTransaction();
				/*rdSession.update(diaryEntryTablePojo);
				tx.commit();*/
				DiaryEntryTablePojo de = (DiaryEntryTablePojo)rdSession.get(DiaryEntryTablePojo.class,diaryEntryTablePojo.getDiaryEntryId());

				  rdSession.evict(de);
				   if(schoolId==de.getSchoolId()&&branchId==de.getBranchId())
					   rdSession.update(diaryEntryTablePojo);				     
				   tx.commit();
				sb.append("<diaryEntryTable>");
				sb.append("\n");
			    sb.append("<diaryTableid>");
				sb.append("diaryEntryTable succssfully updated");
				sb.append("</diaryTableid>");
				sb.append("\n");
				sb.append("</diaryEntryTable>");
				strg= sb.toString();		
				}
		catch (Exception localException) {
					System.out.println(localException);
					localException.printStackTrace();
				   sb.append("<Response>");
				   sb.append("\n");
				   sb.append("<Result>");
				   sb.append("\n");
				   sb.append("Fail");
				   sb.append("\n");
				   sb.append("</Result>");
				   sb.append("\n");
				   sb.append("<Description>");
				   sb.append("could not update diaryEntryTable item");
				   sb.append("</Description>");
				   sb.append("\n");
				   sb.append("<Exception>");
				   sb.append(localException);
				   sb.append("</Exception>");
				   sb.append("</Response>");
				   strg=sb.toString();
				   MDTransactionWriter.exceptionlog.info(localException);
				  if (tx!=null)
				   tx.rollback();
				  } finally {
				   rdSession.close(); 
				  }
				  return strg;
				 }

	@SuppressWarnings("rawtypes")
	public String getAllDiaryEntryTable(int PNO, int size,int schoolId,int branchId,String classId,String sectionId,String studentId,String DETId,String DiaryEntryDate) {
			  String xmlString=null;
			  Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
			  Transaction stgTx=null;
			  StringBuffer sb = new StringBuffer();
			  try
			  {
			   stgTx=stgSession.beginTransaction();
	
			    int fset = (PNO-1)*size;
			    String filterWhere="";
			    if(classId!=null && !"".equalsIgnoreCase(classId)){									  								    	
			    	filterWhere+=" and stuedu.ClassId in("+classId+")";
			    
			    	if(sectionId!=null && !"".equalsIgnoreCase(sectionId)){
					filterWhere +=  " and stuedu.SectionId in("+sectionId+")";
			    	}
			    }
						if(studentId!=null && !"".equalsIgnoreCase(studentId)){
						filterWhere +=  " and stu.StudentNumber in("+studentId+")";
						}
			    	
			    
				if(DETId!=null && !"".equalsIgnoreCase(DETId)){
					filterWhere += " and de.DETId ="+DETId;
				}
			    if(DiaryEntryDate!=null && !"".equalsIgnoreCase(DiaryEntryDate)){
			    	filterWhere+=" and de.Date in ('"+DiaryEntryDate+"')";	
			    }
			    
			    String gsSql ="SELECT count(*) FROM gbl_sm_tbl_diaryentry as de join gbl_sm_tbl_diarytable as dt on dt.DiaryId=de.DiaryId  left outer join gbl_sm_tbl_student as stu on dt.StudentId=stu.StudentId left outer join gbl_sm_tbl_subjects as sub on sub.SubjectId=de.SubjectId  left outer join gbl_sm_tbl_subject_type as subtype on sub.SubjectTypeId=subtype.SubjectTypeId left outer join gbl_sm_tbl_student_education as stuedu on stuedu.StudentId =stu.StudentId left outer join gbl_sm_tbl_class as cls on stuedu.ClassId=cls.ClassId left outer join gbl_sm_tbl_section as sec on sec.SectionId=stuedu.SectionId left outer join gbl_sm_tbl_staff as staff on de.EmployeeId=staff.EmployeeId left outer join gbl_sm_tbl_topic as topic on topic.TopicId=de.TopicId left outer join gbl_sm_tbl_units as units on units.UnitId=de.UnitId left outer join gbl_sm_tbl_chapter as chapter on chapter.ChapterId=de.ChapterId where (de.isDeleted<>'y' or de.isDeleted is 	null) and de.schoolId='"+schoolId+"' and de.branchId='"+branchId+"'"+filterWhere+"";
			    Query gsQuery=stgSession.createSQLQuery(gsSql);
			    Object noRecords= gsQuery.uniqueResult();
			    int intNoRecords=0;
				if(noRecords!=null && Integer.parseInt(noRecords.toString())!=0)
				{
					intNoRecords=Integer.parseInt(noRecords.toString());
				} if(intNoRecords!=0)
				{
			    sb.append("<diaryentrytables>");
			    sb.append("\n");
			    sb.append("<noRecords>"+noRecords+"</noRecords>");
			    sb.append("\n");
			    
			     if (PNO > 0 & size > 0){
			     gsSql="SELECT de.DiaryEntryId,de.EmployeeId,dt.StudentId,stu.StudentNumber,stu.FirstName,stu.MiddleName,stu.LastName,stuedu.ClassId,cls.ClassName,stuedu.SectionId,sec.SectionName,de.DiaryId,dt.Title,de.SubjectId,sub.SubjectTypeId,subtype.SubjectName,de.UnitId,units.UnitNo,units.UnitName,de.ChapterId,chapter.ChapterNo,chapter.ChapterName,de.TopicId,topic.TopicName,de.Title,de.Date,de.SubmitDate,de.`Status`,de.Description,de.Remarks,de.CreatedDate,de.ModifiedDate,de.SchoolId,de.BranchId,de.DETId FROM gbl_sm_tbl_diaryentry as de join gbl_sm_tbl_diarytable as dt on dt.DiaryId=de.DiaryId  left outer join gbl_sm_tbl_student as stu on dt.StudentId=stu.StudentId left outer join gbl_sm_tbl_subjects as sub on sub.SubjectId=de.SubjectId left outer join gbl_sm_tbl_subject_type as subtype on sub.SubjectTypeId=subtype.SubjectTypeId left outer join gbl_sm_tbl_student_education as stuedu on stuedu.StudentId =stu.StudentId left outer join gbl_sm_tbl_class as cls on stuedu.ClassId=cls.ClassId left outer join gbl_sm_tbl_section as sec on sec.SectionId=stuedu.SectionId left outer join gbl_sm_tbl_topic as topic on topic.TopicId=de.TopicId left outer join gbl_sm_tbl_units as units on units.UnitId=de.UnitId left outer join gbl_sm_tbl_chapter as chapter on chapter.ChapterId=de.ChapterId where (de.isDeleted<>'y' or de.isDeleted is 	null) and de.schoolId='"+schoolId+"' and de.branchId='"+branchId+"'"+filterWhere+" limit "+size+" offset "+fset;
			     }
			     else {
			      gsSql="SELECT de.DiaryEntryId,de.EmployeeId,dt.StudentId,stu.StudentNumber,stu.FirstName,stu.MiddleName,stu.LastName,stuedu.ClassId,cls.ClassName,stuedu.SectionId,sec.SectionName,de.DiaryId,dt.Title,de.SubjectId,sub.SubjectTypeId,subtype.SubjectName,de.UnitId,units.UnitNo,units.UnitName,de.ChapterId,chapter.ChapterNo,chapter.ChapterName,de.TopicId,topic.TopicName,de.Title,de.Date,de.SubmitDate,de.`Status`,de.Description,de.Remarks,de.CreatedDate,de.ModifiedDate,de.SchoolId,de.BranchId,de.DETId FROM gbl_sm_tbl_diaryentry as de join gbl_sm_tbl_diarytable as dt on dt.DiaryId=de.DiaryId  left outer join gbl_sm_tbl_student as stu on dt.StudentId=stu.StudentId left outer join gbl_sm_tbl_subjects as sub on sub.SubjectId=de.SubjectId left outer join gbl_sm_tbl_subject_type as subtype on sub.SubjectTypeId=subtype.SubjectTypeId left outer join gbl_sm_tbl_student_education as stuedu on stuedu.StudentId =stu.StudentId left outer join gbl_sm_tbl_class as cls on stuedu.ClassId=cls.ClassId left outer join gbl_sm_tbl_section as sec on sec.SectionId=stuedu.SectionId left outer join gbl_sm_tbl_topic as topic on topic.TopicId=de.TopicId left outer join gbl_sm_tbl_units as units on units.UnitId=de.UnitId left outer join gbl_sm_tbl_chapter as chapter on chapter.ChapterId=de.ChapterId where (de.isDeleted<>'y' or de.isDeleted is 	null) and de.schoolId='"+schoolId+"' and de.branchId='"+branchId+"'"+filterWhere+"";
			     }
			    gsQuery=stgSession.createSQLQuery(gsSql);
			    List gcList=gsQuery.list();
			    Iterator gsIT=gcList.iterator();
			     while(gsIT.hasNext())
			     {
			      Object[] mdcArr=(Object[])gsIT.next();
			      sb.append("<diaryentrytable>");
			      sb.append("\n");
			      sb.append("<diaryEntryId>"+mdcArr[0]+"</diaryEntryId>");
			      sb.append("\n");
			      sb.append("<employeeId>" + mdcArr[1]+ "</employeeId>");
			      int employeeId=(Integer) mdcArr[1] ;
			      //sb.append("<studentId>" +studentId+ "</studentId>");
			      //sb.append("\n");
			      if(employeeId!=0)			    	
			      {
			       gsSql="select staff.EmployeeId,staff.StaffNumber,staff.FirstName,staff.MiddleName,staff.LastName from gbl_sm_tbl_staff as staff where (staff.isDeleted<>'y' or  staff.isDeleted is null) and staff.EmployeeId='"+employeeId+"'";
			       gsQuery = stgSession.createSQLQuery(gsSql);
					List parList1 = gsQuery.list();
					Iterator paIT = parList1.iterator();
					while (paIT.hasNext()) {
						Object[] paArr = (Object[]) paIT.next();
						
					      sb.append("<staffNumber>" + paArr[1] + "</staffNumber>");
					      sb.append("\n");
					      sb.append("<firstName>" + paArr[2] + "</firstName>");
					      sb.append("\n");
					      sb.append("<middleName>" + paArr[3]+ "</middleName>");
					      sb.append("\n");
					      sb.append("<lastName>" + paArr[4] + "</lastName>");
					      sb.append("\n");					
					}
			      }else{
			    	  sb.append("<staffNumber></staffNumber>");
						sb.append("\n");
						sb.append("<firstName></firstName>");
						sb.append("\n");
						sb.append("<middleName></middleName>");
						sb.append("\n");
						sb.append("<lastName></lastName>");
						sb.append("\n");
			      }
			      sb.append("<studentId>" + mdcArr[2]+ "</studentId>");
			      sb.append("\n");
			      sb.append("<studentNumber>" + mdcArr[3]+ "</studentNumber>");
			      sb.append("\n");
			      sb.append("<firstName>" + mdcArr[4] + "</firstName>");
			      sb.append("\n");
			      sb.append("<middleName>" + mdcArr[5]+ "</middleName>");
			      sb.append("\n");
			      sb.append("<lastName>" + mdcArr[6] + "</lastName>");
			      sb.append("\n");
			      sb.append("<classId>" + mdcArr[7]+ "</classId>");
			      sb.append("\n");
			      sb.append("<className>" + mdcArr[8] + "</className>");
			      sb.append("\n");
			      sb.append("<sectionId>" + mdcArr[9]+ "</sectionId>");
			      sb.append("\n");
			      sb.append("<sectionName>" + mdcArr[10] + "</sectionName>");
			      sb.append("\n");
			      sb.append("<diaryId>" +  mdcArr[11]+ "</diaryId>");
			      sb.append("\n");
			      sb.append("<title>" + mdcArr[12] + "</title>");
			      sb.append("\n");
			      sb.append("<subjectId>"+mdcArr[13]+"</subjectId>");
			      sb.append("\n");
			      sb.append("<subjectTypeId>"+mdcArr[14]+"</subjectTypeId>");
			      sb.append("\n");
			      sb.append("<subjectName>" + mdcArr[15]+ "</subjectName>");
			      sb.append("\n");
			      sb.append("<unitId>" + mdcArr[16]+ "</unitId>");
			      sb.append("\n");
			      sb.append("<unitNo>" + mdcArr[17]+ "</unitNo>");
			      sb.append("\n");
			      sb.append("<unitName>" + mdcArr[18] + "</unitName>");
			      sb.append("\n");
			      sb.append("<chapterId>" + mdcArr[19] + "</chapterId>");
			      sb.append("\n");
			      sb.append("<chapterNo>" + mdcArr[20]+ "</chapterNo>");
			      sb.append("\n");
			      sb.append("<chapterName>" + mdcArr[21] + "</chapterName>");
			      sb.append("\n");
			      sb.append("<topicId>" +  mdcArr[22]+ "</topicId>");
			      sb.append("\n");
			      sb.append("<topicName>" + mdcArr[23] + "</topicName>");
			      sb.append("\n");
			      sb.append("<title>"+mdcArr[24]+"</title>");
			      sb.append("\n");
			      sb.append("<date>" + mdcArr[25]+ "</date>");
			      sb.append("\n");
			      sb.append("<submitDate>" + mdcArr[26]+ "</submitDate>");
			      sb.append("\n");
			      sb.append("<status>" + mdcArr[27] + "</status>");
			      sb.append("\n");
			      sb.append("<description>" + mdcArr[28] + "</description>");
			      sb.append("\n");
			      sb.append("<remarks>" + mdcArr[29] + "</remarks>");
			      sb.append("\n");   
			      sb.append("<createdDate>" + mdcArr[30] + "</createdDate>");
			      sb.append("\n");
			      sb.append("<modifiedDate>" + mdcArr[31] + "</modifiedDate>");
			      sb.append("\n");
			      sb.append("<schoolId>" + mdcArr[32] + "</schoolId>");
			      sb.append("\n");
			      sb.append("<branchId>" + mdcArr[33] + "</branchId>");
			      sb.append("\n");
			      sb.append("<DETId>" + mdcArr[34]+ "</DETId>");
			      sb.append("\n");
			      sb.append("</diaryentrytable>");		      
			     }
				}
			    stgTx.commit();
			    sb.append("</diaryentrytables>");
			    sb.append("\n");

			    xmlString=sb.toString();   
			  } 
	
		catch(Exception localException)
		{
			System.out.println(localException);
			localException.printStackTrace();
		   sb.append("<Response>");
		   sb.append("\n");
		   sb.append("<Result>");
		   sb.append("\n");
		   sb.append("Fail");
		   sb.append("\n");
		   sb.append("</Result>");
		   sb.append("\n");
		   sb.append("<Description>");
		   sb.append("could not getall DiaryEntryTable items");
		   sb.append("</Description>");
		   sb.append("\n");
		   sb.append("<Exception>");
		   sb.append(localException);
		   sb.append("</Exception>");
		   sb.append("</Response>");
		   xmlString=sb.toString();
		   MDTransactionWriter.exceptionlog.info(localException);
		  if (stgTx!=null)
			  stgTx.rollback();
		  } finally {
		   stgSession.close(); 
		  }
		  return xmlString;
		 }

	@SuppressWarnings("rawtypes")
	public String getByIdDiaryEntryTable(int diaryentrytableId,int schoolId,int branchId) {
		Session stgSession=MDHibernateUtil.getSessionFactory().openSession();
		  Transaction tx=null;
		StringBuffer sb= new StringBuffer();
		String strg= null;
		try{
			tx = stgSession.beginTransaction();
			Query query=stgSession.createSQLQuery("SELECT de.DiaryEntryId,de.EmployeeId,dt.StudentId,stu.StudentNumber,stu.FirstName,stu.MiddleName,stu.LastName,stuedu.ClassId,cls.ClassName,stuedu.SectionId,sec.SectionName,de.DiaryId,dt.Title,de.SubjectId,sub.SubjectTypeId,subtype.SubjectName,de.UnitId,units.UnitNo,units.UnitName,de.ChapterId,chapter.ChapterNo,chapter.ChapterName,de.TopicId,topic.TopicName,de.Title,de.Date,de.SubmitDate,de.`Status`,de.Description,de.Remarks,de.CreatedDate,de.ModifiedDate,de.SchoolId,de.BranchId,de.DETId FROM gbl_sm_tbl_diaryentry as de join gbl_sm_tbl_diarytable as dt on dt.DiaryId=de.DiaryId  left outer join gbl_sm_tbl_student as stu on dt.StudentId=stu.StudentId left outer join gbl_sm_tbl_subjects as sub on sub.SubjectId=de.SubjectId left outer join gbl_sm_tbl_subject_type as subtype on sub.SubjectTypeId=subtype.SubjectTypeId left outer join gbl_sm_tbl_student_education as stuedu on stuedu.StudentId =stu.StudentId left outer join gbl_sm_tbl_class as cls on stuedu.ClassId=cls.ClassId left outer join gbl_sm_tbl_section as sec on sec.SectionId=stuedu.SectionId left outer join gbl_sm_tbl_topic as topic on topic.TopicId=de.TopicId left outer join gbl_sm_tbl_units as units on units.UnitId=de.UnitId left outer join gbl_sm_tbl_chapter as chapter on chapter.ChapterId=de.ChapterId where (de.isDeleted<>'y' or de.isDeleted is null) and de.DiaryEntryId='"+diaryentrytableId+"' and de.schoolId='"+schoolId+"' and de.branchId='"+branchId+"'");
		    List gcList=query.list();
		    Iterator gsIT=gcList.iterator();
		     while(gsIT.hasNext())
		     {
		      Object[] mdcArr=(Object[])gsIT.next();
		  
		      sb.append("<diaryentrytable>");
		      sb.append("\n");
		      sb.append("<diaryEntryId>"+mdcArr[0]+"</diaryEntryId>");
		      sb.append("\n");
		      sb.append("<employeeId>" + mdcArr[1]+ "</employeeId>");
		      int employeeId=(Integer) mdcArr[1] ;
		      //sb.append("<studentId>" +studentId+ "</studentId>");
		      //sb.append("\n");
		      if(employeeId!=0)			    	
		      {
		      String  gsSql="select staff.EmployeeId,staff.StaffNumber,staff.FirstName,staff.MiddleName,staff.LastName from gbl_sm_tbl_staff as staff where (staff.isDeleted<>'y' or  staff.isDeleted is null) and staff.EmployeeId='"+employeeId+"'";
		      query = stgSession.createSQLQuery(gsSql);
				List parList1 = query.list();
				Iterator paIT = parList1.iterator();
				while (paIT.hasNext()) {
					Object[] paArr = (Object[]) paIT.next();
					
				      sb.append("<staffNumber>" + paArr[1] + "</staffNumber>");
				      sb.append("\n");
				      sb.append("<firstName>" + paArr[2] + "</firstName>");
				      sb.append("\n");
				      sb.append("<middleName>" + paArr[3]+ "</middleName>");
				      sb.append("\n");
				      sb.append("<lastName>" + paArr[4] + "</lastName>");
				      sb.append("\n");					
				}
		      }else{
		    	  sb.append("<staffNumber></staffNumber>");
					sb.append("\n");
					sb.append("<firstName></firstName>");
					sb.append("\n");
					sb.append("<middleName></middleName>");
					sb.append("\n");
					sb.append("<lastName></lastName>");
					sb.append("\n");
		      }
		      sb.append("<studentId>" + mdcArr[2]+ "</studentId>");
		      sb.append("\n");
		      sb.append("<studentNumber>" + mdcArr[3]+ "</studentNumber>");
		      sb.append("\n");
		      sb.append("<firstName>" + mdcArr[4] + "</firstName>");
		      sb.append("\n");
		      sb.append("<middleName>" + mdcArr[5]+ "</middleName>");
		      sb.append("\n");
		      sb.append("<lastName>" + mdcArr[6] + "</lastName>");
		      sb.append("\n");
		      sb.append("<classId>" + mdcArr[7]+ "</classId>");
		      sb.append("\n");
		      sb.append("<className>" + mdcArr[8] + "</className>");
		      sb.append("\n");
		      sb.append("<sectionId>" + mdcArr[9]+ "</sectionId>");
		      sb.append("\n");
		      sb.append("<sectionName>" + mdcArr[10] + "</sectionName>");
		      sb.append("\n");
		      sb.append("<diaryId>" +  mdcArr[11]+ "</diaryId>");
		      sb.append("\n");
		      sb.append("<title>" + mdcArr[12] + "</title>");
		      sb.append("\n");
		      sb.append("<subjectId>"+mdcArr[13]+"</subjectId>");
		      sb.append("\n");
		      sb.append("<subjectTypeId>"+mdcArr[14]+"</subjectTypeId>");
		      sb.append("\n");
		      sb.append("<subjectName>" + mdcArr[15]+ "</subjectName>");
		      sb.append("\n");
		      sb.append("<unitId>" + mdcArr[16]+ "</unitId>");
		      sb.append("\n");
		      sb.append("<unitNo>" + mdcArr[17]+ "</unitNo>");
		      sb.append("\n");
		      sb.append("<unitName>" + mdcArr[18] + "</unitName>");
		      sb.append("\n");
		      sb.append("<chapterId>" + mdcArr[19] + "</chapterId>");
		      sb.append("\n");
		      sb.append("<chapterNo>" + mdcArr[20]+ "</chapterNo>");
		      sb.append("\n");
		      sb.append("<chapterName>" + mdcArr[21] + "</chapterName>");
		      sb.append("\n");
		      sb.append("<topicId>" +  mdcArr[22]+ "</topicId>");
		      sb.append("\n");
		      sb.append("<topicName>" + mdcArr[23] + "</topicName>");
		      sb.append("\n");
		      sb.append("<title>"+mdcArr[24]+"</title>");
		      sb.append("\n");
		      sb.append("<date>" + mdcArr[25]+ "</date>");
		      sb.append("\n");
		      sb.append("<submitDate>" + mdcArr[26]+ "</submitDate>");
		      sb.append("\n");
		      sb.append("<status>" + mdcArr[27] + "</status>");
		      sb.append("\n");
		      sb.append("<description>" + mdcArr[28] + "</description>");
		      sb.append("\n");
		      sb.append("<remarks>" + mdcArr[29] + "</remarks>");
		      sb.append("\n");   
		      sb.append("<createdDate>" + mdcArr[30] + "</createdDate>");
		      sb.append("\n");
		      sb.append("<modifiedDate>" + mdcArr[31] + "</modifiedDate>");
		      sb.append("\n");
		      sb.append("<schoolId>" + mdcArr[32] + "</schoolId>");
		      sb.append("\n");
		      sb.append("<branchId>" + mdcArr[33] + "</branchId>");
		      sb.append("\n");
		      sb.append("<DETId>" + mdcArr[34]+ "</DETId>");
		      sb.append("\n");
		      sb.append("\n");
		      sb.append("</diaryentrytable>");
				String str= sb.toString();
				return str;
		}
							} 	catch (Exception localException) {
								System.out.println(localException);
								localException.printStackTrace();
							   sb.append("<Response>");
							   sb.append("\n");
							   sb.append("<Result>");
							   sb.append("\n");
							   sb.append("Fail");
							   sb.append("\n");
							   sb.append("</Result>");
							   sb.append("\n");
							   sb.append("<Description>");
							   sb.append("could not getby diaryentrytable item");
							   sb.append("</Description>");
							   sb.append("\n");
							   sb.append("<Exception>");
							   sb.append(localException);
							   sb.append("</Exception>");
							   sb.append("</Response>");
							   sb.append("</diaryEntryId>");
							   sb.append("</diaryentrytable>");
							   
							   strg=sb.toString();
							   MDTransactionWriter.exceptionlog.info(localException);
							  if (tx!=null)
							   tx.rollback();
							  } finally {
							   stgSession.close(); 
							  }
							  return strg;
							 }

}

