//Vidya Version 0.8
package com.gwebitsol.core.student;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.gwebitsol.core.security.MDValidation;
import com.gwebitsol.core.security.MDVerifyConnectionID;
import com.gwebitsol.core.security.MDVerifyDatastoreName;
import com.gwebitsol.core.usermanagement.MDGetUserFromID;
import com.gwebitsol.core.util.MDTransactionWriter;

public class StudentService implements StudentServiceIntf {

	@Context
	private HttpServletRequest hsr;

	public Response addStudent(StudentPojo pp, int userid, int connectionid, String datastoreName, int schoolid,int branchId) {

		MDTransactionWriter.accesslog.info("Request from:" + hsr.getRemoteHost());

		String status = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();

		pp.setSchoolId(schoolid);
		pp.setBranchId(branchId);
		
		try {

			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName, schoolid, branchId);
			System.out.println("verifiedvalue::"+ret);
			
			MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userid);
			
			if (ret == 1) // && rtVal==1)
			{
				StudentDao pd = new StudentDao();
				status = pd.addStudent(pp);
				System.out.println(status);
				Long el = System.currentTimeMillis();
				String endDate = dateFormat.format(new Date());
				// status= "user validation is successfull";
				MDTransactionWriter.writeLog(datastoreName, "StudentService_addStudent", requester, startDate, endDate, sl, el, status,
						hsr.getRemoteHost());
			} else {
				status = "you are not authorised user";
			}
		} catch (Exception localException) {

			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status = "failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response updateStudent(StudentPojo pp, int userid, int connectionid, String datastoreName, int schoolid,int branchId) {

		MDTransactionWriter.accesslog.info("Request from:" + hsr.getRemoteHost());

		String status = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();

		pp.setSchoolId(schoolid);
		pp.setBranchId(branchId);
		
		try {

			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName, schoolid, branchId);
			System.out.println("verifiedvalue::"+ret);
			
			MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userid);
			
			if (ret == 1) // && rtVal==1)
			{
				StudentDao pd = new StudentDao();
				status = pd.updateStudent(pp,schoolid,branchId);
				System.out.println(status);
				Long el = System.currentTimeMillis();
				String endDate = dateFormat.format(new Date());
				// status= "user validation is successfull";
				MDTransactionWriter.writeLog(datastoreName, "StudentService_updateStudent", requester, startDate, endDate, sl, el, status,
						hsr.getRemoteHost());
			} else {
				status = "you are not authorised user";
			}
		} catch (Exception localException) {

			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status = "failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response deleteStudent(int studentId, int userid, int connectionid, String datastoreName, int schoolid,int branchId,int studentParentId) {

		MDTransactionWriter.accesslog.info("Request from:" + hsr.getRemoteHost());

		String status = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();

		try {

			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName, schoolid, branchId);
			System.out.println("verifiedvalue::"+ret);
			
			MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userid);
			
			if (ret == 1) // && rtVal==1)
			{
				StudentDao pd = new StudentDao();

				status = pd.deleteStudent(studentId,schoolid, branchId,studentParentId);
				System.out.println(status);
				Long el = System.currentTimeMillis();
				String endDate = dateFormat.format(new Date());
				// status= "user validation is successfull";
				MDTransactionWriter.writeLog(datastoreName, "StudentService_deleteStudent", requester, startDate, endDate, sl, el, status,
						hsr.getRemoteHost());
			} else {
				status = "you are not authorised user";
			}
		} catch (Exception localException) {

			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status = "failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response getStudent(int studentId, int userid, int connectionid, String datastoreName, int schoolid,int branchId) {

		String status = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();

		try {

			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName, schoolid, branchId);
			System.out.println("verifiedvalue::"+ret);
			
			MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userid);
			
			if (ret == 1) // && rtVal==1)
			{
				StudentDao pd = new StudentDao();
				status = pd.getStudent(studentId, schoolid, branchId);
				System.out.println(status);
				Long el = System.currentTimeMillis();
				String endDate = dateFormat.format(new Date());
				// status= "user validation is successfull";
				MDTransactionWriter.writeLog(datastoreName, "StudentService_getStudent", requester, startDate, endDate, sl, el, status,
						hsr.getRemoteHost());
			} else {
				status = "you are not authorised user";
			}
		} catch (Exception localException) {
			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status = "failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	
	public Response getAllStudentsInfo(int userid, int connectionid, String datastoreName, int PNO, int size,String classid,String sectionid,int schoolid,int branchId)
	{
		String status = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();

		try {

			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName,schoolid, branchId);
			System.out.println("verifiedvalue::"+ret);
			
			MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userid);
			
			if (ret == 1) // && rtVal==1)
			{
				StudentDao pd = new StudentDao();
				status = pd.getAllStudentsInfo(PNO,size,classid, sectionid,schoolid, branchId);
						
				System.out.println(status);
				Long el = System.currentTimeMillis();
				String endDate = dateFormat.format(new Date());
				// status= "user validation is successfull";
				MDTransactionWriter.writeLog(datastoreName, "StudentService_getAllStudentsInfo", requester, startDate, endDate, sl, el, status,
						hsr.getRemoteHost());
			} else {
				status = "you are not authorised user";
			}
		} catch (Exception localException) {

			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status = "failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	@Override
	public Response addStudentForOtherBranch(StudentPojo pp, int userid, int connectionid, String datastoreName,
			int schoolid, int branchid) {
		MDTransactionWriter.accesslog.info("Request from:" + hsr.getRemoteHost());

		String status = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();

		pp.setSchoolId(schoolid);
		pp.setBranchId(branchid);
		
		try {

			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName, schoolid, branchid);
			System.out.println("verifiedvalue::"+ret);
			
			MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userid);
			
			if (ret == 1) // && rtVal==1)
			{
				StudentDao pd = new StudentDao();
				status = pd.addStudentForOtherBranch(pp);
				System.out.println(status);
				Long el = System.currentTimeMillis();
				String endDate = dateFormat.format(new Date());
				// status= "user validation is successfull";
				MDTransactionWriter.writeLog(datastoreName, "StudentService_addStudentForOtherBranch", requester, startDate, endDate, sl, el, status,
						hsr.getRemoteHost());
			} else {
				status = "you are not authorised user";
			}
		} catch (Exception localException) {

			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status = "failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

}
