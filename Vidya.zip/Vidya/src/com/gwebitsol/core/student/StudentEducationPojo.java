//Vidya Version 0.8
package com.gwebitsol.core.student;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.stereotype.Component;

@XmlRootElement(name = "StudentEducation")
@Component
public class StudentEducationPojo implements Serializable {

	int studentEdId;
	int studentId;
	String schoolName;
	int classId;
	int sectionId;
	int resultId;
	double percentScore;
	int gradeId;
	String studiedFrom;
	String studiedTo;
	String createdDate;
	String remarks;
	String currentFlg;
	
	int branchId;
	int schoolId;
	
	
	public int getBranchId() {
		return branchId;
	}

	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}

	public int getSchoolId() {
		return schoolId;
	}

	public void setSchoolId(int schoolId) {
		this.schoolId = schoolId;
	}

	public double getPercentScore() {
		return percentScore;
	}

	public void setPercentScore(double percentScore) {
		this.percentScore = percentScore;
	}

	public String getCurrentFlg() {
		return currentFlg;
	}

	public void setCurrentFlg(String currentFlg) {
		this.currentFlg = currentFlg;
	}

	DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	Date date = new Date();
	String modifiedDate = dateFormat.format(date);

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public int getStudentEdId() {
		return studentEdId;
	}

	public void setStudentEdId(int studentEdId) {
		this.studentEdId = studentEdId;
	}

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public String getSchoolName() {
		return schoolName;
	}

	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}

	public int getClassId() {
		return classId;
	}

	public void setClassId(int classId) {
		this.classId = classId;
	}

	public int getSectionId() {
		return sectionId;
	}

	public void setSectionId(int sectionId) {
		this.sectionId = sectionId;
	}

	public int getResultId() {
		return resultId;
	}

	public void setResultId(int resultId) {
		this.resultId = resultId;
	}


	public int getGradeId() {
		return gradeId;
	}

	public void setGradeId(int gradeId) {
		this.gradeId = gradeId;
	}

	public String getStudiedFrom() {
		return studiedFrom;
	}

	public void setStudiedFrom(String studiedFrom) {
		this.studiedFrom = studiedFrom;
	}

	public String getStudiedTo() {
		return studiedTo;
	}

	public void setStudiedTo(String studiedTo) {
		this.studiedTo = studiedTo;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

}
