package com.gwebitsol.core.student;


import java.util.List;
import javax.xml.bind.annotation.XmlRootElement;
import com.gwebitsol.core.parent.ParentPojo;
@XmlRootElement(name="Parentrelation")
public class ParentsForRelation {

	 List<ParentPojo> parents;

	public List<ParentPojo> getParents() {
		return parents;
	}

	public void setParents(List<ParentPojo> parents) {
		this.parents = parents;
	}

}
