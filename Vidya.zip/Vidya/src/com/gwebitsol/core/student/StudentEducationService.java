//Vidya Version 0.8
package com.gwebitsol.core.student;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.stereotype.Service;

import com.gwebitsol.core.security.MDValidation;
import com.gwebitsol.core.security.MDVerifyConnectionID;
import com.gwebitsol.core.security.MDVerifyDatastoreName;
import com.gwebitsol.core.usermanagement.MDGetUserFromID;
import com.gwebitsol.core.util.MDTransactionWriter;

@Service
public class StudentEducationService implements StudentEducationServiceIntf {

	@Context
	private HttpServletRequest hsr;

	public Response addStudentEducation(StudentEducationPojo pp, int userid, int connectionid, String datastoreName, int schoolid,int branchId) {
		MDTransactionWriter.accesslog.info("Request from:" + hsr.getRemoteHost());

		String status = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();
		
		pp.setSchoolId(schoolid);
		pp.setBranchId(branchId);

		try {
			
			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName,schoolid, branchId);
			System.out.println("verifiedvalue::"+ret);
			
			if (ret == 1) // && rtVal==1)
			{
				StudentEducationDao pd = new StudentEducationDao();
				status = pd.addStudentEducation(pp);
				System.out.println(status);
				Long el = System.currentTimeMillis();
				String endDate = dateFormat.format(new Date());
				// status= "user validation is successfull";
				MDTransactionWriter.writeLog("SCHOOL", "MMS", "srinu", startDate, endDate, sl, el, status,
						hsr.getRemoteHost());
			} else {
				status = "you are not authorised user";
			}
		} catch (Exception localException) {

			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status = "failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response updateStudentEducation(StudentEducationPojo pp, int userid, int connectionid,
			String datastoreName, int schoolid,int branchId) {

		MDTransactionWriter.accesslog.info("Request from:" + hsr.getRemoteHost());

		String status = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();

		pp.setSchoolId(schoolid);
		pp.setBranchId(branchId);
		
		try {

			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName, schoolid, branchId);
			System.out.println("verifiedvalue::"+ret);
			
			if (ret == 1) // && rtVal==1)
			{
				StudentEducationDao pd = new StudentEducationDao();
				status = pd.updateStudentEducation(pp,schoolid, branchId);
				System.out.println(status);
				Long el = System.currentTimeMillis();
				String endDate = dateFormat.format(new Date());
				// status= "user validation is successfull";
				MDTransactionWriter.writeLog("SCHOOL", "MMS", "srinu", startDate, endDate, sl, el, status,
						hsr.getRemoteHost());
			} else {
				status = "you are not authorised user";
			}
		} catch (Exception localException) {

			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status = "failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response deleteStudentEducation(int StudentEdId, int userid, int connectionid, String datastoreName, int schoolid,int branchId) {

		MDTransactionWriter.accesslog.info("Request from:" + hsr.getRemoteHost());

		String status = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();

		try {
			

			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName,schoolid, branchId);
			System.out.println("verifiedvalue::"+ret);
			
			if (ret == 1) // && rtVal==1)
			{
				StudentEducationDao pd = new StudentEducationDao();

				status = pd.deleteStudentEducation(StudentEdId, schoolid, branchId);
				System.out.println(status);
				Long el = System.currentTimeMillis();
				String endDate = dateFormat.format(new Date());
				// status= "user validation is successfull";
				MDTransactionWriter.writeLog("SCHOOL", "MMS", "srinu", startDate, endDate, sl, el, status,
						hsr.getRemoteHost());
			} else {
				status = "you are not authorised user";
			}
		} catch (Exception localException) {

			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status = "failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response getStudentEducationByStudentId(int StudentId, int userid, int connectionid, String datastoreName, int schoolid,int branchId) {
		String status = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();

		try {

			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName, schoolid, branchId);
			System.out.println("verifiedvalue::"+ret);
			
			if (ret == 1) // && rtVal==1)
			{
				StudentEducationDao pd = new StudentEducationDao();
				status = pd.getStudentEducationByStudentId(StudentId, schoolid, branchId);
				System.out.println(status);
				Long el = System.currentTimeMillis();
				String endDate = dateFormat.format(new Date());
				// status= "user validation is successfull";
				MDTransactionWriter.writeLog("SCHOOL", "MMS", "srinu", startDate, endDate, sl, el, status,
						hsr.getRemoteHost());

			}

			else {
				status = "you are not authorised user";
			}
		} catch (Exception localException) {
			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status = "failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	
	public Response getAllStudentsPerSection(int sectionid, int classid,int userid, int connectionid, String datastoreName, int schoolid,int branchId) {
		MDTransactionWriter.accesslog.info("Request from:" + hsr.getRemoteHost());
		String status = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();

		try {

			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName, schoolid, branchId);
			System.out.println("verifiedvalue::"+ret);
			
			if (ret == 1) // && rtVal==1)
			{
				StudentEducationDao pd = new StudentEducationDao();
				status = pd.getAllStudentPerSection(sectionid,classid, schoolid, branchId);
				System.out.println(status);
				Long el = System.currentTimeMillis();
				String endDate = dateFormat.format(new Date());
				// status= "user validation is successfull";
				MDTransactionWriter.writeLog("SCHOOL", "MMS", "srinu", startDate, endDate, sl, el, status,
						hsr.getRemoteHost());
			} else {
				status = "you are not authorised user";
			}
		} catch (Exception localException) {
			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status = "failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response getAllStuEdu(int userid, int connectionid, String datastoreName, int PNO, int size, int schoolid,int branchId) {
		MDTransactionWriter.accesslog.info("Request from:" + hsr.getRemoteHost());
		String status = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();

		try {
			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName, schoolid, branchId);
			System.out.println("verifiedvalue::"+ret);
			
			if (ret == 1) // && rtVal==1)
			{
				StudentEducationDao pd = new StudentEducationDao();
				status = pd.getAllStuEdu(PNO,size, schoolid, branchId);
				System.out.println(status);
				Long el = System.currentTimeMillis();
				String endDate = dateFormat.format(new Date());
				// status= "user validation is successfull";
				MDTransactionWriter.writeLog("SCHOOL", "MMS", "srinu", startDate, endDate, sl, el, status,
						hsr.getRemoteHost());
			} else {
				status = "you are not authorised user";
			}
		} catch (Exception localException) {
			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status = "failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response getStudentEducationByStudentEduId(int studentEdId, int studentId, int userid, int connectionid,
			String datastoreName, int schoolid, int branchid) {
		MDTransactionWriter.accesslog.info("Request from:" + hsr.getRemoteHost());
		String status = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();

		try {

			MDValidation mdv = new MDValidation();		
			int ret =mdv.allvalidations(userid, connectionid, datastoreName, schoolid, branchid);
			System.out.println("verifiedvalue::"+ret);
			
			if (ret == 1) // && rtVal==1)
			{
				StudentEducationDao pd = new StudentEducationDao();
				status = pd.getStudentEducationByStuEduId(studentEdId,studentId, schoolid, branchid);
				System.out.println(status);
				Long el = System.currentTimeMillis();
				String endDate = dateFormat.format(new Date());
				// status= "user validation is successfull";
				MDTransactionWriter.writeLog("SCHOOL", "MMS", "srinu", startDate, endDate, sl, el, status,
						hsr.getRemoteHost());

			}

			else {
				status = "you are not authorised user";
			}
		} catch (Exception localException) {
			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status = "failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	


}
