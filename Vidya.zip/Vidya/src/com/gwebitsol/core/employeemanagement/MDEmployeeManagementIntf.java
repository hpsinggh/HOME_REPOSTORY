/*
Proprietary Notice
This file contains confidential information of meldit Pvt. Ltd. (India)  and meldit Inc. (USA), 
which is available for the sole purpose of permitting the recipient for engineering and product development purposes.  
In consideration of receipt of this file, the recipient agrees to maintain such information in confidence and not to
reproduce or otherwise disclose this information to any person outside the group directly responsible for its contents.

Security
The information contained herein is proprietary to meldit Pvt. Ltd. (India)  and meldit Inc. (USA) and may not be used, 
reproduced or disclosed.  The recipient of this file, by its retention and use, agrees to protect the same and the 
information contained therein from distribution, loss and theft.
__________________________________________________________________________________________________________________________________________________________________________________
*/

package com.gwebitsol.core.employeemanagement;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

@Path("/employeemanagement/")
public interface MDEmployeeManagementIntf 
{
	@POST
	@Consumes({"*/*"})
	@Produces({"application/xml","application/json"})
	@Path("/addemployee/")
	public Response addEmployee(MDEmployee mdemp,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@POST
	@Consumes({"*/*"})
	@Produces({"application/xml","application/json"})
	@Path("/updateemployee/")
	public Response updateEmployee(MDEmployee mdemp,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@POST
	@Consumes({"application/xml","application/json"})
	@Produces({"application/xml","application/json"})
	@Path("/deleteemployee/")
	public Response deleteEmployee(@QueryParam("employeeid") String employeeid,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@GET
	@Produces({"application/xml","application/json"})
	@Path("/getemployee/")
	public Response getEmployeeDetails(@QueryParam("employeeid") String employeeid,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@GET
	@Produces({"application/xml","application/json"})
	@Path("/getallemployee/")
	public Response getAllEmployee(@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@Path("/getemployeeimage")
	@Produces("image/*")
	@GET
	public Response getImageStream(@QueryParam("employeeID") String employeeID,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	@GET
	@Produces({"application/xml","application/json"})
	@Path("/getemplist/")
	public Response searchEmployee(@QueryParam("employeeid") String employeeid,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastoreName") String datastoreName);
	
	
}
