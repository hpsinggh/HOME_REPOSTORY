/*
Proprietary Notice
This file contains confidential information of meldit Pvt. Ltd. (India)  and meldit Inc. (USA), 
which is available for the sole purpose of permitting the recipient for engineering and product development purposes.  
In consideration of receipt of this file, the recipient agrees to maintain such information in confidence and not to
reproduce or otherwise disclose this information to any person outside the group directly responsible for its contents.

Security
The information contained herein is proprietary to meldit Pvt. Ltd. (India)  and meldit Inc. (USA) and may not be used, 
reproduced or disclosed.  The recipient of this file, by its retention and use, agrees to protect the same and the 
information contained therein from distribution, loss and theft.
__________________________________________________________________________________________________________________________________________________________________________________
*/

package com.gwebitsol.core.employeemanagement;
import java.awt.Image;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Iterator;
import java.util.List;

import javax.imageio.ImageIO;

import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.dataformat.*;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;
import com.mysql.jdbc.Blob;

//import org.codehaus.*;
//import org.codehaus.jackson.map.ObjectMapper;


public class MDEmployeeManagementDAO 
{
	
	@SuppressWarnings("rawtypes")
	public String createEmployee(MDEmployee mdemp)
	{
		Session addempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction addempTx=null;
		String outStr=null;
		try
		{
			addempTx=addempSession.beginTransaction();
			
			List list=addempSession.createSQLQuery("select * from mdemployees where employeeid='"+mdemp.getEmployeeID()+"'").list();
   		 	if(list!=null && list.size()>0)
   		 	{
   		 		outStr="This EmployeeID has already been assigned to a Employee, Give a unique EmployeeID..";
   			 
   		 	}
   		 	else
   		 	{
			MDEmployeePOJO emppojo=new MDEmployeePOJO();
			emppojo.setEmployeeID(mdemp.getEmployeeID());
			emppojo.setFirstName(mdemp.getFirstName());
			emppojo.setMiddleName(mdemp.getMiddleName());
			emppojo.setLastName(mdemp.getLastName());
			emppojo.setDob(mdemp.getDob());
			emppojo.setPhoto(mdemp.getPhoto());
			emppojo.setDepartment(mdemp.getDepartment());
			emppojo.setDesignation(mdemp.getDesignation());
			emppojo.setFathersName(mdemp.getFathersName());
			emppojo.setAddress(mdemp.getAddress());
			emppojo.setCity(mdemp.getCity());
			emppojo.setState(mdemp.getState());
			emppojo.setPinCode(mdemp.getPinCode());
			emppojo.setCountry(mdemp.getCountry());
			emppojo.setContactNumber(mdemp.getContactNumber());
			emppojo.setEmailID(mdemp.getEmailID());
			emppojo.setFaxNO(mdemp.getFaxNO());
			emppojo.setStatus("Active");
			addempSession.save(emppojo);
			addempTx.commit();
			outStr="employee created";
			System.out.println(outStr);
   		 	}
		
			
		}
		catch(Exception localException)
		{
			addempTx.rollback();
			localException.printStackTrace();
			outStr="fail";
		}
		finally
		{			
			addempSession.close();
		}
		return outStr;
	}
	
	public String updateEmployee(MDEmployee mdemp)
	{
		Session upempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction upempTx=null;
		String outStr=null;
		try
		{
			upempTx=upempSession.beginTransaction();
			
			int sno=(Integer)upempSession.createSQLQuery("select sno from mdemployees where employeeid='"+mdemp.getEmployeeID()+"'").uniqueResult();
			
			MDEmployeePOJO mdemppojo=(MDEmployeePOJO)upempSession.load(MDEmployeePOJO.class,sno);
			mdemppojo.setFirstName(mdemp.getFirstName());
			mdemppojo.setMiddleName(mdemp.getMiddleName());
			mdemppojo.setLastName(mdemp.getLastName());
			mdemppojo.setDob(mdemp.getDob());
			if(mdemp.getPhoto()!=null)
			{
				mdemppojo.setPhoto(mdemp.getPhoto());
			}
			mdemppojo.setDepartment(mdemp.getDepartment());
			mdemppojo.setDesignation(mdemp.getDesignation());
			mdemppojo.setFathersName(mdemp.getFathersName());
			mdemppojo.setAddress(mdemp.getAddress());
			mdemppojo.setCity(mdemp.getCity());
			mdemppojo.setState(mdemp.getState());
			mdemppojo.setPinCode(mdemp.getPinCode());
			mdemppojo.setCountry(mdemp.getCountry());
			mdemppojo.setContactNumber(mdemp.getContactNumber());
			mdemppojo.setEmailID(mdemp.getEmailID());
			mdemppojo.setFaxNO(mdemp.getFaxNO());
			mdemppojo.setStatus("Active");
			upempSession.update(mdemppojo);
			
			upempTx.commit();
			
			outStr="employee details updated";
		}
		catch(Exception localException)
		{
			upempTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			outStr="fail";
			
		}
		finally
		{
			
			upempSession.close();
		}
		return outStr;
	}

	@SuppressWarnings("rawtypes")
	public String deleteEmployee(String employeeID)
	{
		Session delempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction delempTx=null;
		String outStr=null;
		try
		{
			delempTx=delempSession.beginTransaction();
			
			Query empQuery=delempSession.createSQLQuery("update mdemployees set status='deleted' where employeeid='"+employeeID+"'");
			empQuery.executeUpdate();
			
			List list=delempSession.createSQLQuery("select * from mdusers where employeeid='"+employeeID+"'").list();
   		 	if(list!=null && list.size()>0)
   		 	{
   		 		Query udQuery=delempSession.createSQLQuery("update mdusers set status='deleted' where employeeid='"+employeeID+"'");
   		 		udQuery.executeUpdate();
   		 	}
			
			delempTx.commit();
			
			outStr="employee deleted";
		}
		catch(Exception localException)
		{
			delempTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			outStr="fail";
		}
		finally
		{
			
			delempSession.close();
		}
		return outStr;
	}
	
	@SuppressWarnings({ "deprecation", "rawtypes" })
	public String getEmployeeDetails(String employeeid)
	{
		Session gtempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gtempTx=null;
		String outStr=null;
		StringBuffer gtempSB=new StringBuffer();
		//MDHibernateUtil mh=new MDHibernateUtil();
		try
		{
			gtempTx=gtempSession.beginTransaction();
			
			String gtempSql="select * from mdemployees where employeeid='"+employeeid+"'";
			Query gtempQuery=gtempSession.createSQLQuery(gtempSql).addScalar("sno",Hibernate.INTEGER).addScalar("employeeid",Hibernate.STRING).addScalar("firstname",Hibernate.STRING).addScalar("middlename",Hibernate.STRING).addScalar("lastname",Hibernate.STRING).addScalar("dob",Hibernate.STRING)
					.addScalar("department",Hibernate.STRING).addScalar("designation",Hibernate.STRING).addScalar("fathersname",Hibernate.STRING).addScalar("address",Hibernate.STRING).addScalar("city",Hibernate.STRING).addScalar("state",Hibernate.STRING).addScalar("pincode",Hibernate.STRING)
					.addScalar("country",Hibernate.STRING).addScalar("contactnumber",Hibernate.STRING).addScalar("emailid",Hibernate.STRING).addScalar("faxno",Hibernate.STRING).addScalar("status",Hibernate.STRING);
			
			List gtempList=gtempQuery.list();
			Iterator gtempIT=gtempList.iterator();
			gtempSB.append("<MD_EmployeeDetails>");
			gtempSB.append("\n");
			while(gtempIT.hasNext())
			{
				Object[] empObj=(Object[])gtempIT.next();
				gtempSB.append("<EmployeeID>"+empObj[1]+"</EmployeeID>");
				gtempSB.append("\n");
				gtempSB.append("<EmployeeName>"+empObj[2]+" "+empObj[3]+" "+empObj[4]+"</EmployeeName>");
				gtempSB.append("\n");
				gtempSB.append("<DOB>"+empObj[5]+"</DOB>");
				gtempSB.append("\n");
				gtempSB.append("<Department>"+empObj[6]+"</Department>");
				gtempSB.append("\n");
				gtempSB.append("<Designation>"+empObj[7]+"</Designation>");
				gtempSB.append("\n");
				gtempSB.append("<FathersName>"+empObj[8]+"</FathersName>");
				gtempSB.append("\n");
				gtempSB.append("<Address>"+empObj[9]+"</Address>");
				gtempSB.append("\n");
				gtempSB.append("<City>"+empObj[10]+"</City>");
				gtempSB.append("\n");
				gtempSB.append("<State>"+empObj[11]+"</State>");
				gtempSB.append("\n");
				gtempSB.append("<PinCode>"+empObj[12]+"</PinCode>");
				gtempSB.append("\n");
				gtempSB.append("<Country>"+empObj[13]+"</Country>");
				gtempSB.append("\n");
				gtempSB.append("<ContactNo>"+empObj[14]+"</ContactNo>");
				gtempSB.append("\n");
				gtempSB.append("<EmailID>"+empObj[15]+"</EmailID>");
				gtempSB.append("\n");
				gtempSB.append("<faxNO>"+empObj[16]+"</faxNO>");
				gtempSB.append("\n");
				gtempSB.append("<Status>"+empObj[17]+"</Status>");
				gtempSB.append("\n");
				
			}	
			gtempSB.append("\n");
			gtempSB.append("</MD_EmployeeDetails>");
			gtempTx.commit();
			
		
			outStr =MDHibernateUtil.fromJavaToJson((Serializable) gtempList);
			
			
			//outStr = fromJavaToMDHibernateUtilXML((Serializable) gtempList);
			
			//outStr=gtempSB.toString();
			
			gtempSB.setLength(0);
			
		}
		catch(Exception localException)
		{
			gtempTx.rollback();
			gtempSB.setLength(0);
			MDTransactionWriter.exceptionlog.info(localException);
			outStr="fail";
			
		}
		finally
		{
			
			gtempSession.close();
			gtempSB=null;
		}
		return outStr;
	}
	
	@SuppressWarnings({ "deprecation", "rawtypes" })
	public String getAllEmployees()
	{
		Session gtallempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gtallempTx=null;
		String outStr=null;
		StringBuffer gtallSB=new StringBuffer();
		try
		{
			gtallempTx=gtallempSession.beginTransaction();
			
			String gtallempSql="select * from mdemployees where status='Active' order by firstname ASC";
			Query gtallQuery=gtallempSession.createSQLQuery(gtallempSql).addScalar("sno",Hibernate.INTEGER).addScalar("employeeid",Hibernate.STRING)
					.addScalar("firstname",Hibernate.STRING).addScalar("middlename",Hibernate.STRING).addScalar("lastname",Hibernate.STRING);
			List gtallList=gtallQuery.list();
			Iterator gtallIT=gtallList.iterator();
			gtallSB.append("<MD_Employee>");
			gtallSB.append("\n");
			while(gtallIT.hasNext())
			{
				Object[] gtallObj=(Object[])gtallIT.next();
				gtallSB.append("<EmployeeID>"+gtallObj[1]+"</EmployeeID>");
				gtallSB.append("\n");
				gtallSB.append("<EmployeeName>"+gtallObj[2]+" "+gtallObj[3]+" "+gtallObj[4]+"</EmployeeName>");
				gtallSB.append("\n");
			}
			gtallSB.append("\n");
			gtallSB.append("</MD_Employee>");
			
			gtallempTx.commit();
			outStr=gtallSB.toString();
			gtallSB.setLength(0);
			
		}
		catch(Exception localException)
		{
			gtallempTx.rollback();
			gtallSB.setLength(0);
			MDTransactionWriter.exceptionlog.info(localException);
			outStr="fail";
		}
		finally
		{
			
			gtallempSession.close();
			gtallSB=null;
		}
		return outStr;
		
	}
	
	@SuppressWarnings("deprecation")
	public Image getEmployeeImage(String employeeID)
		{
			Session gimgSession=MDHibernateUtil.getSessionFactory().openSession();
			Transaction gimgTx = null;	
			PreparedStatement ps = null;
			ResultSet rs = null;
			Image img=null;
			try
			{
				gimgTx=gimgSession.beginTransaction();
				String sql="select photo from mdemployees where employeeid='"+employeeID+"'";
				java.sql.Connection connection =gimgSession.connection();
				ps = (PreparedStatement) connection.prepareStatement(sql);
				rs = (ResultSet) ps.executeQuery();
				if (rs.next()) 
				{
					Blob bl=(Blob)rs.getBlob("photo");
					InputStream in=bl.getBinaryStream();
					img = ImageIO.read(in);
				}
				
			}
			catch(Exception localException)
			{
				MDTransactionWriter.exceptionlog.info(localException);
			}
			finally
			{
				gimgTx.commit();
				gimgSession.close();
			}
			return img;

		}

	 @SuppressWarnings({ "deprecation", "rawtypes" })
	public String searchEmployee(String employeeid)
	 {
		 Session sempSession=MDHibernateUtil.getSessionFactory().openSession();
		 Transaction sempTx=null;
		 String outString=null;
		 StringBuffer sempSB=new StringBuffer();
		 try
		 {
			 sempTx=sempSession.beginTransaction();
			 String sempSql="select * from mdemployees where employeeid like '%"+employeeid+"%'";
			 Query sempQuery=sempSession.createSQLQuery(sempSql).addScalar("sno",Hibernate.INTEGER).addScalar("employeeid",Hibernate.STRING);
			 List sempList=sempQuery.list();
			 Iterator sempIT=sempList.iterator();
			 sempSB.append("<MD_EmpList>");
			 sempSB.append("\n");
			 if(sempIT.hasNext()==false)
			 {
				 outString="No such employeeid exists..";
			 }
			 else
			 {
				 while(sempIT.hasNext())
			 {
				
				 Object[] sempObj=(Object[])sempIT.next();
				 sempSB.append("<EmpID>"+sempObj[1]+"</EmpID>");
				 sempSB.append("\n");	 
			 }
			 
			 sempSB.append("</MD_EmpList>");
			 outString=sempSB.toString(); 
			 }
			 sempTx.commit();
			 
		 }
		 catch(Exception localException)
		 {
			 sempSB.setLength(0);
			 sempTx.rollback();
			 MDTransactionWriter.exceptionlog.info(localException);
			 outString="fail";
		 }
		 finally
		 {
			 sempSession.close();
			 sempSB=null;
		 }
		 return outString;
	 }
	 

	 
	 
	 
	 
}
