/*
Proprietary Notice
This file contains confidential information of meldit Pvt. Ltd. (India)  and meldit Inc. (USA), 
which is available for the sole purpose of permitting the recipient for engineering and product development purposes.  
In consideration of receipt of this file, the recipient agrees to maintain such information in confidence and not to
reproduce or otherwise disclose this information to any person outside the group directly responsible for its contents.

Security
The information contained herein is proprietary to meldit Pvt. Ltd. (India)  and meldit Inc. (USA) and may not be used, 
reproduced or disclosed.  The recipient of this file, by its retention and use, agrees to protect the same and the 
information contained therein from distribution, loss and theft.
__________________________________________________________________________________________________________________________________________________________________________________
*/

package com.gwebitsol.core.dms;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;

import com.gwebitsol.core.dms.MDDocumentManagementDAO;
import com.gwebitsol.core.dms.MDGetImageFromImageIDServiceIntf;
import com.gwebitsol.core.security.MDVerifyConnectionID;
import com.gwebitsol.core.security.MDVerifyDatastoreName;
import com.gwebitsol.core.usermanagement.MDGetUserFromID;
import com.gwebitsol.core.util.MDTransactionWriter;

public class MDGetImageFromImageIDService implements MDGetImageFromImageIDServiceIntf
{
	@Context private HttpServletRequest hsr;
	public Response getImageStream(String imageID,int userID,int connectionID,String datastoreName)
	{
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long startTime=System.currentTimeMillis();
		InputStream bigInputStream=null;
		final ByteArrayOutputStream out = new ByteArrayOutputStream();
		try
		{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userID);
			
			System.out.println(connectionID);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userID,connectionID);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 && rtVal==1)
			{
			MDDocumentManagementDAO dmDAO=new MDDocumentManagementDAO();
			Image image=dmDAO.getDocument(Integer.parseInt(imageID));
			if(image.equals(null))
				status="fail";
			else
				status="success";
			ImageIO.write((BufferedImage) image, "jpg", out);
			final byte[] imgData = out.toByteArray();
			bigInputStream = new ByteArrayInputStream(imgData);
			String endDate=dateFormat.format(new Date());
			status="got image";
			Long endTime=System.currentTimeMillis();
			MDTransactionWriter.writeLog(datastoreName,"DMS",requester,startDate,endDate,startTime,endTime,status,hsr.getRemoteHost());
			}
			return Response.ok(bigInputStream).build();
		}
		catch (final IOException e)
		{
			return Response.noContent().build();
		}	

	}
}
