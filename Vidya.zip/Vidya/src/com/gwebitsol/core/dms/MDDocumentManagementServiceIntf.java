/*
Proprietary Notice
This file contains confidential information of meldit Pvt. Ltd. (India)  and meldit Inc. (USA), 
which is available for the sole purpose of permitting the recipient for engineering and product development purposes.  
In consideration of receipt of this file, the recipient agrees to maintain such information in confidence and not to
reproduce or otherwise disclose this information to any person outside the group directly responsible for its contents.

Security
The information contained herein is proprietary to meldit Pvt. Ltd. (India)  and meldit Inc. (USA) and may not be used, 
reproduced or disclosed.  The recipient of this file, by its retention and use, agrees to protect the same and the 
information contained therein from distribution, loss and theft.
__________________________________________________________________________________________________________________________________________________________________________________
*/

package com.gwebitsol.core.dms;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

import com.gwebitsol.core.dms.MDDocument;

@Path("/documentmanagement/")
public interface MDDocumentManagementServiceIntf
{
	@Path("/add/")
	@POST
	@Consumes({"*/*"})
	@Produces({"application/xml", "application/json"})
	public Response addDocument(MDDocument mdDocument,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastorename") String datastoreName);
	
	@Path("/get")
	@Produces("image/*")
	@GET
	public Response getDocument(@QueryParam("documentID") String documentID,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastorename") String datastoreName);
	
	@Path("/delete")
	@POST
	@Produces({"application/xml", "application/json"})
	public Response deleteDocument(@QueryParam("documentID") int documentID,@QueryParam("userid") int userid,@QueryParam("connectionid") int connectionid,@QueryParam("datastorename") String datastoreName);
}
