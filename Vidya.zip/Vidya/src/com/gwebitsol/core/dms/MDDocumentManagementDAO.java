/*
Proprietary Notice
This file contains confidential information of meldit Pvt. Ltd. (India)  and meldit Inc. (USA), 
which is available for the sole purpose of permitting the recipient for engineering and product development purposes.  
In consideration of receipt of this file, the recipient agrees to maintain such information in confidence and not to
reproduce or otherwise disclose this information to any person outside the group directly responsible for its contents.

Security
The information contained herein is proprietary to meldit Pvt. Ltd. (India)  and meldit Inc. (USA) and may not be used, 
reproduced or disclosed.  The recipient of this file, by its retention and use, agrees to protect the same and the 
information contained therein from distribution, loss and theft.
__________________________________________________________________________________________________________________________________________________________________________________
*/

package com.gwebitsol.core.dms;

import java.awt.Image;
import java.io.InputStream;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.imageio.ImageIO;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.dms.MDDocumentPOJO;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;
import com.mysql.jdbc.Blob;


public class MDDocumentManagementDAO
{
	public String addDocument(String documentName,int infoclassid, int parentobjectid, byte[] documentPath)
	{
		Session mdmSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String d=dateFormat.format(date);
		String outStr=null;
		try
		{

			MDTransactionWriter.exceptionlog.info("addition of document started");
			transaction=mdmSession.beginTransaction();
			MDDocumentPOJO adObj=new MDDocumentPOJO();
			adObj.setDocumentName(documentName);
			adObj.setDocumentContent(documentPath);
			adObj.setInfoclassID(infoclassid);
			adObj.setParentObjectID(parentobjectid);
			adObj.setCreatedDate(d);
			adObj.setCreatedBy(0);
			adObj.setStatus("active");
			mdmSession.save(adObj);
			transaction.commit();
			outStr="<status> file stored</status>";
		}
		catch (Exception localexception) 
		{
			MDTransactionWriter.exceptionlog.info("", localexception);
			outStr="<status>file addition failed</status>";
		}
		finally
		{
			mdmSession.close();
		}
		return outStr;
	}

	@SuppressWarnings("deprecation")
	public Image getDocument(int documentID)
	{
		Session gimgSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gimgTx = null;	
		PreparedStatement ps = null;
		ResultSet rs = null;
		Image img=null;
		try
		{
			gimgTx=gimgSession.beginTransaction();
			String sql="select documentcontent from mddocument where documentid="+documentID+" and status='active'";
			java.sql.Connection connection =gimgSession.connection();
			ps = (PreparedStatement) connection.prepareStatement(sql);
			rs = (ResultSet) ps.executeQuery();
			if (rs.next()) 
			{
				Blob bl=(Blob)rs.getBlob("documentcontent");
				InputStream in=bl.getBinaryStream();
				img = ImageIO.read(in);
			}
			gimgTx.commit();
		}
		catch(Exception localException)
		{
			MDTransactionWriter.exceptionlog.info(localException);
		}
		finally
		{
			gimgSession.close();
		}
		return img;

	}

	public String deleteDocument(int documentID)
	{
		Session ddSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction ddTx = null;
		String outStr=null;
		try
		{
			ddTx=ddSession.beginTransaction();
			
			Query ddQuery=ddSession.createSQLQuery("update mddocument set status='deleted' where documentid="+documentID);
			ddQuery.executeUpdate();	
			
			ddTx.commit();
			outStr="<status> file deleted</status>";
		}
		catch(Exception localException)
		{
			ddTx.rollback();
			MDTransactionWriter.exceptionlog.info("", localException);
			outStr="<status>file could not be deleted</status>";
		}
		finally
		{
			ddSession.close();
		}
		
		return outStr;
	}
	
	public MDDocumentPOJO addDocument(String documentName, byte[] documentPath)
	{
		Session mdmSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String d=dateFormat.format(date);
		MDDocumentPOJO adObj=null;
		try
		{

			MDTransactionWriter.exceptionlog.info("addition of document started");
			transaction=mdmSession.beginTransaction();
		     adObj=new MDDocumentPOJO();
			adObj.setDocumentName(documentName);
			adObj.setDocumentContent(documentPath);
			adObj.setCreatedDate(d);
			adObj.setCreatedBy(0);
			adObj.setStatus("active");
			mdmSession.save(adObj);
			transaction.commit();
		}
		catch (Exception localexception) 
		{
			MDTransactionWriter.exceptionlog.info("", localexception);
		}
		finally
		{
			mdmSession.close();
		}
		return adObj;
	}

}
