/*
Proprietary Notice
This file contains confidential information of meldit Pvt. Ltd. (India)  and meldit Inc. (USA), 
which is available for the sole purpose of permitting the recipient for engineering and product development purposes.  
In consideration of receipt of this file, the recipient agrees to maintain such information in confidence and not to
reproduce or otherwise disclose this information to any person outside the group directly responsible for its contents.

Security
The information contained herein is proprietary to meldit Pvt. Ltd. (India)  and meldit Inc. (USA) and may not be used, 
reproduced or disclosed.  The recipient of this file, by its retention and use, agrees to protect the same and the 
information contained therein from distribution, loss and theft.
__________________________________________________________________________________________________________________________________________________________________________________
*/

package com.gwebitsol.core.dms;

public class MDDocumentPOJO 
{
private int documentID;
private String documentName;
private byte[] documentContent;
private int infoclassID;
private int parentObjectID;
private String createdDate;
private int createdBy;
private String status;
public int getDocumentID() {
	return documentID;
}
public void setDocumentID(int documentID) {
	this.documentID = documentID;
}
public String getDocumentName() {
	return documentName;
}
public void setDocumentName(String documentName) {
	this.documentName = documentName;
}
public byte[] getDocumentContent() {
	return documentContent;
}
public void setDocumentContent(byte[] documentContent) {
	this.documentContent = documentContent;
}
public int getInfoclassID() {
	return infoclassID;
}
public void setInfoclassID(int infoclassID) {
	this.infoclassID = infoclassID;
}
public int getParentObjectID() {
	return parentObjectID;
}
public void setParentObjectID(int parentObjectID) {
	this.parentObjectID = parentObjectID;
}
public String getCreatedDate() {
	return createdDate;
}
public void setCreatedDate(String createdDate) {
	this.createdDate = createdDate;
}
public int getCreatedBy() {
	return createdBy;
}
public void setCreatedBy(int createdBy) {
	this.createdBy = createdBy;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}


}
