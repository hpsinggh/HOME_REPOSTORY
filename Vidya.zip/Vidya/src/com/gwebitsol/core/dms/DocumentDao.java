package com.gwebitsol.core.dms;

import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

@Repository
@Component
public class DocumentDao {

	Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
	Transaction rdTx = null;
	StringBuffer AddressID=new StringBuffer();
	
	public String addDocument(DocumentPojo ap) {
		
		String docreg = null;
		try {	
			
			rdTx = rdSession.beginTransaction();
			
			  Integer docid  = (Integer) rdSession.save(ap);
			   
			  rdTx.commit();			  
				    AddressID.append("<Document>");
				    AddressID.append("\n");
				    AddressID.append("<id>");
				    AddressID.append("\n");
				    AddressID.append(docid);
				    AddressID.append("</id>");
				    AddressID.append("\n");
				    AddressID.append("</Document>");
				    docreg= AddressID.toString();	    
			} catch (Exception localException) {
				localException.printStackTrace();
		  System.out.println(localException);
		  
		  AddressID.append("<Response>");
		  AddressID.append("\n");
		  AddressID.append("<Result>");
		  AddressID.append("\n");
		  AddressID.append("Fail");
		  AddressID.append("\n");
		  AddressID.append("</Result>");
		  AddressID.append("\n");
		  AddressID.append("<Description>"); 
		  AddressID.append("could not inserted document info");
		  AddressID.append("</Description>");
		  AddressID.append("\n");
		  AddressID.append("<Exception>");
		  AddressID.append(localException);
		  AddressID.append("</Exception>");
		  AddressID.append("</Response>");
		  
		  docreg= AddressID.toString();
		 MDTransactionWriter.exceptionlog.info(localException);
		if (rdTx!=null)
			rdTx.rollback();
		} finally {
			rdSession.close();	
		}
		return docreg;
	}

	public String updateDocument(DocumentPojo ap) {

		String docreg = null;
		
		try {	
			rdTx = rdSession.beginTransaction();
		
			  rdSession.update(ap);
			 
			 rdTx.commit();
			 
			 docreg = "document is succssfully updated";
			 
			 AddressID.append("<Document>");
			 AddressID.append("\n");
			 AddressID.append(docreg);
			 AddressID.append("</Document>");
				String str= AddressID.toString();
				return str;
		} catch (Exception localException) {
			localException.printStackTrace();
			if (rdTx!=null)
			rdTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			docreg="fail";
			
		} finally {
			rdSession.close();	
		}
		return docreg;
	}

	public String deleteDocument(int documentId) {

		String docreg = null;
		
		try {	
			rdTx = rdSession.beginTransaction();
			DocumentPojo ap = new DocumentPojo();
			ap.setDocumentId(documentId);
			rdSession.delete(ap);
			rdTx.commit();
			docreg = "document is succssfully deleted";
			 AddressID.append("<Document>");
			 AddressID.append("\n");
			 AddressID.append(docreg);
			 AddressID.append("</Document>");
				String str= AddressID.toString();
				return str;
		} catch (Exception localException) {
			localException.printStackTrace();
			if (rdTx!=null)
			rdTx.rollback();
			MDTransactionWriter.exceptionlog.info(localException);
			docreg="fail";
			
		} finally {
			rdSession.close();	
		}
		return docreg;
	}

	public String getDocumentById(int documentId) {
		Session gtempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gtTx=null;
			StringBuffer sb= new StringBuffer();
			System.out.println("hi dao impl success");
			String strg= null;
				try {
					gtTx = gtempSession.beginTransaction();
					List list=gtempSession.createSQLQuery("Select d.DocumentId,d.EmployeeId,s.StaffNumber,s.FirstName,s.MiddleName,s.LastName,d.StudentId,st.StudentNumber,st.FirstName,st.MiddleName,st.LastName,d.ParentId,p.FirstName,p.MiddleName,p.LastName,d.AdmissionId,a.AdmissionNo,d.BookReceiptId,b.InVoiceNo,b.OrderNo,d.DocumentPath,d.DocumentName,d.FileName,d.`Status`,d.DocumentType,d.CreatedBy,d.DocumentDescription,d.CreatedDate,d.ModifiedDate from gbl_sm_tbl_document d join gbl_sm_tbl_staff s join gbl_sm_tbl_student st join gbl_sm_tbl_parent p join gbl_sm_tbl_admission a join gbl_sm_tbl_bookreceipt b on d.EmployeeId = s.EmployeeId and d.StudentId = st.StudentId and d.ParentId = p.ParentId and d.AdmissionId = a.AdmissionId  and d.BookReceiptId = b.BookReceiptId where documentId ='" + documentId + "';").list();
				     Iterator it=list.iterator();
				    		    sb.append("<Document>");
						        sb.append("\n");
						        while(it.hasNext())
						        {
								Object[] ex=(Object[])it.next();
						        sb.append("<DocumentId>");
							    sb.append(ex[0]);
							    sb.append("</DocumentId>");
							    sb.append("\n");
							    sb.append("<EmployeeId>");
							    sb.append(ex[1]);
							    sb.append("</EmployeeId>");
							    sb.append("\n");
							    sb.append("<StaffNumber>");
								sb.append(ex[2]);
								sb.append("</StaffNumber>");
								 sb.append("\n");
								sb.append("<FirstName>");
								sb.append(ex[3]);
								sb.append("</FirstName>");
								 sb.append("\n");
								sb.append("<MiddleName>");
								sb.append(ex[4]);
								sb.append("</MiddleName>");
								sb.append("\n");
								sb.append("<LastName>");
								sb.append(ex[5]);
								sb.append("</LastName>");
								sb.append("\n");
								sb.append("<StudentId>");
								sb.append(ex[6]);
								sb.append("</StudentId>");
								sb.append("\n");
								sb.append("<StudentNumber>");
							    sb.append(ex[7]);
							    sb.append("</StudentNumber>");
							    sb.append("\n");
							    sb.append("<FirstName>");
							    sb.append(ex[8]);
							    sb.append("</FirstName>");
							    sb.append("\n");
							    sb.append("<MiddleName>");
								sb.append(ex[9]);
								sb.append("</MiddleName>");
								 sb.append("\n");
								sb.append("<LastName>");
								sb.append(ex[10]);
								sb.append("</LastName>");
								 sb.append("\n");
								sb.append("<ParentId>");
								sb.append(ex[11]);
								sb.append("</ParentId>");
								sb.append("\n");
								 sb.append("<FirstName>");
								    sb.append(ex[12]);
								    sb.append("</FirstName>");
								    sb.append("\n");
								    sb.append("<MiddleName>");
									sb.append(ex[13]);
									sb.append("</MiddleName>");
									 sb.append("\n");
									sb.append("<LastName>");
									sb.append(ex[14]);
									sb.append("</LastName>");
									 sb.append("\n");
								sb.append("<AdmissionId>");
								sb.append(ex[15]);
								sb.append("</AdmissionId>");
								sb.append("\n");
								sb.append("<AdmissionNo>");
								sb.append(ex[16]);
								sb.append("</AdmissionNo>");
								sb.append("\n");
								sb.append("<BookReceiptId>");
								sb.append(ex[17]);
								sb.append("</BookReceiptId>");
								sb.append("\n");
								sb.append("<InVoiceNo>");
								sb.append(ex[18]);
								sb.append("</InVoiceNo>");
								sb.append("\n");
								sb.append("<OrderNo>");
								sb.append(ex[19]);
								sb.append("</OrderNo>");
								sb.append("\n");
								sb.append("<DocumentPath>");
								sb.append(ex[20]);
								sb.append("</DocumentPath>");
								sb.append("\n");
								sb.append("<DocumentName>");
								sb.append(ex[21]);
								sb.append("</DocumentName>");
								sb.append("\n");
								sb.append("<FileName>");
								sb.append(ex[22]);
								sb.append("</FileName>");
								sb.append("\n");
								sb.append("<Status>");
								sb.append(ex[23]);
								sb.append("</Status>");
								sb.append("\n");
								sb.append("<DocumentType>");
								sb.append(ex[24]);
								sb.append("</DocumentType>");
								sb.append("\n");
								sb.append("<CreatedBy>");
								sb.append(ex[25]);
								sb.append("</CreatedBy>");
								sb.append("\n");
								sb.append("<DocumentDescription>");
								sb.append(ex[26]);
								sb.append("</DocumentDescription>");
								sb.append("\n");
								sb.append("<CreatedDate>");
								sb.append(ex[27]);
								sb.append("</CreatedDate>");
								sb.append("\n");
								sb.append("<ModifiedDate>");
								sb.append(ex[28]);
								sb.append("</ModifiedDate>");
								sb.append("\n");
								
						        }
								sb.append("</Document>");
							    strg= sb.toString();
				}
			    catch (HibernateException localException) {
			    	localException.printStackTrace();
			         if (rdTx!=null) rdTx.rollback();
			         localException.printStackTrace(); 
			      }finally {
			         rdSession.close(); 
			      }
			 return strg;

	}

	public String getAllDocuments(int PNO, int size, String document) {
		Session rdSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb= new StringBuffer();
		String string=null;
		//AssessmentPojo ex=null;
		
		try
		{
			tx = rdSession.beginTransaction();
			
			 if(document.trim().equalsIgnoreCase("all"))
			   {
			    int fset = (PNO-1)*size;
			    String gsSql ="select count(*) from gbl_sm_tbl_document";
			    Query gsQuery=rdSession.createSQLQuery(gsSql);
			    Object noRecords= gsQuery.uniqueResult();
			    sb.append("<Documents>");
			    sb.append("\n");
			    sb.append("<noRecords>"+noRecords+"</noRecords>");
			    sb.append("\n");
			    
			     if (PNO > 0 & size > 0){
			     gsSql="Select d.DocumentId,d.EmployeeId,s.StaffNumber,s.FirstName,s.MiddleName,s.LastName,d.StudentId,st.StudentNumber,st.FirstName,st.MiddleName,st.LastName,d.ParentId,p.FirstName,p.MiddleName,p.LastName,d.AdmissionId,a.AdmissionNo,d.BookReceiptId,b.InVoiceNo,b.OrderNo,d.DocumentPath,d.DocumentName,d.FileName,d.`Status`,d.DocumentType,d.CreatedBy,d.DocumentDescription,d.CreatedDate,d.ModifiedDate from gbl_sm_tbl_document d join gbl_sm_tbl_staff s join gbl_sm_tbl_student st join gbl_sm_tbl_parent p join gbl_sm_tbl_admission a join gbl_sm_tbl_bookreceipt b on d.EmployeeId = s.EmployeeId and d.StudentId = st.StudentId and d.ParentId = p.ParentId and d.AdmissionId = a.AdmissionId and d.BookReceiptId = b.BookReceiptId limit "+size+" offset "+fset;}
			     else {
			      gsSql="Select d.DocumentId,d.EmployeeId,s.StaffNumber,s.FirstName,s.MiddleName,s.LastName,d.StudentId,st.StudentNumber,st.FirstName,st.MiddleName,st.LastName,d.ParentId,p.FirstName,p.MiddleName,p.LastName,d.AdmissionId,a.AdmissionNo,d.BookReceiptId,b.InVoiceNo,b.OrderNo,d.DocumentPath,d.DocumentName,d.FileName,d.`Status`,d.DocumentType,d.CreatedBy,d.DocumentDescription,d.CreatedDate,d.ModifiedDate from gbl_sm_tbl_document d join gbl_sm_tbl_staff s join gbl_sm_tbl_student st join gbl_sm_tbl_parent p join gbl_sm_tbl_admission a join gbl_sm_tbl_bookreceipt b on d.EmployeeId = s.EmployeeId and d.StudentId = st.StudentId and d.ParentId = p.ParentId and d.AdmissionId = a.AdmissionId and d.BookReceiptId = b.BookReceiptId";
			     } 
			   
			    gsQuery=rdSession.createSQLQuery(gsSql);
			    List gcList=gsQuery.list();
			    Iterator gsIT=gcList.iterator();
			    while(gsIT.hasNext())
			     {
			    	Object[] ex=(Object[])gsIT.next();
			    	sb.append("<Document>");
				    sb.append("\n");
			        sb.append("<DocumentId>");
				    sb.append(ex[0]);
				    sb.append("</DocumentId>");
				    sb.append("\n");
				    sb.append("<EmployeeId>");
				    sb.append(ex[1]);
				    sb.append("</EmployeeId>");
				    sb.append("\n");
				    sb.append("<StaffNumber>");
					sb.append(ex[2]);
					sb.append("</StaffNumber>");
					 sb.append("\n");
					sb.append("<FirstName>");
					sb.append(ex[3]);
					sb.append("</FirstName>");
					 sb.append("\n");
					sb.append("<MiddleName>");
					sb.append(ex[4]);
					sb.append("</MiddleName>");
					sb.append("\n");
					sb.append("<LastName>");
					sb.append(ex[5]);
					sb.append("</LastName>");
					sb.append("\n");
					sb.append("<StudentId>");
					sb.append(ex[6]);
					sb.append("</StudentId>");
					sb.append("\n");
					sb.append("<StudentNumber>");
				    sb.append(ex[7]);
				    sb.append("</StudentNumber>");
				    sb.append("\n");
				    sb.append("<FirstName>");
				    sb.append(ex[8]);
				    sb.append("</FirstName>");
				    sb.append("\n");
				    sb.append("<MiddleName>");
					sb.append(ex[9]);
					sb.append("</MiddleName>");
					 sb.append("\n");
					sb.append("<LastName>");
					sb.append(ex[10]);
					sb.append("</LastName>");
					 sb.append("\n");
					sb.append("<ParentId>");
					sb.append(ex[11]);
					sb.append("</ParentId>");
					sb.append("\n");
					 sb.append("<FirstName>");
					    sb.append(ex[12]);
					    sb.append("</FirstName>");
					    sb.append("\n");
					    sb.append("<MiddleName>");
						sb.append(ex[13]);
						sb.append("</MiddleName>");
						 sb.append("\n");
						sb.append("<LastName>");
						sb.append(ex[14]);
						sb.append("</LastName>");
						 sb.append("\n");
					sb.append("<AdmissionId>");
					sb.append(ex[15]);
					sb.append("</AdmissionId>");
					sb.append("\n");
					sb.append("<AdmissionNo>");
					sb.append(ex[16]);
					sb.append("</AdmissionNo>");
					sb.append("\n");
					sb.append("<BookReceiptId>");
					sb.append(ex[17]);
					sb.append("</BookReceiptId>");
					sb.append("\n");
					sb.append("<InVoiceNo>");
					sb.append(ex[18]);
					sb.append("</InVoiceNo>");
					sb.append("\n");
					sb.append("<OrderNo>");
					sb.append(ex[19]);
					sb.append("</OrderNo>");
					sb.append("\n");
					sb.append("<DocumentPath>");
					sb.append(ex[20]);
					sb.append("</DocumentPath>");
					sb.append("\n");
					sb.append("<DocumentName>");
					sb.append(ex[21]);
					sb.append("</DocumentName>");
					sb.append("\n");
					sb.append("<FileName>");
					sb.append(ex[22]);
					sb.append("</FileName>");
					sb.append("\n");
					sb.append("<Status>");
					sb.append(ex[23]);
					sb.append("</Status>");
					sb.append("\n");
					sb.append("<DocumentType>");
					sb.append(ex[24]);
					sb.append("</DocumentType>");
					sb.append("\n");
					sb.append("<CreatedBy>");
					sb.append(ex[25]);
					sb.append("</CreatedBy>");
					sb.append("\n");
					sb.append("<DocumentDescription>");
					sb.append(ex[26]);
					sb.append("</DocumentDescription>");
					sb.append("\n");
					sb.append("<CreatedDate>");
					sb.append(ex[27]);
					sb.append("</CreatedDate>");
					sb.append("\n");
					sb.append("<ModifiedDate>");
					sb.append(ex[28]);
					sb.append("</ModifiedDate>");
					sb.append("\n");
					sb.append("</Document>");
			}
		}
					sb.append("</Documents>");
					    String str= sb.toString();
						 tx.commit();
					return str;
			
		
		}
			    catch (HibernateException localException) {
			    	localException.printStackTrace(); 
			         if (rdTx!=null) rdTx.rollback();
			         localException.printStackTrace(); 
			      }finally {
			         rdSession.close(); 
			      }
			
		return string;
	}

}
