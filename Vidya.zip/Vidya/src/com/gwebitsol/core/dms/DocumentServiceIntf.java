package com.gwebitsol.core.dms;

import javax.ws.rs.Consumes;

import javax.ws.rs.GET;
import javax.ws.rs.POST;

import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

@Path("/document/")

public interface DocumentServiceIntf {
	
	@POST
	@Consumes({"application/xml", "application/json"})
	@Produces({"application/xml", "application/json"})
	@Path("/add/")
	public Response addDocument(DocumentPojo ap,@QueryParam("userid") int userid, @QueryParam("connectionid") int connectionid,@QueryParam("datastoreName")String datastoreName);
	
	@POST
	@Consumes({"application/xml", "application/json"})
	@Produces({"application/xml", "application/json"})
	@Path("/update")
	public Response updateDocument(DocumentPojo ap,@QueryParam("userid") int userid, @QueryParam("connectionid") int connectionid,@QueryParam("datastoreName")String datastoreName);
	
	@POST
	@Consumes({"application/xml", "application/json"})
	@Produces({"application/xml", "application/json"})
	@Path("/delete")
	public Response deleteDocument(@QueryParam("documentId") int documentId,@QueryParam("userid") int userid, @QueryParam("connectionid") int connectionid,@QueryParam("datastoreName")String datastoreName);
	
	
	@GET
	@Consumes({"application/xml", "application/json"})
	@Produces({"application/xml", "application/json"})
	@Path("/get")
	public Response getDocumentById(@QueryParam("documentId") int documentId,@QueryParam("userid") int userid, @QueryParam("connectionid") int connectionid,@QueryParam("datastoreName")String datastoreName);
	
	
	@GET
	@Consumes({"application/xml", "application/json"})
	@Produces({"application/xml", "application/json"})
	@Path("/getall")
	public Response getAllDocuments(@QueryParam("userid") int userid, @QueryParam("connectionid") int connectionid,@QueryParam("datastoreName")String datastoreName
			,@QueryParam("PNO") int PNO,@QueryParam("size") int size, @QueryParam("document") String document);
}
	/*@POST
	@Path("/upload") 
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public Response uploadFile(@FormDataParam("upload") InputStream is, 
            @FormDataParam("upload") FormDataContentDisposition formData);
}*/
