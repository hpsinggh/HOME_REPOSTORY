package com.gwebitsol.core.dms;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.stereotype.Service;

import com.gwebitsol.core.security.MDVerifyConnectionID;
import com.gwebitsol.core.security.MDVerifyDatastoreName;
import com.gwebitsol.core.usermanagement.MDGetUserFromID;
import com.gwebitsol.core.util.MDTransactionWriter;

@Service
public class DocumentService implements DocumentServiceIntf{

	@Context private HttpServletRequest hsr;
	
	public Response addDocument(DocumentPojo ap,int userid,int connectionid,String datastoreName) {

		MDTransactionWriter.accesslog.info("Request from:"+hsr.getRemoteHost());
		
		String status= null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		
		try{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userid);
			
			System.out.println(connectionid);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userid,connectionid);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
			
			DocumentDao ad= new DocumentDao();	
			status=  ad.addDocument(ap);
			System.out.println(status);
			Long el=System.currentTimeMillis();
			String endDate=dateFormat.format(new Date());
			//status= "user validation is successfull";
			MDTransactionWriter.writeLog("SCHOOL","MMS","srinu",startDate,endDate,sl,el,status,hsr.getRemoteHost());
	    }
			else
			{
				status="you are not authorised user";
			}
		}
		catch(Exception localException)
		{

			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status="failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response updateDocument(DocumentPojo ap,int userid,int connectionid,String datastoreName) {
	MDTransactionWriter.accesslog.info("Request from:"+hsr.getRemoteHost());
		
		String status= null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();

		try{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userid);
			
			System.out.println(connectionid);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userid,connectionid);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
			DocumentDao ad= new DocumentDao();	
			status=  ad.updateDocument(ap);
			System.out.println(status);
			Long el=System.currentTimeMillis();
			String endDate=dateFormat.format(new Date());
			//status= "user validation is successfull";
			MDTransactionWriter.writeLog("SCHOOL","MMS","srinu",startDate,endDate,sl,el,status,hsr.getRemoteHost());
	
		}
			else
			{
				status="you are not authorised user";
			}
		}catch(Exception localException)
		{

			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status="failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response deleteDocument(int documentId,int userid,int connectionid,String datastoreName) {
		
	MDTransactionWriter.accesslog.info("Request from:"+hsr.getRemoteHost());
		
		String status= null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();

		try{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userid);
			
			System.out.println(connectionid);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userid,connectionid);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
			DocumentDao ad= new DocumentDao();	
			status=  ad.deleteDocument(documentId);
			System.out.println(status);
			Long el=System.currentTimeMillis();
			String endDate=dateFormat.format(new Date());
			//status= "user validation is successfull";
			MDTransactionWriter.writeLog("SCHOOL","MMS","srinu",startDate,endDate,sl,el,status,hsr.getRemoteHost());
	
			}
			else
			{
				status="you are not authorised user";
			}
		}catch(Exception localException)
		{

			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status="failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response getDocumentById(int documentId,int userid,int connectionid,String datastoreName) {

	MDTransactionWriter.accesslog.info("Request from:"+hsr.getRemoteHost());
		
		String status= null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userid);
			
			System.out.println(connectionid);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userid,connectionid);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
			DocumentDao ad= new DocumentDao();	
			status=  ad.getDocumentById(documentId);
			System.out.println(status);
			Long el=System.currentTimeMillis();
			String endDate=dateFormat.format(new Date());
			//status= "user validation is successfull";
			MDTransactionWriter.writeLog("SCHOOL","MMS","srinu",startDate,endDate,sl,el,status,hsr.getRemoteHost());
	
		}
			else
			{
				status="you are not authorised user";
			}
		}catch(Exception localException)
		{

			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status="failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

	public Response getAllDocuments(int userid,int connectionid,String datastoreName,int PNO, int size,String document) {
	MDTransactionWriter.accesslog.info("Request from:"+hsr.getRemoteHost());
		
		String status= null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();

		try{
			MDGetUserFromID mdgufid=new MDGetUserFromID();
			String requester=mdgufid.getUserName(userid);
			
			System.out.println(connectionid);
			MDVerifyConnectionID mdvcid=new MDVerifyConnectionID();
			int ret=mdvcid.verifyConnectionID(userid,connectionid);
			
			MDVerifyDatastoreName mdvdsn=new MDVerifyDatastoreName();
			int rtVal=mdvdsn.verifyDatastoreName(datastoreName);
			
			System.out.println("request making user:: "+requester);
			System.out.println("connectionid verification value:: "+ret);
			System.out.println("datastore verification value :: "+rtVal);
			if(ret==1 )//&& rtVal==1)
			{
			DocumentDao ad= new DocumentDao();	
			status=  ad.getAllDocuments(PNO,size,document);
			System.out.println(status);
			Long el=System.currentTimeMillis();
			String endDate=dateFormat.format(new Date());
			//status= "user validation is successfull";
			MDTransactionWriter.writeLog("SCHOOL","MMS","srinu",startDate,endDate,sl,el,status,hsr.getRemoteHost());
			}
			else
			{
				status="you are not authorised user";
			}
		}catch(Exception localException)
		{

			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status="failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}

}
