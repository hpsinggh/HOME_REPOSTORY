package com.gwebitsol.core.exam;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="Classes")

public class Classes {
	
    int classId;  
    
    Sections section = new Sections();

	public int getClassId() {
		return classId;
	}
	
	public void setClassId(int classId) {
		this.classId = classId;
	}

	public Sections getSection() {
		return section;
	}

	public void setSection(Sections section) {
		this.section = section;
	}

	@XmlElementWrapper(name="Sections")
	@XmlElement(name="Section")
	public List<Section> getSections() {
		return section.getSections();
	}
	
	public void setSections(List<Section> sections) {
		section.setSections(sections);
	}
	
}
