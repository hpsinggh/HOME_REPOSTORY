package com.gwebitsol.core.exam;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="AllRooms")
public class AllRooms {

	// List rooms
	List<RoomTypes> roomtypes;

	public List<RoomTypes> getRoomtypes() {
		return roomtypes;
	}

	public void setRoomtypes(List<RoomTypes> roomtypes) {
		this.roomtypes = roomtypes;
	}
	
}
