package com.gwebitsol.core.exam;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="Room")
public class Room {
	
	int roomId;

	public int getRoomId() {
		return roomId;
	}

	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}
	
}
