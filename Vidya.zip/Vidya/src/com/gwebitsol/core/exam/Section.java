package com.gwebitsol.core.exam;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="Section")
public class Section {
	
	int sectionId;

	public int getSectionId() {
		return sectionId;
	}

	public void setSectionId(int sectionId) {
		this.sectionId = sectionId;
	}

}
