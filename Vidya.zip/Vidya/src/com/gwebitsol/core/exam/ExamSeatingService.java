package com.gwebitsol.core.exam;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.stereotype.Service;

import com.gwebitsol.core.address.AddressDao;
import com.gwebitsol.core.security.MDValidation;
import com.gwebitsol.core.security.MDVerifyConnectionID;
import com.gwebitsol.core.security.MDVerifyDatastoreName;
import com.gwebitsol.core.usermanagement.MDGetUserFromID;
import com.gwebitsol.core.util.MDTransactionWriter;
import com.gwebitsol.seater.GblClass;
import com.gwebitsol.seater.GblRoom;
import com.gwebitsol.seater.GblSeatClass;

@Service
public class ExamSeatingService implements ExamSeatingServiceIntf {

	@Context
	private HttpServletRequest hsr;

	public Response addExamSeating(Seating esa, int userid, int connectionid, String datastoreName, int schoolid,
			int branchid, String status) {

		MDTransactionWriter.accesslog.info("Request from:" + hsr.getRemoteHost() + "at " + new Date());
		String XMLString = null;

		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();

		esa.setBranchId(branchid);
		esa.setSchoolId(schoolid);
		esa.setUserId(userid);
		esa.setStatus(status);

		try {

			MDValidation mdv = new MDValidation();
			int ret = mdv.allvalidations(userid, connectionid, datastoreName, schoolid, branchid);
			System.out.println("verifiedvalue::" + ret);

			if (ret == 1) {
				ExamInputOutputSaving eios = new ExamInputOutputSaving();
				XMLString = eios.InsertExamInput(esa);
				System.out.println(status);
				Long el = System.currentTimeMillis();
				String endDate = dateFormat.format(new Date());

				MDTransactionWriter.writeLog("SCHOOL", "MMS", "srinu", startDate, endDate, sl, el, status,
						hsr.getRemoteHost());
			} else {
				XMLString = "you are not authorised user";
			}
		} catch (Exception localException) {

			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			XMLString = "failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}

	public Response ProcessExamSeating(Seating esa,int userid, int connectionid, String datastoreName, int schoolid,
			int branchid, String status) {
		MDTransactionWriter.accesslog.info("Request from:" + hsr.getRemoteHost() + "at " + new Date());
		String XMLString = null;
		String statusStr = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();

		GblSeatClass seatcls = new GblSeatClass();

		int[] sclasses = null;

		System.out.println("emptyseats" + esa.getEmptySeats());

		try {

			MDValidation mdv = new MDValidation();
			int ret = mdv.allvalidations(userid, connectionid, datastoreName, schoolid, branchid);
			System.out.println("verifiedvalue::" + ret);

			if (ret == 1) {

				// ROOMS

				String aislesFlag = null;
				int seatingtypeid = 0;

				List<GblRoom> lsRoom = new ArrayList<GblRoom>();

				List roomtypes = esa.getAllrooms().getRoomtypes();

				for (int i = 0; i < roomtypes.size(); i++) {

					aislesFlag = esa.getAllrooms().getRoomtypes().get(i).getAislesFlag();

					seatingtypeid = esa.getAllrooms().getRoomtypes().get(i).getRoomtypeId();

					List rooms = esa.getAllrooms().getRoomtypes().get(i).getRooms();

					StudentsForSeatingDao sfs = new StudentsForSeatingDao();

					lsRoom = sfs.getRoomInfo(rooms, seatingtypeid, aislesFlag, lsRoom);

				}

				seatcls.setGblRoom(lsRoom);
				System.out.println(lsRoom.size());

				// CLASSES AND SECTIONS

				List<GblClass> lsSchClass = new ArrayList<GblClass>();

				List classes = esa.getAllclasses().getClasses();

				for (int i = 0; i < classes.size(); i++) {

					Classes Objs = (Classes) classes.get(i);

					int classId = Objs.getClassId();

					List sections = esa.getAllclasses().getClasses().get(i).getSections();

					StudentsForSeatingDao sfs = new StudentsForSeatingDao();

					GblClass gClass = sfs.getAllStudents(classId, sections);

					lsSchClass.add(gClass);
				}

				seatcls.setGblClass(lsSchClass);

				// method call

				Enginecall ec = new Enginecall();
				XMLString = ec.getEnegineResult(classes,seatcls,userid, schoolid, branchid,status);

				// ec.getEnegineResult(classes, seatcls);
				/*
				 * ExamInputOutputSaving eos = new ExamInputOutputSaving();
				 * eos.InsertExamInput(esa);
				 */
				String endDate = dateFormat.format(new Date());
				Long el = System.currentTimeMillis();
				MDTransactionWriter.writeLog(datastoreName, "ServiceMS", "srinu", startDate, endDate, sl, el, statusStr,
						hsr.getRemoteHost());
			} else {
				XMLString = "you are not authorised user";
			}
		} catch (Exception localException) {
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			XMLString = "failed in service layer";
			localException.printStackTrace();
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}

	public Response getExamSeatingbyid(String processno, int assessmentid, int userid, int connectionid,
			String datastoreName, int schoolid, int branchid, String status) {

		String XMLString = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate = dateFormat.format(date);
		Long sl = System.currentTimeMillis();

		try {

			MDValidation mdv = new MDValidation();
			int ret = mdv.allvalidations(userid, connectionid, datastoreName, schoolid, branchid);
			System.out.println("verifiedvalue::" + ret);

			if (ret == 1) // && rtVal==1)
			{

				ExamInputOutputSaving eos = new ExamInputOutputSaving();
				XMLString = eos.getExamseating(processno, assessmentid, schoolid, branchid);
				System.out.println(status);
				Long el = System.currentTimeMillis();
				String endDate = dateFormat.format(new Date());
				// status= "user validation is successfull";
				MDTransactionWriter.writeLog("SCHOOL", "MMS", "srinu", startDate, endDate, sl, el, status,
						hsr.getRemoteHost());
			} else {
				status = "you are not authorised user";
			}
		} catch (Exception localException) {

			MDTransactionWriter.exceptionlog.debug(localException);
			MDTransactionWriter.exceptionlog.info(localException);
			status = "failed in Service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}

}
