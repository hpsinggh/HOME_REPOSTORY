package com.gwebitsol.core.exam;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "Seater")
public class Seating {

	// xml - AllRooms
	// xml - Classes

	String emptySeats;
	int schoolId;
	int branchId;
	int userId;
	String status;
	String createdDate;
	
	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	Date date = new Date();
	String modifiedDate = dateFormat.format(date);

	
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	AllClasses allclasses = new AllClasses();
	
    AllRooms allrooms = new AllRooms();
	
	public AllClasses getAllclasses() {
		return allclasses;
	}

	public void setAllclasses(AllClasses allclasses) {
		this.allclasses = allclasses;
	}

	public AllRooms getAllrooms() {
		return allrooms;
	}

	public void setAllrooms(AllRooms allrooms) {
		this.allrooms = allrooms;
	}

	
	@XmlElementWrapper(name="AllRooms")
    @XmlElement(name="RoomTypes")
	public List<RoomTypes> getRoomtypes() {
		return allrooms.getRoomtypes();
	}
	
	public void setRoomtypes(List<RoomTypes> roomtypes) {
		allrooms.setRoomtypes(roomtypes);
	}

	@XmlElementWrapper(name="AllClasses")
    @XmlElement(name="Classes")
	public List<Classes> getClasses() {
		return allclasses.getClasses();
	}

	public void setClasses(List<Classes> classes) {
		allclasses.setClasses(classes);
	}
	
	
	public String getEmptySeats() {
		return emptySeats;
	}

	public void setEmptySeats(String emptySeats) {
		this.emptySeats = emptySeats;
	}

	public int getSchoolId() {
		return schoolId;
	}

	public void setSchoolId(int schoolId) {
		this.schoolId = schoolId;
	}

	public int getBranchId() {
		return branchId;
	}

	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	
}
