package com.gwebitsol.core.exam;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="RoomTypes")

public class RoomTypes {
	
	int noofRooms;
	int roomtypeId;
	String aislesFlag;
	 	
	Rooms multiplerooms = new Rooms();
	
	@XmlElementWrapper(name="Rooms")
	@XmlElement(name="Room")
	public List<Room> getRooms() {
		return multiplerooms.getRooms();
	}
	public void setRooms(List<Room> rooms) {
		multiplerooms.setRooms(rooms);;
	}

	
	public int getNoofRooms() {
		return noofRooms;
	}
	public void setNoofRooms(int noofRooms) {
		this.noofRooms = noofRooms;
	}
	public int getRoomtypeId() {
		return roomtypeId;
	}
	public void setRoomtypeId(int roomtypeId) {
		this.roomtypeId = roomtypeId;
	}
	public String getAislesFlag() {
		return aislesFlag;
	}
	public void setAislesFlag(String aislesFlag) {
		this.aislesFlag = aislesFlag;
	}
	public Rooms getMultiplerooms() {
		return multiplerooms;
	}
	public void setMultiplerooms(Rooms multiplerooms) {
		this.multiplerooms = multiplerooms;
	}
	
	
}
