package com.gwebitsol.core.exam;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.SQLQuery;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.gwebitsol.seater.GblRoom;
import com.gwebitsol.seater.GblSeatClass;

@Repository
@Component
class ExamSeatingArrangementPrint {

	StringBuffer sb = new StringBuffer();
	
	String exam = null;
	String processtype= null;
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public String printSeatChartOP(
			HashMap<Integer, HashMap<Integer, HashMap<Integer, ArrayList>>> roomTypeRoomGroupSets,
			HashMap<Integer, Integer> grpClas,
			HashMap<HashMap<Integer, Integer>, HashMap<Integer, Integer[]>> seatPers,int userid,int schoolid,int branchid,String status
			) {
		
		System.out.println(); 
		System.out.println("ROOM TYPE GROUP SETS: " + roomTypeRoomGroupSets);
		System.out.println();
		
		Iterator rtrmgsIT = roomTypeRoomGroupSets.entrySet().iterator();

		while (rtrmgsIT.hasNext()) {
			HashMap<Integer, HashMap<Integer, ArrayList>> roomGrpSet = new HashMap<Integer, HashMap<Integer, ArrayList>>();
			Map.Entry rtRgsEntry = (Map.Entry) rtrmgsIT.next();
			Integer roomType = 0;
			roomType = (Integer) rtRgsEntry.getKey();
			
			
			roomGrpSet = (HashMap <Integer, HashMap<Integer, ArrayList>>) rtRgsEntry.getValue();
			Iterator rmgsIT = roomGrpSet.entrySet().iterator();

			while (rmgsIT.hasNext()) {
				Map.Entry rmgsEntry = (Map.Entry) rmgsIT.next();
				//Integer [] aryRoomNo = {};
				Integer RoomNo = 0;
				RoomNo = (Integer) rmgsEntry.getKey();
				
				HashMap<Integer, ArrayList> allGroupSets = new HashMap<Integer, ArrayList>();
				allGroupSets = (HashMap<Integer, ArrayList>) rmgsEntry.getValue();
			
				Iterator gsIT = allGroupSets.entrySet().iterator();
				while (gsIT.hasNext()) {
					Map.Entry gsEntry = (Map.Entry) gsIT.next();
					Integer grpId = 0;
					grpId = (Integer) gsEntry.getKey();
							
					ArrayList <Integer> groupSet = new ArrayList<Integer> ();
					groupSet = (ArrayList<Integer>) gsEntry.getValue();
					
					
					int stdClass = 0;
					if (grpClas.containsKey(grpId)) {
					stdClass = grpClas.get(grpId);
					}
					HashMap <Integer, Integer> roomGroupId = new  HashMap<Integer, Integer> ();
					HashMap  <Integer, Integer[]> classPersonSet = new HashMap<Integer, Integer[]> ();
					roomGroupId.put(RoomNo,grpId);
					if (seatPers.containsKey(roomGroupId)) {
						classPersonSet = seatPers.get(roomGroupId);
					}
					Integer [] personSet = classPersonSet.get(stdClass);
					int lsLgth = 0;
					if (personSet != null) lsLgth = personSet.length;
						
					ExamInputOutputSaving eap = new ExamInputOutputSaving();
					processtype =eap.InsertExamOutput(stdClass,roomType,RoomNo,grpId,personSet,groupSet,userid, schoolid, branchid,status);
			     
					System.out.println("______________________________________________________________________");
					System.out.println("CLASS: " + stdClass + "  [" + lsLgth + "]");       
					System.out.println("ROOM TYPE: " + roomType);
     				System.out.println("ROOM NO.: " + RoomNo + "      PERSONS : " + Arrays.toString(personSet));
				    System.out.println("GROUP : " + grpId + " [" + groupSet.size() + "]       SEATS : " + groupSet); 
				}
			//	System.out.println("                   ROOM_GROUP_SEATS - ROOM NO:" + Arrays.toString(roomNo));
			}	
		}	
		return processtype;
		
	}

	@SuppressWarnings("rawtypes")
	public String printSummary(GblSeatClass seatcls, HashMap<Integer, Integer> persTotal,int userid,int schoolid,int branchid,String status) {

		//Print Seat Summary
				List gblroomLst =  seatcls.getGblRoom();
				Iterator gbrmIT = gblroomLst.iterator();
				
			
				while (gbrmIT.hasNext()){
					GblRoom room = (GblRoom) gbrmIT.next();
					Integer[] roomNoArry = room.getRoomNo();
					int roomType = room.getRoomType();
					HashMap<Integer, Integer> GroupTotals = room.getGroupTotals();
					
					for (int i = 0; i<roomNoArry.length; i++ ) {
						HashMap<Integer, Integer> RoomGroupTotals = room.getRoomGroupTotals();
						
						System.out.println("ROOM NO: " + roomNoArry[i] + "       ROOM GROUP TOTAL: " + RoomGroupTotals);
					}	System.out.println("                   CUMULATIVE GROUP TOTAL (ROOM TYPE - " + roomType + ") : " + GroupTotals);
				}
				System.out.println("______________________________________________________________________");
				
				Iterator ptIT = persTotal.entrySet().iterator();
				
				while (ptIT.hasNext()) {
					
					Map.Entry entry = (Map.Entry) ptIT.next();
					Integer stdClass = (Integer) entry.getKey();
					Integer persTot = (Integer) entry.getValue();
					System.out.println("CLASS : " + stdClass + "          PERSON TOTAL: " + persTot);
				}
				
				System.out.println("______________________________________________________________________");
				return exam;
	}
	
}
