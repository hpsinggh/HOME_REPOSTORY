package com.gwebitsol.core.exam;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.gwebitsol.seater.GblGenericSeater;
import com.gwebitsol.seater.GblSeatClass;
import com.gwebitsol.seater.GblSeater;
//import com.gwebitsol.seater.vname.seaterTest.GblSeaterTest;
//import com.gwebitsol.seater.vname.seaterTest.GblSeaterTest2;
import com.gwebitsol.seater.vname.seaterTest.GblSeaterTest;

public class Enginecall {
	
	public String getEnegineResult(List classes, GblSeatClass seatcls,int userid,int schoolid,int branchid,String status) {
		
		GblSeater genSeat = new GblGenericSeater();
		
		for(int i=0;i<=classes.size()-1;i++)
		{
		Classes Objs = (Classes) classes.get(i); 
		int classId = Objs.getClassId();
		genSeat.getClassPersons(seatcls,classId);
		}
	 
		genSeat.processRoomSeats(seatcls);
		
		
		HashMap<Integer, HashMap<Integer, HashMap<Integer, ArrayList>>> roomTypeRoomGroupSets = genSeat.getRoomSeats();
		
		HashMap<Integer, Integer> grpClas = genSeat.getGroupClassMap();
		
		HashMap<HashMap<Integer, Integer>, HashMap<Integer, Integer[]>> seatPers = genSeat.getSeatedPersons();
		
		HashMap<Integer, Integer> persTotal = genSeat.getPersonTotals();
		
		ExamSeatingArrangementPrint esap = new ExamSeatingArrangementPrint();
		
		//com.gwebitsol.seater.vname.seaterTest.GblSeaterTest esap = new com.gwebitsol.seater.vname.seaterTest.GblSeaterTest();
		//GblSeaterTest esap = new GblSeaterTest();
		//esap.printSummary(seatcls, persTotal,requestid,userid, schoolid, branchid);
		//esap.printSeatChartOP(roomTypeRoomGroupSets,grpClas,seatPers,requestid,userid, schoolid, branchid);
		
	return "<FullSeat>"+"/n"+esap.printSummary(seatcls, persTotal,userid, schoolid, branchid,status)+"/n"+esap.printSeatChartOP(roomTypeRoomGroupSets,grpClas,seatPers,userid, schoolid, branchid,status)+"/n"+"</FullSeat>";
		
	}

	
}
