package com.gwebitsol.core.exam;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class ExamInputOutputSaving {

	Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
	Transaction tx = null;
	StringBuffer sb = new StringBuffer();

	public String InsertExamInput(Seating esa) {
		String str = null;
		try {
			tx = rdSession.beginTransaction();
			Integer exioid = (Integer) rdSession.save(esa);
			
			tx.commit();

			sb.append("<ExamInput>");
			sb.append("\n");
			sb.append("<id>");
			sb.append("\n");
			sb.append(exioid);
			sb.append("</id>");
			sb.append("\n");
			sb.append("</ExamInput>");
		} catch (Exception localException) {
			localException.printStackTrace();
			System.out.println(localException);

			sb.append("<Response>");
			sb.append("\n");
			sb.append("<Result>");
			sb.append("\n");
			sb.append("Fail");
			sb.append("\n");
			sb.append("</Result>");
			sb.append("\n");
			sb.append("<Description>");
			sb.append("could not inserted exam info");
			sb.append("</Description>");
			sb.append("\n");
			sb.append("<Exception>");
			sb.append(localException);
			sb.append("</Exception>");
			sb.append("</Response>");
			str = sb.toString();

			MDTransactionWriter.exceptionlog.info(localException);
			if (tx != null)
				tx.rollback();
		} finally {
			rdSession.close();
		}
		return str;
	}

	public String InsertExamOutput(int stdClass, int roomType, int RoomNo, int grpId, Integer[] personSet,
			ArrayList<Integer> groupSet,int userid, int schoolid, int branchid,String status) {
		String sqlstr = null;
		int[] outputarr = new int[groupSet.size()];
	   
     	/*Calendar cal = Calendar.getInstance();
    	cal.getTime();
    	SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
    	String time=sdf.format(cal.getTime()).toString();
    	String processno=("G"+time.substring(0,2) + time.substring(3, 5) + time.substring(6)+"WEB");
    	*/
		String processno="gwebitsol";
		try {

			tx = rdSession.beginTransaction();
            
            int assessmentid =0;
            
			Integer[] groupids = new Integer[groupSet.size()];
		
			groupids = (Integer[]) groupSet.toArray(new Integer[groupSet.size()]);

			for (int i = 0; i < groupids.length; i++) {
				sqlstr = "insert into gbl_sm_tbl_examoutput (ProcessNo,UserId,AssessmentId,ClassName,SeatingType,RoomNo,PersonRef,Seat,GroupId,ExecutionStatus,SchoolId,BranchId) "
						 + "values ('" +processno + "','" +userid + "','" + assessmentid + "','" + stdClass + "','"+ roomType + "','" + RoomNo + "','"
						 + personSet[i] + "','"  + groupids[i] + "','" +grpId +"','" +status + "','" +schoolid + "','" +branchid+"');";

		    Query query=rdSession.createSQLQuery(sqlstr);
				    
			int outstatus = query.executeUpdate();
			
			outputarr[i] = outstatus;
			
			}
			
			tx.commit();
			
			sb.append("<ExamProcessType>");
			sb.append("\n");
			sb.append("<ExamProcessTypeId>");
			sb.append("\n");
			sb.append(processno);
			sb.append("\n");
			sb.append("</ExamProcessTypeId>");
			sb.append("\n");
			sb.append("</ExamProcessType>");
			sqlstr = sb.toString();
			
		} catch (Exception localException) {
			localException.printStackTrace();
			System.out.println(localException);

			sb.append("<Response>");
			sb.append("\n");
			sb.append("<Result>");
			sb.append("\n");
			sb.append("Fail");
			sb.append("\n");
			sb.append("</Result>");
			sb.append("\n");
			sb.append("<Description>");
			sb.append("could not inserted admission info");
			sb.append("</Description>");
			sb.append("\n");
			sb.append("<Exception>");
			sb.append(localException);
			sb.append("</Exception>");
			sb.append("</Response>");
			sqlstr = sb.toString();

			MDTransactionWriter.exceptionlog.info(localException);
			if (tx != null)
				tx.rollback();
		} finally {
			rdSession.close();
		}
		return sqlstr;
	}

	public String getExamseating(String processno, int assessmentid, int schoolid, int branchid) {
		String studentreg = null;
		String gsSql = null;
	
		 String ptype = null;
		 Integer usrid =null;
		 Integer assmentid= null;
		 Integer scid = null;
		 Integer brid = null;
		 String exstat = null;
		 int exid=0;
		 
		 Integer processid = null;
		 String clsname = null;
		 Integer roomSeatType = null;
		 String perref = null;
		
		 Integer rmno = null;
		 Integer seat = null;
		 Integer grpid = null;
		
		try {
			
			tx = rdSession.beginTransaction();

			/*gsSql= "update gbl_sm_tbl_examoutput set AssessmentId='"+assessmentid+"' where ProcessNo='"+processno+"';";
	 
              SQLQuery query=rdSession.createSQLQuery(gsSql);
		      exid = query.executeUpdate();
		
			if(exid>0)
			{
			*/
			gsSql = "select DISTINCT ProcessNo,UserId,AssessmentId,SchoolId,BranchId,ExecutionStatus from gbl_sm_tbl_examoutput where ProcessNo ='"+processno+"' and SchoolId='"+schoolid+"' and BranchId='"+branchid+"';";
			
			SQLQuery squery = rdSession.createSQLQuery(gsSql).addScalar("ProcessNo", Hibernate.STRING).addScalar("UserId", Hibernate.INTEGER)
					.addScalar("AssessmentId", Hibernate.INTEGER).addScalar("SchoolId", Hibernate.INTEGER)
					.addScalar("BranchId", Hibernate.INTEGER).addScalar("ExecutionStatus", Hibernate.STRING);
			
			List strlist=squery.list();
			
			Iterator it = strlist.iterator();
			while(it.hasNext())
			{
				Object[] mdcArr=(Object[])it.next();
				  ptype   =  (String) mdcArr[0];
				  usrid= (Integer) mdcArr[1];
				  assmentid  = (Integer) mdcArr[2];
				  scid =(Integer) mdcArr[3];
				  brid =(Integer) mdcArr[4];
				  exstat = (String) mdcArr[5];
			}
			
			sb.append("<ExamSeating>");
			sb.append("\n");
			sb.append("<processType>"+ptype+"</processType>");
			sb.append("\n");
			sb.append("<UserId>"+usrid+"</UserId>");
			sb.append("\n");
			sb.append("<AssessmentId>"+assmentid+"</AssessmentId>");
			sb.append("\n");
			sb.append("<schoolId>" +scid + "</schoolId>");
			sb.append("\n");
			sb.append("<branchId>" +brid + "</branchId>");
			sb.append("\n");
			sb.append("<executionStatus>" +exstat + "</executionStatus>");
			sb.append("\n");
			
			
				SQLQuery gsQuery = rdSession.createSQLQuery("select DISTINCT SeatingType from gbl_sm_tbl_examoutput ;")
						.addScalar("SeatingType", Hibernate.INTEGER);
				List gcList = gsQuery.list();

				Iterator sit = gcList.iterator();

				while (sit.hasNext()) 
				{
					roomSeatType = (Integer) sit.next();
				
				/*for (int i = 0; i <= gcList.size(); i++) {
				
					roomSeatType = (Integer) gcList.get(i);*/
					sb.append("<roomType>" + roomSeatType+ "</roomType>");
					sb.append("\n");
					
					SQLQuery roomQuery = rdSession.createSQLQuery(
							"select DISTINCT RoomNo from gbl_sm_tbl_examoutput where SeatingType='" + roomSeatType + "' order by RoomNo;")
							.addScalar("RoomNo", Hibernate.INTEGER);
					List rList = roomQuery.list();
					Iterator rit = rList.iterator();

					while (rit.hasNext()) {
						rmno = (Integer) rit.next();
						sb.append("<roomNo>" + rmno + "</roomNo>");
						sb.append("\n");

						SQLQuery classQuery = rdSession.createSQLQuery(
								"select DISTINCT ClassName from gbl_sm_tbl_examoutput where RoomNo='" + rmno + "';")
								.addScalar("ClassName", Hibernate.STRING);

						List cList = classQuery.list();
						Iterator cit = cList.iterator();
						while (cit.hasNext()) {
							clsname = (String) cit.next();
							sb.append("<ClassName>" +clsname + "</ClassName>");
							sb.append("\n");
							
							SQLQuery grpQuery = rdSession.createSQLQuery(
									"select DISTINCT GroupId from gbl_sm_tbl_examoutput where ClassName='" + clsname
											+ "';")
									.addScalar("GroupId", Hibernate.INTEGER);

							List gList = grpQuery.list();
							Iterator git = gList.iterator();

							while (git.hasNext()) {
								grpid = (Integer) git.next();
								
								sb.append("<groupId>" +grpid + "</groupId>");
								sb.append("\n");
								
								gsSql = "select * from gbl_sm_tbl_examoutput where ProcessNo ='" + processno
										+ "' and SeatingType='" + roomSeatType + "' and RoomNo='"+rmno+"'and ClassName='"+clsname+"' and GroupId='"+grpid+"' and SchoolId='" + schoolid
										+ "' and BranchId='" + branchid + "';";

								SQLQuery prQuery = rdSession.createSQLQuery(gsSql)
										.addScalar("PersonRef", Hibernate.STRING).addScalar("Seat", Hibernate.INTEGER);
								
								List prList=prQuery.list();
								Iterator iter = prList.iterator();
								
								String[] person = new String[gcList.size()];
								String PersonSeat = ""; 
								while(iter.hasNext())
								{
									Object[] obj = (Object[]) iter.next();
									perref  = (String) obj[0];
									seat  = (Integer) obj[1];
									PersonSeat += perref + ":" + seat+",";
		
								}

								sb.append("<personseat>" +PersonSeat.substring(0,PersonSeat.length()-1)+ "</personseat>");
								sb.append("\n");
							}
						}
					}
					
			//	}
			
			
				sb.append("</ExamSeating>");
				sb.append("\n");
	
				}
			tx.commit();
			studentreg=sb.toString();
		} catch (HibernateException localException) {
			localException.printStackTrace();
			System.out.println(localException);

			sb.append("<Response>");
			sb.append("\n");
			sb.append("<Result>");
			sb.append("\n");
			sb.append("Fail");
			sb.append("\n");
			sb.append("</Result>");
			sb.append("\n");
			sb.append("<Description>");
			sb.append("could not get student info");
			sb.append("</Description>");
			sb.append("\n");
			sb.append("<Exception>");
			sb.append(localException);
			sb.append("</Exception>");
			sb.append("</Response>");

			studentreg = sb.toString();
			MDTransactionWriter.exceptionlog.info(localException);
			if (tx != null)
				tx.rollback();
		} finally {
			rdSession.close();
		}
		return studentreg;
	}
}
