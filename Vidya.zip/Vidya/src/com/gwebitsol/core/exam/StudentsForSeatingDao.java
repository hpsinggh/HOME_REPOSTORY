package com.gwebitsol.core.exam;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;
import com.gwebitsol.seater.GblClass;
import com.gwebitsol.seater.GblGenericSeater;
import com.gwebitsol.seater.GblRoom;
import com.gwebitsol.seater.GblSeatClass;
import com.gwebitsol.seater.GblSeater;

@Repository
@Component
public class StudentsForSeatingDao {

	Session rdSession = MDHibernateUtil.getSessionFactory().openSession();
	Transaction tx = null;
	StringBuffer sb = new StringBuffer();

	@SuppressWarnings("rawtypes")
	GblRoom room2 = null;
	GblClass sClass1 = null;

	public GblClass getAllStudents(int classId, List sections) {

		Integer[] studentID = null;
		try {

			tx = rdSession.beginTransaction();

			Iterator it = sections.iterator();
			String strsections = null;

			while (it.hasNext()) {
				Section rms = (Section) it.next();
				int seid = rms.getSectionId();
				strsections += seid + ",";
			}

			System.out.println(strsections);

			String strsec = strsections.substring(4, strsections.lastIndexOf(','));

			SQLQuery entList = rdSession
					.createSQLQuery("select DISTINCT StudentId from gbl_sm_tbl_student_education where ClassId='"
							+ classId + "' and SectionId in (" + strsec + ");")
					.addScalar("StudentId", Hibernate.INTEGER);

			List cssIds = entList.list();

			try {
				studentID = (Integer[]) cssIds.toArray(new Integer[cssIds.size()]);
			} catch (Exception e) {
				System.out.println(e);
			}

			sClass1 = new GblClass(classId, studentID);

		} catch (Exception localException) {
			MDTransactionWriter.exceptionlog.info(localException);
			if (tx != null)
				tx.rollback();
		} finally {
			rdSession.close();
		}
		return sClass1;
	}

	@SuppressWarnings({ "rawtypes", "unused", "deprecation" })

	public List<GblRoom> getRoomInfo(List rooms, int seatingtypeid, String aislesFlag, List<GblRoom> lsRoom) {

		Integer[] RoomNO = null;
		Integer RoomNumber = null;
		int RoomTypeId = 0;
		int NumberOfRows = 0;
		int NumberOfColumns = 0;
		int NumberOfSeatsPerRow = 0;
		int[] ColnoRowSeats = null;

		try {

			tx = rdSession.beginTransaction();

			Iterator it = rooms.iterator();
			String strrooms = null;

			while (it.hasNext()) {
				Room rms = (Room) it.next();
				int rmid = rms.getRoomId();
				strrooms += rmid + ",";
			}

			String strrms = strrooms.substring(4, strrooms.lastIndexOf(','));

			SQLQuery roomNOs = rdSession.createSQLQuery("select RoomNo from gbl_sm_tbl_room where RoomId in (" + strrms
					+ ") and SeatingTypeId='" + seatingtypeid + "'").addScalar("RoomNo", Hibernate.INTEGER);

			List entLst = roomNOs.list();

			RoomNO = (Integer[]) entLst.toArray(new Integer[entLst.size()]);

			/*
			 * Iterator gtemp = entLst.iterator();
			 * 
			 * Integer introno=0;
			 * 
			 * String strm = null; while (gtemp.hasNext()) { Object[] rno =
			 * (Object[]) gtemp.next(); RoomNumber = (Integer)rno[0]; introno =
			 * RoomNumber.intValue(); strm+= introno+"," ; } String stm =
			 * strrooms.substring(4, strm.lastIndexOf(',')); // 101,201
			 * 
			 * int[] ints = new int[stm.length()];
			 * 
			 * ints[0] = Integer.parseInt(stm);
			 * 
			 * RoomNO = new Integer[ ints[0]];
			 */

			String stquery = "select * from gbl_sm_tbl_seatingtype where SeatingTypeId ='" + seatingtypeid + "'";

			SQLQuery roominfo = rdSession.createSQLQuery(stquery).addScalar("SeatingTypeId", Hibernate.INTEGER)
					.addScalar("NumberOfRows", Hibernate.INTEGER).addScalar("NumberOfColumns", Hibernate.INTEGER)
					.addScalar("NumberOfSeatsPerRow", Hibernate.INTEGER).addScalar("ColnoRowSeats", Hibernate.STRING);

			List entList = roominfo.list();

			Iterator gtempIT = entList.iterator();

			while (gtempIT.hasNext()) {
				Object[] stu = (Object[]) gtempIT.next();
				if (stu == null) {
					System.out.println("there is no student object");
				} else {

					// RoomNO = Arrays.copyOfRange(stu, 0, 1, Integer[].class);
					RoomTypeId = (Integer) stu[0];
					NumberOfRows = (Integer) stu[1];
					NumberOfColumns = (Integer) stu[2];
					NumberOfSeatsPerRow = (Integer) stu[3];
					String adsd = (String) stu[4];

					String[] some = adsd.split(",");
					ColnoRowSeats = new int[some.length];

					for (int i = 0; i < ColnoRowSeats.length; i++) {

						ColnoRowSeats[i] = Integer.parseInt(some[i]);

					}
				}
			}
			room2 = new GblRoom(RoomNO.clone(), RoomTypeId, NumberOfRows, NumberOfColumns, NumberOfSeatsPerRow,
					aislesFlag, ColnoRowSeats);
			lsRoom.add(room2);

		} catch (Exception localException) {
			MDTransactionWriter.exceptionlog.info(localException);
			if (tx != null)
				tx.rollback();
		} finally {
			rdSession.close();
		}
		return lsRoom;

	}

}
