package com.gwebitsol.core.exam;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="AllClasses")

public class AllClasses {

	List<Classes> classes;

	public List<Classes> getClasses() {
		return classes;
	}

	public void setClasses(List<Classes> classes) {
		this.classes = classes;
	}

	
}
