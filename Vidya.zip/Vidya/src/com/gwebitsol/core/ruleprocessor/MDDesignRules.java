package com.gwebitsol.core.ruleprocessor;

public class MDDesignRules {

}
