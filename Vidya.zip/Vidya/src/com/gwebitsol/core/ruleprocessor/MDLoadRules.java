package com.gwebitsol.core.ruleprocessor;

public class MDLoadRules 
{
	public void loadRules()
	{
		/* RuleBase ruleBase = RuleBaseLoader.loadFromStream(this.getClass().getResourceAsStream( "/rules/CheeseRules.java.drl" ) );

		        WorkingMemory workingMemory = ruleBase.newWorkingMemory( );

		        //put "bob" in working memory
		        workingMemory.assertObject( bob );

		        workingMemory.fireAllRules( );*/
	}
}
