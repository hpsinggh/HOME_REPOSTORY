package com.gwebitsol.core.library;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.gwebitsol.core.security.MDValidation;
import com.gwebitsol.core.security.MDVerifyConnectionID;
import com.gwebitsol.core.security.MDVerifyDatastoreName;
import com.gwebitsol.core.usermanagement.MDGetUserFromID;
import com.gwebitsol.core.util.MDTransactionWriter;

public class CatalogueService implements CatalogueIntf {
	
	@Context 
	private HttpServletRequest hsr;
	public Response addCatalogue(CataloguePojo cps,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		 	MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
			String XMLString=null;
		    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date date = new Date();
			String startDate=dateFormat.format(date);
			Long sl=System.currentTimeMillis();
			cps.setSchoolId(schoolId);
			cps.setBranchId(branchId);
			  try
			  {
			   MDValidation mdv = new MDValidation();  
			   int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			   System.out.println("verifiedvalue::"+ret);
			   MDGetUserFromID mdgufid = new MDGetUserFromID();
				String requester = mdgufid.getUserName(userID);
			   
			   if(ret==1 )//&& rtVal==1)
			   {
					String endDate=dateFormat.format(new Date());
					Long el=System.currentTimeMillis();
					CatalogueDao cdao=new CatalogueDao();
					XMLString=cdao.addCatalogue(cps);
					System.out.println(XMLString);
					MDTransactionWriter.writeLog(datastoreName,"CataloguePojo_addCatalogue",requester,startDate,endDate,sl,el,XMLString,hsr.getRemoteHost());
				}
				else
				{
					XMLString="you are not authorised user";
				}
			}
			catch(Exception localException)
			{
				MDTransactionWriter.errorlog.debug(localException);
				MDTransactionWriter.errorlog.info(localException);
			   XMLString="failed in service layer";
			}
		
			return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	
	}

	public Response updateCatalogue(CataloguePojo cps,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String XMLString=null;
	    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		cps.setSchoolId(schoolId);
		cps.setBranchId(branchId);
		 try
		  {
		   MDValidation mdv = new MDValidation();  
		   int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
		   System.out.println("verifiedvalue::"+ret);
		   MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userID);
		   if(ret==1 )//&& rtVal==1)
		   {
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				CatalogueDao cdao=new CatalogueDao();
				XMLString=cdao.updateCatalogue(cps,schoolId,branchId);
				System.out.println(XMLString);
				MDTransactionWriter.writeLog(datastoreName,"CataloguePojo_updateCatalogue",requester,startDate,endDate,sl,el,XMLString,hsr.getRemoteHost());
			}
			else
			{
			XMLString="you are not authorised user";
			}
		}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
		   XMLString="failed in service layer";
		}
	
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}

	public Response deleteCatalogue(int bookId,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		@SuppressWarnings("unused")
		String XMLString=null;

		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		
		 try
		  {
		   MDValidation mdv = new MDValidation();  
		   int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
		   System.out.println("verifiedvalue::"+ret);
		   MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userID);
		   if(ret==1 )//&& rtVal==1)
		   {
				CatalogueDao brdao=new CatalogueDao();
				status=brdao.deleteCatalogue(bookId,schoolId,branchId);
		
				String endDate=dateFormat.format(new Date());	
				Long el=System.currentTimeMillis();
		
				MDTransactionWriter.writeLog(datastoreName,"CataloguePojo_deleteCatalogue",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
			}
			else
			{
				XMLString="you are not authorised user";
			}
		}
		catch(Exception localException)
		{
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
		status="failed in service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();	
	}

		public Response getByIdCatalogue(int bookId,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
			MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
			@SuppressWarnings("unused")
			String XMLString=null;

			String status1=null;
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date date = new Date();
			String startDate=dateFormat.format(date);
			Long sl=System.currentTimeMillis();
			 try
			  {
			   MDValidation mdv = new MDValidation();  
			   int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			   System.out.println("verifiedvalue::"+ret);
			   MDGetUserFromID mdgufid = new MDGetUserFromID();
				String requester = mdgufid.getUserName(userID);
			   if(ret==1 )//&& rtVal==1)
			   {
			CatalogueDao ex=new CatalogueDao();
			 status1=ex.getByIdCatalogue(bookId,schoolId,branchId);
			 System.out.println(status1);
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			
			MDTransactionWriter.writeLog(datastoreName,"CataloguePojo_getByIdCatalogue",requester,startDate,endDate,sl,el,status1,hsr.getRemoteHost());		
			}
			else
			{
				XMLString="you are not authorised user";
			}
		}
		catch(Exception localException)
		{
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
		status1="failed in service layer";
		//System.out.println(localException);
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status1).build();
	}

	public Response getAllCatalogue(int userID, int connectionID,String datastoreName,int PNO,int size,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());					
		@SuppressWarnings("unused")
		String XMLString=null;

		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		 try
		  {
		   MDValidation mdv = new MDValidation();  
		   int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
		   System.out.println("verifiedvalue::"+ret);
		   MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userID);
		   if(ret==1 )//&& rtVal==1)
		   {
			CatalogueDao ex=new CatalogueDao();
			status=ex.getAllCatalogue(PNO,size,schoolId,branchId);
			System.out.println(status);
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			MDTransactionWriter.writeLog(datastoreName,"CataloguePojo_getAllCatalogue",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		

			}
			else
			{
				XMLString="you are not authorised user";
			}
		}
		catch(Exception localException)
		   {
			  MDTransactionWriter.errorlog.debug(localException);
			  MDTransactionWriter.errorlog.info(localException);
			  status="failed in service layer";
		   }
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}
}


