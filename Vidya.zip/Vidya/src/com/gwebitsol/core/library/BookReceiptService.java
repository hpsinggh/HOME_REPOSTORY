package com.gwebitsol.core.library;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.gwebitsol.core.security.MDValidation;
import com.gwebitsol.core.usermanagement.MDGetUserFromID;
import com.gwebitsol.core.util.MDTransactionWriter;

public class BookReceiptService implements BookReceiptIntf {
	@Context 
	private HttpServletRequest hsr;
	 public Response addBookReceipt(BookReceiptPojo brp,int userID, int connectionID,String datastoreName,int schoolId,int branchId){
		 MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
			String XMLString=null;
		    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date date = new Date();
			String startDate=dateFormat.format(date);
			Long sl=System.currentTimeMillis();
			brp.setSchoolId(schoolId);
			brp.setBranchId(branchId);
			  try
			  {
			   MDValidation mdv = new MDValidation();  
			   int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			   System.out.println("verifiedvalue::"+ret);
			   MDGetUserFromID mdgufid = new MDGetUserFromID();
				String requester = mdgufid.getUserName(userID);
			   if(ret==1 )//&& rtVal==1)
			   {
					String endDate=dateFormat.format(new Date());
					Long el=System.currentTimeMillis();
					BookReceiptDao brdao=new BookReceiptDao();
					XMLString=brdao.addBookReceipt(brp);
					System.out.println(XMLString);
					MDTransactionWriter.writeLog(datastoreName,"BookReceiptPojo_addBookReceipt",requester,startDate,endDate,sl,el,XMLString,hsr.getRemoteHost());
				}
				else
				{
					XMLString="you are not authorised user";
				}
			}
			catch(Exception localException)
			{
				MDTransactionWriter.errorlog.debug(localException);
				MDTransactionWriter.errorlog.info(localException);
			   XMLString="failed in service layer";
			}
		
			return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();		
	 }
	public Response updateBookReceipt(BookReceiptPojo brp,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String XMLString=null;
	    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		brp.setSchoolId(schoolId);
		brp.setBranchId(branchId);
		 try
		  {
		   MDValidation mdv = new MDValidation();  
		   int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
		   System.out.println("verifiedvalue::"+ret);
		   MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userID);
		   if(ret==1 )//&& rtVal==1)
		   {
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				BookReceiptDao brdao=new BookReceiptDao();
				XMLString=brdao.updateBookReceipt(brp,schoolId,branchId);
				System.out.println(XMLString);
				MDTransactionWriter.writeLog(datastoreName,"BookReceiptPojo_updateBookReceipt",requester,startDate,endDate,sl,el,XMLString,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}
			
		}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
		   XMLString="failed in service layer";
		}
	
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
}
	public Response deleteBookReceipt(int bookReceiptId,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		@SuppressWarnings("unused")
		String XMLString=null;
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		
		 try
		  {
		   MDValidation mdv = new MDValidation();  
		   int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
		   System.out.println("verifiedvalue::"+ret);
		   MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userID);
		   if(ret==1 )//&& rtVal==1)
		   {
			BookReceiptDao brdao=new BookReceiptDao();
			status=brdao.deleteBookReceipt(bookReceiptId,schoolId,branchId);
			
			String endDate=dateFormat.format(new Date());	
			Long el=System.currentTimeMillis();
			
				MDTransactionWriter.writeLog(datastoreName,"BookReceiptPojo_deleteBookReceipt",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
			}
			else
			{
				XMLString="you are not authorised user";
			}
			
		}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			status="failed in service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();	
}
	public Response getByIdBookReceipt(int bookReceiptId,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		@SuppressWarnings("unused")
		String XMLString=null;
		String status1=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();

		 try
		  {
		   MDValidation mdv = new MDValidation();  
		   int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
		   System.out.println("verifiedvalue::"+ret);
		   MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userID);
		   if(ret==1 )//&& rtVal==1)
		   {
			BookReceiptDao ex=new BookReceiptDao();
			 status1=ex.getByIdBookReceipt(bookReceiptId,schoolId,branchId);
			 System.out.println(status1);
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			//status1="user validation successfull";
			MDTransactionWriter.writeLog(datastoreName,"BookReceiptPojo_getByIdBookReceipt",requester,startDate,endDate,sl,el,status1,hsr.getRemoteHost());		
			}
			else
			{
				XMLString="you are not authorised user";
			}
			
		}
	catch(Exception localException)
	{
		MDTransactionWriter.errorlog.debug(localException);
		MDTransactionWriter.errorlog.info(localException);
		status1="failed in service layer";
		//System.out.println(localException);
	}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status1).build();
}
	public Response getAllBookReceipt(int userid, int connectionid,String datastoreName,int PNO,int size,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		
		@SuppressWarnings("unused")
		String XMLString=null;
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		try{
			MDValidation mdv = new MDValidation();  
			   int ret =mdv.allvalidations(userid, connectionid, datastoreName, schoolId,branchId);
			   
			   System.out.println("verifiedvalue::"+ret);
			   MDGetUserFromID mdgufid = new MDGetUserFromID();
				String requester = mdgufid.getUserName(userid);
			if(ret==1 )//&& rtVal==1)
			{
			BookReceiptDao ex=new BookReceiptDao();
			status=ex.getAllBookReceipt(PNO,size,schoolId,branchId);
			System.out.println(status);
			String endDate=dateFormat.format(new Date());
			  Long el=System.currentTimeMillis();
			 MDTransactionWriter.writeLog(datastoreName,"BookReceiptPojo_getAllBookReceipt",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		

			}
			else
			{
				XMLString="you are not authorised user";
			}
			
		}	
			catch(Exception localException)
		   {
			  MDTransactionWriter.errorlog.debug(localException);
			  MDTransactionWriter.errorlog.info(localException);
			  status="failed in service layer";
		   }
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}
}
