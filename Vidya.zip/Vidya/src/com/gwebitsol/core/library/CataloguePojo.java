package com.gwebitsol.core.library;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="Catalogue")
public class CataloguePojo {
	private int 	bookId;
	private String 	catalogueName;
	private int 	bookNo;
	private String 	bookTitle;
	private String 	author;
	private String 	description;
	private int 	ISBN;
	private int 	barcode;
	private String 	publisher;
	private int 	volume;
	private String 	publisheDate;
	private String 	printer;
	private String 	typeSetter;
	private int 	bookTypeId;
	private int 	libSectionId;
	private int 	rackNo;
	private int 	rowNo;
	private int 	orderNo;
	private int 	quantity;
	private int 	bookCost;
	private int 	libSubjectId;
	private String 	isIssue;
	private int bookReceiptId;
	private byte[] image;
	private String 	createdDate;
	
	DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	 Date date = new Date();
	 String modifiedDate=dateFormat.format(date);
	
		private int schoolId;
		private int branchId;
	 public int getSchoolId() {
			return schoolId;
		}
		public void setSchoolId(int schoolId) {
			this.schoolId = schoolId;
		}
		public int getBranchId() {
			return branchId;
		}
		public void setBranchId(int branchId) {
			this.branchId = branchId;
		}
	public int getBookReceiptId() {
		return bookReceiptId;
	}
	public void setBookReceiptId(int bookReceiptId) {
		this.bookReceiptId = bookReceiptId;
	}
	
	public String getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public String getCatalogueName() {
		return catalogueName;
	}
	public void setCatalogueName(String catalogueName) {
		this.catalogueName = catalogueName;
	}
	public int getBookNo() {
		return bookNo;
	}
	public void setBookNo(int bookNo) {
		this.bookNo = bookNo;
	}
	public String getBookTitle() {
		return bookTitle;
	}
	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getISBN() {
		return ISBN;
	}
	public void setISBN(int iSBN) {
		ISBN = iSBN;
	}
	public int getBarcode() {
		return barcode;
	}
	public void setBarcode(int barcode) {
		this.barcode = barcode;
	}
	public String getPublisher() {
		return publisher;
	}
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	public int getVolume() {
		return volume;
	}
	public void setVolume(int volume) {
		this.volume = volume;
	}
	
	public String getPrinter() {
		return printer;
	}
	
	public String getPublisheDate() {
		return publisheDate;
	}
	public void setPublisheDate(String publisheDate) {
		this.publisheDate = publisheDate;
	}
	public DateFormat getDateFormat() {
		return dateFormat;
	}
	public void setDateFormat(DateFormat dateFormat) {
		this.dateFormat = dateFormat;
	}
	public void setPrinter(String printer) {
		this.printer = printer;
	}
	public String getTypeSetter() {
		return typeSetter;
	}
	public void setTypeSetter(String typeSetter) {
		this.typeSetter = typeSetter;
	}
	public int getBookTypeId() {
		return bookTypeId;
	}
	public void setBookTypeId(int bookTypeId) {
		this.bookTypeId = bookTypeId;
	}
	public int getLibSectionId() {
		return libSectionId;
	}
	public void setLibSectionId(int libSectionId) {
		this.libSectionId = libSectionId;
	}
	public int getRackNo() {
		return rackNo;
	}
	public void setRackNo(int rackNo) {
		this.rackNo = rackNo;
	}
	public int getRowNo() {
		return rowNo;
	}
	public void setRowNo(int rowNo) {
		this.rowNo = rowNo;
	}
	public int getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(int orderNo) {
		this.orderNo = orderNo;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getBookCost() {
		return bookCost;
	}
	public void setBookCost(int bookCost) {
		this.bookCost = bookCost;
	}
	public int getLibSubjectId() {
		return libSubjectId;
	}
	public void setLibSubjectId(int libSubjectId) {
		this.libSubjectId = libSubjectId;
	}
	public String getIsIssue() {
		return isIssue;
	}
	public void setIsIssue(String isIssue) {
		this.isIssue = isIssue;
	}
	
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public byte[] getImage() {
		return image;
	}
	public void setImage(byte[] image) {
		this.image = image;
	}
	
}
