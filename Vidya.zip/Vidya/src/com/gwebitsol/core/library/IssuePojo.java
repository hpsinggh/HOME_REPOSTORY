package com.gwebitsol.core.library;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.stereotype.Component;

@XmlRootElement(name="Issue")
@Component
public class IssuePojo {
	private int 	issueId;
	private int 	bookId;
	private String 	employeeId;
	private String 	studentId;
	/*private int employeeId;
	private int	studentId;*/
	private String 	issuedDate;
	private String 	returnDate;
	private String 	returnedOn;
	private int 	lateFee;
	private String 	isFeeCollected;
	private String 	isLost;
	private String 	isDamaged;
	private int 	recoveredCost;
	private int 	issuedBy;
	private String 	createdDate;
	DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	 Date date = new Date();
	 String modifiedDate=dateFormat.format(date);
	
		private int schoolId;
		private int branchId;
		public int getSchoolId() {
			return schoolId;
		}
		public void setSchoolId(int schoolId) {
			this.schoolId = schoolId;
		}
		public int getBranchId() {
			return branchId;
		}
		public void setBranchId(int branchId) {
			this.branchId = branchId;
		}
	
	public String getCreatedDate() {
			return createdDate;
		}
		public void setCreatedDate(String createdDate) {
			this.createdDate = createdDate;
		}
		public String getModifiedDate() {
			return modifiedDate;
		}
		public void setModifiedDate(String modifiedDate) {
			this.modifiedDate = modifiedDate;
		}
	public int getIssueId() {
		return issueId;
	}
	public void setIssueId(int issueId) {
		this.issueId = issueId;
	}
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getStudentId() {
		return studentId;
	}
	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}
	public String getIssuedDate() {
		return issuedDate;
	}
	public void setIssuedDate(String issuedDate) {
		this.issuedDate = issuedDate;
	}
	public String getReturnDate() {
		return returnDate;
	}
	public void setReturnDate(String returnDate) {
		this.returnDate = returnDate;
	}
	public String getReturnedOn() {
		return returnedOn;
	}
	public void setReturnedOn(String returnedOn) {
		this.returnedOn = returnedOn;
	}
	public int getLateFee() {
		return lateFee;
	}
	public void setLateFee(int lateFee) {
		this.lateFee = lateFee;
	}
	public String getIsFeeCollected() {
		return isFeeCollected;
	}
	public void setIsFeeCollected(String isFeeCollected) {
		this.isFeeCollected = isFeeCollected;
	}
	public String getIsLost() {
		return isLost;
	}
	public void setIsLost(String isLost) {
		this.isLost = isLost;
	}
	public String getIsDamaged() {
		return isDamaged;
	}
	public void setIsDamaged(String isDamaged) {
		this.isDamaged = isDamaged;
	}
	public int getRecoveredCost() {
		return recoveredCost;
	}
	public void setRecoveredCost(int recoveredCost) {
		this.recoveredCost = recoveredCost;
	}
	public int getIssuedBy() {
		return issuedBy;
	}
	public void setIssuedBy(int issuedBy) {
		this.issuedBy = issuedBy;
	}
	/*public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}*/
	

}
