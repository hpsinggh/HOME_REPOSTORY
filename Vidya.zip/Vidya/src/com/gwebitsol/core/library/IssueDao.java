
package com.gwebitsol.core.library;


import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.employeemanagement.MDEmployeePOJO;
import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class IssueDao {
	
	public String addIssues(IssuePojo ip) {
		Session addempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction addempTx=null;
		StringBuffer sb=new StringBuffer();

		String outStr=null;
		try
		{
			addempTx=addempSession.beginTransaction();
	        Integer in=(Integer)addempSession.save(ip);
			System.out.println(in);
			
			addempTx.commit();
			
			sb.append("<Issue>");
			sb.append("\n");
			sb.append("<IssueId>");
			sb.append(in);
			sb.append("</IssueId>");
			sb.append("</Issue>");
			String str=sb.toString();
			return str;
		   
   		 	}
		
		catch(Exception localException)
		{
			System.out.println(localException);
			
			localException.printStackTrace();  
			sb.append("<Response>");
	       sb.append("\n");
	       sb.append("<Result>");
	       sb.append("\n");
	       sb.append("Fail");
	       sb.append("\n");
	       sb.append("</Result>");
	       sb.append("\n");
	       sb.append("<Description>");
	       
	       sb.append("could not inserted Issue info");
	       sb.append("</Description>");
	       sb.append("\n");
	       sb.append("<Exception>");
	       sb.append(localException);
	       sb.append("</Exception>");
	       sb.append("</Response>");
	       outStr= sb.toString();
	      MDTransactionWriter.exceptionlog.info(localException);
	     if (addempTx!=null)
	      addempTx.rollback();
		}
		finally
		{			
			addempSession.close();
		}
		return outStr;
		}

	public String updateIssues(IssuePojo ip,int schoolId,int branchId) {
		Session upempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction upempTx=null;
		StringBuffer sb=new StringBuffer();

		String outStr=null;
		try
		{
			upempTx=upempSession.beginTransaction();
			IssuePojo issue = (IssuePojo) upempSession.get(IssuePojo.class,ip.getIssueId());
		      
			   if(branchId==issue.getBranchId()&&schoolId==issue.getSchoolId())
			       
			    upempSession.evict(issue);
			 upempSession.update(ip);
				
				upempTx.commit();
				
				sb.append("<Issue>");
				sb.append("\n");
				sb.append("update successfully");
				sb.append("</Issue>");
				String str=sb.toString();
				return str;
			   
	   		 	}
			
			catch(Exception localException)
			{
				System.out.println(localException);
				
				localException.printStackTrace();  
				sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not update Issue info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       outStr= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (upempTx!=null)
		    	 upempTx.rollback();
			}
			finally
			{			
				upempSession.close();
			}
			return outStr;
	}

	public String deleteIssues(int issueId,int schoolId,int branchId) {
		Session delempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction delempTx=null;
		StringBuffer sb=new StringBuffer();

		String outStr=null;
		try
		{
			delempTx=delempSession.beginTransaction();
			IssuePojo mdclpojo = (IssuePojo) delempSession.get(IssuePojo.class,issueId);
			   
			   int branid = mdclpojo.getBranchId();
			   int sclid = mdclpojo.getSchoolId();
			   delempSession.evict(mdclpojo);          
			   if(branchId==branid&&schoolId==sclid) 
			   {  
				   Query empQuery=delempSession.createSQLQuery("update gbl_sm_tbl_issues set isDeleted='y' where issueId='"+issueId+"'");
				   empQuery.executeUpdate();
			
				   delempTx.commit();
				
				   sb.append("<Issue>");
				   sb.append("\n");
				   sb.append("delete successfully");
				   sb.append("</Issue>");
				   String str=sb.toString();
				   return str;
	   		 	}
		}
			catch(Exception localException)
			{
			   System.out.println(localException);				
			   localException.printStackTrace();  
			   sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");		       
		       sb.append("could not delete Issue info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       outStr= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (delempTx!=null)
		    	 delempTx.rollback();

			}
			finally
			{			
				delempSession.close();
			}
			return outStr;
	}

	

	@SuppressWarnings("rawtypes")
	public String getByIdIssue(int issueId,int schoolId,int branchId) {
		Session gtempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gtempTx=null;
		StringBuffer sb=new StringBuffer();
		String strg= null;
		try {
			gtempTx = gtempSession.beginTransaction();
			List list = gtempSession.createSQLQuery(
					"select iss.IssueId,iss.BookId,ct.CatalogueName,iss.EmployeeId,st.StaffNumber,st.FirstName,st.LastName,iss.StudentId,iss.IssuedDate,iss.ReturnDate,iss.ReturnedOn,iss.LateFee,iss.IsFeeCollected,iss.IsLost,iss.IsDamaged,iss.RecoveredCost,iss.IssuedBy,iss.SchoolId,iss.BranchId from  gbl_sm_tbl_issues as iss join gbl_sm_tbl_catalogue as ct on iss.BookId=ct.BookId left join gbl_sm_tbl_staff as st on iss.EmployeeId=st.EmployeeId where iss.issueId='" + issueId + "' and iss.SchoolId='" + schoolId + "' and iss.BranchId='" + branchId + "' and iss.IsDeleted Is Null;").list();
			Iterator it = list.iterator();
			sb.append("<Issue>");
			while (it.hasNext()) {
						Object[] ex=(Object[])it.next();
				        sb.append("\n");
				        sb.append("<issueId>");
					    sb.append(ex[0]);
					    sb.append("</issueId>");
					    sb.append("\n");
					    sb.append("<bookId>");
						sb.append(ex[1]);
						sb.append("</bookId>");
						sb.append("\n");
						sb.append("<catalogueName>");
					    sb.append(ex[2]);
					    sb.append("</catalogueName>");
					    sb.append("\n");
				        sb.append("<employeeId>");
					    sb.append(ex[3]);
					    sb.append("</employeeId>");
					    sb.append("\n");
					    sb.append("<staffNumber>");
					    sb.append(ex[4]);
					    sb.append("</staffNumber>");
					    sb.append("\n");
					    sb.append("<firstName>");
					    sb.append(ex[5]);
					    sb.append("</firstName>");
					    sb.append("\n");
					    sb.append("<lastName>");
					    sb.append(ex[6]);
					    sb.append("</lastName>");
					    sb.append("\n");
					    
					    String studentId=(String)ex[7];
				         sb.append("<studentId>" +studentId+ "</studentId>");
				         sb.append("\n");
				         if(studentId!=null)
				         {
				       String  gsSql="select stu.StudentId,stu.StudentNumber,stu.FirstName,stu.MiddleName,stu.LastName from gbl_sm_tbl_student as stu where (stu.isDeleted<>'y' or  stu.isDeleted is null) and stu.StudentId='"+studentId+"'";
				      Query   gsQuery = gtempSession.createSQLQuery(gsSql);
				     List parList1 = gsQuery.list();
				     Iterator paIT = parList1.iterator();
				      //sb.append("<studentDetails>");
				      //sb.append("\n");
				     while (paIT.hasNext()) {
				      Object[] paArr = (Object[]) paIT.next();
				      //sb.append("<student>");
				      //sb.append("\n");
				      //sb.append("<studentId>" + paArr[0] + "</studentId>");
				      //sb.append("\n");
				      sb.append("<studentnumber>"+paArr[1]+"</studentnumber>");
				      sb.append("\n");
				      sb.append("<studentfirstName>" + paArr[2] + "</studentfirstName>");
				      sb.append("\n");
				      sb.append("<studentmiddleName>" + paArr[3] + "</studentmiddleName>");
				      sb.append("\n");
				      sb.append("<studentlastName>" + paArr[4] + "</studentlastName>");
				      sb.append("\n");      
				     }
				         }else{
				          sb.append("<studentnumber></studentnumber>");
				      sb.append("\n");
				      sb.append("<studentfirstName></studentfirstName>");
				      sb.append("\n");
				      sb.append("<studentmiddleName></studentmiddleName>");
				      sb.append("\n");
				      sb.append("<studentlastName></studentlastName>");
				      sb.append("\n");
				         }
					    
						
						
						sb.append("<issuedDate>");
					    sb.append(ex[8]);
					    sb.append("</issuedDate>");
					    sb.append("\n");
					    sb.append("<returnDate>");
						sb.append(ex[9]);
						sb.append("</returnDate>");
						sb.append("\n");
				        sb.append("<returnedOn>");
					    sb.append(ex[10]);
					    sb.append("</returnedOn>");
					    sb.append("\n");
					    sb.append("<lateFee>");
						sb.append(ex[11]);
						sb.append("</lateFee>");
						sb.append("\n");
						sb.append("<isFeeCollected>");
					    sb.append(ex[12]);
					    sb.append("</isFeeCollected>");
					    sb.append("\n");
					    sb.append("<isLost>");
						sb.append(ex[13]);
						sb.append("</isLost>");
						sb.append("\n");
				        sb.append("<isDamaged>");
					    sb.append(ex[14]);
					    sb.append("</isDamaged>");
					    sb.append("\n");
					    sb.append("<recoveredCost>");
						sb.append(ex[15]);
						sb.append("</recoveredCost>");
						sb.append("\n");
						sb.append("<IssuedBy>");
						sb.append(ex[16]);
						sb.append("</IssuedBy>");
						sb.append("\n");
						sb.append("<schoolId>");
				        sb.append(ex[17]);
				        sb.append("</schoolId>");
				        sb.append("\n");
				        sb.append("<branchId>");
				        sb.append(ex[18]);
				        sb.append("</branchId>");
				        sb.append("\n");
						
					}
					
					sb.append("</Issue>");
					strg=sb.toString(); 
					 
					gtempTx.commit();
					 
					
			} 	catch (Exception localException) {
				System.out.println(localException);
				
				localException.printStackTrace();  
				sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not get Issue info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       strg= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (gtempTx!=null)
		    	 gtempTx.rollback();
				} finally {
					gtempSession.close();
				}
		return strg;
	}

	@SuppressWarnings({ "rawtypes" })
	public String getAllIssues(int PNO, int size,int schoolId,int branchId) {
		Session rdSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb= new StringBuffer();
		String string=null;
		try
		{
			tx = rdSession.beginTransaction();
			int fset = (PNO-1)*size;
			String gsSql ="select count(*) from gbl_sm_tbl_issues where isDeleted is null and schoolId="+schoolId+" and branchId="+branchId+"";
			Query gsQuery=rdSession.createSQLQuery(gsSql);
			Object noRecords= gsQuery.uniqueResult();
			int intNoRecords=0;
			if(noRecords!=null && Integer.parseInt(noRecords.toString())!=0)
			{
				intNoRecords=Integer.parseInt(noRecords.toString());
			}
			sb.append("<Issues>");
			sb.append("\n");
			sb.append("<noRecords>"+intNoRecords+"</noRecords>");
			sb.append("\n");
			if(intNoRecords!=0)
			{
			 if (PNO > 0 & size > 0){
			 gsSql="select iss.IssueId,iss.BookId,ct.CatalogueName,iss.EmployeeId,st.StaffNumber,st.FirstName,st.LastName, iss.StudentId,iss.IssuedDate,iss.ReturnDate,iss.ReturnedOn,iss.LateFee, iss.IsFeeCollected,iss.IsLost,iss.IsDamaged,iss.RecoveredCost,iss.IssuedBy,iss.SchoolId,iss.BranchId from  gbl_sm_tbl_issues as iss  join gbl_sm_tbl_catalogue as ct on iss.BookId=ct.BookId left join gbl_sm_tbl_staff as st on iss.EmployeeId=st.EmployeeId  where iss.SchoolId='" + schoolId + "' and iss.BranchId='" + branchId + "' and iss.IsDeleted Is Null limit "+size+" offset "+fset;}
			 else {
			  gsSql="select iss.IssueId,iss.BookId,ct.CatalogueName,iss.EmployeeId,st.StaffNumber,st.FirstName,st.LastName, iss.StudentId,iss.IssuedDate,iss.ReturnDate,iss.ReturnedOn,iss.LateFee, iss.IsFeeCollected,iss.IsLost,iss.IsDamaged,iss.RecoveredCost,iss.IssuedBy,iss.SchoolId,iss.BranchId from  gbl_sm_tbl_issues as iss  join gbl_sm_tbl_catalogue as ct on iss.BookId=ct.BookId left join gbl_sm_tbl_staff as st on iss.EmployeeId=st.EmployeeId  where iss.SchoolId='" + schoolId + "' and iss.BranchId='" + branchId + "' and iss.IsDeleted Is Null";
			 } 
   
			gsQuery=rdSession.createSQLQuery(gsSql);
			List gcList=gsQuery.list();
			Iterator gsIT=gcList.iterator();
			//String[] st;
			 while(gsIT.hasNext())
			 {
				
			  Object[] mdcArr=(Object[])gsIT.next();
			  
			  sb.append("<Issue>");
			  sb.append("\n");
			  sb.append("<issueId>"+mdcArr[0]+"</issueId>");
			  sb.append("\n");
			  sb.append("<bookId>" + mdcArr[1]+ "</bookId>");
			  sb.append("\n");
			  sb.append("<catalogueName>" + mdcArr[2] + "</catalogueName>");
			  sb.append("\n");
			  sb.append("<employeeId>" + mdcArr[3]+ "</employeeId>");
			  sb.append("\n");
			  sb.append("<staffNumber>" + mdcArr[4]+ "</staffNumber>");
			  sb.append("\n");
			  sb.append("<firstName>" + mdcArr[5]+ "</firstName>");
			  sb.append("\n");
			  sb.append("<lastName>" + mdcArr[6] + "</lastName>");
			  sb.append("\n");
			  /*sb.append("<studentId>" + mdcArr[7] + "</studentId>");
			  sb.append("\n");*/
			  String studentId=(String)mdcArr[7];
		         sb.append("<studentId>" +studentId+ "</studentId>");
		         sb.append("\n");
		         if(studentId!=null)
		         {
		         gsSql="select stu.StudentId,stu.StudentNumber,stu.FirstName,stu.MiddleName,stu.LastName from gbl_sm_tbl_student as stu where (stu.isDeleted<>'y' or  stu.isDeleted is null) and stu.StudentId='"+studentId+"'";
		         gsQuery = rdSession.createSQLQuery(gsSql);
		     List parList1 = gsQuery.list();
		     Iterator paIT = parList1.iterator();
		      //sb.append("<studentDetails>");
		      //sb.append("\n");
		     while (paIT.hasNext()) {
		      Object[] paArr = (Object[]) paIT.next();
		      //sb.append("<student>");
		      //sb.append("\n");
		      //sb.append("<studentId>" + paArr[0] + "</studentId>");
		      //sb.append("\n");
		      sb.append("<studentnumber>"+paArr[1]+"</studentnumber>");
		      sb.append("\n");
		      sb.append("<studentfirstName>" + paArr[2] + "</studentfirstName>");
		      sb.append("\n");
		      sb.append("<studentmiddleName>" + paArr[3] + "</studentmiddleName>");
		      sb.append("\n");
		      sb.append("<studentlastName>" + paArr[4] + "</studentlastName>");
		      sb.append("\n");      
		     }
		         }else{
		          sb.append("<studentnumber></studentnumber>");
		      sb.append("\n");
		      sb.append("<studentfirstName></studentfirstName>");
		      sb.append("\n");
		      sb.append("<studentmiddleName></studentmiddleName>");
		      sb.append("\n");
		      sb.append("<studentlastName></studentlastName>");
		      sb.append("\n");
		         }
			  /*sb.append("<studentNumber>" + mdcArr[8] + "</studentNumber>");
			  sb.append("\n");
			  sb.append("<StudentfirstName>" + mdcArr[9]+ "</StudentfirstName>");
			  sb.append("\n");
			  sb.append("<StudentlastName>" + mdcArr[10] + "</StudentlastName>");
			  sb.append("\n");*/
			  sb.append("<issuedDate>"+mdcArr[8]+"</issuedDate>");
			  sb.append("\n");
			  sb.append("<returnDate>" + mdcArr[9]+ "</returnDate>");
			  sb.append("\n");
			  sb.append("<returnedOn>" + mdcArr[10]+ "</returnedOn>");
			  sb.append("\n");
			  sb.append("<lateFee>" + mdcArr[11] + "</lateFee>");
			  sb.append("\n");
			  
			  sb.append("<isFeeCollected>"+mdcArr[12]+"</isFeeCollected>");
			  sb.append("\n");
			  sb.append("<isLost>" + mdcArr[13]+ "</isLost>");
			  sb.append("\n");
			  sb.append("<isDamaged>" + mdcArr[14]+ "</isDamaged>");
			  sb.append("\n");
			  sb.append("<recoveredCost>" + mdcArr[15] + "</recoveredCost>");
			  sb.append("\n");
			  
			  sb.append("<issuedBy>"+mdcArr[16]+"</issuedBy>");
			  sb.append("\n");
			  sb.append("<schoolId>" + mdcArr[17]+ "</schoolId>");
			  sb.append("\n");
			  sb.append("<branchId>" + mdcArr[18]+ "</branchId>");
			  sb.append("\n");
			  sb.append("</Issue>");
			  sb.append("\n");
			 }
			}
			 tx.commit();
			sb.append("</Issues>");
			sb.append("\n");

			string=sb.toString();
			   
			  } 
			  catch(Exception localException)
			  {
				  tx.rollback();
			   localException.printStackTrace();
			   string = "fail";
			   System.out.println("Could not Get Issues");
			  }
			  finally
			  {
			   rdSession.close();
			  } 
			  return string;

			 }

	
	@SuppressWarnings({ "rawtypes" })
	public String updateReturns(int IssueId,int schoolId,int branchId)
	{
		Session sempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction spempTx=null;
		StringBuffer sb=new StringBuffer();

		String outStr=null;
		try
		{

			spempTx=sempSession.beginTransaction();
			List list=sempSession.createSQLQuery("select * from gbl_sm_tbl_issues where IssueId like '"+IssueId+"';").list();
			Iterator it=list.iterator();
			sb.append("<Issue>");
			sb.append("\n");
			while(it.hasNext()){
				Object[] ex=(Object[])it.next();
				sb.append("<issueId>");
			    sb.append(ex[0]);
			    sb.append("</issueId>");
			    sb.append("\n");
			    sb.append("<bookId>");
			    sb.append(ex[1]);
			    sb.append("</bookId>");
			    sb.append("\n");
			    sb.append("<employeeId>");
				sb.append(ex[2]);
				sb.append("</employeeId>");
				 sb.append("\n");
				sb.append("<studentId>");
				sb.append(ex[3]);
				sb.append("</studentId>");
				sb.append("\n");
			   
				sb.append("<issuedDate>");
				sb.append(ex[4]);
				sb.append("</issuedDate>");
				sb.append("\n");
				sb.append("<returnDate>");
				sb.append(ex[5]);
				sb.append("</returnDate>");
				sb.append("\n");
				sb.append("<returnedOn>");
				sb.append(ex[6]);
				sb.append("</returnedOn>");
				sb.append("\n");
				sb.append("<isFeeCollected>");
				sb.append(ex[7]);
			 sb.append("</isFeeCollected>");
			 sb.append("\n");
			 sb.append("<isLost>");
			 sb.append(ex[8]);
			 sb.append("</isLost>");
			 sb.append("\n");
			 sb.append("<issuedBy>");
			 sb.append(ex[9]);
			 sb.append("</issuedBy>");
			 sb.append("\n");
			 sb.append("<isDamaged>");
			 sb.append(ex[10]);
			 sb.append("</isDamaged>");
			 sb.append("\n");
			 sb.append("<recoveredCost>");
			 sb.append(ex[11]);
			 sb.append("</recoveredCost>");
			 sb.append("\n");
			 sb.append("<lateFee>");
			 sb.append(ex[12]);
			 sb.append("</lateFee>");
			 sb.append("\n");
			 
			}
			 sb.append("</Issue>");
			 outStr=sb.toString(); 
			 
			 spempTx.commit();
			 
		}
		
			catch(Exception localException)
			{
				System.out.println(localException);
				
				localException.printStackTrace();  
				sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not update Issue info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       outStr= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (spempTx!=null)
		    	 spempTx.rollback();		}
			finally
			{			
				sempSession.close();
			}
			return outStr;
	
	}

	public String updateReturnlist(IssuePojo ip, int schoolId, int branchId) {
		Session upempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction upempTx=null;
		StringBuffer sb=new StringBuffer();

		String outStr=null;
		try
		{
			upempTx=upempSession.beginTransaction();
			IssuePojo issue = (IssuePojo) upempSession.get(IssuePojo.class,ip.getIssueId());
		      
			   if(branchId==issue.getBranchId()&&schoolId==issue.getSchoolId())
			       
			    upempSession.evict(issue);
			  int issueid=(Integer)upempSession.createSQLQuery("select issueid from gbl_sm_tbl_issues where issueid='"+ip.getIssueId()+"'").uniqueResult();
			  IssuePojo ipojo=(IssuePojo)upempSession.load(IssuePojo.class,issueid);
			  ipojo.setBookId(ip.getBookId());
			  ipojo.setEmployeeId(ip.getEmployeeId());
			  ipojo.setStudentId(ip.getStudentId());
			  ipojo.setIssuedDate(ip.getIssuedDate());
			  ipojo.setReturnDate(ip.getReturnDate());
			  ipojo.setReturnedOn(ip.getReturnedOn());
			  ipojo.setIsDamaged(ip.getIsDamaged());
			  ipojo.setIsFeeCollected(ip.getIsFeeCollected());
			  ipojo.setIsLost(ip.getIsLost());
			  ipojo.setRecoveredCost(ip.getRecoveredCost());
			  upempSession.update(ipojo);
				
				upempTx.commit();
				
				sb.append("<Issue>");
				sb.append("\n");
				sb.append("update successfully");
				sb.append("</Issue>");
				String str=sb.toString();
				return str;
			   
	   		 	}
			
			catch(Exception localException)
			{
				System.out.println(localException);
				
				localException.printStackTrace();  
				sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not update Issue info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       outStr= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (upempTx!=null)
		    	 upempTx.rollback();
			}
			finally
			{			
				upempSession.close();
			}
			return outStr;
	}
}