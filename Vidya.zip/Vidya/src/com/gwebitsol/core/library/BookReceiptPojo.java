package com.gwebitsol.core.library;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="bookReceipt")
public class BookReceiptPojo {
	private int 	bookReceiptId;
	private String bookReceiptTitle;
	private String description;
	private int 	quantityReceived;
	private int 	inVoiceNo;
	private int 	orderNo;
	private int 	inVoiceAmount;
	private int 	bookPrice;
	private String 	dateReceived;
	
	private String 	createdDate;
	DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	 Date date = new Date();
	 String modifiedDate=dateFormat.format(date);
	
		private int schoolId;
		private int branchId;

	public int getSchoolId() {
			return schoolId;
		}
		public void setSchoolId(int schoolId) {
			this.schoolId = schoolId;
		}
		public int getBranchId() {
			return branchId;
		}
		public void setBranchId(int branchId) {
			this.branchId = branchId;
		}
	public String getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public int getBookReceiptId() {
		return bookReceiptId;
	}
	public void setBookReceiptId(int bookReceiptId) {
		this.bookReceiptId = bookReceiptId;
	}
	public int getQuantityReceived() {
		return quantityReceived;
	}
	public void setQuantityReceived(int quantityReceived) {
		this.quantityReceived = quantityReceived;
	}
	public int getInVoiceNo() {
		return inVoiceNo;
	}
	public void setInVoiceNo(int inVoiceNo) {
		this.inVoiceNo = inVoiceNo;
	}
	public int getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(int orderNo) {
		this.orderNo = orderNo;
	}
	public int getInVoiceAmount() {
		return inVoiceAmount;
	}
	public void setInVoiceAmount(int inVoiceAmount) {
		this.inVoiceAmount = inVoiceAmount;
	}
	public int getBookPrice() {
		return bookPrice;
	}
	public void setBookPrice(int bookPrice) {
		this.bookPrice = bookPrice;
	}
	public String getDateReceived() {
		return dateReceived;
	}
	public void setDateReceived(String dateReceived) {
		this.dateReceived = dateReceived;
	}
	public String getBookReceiptTitle() {
		return bookReceiptTitle;
	}
	public void setBookReceiptTitle(String bookReceiptTitle) {
		this.bookReceiptTitle = bookReceiptTitle;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	

}
