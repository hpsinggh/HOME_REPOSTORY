package com.gwebitsol.core.library;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;
@Repository
public class CatalogueDao {
	
	public String addCatalogue(CataloguePojo cps) {
		Session addempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction addempTx=null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			addempTx=addempSession.beginTransaction();
	        Integer in=(Integer)addempSession.save(cps);
			System.out.println(in);
			
			addempTx.commit();
			
			sb.append("<Catalogue>");
			sb.append("\n");
			sb.append("<bookId>");
			sb.append(in);
			sb.append("</bookId>");
			sb.append("</Catalogue>");
			String str=sb.toString();
			return str;
		   
   		 	}
		
		catch(Exception localException)
		{
			System.out.println(localException);
			
			localException.printStackTrace();  
			sb.append("<Response>");
	       sb.append("\n");
	       sb.append("<Result>");
	       sb.append("\n");
	       sb.append("Fail");
	       sb.append("\n");
	       sb.append("</Result>");
	       sb.append("\n");
	       sb.append("<Description>");
	       
	       sb.append("could not inserted Catalogue info");
	       sb.append("</Description>");
	       sb.append("\n");
	       sb.append("<Exception>");
	       sb.append(localException);
	       sb.append("</Exception>");
	       sb.append("</Response>");
	       outStr= sb.toString();
	      MDTransactionWriter.exceptionlog.info(localException);
	     if (addempTx!=null)
	      addempTx.rollback();
		}
		finally
		{			
			addempSession.close();
		}
		return outStr;
	}
	public String updateCatalogue(CataloguePojo cps,int schoolId,int branchId) {
		Session upempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction upempTx=null;
		StringBuffer sb=new StringBuffer();

		String outStr=null;
		try
		{
			upempTx=upempSession.beginTransaction();
			CataloguePojo cat = (CataloguePojo) upempSession.get(CataloguePojo.class,cps.getBookId());
		      
			   if(branchId==cat.getBranchId()&&schoolId==cat.getSchoolId())
			       
			    upempSession.evict(cat);
			 upempSession.update(cps);
				
				upempTx.commit();
				
				sb.append("<Catalogue>");
				sb.append("\n");
				sb.append("update successfully");
				sb.append("</Catalogue>");
				String str=sb.toString();
				return str;
			   
	   		 	}
			
			catch(Exception localException)
			{
				System.out.println(localException);
				
				localException.printStackTrace();  
				sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not update Catalogue info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       outStr= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (upempTx!=null)
		    	 upempTx.rollback();

			}
			finally
			{			
				upempSession.close();
			}
			return outStr;

	}
	public String deleteCatalogue(int bookId,int schoolId,int branchId) {
		Session delempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction delempTx=null;
		StringBuffer sb=new StringBuffer();

		String outStr=null;
		try
		{
			delempTx=delempSession.beginTransaction();
			CataloguePojo mdclpojo = (CataloguePojo) delempSession.get(CataloguePojo.class,bookId);
			   
			   int branid = mdclpojo.getBranchId();
			   int sclid = mdclpojo.getSchoolId();
			   delempSession.evict(mdclpojo);  
			   if(branchId==branid&&schoolId==sclid)
			   {
				   Query empQuery=delempSession.createSQLQuery("update gbl_sm_tbl_catalogue set isDeleted='y' where bookId='"+bookId+"'");
				   empQuery.executeUpdate();
			
				   delempTx.commit();
				
				sb.append("<Catalogue>");
				sb.append("\n");
				sb.append("delete successfully");
				sb.append("</Catalogue>");
				String str=sb.toString();
				return str;
			   
	   		 	}
		}
			
			catch(Exception localException)
			{
				System.out.println(localException);
				
				localException.printStackTrace();  
				sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not delete Catalogue info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       outStr= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (delempTx!=null)
		    	 delempTx.rollback();

			}
			finally
			{			
				delempSession.close();
			}
			return outStr;
	}
	@SuppressWarnings("rawtypes")
	public String getByIdCatalogue(int bookId,int schoolId,int branchId) {
		Session gtempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gtempTx=null;
		StringBuffer sb=new StringBuffer();

		
		System.out.println("hi success");
		String strg= null;
			try {
					gtempTx = gtempSession.beginTransaction();
					List list=gtempSession.createSQLQuery("select cat.BookId,cat.BookTypeId,bt.BookTypeName,cat.LibSubjectId,ls.SubjectName,cat.LibSectionId,lsec.SectionName,cat.BookReceiptId,br.BookReceiptTitle,cat.CatalogueName,cat.BookNo,cat.BookTitle,cat.image,cat.Author,cat.ISBN,cat.Barcode,cat.Publisher,cat.Volume,cat.PublisheDate,cat.Printer,cat.TypeSetter,cat.RackNo,cat.RowNo,cat.OrderNo,cat.Quantity,cat.BookCost,cat.IsIssue,cat.Description,cat.SchoolId,cat.BranchId from  gbl_sm_tbl_catalogue as cat join gbl_sm_tbl_book_type as bt on cat.BookTypeId=bt.BookTypeId join gbl_sm_tbl_lib_subject as ls on cat.LibSubjectId=ls.LibSubjectId join gbl_sm_tbl_lib_section as lsec on cat.LibSectionId=lsec.LibSectionId join gbl_sm_tbl_bookreceipt as br on cat.BookReceiptId=br.BookReceiptId where cat.BookId='" + bookId + "' and cat.SchoolId='" + schoolId + "' and cat.BranchId='" + branchId + "' and cat.IsDeleted Is Null;").list();
					//List<CataloguePojo> cat=new ArrayList<CataloguePojo>(list);
					Iterator it=list.iterator();
					sb.append("<Catalogue>");
					sb.append("\n");
					while(it.hasNext()){
						Object[] ex=(Object[])it.next();
				        sb.append("\n");
				        sb.append("<bookId>");
					    sb.append(ex[0]);
					    sb.append("</bookId>");
					    sb.append("\n");
					    sb.append("<bookTypeId>");
						 sb.append(ex[1]);
						 sb.append("</bookTypeId>");
						 sb.append("\n");
						 sb.append("<bookTypeName>");
						 sb.append(ex[2]);
						 sb.append("</bookTypeName>");
						 sb.append("\n");
						 sb.append("<libSubjectId>");
						 sb.append(ex[3]);
						 sb.append("</libSubjectId>");
						 sb.append("\n");
						 sb.append("<subjectName>");
						 sb.append(ex[4]);
						 sb.append("</subjectName>");
						 sb.append("\n");
					
						 sb.append("<libSectionId>");
						 sb.append(ex[5]);
						 sb.append("</libSectionId>");
						 sb.append("\n");
						 sb.append("<sectionName>");
						 sb.append(ex[6]);
						 sb.append("</sectionName>");
						 sb.append("\n");
						 sb.append("<bookReceiptId>");
						 sb.append(ex[7]);
						 sb.append("</bookReceiptId>");
						 sb.append("\n");
						 sb.append("<bookReceiptTitle>");
						 sb.append(ex[8]);
						 sb.append("</bookReceiptTitle>");
						 sb.append("\n");
				        sb.append("<catalogueName>");
					    sb.append(ex[9]);
					    sb.append("</catalogueName>");
					    sb.append("\n");
					    sb.append("<bookNo>");
						sb.append(ex[10]);
						sb.append("</bookNo>");
						sb.append("\n");
						sb.append("<bookTitle>");
						sb.append(ex[11]);
						sb.append("</bookTitle>");
						 sb.append("\n");
						 sb.append("<image>");
						 sb.append(ex[12]);
						 sb.append("</image>");
						 sb.append("\n");
						 sb.append("<author>");
						 sb.append(ex[13]);
						 sb.append("</author>");
						 sb.append("\n");
						 sb.append("<ISBN>");
						 sb.append(ex[14]);
						 sb.append("</ISBN>");
						 sb.append("\n");
						 sb.append("<barcode>");
						 sb.append(ex[15]);
						 sb.append("</barcode>");
						 sb.append("\n");
						 sb.append("<publisher>");
						 sb.append(ex[16]);
						 sb.append("</publisher>");
						 sb.append("\n");
						 sb.append("<volume>");
						 sb.append(ex[17]);
						 sb.append("</volume>");
						 sb.append("\n");
						 sb.append("<publisheDate>");
						 sb.append(ex[18]);
						 sb.append("</publisheDate>");
						 sb.append("\n");
						 sb.append("<printer>");
						 sb.append(ex[19]);
						 sb.append("</printer>");
						 sb.append("\n");
						 sb.append("<typeSetter>");
						 sb.append(ex[20]);
						 sb.append("</typeSetter>");
						 sb.append("\n");
						 
						 
						 sb.append("<rackNo>");
						 sb.append(ex[21]);
						 sb.append("</rackNo>");
						 sb.append("\n");
						 
						 sb.append("<rowNo>");
						 sb.append(ex[22]);
						 sb.append("</rowNo>");
						 sb.append("\n");
						 sb.append("<orderNo>");
						 sb.append(ex[23]);
						 sb.append("</orderNo>");
						 sb.append("\n");
						
						
						sb.append("<quantity>");
						 sb.append(ex[24]);
						 sb.append("</quantity>");
						 sb.append("\n");
						 sb.append("<bookCost>");
						 sb.append(ex[25]);
						 sb.append("</bookCost>");
						 sb.append("\n");
						 
						 sb.append("<isIssue>");
						 sb.append(ex[26]);
						 sb.append("</isIssue>");
						 sb.append("\n");
						 sb.append("<description>");
						 sb.append(ex[27]);
						 sb.append("</description>");
						 sb.append("\n");
						 sb.append("<schoolId>");
					        sb.append(ex[28]);
					        sb.append("</schoolId>");
					        sb.append("\n");
					        sb.append("<branchId>");
					        sb.append(ex[29]);
					        sb.append("</branchId>");
					        sb.append("\n");
					}
						 sb.append("</Catalogue>");
							    String str= sb.toString();
							return str;
					
			} 	catch (Exception localException) {
				System.out.println(localException);
				
				localException.printStackTrace();  
				sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not get Catalogue info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       strg= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (gtempTx!=null)
		    	 gtempTx.rollback();

				} finally {
					gtempSession.close();
				}
		return strg;
	}
	@SuppressWarnings("rawtypes")
	public String getAllCatalogue(int PNO, int size,int schoolId,int branchId) {
		Session rdSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb= new StringBuffer();
		String string=null;
		try
		{
			tx = rdSession.beginTransaction();
			int fset = (PNO-1)*size;
			String gsSql ="select count(*) from gbl_sm_tbl_catalogue where isDeleted is null and schoolId="+schoolId+" and branchId="+branchId+"";
			Query gsQuery=rdSession.createSQLQuery(gsSql);
			Object noRecords= gsQuery.uniqueResult();
			int intNoRecords=0;
			if(noRecords!=null && Integer.parseInt(noRecords.toString())!=0)
			{
				intNoRecords=Integer.parseInt(noRecords.toString());
			}
			sb.append("<Catalogues>");
			sb.append("\n");
			sb.append("<noRecords>"+intNoRecords+"</noRecords>");
			sb.append("\n");
			if(intNoRecords!=0)
			{
			 if (PNO > 0 & size > 0){
			 gsSql="select cat.BookId,cat.BookTypeId,bt.BookTypeName,cat.LibSubjectId,ls.SubjectName,cat.LibSectionId,lsec.SectionName,cat.BookReceiptId,br.BookReceiptTitle,cat.CatalogueName,cat.BookNo,cat.BookTitle,cat.image,cat.Author,cat.ISBN,cat.Barcode,cat.Publisher,cat.Volume,cat.PublisheDate,cat.Printer,cat.TypeSetter,cat.RackNo,cat.RowNo,cat.OrderNo,cat.Quantity,cat.BookCost,cat.IsIssue,cat.Description,cat.SchoolId,cat.BranchId from  gbl_sm_tbl_catalogue as cat join gbl_sm_tbl_book_type as bt on cat.BookTypeId=bt.BookTypeId join gbl_sm_tbl_lib_subject as ls on cat.LibSubjectId=ls.LibSubjectId join gbl_sm_tbl_lib_section as lsec on cat.LibSectionId=lsec.LibSectionId join gbl_sm_tbl_bookreceipt as br on cat.BookReceiptId=br.BookReceiptId where cat.SchoolId='" + schoolId + "' and cat.BranchId='" + branchId + "' and cat.IsDeleted Is Null limit "+size+" offset "+fset;}
			 else {
			  gsSql="select cat.BookId,cat.BookTypeId,bt.BookTypeName,cat.LibSubjectId,ls.SubjectName,cat.LibSectionId,lsec.SectionName,cat.BookReceiptId,br.BookReceiptTitle,cat.CatalogueName,cat.BookNo,cat.BookTitle,cat.image,cat.Author,cat.ISBN,cat.Barcode,cat.Publisher,cat.Volume,cat.PublisheDate,cat.Printer,cat.TypeSetter,cat.RackNo,cat.RowNo,cat.OrderNo,cat.Quantity,cat.BookCost,cat.IsIssue,cat.Description,cat.SchoolId,cat.BranchId from  gbl_sm_tbl_catalogue as cat join gbl_sm_tbl_book_type as bt on cat.BookTypeId=bt.BookTypeId join gbl_sm_tbl_lib_subject as ls on cat.LibSubjectId=ls.LibSubjectId join gbl_sm_tbl_lib_section as lsec on cat.LibSectionId=lsec.LibSectionId join gbl_sm_tbl_bookreceipt as br on cat.BookReceiptId=br.BookReceiptId where cat.SchoolId='" + schoolId + "' and cat.BranchId='" + branchId + "' and cat.IsDeleted Is Null";
			 } 
   
			gsQuery=rdSession.createSQLQuery(gsSql);
			List gcList=gsQuery.list();
			Iterator gsIT=gcList.iterator();
			 while(gsIT.hasNext())
			 {
			  Object[] mdcArr=(Object[])gsIT.next();
			  sb.append("<Catalogue>");
			  sb.append("\n");
			  sb.append("<bookId>"+mdcArr[0]+"</bookId>");
			  sb.append("\n");
			  sb.append("<bookTypeId>" + mdcArr[1]+ "</bookTypeId>");
			  sb.append("\n");
			  sb.append("<bookTypeName>" + mdcArr[2]+ "</bookTypeName>");
			  sb.append("\n");
			  sb.append("<libSubjectId>" + mdcArr[3]+ "</libSubjectId>");
			  sb.append("\n");
			  sb.append("<subjectName>" + mdcArr[4]+ "</subjectName>");
			  sb.append("\n");
			  sb.append("<libSectionId>" + mdcArr[5] + "</libSectionId>");
			  sb.append("\n");
			  sb.append("<sectionName>" + mdcArr[6]+ "</sectionName>");
			  sb.append("\n");
			  sb.append("<bookReceiptId>" + mdcArr[7] + "</bookReceiptId>");
			  sb.append("\n");
			  sb.append("<bookReceiptTitle>" + mdcArr[8] + "</bookReceiptTitle>");
			  sb.append("\n");
			  sb.append("<catalogueName>" + mdcArr[9] + "</catalogueName>");
			  sb.append("\n");
			  sb.append("<bookNo>" + mdcArr[10]+ "</bookNo>");
			  sb.append("\n");
			  sb.append("<bookTitle>" + mdcArr[11] + "</bookTitle>");
			  sb.append("\n");
			  sb.append("<image>" + mdcArr[12] + "</image>");
			  sb.append("\n");
			  sb.append("<author>" + mdcArr[13] + "</author>");
			  sb.append("\n");
			  sb.append("<ISBN>" + mdcArr[14] + "</ISBN>");
			  sb.append("\n");
			  sb.append("<barcode>" + mdcArr[15] + "</barcode>");
			  sb.append("\n");
			  sb.append("<publisher>" + mdcArr[16]+ "</publisher>");
			  sb.append("\n");
			  sb.append("<volume>" +  mdcArr[17]+ "</volume>");
			  sb.append("\n");
			  sb.append("<publisheDate>" +  mdcArr[18]+ "</publisheDate>");
			  sb.append("\n");
			  sb.append("<printer>" +  mdcArr[19] + "</printer>");
			  sb.append("\n");
			  sb.append("<typeSetter>" + mdcArr[20] + "</typeSetter>");
			  sb.append("\n");
			  sb.append("<rackNo>" + mdcArr[21] + "</rackNo>");
			  sb.append("\n");
			  sb.append("<rowNo>" + mdcArr[22] + "</rowNo>");
			  sb.append("\n");
			  sb.append("<orderNo>" + mdcArr[23]+ "</orderNo>");
			  sb.append("\n");
			  sb.append("<quantity>" +  mdcArr[24]+ "</quantity>");
			  sb.append("\n");
			  sb.append("<bookCost>" +  mdcArr[25]+ "</bookCost>");
			  sb.append("\n");
			  sb.append("<isIssue>" +  mdcArr[26] + "</isIssue>");
			  sb.append("\n");
			  sb.append("<description>" +  mdcArr[27] + "</description>");
			  sb.append("\n");
			  sb.append("<schoolId>" + mdcArr[28]+ "</schoolId>");
		      sb.append("\n");
		      sb.append("<branchId>" + mdcArr[29]+ "</branchId>");
		      sb.append("\n");
			  sb.append("</Catalogue>");
			  sb.append("\n");
			 }
			}
			 tx.commit();
			sb.append("</Catalogues>");
			sb.append("\n");

			string=sb.toString();
			   
			  } 
			  catch(Exception localException)
			  {
				  tx.rollback();
			   localException.printStackTrace();
			   string = "fail";
			   System.out.println("Could not Get Catalogues");
			  }
			  finally
			  {
			   rdSession.close();
			  } 
			  return string;

			 }

		
}


