package com.gwebitsol.core.library;

import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement(name="libsubject")
public class LibSubjectPojo {
	private int 	libSubjectId;
	private String 	subjectName;
	private String 	description;
	private int 	libCategoryId;
	private int schoolId;
	private int branchId;
	public int getSchoolId() {
		return schoolId;
	}
	public void setSchoolId(int schoolId) {
		this.schoolId = schoolId;
	}
	public int getBranchId() {
		return branchId;
	}
	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}
	public int getLibSubjectId() {
		return libSubjectId;
	}
	public void setLibSubjectId(int libSubjectId) {
		this.libSubjectId = libSubjectId;
	}
	public String getSubjectName() {
		return subjectName;
	}
	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getLibCategoryId() {
		return libCategoryId;
	}
	public void setLibCategoryId(int libCategoryId) {
		this.libCategoryId = libCategoryId;
	}
	
	
	
	
	
    
}
