package com.gwebitsol.core.library;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.gwebitsol.core.security.MDValidation;
import com.gwebitsol.core.usermanagement.MDGetUserFromID;
import com.gwebitsol.core.util.MDTransactionWriter;

public class IssueService implements IssueIntf {
	@Context 
	private HttpServletRequest hsr;
	public Response addIssues(IssuePojo ip,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String XMLString=null;
	    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		ip.setSchoolId(schoolId);
		ip.setBranchId(branchId);
		  try
		  {
		   MDValidation mdv = new MDValidation();  
		   int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
		   System.out.println("verifiedvalue::"+ret);
		   MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userID);
		   if(ret==1 )//&& rtVal==1)
		   {
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				IssueDao idao=new IssueDao();
				XMLString=idao.addIssues(ip);
				System.out.println(XMLString);
				MDTransactionWriter.writeLog(datastoreName,"IssuePojo_addIssues",requester,startDate,endDate,sl,el,XMLString,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}
			
		}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			XMLString="failed in service layer";
		}
	
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	
	}
	public Response updateIssues(IssuePojo ip,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
		String XMLString=null;
	    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		ip.setSchoolId(schoolId);
		ip.setBranchId(branchId);
		 try
		  {
		   MDValidation mdv = new MDValidation();  
		   int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
		   System.out.println("verifiedvalue::"+ret);
		   MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userID);
		   if(ret==1 )//&& rtVal==1)
		   {

				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				IssueDao idao=new IssueDao();
				XMLString=idao.updateIssues(ip,schoolId,branchId);
				System.out.println(XMLString);
				MDTransactionWriter.writeLog(datastoreName,"IssuePojo_updateIssues",requester,startDate,endDate,sl,el,XMLString,hsr.getRemoteHost());
			}
			else
			{
				XMLString="you are not authorised user";
			}
			
		}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
		   XMLString="failed in service layer";
		}
	
		return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
	}
	
	
	
	
	public Response deleteIssues(int issueId,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		@SuppressWarnings("unused")
		String XMLString=null;
		String status=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
		
		 try
		  {
		   MDValidation mdv = new MDValidation();  
		   int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
		   System.out.println("verifiedvalue::"+ret);
		   MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userID);
		   if(ret==1 )//&& rtVal==1)
		   {

				IssueDao idao=new IssueDao();
				status=idao.deleteIssues(issueId,schoolId,branchId);
		
				String endDate=dateFormat.format(new Date());	
				Long el=System.currentTimeMillis();
		
				MDTransactionWriter.writeLog(datastoreName,"IssuePojo_deleteIssues",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		
			}
			else
			{
				XMLString="you are not authorised user";
			}
			
		}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			status="failed in service layer";
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();			
	}
	public Response getByIdIssue(int issueId,int userID, int connectionID,String datastoreName,int schoolId,int branchId) {
		MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost());	
		@SuppressWarnings("unused")
		String XMLString=null;

		String status1=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		String startDate=dateFormat.format(date);
		Long sl=System.currentTimeMillis();
				
		 try
		  {
		   MDValidation mdv = new MDValidation();  
		   int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
		   System.out.println("verifiedvalue::"+ret);
		   MDGetUserFromID mdgufid = new MDGetUserFromID();
			String requester = mdgufid.getUserName(userID);
		   if(ret==1 )//&& rtVal==1)
		   {

			IssueDao ex=new IssueDao();
			 status1=ex.getByIdIssue(issueId,schoolId,branchId);
			 System.out.println(status1);
			String endDate=dateFormat.format(new Date());
			Long el=System.currentTimeMillis();
			//status1="user validation successfull";
			MDTransactionWriter.writeLog(datastoreName,"IssuePojo_getByIdIssue",requester,startDate,endDate,sl,el,status1,hsr.getRemoteHost());		
			}
			else
			{
				XMLString="you are not authorised user";
			}
			
		}
		catch(Exception localException)
		{
			MDTransactionWriter.errorlog.debug(localException);
			MDTransactionWriter.errorlog.info(localException);
			status1="failed in service layer";
			//System.out.println(localException);
		}
		return Response.ok().type(MediaType.APPLICATION_XML).entity(status1).build();
	}
	
	
	public Response getAllIssues(int userID, int connectionID,String datastoreName,int PNO,int size,int schoolId,int branchId) {
			MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
			
			@SuppressWarnings("unused")
			String XMLString=null;

			String status=null;
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date date = new Date();
			String startDate=dateFormat.format(date);
			Long sl=System.currentTimeMillis();
			 try
			  {
			   MDValidation mdv = new MDValidation();  
			   int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			   System.out.println("verifiedvalue::"+ret);
			   MDGetUserFromID mdgufid = new MDGetUserFromID();
				String requester = mdgufid.getUserName(userID);
			   if(ret==1 )//&& rtVal==1)
			   {

				IssueDao ex=new IssueDao();
				status=ex.getAllIssues(PNO,size,schoolId,branchId);
				System.out.println(status);
				String endDate=dateFormat.format(new Date());
				  Long el=System.currentTimeMillis();
				 MDTransactionWriter.writeLog(datastoreName,"IssuePojo_getAllIssues",requester,startDate,endDate,sl,el,status,hsr.getRemoteHost());		

				}
				else
				{
					XMLString="you are not authorised user";
				}
				
			}
				catch(Exception localException)
			   {
				  MDTransactionWriter.errorlog.debug(localException);
				  MDTransactionWriter.errorlog.info(localException);
				  status="failed in service layer";
			   }
			return Response.ok().type(MediaType.APPLICATION_XML).entity(status).build();
	}
				
		@SuppressWarnings("unused")
	public Response updateReturns(int issueId, int userID, int connectionID, String datastoreName,int schoolId,int branchId) {
			MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
			String XMLString=null;
			String statusString=null;
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date date = new Date();
			String startDate=dateFormat.format(date);
			Long sl=System.currentTimeMillis();
			 try
			  {
			   MDValidation mdv = new MDValidation();  
			   int ret =mdv.allvalidations(userID, connectionID, datastoreName,schoolId,branchId);
			   System.out.println("verifiedvalue::"+ret);
			   MDGetUserFromID mdgufid = new MDGetUserFromID();
				String requester = mdgufid.getUserName(userID);
			   if(ret==1 )//&& rtVal==1)
			   {
					IssueDao gmDAO=new IssueDao();
					IssuePojo issp=new IssuePojo();
				XMLString=gmDAO.updateReturns(issueId,schoolId,branchId);
				if(XMLString.equals("group updation failed"))
					statusString="failed";
				else
					statusString="success";
				String endDate=dateFormat.format(new Date());
				Long el=System.currentTimeMillis();
				
				MDTransactionWriter.writeLog(datastoreName,"IssuePojo_updateReturns",requester,startDate,endDate,sl,el,statusString,hsr.getRemoteHost());
				}
				else
				{
					XMLString="you are not authorised user";
				}
			
			}
			catch(Exception localException)
			{
				MDTransactionWriter.errorlog.debug(localException);
				MDTransactionWriter.errorlog.info(localException);
				statusString="failed in service layer";
			}
			return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
		}
		@Override
		public Response updateReturnlist(IssuePojo ip, int userid, int connectionid, String datastoreName, int schoolId,
				int branchId) {
			MDTransactionWriter.accesslog.info("Request from: "+hsr.getRemoteHost()+" at "+new Date());			
			String XMLString=null;
		    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date date = new Date();
			String startDate=dateFormat.format(date);
			Long sl=System.currentTimeMillis();
			ip.setSchoolId(schoolId);
			ip.setBranchId(branchId);
			 try
			  {
			   MDValidation mdv = new MDValidation();  
			   int ret =mdv.allvalidations(userid, connectionid, datastoreName,schoolId,branchId);
			   System.out.println("verifiedvalue::"+ret);
			   MDGetUserFromID mdgufid = new MDGetUserFromID();
				String requester = mdgufid.getUserName(userid);
			   if(ret==1 )//&& rtVal==1)
			   {

					String endDate=dateFormat.format(new Date());
					Long el=System.currentTimeMillis();
					IssueDao idao=new IssueDao();
					XMLString=idao.updateReturnlist(ip,schoolId,branchId);
					System.out.println(XMLString);
					MDTransactionWriter.writeLog(datastoreName,"IssuePojo_updateReturnlist",requester,startDate,endDate,sl,el,XMLString,hsr.getRemoteHost());
				}
				else
				{
					XMLString="you are not authorised user";
				}
				
			}
			catch(Exception localException)
			{
				MDTransactionWriter.errorlog.debug(localException);
				MDTransactionWriter.errorlog.info(localException);
			   XMLString="failed in service layer";
			}
		
			return Response.ok().type(MediaType.APPLICATION_XML).entity(XMLString).build();
		}		
}
