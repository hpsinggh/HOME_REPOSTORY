package com.gwebitsol.core.library;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class LibSubjectDao {

	public String addLibSubjects(LibSubjectPojo lsubp) {
		Session addempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction addempTx=null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		try
		{
			addempTx=addempSession.beginTransaction(); 
		    Integer in=(Integer)addempSession.save(lsubp);
			System.out.println(in);
			
			addempTx.commit();
			
			sb.append("<LibSubject>");
			sb.append("\n");
			sb.append("<LibSubjectId>");
			sb.append(in);
			sb.append("</LibSubjectId>");
			sb.append("</LibSubject>");
			String str=sb.toString();
			return str;
		   
   		 	}
		
		catch(Exception localException)
		{
			System.out.println(localException);
			
			localException.printStackTrace();  
			sb.append("<Response>");
	       sb.append("\n");
	       sb.append("<Result>");
	       sb.append("\n");
	       sb.append("Fail");
	       sb.append("\n");
	       sb.append("</Result>");
	       sb.append("\n");
	       sb.append("<Description>");
	       
	       sb.append("could not inserted LibSubject info");
	       sb.append("</Description>");
	       sb.append("\n");
	       sb.append("<Exception>");
	       sb.append(localException);
	       sb.append("</Exception>");
	       sb.append("</Response>");
	       outStr= sb.toString();
	      MDTransactionWriter.exceptionlog.info(localException);
	     if (addempTx!=null)
	      addempTx.rollback();
		}
		finally
		{			
			addempSession.close();
		}
		return outStr;
	}

	

	public String updateLibSubjects(LibSubjectPojo lsubp,int schoolId,int branchId) {
		
		Session upempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction upempTx=null;
		StringBuffer sb=new StringBuffer();

		String outStr=null;
		try
		{
			upempTx=upempSession.beginTransaction();
			LibSubjectPojo lsubject = (LibSubjectPojo) upempSession.get(LibSubjectPojo.class,lsubp.getLibSubjectId());
		      
			   if(branchId==lsubject.getBranchId()&&schoolId==lsubject.getSchoolId())
			       
			    upempSession.evict(lsubject);
			 upempSession.update(lsubp);
				
				upempTx.commit();
				
				sb.append("<LibSubject>");
				sb.append("\n");
				sb.append("update successfully");
				sb.append("</LibSubject>");
				String str=sb.toString();
				return str;
			   
	   		 	}
			
			catch(Exception localException)
			{
				System.out.println(localException);
				
				localException.printStackTrace();  
				sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not update LibSubject info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       outStr= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (upempTx!=null)
		    	 upempTx.rollback();
			}
			finally
			{			
				upempSession.close();
			}
			return outStr;
	}



	public String deleteLibSubjects(int libSubjectId,int schoolId,int branchId) {
		Session delempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction delempTx=null;
		StringBuffer sb=new StringBuffer();

		String outStr=null;
		try
		{
			delempTx=delempSession.beginTransaction();
			LibSubjectPojo mdclpojo = (LibSubjectPojo) delempSession.get(LibSubjectPojo.class,libSubjectId);
			   
			   int branid = mdclpojo.getBranchId();
			   int sclid = mdclpojo.getSchoolId();
			   delempSession.evict(mdclpojo);
			   if(branchId==branid&&schoolId==sclid) 
			   {
				   Query empQuery=delempSession.createSQLQuery("update gbl_sm_tbl_lib_subject set isDeleted='y' where libSubjectId='"+libSubjectId+"'");
				   empQuery.executeUpdate();
			
				   delempTx.commit();
				
				   sb.append("<LibSubject>");
				   sb.append("\n");
				   sb.append("delete successfully");
				   sb.append("</LibSubject>");
				   String str=sb.toString();
				   return str;
	   		 	}
		}
			catch(Exception localException)
			{
				System.out.println(localException);
				
				localException.printStackTrace();  
				sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not delete LibSubject info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       outStr= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (delempTx!=null)
		    	 delempTx.rollback();
			}
			finally
			{			
				delempSession.close();
			}
			return outStr;
	}



	@SuppressWarnings({ "rawtypes", "unchecked" })
	public String getByIdLibSubject(int libSubjectId,int schoolId,int branchId) {
		Session gtempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gtempTx=null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		JSONObject obj = new JSONObject();
		System.out.println("hi dao impl success");
		String strg= null;
			try {
					gtempTx = gtempSession.beginTransaction();	
					List list=gtempSession.createSQLQuery("SELECT ls.LibSubjectId,ls.LibCategoryId,lc.CategoryName,ls.SubjectName,ls.Description,ls.SchoolId,ls.BranchId FROM gbl_sm_tbl_lib_subject as ls INNER JOIN gbl_sm_tbl_lib_category as lc ON ls.LibCategoryId=lc.LibCategoryId where LibSubjectId='" + libSubjectId + "' and ls.SchoolId='" + schoolId + "' and ls.BranchId='" + branchId + "' and ls.IsDeleted Is Null;").list();
					Iterator it=list.iterator();
					
					sb.append("<LibSubject>");
					sb.append("\n");
					while(it.hasNext()){
						Object[] ex=(Object[])it.next();
						
						/*obj.put("libSubjectId",ex[0]);
						obj.put("libCategoryId", ex[1]);
						obj.put("categoryName", ex[2]);
						obj.put("subjectName", ex[3]);
						obj.put("description", ex[4]);
						obj.put("schoolId", ex[5]);
						obj.put("branchId", ex[6]);*/
						
						
						sb.append("<libSubjectId>");
					    sb.append(ex[0]);
					    sb.append("</libSubjectId>");
					    sb.append("\n");
					    sb.append("<libCategoryId>");
					    sb.append(ex[1]);
					    sb.append("</libCategoryId>");
					    sb.append("\n");
					    sb.append("<categoryName>");
						sb.append(ex[2]);
						sb.append("</categoryName>");
						 sb.append("\n");
						sb.append("<subjectName>");
						sb.append(ex[3]);
						sb.append("</subjectName>");
						sb.append("\n");
					   
						sb.append("<description>");
						sb.append(ex[4]);
						sb.append("</description>");
						sb.append("\n");
				        sb.append("<schoolId>");
				        sb.append(ex[5]);
				        sb.append("</schoolId>");
				        sb.append("\n");
				        sb.append("<branchId>");
				        sb.append(ex[6]);
				        sb.append("</branchId>");
				        sb.append("\n");
					 
					}
					 sb.append("</LibSubject>");
					 System.out.println(obj);
					 gtempTx.commit();
					String str= sb.toString();
					
					/*JSONObject obj2 = new JSONObject();
					String xml = XML.toString(json);*/
					return str;
					
			} 	catch (Exception localException) {
				System.out.println(localException);
				
				localException.printStackTrace();  
				sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not get LibSubject info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       strg= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (gtempTx!=null)
		    	 gtempTx.rollback();

				} finally {
					gtempSession.close();
				}
		return strg;
	}



	@SuppressWarnings({ "rawtypes" })
	public String getAllLibSubjects(int PNO, int size,int schoolId,int branchId) {
		Session rdSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		StringBuffer sb= new StringBuffer();
		String string=null;
		JSONObject obj = new JSONObject();
		try
		{
			tx = rdSession.beginTransaction();
			   int fset = (PNO-1)*size;
			String gsSql ="select count(*) from gbl_sm_tbl_lib_subject where isDeleted is null and schoolId="+schoolId+" and branchId="+branchId+"";
			Query gsQuery=rdSession.createSQLQuery(gsSql);
			Object noRecords= gsQuery.uniqueResult();
			int intNoRecords=0;
			if(noRecords!=null && Integer.parseInt(noRecords.toString())!=0)
			{
				intNoRecords=Integer.parseInt(noRecords.toString());
			}
			sb.append("<LibSubjects>");
			sb.append("\n");
			sb.append("<noRecords>"+intNoRecords+"</noRecords>");
			sb.append("\n");
			if(intNoRecords!=0)
			{
			 if (PNO > 0 & size > 0){
			 gsSql="SELECT ls.LibSubjectId,ls.LibCategoryId,lc.CategoryName,ls.SubjectName,ls.Description,ls.SchoolId,ls.BranchId FROM gbl_sm_tbl_lib_subject as ls INNER JOIN gbl_sm_tbl_lib_category as lc ON ls.LibCategoryId=lc.LibCategoryId where ls.SchoolId='" + schoolId + "' and ls.BranchId='" + branchId + "' and ls.IsDeleted Is Null limit "+size+" offset "+fset;}
			 else {
			  gsSql="SELECT ls.LibSubjectId,ls.LibCategoryId,lc.CategoryName,ls.SubjectName,ls.Description,ls.SchoolId,ls.BranchId FROM gbl_sm_tbl_lib_subject as ls INNER JOIN gbl_sm_tbl_lib_category as lc ON ls.LibCategoryId=lc.LibCategoryId where ls.SchoolId='" + schoolId + "' and ls.BranchId='" + branchId + "' and ls.IsDeleted Is Null";
			 } 
   
			gsQuery=rdSession.createSQLQuery(gsSql);
			List gcList=gsQuery.list();
			Iterator gsIT=gcList.iterator();
			 while(gsIT.hasNext())
			 {
			  Object[] mdcArr=(Object[])gsIT.next();
			 /*obj.put("libSubjectId",mdcArr[0]);
				obj.put("libCategoryId", mdcArr[1]);
				obj.put("categoryName", mdcArr[2]);
				obj.put("subjectName", mdcArr[3]);
				obj.put("description", mdcArr[4]);
				obj.put("schoolId", mdcArr[5]);
				obj.put("branchId", mdcArr[6]);*/
				
			 
			//System.out.println(obj);
			
			 sb.append("<libsubjects>");
			  sb.append("\n");
			  sb.append("<libSubjectId>"+mdcArr[0]+"</libSubjectId>");
			  sb.append("\n");
			  sb.append("<libCategoryId>" + mdcArr[1]+ "</libCategoryId>");
			  sb.append("\n");
			  sb.append("<categoryName>" + mdcArr[2]+ "</categoryName>");
			  sb.append("\n");
			  sb.append("<subjectName>" + mdcArr[3]+ "</subjectName>");
			  sb.append("\n");
			  sb.append("<description>" + mdcArr[4] + "</description>");
			  sb.append("\n");
			  sb.append("<schoolId>" + mdcArr[5]+ "</schoolId>");
			  sb.append("\n");
			  sb.append("<branchId>" + mdcArr[6]+ "</branchId>");
			  sb.append("\n");
			  sb.append("</libsubjects>");
			  sb.append("\n");
			 }
			}
			 tx.commit();
			sb.append("</LibSubjects>");
			
			sb.append("\n");
		
			String str=sb.toString();
			
			return str;
			 
			   
			
			
			
			
			  } 
			  catch(Exception localException)
			  {
				  tx.rollback();
			   localException.printStackTrace();
			   string = "fail";
			   System.out.println("Could not Get libsubjects");
			  }
			  finally
			  {
			   rdSession.close();
			  } 
			  return string;

			 }

}
