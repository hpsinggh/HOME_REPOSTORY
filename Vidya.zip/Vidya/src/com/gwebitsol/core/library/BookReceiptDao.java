package com.gwebitsol.core.library;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.gwebitsol.core.util.MDHibernateUtil;
import com.gwebitsol.core.util.MDTransactionWriter;

public class BookReceiptDao {
	
	
	public String addBookReceipt(BookReceiptPojo brp) {
		Session addempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction addempTx=null;
		StringBuffer sb=new StringBuffer();
		String outStr=null;
		
		try
		{
			addempTx=addempSession.beginTransaction();
	        Integer in=(Integer)addempSession.save(brp);
			addempTx.commit();
			System.out.println(in);
			sb.append("<BookReceipt>");
			sb.append("\n");
			sb.append("<BookReceiptId>");
			sb.append(in);
			sb.append("</BookReceiptId>");
			sb.append("</BookReceipt>");
			String str=sb.toString();
			return str;
   		 	}
		
		catch(Exception localException)
		{
			System.out.println(localException);
			
			   localException.printStackTrace();  
			   sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not inserted BookReceipt info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       outStr= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
	     if (addempTx!=null)
	      addempTx.rollback();   
		}
		finally
		{			
			addempSession.close();
		}
		return outStr;
	}

	public String updateBookReceipt(BookReceiptPojo brp,int schoolId,int branchId) {
		Session upempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction upempTx=null;
		StringBuffer sb=new StringBuffer();

		String outStr=null;
		try
		{
			upempTx=upempSession.beginTransaction();
			BookReceiptPojo breceipt = (BookReceiptPojo) upempSession.get(BookReceiptPojo.class,brp.getBookReceiptId());
		      
			   if(branchId==breceipt.getBranchId()&&schoolId==breceipt.getSchoolId())
			       
			    upempSession.evict(breceipt);
			 upempSession.update(brp);
				
				upempTx.commit();
				
				sb.append("<BookReceipt>");
				sb.append("update successfully");
				sb.append("</BookReceipt>");
				String str=sb.toString();
				return str;
			   
	   		 	}
			
			catch(Exception localException)
			{
				System.out.println(localException);
				
			   localException.printStackTrace();  
				sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not update BookReceipt info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       outStr= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (upempTx!=null)
		    	 upempTx.rollback();
			}
			finally
			{			
				upempSession.close();
			}
			return outStr;

	}

	public String deleteBookReceipt(int bookReceiptId,int schoolId,int branchId) {
		Session delempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction delempTx=null;
		StringBuffer sb=new StringBuffer();

		String outStr=null;
		try
		{
			delempTx=delempSession.beginTransaction();
			BookReceiptPojo mdclpojo = (BookReceiptPojo) delempSession.get(BookReceiptPojo.class,bookReceiptId);
			   
			   int branid = mdclpojo.getBranchId();
			   int sclid = mdclpojo.getSchoolId();
			   delempSession.evict(mdclpojo);      
			   if(branchId==branid&&schoolId==sclid)
			   { 
				   Query empQuery=delempSession.createSQLQuery("update gbl_sm_tbl_bookreceipt set isDeleted='y' where bookReceiptId='"+bookReceiptId+"'");
				   empQuery.executeUpdate();
			
				   delempTx.commit();
				
				sb.append("<BookReceipt>");
				sb.append("delete successfully");
				sb.append("</BookReceipt>");
				String str=sb.toString();
				return str;
			   
	   		 	}
		}			
			catch(Exception localException)
			{
System.out.println(localException);
				
				localException.printStackTrace();  
				sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not delete BookReceipt info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       outStr= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (delempTx!=null)
		    	 delempTx.rollback();
			}
			finally
			{			
				delempSession.close();
			}
			return outStr;
	}

	@SuppressWarnings("rawtypes")
	public String getByIdBookReceipt(int bookReceiptId,int schoolId,int branchId) {
		Session gtempSession=MDHibernateUtil.getSessionFactory().openSession();
		Transaction gtempTx=null;
		StringBuffer sb=new StringBuffer();

		
		System.out.println("hi success");
		String strg= null;
			try {
					gtempTx = gtempSession.beginTransaction();
					List list=gtempSession.createSQLQuery("select br.BookReceiptId,br.BookReceiptTitle,br.QuantityReceived,br.InVoiceNo,br.OrderNo,br.InVoiceAmount,br.BookPrice,br.DateReceived,br.Description,br.SchoolId,br.BranchId from gbl_sm_tbl_bookreceipt as br where br.bookReceiptId='" + bookReceiptId + "' and br.SchoolId='" + schoolId + "' and br.BranchId='" + branchId + "' and IsDeleted Is Null;").list();
					Iterator it=list.iterator();
					sb.append("<BookReceipt>");
					while(it.hasNext()){
						Object[] ex=(Object[])it.next();
						sb.append("\n");
				        sb.append("<bookReceiptId>");
					    sb.append(ex[0]);
					    sb.append("</bookReceiptId>");
					    sb.append("\n");
					    sb.append("<bookReceiptTitle>");
					    sb.append(ex[1]);
					    sb.append("</bookReceiptTitle>");
					    sb.append("\n");
					    sb.append("<quantityReceived>");
						sb.append(ex[2]);
						sb.append("</quantityReceived>");
						sb.append("\n");
				        sb.append("<inVoiceNo>");
					    sb.append(ex[3]);
					    sb.append("</inVoiceNo>");
					    sb.append("\n");
					    sb.append("<orderNo>");
						sb.append(ex[4]);
						sb.append("</orderNo>");
						sb.append("\n");
						sb.append("<inVoiceAmount>");
					    sb.append(ex[5]);
					    sb.append("</inVoiceAmount>");
					    sb.append("\n");
					    sb.append("<bookPrice>");
						sb.append(ex[6]);
						sb.append("</bookPrice>");
						sb.append("\n");
				        sb.append("<dateReceived>");
					    sb.append(ex[7]);
					    sb.append("</dateReceived>");
					    sb.append("\n");
					    sb.append("<description>");
					    sb.append(ex[8]);
					    sb.append("</description>");
					    sb.append("\n");
					    sb.append("<schoolId>");
				        sb.append(ex[9]);
				        sb.append("</schoolId>");
				        sb.append("\n");
				        sb.append("<branchId>");
				        sb.append(ex[10]);
				        sb.append("</branchId>");
				        sb.append("\n");
						
					}
					sb.append("</BookReceipt>");
				    String str= sb.toString();
				return str;
					
			} 	catch (Exception localException) {
				System.out.println(localException);
				
				localException.printStackTrace();  
				sb.append("<Response>");
		       sb.append("\n");
		       sb.append("<Result>");
		       sb.append("\n");
		       sb.append("Fail");
		       sb.append("\n");
		       sb.append("</Result>");
		       sb.append("\n");
		       sb.append("<Description>");
		       
		       sb.append("could not get BookReceipt info");
		       sb.append("</Description>");
		       sb.append("\n");
		       sb.append("<Exception>");
		       sb.append(localException);
		       sb.append("</Exception>");
		       sb.append("</Response>");
		       strg= sb.toString();
		      MDTransactionWriter.exceptionlog.info(localException);
		     if (gtempTx!=null)
		    	 gtempTx.rollback();

				} finally {
					gtempSession.close();
				}
		return strg;
	}

	@SuppressWarnings("rawtypes")
	public String getAllBookReceipt(int PNO, int size,int schoolId,int branchId) {
		 Session rdSession=MDHibernateUtil.getSessionFactory().openSession();
			Transaction tx = null;
			StringBuffer sb= new StringBuffer();
			String string=null;
			
			try
			{
				tx = rdSession.beginTransaction();
				
				    int fset = (PNO-1)*size;
				    String gsSql ="select count(*) from gbl_sm_tbl_bookreceipt where isDeleted is null and schoolId="+schoolId+" and branchId="+branchId+"";
				    Query gsQuery=rdSession.createSQLQuery(gsSql);
				    Object noRecords= gsQuery.uniqueResult();
				    int intNoRecords=0;
					if(noRecords!=null && Integer.parseInt(noRecords.toString())!=0)
					{
						intNoRecords=Integer.parseInt(noRecords.toString());
					}
					sb.append("<BookReceipts>");
					sb.append("\n");
					sb.append("<noRecords>"+intNoRecords+"</noRecords>");
					sb.append("\n");
					if(intNoRecords!=0)
					{
				     if (PNO > 0 & size > 0){
				     gsSql="select br.BookReceiptId,br.BookReceiptTitle,br.QuantityReceived,br.InVoiceNo,br.OrderNo,br.InVoiceAmount,br.BookPrice,br.DateReceived,br.Description,br.SchoolId,br.BranchId from gbl_sm_tbl_bookreceipt as br where br.SchoolId='" + schoolId + "' and br.BranchId='" + branchId + "' and  br.IsDeleted is null  limit "+size+" offset "+fset;}
				     else {
				      gsSql="select br.BookReceiptId,br.BookReceiptTitle,br.QuantityReceived,br.InVoiceNo,br.OrderNo,br.InVoiceAmount,br.BookPrice,br.DateReceived,br.Description,br.SchoolId,br.BranchId from gbl_sm_tbl_bookreceipt as br where br.SchoolId='" + schoolId + "' and br.BranchId='" + branchId + "' and br.IsDeleted is null";
				     } 
				   
				    gsQuery=rdSession.createSQLQuery(gsSql);
				    List gcList=gsQuery.list();
				    Iterator gsIT=gcList.iterator();
				     while(gsIT.hasNext())
				     {
				      Object[] mdcArr=(Object[])gsIT.next();
				      sb.append("<bookReceipt>");
				      sb.append("\n");
				      sb.append("<bookReceiptId>"+mdcArr[0]+"</bookReceiptId>");
				      sb.append("\n");
				      /*sb.append("<schoolId>"+mdcArr[1]+"</schoolId>");
				      sb.append("\n");
				      sb.append("<schoolName>"+mdcArr[2]+"</schoolName>");
				      sb.append("\n");
				      sb.append("<branchId>"+mdcArr[3]+"</branchId>");
				      sb.append("\n");
				      sb.append("<branchName>"+mdcArr[4]+"</branchName>");
				      sb.append("\n");*/
				      sb.append("<bookReceiptTitle>"+mdcArr[1]+"</bookReceiptTitle>");
				      sb.append("\n");
				      sb.append("<quantityReceived>" + mdcArr[2]+ "</quantityReceived>");
				      sb.append("\n");
				      sb.append("<inVoiceNo>" + mdcArr[3]+ "</inVoiceNo>");
				      sb.append("\n");
				      sb.append("<orderNo>" + mdcArr[4] + "</orderNo>");
				      sb.append("\n");
				      sb.append("<inVoiceAmount>"+mdcArr[5]+"</inVoiceAmount>");
				      sb.append("\n");
				      sb.append("<bookPrice>" + mdcArr[6]+ "</bookPrice>");
				      sb.append("\n");
				      sb.append("<dateReceived>" + mdcArr[7]+ "</dateReceived>");
				      sb.append("\n");
				      sb.append("<description>" + mdcArr[8]+ "</description>");
				      sb.append("\n");
				      sb.append("<schoolId>" + mdcArr[9]+ "</schoolId>");
				      sb.append("\n");
				      sb.append("<branchId>" + mdcArr[10]+ "</branchId>");
				      sb.append("\n");
				      sb.append("</bookReceipt>");
				      sb.append("\n");
				     }
					}
				     tx.commit();
				    sb.append("</BookReceipts>");
				    sb.append("\n");

				    string=sb.toString();
				   
				 
				  } 
				  catch(Exception localException)
				  {
					  tx.rollback();
				   localException.printStackTrace();
				   string = "fail";
				   System.out.println("Could not Get BookReceipts");
				  }
				  finally
				  {
				   rdSession.close();
				  } 
				  return string;

				 }

		
	}

